% Exact distribution and moments of the least squares estimator in AR(1) models
% MATLAB programs accompanying
%
%   Bao, Y. and Kan, R., "Exact Finite-Sample Distribution and Moments of
%   the Least Squares Estimator in First-Order Autoregressions: O(1)
%   Algorithms," Purdue University and University of Toronto.
%
% Model: y_t = alpha + phi*y_{t-1} + sigma*e_t, t = 1..n, e_t i.i.d. N(0,1).
% Six cases, selected by a two-letter code:
%   (D: deterministic, i.e. fixed, start; S: stationary start)
%   'DK'  y_0 fixed, no intercept (alpha = 0 known);   parameter z0 = y_0/sigma
%   'DU'  y_0 fixed, intercept estimated;  parameter gamma = [alpha-(1-phi)y_0]/sigma
%   'SK'  stationary start, mean known (no intercept);  |phi| < 1
%   'SU'  stationary start, intercept estimated;        |phi| < 1
%   'DT'  y_0 fixed, y_t = alpha + delta t + phi y_{t-1} + sigma e_t, regression
%         on 1, t and y_{t-1}; parameter [gamma gamma_tau] (see ar1_logcf)
%   'ST'  stationary start around a linear trend, the same regression; |phi| < 1
% (the trend cases are described in Section S7 of the Online Supplement
% to the paper)
% In the fixed-start cases phi may be any real number (unit root and
% explosive values included).  The characteristic function and all its
% derivatives cost a bounded number of scalar operations per quadrature
% node, independent of the sample size n (the pivot recursion and the dense
% reference, which exist only as checks, are O(n) and O(n^3)).
%
% Every cdf, pdf and moment routine (except ar1_cmom, whose second output
% is the variance) returns an error estimate as a second output and warns
% ('ratio:accuracy') when it exceeds the requested tolerance; see the
% accuracy notes in ar1_cdf and ar1_logcf.
%
% Exact finite-sample distribution and moments of phihat
%   ar1_cdf       - cdf  P[phihat < x]
%   ar1_pdf       - density of phihat
%   ar1_pdf_rank2 - the density for n = 3 (DK, DU, SU) and n = 4 (DT, ST),
%                   by integrating out the last observation (called by ar1_pdf)
%   ar1_pdf_rank3 - the same for n = 4 in case DK with z0 ~= 0 (called by ar1_pdf)
%   ar1_icdf      - quantiles of phihat
%   ar1_mom       - moments E[(phihat-c)^j], j = 1..k, about any c
%   ar1_cmom      - mean, variance, skewness and excess kurtosis of phihat
%
% Limiting distributions of n(phihat - phi), phi = 1 + c/n
%   ar1lim_cdf, ar1lim_pdf, ar1lim_icdf, ar1lim_mom
%                 - the Dickey-Fuller (c = 0) and local-to-unity limits of
%                   the six cases (Phillips 1987, Perron 1991, Nabeya and
%                   Tanaka 1990, Zhou and Yu 2015, stationary initial condition)
%   ar1lim_ray    - the limit cdf at x = -c in closed form (chi-square
%                   representation of A + cB)
%   ar1explim     - the Cauchy-type limit of the explosive case (White 1958,
%                   Anderson 1959) with a nonzero start
%
% Computational core
%   ar1_logcf     - log of the joint characteristic function of the numerator
%                   and denominator of phihat - phi, O(1) per point, in
%                   Taylor-mode (jet) arithmetic: any order of derivative in
%                   s or t comes out of the same assembly
%   ar1_logcf_exp - the same closed forms in a cancellation-free arrangement
%                   for the explosive region |phi| > 1 (used automatically)
%   ar1_logcf_exps - the same in scaled arguments, for the distribution of
%                   |phi|^n (phihat - phi)/(phi^2 - 1) at any n (AR1_CDF,
%                   AR1_PDF, AR1_ICDF with centered = 'scaled')
%   ar1_logcf_piv - O(n) pivot recursion, an independent check of the
%                   closed-form assembly
%   ar1lim_logcf  - the same for the limiting distributions
%   ttprimsj      - determinant and bilinear forms of the inverse of a
%                   tridiagonal Toeplitz matrix (jets; closed forms in the
%                   roots or Chebyshev expansions at the confluent points)
%   ratio_cdf, ratio_pdf, ratio_icdf, ratio_mom, ratio_scale
%                 - inversion (Gil-Pelaez/Imhof, Geary) and moment (Sawa)
%                   engines for a ratio u/v given the jet of log E exp(isu+itv),
%                   with error estimates and an asymptotic treatment of
%                   slowly decaying tails (ar1lim_opts)
%   ar1_args      - argument validation shared by the finite-sample routines
%   jm, jd, jc, jsq, jlog0, jexp0, jexp, jpow, jcos
%                 - arithmetic of truncated power series (jets)
%
% Validation and examples
%   ar1_demo      - worked examples (start here)
%   ar1_test      - validation suite with assertions and a failure count
%                   (closed form vs dense O(n^3) evaluation, phase
%                   continuity, jets, cdf/pdf consistency, Monte Carlo,
%                   limits, cost against n, explosive region, regressions);
%                   ar1_test(true) is a quick version, ar1_test(quick,true)
%                   raises an error when a test fails (for scripts)
%   cf_dense      - dense O(n^3) reference characteristic function
%   ar1_paper     - reproduces the tables and figures of the paper (MATLAB
%                   graphics; the tables also run in Octave)
%   ar1_trend_tables - reproduces the tables of Section S7 of the Supplement
%   dfcompare     - the simulated tables of adftest against the exact
%                   Dickey-Fuller distribution (requires the Econometrics
%                   Toolbox; the only file that does)
%   validation/   - the 250-digit reference evaluation of the explosive
%                   region (hp_ref.py, Python/mpmath) with its parameter
%                   grid and output, the 40-digit dense reference of
%                   Table 2 of the paper (hp_acc.py), and the high-precision
%                   dense reference of case DT in the explosive region
%                   (hp_trend.py, hp_trend_ref.txt)
%   doc/          - the user manual (ar1_manual.pdf)
%
% Requirements.  Base MATLAB (R2019b or later); the computational core and
% the test suite also run on GNU Octave (tested with Octave 8).  ar1_demo
% uses table/disp, ar1_paper uses MATLAB graphics and dfcompare needs the
% Econometrics Toolbox.
%
% License: MIT (see LICENSE).  Please cite the paper when using the programs.
