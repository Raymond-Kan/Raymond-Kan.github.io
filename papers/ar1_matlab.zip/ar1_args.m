function [cas,par0] = ar1_args(n,phi,cas,par0,x)
%AR1_ARGS  Validation of the common arguments of the finite-sample routines.
%   [cas,par0] = AR1_ARGS(n,phi,cas,par0,x) checks that n is an integer >= 3,
%   phi a finite real scalar, cas one of 'DK','DU','SK','SU','DT','ST'
%   (returned in upper case; a stationary start requires |phi| < 1), par0 a
%   finite real scalar (returned as 0 when empty; in case 'DT' a scalar gamma
%   or a pair [gamma gamma_tau], returned as a pair) and x, if given, a real
%   array of finite values.
if ~(isnumeric(n) && isscalar(n) && isreal(n) && isfinite(n) && n == round(n) && n >= 3)
    error('ar1:n','n must be an integer >= 3.');
end
if ~(isnumeric(phi) && isscalar(phi) && isreal(phi) && isfinite(phi))
    error('ar1:phi','phi must be a finite real scalar.');
end
if ~(ischar(cas) || isstring(cas))
    error('ar1:cas','cas must be one of ''DK'', ''DU'', ''SK'', ''SU'', ''DT'', ''ST''.');
end
cas = upper(char(cas));
if ~ismember(cas,{'DK','DU','SK','SU','DT','ST'})
    error('ar1:cas','cas must be one of ''DK'', ''DU'', ''SK'', ''SU'', ''DT'', ''ST''.');
end
if cas(2) == 'T' && n < 4
    error('ar1:n','Trend cases require n >= 4.');
end
if cas(1) == 'S' && abs(phi) >= 1
    error('ar1:phi','A stationary start requires |phi| < 1.');
end
if nargin < 4 || isempty(par0), par0 = 0; end
if strcmp(cas,'DT')
    if ~(isnumeric(par0) && isreal(par0) && all(isfinite(par0(:))) && any(numel(par0) == [1 2]))
        error('ar1:par0','in case DT par0 must be gamma or [gamma gamma_tau] (finite reals).');
    end
    if isscalar(par0), par0 = [par0 0]; end
    par0 = par0(:).';
elseif ~(isnumeric(par0) && isscalar(par0) && isreal(par0) && isfinite(par0))
    error('ar1:par0','par0 must be a finite real scalar.');
end
if nargin >= 5 && ~(isnumeric(x) && isreal(x) && all(isfinite(x(:))))
    error('ar1:x','the evaluation points must be real and finite.');
end
end
