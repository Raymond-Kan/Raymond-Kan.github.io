function [F,err] = ar1_cdf(x,n,phi,cas,par0,tol,centered)
%AR1_CDF  Exact cdf of the least squares estimator of the AR(1) coefficient.
%
%   F = AR1_CDF(x,n,phi,cas,par0) returns P[phihat < x] for the least
%   squares estimator of phi in y_t = alpha + phi y_{t-1} + sigma e_t,
%   t = 1,...,n, with i.i.d. N(0,1) errors, evaluated at the points in x.
%   cas selects the case (see AR1_LOGCF):
%     'DK'  y_0 fixed, no intercept (alpha = 0 known);  par0 = z0 = y_0/sigma
%     'DU'  y_0 fixed, intercept estimated;  par0 = gamma = [alpha-(1-phi)y_0]/sigma
%     'SK'  stationary start, no intercept (mean known); |phi| < 1
%     'SU'  stationary start, intercept estimated;      |phi| < 1
%     'DT'  fixed start with intercept and trend; par0 = [gamma gamma_tau]
%     'ST'  stationary start with intercept and trend; |phi| < 1
%   Trend cases require n >= 4. See AR1_LOGCF for drift conventions.
%   For the fixed-start cases any real phi is allowed, including the unit
%   root and explosive values.  tol (optional) is the absolute tolerance of
%   the quadrature (default 1e-10).  With centered = true (7th argument) x
%   is read as phihat - phi rather than phihat; this matters in the
%   explosive region, where phihat - phi is of order phi^{-n} and
%   phi + x may not be representable (e.g. 1.2 + 1e-17 == 1.2).
%   With centered = 'scaled' (|phi| > 1, cases 'DK', 'DU' and 'DT') x is
%   read as a value of X_n = |phi|^n (phihat - phi)/(phi^2 - 1), the
%   statistic of order one whose limit is AR1EXPLIM, and P[X_n < x] is
%   returned for any n: the characteristic function is then evaluated in
%   scaled arguments by AR1_LOGCF_EXPS, which has no upper limit in n
%   (with x read as phihat or phihat - phi, phi^(2n) must stay below about
%   1e300).
%   [F,err] = AR1_CDF(...) also returns an estimate of the error of each
%   value (quadrature error plus the rounding noise of the characteristic
%   function, see RATIO_CDF); a warning is issued when it exceeds tol.
%
%   Accuracy.  The characteristic function is evaluated with a relative
%   error of a few units of rounding away from the unit root, and of order
%   n eps near phi = 1 (the O(1) quantities of the assembly are formed from
%   quantities of order n there); the cdf therefore carries an error of
%   about 1e-16 n near the unit root, i.e. 1e-10 at n = 10^6, which the
%   error estimate reports.  Tail probabilities below the absolute error
%   are not resolved; the relative accuracy of F is err/F.
%
%   Method.  P[phihat < x] = 1/2 - (1/pi) int_0^inf Im(phi(t1,-r t1))/t1 dt1,
%   r = x - phi (Gil-Pelaez 1951, Imhof 1961), with the joint characteristic
%   function of the numerator and denominator evaluated by AR1_LOGCF in O(1)
%   operations per quadrature point, independent of n (RATIO_CDF).
%
%   See also AR1_PDF, AR1_ICDF, AR1_MOM, AR1_LOGCF, AR1_LOGCF_EXPS, RATIO_CDF.
if nargin < 5, par0 = 0; end
if nargin < 6, tol = []; end
if nargin < 7 || isempty(centered), centered = false; end
[cas,par0] = ar1_args(n,phi,cas,par0,x);
scaled = (ischar(centered) || isstring(centered)) && strcmpi(centered,'scaled');
if scaled
    c = ar1_scaled_check(phi,cas);
    if 2*n*log10(abs(phi)) > 2             % the explosive forms (AR1_LOGCF), in scaled arguments
        h = @(a,b) ar1_logcf_exps(a,b,n,phi,cas,par0);
        [F,err] = ratio_cdf(h,c*x,tol);
    else                                   % phihat - phi is representable
        [F,err] = ar1_cdf(c*x/abs(phi)^n,n,phi,cas,par0,tol,true);
    end
    return
end
h = @(t1,t2) ar1_logcf(t1,t2,n,phi,cas,par0);
[F,err] = ratio_cdf(h,x-phi*(~centered),tol);
end
