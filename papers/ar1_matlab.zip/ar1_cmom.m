function [mu,v,sk,ku,cm] = ar1_cmom(n,phi,cas,par0,tol)
%AR1_CMOM  Mean, variance, skewness and excess kurtosis of the AR(1) least squares estimator.
%
%   [mu,v,sk,ku] = AR1_CMOM(n,phi,cas,par0) returns the mean mu = E[phihat],
%   the variance v, the skewness sk and the excess kurtosis ku (the
%   kurtosis minus 3) of phihat, for the model and case described in
%   AR1_CDF.  The fifth output cm holds the central moments of orders 1
%   to 4.  The central moments are computed directly about the mean (by
%   RATIO_MOM, about E[phihat - phi] on the scale of phihat - phi), so that
%   no cancellation between large raw moments occurs (important at and near
%   the unit root, where phihat - 1 is O(1/n)), and the center is not
%   rounded to phi in the explosive region, where E[phihat] - phi is of
%   order |phi|^(-n).
%   Moments of order k exist if and only if k < n-1 in cases 'DU' and 'SU'
%   and in case 'DK' with z0 = 0, k < n in case 'SK', k < n-2 in cases 'DT'
%   and 'ST', and for every k in case 'DK' with z0 ~= 0 (Proposition 1 of
%   the paper and Proposition S7.2 of the Online Supplement); the statistics
%   that need a moment that does not exist (the kurtosis when n = 5 in
%   cases 'DU', 'SU' and 'DK' with z0 = 0, for example) are returned as
%   NaN, as are the corresponding entries of cm.  So are, in the explosive
%   region, the statistics when phi^(2n) exceeds about 1e300, beyond the
%   range of double precision (see AR1_MOM).  tol (optional) is
%   passed to AR1_MOM.
%
%   See also AR1_MOM.

if nargin < 4, par0 = 0; end
if nargin < 5, tol = []; end
[cas,par0] = ar1_args(n,phi,cas,par0);
switch cas
    case 'DK', if par0 == 0, kmax = n-2; else, kmax = Inf; end
    case 'SK', kmax = n-1;
    case {'DT','ST'}, kmax = n-3;
    otherwise, kmax = n-2;
end
k = min(4,kmax);
% the mean as phi + d, d = E[phihat - phi]; the central moments are taken
% about d on the scale of phihat - phi (RATIO_MOM), not about mu = phi + d:
% in the explosive region d is of order |phi|^(-n), below the spacing of
% floating-point numbers near phi, and mu rounds to phi
d = ar1_mom(1,n,phi,cas,par0,phi,tol);
mu = phi+d;
cm = NaN(1,4);
if ~isfinite(d)                        % beyond the range (AR1_MOM warns)
    cm(:) = NaN;
elseif k >= 2
    h = @(t1,t2) ar1_logcf(t1,t2,n,phi,cas,par0);
    cm(1:k) = ratio_mom(h,k,d,tol);
else
    cm(1) = 0;
end
v  = cm(2);
sk = cm(3)/v^1.5;
ku = cm(4)/v^2 - 3;   % excess kurtosis
end
