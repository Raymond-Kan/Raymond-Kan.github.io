%AR1_DEMO  Worked examples for the AR(1) exact distribution programs.
%
%   The four cases are selected by a two-letter code: 'DK' (fixed start, no
%   intercept), 'DU' (fixed start, intercept estimated), 'SK' (stationary
%   start, no intercept), 'SU' (stationary start, intercept estimated).

% 1. Unit root, intercept estimated, n = 100: the exact cdf, density and
%    quantiles of phihat, and the 5% critical value of n(phihat-1).
n = 100; phi = 1; gam = 0;
x = [0.90 0.95 0.98 1.00 1.02];
F = ar1_cdf(x,n,phi,'DU',gam);
f = ar1_pdf(x,n,phi,'DU',gam);
disp(table(x',F',f','VariableNames',{'x','cdf','pdf'}))
q05 = ar1_icdf(0.05,n,phi,'DU',gam);
fprintf('exact 5%% critical value of n(phihat-1), n = %d: %.4f  (limit: %.4f)\n', ...
        n, n*(q05-1), ar1lim_icdf(0.05,0,'DU',0));

% 2. Moments: mean, standard deviation, skewness, excess kurtosis.
[mu,v,sk,ku] = ar1_cmom(n,phi,'DU',gam);
fprintf('n = %d, phi = 1: E[phihat] = %.6f, sd = %.6f, skew = %.4f, excess kurt = %.4f\n', n,mu,sqrt(v),sk,ku);

% 3. A stationary process with unknown mean, n = 50, phi = 0.9: bias of phihat.
m = ar1_mom(2,50,0.9,'SU');
fprintf('n = 50, phi = 0.9 (stationary, intercept): bias = %.6f, sd = %.6f\n', m(1)-0.9, sqrt(m(2)-m(1)^2));

% 4. A random walk with drift (gamma = alpha/sigma = 1) and a fixed start:
%    the drift pulls phihat toward 1 at rate n^{-3/2}.
for nn = [50 200 800]
    [mu,v] = ar1_cmom(nn,1,'DU',1);
    fprintf('n = %4d, phi = 1, gamma = 1: 1-E[phihat] = %.3e, sd = %.3e\n', nn, 1-mu, sqrt(v));
end

% 5. The explosive case phi = 1.1 with a fixed start y_0 = 0, no intercept:
%    exact quantiles of |phi|^n(phihat-phi)/(phi^2-1) against the Cauchy limit.
phi = 1.1; n = 50; g = phi^n/(phi^2-1);
p = [0.05 0.25 0.5 0.75 0.95];
q = g*(ar1_icdf(p,n,phi,'DK',0)-phi);
disp(table(p',q',tan(pi*(p'-0.5)),'VariableNames',{'p','exact_n50','Cauchy_limit'}))

% 6. The cost does not grow with n.
for nn = [100 10000 1000000]
    tic; F = ar1_cdf(1-8/nn,nn,1,'DU',0); t = toc;
    fprintf('n = %7d: P[n(phihat-1) < -8] = %.8f  (%.3f s)\n', nn, F, t);
end
