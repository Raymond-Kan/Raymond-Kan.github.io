function x = ar1_icdf(pr,n,phi,cas,par0,tol,centered)
%AR1_ICDF  Exact quantiles of the least squares estimator of the AR(1) coefficient.
%
%   x = AR1_ICDF(pr,n,phi,cas,par0) returns the quantiles x with
%   P[phihat < x] = pr for the probabilities in pr; inputs as in AR1_CDF.
%   With centered = true (7th argument) the quantiles of phihat - phi are
%   returned instead, and with centered = 'scaled' those of
%   X_n = |phi|^n (phihat - phi)/(phi^2 - 1), for any n (see AR1_CDF).
%
%   See also AR1_CDF, AR1_PDF, RATIO_ICDF.
if nargin < 5, par0 = 0; end
if nargin < 6, tol = []; end
if nargin < 7 || isempty(centered), centered = false; end
[cas,par0] = ar1_args(n,phi,cas,par0);
scaled = (ischar(centered) || isstring(centered)) && strcmpi(centered,'scaled');
if scaled
    c = ar1_scaled_check(phi,cas);
    if 2*n*log10(abs(phi)) > 2
        h = @(a,b) ar1_logcf_exps(a,b,n,phi,cas,par0);
        x = ratio_icdf(h,pr,tol)/c;
    else
        x = ar1_icdf(pr,n,phi,cas,par0,tol,true)*abs(phi)^n/c;
    end
    return
end
h = @(t1,t2) ar1_logcf(t1,t2,n,phi,cas,par0);
x = ratio_icdf(h,pr,tol);
if ~centered, x = phi+x; end
end
