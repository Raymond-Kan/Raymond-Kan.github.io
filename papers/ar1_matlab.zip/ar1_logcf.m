function [L,info] = ar1_logcf(sj,tj,n,phi,cas,par0,opts)
%AR1_LOGCF  Log of the joint characteristic function of the numerator and
%   denominator of the centered least squares estimator in an AR(1) model,
%   evaluated in O(1) operations per point, in Taylor-mode (jet) arithmetic.
%
%   L = AR1_LOGCF(t1,t2,n,phi,cas,par0) returns log phi(t1,t2), where
%
%       phi(t1,t2) = E[exp(i t1 u + i t2 v)],
%
%   and (u,v) are the numerator and denominator of
%
%       phihat - phi = u/v,     u = sum (y_{t-1}-ybar_)(y_t-alpha-phi y_{t-1}),
%                               v = sum (y_{t-1}-ybar_)^2,
%
%   in the model y_t = alpha + phi y_{t-1} + sigma e_t, t = 1..n, with
%   i.i.d. standard normal e_t, for one of six cases:
%
%     cas = 'DK'  y_0 fixed, alpha known (= 0): regression without intercept
%                 of y_t on y_{t-1}; par0 = z0 = y_0/sigma.  Any real phi.
%     cas = 'DU'  y_0 fixed, alpha unknown: regression with intercept;
%                 par0 = gamma = [alpha-(1-phi) y_0]/sigma.  Any real phi.
%     cas = 'SK'  y_0 drawn from the stationary distribution, alpha known
%                 (mean known, = 0): no intercept; |phi| < 1; par0 unused.
%     cas = 'SU'  stationary start, alpha unknown: with intercept; |phi| < 1.
%     cas = 'DT'  y_t = alpha + delta t + phi y_{t-1} + sigma e_t, y_0 fixed,
%                 regression of y_t on 1, t and y_{t-1}; par0 = [gamma gamma_tau],
%                 gamma = [alpha + delta (n+1)/2 - (1-phi) y_0]/sigma,
%                 gamma_tau = delta/sigma (a scalar par0 means gamma_tau = 0).
%                 Any real phi.
%     cas = 'ST'  y_t = mu + beta t + x_t, x_t = phi x_{t-1} + sigma e_t, x_0
%                 from the stationary distribution, the same regression;
%                 |phi| < 1; par0 unused (the estimator does not depend on
%                 mu and beta).
%   (D: deterministic, i.e. fixed, start; S: stationary start; K, U, T: known
%   mean, unknown intercept, intercept and trend.)  The trend cases are
%   described in Section S7 of the Online Supplement to the paper.
%   In terms of y, (u,v) are then the numerator and denominator of phihat - phi
%   in the regression on 1, t and y_{t-1}.
%
%   Jets.  t1 and t2 may be jets, i.e. (K+1) x N arrays whose (j+1)-th row
%   holds the Taylor coefficient z^{[j]} = z^{(j)}/j! of a truncated power
%   series in one scalar variable; plain 1 x N rows are jets of order 0.
%   The output is the jet of log phi in the same variable: with t1 = [a; 1]
%   and t2 = [b; 0] the second row of L is d log phi/dt1 at (a,b), and so
%   on, without finite-difference error, at any order.  Complex t1 and t2
%   are allowed, so the same routine evaluates the joint moment generating
%   function M(s1,s2) = phi(-i s1,-i s2) at real arguments.
%
%   The constant coefficient of L carries the CONTINUOUS phase of
%   phi, assembled factor by factor as described in Section 4.2 of the
%   paper (the phase of the tridiagonal core from TTPRIMSJ, and the
%   principal arguments of the rank-one and border factors, which the
%   accretivity of the matrix keeps off the branch cut).
%
%   Structure (Theorem 1 and Proposition 2 of the paper).
%   phi(t1,t2) = varrho |K|^{-1/2} exp(beta'K^{-1}beta/2 + eta), where K is
%   an (n+1)-dimensional complex symmetric matrix (a dummy first coordinate
%   being appended in the fixed-start cases) of the form
%
%       K = [c11  a'  c1n ;  a  Delta  b ;  c1n  b'  1],
%       Delta = D + kappa 1 1',  a = a1 1 + a2 e_1,  b = b1 1 + q e_m,
%
%   with D the m x m tridiagonal Toeplitz matrix with diagonal
%   p = 1+phi^2+2i(phi t1-t2) and off-diagonal q = -(phi+i t1), m = n-1,
%   the coefficients c11, c1n, a1, a2, b1, kappa of Table 1 of the paper,
%   and beta a vector in the span of the last coordinate and of 1, e_1 in
%   the core.  Everything is then an explicit expression in |D| and the
%   four primitives d1..d4 of D^{-1} (TTPRIMSJ).
%
%   opts.thr (optional) is the regime threshold passed to TTPRIMSJ.
%   opts.m1 (testing only) = true or false forces or disables the assembly
%   about the core of size m-1 (see the end of the main function).
%
%   Explosive region.  When |phi| > 1 and |phi|^{2n} > 100 (fixed-start
%   cases) the same closed forms are evaluated by AR1_LOGCF_EXP, which
%   rearranges them so that no O(1) quantity is obtained as a difference of
%   quantities of order phi^{2n}; the generic assembly below loses about
%   2n log10|phi| digits there.  Set opts.exp = false to force the generic
%   assembly.  The value of the characteristic function is accurate to a
%   few units of rounding as long as phi^{-2n} is representable
%   (|phi|^{2n} < 1e300 or so; verified against a 250-digit reference for
%   |phi| <= 1.5, n <= 600, i.e. phi^{2n} up to 2e211); its derivatives in
%   t2, which the cdf, pdf and moment routines need, involve Var(v) ~ phi^{4n}
%   and overflow earlier, at |phi|^{2n} > 1e150 or so.  AR1_LOGCF_EXPS
%   evaluates the same forms in the scaled arguments |phi|^n t1 and
%   phi^{2n} t2, with no limit in n (AR1_CDF with centered = 'scaled').
%
%   Accuracy near the unit root.  The O(1) quantities of the assembly (the
%   rank-one and border factors) are formed from quantities of order n or
%   n^2 when phi is within O(1/n) of 1, and the result carries a relative
%   rounding error of order n eps there (1e-10 at n = 1e6); elsewhere it is
%   a few units of rounding.
%
%   info.regime: regime indicator of TTPRIMSJ for every column (3 = the
%   explosive rearrangement).
%
%   See also TTPRIMSJ, AR1_LOGCF_EXP, AR1_CDF, AR1_PDF, AR1_MOM.

if nargin < 7, opts = struct; end
thr = [];
if isfield(opts,'thr'), thr = opts.thr; end
if nargin < 6, par0 = []; end
[cas,par0] = ar1_args(n,phi,cas,par0);
% In the explosive region the generic assembly |K| = |D| rho delta_4
% multiplies |D| ~ phi^{2n} by factors of order phi^{-2n}, each of which is
% a difference of O(1) quantities, and loses about 2n log10|phi| digits.
% AR1_LOGCF_EXP evaluates the same closed forms in a cancellation-free
% arrangement (the roots are well separated there, so no confluent
% expansion is needed).
useexp = true;
if isfield(opts,'exp'), useexp = opts.exp; end
if useexp && abs(phi) > 1 && 2*n*log(abs(phi)) > log(100)
    [L,info] = ar1_logcf_exp(sj,tj,n,phi,cas,par0);
    return
end
% cases with a linear trend (Online Supplement, Section S7)
if strcmp(cas,'DT') || strcmp(cas,'ST')
    [L,info] = trendcf(sj,tj,n,phi,cas,par0,thr,opts);
    return
end

% ---- broadcast the two jets to a common shape -------------------------
if size(sj,1) == 1 && size(tj,1) > 1, sj = [sj; zeros(size(tj,1)-1,size(sj,2))]; end
if size(tj,1) == 1 && size(sj,1) > 1, tj = [tj; zeros(size(sj,1)-1,size(tj,2))]; end
if size(sj,2) == 1 && size(tj,2) > 1, sj = repmat(sj,1,size(tj,2)); end
if size(tj,2) == 1 && size(sj,2) > 1, tj = repmat(tj,1,size(sj,2)); end
K = size(sj,1)-1;  N = size(sj,2);
m = n-1;
z = zeros(K+1,N);

% ---- the tridiagonal core -------------------------------------------
% p+2q is formed in closed form: (1-phi)^2 is exact in floating point and
% nothing cancels, whereas p+2q by subtraction loses eps*n^2 near phi = 1.
om  = 1-phi;
q   = jc(-1i*sj,-phi);                        % -(phi + i s)
p2q = jc(2i*(-om*sj-tj),om^2);                % (1-phi)^2 + 2i((phi-1)s - t)
pm2q = jc(2i*((1+phi)*sj-tj),(1+phi)^2);      % (1+phi)^2 + 2i((phi+1)s - t)
p   = p2q-2*q;                                % 1+phi^2+2i(phi s - t)

% ---- the border and rank-one data of the four cases -------------------
one = jc(z,1);
switch cas
    case 'DK'
        c11 = one;  a1 = z;  a2 = z;  c1n = z;
        kap = z;
        b1  = z;    b2 = q;  cnn = one;
        beta = {z, z, -par0*q, z, z};         % (beta0, beta_c, beta_1, beta_m, beta_n)
        cst  = -0.5*par0^2*jc(p,-1);
    case 'DU'
        c11 = one;  a1 = z;  a2 = z;  c1n = z;
        kap = 2i*(om*sj+tj)/n;
        b1  = 1i*sj/n;  b2 = q;  cnn = one;
        beta = {z, jc(z,par0*om), z, z, jc(z,par0)};
        cst  = jc(z,-0.5*n*par0^2);
    case 'SK'
        c11 = jc(2i*(phi*sj-tj),1);  a1 = z;  a2 = q;  c1n = z;
        kap = z;
        b1  = z;  b2 = q;  cnn = one;
        beta = [];
        cst  = jc(z,0.5*log1p(-phi^2));
    case 'SU'
        c11 = jc(2i*(phi*sj-tj)*(1-1/n),1);
        a1  = 1i*((1-2*phi)*sj+2*tj)/n;  a2 = q;
        c1n = 1i*sj/n;
        kap = 2i*(om*sj+tj)/n;
        b1  = 1i*sj/n;  b2 = q;  cnn = one;
        beta = [];
        cst  = jc(z,0.5*log1p(-phi^2));
end

% ---- primitives of the core -------------------------------------------
[d1,d2,d3,d4,lgi,info] = ttprimsj(p,q,p2q,m,thr,pm2q);

% ---- Sherman-Morrison for the rank-one term ---------------------------
rho = jc(jm(kap,d1),1);                       % |Delta|/|D|
cc  = jd(kap,rho);
w1  = jd(d1,rho);
w2  = jd(d2,rho);
d2sq = jm(d2,d2);
w3  = d3-jm(cc,d2sq);
w4  = d4-jm(cc,d2sq);

% ---- the 2 x 2 Schur complement of Delta in K -------------------------
aDa = bil(a1,a2,z,a1,a2,z,w1,w2,w3,w4);
aDb = bil(a1,a2,z,b1,z,b2,w1,w2,w3,w4);
bDb = bil(b1,z,b2,b1,z,b2,w1,w2,w3,w4);
e1 = c11-aDa;  e2 = c1n-aDb;  e3 = cnn-bDb;
e4 = jm(e1,e3)-jm(e2,e2);                     % border factor

% ---- log|K|^{-1/2} with continuous phase ------------------------------
% lgi has the continuous phase in its constant coefficient; rho and e4 are
% off the closed negative real axis (accretivity), so their principal
% arguments are the continuous ones.
lrho = jlog0(rho);  lrho(1,:) = log(abs(rho(1,:)))+1i*angle(rho(1,:));
le4  = jlog0(e4);   le4(1,:)  = log(abs(e4(1,:))) +1i*angle(e4(1,:));
L = 0.5*(lgi-lrho-le4)+cst;

% ---- the exponential factor beta'K^{-1}beta/2 -------------------------
if ~isempty(beta)
    [b0,bc,be1,bem,bn] = beta{:};
    ga = bil(a1,a2,z,bc,be1,bem,w1,w2,w3,w4);  % a'Delta^{-1}beta_v
    gb = bil(b1,z,b2,bc,be1,bem,w1,w2,w3,w4);  % b'Delta^{-1}beta_v
    gg = bil(bc,be1,bem,bc,be1,bem,w1,w2,w3,w4);
    num = jm(jm(b0,b0),e3)+jm(jm(bn,bn),e1)-2*jm(jm(b0,bn),e2) ...
        + 2*jm(b0,jm(e2,gb)-jm(e3,ga)) + 2*jm(bn,jm(e2,ga)-jm(e1,gb)) ...
        + jm(e3,jm(ga,ga))-2*jm(e2,jm(ga,gb))+jm(e1,jm(gb,gb));
    L = L + 0.5*(gg+jd(num,e4));
end

% ---- near a zero of U_m: the assembly about the core of size m-1 ------
% Where x = p/(2q) is near a zero of U_m, D is nearly singular relative to
% its scale (this happens at large t1 when phihat is near -cos(k pi/n), as
% x tends to -phihat), D^{-1} has a large component, and rho and delta_4
% are formed as differences of nearly equal quantities: the assembly above
% then loses about eps t1^2 in relative terms, against the eps t1 that the
% rank drop of u - r v there makes inherent (NaN, Inf or O(1) errors from
% t1 of order 1e8 on; November 2026).  There, |q d3| = |U_{m-1}/U_m| is
% large, and K is assembled about the core of size m-1 (ASM_M1), which is
% well conditioned since U_{m-1}^2 - U_m U_{m-2} = 1.
% Only at real (t1,t2), the arguments of the inversion integrals (the
% moment formulas evaluate the moment generating function at imaginary
% arguments, where these switches are not needed and are not made).
realb = imag(sj(1,:)) == 0 & imag(tj(1,:)) == 0;
ia = abs(q(1,:).*d3(1,:)) > 4 & realb;
if isfield(opts,'m1'), ia(:) = logical(opts.m1); end   % for testing: force (true) or disable (false)
if any(ia)
    if isempty(beta), bt = []; else, bt = cellfun(@(v) v(:,ia),beta,'UniformOutput',false); end
    L(:,ia) = asm_m1(p(:,ia),q(:,ia),p2q(:,ia),pm2q(:,ia),m,thr,c11(:,ia),a1(:,ia),a2(:,ia), ...
        c1n(:,ia),kap(:,ia),b1(:,ia),b2(:,ia),cnn(:,ia),bt,cst(:,ia));
end
end

% =========================================================================
function L = asm_m1(p,q,p2q,pm2q,m,thr,c11,a1,a2,c1n,kap,b1,b2,cnn,beta,cst)
%ASM_M1  log phi from K = K0 + kappa f f', f the indicator of the core
%   y_1..y_m, with the borders of K0 eliminated about the Toeplitz core
%   D_{m-1} (y_1..y_{m-1}) and the rank one last:
%       |K| = |D_{m-1}| |E| (1 + kappa f'K0^{-1} f),
%   E the 3 x 3 Schur complement of D_{m-1} in K0 for the border (y_0, y_m,
%   y_n).  The order matters: when U_m is small, Delta = D + kappa 1 1' is
%   nearly singular as well, and the elimination of the rank one first (as
%   in the main assembly) would cancel again.  Couplings to the core, as
%   coefficients of (1, e_1, e_{m-1}): y_0: a1 1 + a2 e_1; y_m: q e_{m-1};
%   y_n: b1 1 (its q now couples to y_m).  Branch: K0 is accretive (K minus
%   kappa f f', kappa imaginary), E is reduced by LDL' without pivoting, each
%   pivot a 1 x 1 Schur complement of an accretive matrix, and 1 + lambda
%   kappa f'K0^{-1}f does not vanish for lambda in [0,1] (K0 + lambda kappa
%   f f' is accretive): all principal arguments, as in the main assembly.
z = zeros(size(p));  one = jc(z,1);
[d1,d2,d3,d4,lgi] = ttprimsj(p,q,p2q,m-1,thr,pm2q);
W = @(u,v) bil(u{:},v{:},d1,d2,d3,d4);
U = {{a1,a2,z},{z,z,q},{b1,z,z}};
bm = b1+b2;
B = {c11, a1, c1n; a1, p, bm; c1n, bm, cnn};
E = cell(3,3);
for i = 1:3
    for j = i:3
        E{i,j} = B{i,j}-W(U{i},U{j});  E{j,i} = E{i,j};
    end
end
% LDL' of E (unit lower triangular l, pivots d)
d = cell(1,3);  l = cell(3,3);
d{1} = E{1,1};  l{2,1} = jd(E{2,1},d{1});  l{3,1} = jd(E{3,1},d{1});
d{2} = E{2,2}-jm(l{2,1},E{1,2});
A23  = E{2,3}-jm(l{2,1},E{1,3});
l{3,2} = jd(A23,d{2});
d{3} = E{3,3}-jm(l{3,1},E{1,3})-jm(l{3,2},A23);
% x'E^{-1}y by forward substitution
fs = @(x) {x{1}, x{2}-jm(l{2,1},x{1}), x{3}-jm(l{3,1},x{1})-jm(l{3,2},x{2}-jm(l{2,1},x{1}))};
qfE = @(x,y) jd(jm(x{1},y{1}),d{1})+jd(jm(x{2},y{2}),d{2})+jd(jm(x{3},y{3}),d{3});
fcore = {one,z,z};
gr = cell(1,3);  fB = {z,one,z};
for i = 1:3, gr{i} = fB{i}-W(U{i},fcore); end
gs = fs(gr);
ff  = W(fcore,fcore)+qfE(gs,gs);              % f'K0^{-1}f
rhoK = jc(jm(kap,ff),1);
lsum = jlog0(d{1})+jlog0(d{2})+jlog0(d{3})+jlog0(rhoK);
lsum(1,:) = log(abs(d{1}(1,:)))+1i*angle(d{1}(1,:)) + log(abs(d{2}(1,:)))+1i*angle(d{2}(1,:)) ...
          + log(abs(d{3}(1,:)))+1i*angle(d{3}(1,:)) + log(abs(rhoK(1,:)))+1i*angle(rhoK(1,:));
L = 0.5*(lgi-lsum)+cst;
if ~isempty(beta)
    % beta'K^{-1}beta = beta'K0^{-1}beta - kappa (beta'K0^{-1}f)^2/(1 + kappa f'K0^{-1}f);
    % beta = (b0, bc 1 + be1 e_1 + bem e_m, bn) on (y_0, old core, y_n): on the
    % new core bc 1 + be1 e_1, and y_m carries bc + bem
    [b0,bc,be1,bem,bn] = beta{:};
    bcore = {bc,be1,z};  bB = {b0,bc+bem,bn};
    rr = cell(1,3);
    for i = 1:3, rr{i} = bB{i}-W(U{i},bcore); end
    rs = fs(rr);
    bt = W(bcore,bcore)+qfE(rs,rs);
    bf = W(bcore,fcore)+qfE(rs,gs);
    L = L + 0.5*(bt-jd(jm(kap,jm(bf,bf)),rhoK));
end
end

% =========================================================================
function r = bil(u1,u2,u3,v1,v2,v3,w1,w2,w3,w4)
%BIL  u'Delta^{-1}v for u = u1*1+u2*e_1+u3*e_m and v likewise, given the
%   four primitives of Delta^{-1} (persymmetry supplies the rest).
r = jm(jm(u1,v1),w1) + jm(jm(u1,v2)+jm(u2,v1)+jm(u1,v3)+jm(u3,v1),w2) ...
  + jm(jm(u2,v2)+jm(u3,v3),w3) + jm(jm(u2,v3)+jm(u3,v2),w4);
end

% =========================================================================
function [L,info] = trendcf(sj,tj,n,phi,cas,par0,thr,opts)
%TRENDCF  Cases 'DT' and 'ST' (intercept and linear trend in the regression).
%   With w_t = (y_t - y_0)/sigma the fixed-start model is
%   w_t = gamma + gamma_tau c_t + phi w_{t-1} + e_t, w_0 = 0, c_t = t-(n+1)/2,
%   and the projection off X = [1, c] (X'X = diag(n, n(n^2-1)/12)) adds to the
%   matrix of case 'DK' the rank-two term Z C Z' in the core, Z = [1_m, l],
%   l = (1,...,m)' - n/2, the term Z bv to the border, and nothing to the
%   corner:  K = [D + Z C Z', q e_m + Z bv; (q e_m + Z bv)', 1].  With
%   W = Z'D^{-1}Z = diag(d1, l'D^{-1}l) (1'D^{-1}l = 0 by persymmetry) and
%   M = I + C W, the Woodbury identity gives |K| = |D| |M| S,
%   S = 1 - b'Delta^{-1}b, and every bilinear form of Delta^{-1} from d1..d4,
%   ec = e_m'D^{-1}l and wcc = l'D^{-1}l (TTPRIMSJ).  The mean of w enters
%   through beta = F'mu, F = I - phi J: core part Z bc, last entry bn.
%   Branch: |D| from TTPRIMSJ; |M| = (1+k1)(1+k2), k1, k2 the eigenvalues of
%   C W, each factor off the closed negative real axis (D + lambda Z C Z' is
%   accretive for lambda in [0,1]); S is the Schur complement of an accretive
%   matrix.  Case 'ST' is case 'DT' with gamma_tau = 0 and gamma =
%   -(1-phi) x_0/sigma ~ N(0, (1-phi)/(1+phi)): log psi_DT = L0 + Cg gamma^2,
%   and E psi = exp(L0) (1 - 2 s2 Cg)^(-1/2), s2 = (1-phi)/(1+phi), with
%   Re(1 - 2 s2 Cg) >= 1 at real arguments.
if size(sj,1) == 1 && size(tj,1) > 1, sj = [sj; zeros(size(tj,1)-1,size(sj,2))]; end
if size(tj,1) == 1 && size(sj,1) > 1, tj = [tj; zeros(size(sj,1)-1,size(tj,2))]; end
if size(sj,2) == 1 && size(tj,2) > 1, sj = repmat(sj,1,size(tj,2)); end
if size(tj,2) == 1 && size(sj,2) > 1, tj = repmat(tj,1,size(sj,2)); end
K = size(sj,1)-1;  N = size(sj,2);
m = n-1;  om = 1-phi;  z = zeros(K+1,N);
q    = jc(-1i*sj,-phi);
p2q  = jc(2i*(-om*sj-tj),om^2);
pm2q = jc(2i*((1+phi)*sj-tj),(1+phi)^2);
p    = p2q-2*q;
[d1,d2,d3,d4,lgi,info,ec,wcc] = ttprimsj(p,q,p2q,m,thr,pm2q);
[Pr,detM,S] = trendasm(sj,tj,n,phi,q,d1,d2,d3,ec,wcc,[]);
% log|K|^{-1/2}: continuous phase of |M| from its two eigenvalue factors
lM = jlog0(detM);
lM(1,:) = log(abs(detM(1,:))) + 1i*argM(Pr);
lS = jlog0(S);  lS(1,:) = log(abs(S(1,:))) + 1i*angle(S(1,:));
L = 0.5*(lgi-lM-lS);
if strcmp(cas,'ST')
    s2 = (1-phi)/(1+phi);
    Cg = trendexp(Pr,S,n,phi,1,0,z);            % the exponent at gamma = 1
    mix = jc(-2*s2*Cg,1);
    lmix = jlog0(mix);  lmix(1,:) = log(abs(mix(1,:))) + 1i*angle(mix(1,:));
    L = L - 0.5*lmix;
else
    gam = par0(1);  gtau = 0;
    if numel(par0) > 1, gtau = par0(2); end
    % The estimator depends on (gamma, gamma_tau) only through
    % xi = (1-phi) gamma - [(1-phi)(n+1)/2 + phi] gamma_tau (the effective
    % start, Online Supplement, Proposition S7.1).  The mean terms of the
    % assembly cancel to O(1) from terms of order n gamma^2 +
    % n^3 gamma_tau^2/12, so the pair with this xi that minimizes that sum is
    % used (Section S7.4.4).
    u = 1-phi;  v = -(u*(n+1)/2 + phi);
    xi = u*gam + v*gtau;
    lam = xi/(u^2/n + 12*v^2/n^3);
    gam = lam*u/n;  gtau = 12*lam*v/n^3;
    if gam ~= 0 || gtau ~= 0
        L = L + trendexp(Pr,S,n,phi,gam,gtau,z);
    end
end
% ---- near a zero of U_m, or where M is nearly singular ----------------
% As in the cases without a trend, the assembly above loses about eps t1^2
% in relative terms where D is nearly singular relative to its scale (x
% near a zero of U_m, |q d3| large) or where Delta = D + Z C Z' is (one of
% 1 + k1, 1 + k2 small): then |K| = |D| |M| S multiplies a small factor by
% a large one, and S, which needs Delta^{-1}, cancels (O(1) errors from t1
% of order 1e8 on, and up to 1e-2 already below; November 2026).  There
% K is assembled about the core of size m-1 (TREND_M1) where U_m is small,
% and where only Delta is nearly singular, the border y_n is eliminated
% first and the rank-two term last (TREND_ALT).
c11 = Pr.C11(1,:);  c12 = Pr.C12(1,:);  c22 = Pr.C22(1,:);
tr = c11.*d1(1,:) + c22.*wcc(1,:);  dt = (c11.*c22 - c12.^2).*d1(1,:).*wcc(1,:);
sq = sqrt(tr.^2 - 4*dt);
small = min(abs(1+(tr+sq)/2),abs(1+(tr-sq)/2)) < 0.05;
nearz = abs(q(1,:).*d3(1,:)) > 4;
realb = imag(sj(1,:)) == 0 & imag(tj(1,:)) == 0;       % real (t1,t2) only, as in the main function
ia = (nearz | small) & realb;
force = isfield(opts,'m1');
if force, ia(:) = logical(opts.m1); end
if any(ia)
    % the core of size m-1 (rank-two term first) where it is well conditioned
    % (D_{m-1} and M' = I + C W'); otherwise, with D well conditioned, the
    % border first about D (TREND_ALT); D and D_{m-1} are never both nearly
    % singular (U_{m-1}^2 - U_m U_{m-2} = 1)
    sl = @(v) v(:,ia);  zc = sl(z);
    G = {sl(Pr.C11), sl(Pr.C12), sl(Pr.bv1); sl(Pr.C12), sl(Pr.C22), sl(Pr.bv2); sl(Pr.bv1), sl(Pr.bv2), zc};
    if strcmp(cas,'ST')
        cb = {jc(zc,om), zc, jc(zc,1)};                 % beta at gamma = 1, gamma_tau = 0
    else
        k0 = -(1+phi)/2;
        cb = {jc(zc,gam*om + gtau*k0), jc(zc,gtau*om), jc(zc,gam + gtau*m/2)};
    end
    [lK,Qb,ok] = trend_m1(p(:,ia),q(:,ia),p2q(:,ia),pm2q(:,ia),m,thr,G,cb);
    ua = ~ok & ~nearz(ia) & ~force;
    if any(ua)
        su = @(v) v(:,ua);
        [lK(:,ua),Qb(:,ua)] = trend_alt(su(p(:,ia)),su(q(:,ia)),su(p2q(:,ia)),su(pm2q(:,ia)),m,thr, ...
            cellfun(su,G,'UniformOutput',false),cellfun(su,cb,'UniformOutput',false));
    end
    if strcmp(cas,'ST')
        Cg = 0.5*Qb;  Cg(1,:) = Cg(1,:) - 0.5*n;
        mix = jc(-2*s2*Cg,1);
        lmix = jlog0(mix);  lmix(1,:) = log(abs(mix(1,:))) + 1i*angle(mix(1,:));
        L(:,ia) = -0.5*lK - 0.5*lmix;
    else
        Lc = -0.5*lK;
        if gam ~= 0 || gtau ~= 0
            E = 0.5*Qb;  E(1,:) = E(1,:) - 0.5*(n*gam^2 + gtau^2*n*(n^2-1)/12);
            Lc = Lc + E;
        end
        L(:,ia) = Lc;
    end
end
end

function [lK,Qb,ok] = trend_m1(p,q,p2q,pm2q,m,thr,G,cb)
%TREND_M1  log|K| and beta'K^{-1}beta in the trend cases about the core of
%   size m-1, D' (y_1..y_{m-1}), where U_m is small: the rank-two term first,
%   Delta' = D' + Z' C Z'' (Woodbury, M' = I + C W', W' = Z''D'^{-1}Z'), then
%   the border (y_m, y_n), whose 2 x 2 Schur complement is reduced by LDL'
%   with y_n first.  On the smaller core Z_1 = 1 and Z_2 = l' - 1/2, l' its
%   centered index vector, and y_m has z_m = (1, (m-1)/2).  Vectors on the
%   core are triples of coefficients of (1, l', e_{m-1}).  The border-first
%   order of TREND_ALT does not serve here: e_n'K00^{-1}e_n involves |D_m|,
%   which is small, and |I + G H|, of order 1/t1, magnifies its rounding.
%   Branch: |D'| from TTPRIMSJ, |M'| from the principal arguments of its two
%   eigenvalue factors (as ARGM), the pivots principal (accretive).  ok marks
%   the columns where this partition is well conditioned: |q d3'| <= 4 and
%   both eigenvalue factors of M' at least 0.05 in modulus.
z = zeros(size(p));  one = jc(z,1);
[d1,d2,d3,~,lgi,~,ec,wcc] = ttprimsj(p,q,p2q,m-1,thr,pm2q);
bilD = @(u,v) jm(jm(u{1},v{1}),d1) + jm(jm(u{2},v{2}),wcc) + jm(jm(u{1},v{3})+jm(u{3},v{1}),d2) ...
            + jm(jm(u{2},v{3})+jm(u{3},v{2}),ec) + jm(jm(u{3},v{3}),d3);
C11 = G{1,1};  C12 = G{1,2};  C22 = G{2,2};  bv1 = G{1,3};  bv2 = G{2,3};
Zc = {{one,z,z}, {jc(z,-0.5),one,z}};             % Z_1, Z_2 on the core
W11 = d1;  W12 = -0.5*d1;  W22 = wcc + 0.25*d1;    % W' = Z''D'^{-1}Z'
M11 = jc(jm(C11,W11)+jm(C12,W12),1);  M12 = jm(C11,W12)+jm(C12,W22);
M21 = jm(C12,W11)+jm(C22,W12);        M22 = jc(jm(C12,W12)+jm(C22,W22),1);
detM = jm(M11,M22)-jm(M12,M21);
% Q = M'^{-1} C
Q11 = jd(jm(M22,C11)-jm(M12,C12),detM);  Q12 = jd(jm(M22,C12)-jm(M12,C22),detM);
Q21 = jd(jm(M11,C12)-jm(M21,C11),detM);  Q22 = jd(jm(M11,C22)-jm(M21,C12),detM);
% u'Delta'^{-1}v = u'D'^{-1}v - (u'D'^{-1}Z') Q (Z''D'^{-1}v)
bilA = @(u,v) bilA_(u,v,bilD,Zc,Q11,Q12,Q21,Q22);
lm = (m-1)/2;
Cz1 = C11 + lm*C12;  Cz2 = C12 + lm*C22;            % C z_m
cm = {Cz1-0.5*Cz2, Cz2, q};                         % core coupling of y_m: Z'C z_m + q e_{m-1}
cn = {bv1-0.5*bv2, bv2, z};                         % core coupling of y_n: Z' bv
Kmm = p + Cz1 + lm*Cz2;                              % p + z_m'C z_m
Kmn = q + bv1 + lm*bv2;                              % q + z_m'bv
Enn = jc(-bilA(cn,cn),1);
Emn = Kmn - bilA(cm,cn);
Emm = Kmm - bilA(cm,cm);
pn = Enn;  lmn = jd(Emn,pn);  pm = Emm - jm(lmn,Emn);   % LDL' with y_n first
% branch of |M'|: eigenvalues of C W' (constant coefficients)
c11 = C11(1,:); c12 = C12(1,:); c22 = C22(1,:); w11 = W11(1,:); w12 = W12(1,:); w22 = W22(1,:);
a11 = c11.*w11+c12.*w12;  a12 = c11.*w12+c12.*w22;  a21 = c12.*w11+c22.*w12;  a22 = c12.*w12+c22.*w22;
tr = a11+a22;  dt = a11.*a22-a12.*a21;  sq = sqrt(tr.^2-4*dt);
argMp = angle(1+(tr+sq)/2) + angle(1+(tr-sq)/2);
ok = abs(q(1,:).*d3(1,:)) <= 4 & min(abs(1+(tr+sq)/2),abs(1+(tr-sq)/2)) >= 0.05;
lM = jlog0(detM);  lM(1,:) = log(abs(detM(1,:))) + 1i*argMp;
lpn = jlog0(pn);  lpn(1,:) = log(abs(pn(1,:))) + 1i*angle(pn(1,:));
lpm = jlog0(pm);  lpm(1,:) = log(abs(pm(1,:))) + 1i*angle(pm(1,:));
lK = -lgi + lM + lpn + lpm;
% beta = Y cb: core Z' cb(1:2), y_m z_m'cb(1:2), y_n cb(3)
bc = {cb{1}-0.5*cb{2}, cb{2}, z};
bm = cb{1} + lm*cb{2};  bn = cb{3};
rn = bn - bilA(cn,bc);  rm = bm - bilA(cm,bc);
y2 = rm - jm(lmn,rn);
Qb = bilA(bc,bc) + jd(jm(rn,rn),pn) + jd(jm(y2,y2),pm);
end

function v = bilA_(u,w,bilD,Zc,Q11,Q12,Q21,Q22)
xu1 = bilD(u,Zc{1});  xu2 = bilD(u,Zc{2});
yw1 = bilD(Zc{1},w);  yw2 = bilD(Zc{2},w);
v = bilD(u,w) - (jm(xu1,jm(Q11,yw1)+jm(Q12,yw2)) + jm(xu2,jm(Q21,yw1)+jm(Q22,yw2)));
end

function [lK,Qb] = trend_alt(p,q,p2q,pm2q,m,thr,G,cb)
%TREND_ALT  log|K| and beta'K^{-1}beta in the trend cases from
%   K = K00 + Y G Y',  K00 = [D, q e_m; q e_m', 1],  Y = [Z_1, Z_2, e_n],
%   G = [C, bv; bv', 0], beta = Y cb:  |K| = |K00| |I + G H| and
%   beta'K^{-1}beta = cb'H cb - (H cb)'(I + G H)^{-1} G H cb, H = Y'K00^{-1}Y,
%   K00^{-1} from the core D and its border y_n.  Used where Delta = D + Z C Z'
%   is nearly singular and D is not, and TREND_M1 is not well conditioned
%   either.  (Near a rank drop of u - r v, G H has a nearly double eigenvalue
%   at -1, and the branch from the eigenvalues can then be wrong; TREND_M1 is
%   preferred for that reason.)  Branch: |K00| from TTPRIMSJ and the
%   accretive pivot 1 - q^2 d3; G is imaginary and K00 + lambda Y G Y'
%   accretive for lambda in [0,1], so the continuous argument of |I + G H| is
%   the sum of the principal arguments of 1 + kappa_i, kappa_i the eigenvalues
%   of G H (as for |M| in the main assembly); it fixes the multiple of 2 pi of
%   the principal argument of the determinant, which is computed directly.
z = zeros(size(p));  one = jc(z,1);
[d1,d2,d3,~,lgi,~,ec,wcc] = ttprimsj(p,q,p2q,m,thr,pm2q);
s00 = jc(-jm(jm(q,q),d3),1);
qs = jd(q,s00);
H = cell(3,3);
H{1,1} = d1 + jm(jm(q,qs),jm(d2,d2));
H{2,2} = wcc + jm(jm(q,qs),jm(ec,ec));
H{1,2} = jm(jm(q,qs),jm(d2,ec));
H{1,3} = -jm(qs,d2);  H{2,3} = -jm(qs,ec);  H{3,3} = jd(one,s00);
l00 = jlog0(s00);  l00(1,:) = log(abs(s00(1,:))) + 1i*angle(s00(1,:));
lK00 = -lgi + l00;
for i = 2:3, for j = 1:i-1, H{i,j} = H{j,i}; end, end
% A = I + G H
A = cell(3,3);
for i = 1:3
    for j = 1:3
        a = jm(G{i,1},H{1,j}) + jm(G{i,2},H{2,j}) + jm(G{i,3},H{3,j});
        if i == j, a = jc(a,1); end
        A{i,j} = a;
    end
end
co = @(i1,j1,i2,j2) jm(A{i1,j1},A{i2,j2}) - jm(A{i1,j2},A{i2,j1});
Cf = {co(2,2,3,3), -co(2,1,3,3), co(2,1,3,2); -co(1,2,3,3), co(1,1,3,3), -co(1,1,3,2); co(1,2,2,3), -co(1,1,2,3), co(1,1,2,2)};
detA = jm(A{1,1},Cf{1,1}) + jm(A{1,2},Cf{1,2}) + jm(A{1,3},Cf{1,3});
% the continuous argument of |I + G H| (constant coefficients)
N = size(p,2);  ac = zeros(1,N);
for k = 1:N
    G0 = cellfun(@(v) v(1,k),G);  H0 = cellfun(@(v) v(1,k),H);
    ac(k) = sum(angle(1+eig(G0*H0)));
end
ap = angle(detA(1,:));
lA = jlog0(detA);  lA(1,:) = log(abs(detA(1,:))) + 1i*(ap + 2*pi*round((ac-ap)/(2*pi)));
lK = lK00 + lA;
% beta'K^{-1}beta
hc = cell(1,3);  gh = cell(1,3);
for i = 1:3, hc{i} = jm(H{i,1},cb{1}) + jm(H{i,2},cb{2}) + jm(H{i,3},cb{3}); end
for i = 1:3, gh{i} = jm(G{i,1},hc{1}) + jm(G{i,2},hc{2}) + jm(G{i,3},hc{3}); end
% y = A^{-1} (G H cb) = adj(A) gh / det A, adj(A)(i,j) = Cf{j,i}
Qb = jm(cb{1},hc{1}) + jm(cb{2},hc{2}) + jm(cb{3},hc{3});
for i = 1:3
    yi = jd(jm(Cf{1,i},gh{1}) + jm(Cf{2,i},gh{2}) + jm(Cf{3,i},gh{3}),detA);
    Qb = Qb - jm(hc{i},yi);
end
end

function [Pr,detM,S] = trendasm(sj,tj,n,phi,q,d1,d2,d3,ec,wcc,Sgiven)
%TRENDASM  The rank-two Woodbury assembly of the trend cases (generic form).
m = n-1;  om = 1-phi;  k0 = -(1+phi)/2;
G1 = 1/n;  G2 = 12/(n*(n^2-1));
% C = sum_i G_i [ i t1 (j_i k_i' + k_i j_i') + 2 i t2 j_i j_i' ],
% j_1 = (1,0), k_1 = (om,0), j_2 = (1/2,1), k_2 = (k0,om) in the basis (1, l)
C11 = G1*(2i*om*sj + 2i*tj) + G2*(1i*k0*sj + 0.5i*tj);
C12 = G2*(-1i*phi*sj + 1i*tj);                % (om/2 + k0) = -phi
C22 = G2*(2i*om*sj + 2i*tj);
% border: q e_m + Z bv, bv = sum_i G_i i t1 j_i beta_i, beta = (1, m/2)
bv1 = G1*1i*sj + G2*(m/2)*0.5i*sj;
bv2 = G2*(m/2)*1i*sj;
M11 = jc(jm(C11,d1),1);  M12 = jm(C12,wcc);  M21 = jm(C12,d1);  M22 = jc(jm(C22,wcc),1);
detM = jm(M11,M22)-jm(M12,M21);
Q11 = jd(jm(M22,C11)-jm(M12,C12),detM);  Q12 = jd(jm(M22,C12)-jm(M12,C22),detM);
Q21 = jd(jm(M11,C12)-jm(M21,C11),detM);  Q22 = jd(jm(M11,C22)-jm(M21,C12),detM);
Pr = struct('d1',d1,'d2',d2,'d3',d3,'ec',ec,'wcc',wcc,'Q11',Q11,'Q12',Q12,'Q21',Q21,'Q22',Q22, ...
    'C11',C11,'C12',C12,'C22',C22,'bv1',bv1,'bv2',bv2,'q',q,'m',m,'k0',k0,'om',om);
if isempty(Sgiven)
    z = zeros(size(sj));
    S = jc(-tbil(Pr,bv1,bv2,q,bv1,bv2,q),1);
else
    S = Sgiven;
end
end

function E = trendexp(Pr,S,n,phi,gam,gtau,z)
%TRENDEXP  beta'K^{-1}beta/2 + eta for the mean (gamma, gamma_tau) (generic form).
om = 1-phi;  k0 = -(1+phi)/2;  m = n-1;
bc1 = jc(z,gam*om + gtau*k0);  bc2 = jc(z,gtau*om);  bn = jc(z,gam + gtau*m/2);
bDc = tbil(Pr,bc1,bc2,z,bc1,bc2,z);
gb  = tbil(Pr,Pr.bv1,Pr.bv2,Pr.q,bc1,bc2,z);
E = 0.5*(bDc + jd(jm(bn-gb,bn-gb),S));
E(1,:) = E(1,:) - 0.5*(n*gam^2 + gtau^2*n*(n^2-1)/12);
end

function a = argM(Pr)
%ARGM  Continuous argument of |M| = |I + C W| as Arg(1+k1) + Arg(1+k2).
c11 = Pr.C11(1,:); c12 = Pr.C12(1,:); c22 = Pr.C22(1,:);
w1 = Pr.d1(1,:);  w2 = Pr.wcc(1,:);
tr = c11.*w1 + c22.*w2;
dt = (c11.*c22 - c12.^2).*w1.*w2;
sq = sqrt(tr.^2 - 4*dt);
k1 = (tr + sq)/2;  k2 = (tr - sq)/2;
a = angle(1+k1) + angle(1+k2);
end

function v = tbil(P,a1,a2,ae,b1,b2,be)
%TBIL  x'Delta^{-1}y for x = Z(a1,a2)' + ae e_m and y = Z(b1,b2)' + be e_m (Woodbury).
xDy = jm(jm(a1,b1),P.d1) + jm(jm(a2,b2),P.wcc) + jm(jm(a1,be)+jm(ae,b1),P.d2) ...
    + jm(jm(a2,be)+jm(ae,b2),P.ec) + jm(jm(ae,be),P.d3);
xu1 = jm(a1,P.d1)+jm(ae,P.d2);  xu2 = jm(a2,P.wcc)+jm(ae,P.ec);
yu1 = jm(b1,P.d1)+jm(be,P.d2);  yu2 = jm(b2,P.wcc)+jm(be,P.ec);
v = xDy - (jm(xu1,jm(P.Q11,yu1)+jm(P.Q12,yu2)) + jm(xu2,jm(P.Q21,yu1)+jm(P.Q22,yu2)));
end
