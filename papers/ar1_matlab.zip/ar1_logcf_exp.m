function [L,info] = ar1_logcf_exp(sj,tj,n,phi,cas,par0)
%AR1_LOGCF_EXP  Log joint characteristic function in the explosive region, by
%   a cancellation-free rearrangement of the closed forms (cases 'DK', 'DU', 'DT').
%
%   L = AR1_LOGCF_EXP(t1,t2,n,phi,cas,par0) returns the jet of log phi
%   exactly as AR1_LOGCF does, for the fixed-start cases with |phi| > 1.
%
%   Why a separate routine.  With |phi| > 1 the tridiagonal core D has
%   |D| ~ phi^{2n} while |K| = O(1) (the real part of K has unit
%   determinant), so the assembly |K| = |D| rho delta_4 computes the O(1)
%   determinant as the product of a huge number and tiny ones, each of
%   which is itself a difference of O(1) quantities: the relative error is
%   eps phi^{2n}.  The same amplification affects a pivot recursion in
%   either direction (the pivots of Re K eliminated from the last coordinate
%   are all one, but that fixed point of the recursion is unstable, with
%   multiplier phi^2 per step).  The remedy is algebraic (Proposition 3 of
%   the paper).  With r+- the roots of r^2 - p r + q^2 = 0, h = r+ - r-,
%   e+- = 1 - r+-, w = q/r+ and zeta = w^2 = r-/r+,
%
%      |D| = r+^n (1 - zeta^n)/h,
%      delta_DK = 1 - q^2 d3 = (e- - zeta^n e+)/(1 - zeta^n),
%      e+ e- = 1 - p + q^2 = 2i t2 - t1^2,   so   e- = (2i t2 - t1^2)/e+,
%
%   in which e- is small but exact to rounding, and nothing cancels.  Case
%   'DK' is then phi = |D|^{-1/2} delta_DK^{-1/2} exp(z0^2 e+ e-/(2 delta_DK)).
%   In case 'DU', K = [D + kappa 11', b; b', 1] with b = b1 1 + q e_m,
%   b1 = i t1/n, and eliminating the last coordinate gives |K| = |D| rho S,
%   rho = 1 + kappa d1, and beta'K^{-1}beta = gamma^2[(1-phi)^2 d1/rho + F^2/S],
%   where the small quantities S ~ phi^{-2n} and F ~ phi^{-n} are sums of
%   small terms,
%     rho S = rho delta_DK + (2i/n) q d2 (t1 f + t2 q d2) + (t1^2/n^2) d1,
%     rho F = f - (i/n)[(1-phi) t1 + 2 t2] d1,
%   with the stable combinations
%     g = q^2(d3 + d4) - 1 = [(-w)^n h - (e- - zeta^n e+)]/(1 - zeta^n),
%     f = (1-phi) q d2 - 1 = {i[(1-phi) t1 + 2 t2] + (1-phi) g}/(p+2q).
%   The three factors |D|, rho and S carry the continuous phase:
%   the first by the roots-regime identity of Theorem 2(iii), the other two by
%   their principal arguments (a rank-one factor and a Schur complement of
%   an accretive matrix).  Verified against a 250-digit evaluation of the
%   pivot recursion (validation/hp_ref.py) to 2.5e-13 in log phi, and
%   typically 1e-14, on a grid reaching |phi|^{2n} = 2e211; the limit is the
%   representability of phi^{-2n} in double precision.
%
%   See also AR1_LOGCF, AR1_LOGCF_PIV.

if nargin < 6 || isempty(par0), par0 = 0; end
cas = upper(cas);
if size(sj,1) == 1 && size(tj,1) > 1, sj = [sj; zeros(size(tj,1)-1,size(sj,2))]; end
if size(tj,1) == 1 && size(sj,1) > 1, tj = [tj; zeros(size(sj,1)-1,size(tj,2))]; end
if size(sj,2) == 1 && size(tj,2) > 1, sj = repmat(sj,1,size(tj,2)); end
if size(tj,2) == 1 && size(sj,2) > 1, tj = repmat(tj,1,size(sj,2)); end
K = size(sj,1)-1;  N = size(sj,2);
m = n-1;
om  = 1-phi;
q   = jc(-1i*sj,-phi);
p2q = jc(2i*(-om*sj-tj),om^2);
p   = p2q-2*q;
tau0 = jm(sj,sj)-2i*tj;                       % s^2 - 2it

% ---- roots, with r1 the root of larger modulus --------------------------
pm2q = jc(2i*((1+phi)*sj-tj),(1+phi)^2);
h  = jsq(jm(pm2q,p2q));
r1 = (p+h)/2;  r2 = (p-h)/2;
sw = abs(r2(1,:)) > abs(r1(1,:));
if any(sw), tmp = r1(:,sw); r1(:,sw) = r2(:,sw); r2(:,sw) = tmp; h(:,sw) = -h(:,sw); end
w    = jd(q,r1);
zn   = jpow(w,2*n);                           % zeta^n
zn1  = jpow(w,2*n-2);                         % zeta^{n-1}
wn   = jpow(-w,n);                            % (-w)^n = (-q)^n / r1^n
den  = jc(-zn,1);                             % 1 - zeta^n
ep   = jc(-r1,1);                             % e+ = 1 - r1
em   = jd(-tau0,ep);                          % e- = -(s^2-2it)/e+
% log|D_{n-1}| with continuous phase: |D| = r1^n (1-zeta^n)/h
lgD  = n*jlogc(r1)+jlogc(den)-jlogc(h);
% delta_3 = |R_n|/|D_{n-1}|, off the negative axis (accretivity)
RD   = jd(em-jm(zn,ep),den);
% primitives of D (closed forms; stable away from phi = 1)
d3 = jd(jd(jc(-zn1,1),r1),den);
d4 = ((-1)^n)*jd(jm(jpow(w,n-2),h),jm(jm(r1,r1),den));
d2 = jd(jc(jm(q,d3+d4),1),p2q);
d1 = jd(jc(2*jm(q,d2),m),p2q);
% g = q^2(d3+d4) - 1 = [(-q)^n - |R_n|]/|D_{n-1}| = [(-w)^n h - (e- - zeta^n e+)]/(1-zeta^n)
g  = jd(jm(wn,h)-(em-jm(zn,ep)),den);
% f = (1-phi) q d2 - 1, stable
f  = jd(1i*(om*sj+2*tj) + om*g, p2q);

switch cas
    case 'DK'
        % |R_n|^{-1/2} exp( z0^2 e+ e- |D|/(2|R_n|) )
        L = -0.5*(lgD+jlogc(RD)) + 0.5*par0^2*jd(jm(ep,em),RD);
    case 'DU'
        % K = [Delta, b; b', 1] with Delta = D + kap 11', b = sig 1 + q e_m,
        % sig = is/n.  Eliminating the last coordinate,
        %   |K| = |D| (1 + kap d1) S,      S = 1 - b'Delta^{-1}b,
        %   delta'K^{-1}delta = (1-phi)^2 d1/(1+kap d1) + F^2/S,
        %   F = (1-phi) 1'Delta^{-1}b - 1,
        % and S ~ phi^{-2n}, F ~ phi^{-n} are rearranged so that only small
        % quantities are added:
        %   S (1+kap d1) = delta3 (1+kap d1) + (2i/n) q d2 (s f + t q d2) - sig^2 d1,
        %   F (1+kap d1) = f - (i/n)[(1-phi)s + 2t] d1.
        kap = 2i*(om*sj+tj)/n;
        sig = 1i*sj/n;
        rho = jc(jm(kap,d1),1);                   % |Delta|/|D|, off the negative axis
        qd2 = jm(q,d2);
        S   = RD + jd((2i/n)*jm(qd2,jm(sj,f)+jm(tj,qd2)) - jm(jm(sig,sig),d1), rho);
        F   = jd(f - (1i/n)*jm(om*sj+2*tj,d1), rho);
        w1  = jd(d1,rho);
        L = -0.5*(lgD+jlogc(rho)+jlogc(S)) + 0.5*par0^2*jc(om^2*w1 + jd(jm(F,F),S), -n);
    case 'DT'
        % K = [D + Z C Z', q e_m + Z bv; ., 1], Z = [1, l], l = (1..m)' - n/2
        % (the trend cases of AR1_LOGCF).  With h = q (d2, ec)' = (h1, h2)',
        % W = diag(d1, wcc), M = I + C W, s = C h - 2 bv,
        %   S = delta3 + h's - h'C W M^{-1} s - bv'W M^{-1} bv,
        % in which only h's needs rearranging (the other terms are products
        % of small factors).  With the stable combinations f = (1-phi) h1 - 1
        % (case DU) and
        %   lam = k0 h1 + (1-phi) h2 - m/2 = {(i/2)[(n(1-phi)+1+phi) s + 2m t]
        %         - (1/2)(n(1-phi)+1+phi) g - n(1-phi) delta3}/(p+2q),
        % k0 = -(1+phi)/2. Here f is O(|phi|^{-n}) and lam is O(n |phi|^{-n}),
        %   h's = i s [2 G1 h1 f + G2 lam (h1 + 2 h2)] + 2i t [G1 h1^2 + G2 (h1/2 + h2)^2].
        % The mean enters through F = bn - b'Delta^{-1}bc = -gamma f - gamma_tau lam
        %   + h'C W M^{-1} kc - bv'W M^{-1} kc,  kc = (gamma(1-phi) + gamma_tau k0, gamma_tau(1-phi))',
        % and the exponent is [E0 - kc'W C W M^{-1} kc + F^2/S]/2 with
        %   (p+2q) E0 = gamma^2 [(1-phi)(1+phi) + 2(1-phi) f + 2i n((1-phi)s + t)]
        %             - gamma gamma_tau (1+phi)(a + 2f)
        %             + gamma_tau^2 [(1+phi)(a^2 + 2 a f)/(4(1-phi)) + n(1-phi) lam
        %                            + i n(n^2-1)((1-phi)s + t)/6],   a = n(1-phi)+1+phi,
        % the exact form of kc'W kc - n gamma^2 - gamma_tau^2 n(n^2-1)/12 (no
        % difference of large terms).  Derived and checked symbolically (note
        % on the trend cases, Section 5).
        G1 = 1/n;  G2 = 12/(n*(n^2-1));  k0 = -(1+phi)/2;  a = n*om+1+phi;
        h1  = jm(q,d2);
        lam = jd(0.5i*(a*sj + 2*m*tj) - 0.5*a*g - n*om*RD, p2q);
        h2  = jc(lam - k0*h1, m/2)/om;
        wcc = jd(jc(n*h2, m*(m^2-1)/12), p2q);
        C11 = G1*(2i*om*sj + 2i*tj) + G2*(1i*k0*sj + 0.5i*tj);
        C12 = G2*(-1i*phi*sj + 1i*tj);
        C22 = G2*(2i*om*sj + 2i*tj);
        bv1 = G1*1i*sj + G2*(m/2)*0.5i*sj;
        bv2 = G2*(m/2)*1i*sj;
        % M = I + C W and R = M^{-1}
        M11 = jc(jm(C11,d1),1);  M12 = jm(C12,wcc);  M21 = jm(C12,d1);  M22 = jc(jm(C22,wcc),1);
        detM = jm(M11,M22)-jm(M12,M21);
        R11 = jd(M22,detM);  R12 = jd(-M12,detM);  R21 = jd(-M21,detM);  R22 = jd(M11,detM);
        % s = C h - 2 bv
        s1 = jm(C11,h1)+jm(C12,h2)-2*bv1;  s2 = jm(C12,h1)+jm(C22,h2)-2*bv2;
        % row vectors x'C W and x'W for x = h, bv; then x'(C W) R y and x'W R y
        cw = @(x1,x2) {jm(jm(x1,C11)+jm(x2,C12),d1), jm(jm(x1,C12)+jm(x2,C22),wcc)};
        qf = @(r,y1,y2) jm(r{1},jm(R11,y1)+jm(R12,y2)) + jm(r{2},jm(R21,y1)+jm(R22,y2));
        hCW = cw(h1,h2);  bW = {jm(bv1,d1), jm(bv2,wcc)};
        hs = 1i*jm(sj, 2*G1*jm(h1,f) + G2*jm(lam,h1+2*h2)) ...
           + 2i*jm(tj, G1*jm(h1,h1) + G2*jm(0.5*h1+h2,0.5*h1+h2));
        S  = RD + hs - qf(hCW,s1,s2) - qf(bW,bv1,bv2);
        % log|K|^{-1/2}: |D| (continuous phase), |M| (two eigenvalue factors), S
        lM = jlogc(detM);
        c11 = C11(1,:); c12 = C12(1,:); c22 = C22(1,:); w1 = d1(1,:); w2 = wcc(1,:);
        tr = c11.*w1 + c22.*w2;  dt = (c11.*c22 - c12.^2).*w1.*w2;  sq = sqrt(tr.^2-4*dt);
        lM(1,:) = log(abs(detM(1,:))) + 1i*(angle(1+(tr+sq)/2) + angle(1+(tr-sq)/2));
        L = -0.5*(lgD + lM + jlogc(S));
        gam = par0(1);  gtau = 0;
        if numel(par0) > 1, gtau = par0(2); end
        if gam ~= 0 || gtau ~= 0
            kc1 = gam*om + gtau*k0;  kc2 = gtau*om;
            kj1 = jc(0*h1,kc1);  kj2 = jc(0*h1,kc2);         % kc as jets (constants)
            F  = -gam*f - gtau*lam + qf(hCW,kj1,kj2) - qf(bW,kj1,kj2);
            kW = {kc1*d1, kc2*wcc};                     % kc'W
            kWCW = {jm(jm(kW{1},C11)+jm(kW{2},C12),d1), jm(jm(kW{1},C12)+jm(kW{2},C22),wcc)};
            ost = om*sj + tj;
            E0 = gam^2*jc(2*om*f + 2i*n*ost, om*(1+phi)) - gam*gtau*(1+phi)*jc(2*f, a) ...
               + gtau^2*(jc((1+phi)*2*a*f, (1+phi)*a^2)/(4*om) + n*om*lam + 1i*n*(n^2-1)/6*ost);
            E0 = jd(E0,p2q);
            L = L + 0.5*(E0 - qf(kWCW,kj1,kj2) + jd(jm(F,F),S));
        end
    otherwise
        error('ar1:cas','AR1_LOGCF_EXP handles the fixed-start cases only.');
end
info = struct('regime',3*ones(1,N));
% Near a zero of U_m (|q d3| large), and in case DT where M is nearly
% singular, the closed forms lose about eps t1^2 at large t1 (NaN at some
% points in case DT; November 2026).  There x = p/(2q) is near -phihat in
% (-1,1), |w| is close to 1 and the explosive cancellation that this
% arrangement avoids is absent, so those columns are evaluated by the
% generic assembly of AR1_LOGCF, which has the cancellation-free forms for
% them.  (|q d3| is about |w| < 1 wherever |w|^{2n} is small, so these
% columns never fall in the explosive regime proper.)
fl = abs(q(1,:).*d3(1,:)) > 4;
fl = fl & imag(sj(1,:)) == 0 & imag(tj(1,:)) == 0;     % real (t1,t2) only (as in AR1_LOGCF)
if strcmp(cas,'DT')
    fl = fl | (min(abs(1+(tr+sq)/2),abs(1+(tr-sq)/2)) < 0.05 & imag(sj(1,:)) == 0 & imag(tj(1,:)) == 0);
end
if any(fl)
    L(:,fl) = ar1_logcf(sj(:,fl),tj(:,fl),n,phi,cas,par0,struct('exp',false));
    info.regime(fl) = 0;
end
end

function l = jlogc(a)
l = jlog0(a);
l(1,:) = log(abs(a(1,:))) + 1i*angle(a(1,:));
end
