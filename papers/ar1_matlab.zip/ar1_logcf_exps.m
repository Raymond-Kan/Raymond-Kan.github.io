function [L,info] = ar1_logcf_exps(aj,bj,n,phi,cas,par0)
%AR1_LOGCF_EXPS  Log joint characteristic function of the scaled numerator and
%   denominator in the explosive region, for any n (cases 'DK', 'DU', 'DT').
%
%   L = AR1_LOGCF_EXPS(a,b,n,phi,cas,par0) returns the jet of
%
%       log E[exp(i a ut + i b vt)],   ut = |phi|^(-n) u,   vt = phi^(-2n) v,
%
%   for the fixed-start cases with |phi| > 1, where (u,v) are the numerator
%   and denominator of phihat - phi (AR1_LOGCF).  In terms of AR1_LOGCF,
%   L(a,b) = log phi(|phi|^(-n) a, phi^(-2n) b), and ut/vt = |phi|^n
%   (phihat - phi) is of order one, so the distribution of
%   X_n = |phi|^n (phihat - phi)/(phi^2 - 1) is obtained by inversion in a
%   and b of order one (AR1_CDF and AR1_PDF with centered = 'scaled').
%
%   Why.  AR1_LOGCF_EXP evaluates the cancellation-free forms of Proposition
%   3 of the paper at t1 of order |phi|^(-n) and t2 of order phi^(-2n); its
%   small quantities (e- and delta_3 of order phi^(-2n), g, f and F of order
%   |phi|^(-n), S of order phi^(-2n)) underflow, and the routine fails, once
%   phi^(2n) exceeds about 1e300.  Here the same forms are written for the
%   scaled arguments, with every small quantity carried divided by its
%   order (e-/eps, delta_3/eps, g/se, f/se, lam/se, S/eps, F/se, with
%   se = |phi|^(-n) and eps = se^2), and log|D| + log eps formed as
%   n log(r+/phi^2) + log(1 - zeta^n) - log h, where n log(r+/phi^2),
%   zeta^n/eps and (-w)^n/se come from log1p of the small quantities t1/phi
%   and e- (r+/phi^2 = (1 + i t1/phi)^2/(1 - e-)), so that no O(1) number
%   is raised to the power n and the error does not grow with n.  The remaining explicit
%   factors se and eps multiply terms that are smaller than the retained
%   ones by that factor; where se underflows to zero those terms are below
%   rounding, so the routine has no upper limit in n.  Wherever both are
%   representable the result equals AR1_LOGCF_EXP(se a, eps b, ...) to
%   rounding (the two are algebraically identical; AR1_TEST checks this).
%   The phase is assembled as in AR1_LOGCF_EXP: n log(r+/phi^2) has the
%   phase of n arg r+, since phi^2 > 0 and r+/phi^2 is near one.
%
%   See also AR1_LOGCF_EXP, AR1_CDF, AR1_PDF, AR1EXPLIM.

if nargin < 6 || isempty(par0), par0 = 0; end
cas = upper(cas);
if size(aj,1) == 1 && size(bj,1) > 1, aj = [aj; zeros(size(bj,1)-1,size(aj,2))]; end
if size(bj,1) == 1 && size(aj,1) > 1, bj = [bj; zeros(size(aj,1)-1,size(bj,2))]; end
if size(aj,2) == 1 && size(bj,2) > 1, aj = repmat(aj,1,size(bj,2)); end
if size(bj,2) == 1 && size(aj,2) > 1, bj = repmat(bj,1,size(aj,2)); end
N = size(aj,2);
m   = n-1;
om  = 1-phi;
se  = exp(-n*log(abs(phi)));                  % |phi|^(-n), may underflow to 0
se2 = se^2;                                   % eps = phi^(-2n)
sj  = se*aj;  tj = se2*bj;                    % the unscaled arguments t1, t2
q   = jc(-1i*sj,-phi);
p2q = jc(2i*(-om*sj-tj),om^2);
p   = p2q-2*q;
tau0s = jm(aj,aj)-2i*bj;                      % (t1^2 - 2i t2)/eps

% ---- roots, with r1 the root of larger modulus --------------------------
pm2q = jc(2i*((1+phi)*sj-tj),(1+phi)^2);
h  = jsq(jm(pm2q,p2q));
r1 = (p+h)/2;  r2 = (p-h)/2;
sw = abs(r2(1,:)) > abs(r1(1,:));
if any(sw), tmp = r1(:,sw); r1(:,sw) = r2(:,sw); r2(:,sw) = tmp; h(:,sw) = -h(:,sw); end %#ok<NASGU>
w    = jd(q,r1);                              % about -1/phi
ep   = jc(-r1,1);                             % e+ = 1 - r1
ems  = jd(-tau0s,ep);                         % e-/eps
% The powers of order n are formed from logarithms of the small
% quantities, not from O(1) numbers raised to the power n (which would
% carry an error of order n eps): with r2 = 1 - e- = q^2/r1 and
% q = -phi(1 + i t1/phi),
%   r1/phi^2 = (1 + i t1/phi)^2/(1 - e-),
%   |phi| w  = -sign(phi) (1 - e-)/(1 + i t1/phi),
% so with lr = log(1 - e-) - log(1 + i t1/phi) (both by log1p),
%   n log(r1/phi^2) = n[2 log(1 + i t1/phi) - log(1 - e-)],
%   zeta^n/eps = exp(2 n lr),   (-w)^n/se = sign(phi)^n exp(n lr).
l1t  = jlog1p(1i*sj/phi);
l1e  = jlog1p(-se2*ems);
lr   = l1e-l1t;
zns  = jexp(2*n*lr);                          % zeta^n/eps
wns  = sign(phi)^n*jexp(n*lr);                % (-w)^n/se
zn1  = se2*jd(zns,jm(w,w));                   % zeta^(n-1)
den  = jc(-se2*zns,1);                        % 1 - zeta^n
% log|D_{n-1}| + log eps, continuous phase: |D| = r1^n (1-zeta^n)/h
lgD  = n*(2*l1t-l1e)+jlogc(den)-jlogc(h);
% delta_3/eps
RD   = jd(ems-jm(zns,ep),den);
% primitives of D
d3 = jd(jd(jc(-zn1,1),r1),den);
d4 = se*jd(jm(wns,h),jm(jm(jm(w,w),jm(r1,r1)),den));
d2 = jd(jc(jm(q,d3+d4),1),p2q);
d1 = jd(jc(2*jm(q,d2),m),p2q);
% g/se and f/se
g  = jd(jm(wns,h)-se*(ems-jm(zns,ep)),den);
f  = jd(1i*(om*aj+2*se*bj) + om*g, p2q);

switch cas
    case 'DK'
        L = -0.5*(lgD+jlogc(RD)) + 0.5*par0^2*jd(jm(ep,ems),RD);
    case 'DU'
        % as in AR1_LOGCF_EXP, with S/eps and F/se
        kap = 2i*(om*sj+tj)/n;
        rho = jc(jm(kap,d1),1);
        qd2 = jm(q,d2);
        S   = RD + jd((2i/n)*jm(qd2,jm(aj,f)+jm(bj,qd2)) - jm(jm(1i*aj/n,1i*aj/n),d1), rho);
        F   = jd(f - (1i/n)*jm(om*aj+2*se*bj,d1), rho);
        w1  = jd(d1,rho);
        L = -0.5*(lgD+jlogc(rho)+jlogc(S)) + 0.5*par0^2*jc(om^2*w1 + jd(jm(F,F),S), -n);
    case 'DT'
        % as in AR1_LOGCF_EXP; C, s, bv carry a factor se (C = se Cs, ...),
        % lam = se lams, and S/eps, F/se
        G1 = 1/n;  G2 = 12/(n*(n^2-1));  k0 = -(1+phi)/2;  a = n*om+1+phi;
        h1  = jm(q,d2);
        lam = jd(0.5i*(a*aj + 2*m*se*bj) - 0.5*a*g - n*om*se*RD, p2q);
        h2  = jc(se*lam - k0*h1, m/2)/om;
        wcc = jd(jc(n*h2, m*(m^2-1)/12), p2q);
        C11 = G1*(2i*om*aj + 2i*se*bj) + G2*(1i*k0*aj + 0.5i*se*bj);
        C12 = G2*(-1i*phi*aj + 1i*se*bj);
        C22 = G2*(2i*om*aj + 2i*se*bj);
        bv1 = G1*1i*aj + G2*(m/2)*0.5i*aj;
        bv2 = G2*(m/2)*1i*aj;
        M11 = jc(se*jm(C11,d1),1);  M12 = se*jm(C12,wcc);  M21 = se*jm(C12,d1);  M22 = jc(se*jm(C22,wcc),1);
        detM = jm(M11,M22)-jm(M12,M21);
        R11 = jd(M22,detM);  R12 = jd(-M12,detM);  R21 = jd(-M21,detM);  R22 = jd(M11,detM);
        s1 = jm(C11,h1)+jm(C12,h2)-2*bv1;  s2 = jm(C12,h1)+jm(C22,h2)-2*bv2;
        cw = @(x1,x2) {jm(jm(x1,C11)+jm(x2,C12),d1), jm(jm(x1,C12)+jm(x2,C22),wcc)};
        qf = @(r,y1,y2) jm(r{1},jm(R11,y1)+jm(R12,y2)) + jm(r{2},jm(R21,y1)+jm(R22,y2));
        hCW = cw(h1,h2);  bW = {jm(bv1,d1), jm(bv2,wcc)};
        hs = 1i*jm(aj, 2*G1*jm(h1,f) + G2*jm(lam,h1+2*h2)) ...
           + 2i*jm(bj, G1*jm(h1,h1) + G2*jm(0.5*h1+h2,0.5*h1+h2));
        S  = RD + hs - qf(hCW,s1,s2) - qf(bW,bv1,bv2);
        lM = jlogc(detM);
        c11 = se*C11(1,:); c12 = se*C12(1,:); c22 = se*C22(1,:); w1 = d1(1,:); w2 = wcc(1,:);
        tr = c11.*w1 + c22.*w2;  dt = (c11.*c22 - c12.^2).*w1.*w2;  sq = sqrt(tr.^2-4*dt);
        lM(1,:) = log(abs(detM(1,:))) + 1i*(angle(1+(tr+sq)/2) + angle(1+(tr-sq)/2));
        L = -0.5*(lgD + lM + jlogc(S));
        % The noncentral exponent.  The estimator depends on (gamma, gamma_tau)
        % only through the effective start (Online Supplement, Proposition
        % S7.1): case DT with (gamma, gamma_tau) is case DT with (geff, 0),
        % geff = gamma - gamma_tau [(n+1)/2 + phi/(1-phi)], which is a series
        % without drift started at y0 = C = -geff/(1-phi).  With y0 as a
        % further coordinate of the Gaussian integral (a flat start), the
        % exponent is -C^2 Sig0/2, Sig0 the Schur complement of the start in
        % the matrix of (y0, y_1..y_n), and by Lemma 1 (y0 and y_n bordering
        % the core) Sig0 = delta4/S, delta4 = det [d1 d2; d2 S] of the 2 x 2
        % border.  In case DK (no regression) delta4 = tau = t1^2 - 2i t2
        % exactly; the regression changes the border by Xi, every entry of
        % which is proportional to (t1, t2), so that
        %   delta4 = tau + S_DK Xi11 + d1_DK Xi22 - 2 d2_DK Xi12 + det Xi,
        %   d1_DK = q^2(1-d3) + tau,  d2_DK = -q^2 d4,  S_DK = delta_3 (RD),
        % has no term that cancels at t = 0.  (The earlier assembly, beta'
        % K^-1 beta/2 + eta, formed the exponent as a difference of terms of
        % order geff^2 = O(gamma_tau^2 n^2) that cancel at t = 0, and lost
        % about eps (gamma_tau n)^2: log psi(0,0) = 4e-3 at n = 5e6, phi = 1.2,
        % gamma_tau = 1, and -64 at n = 5e8.)  Xi22 = S - S_DK is the explicit
        % part of S above, and with H1 = q Z'D^-1 e_1 = (h1, -h2) (by
        % persymmetry), H2 = (h1, h2), R = (I + CW)^-1 and the coupling
        % of y0 to the core, Z a_r, and to y_n, c0n, and its own term c00
        % (from the regression on 1 and t; the lag and the innovation of
        % y0 enter at t = 1),
        %   Xi11 = c00 + H1'R C H1 - 2 H1'R a_r - a_r'W R a_r,
        %   Xi12 = c0n + H1'R (C H2 - bv) - a_r'R'(H2 + W bv),
        % all carried divided by se (Xi22 by eps).
        gam = par0(1);  gtau = 0;
        if numel(par0) > 1, gtau = par0(2); end
        geff = gam - gtau*((n+1)/2 + phi/om);
        if geff ~= 0
            ar1 = G1*(1i*(1-2*phi)*aj + 2i*se*bj) + G2*(m/2)*(1i*(phi+0.5)*aj - 1i*se*bj);
            ar2 = G2*(m/2)*(1i*(2*phi-1)*aj - 2i*se*bj);
            c00 = (G1 + G2*m^2/4)*(2i*se*bj - 2i*phi*aj);
            c0n = (G1 - G2*m^2/4)*1i*aj;
            Rv  = @(x1,x2) {jm(R11,x1)+jm(R12,x2), jm(R21,x1)+jm(R22,x2)};      % R x
            dot = @(x,y1,y2) jm(x{1},y1) + jm(x{2},y2);
            % C H1 and C H2 (divided by se), H1 = (h1,-h2), H2 = (h1,h2)
            ch11 = jm(C11,h1) - jm(C12,h2);  ch12 = jm(C12,h1) - jm(C22,h2);
            rs1  = jm(C11,h1) + jm(C12,h2) - bv1;  rs2 = jm(C12,h1) + jm(C22,h2) - bv2;
            Rch1 = Rv(ch11,ch12);  Rar = Rv(ar1,ar2);  Rr = Rv(rs1,rs2);
            X11 = c00 + dot(Rch1,h1,-h2) - 2*dot(Rar,h1,-h2) - se*(jm(jm(ar1,d1),Rar{1}) + jm(jm(ar2,wcc),Rar{2}));
            X12 = c0n + dot(Rr,h1,-h2) - (jm(Rar{1},h1 + se*jm(d1,bv1)) + jm(Rar{2},h2 + se*jm(wcc,bv2)));
            X22 = hs - qf(hCW,s1,s2) - qf(bW,bv1,bv2);                        % S - RD
            q2  = jm(q,q);
            d4s = jd(jm(wns,h),jm(jm(jm(w,w),jm(r1,r1)),den));                % d4/se
            dl1 = jm(q2,jc(-d3,1)) + se2*tau0s;                                % d1_DK
            del4 = tau0s + se*jm(RD,X11) + jm(dl1,X22) + 2*jm(jm(q2,d4s),X12) ...
                 + se*jm(X11,X22) - jm(X12,X12);                               % delta4/eps
            L = L - 0.5*(geff/om)^2*jd(del4,S);
        end
    otherwise
        error('ar1:cas','AR1_LOGCF_EXPS handles the fixed-start cases DK, DU and DT only.');
end
info = struct('regime',3*ones(1,N));
end

function l = jlogc(a)
l = jlog0(a);
l(1,:) = log(abs(a(1,:))) + 1i*angle(a(1,:));
end

function l = jlog1p(x)
% log(1 + x) for a jet x with a small constant coefficient
l = jlog0(jc(x,1));
l(1,:) = log1p(x(1,:));
end
