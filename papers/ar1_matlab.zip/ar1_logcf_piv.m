function [L,info] = ar1_logcf_piv(sj,tj,n,phi,cas,par0)
%AR1_LOGCF_PIV  Log joint characteristic function by a backward pivot recursion.
%
%   L = AR1_LOGCF_PIV(t1,t2,n,phi,cas,par0) returns the same quantity as
%   AR1_LOGCF (the jet of log phi(t1,t2) with the continuous phase) by
%   Gaussian elimination of the matrix K of Theorem 1, carried out from the
%   LAST coordinate backwards.  Each step costs O(1), so the whole recursion
%   costs O(n) per point, and every pivot is the Schur complement of the
%   trailing block of an accretive matrix, hence lies in the open right half
%   plane: the sum of the principal arguments of the pivots is the continuous
%   phase of |K| pointwise, with no branch condition at all.
%
%   This routine is an independent check of the O(1) assembly of AR1_LOGCF:
%   it uses none of the closed forms (no Chebyshev polynomials, no roots, no
%   confluent expansions), only the recursion, and it is exact in exact
%   arithmetic.  It is NOT a remedy for the explosive region: eliminated
%   from the last coordinate, the pivots of Re K = (I - phi J)'(I - phi J)
%   are all one, but that fixed point of the pivot recursion
%   x -> p - q^2/x is unstable when |phi| > 1 (its multiplier is phi^2), so
%   rounding errors grow like phi^{2j} along the recursion, exactly as in
%   the generic closed-form assembly.  The cancellation-free rearrangement
%   AR1_LOGCF_EXP is what AR1_LOGCF uses there.  (Eliminating forwards, the
%   pivots converge to the stable fixed point phi^2 but the last pivot, of
%   order phi^{-2n}, is then a difference of O(1) quantities: same loss.)
%
%   The state of the elimination.  After the trailing coordinates have been
%   eliminated, the remaining matrix on the coordinates (0, 1, ..., j) is
%
%       [ c           (al 1 + a2 e_1 + be e_j)'            ]
%       [ ...         D_j + ka 11' + mu(1 e_j' + e_j 1') + nu e_j e_j' ],
%
%   with D_j the j x j Toeplitz core, and the linear term is
%   (b0; bc 1 + b1 e_1 + bm e_j).  Eliminating coordinate j updates these
%   nine scalars (all jets) in O(1) operations.
%
%   See also AR1_LOGCF.

if nargin < 6 || isempty(par0), par0 = 0; end
cas = upper(cas);
if size(sj,1) == 1 && size(tj,1) > 1, sj = [sj; zeros(size(tj,1)-1,size(sj,2))]; end
if size(tj,1) == 1 && size(sj,1) > 1, tj = [tj; zeros(size(sj,1)-1,size(tj,2))]; end
if size(sj,2) == 1 && size(tj,2) > 1, sj = repmat(sj,1,size(tj,2)); end
if size(tj,2) == 1 && size(sj,2) > 1, tj = repmat(tj,1,size(sj,2)); end
K = size(sj,1)-1;  N = size(sj,2);
m = n-1;
z = zeros(K+1,N);  one = jc(z,1);
om = 1-phi;
q  = jc(-1i*sj,-phi);
p  = jc(2i*(phi*sj-tj),1+phi^2);

switch cas
    case 'DK'
        c = one;  al = z;  a2 = z;  c1n = z;  kap = z;  b1 = z;  b2 = q;  cnn = one;
        b0 = z;  bc = z;  be1 = -par0*q;  bem = z;  bn = z;
        cst = -0.5*par0^2*jc(p,-1);  pref = 0;
    case 'DU'
        c = one;  al = z;  a2 = z;  c1n = z;  kap = 2i*(om*sj+tj)/n;  b1 = 1i*sj/n;  b2 = q;  cnn = one;
        b0 = z;  bc = jc(z,par0*om);  be1 = z;  bem = z;  bn = jc(z,par0);
        cst = jc(z,-0.5*n*par0^2);  pref = 0;
    case 'SK'
        c = jc(2i*(phi*sj-tj),1);  al = z;  a2 = q;  c1n = z;  kap = z;  b1 = z;  b2 = q;  cnn = one;
        b0 = z;  bc = z;  be1 = z;  bem = z;  bn = z;
        cst = z;  pref = 0.5*log1p(-phi^2);
    case 'SU'
        c = jc(2i*(phi*sj-tj)*(1-1/n),1);  al = 1i*((1-2*phi)*sj+2*tj)/n;  a2 = q;  c1n = 1i*sj/n;
        kap = 2i*(om*sj+tj)/n;  b1 = 1i*sj/n;  b2 = q;  cnn = one;
        b0 = z;  bc = z;  be1 = z;  bem = z;  bn = z;
        cst = z;  pref = 0.5*log1p(-phi^2);
    otherwise
        error('ar1:cas','unknown case');
end

logdet = z;  quad = z;              % jets of log|K| (continuous) and beta'K^{-1}beta
% ---- eliminate the last border coordinate n ----------------------------
piv = cnn;
logdet = logdet + jlogc(piv);
bj = bn;
quad = quad + jd(jm(bj,bj),piv);
% column of coordinate n: border entry c1n, core entries b1*1 + b2*e_m
% state after elimination (core coordinates 1..m, j = m):
ka = kap - jd(jm(b1,b1),piv);
mu = -jd(jm(b1,b2),piv);
nu = -jd(jm(b2,b2),piv);
al = al - jd(jm(c1n,b1),piv);
be = -jd(jm(c1n,b2),piv);
c  = c - jd(jm(c1n,c1n),piv);
bc = bc - jd(jm(bj,b1),piv);
bem = bem - jd(jm(bj,b2),piv);
b0 = b0 - jd(jm(bj,c1n),piv);
% ---- eliminate the core coordinates j = m, m-1, ..., 1 ----------------
for j = m:-1:1
    if j > 1
        piv = p + ka + 2*mu + nu;                 % (j,j) entry
        colc = ka + mu;                           % coefficient of 1_{j-1} in column j
        colq = q;                                 % coefficient of e_{j-1}
        colb = al + be;                           % border entry of column j
        bj   = bc + bem;                          % linear term at j
    else
        % j = 1: the vectors e_1 and e_j coincide
        piv  = p + ka + 2*mu + nu;
        colb = al + be + a2;
        bj   = bc + bem + be1;
    end
    logdet = logdet + jlogc(piv);
    quad   = quad + jd(jm(bj,bj),piv);
    if j > 1
        ka  = ka - jd(jm(colc,colc),piv);
        mu  = -jd(jm(colc,colq),piv);
        nu  = -jd(jm(colq,colq),piv);
        al  = al - jd(jm(colb,colc),piv);
        be  = -jd(jm(colb,colq),piv);
        c   = c - jd(jm(colb,colb),piv);
        bc  = bc - jd(jm(bj,colc),piv);
        bem = -jd(jm(bj,colq),piv);
        b0  = b0 - jd(jm(bj,colb),piv);
    else
        c   = c - jd(jm(colb,colb),piv);
        b0  = b0 - jd(jm(bj,colb),piv);
    end
end
% ---- the first border coordinate -----------------------------------------
logdet = logdet + jlogc(c);
quad   = quad + jd(jm(b0,b0),c);
L = -0.5*logdet + 0.5*quad + cst;
L(1,:) = L(1,:) + pref;
info = struct('regime',2*ones(1,N));
end

function l = jlogc(a)
%JLOGC  log of a jet with the principal argument in the constant term.
l = jlog0(a);
l(1,:) = log(abs(a(1,:))) + 1i*angle(a(1,:));
end
