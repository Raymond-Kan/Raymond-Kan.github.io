function [m,err] = ar1_mom(k,n,phi,cas,par0,c,tol)
%AR1_MOM  Exact moments of the least squares estimator of the AR(1) coefficient.
%
%   m = AR1_MOM(k,n,phi,cas,par0) returns m(j) = E[phihat^j], j = 1..k, for
%   the model and case described in AR1_CDF.
%   m = AR1_MOM(k,n,phi,cas,par0,c) returns the moments about c,
%   m(j) = E[(phihat-c)^j]; c = phi gives the moments of the estimation
%   error and c = E[phihat] the central moments, computed directly rather
%   than from the raw moments, so that no cancellation occurs (see
%   AR1_CMOM).  tol (optional) is the absolute tolerance of the quadrature
%   for the moments of the standardized ratio (default 1e-10; see
%   RATIO_MOM).  [m,err] = AR1_MOM(...) also returns the error estimates.
%
%   Existence (Proposition 1 of the paper).  For real k > 0, E|phihat|^k < inf
%   if and only if k < n-1 (cases 'DU' and 'SU', and 'DK' with z0 = 0),
%   k < n ('SK'), and k < n-2 ('DT' and 'ST', the cases with a trend), while
%   for 'DK' with z0 ~= 0 every moment exists (the denominator is bounded
%   below by z0^2).
%
%   Range.  For |phi| > 1 the moments can be evaluated in double precision
%   for phi^(2n) up to about 1e300; beyond that they are returned as NaN,
%   with warning 'ar1:range' (Section 4.3 of the paper).
%
%   Method.  Sawa's (1978) representation of the moments of a ratio as an
%   integral of derivatives of the joint moment generating function, the
%   derivatives being read off the Taylor-mode (jet) evaluation of
%   AR1_LOGCF at imaginary arguments (RATIO_MOM).  O(1) per node,
%   independent of n.
%
%   See also AR1_CMOM, AR1_CDF, AR1_PDF, AR1_LOGCF, RATIO_MOM.
if nargin < 5 || isempty(par0), par0 = 0; end
if nargin < 6 || isempty(c), c = 0; end
if nargin < 7, tol = []; end
[cas,par0] = ar1_args(n,phi,cas,par0);
if ~(isnumeric(k) && isscalar(k) && isreal(k) && isfinite(k) && k == round(k) && k >= 1), error('ar1:k','k must be a positive integer.'); end
switch cas
    case 'DK', if par0 == 0, kmax = n-2; else kmax = Inf; end
    case 'SK', kmax = n-1;
    case {'DT','ST'}, kmax = n-3;
    otherwise, kmax = n-2;
end
if k > kmax
    error('ar1:mom','E|phihat|^%d does not exist for this case with n = %d.',k,n);
end
% Range of double precision in the explosive region (Section 4.3 of the
% paper): E[v], of order phi^(2n), and the second scale of the integrand of
% RATIO_MOM, at log(s2 E[v]) of about log E[v], must be representable, so
% the moments are returned as NaN, with warning 'ar1:range', when phi^(2n)
% exceeds 1e300.  (Up to there all four moments are computed: RATIO_MOM
% rescales the jet variable at the second scale and normalizes each order by
% the peak of its integrand; checked at phi = 1.02, 1.1, -1.1 and 1.2 in
% cases DK, DU and DT, the values following the |phi|^(-n) scaling.)
m = NaN(1,k);  err = m;
kr = k;
if abs(phi) > 1
    lg = 2*n*log10(abs(phi));
    if lg > 300
        kr = 0;
        warning('ar1:range','ar1_mom: phi^(2n) = 10^%.0f exceeds 1e300; the moments are beyond the range of double precision (Section 4.3 of the paper) and are returned as NaN.',lg);
    end
end
if kr >= 1
    h = @(t1,t2) ar1_logcf(t1,t2,n,phi,cas,par0);
    [m(1:kr),err(1:kr)] = ratio_mom(h,kr,c-phi,tol);
end
end
