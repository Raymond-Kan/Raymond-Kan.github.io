function ar1_paper(outdir,which)
%AR1_PAPER  Reproduces the tables and figures of the paper.
%
%   AR1_PAPER(outdir) writes the LaTeX table bodies (tab_*.tex) and the
%   figures (fig_*.pdf) into outdir.  AR1_PAPER(outdir,which) runs only the
%   items listed in the cell array which, e.g. {'cv','mom'}.
%   Items: 'acc' (accuracy of the O(1) evaluation), 'conf' (confluence),
%   'time' (cost against n), 'cv' (exact critical values), 'mom' (moments,
%   Tables S5 and S6 of the Online Supplement), 'lur' (local to unity,
%   Table S9), 'exp' (explosive, Table S8), 'df' (simulated tables of
%   adftest versus the exact distribution; needs the Econometrics Toolbox),
%   'drift' (drift at the unit root), 'limconv' (Table S1 of the Online
%   Supplement: convergence of the characteristic function to its limit),
%   'expFU' (Table S10: the explosive limit with an intercept and its
%   corrections), 'figs' (figures).
if nargin < 1 || isempty(outdir), outdir = pwd; end
if nargin < 2, which = {'acc','conf','time','cv','cvext','mom','lur','exp','df','drift','limconv','expFU','figs'}; end
if ~exist(outdir,'dir'), mkdir(outdir); end
log = fopen(fullfile(outdir,'ar1_paper_log.txt'),'a');
fprintf(log,'\n==== ar1_paper run %s ====\n',datestr(now));

% ------------------------------------------------------------------ acc
if any(strcmp(which,'acc'))
    % max absolute error of the closed-form cf against the dense evaluation
    % along the inversion paths, n = 60 and 200
    % for |phi| > 1 the dense reference in double precision is itself
    % inaccurate at n = 200 (the covariance matrix has entries of order
    % phi^{2n} = 3.6e16); those rows use the same eigenvalue evaluation
    % carried out in 40-digit arithmetic (validation/hp_acc.py, mpmath),
    % read from validation/hp_acc_ref.txt, and are marked with a dagger
    hpfile = fullfile(fileparts(mfilename('fullpath')),'validation','hp_acc_ref.txt');
    hp = [];
    if exist(hpfile,'file')
        fh = fopen(hpfile,'r'); H = textscan(fh,'%s %f %f %f %f %f %f %f','CommentStyle','#'); fclose(fh);
        hp = struct('cas',{H{1}},'phi',H{2},'par0',H{3},'n',H{4},'r',H{5},'s',H{6},'cf',H{7}+1i*H{8});
    end
    fid = fopen(fullfile(outdir,'tab_acc.tex'),'w');
    cfg = {{'DK',0.5,0},{'DK',1,0},{'DK',1,1},{'DK',1.1,0.5},{'DK',-1,0},{'DU',0.9,0},{'DU',1,0},{'DU',1,1},{'DU',1.1,0.5},{'DU',-1,0},{'SK',0.95,[]},{'SK',0.999,[]},{'SU',0.95,[]},{'SU',0.999,[]}};
    svec = logspace(-5,3,2000);
    for ic = 1:numel(cfg)
        c = cfg{ic}; cas = c{1}; phi = c{2}; par0 = c{3};
        usehp = abs(phi) > 1 && ~isempty(hp) && any(strcmp(hp.cas,cas) & hp.phi == phi & hp.par0 == par0);
        row = sprintf('%s & $%g%s$ & %s', ['\textsf{' cas '}'], phi, repmat('^{\dagger}',1,usehp), parstr(cas,par0));
        for n = [60 200]
            worst = 0;
            if usehp
                sel = strcmp(hp.cas,cas) & hp.phi == phi & hp.par0 == par0 & hp.n == n;
                for r = unique(hp.r(sel)).'
                    i = find(sel & hp.r == r); s = hp.s(i).';
                    got = exp(ar1_logcf(s,-r*s,n,phi,cas,par0));
                    worst = max(worst,max(abs(got-hp.cf(i).')));
                end
            else
                h = @(t1,t2) ar1_logcf(t1,t2,n,phi,cas,par0);
                [Eu,Ev,~,Vu] = ratio_scale(h); sd = sqrt(Vu)/Ev;
                if abs(phi) > 1, rs = [-2 -0.1 0.1 2]*phi^(-n)*(phi^2-1); else rs = Eu/Ev+sd*[-3 -1 0.5 2]; end
                for r = rs
                    t = -r*svec;
                    got = exp(ar1_logcf(svec,t,n,phi,cas,par0));
                    ref = cf_dense(svec,t,n,phi,cas,par0);
                    worst = max(worst,max(abs(got-ref)));
                end
            end
            row = [row sprintf(' & %s', sci(worst))];
        end
        fprintf(fid,'%s \\\\\n',row);
    end
    fclose(fid);
    fprintf(log,'acc done\n');
end

% ----------------------------------------------------------------- conf
if any(strcmp(which,'conf'))
    % d1 = 1'D^{-1}1 at s = t = 0 (p = 1+phi^2, q = -phi), m = n-1, n = 120:
    % closed form in the roots vs Chebyshev expansion vs the spectral sum
    % reference.  The reference is evaluated in a cancellation-free form:
    % lambda_j = (p+2q) - 4q sin^2(j pi/(2n)) with p+2q = (1-phi)^2 formed
    % exactly (p + 2q cos(j pi/n) subtracts nearly equal numbers near phi = 1
    % and loses up to 1e-12 relative at n = 600), and the weights
    % (1'u_j)^2 = (2/n) cot^2(j pi/(2n)) for odd j, 0 for even j.  At phi = 1
    % the exact value is n(n^2-1)/12, against which the stabilized sum is
    % accurate to a few units of rounding; the reference is still a
    % double-precision evaluation, and the table reports differences from it.
    fid = fopen(fullfile(outdir,'tab_conf.tex'),'w');
    n = 120; m = n-1;
    for phi = [0.9 0.98 0.99 0.999 0.9999 0.99999 0.999999 1]
        p = 1+phi^2; q = -phi; p2q = (1-phi)^2;
        j = (1:2:m)'; lam = p2q-4*q*sin(j*pi/(2*n)).^2;
        w = (2/n)*cot(j*pi/(2*n)).^2;                      % (1'u_j)^2, odd j
        d1ex = sum(w./lam);
        % roots, forced
        [a1,~,~,~,~,~] = ttprimsj(p,q,p2q,m,0);
        % chebyshev, forced
        [a2,~,~,~,~,~] = ttprimsj(p,q,p2q,m,Inf);
        [a3,~,~,~,~,inf3] = ttprimsj(p,q,p2q,m);
        tau = n^2*abs(p2q/(2*q));
        fprintf(fid,'$%s$ & %s & %.6f & %s & %s & %s \\\\\n', num2str(phi,'%.6g'), sci(tau), d1ex, sci(abs(a1/d1ex-1)), sci(abs(a2/d1ex-1)), regname(inf3.regime));
    end
    fclose(fid);
    fprintf(log,'conf done\n');
end

% ----------------------------------------------------------------- time
if any(strcmp(which,'time'))
    fid = fopen(fullfile(outdir,'tab_time.tex'),'w');
    % the hardware and software of the run, for the table note (the times are a
    % benchmark on one machine, not a property of the method)
    cpu = '';
    if ispc
        [st,o] = system('reg query "HKLM\HARDWARE\DESCRIPTION\System\CentralProcessor\0" /v ProcessorNameString');
        if st == 0, t = regexp(o,'REG_SZ\s+([^\r\n]+)','tokens','once'); if ~isempty(t), cpu = strtrim(t{1}); end, end
    elseif isunix
        [st,o] = system('grep -m1 ''model name'' /proc/cpuinfo | cut -d: -f2'); if st == 0, cpu = strtrim(o); end
    end
    if isempty(cpu), cpu = computer; end
    os = computer;
    if ispc, [st,o] = system('ver'); if st == 0 && ~isempty(strtrim(o)), os = strtrim(o); end
    elseif isunix, [st,o] = system('uname -sr'); if st == 0, os = strtrim(o); end
    end
    hw = sprintf('%s, %s, %d computational threads, MATLAB %s', strtrim(cpu), os, maxNumCompThreads, version);
    fprintf(fid,'%% ar1_paper ''time'', %s: %s\n', datestr(now,'yyyy-mm-dd'), hw);
    fprintf(log,'time: %s, %s\n', datestr(now,'yyyy-mm-dd HH:MM'), hw);
    fh = fopen(fullfile(outdir,'tab_time_hw.tex'),'w'); fprintf(fh,'%s\n',hw); fclose(fh);
    for n = [100 1000 10000 100000 1000000]
        phi = 1; cas = 'DU'; x = 1-8/n;
        % warm-up call, then every entry is the average of five runs
        ar1_cdf(x,n,phi,cas,0); ar1_pdf(x,n,phi,cas,0); ar1_icdf(0.05,n,phi,cas,0); ar1_mom(4,n,phi,cas,0,1); ar1_cdf(0.95,n,0.95,'SU');
        tic; for k = 1:5, F = ar1_cdf(x,n,phi,cas,0); end; t1 = toc/5;
        tic; for k = 1:5, f = ar1_pdf(x,n,phi,cas,0); end; t2 = toc/5;
        tic; for k = 1:5, q = ar1_icdf(0.05,n,phi,cas,0); end; t3 = toc/5;
        tic; for k = 1:5, m = ar1_mom(4,n,phi,cas,0,1); end; t4 = toc/5;
        tic; for k = 1:5, F2 = ar1_cdf(0.95,n,0.95,'SU'); end; t5 = toc/5;
        % the same cdf value by the O(n) backward pivot recursion (AR1_LOGCF_PIV) in place of
        % the O(1) assembly: one run (it takes minutes at n = 10^6)
        hp = @(t1,t2) ar1_logcf_piv(t1,t2,n,phi,cas,0);
        tic; Fp = ratio_cdf(hp,x-phi); t6 = toc;
        % the eigenvalue approach: one eigendecomposition of the n x n matrix of u - rv
        % (one per value of r), n <= 10^4 only
        if n <= 1e4
            s = logspace(-2,2,2)/n^2;
            try, tic; cf_dense(s,-(x-phi)*s,n,phi,cas,0); t7 = sprintf('%.2f',toc); catch, t7 = '--'; end
        else
            t7 = '--';
        end
        fprintf(fid,'$10^{%d}$ & %.4f & %.4f & %.3f & %.3f & %.4f & %.2f & %s \\\\\n', round(log10(n)), t1, t2, t3, t4, t5, t6, t7);
        fprintf(log,'time n=%d: F=%.10f f=%.10f q=%.10f n*m1=%.8f F(O(n))=%.10f\n', n, F, f, n*(q-1), n*m(1), Fp);
    end
    fclose(fid);
end

% ------------------------------------------------------------------- cv
if any(strcmp(which,'cv'))
    pr = [0.01 0.025 0.05 0.10 0.50 0.90 0.95 0.975 0.99];
    ns = [25 50 100 250 500 1000];
    for cas = {'DK','DU'}
        fid = fopen(fullfile(outdir,['tab_cv_' cas{1} '.tex']),'w');
        for n = ns
            q = n*(ar1_icdf(pr,n,1,cas{1},0)-1);
            fprintf(fid,'%d%s \\\\\n', n, qcells(q));
        end
        q = ar1lim_icdf(pr,0,cas{1},0);
        fprintf(fid,'$\\infty$%s \\\\\n', qcells(q));
        fclose(fid);
    end
    % also the stationary cases at phi = 0.99, n = 100, and the two fixed
    % cases at 0.99: quantiles of sqrt(n)(phihat-phi) vs N(0,1-phi^2)
    fid = fopen(fullfile(outdir,'tab_q099.tex'),'w');
    pr2 = [0.01 0.05 0.10 0.50 0.90 0.95 0.99];
    for cas = {'DK','DU','SK','SU'}
        for n = [50 200 1000]
            q = sqrt(n)*(ar1_icdf(pr2,n,0.99,cas{1},0)-0.99);
            fprintf(fid,'%s & %d%s \\\\\n', ['\textsf{' cas{1} '}'], n, sprintf(' & $%.3f$',q));
        end
    end
    fprintf(fid,'$N(0,1-\\phi^2)$ & $\\infty$%s \\\\\n', sprintf(' & $%.3f$',sqrt(1-0.99^2)*sqrt(2)*erfinv(2*pr2-1)));
    fclose(fid);
    fprintf(log,'cv done\n');
end

% ---------------------------------------------------------------- cvext
if any(strcmp(which,'cvext'))
    pr = [0.005 0.01 0.025 0.05 0.10 0.25 0.50 0.75 0.90 0.95 0.975 0.99 0.995];
    ns = [10 15 20 25 30 40 50 75 100 150 200 250 300 400 500 750 1000 2000 5000];
    for cas = {'DK','DU'}
        if strcmp(cas{1},'DU'), fq = ' & $%.4f$'; else, fq = ' & $%.3f$'; end   % DU: four decimals (the 95% quantile at n = 25 is -0.0005)
        fid = fopen(fullfile(outdir,['tab_cvext_' cas{1} '.tex']),'w');
        for n = ns
            q = n*(ar1_icdf(pr,n,1,cas{1},0)-1);
            fprintf(fid,'%d%s \\\\\n', n, sprintf(fq,q));
        end
        q = ar1lim_icdf(pr,0,cas{1},0);
        fprintf(fid,'$\\infty$%s \\\\\n', sprintf(fq,q));
        fclose(fid);
    end
    fprintf(log,'cvext done\n');
end

% ------------------------------------------------------------------ mom
if any(strcmp(which,'mom'))
    % Table S5 of the Online Supplement: Panel A, the fixed-start cases
    % (tab_mom_F), and Panel B, the stationary-start cases (tab_mom_S, which
    % has no unit-root rows)
    fidF = fopen(fullfile(outdir,'tab_mom_F.tex'),'w'); fidS = fopen(fullfile(outdir,'tab_mom_S.tex'),'w');
    for phi = [0 0.5 0.9 0.99 1]
        for n = [25 100 400]
            rowF = sprintf('$%g$ & %d', phi, n); rowS = rowF;
            for cas = {'DK','DU','SK','SU'}
                if cas{1}(1) == 'S' && phi >= 1, continue, end
                [mu,v,sk,ku] = ar1_cmom(n,phi,cas{1},0);
                cells = sprintf(' & $%.4f$ & $%.4f$ & $%.3f$ & $%.3f$', mu-phi, sqrt(v), sk, ku);   % ku is the excess kurtosis
                if cas{1}(1) == 'D', rowF = [rowF cells]; else rowS = [rowS cells]; end
            end
            fprintf(fidF,'%s \\\\\n',rowF);
            if phi < 1, fprintf(fidS,'%s \\\\\n',rowS); end
        end
    end
    fclose(fidF); fclose(fidS);
    % moments of the limits at the unit root
    fid = fopen(fullfile(outdir,'tab_mom_lim.tex'),'w');
    for cas = {'DK','DU'}
        for n = [25 100 400 1600 6400 Inf]
            if isinf(n)
                m = ar1lim_mom(4,0,cas{1},0);
            else
                m = ar1_mom(4,n,1,cas{1},0,1);  m = m.*n.^(1:4);
            end
            mu = m(1); v = m(2)-mu^2; c3 = m(3)-3*mu*m(2)+2*mu^3; c4 = m(4)-4*mu*m(3)+6*mu^2*m(2)-3*mu^4;
            if isinf(n), ns = '$\infty$'; else ns = sprintf('%d',n); end
            fprintf(fid,'%s & %s & $%.4f$ & $%.4f$ & $%.4f$ & $%.4f$ \\\\\n', ['\textsf{' cas{1} '}'], ns, mu, sqrt(v), c3/v^1.5, c4/v^2-3);   % excess kurtosis
        end
    end
    fclose(fid);
    fprintf(log,'mom done\n');
end

% ------------------------------------------------------------------ lur
if any(strcmp(which,'lur'))
    fid = fopen(fullfile(outdir,'tab_lur.tex'),'w');
    pr = [0.05 0.50 0.95];
    for cas = {'DK','DU'}
        for c = [-10 -2 2 5]
            row = sprintf('%s & $%g$', ['\textsf{' cas{1} '}'], c);
            for n = [50 200 1000]
                phi = 1+c/n;
                q = n*(ar1_icdf(pr,n,phi,cas{1},0)-phi);
                row = [row sprintf(' & $%.3f$',q)];
            end
            q = ar1lim_icdf(pr,c,cas{1},0);
            row = [row sprintf(' & $%.3f$',q)];
            fprintf(fid,'%s \\\\\n',row);
        end
    end
    % stationary start with c < 0: exact (phi = 1+c/n) vs limit with random gamma
    for cas = {'SK','SU'}
        for c = [-10 -2]
            row = sprintf('%s & $%g$', ['\textsf{' cas{1} '}'], c);
            for n = [50 200 1000]
                phi = 1+c/n;
                q = n*(ar1_icdf(pr,n,phi,cas{1})-phi);
                row = [row sprintf(' & $%.3f$',q)];
            end
            q = ar1lim_icdf(pr,c,cas{1});
            row = [row sprintf(' & $%.3f$',q)];
            fprintf(fid,'%s \\\\\n',row);
        end
    end
    fclose(fid);
    fprintf(log,'lur done\n');
end

% ------------------------------------------------------------------ exp
if any(strcmp(which,'exp'))
    fid = fopen(fullfile(outdir,'tab_exp.tex'),'w');
    pr = [0.05 0.25 0.50 0.75 0.95];
    % case DK with z0 = 0 and 1, and case DU with gamma = 0 (the same Cauchy limit as DK, z0 = 0)
    cfg = {'DK',0,'\Fk, $z_0=0$'; 'DK',1,'\Fk, $z_0=1$'; 'DU',0,'\Fu, $\gamma=0$'};
    for ic = 1:size(cfg,1)
        cas = cfg{ic,1}; par = cfg{ic,2}; lab = cfg{ic,3};
        for phi = [1.05 1.2]
            for n = [10 25 50 100 400]
                g = phi^n/(phi^2-1);
                q = g*ar1_icdf(pr,n,phi,cas,par,[],true);   % quantiles of phihat-phi
                fprintf(fid,'%s & $%g$ & %d%s \\\\\n', lab, phi, n, sprintf(' & $%.4f$',q));
            end
            % limit quantiles: Z1/Z2 with Z2 ~ N(z0 sqrt(phi^2-1),1); for DU, z0 = gamma/(phi-1)
            z0 = par; if strcmp(cas,'DU'), z0 = par/(phi-1); end
            ql = zeros(size(pr));
            for i = 1:numel(pr)
                ql(i) = fzero(@(x) cdfexp(x,phi,z0)-pr(i),[-1e4 1e4]);
            end
            fprintf(fid,'%s & $%g$ & $\\infty$%s \\\\\n', lab, phi, sprintf(' & $%.4f$',ql));
        end
    end
    fclose(fid);
    fprintf(log,'exp done\n');
end

% ------------------------------------------------------------------- df
if any(strcmp(which,'df'))
    % simulated tables of adftest (Econometrics Toolbox) vs the exact
    % distribution of the normalized-bias statistic T_e(phihat-1), T_e = T-1
    if exist('adftest','file')
        fid = fopen(fullfile(outdir,'tab_df.tex'),'w');
        for T = [25 50 100 250 500 1000 5000]
            y = cumsum(randn(T,1)); row = sprintf('%d', T);
            for mdl = {'AR','ARD'}
                [~,~,~,cv] = adftest(y,'Model',mdl{1},'Test','t2','Lags',0,'Alpha',[0.01 0.05]);
                if strcmp(mdl{1},'ARD')
                    q = (T-1)*(ar1_icdf([0.01 0.05],T-1,1,'DU',0)-1); sz = ar1_cdf(1+cv/(T-1),T-1,1,'DU',0);
                else
                    q = (T-1)*(ar1_icdf([0.01 0.05],T,1,'DK',0)-1); sz = ar1_cdf(1+cv/(T-1),T,1,'DK',0);
                end
                row = [row sprintf(' & $%.3f$ & $%.3f$ & $%.2f$ & $%.3f$ & $%.3f$ & $%.2f$', cv(1), q(1), 100*sz(1), cv(2), q(2), 100*sz(2))];
            end
            fprintf(fid,'%s \\\\\n', row);
        end
        fclose(fid);
        fprintf(log,'df done\n');
    else
        fprintf(log,'df skipped (adftest not available)\n');
    end
end

% ---------------------------------------------------------------- drift
if any(strcmp(which,'drift'))
    fid = fopen(fullfile(outdir,'tab_drift.tex'),'w');
    pr = [0.05 0.50 0.95];
    for n = [50 200]
        for gam = [0 0.1 0.5 1 2]
            [mu,v,sk,ku] = ar1_cmom(n,1,'DU',gam);
            q = n*(ar1_icdf(pr,n,1,'DU',gam)-1);
            ql = ar1lim_icdf(pr,0,'DU',sqrt(n)*gam);
            fprintf(fid,'%d & $%g$ & $%.4f$ & $%.4f$ & $%.3f$ & $%.3f$%s%s \\\\\n', n, gam, n*(mu-1), n*sqrt(v), sk, ku, sprintf(' & $%.3f$',q), sprintf(' & $%.3f$',ql));
        end
    end
    fclose(fid);
    fprintf(log,'drift done\n');
end

% -------------------------------------------------------------- limconv
if any(strcmp(which,'limconv'))
    % Table S1: max |phi_n(t1/n, t2/n^2) - phi_inf(t1,t2)| over six points
    % (t1,t2), for n = 500, 2000, 8000, at phi = 1 + c/n with z0 = sqrt(n) gamma_0
    % (case DK) and gamma = varkappa/sqrt(n) (case DU); the differences are O(1/n)
    fid = fopen(fullfile(outdir,'tab_limconv.tex'),'w');
    cfg = {{'DK',0,0},{'DK',0,1.2},{'DK',-5,0.7},{'DK',3,0.5}, ...
           {'DU',0,0},{'DU',0,1.5},{'DU',-8,0.6},{'DU',2,-0.4}, ...
           {'SK',-4,[]},{'SK',-0.5,[]},{'SU',-6,[]},{'SU',-0.2,[]}};
    T1 = [1e-3 0.1 0.5 2 5 15]; T2 = [0.3 -1 4 -4 1.5 -0.2];
    for ic = 1:numel(cfg)
        c = cfg{ic}; cas = c{1}; cc = c{2}; par = c{3};
        Li = ar1lim_logcf(T1,T2,cc,cas,par);
        switch cas
            case 'DK', lab = sprintf('$(%g,\\gamma_0=%g)$',cc,par);
            case 'DU', lab = sprintf('$(%g,\\varkappa=%g)$',cc,par);
            otherwise, lab = sprintf('$c=%g$',cc);
        end
        row = sprintf('%s & %s',['\textsf{' cas '}'],lab);
        for n = [500 2000 8000]
            phi = 1+cc/n;
            switch cas
                case 'DK', p0 = sqrt(n)*par;
                case 'DU', p0 = par/sqrt(n);
                otherwise, p0 = [];
            end
            Ln = ar1_logcf(T1/n,T2/n^2,n,phi,cas,p0);
            row = [row sprintf(' & %s',sci(max(abs(exp(Ln)-exp(Li)))))]; %#ok<AGROW>
        end
        fprintf(fid,'%s \\\\\n',row);
    end
    fclose(fid);
    fprintf(log,'limconv done\n');
end

% ---------------------------------------------------------------- expFU
if any(strcmp(which,'expFU'))
    % Table S10: the explosive limit with an intercept.  For T_n = phi^n (phihat
    % - phi)/(phi^2 - 1) in case DU, the largest difference over a grid of x
    % between the exact P[T_n <= x] and (i) the limit Z1/(Z2 + a) of Wang and
    % Yu (2015), a = gamma (phi+1)/sqrt(phi^2-1); (ii) for gamma = 0, the
    % first-order correction F_C((x + d)/(1 + d/2)), d = c_E/n, c_E =
    % (phi+1)/(phi-1); (iii) the Gaussian-ratio law G_n of Proposition S5.1
    fid = fopen(fullfile(outdir,'tab_expFU.tex'),'w');
    rows = [1.175 0 50; 1.175 0 200; 1.175 0 800; 1.5 0 50; 1.5 0 200; -1.2 0 100; -1.2 0 201; ...
            1.175 -1 50; 1.175 -1 200; 1.175 -1 800; 1.5 0.4 100; 1.2 2 200];
    xg = [-8 -4 -2 -1 -0.5 -0.2 -0.1 0 0.03 sqrt(65)-8 0.1 0.2 0.5 1 2 4 8];
    for ir = 1:size(rows,1)
        phi = rows(ir,1); gam = rows(ir,2); n = rows(ir,3);
        cE = (phi+1)/(phi-1); d = cE/n; a = gam*(phi+1)/sqrt(phi^2-1);
        md = -d/(1-d); sd = sqrt(1-d-d^2)/(1-d);
        % P[T_n <= x] with the signed power phi^n: for phi^n < 0 (negative phi,
        % odd n) the inequality reverses, P[T_n <= x] = 1 - P[phihat - phi < x(phi^2-1)/phi^n]
        Fex = ar1_cdf(xg*(phi^2-1)/phi^n,n,phi,'DU',gam,[],true);
        if phi^n < 0, Fex = 1-Fex; end
        Flim = ratiocdf(xg,0,1,a);
        Fg = ratiocdf(xg,md,sd,a);
        e1 = max(abs(Fex-Flim)); e3 = max(abs(Fex-Fg));
        if gam == 0
            Ff = 0.5+atan((xg+d)/(1+d/2))/pi; e2 = sci(max(abs(Fex-Ff)),2);
        else
            e2 = '--';
        end
        fprintf(fid,'$%g$ & $%g$ & %d & $%.4g$ & %s & %s & %s \\\\\n',phi,gam,n,cE,sci(e1,2),e2,sci(e3,1));
    end
    fclose(fid);
    fprintf(log,'expFU done\n');
end

% ----------------------------------------------------------------- figs
if any(strcmp(which,'figs'))
    set(0,'DefaultAxesFontSize',10);
    % LaTeX for every piece of text (labels, tick labels, legends); restored on exit
    ip = {'DefaultTextInterpreter','DefaultAxesTickLabelInterpreter','DefaultLegendInterpreter'};
    old = cellfun(@(f) get(groot,f),ip,'UniformOutput',false);
    cl = onCleanup(@() cellfun(@(f,v) set(groot,f,v),ip,old));  %#ok<NASGU>
    cellfun(@(f) set(groot,f,'latex'),ip);
    % Figure S2 of the Supplement: densities of phihat, n = 25, four cases, phi = 0.5, 0.9, 1
    fh = figure('Visible','off','Position',[100 100 900 300]);
    phis = [0.5 0.9 1.0]; n = 25;
    for k = 1:3
        subplot(1,3,k); hold on
        phi = phis(k);
        % plotted range: from the smallest 0.2% quantile to the largest 99.8% quantile over the cases
        cases = {'DK','DU','SK','SU'}; if phi >= 1, cases = cases(1:2); end
        lo = Inf; hi = -Inf;
        for ic = 1:numel(cases), q = ar1_icdf([0.002 0.998],n,phi,cases{ic},0); lo = min(lo,q(1)); hi = max(hi,q(2)); end
        xx = linspace(lo,hi,300);
        ls = {'-','--','-.',':'}; leg = {};
        for ic = 1:numel(cases)
            cas = cases{ic};
            plot(xx,ar1_pdf(xx,n,phi,cas,0),ls{ic},'LineWidth',1.2); leg{end+1} = cas;
        end
        title(sprintf('$\\phi = %g$',phi)); xlabel('$\hat\phi$'); ylabel('density'); xlim([xx(1) xx(end)]);
        legend(leg,'Location','northwest'); box on
    end
    savefig_(fh,fullfile(outdir,'fig_pdf4.pdf')); close(fh);

    % Figure 1: exact density of n(phihat-1) vs the limit, DK and DU
    fh = figure('Visible','off','Position',[100 100 900 320]);
    for k = 1:2
        cas = {'DK','DU'}; cas = cas{k};
        subplot(1,2,k); hold on
        if k == 1, xx = linspace(-12,4,300); else xx = linspace(-20,5,300); end   % the left tails are long: cut where the densities fall below 2% of their peaks
        for n = [25 100 1000]
            plot(xx,ar1_pdf(1+xx/n,n,1,cas,0)/n,'LineWidth',1.1);
        end
        plot(xx,ar1lim_pdf(xx,0,cas,0),'k--','LineWidth',1.2);
        legend({'$n=25$','$n=100$','$n=1000$','limit'},'Location','northwest');
        xlabel('$n(\hat\phi-1)$'); ylabel('density'); title(cas); box on; xlim([xx(1) xx(end)]);
    end
    savefig_(fh,fullfile(outdir,'fig_df.pdf')); close(fh);

    % Figure 2: explosive case, phi = 1.05 (as in Table S9), DK (z0 = 0) and DU (gamma = 0), the
    % normalized statistic against the common standard Cauchy limit: DK converges like phi^-n, DU like 1/n
    fh = figure('Visible','off','Position',[100 100 900 320]);
    phi = 1.05; xx = linspace(-6,6,241);
    for k = 1:2
        cas = {'DK','DU'}; cas = cas{k};
        subplot(1,2,k); hold on
        for n = [25 100 400]
            g = phi^n/(phi^2-1);
            plot(xx,ar1_pdf(xx/g,n,phi,cas,0,[],true)/g,'LineWidth',1.1);
        end
        plot(xx,ar1explim(xx,phi,0),'k--','LineWidth',1.2);
        legend({'$n=25$','$n=100$','$n=400$','limit'},'Location','northeast');
        xlabel('$|\phi|^n(\hat\phi-\phi)/(\phi^2-1)$'); ylabel('density');
        title(cas); box on; xlim([xx(1) xx(end)]);
    end
    savefig_(fh,fullfile(outdir,'fig_exp.pdf')); close(fh);

    % Figure S1 of the Supplement: the two regimes for d1 along a path, n = 600, phi = 1-1e-7
    fh = figure('Visible','off','Position',[100 100 900 320]);
    n = 600; m = n-1; phi = 1-1e-7; r = 0.1/n;
    s = logspace(-13,-0.5,400); t = -r*s;
    p = 1+phi^2+2i*(phi*s-t); q = -(phi+1i*s); p2q = (1-phi)^2+2i*((phi-1)*s-t);
    tau = n^2*abs(p2q./(2*q));
    % reference: the spectral sum in its cancellation-free form (see 'conf')
    j = (1:2:m)'; w = (2/n)*cot(j*pi/(2*n)).^2; s2 = sin(j*pi/(2*n)).^2;
    d1ex = zeros(size(s));
    for i = 1:numel(s), d1ex(i) = sum(w./(p2q(i)-4*q(i)*s2)); end
    d1r = ttprimsj(p,q,p2q,m,0);  d1c = ttprimsj(p,q,p2q,m);
    % a few markers, evenly spaced in log|tau| (tau is not log-uniform in s)
    lt = log10(tau); tg = linspace(min(lt),max(lt),15);
    ii = unique(arrayfun(@(v) find(abs(lt-v) == min(abs(lt-v)),1), tg));
    subplot(1,2,1); loglog(tau,abs(d1ex),'k-','LineWidth',0.6); hold on
    loglog(tau,abs(d1r),'r--','LineWidth',0.8); loglog(tau(ii),abs(d1c(ii)),'bo','MarkerSize',4.5,'LineWidth',0.8);
    xlabel('$|\tau|$'); ylabel('$|d_1|$'); legend({'exact','roots','two-regime'},'Location','northeast'); box on
    set(gca,'XMinorTick','off','YMinorTick','off','XTick',10.^(-8:2:0),'YTick',10.^(6:3:18));   % ten and thirteen decades: no minor ticks
    xlim([min(tau) max(tau)]);
    subplot(1,2,2); loglog(tau,abs(d1r./d1ex-1)+1e-18,'r--','LineWidth',0.8); hold on
    loglog(tau,abs(d1c./d1ex-1)+1e-18,'b-','LineWidth',0.8);
    xlabel('$|\tau|$'); ylabel('relative error'); legend({'roots','two-regime'},'Location','northeast'); box on
    set(gca,'XMinorTick','off','YMinorTick','off','XTick',10.^(-8:2:0),'YTick',10.^(-15:5:10));
    xlim([min(tau) max(tau)]);
    savefig_(fh,fullfile(outdir,'fig_d1.pdf')); close(fh);
    fprintf(log,'figs done\n');
end
% ------------------------------------------------------------- cleanup
% replace signed zeros ($-0.000$) by $0.000$ in every table body written so far,
% except the quantile tables, where a printed -0.000 is a genuinely negative
% quantile (case DU, n = 25, p = 0.95: -0.000489)
dd = dir(fullfile(outdir,'tab_*.tex'));
dd = dd(~startsWith({dd.name},'tab_cv'));
for k = 1:numel(dd)
    f = fullfile(outdir,dd(k).name); txt = fileread(f);
    txt2 = txt;
    for z = 1:6, txt2 = strrep(txt2,['$-0.' repmat('0',1,z) '$'],['$0.' repmat('0',1,z) '$']); end
    if ~strcmp(txt,txt2), fid = fopen(f,'w'); fwrite(fid,txt2); fclose(fid); end
end
fclose(log);
end

% =========================================================================
function s = qcells(q)
% table cells to three decimals; a small negative quantile that would print as
% -0.000 is given to four decimals (case DU, n = 25, p = 0.95: -0.0005)
s = '';
for x = q(:)'
    if x < 0 && x > -0.0005, s = [s sprintf(' & $%.4f$',x)]; %#ok<AGROW>
    else, s = [s sprintf(' & $%.3f$',x)]; end %#ok<AGROW>
end
end
function s = sci(x,dg)
% x in scientific notation with dg digits after the decimal point (default 1)
if nargin < 2, dg = 1; end
if ~isfinite(x), s = '--'; return; end
if x == 0, s = '$0$'; return; end
e = floor(log10(x)); m = x/10^e;
if round(m,dg) >= 10, m = m/10; e = e+1; end
s = sprintf(['$%.' num2str(dg) 'f\\times 10^{%d}$'], m, e);
end
function s = parstr(cas,par0)
switch cas
    case 'DK', s = sprintf('$z_0=%g$',par0);
    case 'DU', s = sprintf('$\\gamma=%g$',par0);
    otherwise, s = '--';
end
end
function s = regname(r)
if r == 0, s = 'roots'; elseif r == -1, s = 'Chebyshev'; else s = 'Chebyshev$^+$'; end
end
function F = cdfexp(x,phi,z0)
[~,F] = ar1explim(x,phi,z0);
end
function F = ratiocdf(x,m,s,a)
%RATIOCDF  P[m + (s Z1 - m a)/(Z2 + a) <= x], Z1, Z2 independent N(0,1)
%   (the law G_n of Proposition S5.1; m = 0, s = 1 give the limit Z1/(Z2+a)).
Phi = @(z) 0.5*erfc(-z/sqrt(2)); npdf = @(z) exp(-z.^2/2)/sqrt(2*pi);
F = zeros(size(x));
for i = 1:numel(x)
    xm = x(i)-m;
    g = @(z) Phi((xm*(z+a)+m*a)/s).*npdf(z);                % Z2 + a > 0
    hh = @(z) (1-Phi((xm*(z+a)+m*a)/s)).*npdf(z);           % Z2 + a < 0
    F(i) = quadgk(g,-a,Inf,'AbsTol',1e-13,'RelTol',1e-11)+quadgk(hh,-Inf,-a,'AbsTol',1e-13,'RelTol',1e-11);
end
end

% =========================================================================
function savefig_(fh,file)
%SAVEFIG_  Vector PDF cropped to the content (exportgraphics when available).
if exist('exportgraphics','file')
    exportgraphics(fh,file,'ContentType','vector');
else
    set(fh,'PaperPositionMode','auto'); pos = get(fh,'Position');
    set(fh,'PaperUnits','points','PaperSize',pos(3:4),'PaperPosition',[0 0 pos(3:4)]);
    print(fh,file,'-dpdf');
end
end
