function [f,err] = ar1_pdf(x,n,phi,cas,par0,tol,centered)
%AR1_PDF  Exact density of the least squares estimator of the AR(1) coefficient.
%
%   f = AR1_PDF(x,n,phi,cas,par0) returns the density of phihat at the
%   points in x; inputs as in AR1_CDF.  tol (optional) is the absolute
%   tolerance of the quadrature (default 1e-10); centered = true reads x as
%   phihat - phi, and centered = 'scaled' as the value of
%   X_n = |phi|^n (phihat - phi)/(phi^2 - 1), whose density is then
%   returned, for any n (see AR1_CDF).  [f,err] = AR1_PDF(...) also returns the
%   error estimate (see RATIO_PDF and the accuracy note in AR1_CDF).
%
%   Method (Geary 1944):
%   f(x) = (1/pi) int_0^inf Im(d phi(t1,t2)/dt2 |_{t2=-r t1}) dt1, r = x - phi,
%   the t2-derivative being obtained exactly from a first-order jet of
%   log phi (AR1_LOGCF), at O(1) cost per quadrature point.
%
%   The inversion integral converges, and the density is finite, wherever
%   the quadratic form u - r v in the Gaussian coordinates has rank at
%   least three (its characteristic function then decays like t^(-rank/2)
%   and the integrand like t^(1-rank/2)).  The rank is generically n + 1
%   or n (n - 1 in cases DT and ST) and drops by one at isolated r, so the
%   density is infinite only at n = 3 in case DK with z0 = 0 at phihat = 0
%   (phihat = y_2(y_1+y_3)/(y_1^2+y_2^2)) and in cases DU and SU at
%   phihat = -1/2, and at n = 4 in cases DT and ST at phihat = -2/3, for
%   every phi and par0: the rank is two there and the density has a
%   logarithmic singularity.  The routine returns Inf, with a warning, only
%   where phihat equals the singular point exactly, and the finite density
%   at every other point, however close: for centered = true the distance
%   of phihat = x + phi from it is computed without rounding.  (-2/3 is not
%   a double, so in cases DT and ST the value Inf is never returned.  Until
%   November 2026 a band of 8 eps was used, which also returned Inf at
%   doubles distinct from the singular point, such as -1/2 + 2^(-49).)
%   (At n = 3
%   in cases DT and ST the rank is two for every r, but phihat is then a
%   ratio of two jointly normal variables, whose density is finite.)
%
%   In these smallest samples (n = 3 in cases DK, DU and SU, n = 4 in cases
%   DT and ST) the residualized lags have only two random dimensions, and
%   the density is computed at every x by AR1_PDF_RANK2 instead, by
%   integrating out the last observation (a two-dimensional integral).  The
%   inversion integrand decays only like t^(-3/2) there (in case DK with
%   z0 ~= 0 it also oscillates, and the inversion fails), and near a
%   singular point like t^(-1) out to t of order one over the distance.
%   At n = 4 in case DK with z0 ~= 0 the integrand still decays only like
%   t^(-2) and oscillates, and AR1_PDF_RANK3 (the same method, with three
%   random dimensions) is used; in the other cases with n = 4 the inversion
%   is fast and accurate.
%
%   See also AR1_CDF, AR1_ICDF, AR1_MOM, AR1_LOGCF, AR1_LOGCF_EXPS, RATIO_PDF.
if nargin < 5, par0 = 0; end
if nargin < 6, tol = []; end
if nargin < 7 || isempty(centered), centered = false; end
[cas,par0] = ar1_args(n,phi,cas,par0,x);
scaled = (ischar(centered) || isstring(centered)) && strcmpi(centered,'scaled');
if scaled
    % density of X_n: c times the density of ut/vt = |phi|^n (phihat - phi)
    % at c x (AR1_LOGCF_EXPS); the smallest samples, which have their own
    % routines, and phi^(2n) <= 100 go through phihat - phi
    c = ar1_scaled_check(phi,cas);
    small = n == 3 || (n == 4 && (cas(2) == 'T' || (strcmp(cas,'DK') && par0 ~= 0)));
    if 2*n*log10(abs(phi)) > 2 && ~small
        h = @(a,b) ar1_logcf_exps(a,b,n,phi,cas,par0);
        [f,err] = ratio_pdf(h,c*x,tol);  f = c*f;  err = c*err;
    else
        g = c/abs(phi)^n;
        [f,err] = ar1_pdf(g*x,n,phi,cas,par0,tol,true);  f = g*f;  err = g*err;
    end
    return
end
h = @(t1,t2) ar1_logcf(t1,t2,n,phi,cas,par0);
r = x-phi*(~centered);
% the density is infinite (rank two of u - r v) at n = 3: case DK with
% z0 = 0 at phihat = 0, cases DU and SU at phihat = -1/2; at n = 4,
% DT and ST have a rank-two logarithmic singularity at phihat = -2/3.
% AR1_PDF_RANK2 returns Inf exactly there and the finite density elsewhere.
% For centered = true, phihat = x + phi is passed as the unevaluated sum
% ph + plo of its rounded value and its rounding error (TwoSum, exact), so
% that the distance to the singular point is not lost to rounding
if centered
    ph = x+phi;  bb = ph-x;  plo = (x-(ph-bb))+(phi-bb);   % x + phi = ph + plo exactly
else
    ph = x;  plo = zeros(size(x));
end
istrend = n == 4 && any(strcmp(cas,{'DT','ST'}));
if (n == 3 && any(strcmp(cas,{'DK','DU','SU'}))) || istrend
    [f,err] = ar1_pdf_rank2(ph,n,phi,cas,par0,tol,plo);
    if any(isinf(f(:)))
        if cas(2) == 'U', xs = -0.5; else, xs = 0; end
        warning('ar1:singular','ar1_pdf: the density is infinite at phihat = %g for n = %d in case %s.',xs,n,cas);
    end
elseif n == 4 && strcmp(cas,'DK') && par0 ~= 0
    [f,err] = ar1_pdf_rank3(ph,n,phi,cas,par0);
else
    [f,err] = ratio_pdf(h,r,tol);
end
end
