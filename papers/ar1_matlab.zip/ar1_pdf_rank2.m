function [f,err] = ar1_pdf_rank2(xh,n,phi,cas,par0,tol,xlo)
%AR1_PDF_RANK2  Density of phihat when the residualized lags have two random
%   dimensions: n = 3 in cases DK, DU and SU, n = 4 in cases DT and ST.
%
%   [f,err] = AR1_PDF_RANK2(xh,n,phi,cas,par0,tol) returns the density of
%   phihat at the values xh of phihat itself (not of phihat - phi), with an
%   error estimate.  Called by AR1_PDF; the arguments are assumed checked.
%   [f,err] = AR1_PDF_RANK2(xh,n,phi,cas,par0,tol,xlo) evaluates the density
%   at the unevaluated sum phihat = xh + xlo (AR1_PDF passes the rounding
%   error of x + phi for a centered x), so that the distance of phihat from
%   the singular point is exact.
%
%   These are the configurations in which the density has a logarithmic
%   singularity (n = 3: phihat = 0 in case DK with z0 = 0, phihat = -1/2 in
%   cases DU and SU; n = 4: phihat = -2/3 in cases DT and ST; Section S6 of
%   the Supplement).  Near such a point the characteristic function of
%   u - rv decays like t^(-1) out to t of order one over the distance, so
%   the inversion integral of RATIO_PDF converges very slowly; this routine
%   avoids the inversion altogether.
%
%   Method.  Let z be the lags y_0..y_{n-1} residualized on the regressors
%   (none, 1, or 1 and t), so that v = z'z.  The numerator of phihat is
%       N = sum_{t=1}^{n-1} z_t z_{t+1} + z_n w,   w = y_n - x_{n+1}' b,
%   where x_{n+1}'b is the fitted line of the lags extrapolated to time n+1
%   (w = y_n without regressors).  Since phihat < x if and only if
%   N - x v < 0, and N - x v is linear in w with slope z_n,
%       f(x) = E[ v p(w*|z) / |z_n| ],   w* = -(Q(z) - x v)/z_n,
%   with Q(z) = sum_{t=1}^{n-1} z_t z_{t+1} and p(.|z) the normal density of
%   w given z (its variance is at least one, since w contains e_n).  Here z
%   has two random dimensions, z = mu_z + b_tau tau + b_gam gam with tau and
%   gam independent standard normal and z_n = mu_n + |r| tau, so f is a
%   two-dimensional integral.  The inner integral over tau is taken in
%   sigma = log|z_n| on each side of z_n = 0, where the factor 1/|z_n|
%   disappears; the integrand vanishes for |z_n| well below
%   |kappa0| = |Q - x v| at z_n = 0, and the inner integral grows like
%   log(1/|kappa0|) as kappa0 -> 0.  kappa0 is a quadratic in gam, and its
%   real roots are waypoints of the outer integral, whose integrand has
%   logarithmic singularities there.  Rounding is kept out of the small
%   quantities: kappa0 is evaluated in vertex form, and Q - x v along z_n
%   from coefficients formed once per gam, never as a difference of O(1)
%   terms at tiny z_n.  At the singular point itself kappa0
%   vanishes identically and the density is infinite: Inf is returned
%   exactly there (the distance dx = phihat - x0 is exactly zero), and the
%   finite density at every other point, however close.  (Until November
%   2026 this routine integrated at the singular point itself as well, with
%   the inner integral cut off at |z_n| = exp(-740), and returned a finite
%   value, 134.2 at n = 3, phi = 0.7 in case DU with gamma = 0.2.)
%
%   See also AR1_PDF.
if nargin < 6 || isempty(tol), tol = 1e-10; end
if nargin < 7 || isempty(xlo), xlo = zeros(size(xh)); end
stat = cas(1) == 'S';
m = n+stat;                                 % number of Gaussian innovations
mu = zeros(n+1,1);  L = zeros(n+1,m);       % y = mu + L*eps, y = (y_0..y_n)'
alpha = 0;  delta = 0;  y0 = 0;
switch cas
    case 'DK', y0 = par0(1);
    case 'DU', alpha = par0(1);              % y_0 = 0, gamma = alpha
    case 'DT'                                % y_0 = 0, delta = gamma_tau
        gm = par0(1);  gt = 0;  if numel(par0) > 1, gt = par0(2); end
        delta = gt;  alpha = gm-delta*(n+1)/2;
end
if stat, L(1,1) = 1/sqrt(1-phi^2); else, mu(1) = y0; end
for t = 1:n
    mu(t+1) = alpha+delta*t+phi*mu(t);
    L(t+1,:) = phi*L(t,:);  L(t+1,stat+t) = L(t+1,stat+t)+1;
end
S = [eye(n) zeros(n,1)];                    % the lags
switch cas(2)
    case 'K', X = zeros(n,0); xn1 = zeros(1,0);
    case 'U', X = ones(n,1);  xn1 = 1;
    otherwise, X = [ones(n,1) (1:n)']; xn1 = [1 n+1];
end
if isempty(X), B = zeros(0,n); else, B = (X'*X)\X'; end
Mz = eye(n)-X*B;
Gz = Mz*S*L;  muz = Mz*S*mu;
gw = (L(n+1,:)-xn1*B*S*L)';  muw = mu(n+1)-xn1*B*S*mu;
[U,Sg,V] = svd(Gz,'econ');  sg = diag(Sg);
if numel(sg) < 2 || sg(2) <= 1e-12*sg(1) || (numel(sg) > 2 && sg(3) > 1e-10*sg(1))
    error('ar1:rank2','ar1_pdf_rank2: the residualized lags do not have two random dimensions.');
end
Bz = U(:,1:2)*Sg(1:2,1:2);  V2 = V(:,1:2);  % z = muz + Bz*eta, eta = V2'*eps
cw = (gw'*V2)';  sw = sqrt(max(gw'*gw-cw'*cw,0));   % w | eta ~ N(muw + cw'eta, sw^2)
r = Bz(n,:)';  nr = norm(r);  e1 = r/nr;  e2 = [-e1(2); e1(1)];
bt = Bz*e1;  bg = Bz*e2;  ct = cw'*e1;  cg = cw'*e2;
tau0 = -muz(n)/nr;                          % z_n = nr (tau - tau0)
% z_n = 0 exactly on the gam line (bg is orthogonal to z_n): rounding here would turn
% a double root of kappa0 (case DK, n = 3, phihat = -1/2) into a small positive minimum
bg(n) = 0;  z0n = muz+bt*tau0;  z0n(n) = 0;
Aq = diag(ones(n-1,1),1);  Aq = (Aq+Aq')/2;  % Q(z) = z'Aq z
% the candidate singular point, and whether kappa0 vanishes identically there
% (it does in the rank-two configurations, not in case DK with z0 ~= 0)
switch cas(2), case 'K', x0 = 0; case 'U', x0 = -1/2; otherwise, x0 = -2/3; end
% the distance dx = phihat - x0, with a single rounding: xh - x0 is exact
% near x0 (Sterbenz), and -2/3 = fl(-2/3) - 2^(-53)/3 (x0lo is the
% correction; -1/2 and 0 are doubles).  dx = 0 exactly at the singular point
% only; -2/3 itself is not a double, so dx never vanishes in cases DT and ST
x0lo = 0;  if cas(2) == 'T', x0lo = -2^(-53)/3; end
dx = (xh-x0)+(xlo-x0lo);
z0c = z0n;  K0 = Aq-x0*eye(n);
% Whether kappa0 vanishes identically at x0 is structural, not numerical:
% it does in cases DU, SU, DT and ST for every phi and par0, and in case DK
% only with z0 = 0.  (A relative threshold on the computed q0 mistook a
% tiny but nonzero start, z0 = 1e-12 at n = 3, phi = 0, for z0 = 0: the
% smoothing term was dropped and the density at x0 followed the cutoff of
% the inner integral, 83.5 instead of 3.50.)  The coefficient of gam^2,
% bg'*K0*bg, does not depend on the start and vanishes in every case (it is
% that of z0 = 0); it is set to zero, so that its rounding does not compete
% with the other two, which are proportional to z0 and to z0^2.
sing0 = ~strcmp(cas,'DK') || par0(1) == 0;
if sing0, q0 = [0 0 0]; else, q0 = [0, 2*z0c'*K0*bg, z0c'*K0*z0c]; end
f = zeros(size(xh));  err = f;
for i = 1:numel(xh)
    x = xh(i);
    if sing0 && dx(i) == 0
        f(i) = Inf;  err(i) = Inf;  continue
    end
    K = Aq-x*eye(n);
    z0 = z0n;                               % z at z_n = 0, gam = 0
    % kappa0(gam) = q(1) gam^2 + q(2) gam + q(3), formed as q0 - (x - x0) times
    % the coefficients of v, since K = K0 - (x - x0) I: where q0 vanishes
    % (identically in the singular configurations, nearly for a tiny start)
    % this avoids the relative error eps/|x - x0| of forming q from K
    q = q0 - dx(i)*[bg'*bg, 2*z0'*bg, z0'*z0];
    % kappa0 = q(1)[(gam - gc)^2 - dq]: the vertex form keeps kappa0 accurate,
    % relative to itself, near a (double) root, where the expanded quadratic
    % would lose all its digits; the roots and the vertex are waypoints
    if abs(q(1)) > 1e-14*max(abs(q))
        gc = -q(2)/(2*q(1));  dq = gc^2-q(3)/q(1);
        kfun = @(gam) q(1)*((gam-gc).^2-dq);
        wpo = gc;  if dq > 0, wpo = [gc-sqrt(dq) gc gc+sqrt(dq)]; end
    else
        kfun = @(gam) q(2)*gam+q(3);
        wpo = [];  if q(2) ~= 0, wpo = -q(3)/q(2); end
    end
    wpo = unique(sort([wpo 0]));  wpo = wpo(wpo > -14 & wpo < 14);
    [f(i),eo] = quadgk(@(gam) outer(gam,x,K,kfun),-14,14,'Waypoints',wpo,'AbsTol',tol/10,'RelTol',max(tol,1e-12),'MaxIntervalCount',2000);
    err(i) = eo;
end

    function y = outer(gam,x,K,kfun)
        y = zeros(size(gam));
        for k = 1:numel(gam)
            y(k) = exp(-gam(k)^2/2)/sqrt(2*pi)*inner(gam(k),x,K,kfun(gam(k)));
        end
    end

    function s = inner(gam,x,K,kap0)
        % sum over the two sides z_n > 0 and z_n < 0 of the integral in
        % sigma = log|z_n| (dtau/|z_n| = dsigma/nr).  With z = zc + db*beta
        % (beta = z_n), Q - x v and v are quadratics in beta whose
        % coefficients are formed once: evaluating Q - x v from z at tiny
        % beta would add rounding noise of relative size eps/|beta| to w*
        zc = z0n+bg*gam;  db = bt/nr;
        kc = [db'*K*db, 2*zc'*K*db, kap0];          % Q - x v = polyval(kc,beta)
        vc = [db'*db, 2*zc'*db, zc'*zc];            % v = polyval(vc,beta)
        hi = log(nr*(abs(tau0)+14));
        lo = max(log(abs(kap0))-12,-740);  lo = min(lo,hi-1);
        wpi = log(abs(kap0));  wpi = wpi(wpi > lo & wpi < hi);
        s = 0;
        for sgn = [-1 1]
            s = s+quadgk(@(sig) g(sig,sgn,gam,kc,vc),lo,hi,'Waypoints',wpi,'AbsTol',tol/1000,'RelTol',max(tol/100,1e-14),'MaxIntervalCount',2000);
        end
    end

    function y = g(sig,sgn,gam,kc,vc)
        beta = sgn*exp(sig);                 % z_n
        tau = tau0+beta/nr;
        ws = -(kc(3)./beta+kc(2)+kc(1)*beta); % w* = -(Q - x v)/z_n
        v = (vc(1)*beta+vc(2)).*beta+vc(3);
        mw = muw+ct*tau+cg*gam;
        y = exp(-tau.^2/2)/sqrt(2*pi).*v.*exp(-(ws-mw).^2/(2*sw^2))/(sqrt(2*pi)*sw)/nr;
        y(~isfinite(y)) = 0;
    end
end
