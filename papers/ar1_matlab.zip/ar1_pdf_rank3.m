function [f,err] = ar1_pdf_rank3(xh,n,phi,cas,par0)
%AR1_PDF_RANK3  Density of phihat when the residualized lags have three
%   random dimensions; used by AR1_PDF for n = 4 in case DK with z0 ~= 0.
%
%   [f,err] = AR1_PDF_RANK3(xh,n,phi,cas,par0) returns the density of phihat
%   at the values xh of phihat itself, with an error estimate.  The
%   arguments are assumed checked.
%
%   Why.  At n = 4 in case DK with z0 ~= 0 the integrand of the inversion
%   formula decays only like t^(-2) and oscillates (the linear term from the
%   fixed start has a component off the range of the quadratic part), so the
%   inversion takes about ten seconds per value and reaches only about 1e-8.
%   (In the other cases with n = 4, and in cases DT and ST with n = 5, the
%   inversion is fast and accurate.)
%
%   Method.  As in AR1_PDF_RANK2: with z the lags y_0..y_{n-1} (no
%   regressors in case DK), v = z'z, and the last observation integrated
%   out,
%       f(x) = E[ v p(w*|z) / |z_n| ],   w* = -(Q(z) - x v)/z_n,
%   Q(z) = sum_{t=1}^{n-1} z_t z_{t+1}, w = y_n.  Here z has three random
%   dimensions, z = mu_z + b_tau tau + B_gam (gam_1, gam_2)', so f is a
%   three-dimensional Gaussian integral.  The innermost integral, over tau,
%   is taken in sigma = log|z_n| by a fixed Gauss-Legendre rule (10 points
%   on 41 panels on each side of z_n = 0, placed around log|kappa0|,
%   kappa0 = Q - x v at z_n = 0, below the upper end, and geometrically in
%   between).  The integrals over gam_2 and gam_1 have logarithmic
%   singularities, at the roots in gam_2 of the quadratic kappa0 and at the
%   gam_1 where the two roots merge; they are taken by a fixed hybrid rule:
%   tanh-sinh quadrature (step 1/8) on the panels that end at such a point
%   (and at the vertex of kappa0), 8-point Gauss-Legendre on a fixed grid
%   elsewhere, the grid points within distance 1 of a singular point being
%   dropped so that every Gauss-Legendre panel is well separated from the
%   singularities.  All the gam_2 nodes for one gam_1 are evaluated at once.
%   The error estimate is the difference from the same computation with
%   tanh-sinh step 1/4 (a subset of the nodes), squared and divided by the
%   value (tanh-sinh converges double-exponentially), plus 1e-11 times the
%   value.  Against a reference computed with step 1/16 (which agrees with
%   a fully adaptive evaluation to 3e-13) the error is below 2e-12; about
%   0.6 s per value.
%
%   See also AR1_PDF, AR1_PDF_RANK2.
mu = zeros(n+1,1);  L = zeros(n+1,n);       % y = mu + L*e, y = (y_0..y_n)'
if cas(1) == 'S', error('ar1:rank3','ar1_pdf_rank3: fixed-start cases only.'); end
alpha = 0;  delta = 0;  y0 = 0;
switch cas
    case 'DK', y0 = par0(1);
    case 'DU', alpha = par0(1);
    case 'DT'
        gm = par0(1);  gt = 0;  if numel(par0) > 1, gt = par0(2); end
        delta = gt;  alpha = gm-delta*(n+1)/2;
end
mu(1) = y0;
for t = 1:n
    mu(t+1) = alpha+delta*t+phi*mu(t);
    L(t+1,:) = phi*L(t,:);  L(t+1,t) = L(t+1,t)+1;
end
S = [eye(n) zeros(n,1)];
switch cas(2)
    case 'K', X = zeros(n,0); xn1 = zeros(1,0);
    case 'U', X = ones(n,1);  xn1 = 1;
    otherwise, X = [ones(n,1) (1:n)']; xn1 = [1 n+1];
end
if isempty(X), B = zeros(0,n); else, B = (X'*X)\X'; end
Mz = eye(n)-X*B;
Gz = Mz*S*L;  muz = Mz*S*mu;
gw = (L(n+1,:)-xn1*B*S*L)';  muw = mu(n+1)-xn1*B*S*mu;
[U,Sg,V] = svd(Gz,'econ');  sg = diag(Sg);
if sum(sg > 1e-10*sg(1)) ~= 3
    error('ar1:rank3','ar1_pdf_rank3: the residualized lags do not have three random dimensions.');
end
Bz = U(:,1:3)*Sg(1:3,1:3);  V3 = V(:,1:3);
cw = (gw'*V3)';  sw = sqrt(max(gw'*gw-cw'*cw,0));   % w | eta ~ N(muw + cw'eta, sw^2)
r = Bz(n,:)';  nr = norm(r);  e1 = r/nr;  E = null(e1');
bt = Bz*e1;  Bg0 = Bz*E;  ct = cw'*e1;  cg0 = E'*cw;
tau0 = -muz(n)/nr;  z0 = muz+bt*tau0;  db = bt/nr;
z0(n) = 0;  Bg0(n,:) = 0;                  % z_n = 0 exactly on the gam plane
hi = log(nr*(abs(tau0)+14));
Aq = diag(ones(n-1,1),1);  Aq = (Aq+Aq')/2;
% fixed rules
[xg10,wg10] = gauleg(10);  [xg8,wg8] = gauleg(8);
tts = -3:1/8:3;  uts = pi/2*sinh(tts);
xts = tanh(uts);  wts = (1/8)*pi/2*cosh(tts)./cosh(uts).^2;
wtsc = 2*wts.*(mod(round(8*tts),2) == 0);   % step 1/4: every other node
grid0 = [-9 -6.5 -4.5 -3 -2 -1 0 1 2 3 4.5 6.5 9];
tr = [-10 -7 -5 -3.5 -2.5 -1.5 -0.75 0 0.75 1.5 2.5 4 6];
tp = [0 0.4 0.8 1.2 1.6 2.2 3 4 5.5 7.5 10];
f = zeros(size(xh));  err = f;
for i = 1:numel(xh)
    x = xh(i);  K = Aq-x*eye(n);
    A = Bg0'*K*Bg0;  b = Bg0'*K*z0;  c = z0'*K*z0;   % kappa0 = gam'A gam + 2b'gam + c
    [W,lam] = eig((A+A')/2);  [~,j] = max(abs(diag(lam)));  W = W(:,[3-j j]);
    A = W'*A*W;  b = W'*b;  Bg = Bg0*W;  cg = W'*cg0;
    k1c = 2*(K*db);  k2 = db'*K*db;  v2 = db'*db;
    dc = [A(1,2)^2-A(2,2)*A(1,1), 2*(A(1,2)*b(2)-A(2,2)*b(1)), b(2)^2-A(2,2)*c];
    rt = roots(dc);  rt = real(rt(abs(imag(rt)) <= 1e-9*max(1,abs(rt))))';
    [X1,W1,W1c] = hyrule(rt);
    I = 0;  Ic = 0;
    for k = 1:numel(X1)
        g1 = X1(k);
        a2 = A(2,2);  a1 = 2*(A(1,2)*g1+b(2));  a0 = (A(1,1)*g1+2*b(1))*g1+c;
        [kf,sp] = vertex(a2,a1,a0);
        [X2,W2,W2c] = hyrule(sp);
        G = [g1+0*X2; X2];  zc = z0+Bg*G;
        s = tauint(kf(X2),k1c'*zc,sum(zc.^2,1),2*db'*zc,muw+ct*tau0+cg'*G).*exp(-X2.^2/2)/sqrt(2*pi);
        wg1 = exp(-g1^2/2)/sqrt(2*pi);
        I = I+W1(k)*wg1*(W2*s');  Ic = Ic+W1c(k)*wg1*(W2c*s');
    end
    f(i) = I;  err(i) = (I-Ic)^2/max(abs(I),realmin)+1e-11*abs(I);
end

    function [X,Wt,Wc] = hyrule(sing)
        % tanh-sinh on panels that end at a singular point, Gauss-Legendre
        % (8 points) on the others; grid points within 1 of a singular point
        % are dropped.  Wc: the same with tanh-sinh step 1/4.
        sing = sing(sing > -9 & sing < 9);
        g = grid0;
        if ~isempty(sing)
            keep = abs(g) == 9 | min(abs(g'-sing),[],2)' >= 1;  g = g(keep);
        end
        br = unique([g sing]);
        X = [];  Wt = [];  Wc = [];
        for p = 1:numel(br)-1
            a = br(p);  bb = br(p+1);  if bb-a < 1e-15, continue, end
            if any(abs(a-sing) < 1e-15) || any(abs(bb-sing) < 1e-15)
                X = [X (a+bb)/2+(bb-a)/2*xts];  Wt = [Wt (bb-a)/2*wts];  Wc = [Wc (bb-a)/2*wtsc]; %#ok<AGROW>
            else
                X = [X (a+bb)/2+(bb-a)/2*xg8];  Wt = [Wt (bb-a)/2*wg8];  Wc = [Wc (bb-a)/2*wg8]; %#ok<AGROW>
            end
        end
    end

    function s = tauint(kap0,k1,v0,v1,mw0)
        N = numel(kap0);
        cc = max(log(abs(kap0(:))),-730);  aa = min(cc-10,hi-1);
        TR = cc+tr;  lof = min(TR(:,end),hi);  hif = max(hi-tp(end),aa);
        Lf = max(hif-lof,0);  w = (Lf/2).*2.^(-7:0);
        br = [aa, hi+0*aa, TR, repmat(hi-tp,N,1), lof+w, hif-w];
        br = sort(min(max(br,aa),hi),2);    % N x 42; duplicates give empty panels
        np = size(br,2)-1;
        lft = br(:,1:end-1);  wid = br(:,2:end)-lft;
        sig = reshape(lft,N,np,1)+reshape(wid,N,np,1).*reshape((xg10+1)/2,1,1,10);
        wq = reshape(wid,N,np,1).*reshape(wg10/2,1,1,10);
        sig = reshape(sig,N,[]);  wq = reshape(wq,N,[]);
        s = zeros(1,N);
        for sgn = [-1 1]
            beta = sgn*exp(sig);
            tau = tau0+beta/nr;
            ws = -(kap0(:)./beta+k1(:)+k2*beta);
            v = v0(:)+v1(:).*beta+v2*beta.^2;
            mw = mw0(:)+ct*beta/nr;
            yy = exp(-tau.^2/2)/sqrt(2*pi).*v.*exp(-(ws-mw).^2/(2*sw^2))/(sqrt(2*pi)*sw)/nr;
            yy(~isfinite(yy)) = 0;
            s = s+sum(wq.*yy,2)';
        end
    end
end

function [kf,sp] = vertex(a2,a1,a0)
% kappa0(g) = a2 g^2 + a1 g + a0 in vertex form a2[(g - gc)^2 - dq];
% singular points: the vertex and the real roots
if abs(a2) > 1e-14*max(abs([a2 a1 a0]))
    gc = -a1/(2*a2);  dq = gc^2-a0/a2;
    kf = @(g) a2*((g-gc).^2-dq);
    sp = gc;  if dq > 0, sp = [gc-sqrt(dq) gc gc+sqrt(dq)]; end
else
    kf = @(g) a1*g+a0;
    sp = [];  if a1 ~= 0, sp = -a0/a1; end
end
end

function [x,w] = gauleg(m)
bb = (1:m-1)./sqrt(4*(1:m-1).^2-1);
[Vv,D] = eig(diag(bb,1)+diag(bb,-1));
x = diag(D)';  [x,ix] = sort(x);  w = 2*Vv(1,ix).^2;
end
