function c = ar1_scaled_check(phi,cas)
%AR1_SCALED_CHECK  Checks the arguments of the scaled form (centered = 'scaled'
%   in AR1_CDF, AR1_PDF and AR1_ICDF) and returns c = phi^2 - 1, so that
%   X_n = |phi|^n (phihat - phi)/(phi^2 - 1) = ut/vt / c with
%   ut/vt = |phi|^n (phihat - phi) (AR1_LOGCF_EXPS).
if ~(abs(phi) > 1 && any(strcmp(cas,{'DK','DU','DT'})))
    error('ar1:scaled','centered = ''scaled'' (x = |phi|^n (phihat - phi)/(phi^2 - 1)) requires |phi| > 1 and a fixed start (cases DK, DU and DT).');
end
c = phi^2-1;
end
