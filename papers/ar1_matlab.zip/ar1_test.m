function nfail = ar1_test(quick,strict)
%AR1_TEST  Validation suite for the AR(1) exact distribution programs.
%
%   nfail = AR1_TEST runs the checks below, prints each comparison with its
%   tolerance and a PASS/FAIL mark, and returns the number of failures.
%   AR1_TEST(true) skips the slower parts (Monte Carlo, the largest sample
%   sizes).  AR1_TEST(quick,true) raises an error at the end when a check
%   has failed, for use in scripts (a nonzero exit status in batch mode).
%
%    1. the closed-form O(1) characteristic function against a dense O(n^3)
%       evaluation for the four cases, including unit-root, negative and
%       explosive phi, with its first derivative;
%    2. the continuity of the assembled phase along the inversion paths
%       against the dense (eigenvalue) evaluation;
%    3. the jets against matrix identities (first and higher derivatives), in
%       both confluent regimes (x near +1 and near -1) and the roots regime;
%    4. cdf/pdf consistency, total mass, monotonicity and quantile inversion;
%    5. exact moments against Monte Carlo (slow);
%    6. the limiting distributions: known constants, the closed form at
%       x = -c against the inversion with the asymptotic tail, the finite-
%       sample characteristic function at large n, limits for large positive c;
%    7. the flatness of the cost in n;
%    8. the explosive region: the cancellation-free assembly against the
%       generic one, the dense evaluation, Monte Carlo and the Cauchy-type limit;
%    9. regressions: the zero-base power (jpow with a vanishing constant
%       term; ar1_mom at phi = 0), the sign symmetry phi -> -phi (both unit-root
%       neighborhoods), normalization at very large n (n = 1e8), conjugacy,
%       the scale of the moment tolerance at n = 1e6, ar1explim at large
%       noncentrality and at +-Inf, and the argument validation;
%   10. ray, drift and moment checks: the closed form at the ray
%       for large noncentrality (kappa = 200, 1000; 60-digit references), its
%       continuity and error estimate, the stationary ray at c = -1e-12, the
%       rescaling invariance of jpow, the singular density at n = 3, 4 and
%       the density there by integrating out the last observation, the
%       normalization log phi(0,0) with a drift (the cancellation of order
%       n^2 gamma^2 eps) and its appearance in the error estimates, and the
%       closed-form second and fourth moments of case DK at phi = z0 = 0;
%   11. the trend cases DT and ST: the closed form against the dense
%       evaluation (unit root, phi = -1, explosive), the explosive forms
%       against the high-precision reference, the invariance to the drift
%       (effective start), cdf/pdf/quantile consistency, moments against
%       Monte Carlo, the limit against Nabeya and Tanaka's Model 4 and against
%       the finite-sample cf at large n, the closed form at x = -c, and the
%       explosive limit at the effective start;
%   12. large t1 near the zeros -cos(k pi/n) of U_m and the rank drops of
%       u - r v (November 2026): the characteristic function against the
%       dense evaluation for all six cases (explosive DU and DT included),
%       the density there finite and continuous, the assemblies about the
%       core of size m-1 against the main ones, and moments in case ST.
%
%   The tolerances are those the paper claims: a few units of rounding for
%   the characteristic function away from the unit root, n eps near it, and
%   the requested quadrature tolerance (plus the reported error estimate)
%   for the distributions.
if nargin < 1 || isempty(quick), quick = false; end
if nargin < 2 || isempty(strict), strict = false; end
% Preserve generator type and state, including on failure.
rng_before = rng; rng_cleanup = onCleanup(@() rng(rng_before)); %#ok<NASGU>
nfail = 0; ntest = 0;
ws = warning('off','ratio:accuracy'); cl = onCleanup(@() warning(ws)); %#ok<NASGU>

fprintf('\n=== 1. closed-form vs dense characteristic function (n = 11) ===\n');
cfg = {{'DK',0.5,0.7},{'DK',1.0,1.5},{'DK',1.2,0.3},{'DK',-0.8,0.5},{'DU',0.9,0.0},{'DU',1.0,0.8},{'DU',1.05,-0.4},{'DU',-1,0.3},{'SK',0.95,[]},{'SK',-0.5,[]},{'SU',0.99,[]},{'SU',-0.95,[]}};
n = 11;
for ic = 1:numel(cfg)
    c = cfg{ic};
    s = [0.01 0.3 1.5 4 9 0.2]; t = [0.5 -0.4 2 -3 1 0];
    ref = cf_dense(s,t,n,c{2},c{1},c{3});
    got = exp(ar1_logcf(s,t,n,c{2},c{1},c{3}));
    e = max(abs(got-ref)./abs(ref));
    Lj  = ar1_logcf(s,[t;ones(size(t))],n,c{2},c{1},c{3});
    h = 1e-5;
    dref = (log(cf_dense(s,t+h,n,c{2},c{1},c{3}))-log(cf_dense(s,t-h,n,c{2},c{1},c{3})))/(2*h);
    ed = max(abs(Lj(2,:)-dref)./abs(dref));
    check(sprintf('%s phi=%5.2f par0=%s: cf vs dense (rel)',c{1},c{2},mat2str(c{3})),e,1e-12);
    check('   d/dt vs finite difference of dense (rel)',ed,1e-7);
end

fprintf('\n=== 2. phase continuity along the inversion paths vs dense (n = 60) ===\n');
n = 60; svec = logspace(-5,3,1500);
cfg2 = {{'DK',1.0,0.0},{'DK',1.1,0.5},{'DK',-1,0.3},{'DU',1.0,1},{'DU',-0.97,0.5},{'SU',0.999,[]},{'SK',-0.9,[]}};
for ic = 1:numel(cfg2)
    c = cfg2{ic}; phi = c{2}; worst = 0;
    if abs(phi) > 1, xs = [-1 0.02 1]*phi^(-n/2); else xs = [-3 -0.05 0.5]/n*5; end
    for x = xs
        t = -x*svec;
        got = exp(ar1_logcf(svec,t,n,phi,c{1},c{3}));
        ref = cf_dense(svec,t,n,phi,c{1},c{3});
        worst = max(worst,max(abs(got-ref)));
    end
    check(sprintf('%s phi=%6.3f: |cf - dense| along three paths',c{1},phi),worst,1e-12);
end

fprintf('\n=== 3. jets vs matrix identities, all regimes ===\n');
% d^k/dp^k of the primitives of D^{-1}: (-1)^k k! times the primitives of D^{-(k+1)}
% (at phi = -1 the dense reference is ill conditioned for 1'D^{-k}1 beyond
% m = 25, so the branch x near +1 is checked below through the exact
% symmetry phi -> -phi, s -> -s of the assembled jets, whose other side is
% the branch x near -1 validated here)
cases = {[0.5,0.3,-0.2,12];[1.0,1e-4,-1e-5,80];[1.0,0,0,200];[-1,0,0,25];[-1,1e-4,1e-5,25];[1.3,2,-0.5,40];[0.9999,1e-6,1e-6,400];[1.0,0.02,-0.01,30]};
for ic = 1:numel(cases)
    v = cases{ic}; phi=v(1); s=v(2); t=v(3); m=v(4); K = 3;
    P = zeros(K+1,1); Q = zeros(K+1,1); P2 = zeros(K+1,1); PM2 = zeros(K+1,1);
    P(1) = 1+phi^2+2i*(phi*s-t); P(2) = -2i; Q(1) = -(phi+1i*s);
    P2(1) = (1-phi)^2 + 2i*((phi-1)*s - t); P2(2) = -2i;
    PM2(1) = (1+phi)^2 + 2i*((phi+1)*s - t); PM2(2) = -2i;
    [d1,d2,d3,d4,lgi,info] = ttprimsj(P,Q,P2,m,[],PM2);
    D = P(1)*eye(m) + Q(1)*(diag(ones(m-1,1),1)+diag(ones(m-1,1),-1));
    Di = inv(D); one = ones(m,1); worst = 0;
    Dk = Di;
    for k = 1:K
        Dk = Dk*Di;                            % D^{-(k+1)}
        ex = [one'*Dk*one, Dk(1,:)*one, Dk(1,1), Dk(1,m)]*(2i)^k;   % coefficient k of the jet in x: (D0 - 2ix I)^{-1} = sum (2ix)^k D0^{-(k+1)}
        got = [d1(k+1) d2(k+1) d3(k+1) d4(k+1)];
        worst = max(worst,max(abs(got-ex)./abs(ex)));
    end
    lg = -sum(log(eig(D)));
    check(sprintf('phi=%7.4f s=%g m=%4d regime %2d: jets of orders 1-3 (rel)',phi,s,m,info.regime),worst,1e-9);
    check('   log|D|^{-1} vs eigenvalues (real part, rel; the reference is eig)',abs(real(lgi(1))-real(lg))/abs(real(lg)),1e-10);
end
for v = {[1,1e-4,-1e-5,151],[0.9999,1e-6,-1e-6,401],[1,0,0,1001]}
    phi = v{1}(1); s = v{1}(2); t = v{1}(3); n = v{1}(4);
    sj = [s;1;0.3;0]; tj = [t;-0.4;0.1;0];
    L1 = ar1_logcf(sj,tj,n,phi,'DK',0.4); L2 = ar1_logcf(-sj,tj,n,-phi,'DK',0.4);
    check(sprintf('phi=%g vs -phi, n=%d: order-3 jets of log cf agree (both confluent branches)',phi,n),max(abs(L1-L2)./(1+abs(L1))),1e-12);
end

fprintf('\n=== 4. cdf/pdf consistency, mass, monotonicity, quantiles ===\n');
cfg4 = {{'DU',1.0,0.0,50},{'DK',1.2,0.5,30},{'SU',0.99,[],200},{'SK',0.5,[],20},{'DK',-1,0.3,40}};
for ic = 1:numel(cfg4)
    c = cfg4{ic}; cas=c{1}; phi=c{2}; par0=c{3}; n=c{4};
    h = @(t1,t2) ar1_logcf(t1,t2,n,phi,cas,par0);
    [Eu,Ev,~,Vu] = ratio_scale(h); sd = sqrt(Vu)/Ev;
    xs = phi+Eu/Ev+sd*[-2 -0.5 1];
    [F,eF] = ar1_cdf(xs,n,phi,cas,par0); f = ar1_pdf(xs,n,phi,cas,par0);
    hh = 1e-4*sd; fd = (ar1_cdf(xs+hh,n,phi,cas,par0)-ar1_cdf(xs-hh,n,phi,cas,par0))/(2*hh);
    lo = ar1_icdf(1e-10,n,phi,cas,par0); hi = ar1_icdf(1-1e-10,n,phi,cas,par0);
    mass = quadgk(@(x) ar1_pdf(x,n,phi,cas,par0),lo,hi,'AbsTol',1e-9,'RelTol',1e-8);
    q = ar1_icdf(F,n,phi,cas,par0);
    grid = phi+Eu/Ev+sd*linspace(-3,3,13); Fg = ar1_cdf(grid,n,phi,cas,par0);
    fprintf('  %s n=%d phi=%g (error estimates %s)\n',cas,n,phi,mat2str(eF,2));
    check('   |f - dF/dx|/f',max(abs(f-fd)./f),1e-6);
    check('   |mass - 1|',abs(mass-1),1e-7);
    check('   |icdf(cdf(x)) - x|/sd',max(abs(q-xs))/sd,1e-8);
    check('   cdf monotone on a 13-point grid (min increment)',-min(diff(Fg)),0);
    check('   cdf within [0,1]',max([-Fg Fg-1]),0);
end

if ~quick
fprintf('\n=== 5. exact moments vs Monte Carlo (R = 200000) ===\n');
cfg5 = {{'DU',1.0,0.6,100},{'DK',0.5,1.0,30},{'SU',0.8,[],25},{'SK',0.95,[],60},{'DK',1.3,0.0,12}};
for ic = 1:numel(cfg5)
    c = cfg5{ic}; cas=c{1}; phi=c{2}; par0=c{3}; n=c{4};
    m = ar1_mom(2,n,phi,cas,par0);
    R = 200000; randn('seed',ic);
    e = randn(n,R);
    if cas(1)=='D', if cas(2)=='K', x0=par0*ones(1,R); a=0; else x0=zeros(1,R); a=par0; end
    else x0 = randn(1,R)/sqrt(1-phi^2); a=0; end
    X = zeros(n+1,R); X(1,:)=x0; for tt=1:n, X(tt+1,:) = a+phi*X(tt,:)+e(tt,:); end
    Xl = X(1:n,:); Xc = X(2:n+1,:); if cas(2)=='U', Xl = Xl-mean(Xl,1); end
    ph = sum(Xl.*Xc,1)./sum(Xl.^2,1);
    if abs(phi) <= 1
        se = std(ph)/sqrt(R);
        check(sprintf('%s n=%d phi=%g: |E[phihat] - MC|/se (exact %.6f, MC %.6f)',cas,n,phi,m(1),mean(ph)),abs(m(1)-mean(ph))/se,4);
        check(sprintf('   |E[phihat^2] - MC|/se (exact %.6f, MC %.6f)',m(2),mean(ph.^2)),abs(m(2)-mean(ph.^2))/(std(ph.^2)/sqrt(R)),4);
    else   % explosive: the normalized statistic, heavy-tailed
        g = abs(phi)^n/(phi^2-1); [mu,v,sk,ku] = ar1_cmom(n,phi,cas,par0); x = g*(ph-phi);
        check(sprintf('%s n=%d phi=%g: normalized mean, |exact - MC|/se (%.4f vs %.4f)',cas,n,phi,g*(mu-phi),mean(x)),abs(g*(mu-phi)-mean(x))/(std(x)/sqrt(R)),4);
        check(sprintf('   normalized sd, rel diff (%.4f vs %.4f)',g*sqrt(v),std(x)),abs(g*sqrt(v)/std(x)-1),0.02);
        check(sprintf('   skewness and excess kurtosis, rel diff (%.3f %.2f vs %.3f %.2f)',sk,ku,skewness_(x),kurtosis_(x)),max(abs(sk/skewness_(x)-1),abs(ku/kurtosis_(x)-1)),0.1);
    end
end
end

fprintf('\n=== 6. limiting distributions ===\n');
check('P[DF (no mean) < 0] vs 2Phi(1)-1 (closed form at x = -c)',abs(ar1lim_cdf(0,0,'DK',0)-erf(1/sqrt(2))),1e-14);
check('P[DF (demeaned) < 0] vs 0.95756559 (closed form)',abs(ar1lim_cdf(0,0,'DU',0)-0.95756559),5e-9);
% the inversion with the asymptotic tail against the closed form, next to the ray
for cc = {{'DK',0,0},{'DK',2,1.3},{'DU',0,0},{'DU',-3,0.8},{'DU',10,0.4},{'SK',-5,0},{'SU',-5,0}}
    c = cc{1}; cl = ar1lim_ray(c{2},c{1},c{3});
    [F,eF] = ar1lim_cdf(-c{2}+1e-9,c{2},c{1},c{3}); f = ar1lim_pdf(-c{2},c{2},c{1},c{3});
    check(sprintf('%s c=%g par=%g: inversion at x = -c+1e-9 vs closed form (%.10f), minus f*1e-9',c{1},c{2},c{3},cl),abs(F-f*1e-9-cl),1e-10+eF);
end
% density against the derivative of the cdf at and near the ray
for cc = {{'DU',0,0,0},{'DU',0,0,0.02},{'DK',0,0.7,0},{'SU',-2,0,2.01}}
    c = cc{1}; d = 1e-2; x = c{4};
    Fv = ar1lim_cdf(x+[-2 -1 1 2]*d,c{2},c{1},c{3},1e-12); fd = (-Fv(4)+8*Fv(3)-8*Fv(2)+Fv(1))/(12*d);
    [f,ef] = ar1lim_pdf(x,c{2},c{1},c{3});
    check(sprintf('%s c=%g par=%g: pdf at %g vs 4th-order difference of cdf',c{1},c{2},c{3},x),abs(f-fd),1e-8+ef);
end
check('E[DF (no mean)] vs -1.7814 (Evans-Savin)',abs(ar1lim_mom(1,0,'DK',0)+1.7814),1e-4);
check('E[DF (demeaned)] vs -5.3791',abs(ar1lim_mom(1,0,'DU',0)+5.3791),1e-4);
s = [0.3 1 2.5 6]; t = [0.5 -0.7 3 -4];
for cc = {{'DK',0,1.2},{'DU',2,-0.4},{'SK',-4,[]},{'SU',-0.2,[]},{'DK',12,0.3},{'DU',20,0}}
    c = cc{1}; n = 4000; if c{2} > 5, n = 100000; end
    phi = 1+c{2}/n;
    switch c{1}, case 'DK', par0 = sqrt(n)*c{3}; case 'DU', par0 = c{3}/sqrt(n); otherwise, par0 = 0; end
    if c{2} > 5, sc = exp(-2*c{2})*2*c{2}; else sc = 1; end
    e = max(abs(exp(ar1_logcf(s*sc/n,t*sc/n^2,n,phi,c{1},par0))-exp(ar1lim_logcf(s*sc,t*sc,c{2},c{1},c{3}))));
    check(sprintf('%s c=%g: |cf_n(n=%d) - cf_lim| (O(1/n))',c{1},c{2},n),e,20/n*(1+9*(c{2} > 5)));
end
check('ar1lim_logcf(0,0,c) = 0 for c = 30, 100, 300 (normalization at large c)', ...
      max(abs([ar1lim_logcf(0,0,30,'DK',0.5) ar1lim_logcf(0,0,100,'DU',0.5) ar1lim_logcf(0,0,300,'DK',0)])),1e-13);
% the explosive side: on the scale t1 = O(e^-c), t2 = O(e^-2c), vartheta - c and
% i t1 cancel to O(e^-2c) (references: the closed forms in 200-digit arithmetic)
R = {'DK', 20, 2.0611536224385579e-09, 1.6993417021166355e-17, -0.00668435406649397219, 0.0514360031164375829
     'DK',100, 3.7200759760208361e-44, 2.7677930534734749e-86, -0.00128671548308360727, 0.0494974884304790467
     'DU', 20, 2.0611536224385579e-09, 1.6993417021166355e-17, -0.000291828631652159605, -0.000139665321864292474
     'DU',100, 3.7200759760208361e-44, 2.7677930534734749e-86, -0.0000125207349278594954, 0.000394792155893962982};
err = 0;
for k = 1:size(R,1)
    L = ar1lim_logcf(R{k,3},R{k,4},R{k,2},R{k,1},0.7);
    err = max(err,abs(L-complex(R{k,5},R{k,6})));
end
check('DK, DU limits, c = 20, 100: log cf on the explosive scale vs 200-digit references',err,1e-13);
c = 10; L = ar1lim_logcf([0;1;0],[0;0;0],c,'DU',0.5);
check('E[A] of the demeaned limit at c = 10 vs closed form -[(e^c-1)/c-1]/c',abs(imag(L(2))+(expm1(c)/c-1)/c)/((expm1(c)/c-1)/c),1e-13);

fprintf('\n=== 7. cost against the sample size (cdf, one point) ===\n');
tm = zeros(1,3); ns = [100 10000 1000000];
for i = 1:3
    n = ns(i); tic; [F,eF] = ar1_cdf(1-8/n,n,1,'DU',0); tm(i) = toc;
    fprintf('  n = %8d: %.3f s, F = %.10f (error estimate %.1e)\n', n, tm(i), F, eF);
end
check('time(n=1e6)/time(n=100) (flat cost; the error estimate grows like n eps)',tm(3)/tm(1),4);

fprintf('\n=== 8. explosive region: cancellation-free assembly ===\n');
for c = {{'DK',1.2,0.5},{'DU',-1.2,0.4}}
    n = 25; phi = c{1}{2}; g = abs(phi)^n/(phi^2-1);
    s = logspace(-2,2,9)/g; t = s/g;
    ref = cf_dense(s,t,n,phi,c{1}{1},c{1}{3});
    gen = exp(ar1_logcf(s,t,n,phi,c{1}{1},c{1}{3},struct('exp',false)));
    rea = exp(ar1_logcf(s,t,n,phi,c{1}{1},c{1}{3}));
    check(sprintf('%s phi=%.1f n=%d (phi^2n=%.0e): |generic - dense|',c{1}{1},phi,n,phi^(2*n)),max(abs(gen-ref)),1e-9);
    check('   |rearranged - dense|',max(abs(rea-ref)),1e-12);
    n = 100; g = abs(phi)^n/(phi^2-1); s = logspace(-2,2,9)/g; t = s/g;
    gen = exp(ar1_logcf(s,t,n,phi,c{1}{1},c{1}{3},struct('exp',false)));
    rea = exp(ar1_logcf(s,t,n,phi,c{1}{1},c{1}{3}));
    fprintf('  %s phi=%.1f n=%d (phi^2n=%.0e): |generic - rearranged| %.1e (the generic assembly has lost all digits)\n', c{1}{1}, phi, n, phi^(2*n), max(abs(gen-rea)));
end
vf = fullfile(fileparts(which('ar1_logcf')),'validation','hp_ref_grid.txt');
if exist(vf,'file')
    addpath(fileparts(vf));
    wg = 0;  w = evalc('wg = check_grid(vf);'); %#ok<NASGU>
    check('|logcf - 250-digit reference| on the validation grid (phi^2n up to 2e211)',wg,5e-13);
end
% the scaled arguments (AR1_LOGCF_EXPS, centered = 'scaled'): against the 250-digit
% references, against AR1_LOGCF_EXP where both work, and beyond phi^{2n} = 1e300 against
% the limit, from which case DK differs by O(|phi|^-n) and cases DU and DT by O(1/n)
if exist(vf,'file')
    fid = fopen(vf,'r'); C = textscan(fid,'%s %f %f %f %f %f %f %f','CommentStyle','#'); fclose(fid);
    [grp,~,ig] = unique([C{2} C{3} strcmp(C{1},'DU')],'rows'); e = 0;
    for k = 1:size(grp,1)
        i = find(ig == k); ph = grp(k,1); nn = grp(k,2); cs = C{1}{i(1)};
        L = ar1_logcf_exps(C{5}(i).'*abs(ph)^nn,C{6}(i).'*ph^(2*nn),nn,ph,cs,C{4}(i(1)));
        rf = (C{7}(i)+1i*C{8}(i)).'; d = abs(L-rf);
        e = max(e,max(max(d./max(1,abs(rf))),max([0 d(real(rf) > -40)])));
    end
    check('ar1_logcf_exps (scaled arguments) vs the 250-digit reference (DK, DU)',e,5e-13);
end
fn = fullfile(fileparts(which('ar1_logcf')),'validation','hp_trend_ref.txt');
if exist(fn,'file')
    R = dlmread(fn); R = R(abs(R(:,1)) > 1 & R(:,1).^(2*R(:,2)) > 100,:); cfg = unique(R(:,1:4),'rows'); e = 0;
    for k = 1:size(cfg,1)
        I = all(R(:,1:4) == cfg(k,:),2); ph = cfg(k,1); nn = cfg(k,2);
        L = ar1_logcf_exps(R(I,5).'*abs(ph)^nn,R(I,6).'*ph^(2*nn),nn,ph,'DT',cfg(k,3:4));
        e = max(e,max(abs(real(L).'-R(I,7))./max(1,abs(R(I,7)))));
        c2 = exp(2*L).'; r2 = R(I,8)+1i*R(I,9); ok = abs(r2) > 1e-290;
        e = max(e,max(abs(c2(ok)-r2(ok))./abs(r2(ok))));
    end
    check('ar1_logcf_exps, DT, |phi| > 1: log|cf| and cf^2 vs the high-precision reference',e,1e-10);
end
e = 0;
for cc = {{'DK',0.7},{'DU',0.5},{'DT',[0.3 0.2]}}
    for phi = [1.2 -1.3 1.01]
        for lg = [50 250]
            n = ceil(lg/(2*log10(abs(phi)))); se = abs(phi)^(-n); tau = [0.01 0.3 1 3 10];
            a = [tau; ones(1,5)]; b = [-0.5*(phi^2-1)*tau; -0.5*(phi^2-1)*ones(1,5)];
            Ls = ar1_logcf_exps(a,b,n,phi,cc{1}{1},cc{1}{2}); Le = ar1_logcf_exp(se*a,se^2*b,n,phi,cc{1}{1},cc{1}{2});
            e = max(e,max(abs(Ls(:)-Le(:))./max(1,abs(Le(:)))));
        end
    end
end
check('ar1_logcf_exps vs ar1_logcf_exp (values and first derivatives), phi^{2n} = 1e50 and 1e250',e,1e-10);
X = [-3 -1 -0.2 0 0.5 2];
[fl,Fl] = ar1explim(X,1.2,1); [F,eF] = ar1_cdf(X,50000,1.2,'DK',1,[],'scaled'); f = ar1_pdf(X,50000,1.2,'DK',1,[],'scaled');
check('DK phi=1.2, z0=1, n=50000 (phi^{2n} = 1e7918): scaled cdf and pdf = the limit (O(|phi|^-n))',max(abs([F-Fl f-fl])),1e-12);
xq = ar1_icdf([0.05 0.5 0.9],50000,1.2,'DK',1,[],'scaled');
check('   scaled quantiles: cdf at them',max(abs(ar1_cdf(xq,50000,1.2,'DK',1,[],'scaled')-[0.05 0.5 0.9])),1e-9);
[~,Fl] = ar1explim(X,-1.1,0);
d = zeros(1,2); nn = [5e4 5e6];
for k = 1:2, d(k) = nn(k)*max(abs(ar1_cdf(X,nn(k),-1.1,'DU',0,[],'scaled')-Fl)); end
check(sprintf('DU phi=-1.1, n=5e4 and 5e6: n|F_n - F_lim| = %.4f, %.4f (the O(1/n) approach)',d),abs(d(1)-d(2)),1e-3);
F1 = ar1_cdf(X,1600,1.05,'DT',[0.1 0],[],'scaled'); F2 = ar1_cdf(X*(1.05^2-1)/1.05^1600,1600,1.05,'DT',[0.1 0],[],true);
f1 = ar1_pdf(X,1600,1.05,'DT',[0.1 0],[],'scaled'); f2 = ar1_pdf(X*(1.05^2-1)/1.05^1600,1600,1.05,'DT',[0.1 0],[],true)*(1.05^2-1)/1.05^1600;
check('DT phi=1.05, n=1600: scaled vs centered route, cdf and pdf',max(abs([F1-F2 f1-f2])),1e-11);
phi = 1.2; n = 100; g = phi^n/(phi^2-1);
xg = [-3 -1 0 1 3];
F = ar1_cdf(xg/g,n,phi,'DK',0,[],true);
[~,Fl] = ar1explim(xg,phi,0);
if ~quick
    R = 200000; y = zeros(1,R); v = zeros(1,R); u = zeros(1,R); randn('seed',7);
    for tt = 1:n, e = randn(1,R); u = u + y.*e; v = v + y.^2; y = phi*y + e; end
    Fmc = arrayfun(@(x) mean(u./v < x/g), xg);
    check(sprintf('cdf of g(phihat-phi), phi=1.2, n=100: max |exact - MC| (R=%d), se ~ 1e-3',R),max(abs(F-Fmc)),4e-3);
end
check('   max |exact - Cauchy limit| (O(phi^{-n}))',max(abs(F-Fl)),1e-4);
g = phi^400/(phi^2-1); [F,eF] = ar1_cdf(xg/g,400,phi,'DK',0,[],true);
check(sprintf('n=400 (phi^2n = %.0e): |exact - limit| at 5 points (error estimates %s)',phi^800,mat2str(eF,1)),max(abs(F-Fl)),1e-8);
[Eu,Ev,sdv] = ratio_scale(@(t1,t2) ar1_logcf(t1,t2,600,1.5,'DK',0.5));
check('phi=1.5, n=600: Var v overflows (sdv = Inf is reported, not 0)',double(~isinf(sdv)),0);
F = ar1_cdf([-1 0 1]*(1.5^2-1)/1.5^600,600,1.5,'DK',0.5,[],true); [~,Fl] = ar1explim([-1 0 1],1.5,0.5);
check('   cdf still evaluated (scaled by Var u alone), vs limit',max(abs(F-Fl)),1e-8);

fprintf('\n=== 9. regressions ===\n');
a = zeros(21,1); a(2) = 1; b = jpow(a,13);
check('jpow: x^13 through degree 20 (coefficient 13 = 1, others 0)',max(abs(b-[zeros(13,1);1;zeros(7,1)])),0);
a = zeros(5,3); a(1,:) = [0 1e-20 2]; a(2,:) = 1; a(3,:) = 0.5; b = jpow(a,15); bb = jpow(a,3);
check('jpow: zero and tiny constant terms, m = 15 (finite, no NaN)',double(~all(isfinite(b(:)))),0);
check('jpow: m = 3 by multiplication vs log-exp route agree (jm(jm(a,a),a))',max(abs(bb(:)-reshape(jm(jm(a,a),a),[],1))),1e-14);
% explosive region far beyond phi^n = 1e15: the second scale of the moment integrand
% (s2 of order one, u = log E[v]) lies beyond the first by 2 n log phi; phi^n E(phihat-phi)^2
% grows like n^(1/2) (the Cauchy limit has no second moment)
g = zeros(1,3); nn3 = [200 400 600]; lastwarn('');
for i = 1:3, m = ar1_mom(2,nn3(i),1.2,'DK',0,1.2); g(i) = 1.2^nn3(i)*m(2)/sqrt(nn3(i)); end
check(sprintf('phi=1.2, DK, n=200,400,600: phi^n E(phihat-phi)^2/sqrt(n) = %s (smooth in n)',mat2str(g,4)),max(abs(g(2:3)/g(1)-1)),0.05);
check('   no accuracy warning',double(~isempty(lastwarn)),0);
% the range of double precision for the moments (Section 4.3): all four orders up to phi^(2n)
% of about 1e300 (RATIO_MOM rescales the jet variable at the second scale of its integrand and
% normalizes each order by its peak), where the moments scale like sqrt(n) |phi|^(-n); beyond it
% AR1_MOM returns NaN with warning ar1:range
ws = warning('off','ar1:range'); lastwarn('');
m1 = ar1_mom(4,900,1.2,'DK',1.2,1.2); m2 = ar1_mom(4,1800,1.2,'DK',1.2,1.2);
m3 = ar1_mom(4,1958,1.2,'DK',1.2,1.2); [~,wid] = lastwarn;
[mu,v,sk,ku] = ar1_cmom(2000,1.2,'DK',1.2); warning(ws);
g = log10(abs(m1))+900*log10(1.2)-0.5*log10(900)-(log10(abs(m2))+1800*log10(1.2)-0.5*log10(1800));
check('phi=1.2, DK, n=900 (1e142) and 1800 (1e285): orders 1-4 scale like sqrt(n)|phi|^(-n)',max(abs(g)),0.1);
check('   n=1958 (1e310): NaN with warning ar1:range',double(~(all(isnan(m3)) && strcmp(wid,'ar1:range'))),0);
check('   ar1_cmom at 1e317 (beyond 1e300): all NaN, no error',double(~all(isnan([mu v sk ku]))),0);
[~,v1,s1,k1] = ar1_cmom(1600,-1.1,'DU',0); [~,v2,s2,k2] = ar1_cmom(3600,-1.1,'DU',0);
r = [s1*1600^0.25/1.1^800 s2*3600^0.25/1.1^1800 k1*sqrt(1600)/1.1^1600 k2*sqrt(3600)/1.1^3600];
check(sprintf('DU phi=-1.1, n=1600 and 3600 (1e298): skewness/(n^(-1/4)|phi|^(n/2)) %.4f, %.4f, kurtosis/(n^(-1/2)|phi|^n) %.4f, %.4f',r),max(abs([r(2)/r(1) r(4)/r(3)]-1)),0.02);
[~,v,sk,ku,cm] = ar1_cmom(250,-1.15,'DT',[1 1]);
check('DT phi=-1.15, n=250, gamma = gamma_tau = 1 (the far end of the moment integrand): finite moments',double(~all(isfinite([v sk ku]))),0);
check('   first central moment / sd (the center E[phihat] - phi = -1e-22 kept on its own scale)',abs(cm(1))/sqrt(v),1e-9);
nerr = 0; try, ar1_mom(1+1i,20,0.5,'DK'); catch, nerr = nerr+1; end; try, ar1_mom(Inf,20,0.5,'DK',1); catch, nerr = nerr+1; end
check('ar1_mom: complex and infinite k rejected',2-nerr,0);
[mu,v,sk,ku] = ar1_cmom(5,0,'SK',0); [~,~,~,ku5] = ar1_cmom(5,0,'DU',0);
check(sprintf('ar1_cmom(5,0,''SK''): kurtosis exists (%.6f); DU at n = 5: NaN',ku),double(~(isfinite(ku) && isnan(ku5))),0);
m = ar1_mom(14,15,0,'DK',1);
check('ar1_mom(14,15,0,''DK'',1): m2 > 0 and m14 finite positive',double(~(m(2) > 0.05 && m(14) > 0 && isfinite(m(14)))),0);
% sign symmetry: alternating the signs of y maps (u,v,phi) -> (-u,v,-phi)
for nn = [1e4 1e6]
    s = 0.3/nn; t = -0.7/nn^2; phi = 1-1e-8;
    a1 = ar1_logcf(s,t,nn,phi,'DK',0); a2 = ar1_logcf(-s,t,nn,-phi,'DK',0);
    check(sprintf('phi -> -phi symmetry at n=%g, phi=1-1e-8 (rel)',nn),abs(a1-a2)/abs(a1),1e-12);
end
check('phi -> -phi symmetry of the cdf (n=30, phi=0.7)',abs(ar1_cdf(0.1,30,0.7,'DK',0,[],true)-(1-ar1_cdf(-0.1,30,-0.7,'DK',0,[],true))),1e-12);
check('phi -> -phi symmetry of the cdf (n=40, phi=1, DK, z0 = 0.5)',abs(ar1_cdf(-0.05,40,1,'DK',0.5,[],true)-(1-ar1_cdf(0.05,40,-1,'DK',-0.5,[],true))),1e-10);
check('conjugacy phi(-s,-t) = conj phi(s,t) (n=50, phi=0.9, SU)',max(abs(ar1_logcf(-[0.2 3],-[0.1 -1],50,0.9,'SU')-conj(ar1_logcf([0.2 3],[0.1 -1],50,0.9,'SU')))),1e-14);
check('normalization ar1_logcf(0,0) at n = 1e8, phi = 1 (DU); noise n eps',abs(ar1_logcf(0,0,1e8,1,'DU',0)),1e-7);
check('normalization ar1_logcf(0,0) at n = 1e8, phi = -1 (DK); noise n eps',abs(ar1_logcf(0,0,1e8,-1,'DK',0.5)),1e-7);
Fl = ar1lim_cdf(-8,0,'DU',0);
[F6,e6] = ar1_cdf(-8/1e6,1e6,1,'DU',0,[],true); [F8,e8] = ar1_cdf(-8/1e8,1e8,1,'DU',0,[],true);
check(sprintf('cdf at n=1e6 vs limit: n|F_n - F_inf| (est. errors %.1e, %.1e)',e6,e8),1e6*abs(F6-Fl),2);
check('cdf at n=1e8 vs limit: n|F_n - F_inf| within the n eps noise',1e8*abs(F8-Fl),2+1e8*(e8+1e-9));
if ~quick
    n = 1e6; [m,em] = ar1_mom(4,n,1,'DU',0,1); ml = ar1lim_mom(4,0,'DU',0);
    check(sprintf('n=1e6 moments about 1, scaled by n^j, vs the limit (O(1/n); estimates %s)',mat2str(em.*n.^(1:4),1)),max(abs(m.*n.^(1:4)-ml)./abs(ml)),1e-4);
end
f = ar1explim(0,1.2,100); [f2,F2] = ar1explim([-Inf 0 Inf],1.2,1);
check('ar1explim(0,1.2,100) finite (combined exponents)',double(~isfinite(f)),0);
check('ar1explim at +-Inf: f = 0, F = 0 and 1',max(abs([f2(1) f2(3) F2(1) F2(3)-1])),0);
nerr = 0;
try, ar1_cdf(0.5,2,0.5,'DK'); catch, nerr = nerr+1; end
try, ar1_cdf(0.5,10,1.1,'SU'); catch, nerr = nerr+1; end
try, ar1_cdf(0.5,10,0.5,'XX'); catch, nerr = nerr+1; end
try, ar1_cdf(NaN,10,0.5,'DK'); catch, nerr = nerr+1; end
try, ar1_cdf(0.5,10.5,0.5,'DK'); catch, nerr = nerr+1; end
try, ar1lim_cdf(0,1,'SK'); catch, nerr = nerr+1; end
try, ar1lim_logcf(0,0,0,'FX'); catch, nerr = nerr+1; end
try, ratio_icdf(@(t1,t2) ar1_logcf(t1,t2,20,0.5,'DK'),1.5); catch, nerr = nerr+1; end
check('argument validation: 8 invalid calls raise errors',8-nerr,0);
% a tight tolerance at which QUADGK reaches its interval limit on [0,inf)
% (Octave returned a wrong value with a small error estimate): the
% decade-by-decade fallback of RATIO_CDF must agree with the default tolerance
phi = 1.175; n = 200; x = 0.5*(phi^2-1)/phi^n;
F1 = ar1_cdf(x,n,phi,'DU',0,[],true);
[F2,e2] = ar1_cdf(x,n,phi,'DU',0,1e-13,true);
check('DU, phi = 1.175, n = 200: cdf at tol 1e-13 vs default (and its error estimate)',max(abs(F2-F1),e2),1e-10);

fprintf('\n=== 10. the ray r = -c, the drift normalization and closed-form moments ===\n');
% the closed form at the ray for large noncentrality (the earlier folded-normal
% quadrature missed the mass near sqrt(mu_2)); references: mpmath, 60 digits
[P,eP] = ar1lim_cdf(0,0,'DU',200);
check('ar1lim_cdf(0,0,''DU'',200) vs 0.503454984681967663 (60-digit reference)',abs(P-0.503454984681967663),1e-12+eP);
check('   error estimate at the ray is positive (quadrature, not 1e-15 nominal)',double(~(eP > 0)),0);
check('ar1lim_cdf(0,0,''DU'',1000) vs 0.500690988644436976',abs(ar1lim_cdf(0,0,'DU',1000)-0.500690988644436976),1e-12);
F = ar1lim_cdf([-1e-9 0 1e-9],0,'DU',200);
check('   continuity across the ray, kappa = 200: F(-1e-9) <= F(0) <= F(1e-9), spread < 1e-7',max([F(1)-F(2) F(2)-F(3) F(3)-F(1)-1e-7]),0);
check('ar1lim_cdf(1e-12,-1e-12,''SK'') vs direct chi-square quadrature 0.5000034387616952',abs(ar1lim_cdf(1e-12,-1e-12,'SK')-0.5000034387616952),1e-11);
% jpow: exact leading-power factoring, invariance under rescaling of the jet variable
check('jpow([1;1e15],13) = [1;1.3e16] (constant term tiny relative to the slope)',max(abs(jpow([1;1e15],13)-[1;1.3e16])./[1;1.3e16]),1e-14);
randn('seed',7); a = randn(21,4).*10.^(3*randn(21,4)); a(1,2) = 1e-30; a(1:3,3) = 0; sc = 1e4; K = 20; m = 30;
b1 = jpow(a,m); b2 = jpow(a.*(sc.^(0:K)'),m)./(sc.^(0:K)');
check('jpow: rescaling invariance jpow(a(s x))(x) = jpow(a)(s x), K = 20, m = 30 (rel)',max(max(abs(b1-b2)./max(abs(b1),realmin))),1e-11);
% density: the rank condition fails only at n = 3 (DK with z0 = 0 at phihat = 0,
% DU and SU at phihat = -1/2) and at n = 4 (DT and ST at phihat = -2/3); the
% density is infinite there and finite elsewhere
lastwarn(''); f3 = ar1_pdf([0 1e-3],3,0,'DK',0);
check('ar1_pdf at n = 3, DK, z0 = 0: f(0) = Inf, f(1e-3) finite',double(~(isinf(f3(1)) && isfinite(f3(2)) && f3(2) > 0)),0);
check('   singular point warned (ar1:singular)',double(isempty(lastwarn)),0);
f3 = [ar1_pdf([-0.5 -0.49],3,0.6,'DU',0.3) ar1_pdf([-0.5 -0.49],3,0.6,'SU')]; f4 = ar1_pdf([0 -0.5],4,0,'DK',0);
check('ar1_pdf at n = 3, DU and SU: f(-1/2) = Inf, f(-0.49) finite; n = 4: finite at both points',double(~(all(isinf(f3([1 3]))) && all(isfinite(f3([2 4]))) && all(isfinite(f4)))),0);
% n = 4, DT and ST: -2/3 is not a double, so the density at fl(-2/3) is
% finite (Inf was returned within 8 eps until November 2026); it is checked
% against the logarithmic growth through the next three doubles, at the exact
% distances k u + 2^(-53)/3 from -2/3 (u = eps(2/3)), which tests that the
% distance is formed without rounding
u = eps(2/3);  dk = (0:3)*u+2^(-53)/3;  eT = 0;  fin = true;
for cc = {{'DT',[0.2 0.1]},{'ST',0}}
    fk = ar1_pdf(-2/3+(0:3)*u,4,0.5,cc{1}{1},cc{1}{2});
    fin = fin && all(isfinite(fk));
    pk = polyfit(log(dk(2:4)),fk(2:4),1);
    eT = max(eT,abs(fk(1)-polyval(pk,log(dk(1)))));
end
check('ar1_pdf at n = 4, DT and ST: finite at fl(-2/3), on the log line of the next three doubles',eT+double(~fin),1e-6);
% Yong Bao's example (November 2026): n = 3, DU, phi = 0.7, gamma = 0.2.  The
% doubles -1/2 + 2^(-p), p = 45..54, are distinct from -1/2 and the density is
% finite there, growing by the same amount per halving of the distance; from
% p = 55 on, -1/2 + 2^(-p) is -1/2 and the density is Inf, also from
% AR1_PDF_RANK2 directly (which once returned 134.2 there)
lastwarn('');  fy = ar1_pdf(-0.5+2.^-(45:55),3,0.7,'DU',0.2);  dy = diff(fy(1:10));
check('ar1_pdf at n = 3, DU, phihat = -1/2 + 2^(-p): finite for p = 45..54, equal steps per halving',double(~all(isfinite(fy(1:10))))+max(abs(dy-mean(dy))),1e-9);
check('   Inf at -1/2 + 2^(-55) = -1/2, from ar1_pdf and ar1_pdf_rank2',double(~(isinf(fy(11)) && isinf(ar1_pdf_rank2(-0.5,3,0.7,'DU',0.2)))),0);
check('   singular point warned (ar1:singular)',double(isempty(lastwarn)),0);
% centered input: phihat = x + phi is used exactly (TwoSum); fl(-1.2) + 0.7 is
% exactly -1/2, and one ulp of 1.2 away it is -1/2 + 2^(-52)
fc = ar1_pdf(-1.2+[0 1]*eps(1.2),3,0.7,'DU',0.2,[],true);
check('ar1_pdf, centered, n = 3, DU: Inf at x = fl(-1.2) (phihat = -1/2 exactly), = uncentered at -1/2 + 2^(-52)',double(~isinf(fc(1)))+abs(fc(2)-ar1_pdf(-0.5+2^-52,3,0.7,'DU',0.2)),1e-12);
f5 = [ar1_pdf(-2/3,5,0.5,'DT',0) ar1_pdf(-2/3,5,0.5,'ST',0)];
check('ar1_pdf at n = 5, DT and ST: finite at phihat = -2/3',double(~all(isfinite(f5) & f5 > 0)),0);
f3 = ar1_pdf(0,3,0,'DK',0.3);
check('ar1_pdf at n = 3, DK, z0 = 0.3: finite at phihat = 0',double(~isfinite(f3)),0);
% a tiny but nonzero start: f(0) is finite and grows like log(1/z0) as z0 -> 0
% (a relative threshold once treated z0 = 1e-12 as zero and returned 83.5;
% the value is 3.4971978406)
f3 = arrayfun(@(z) ar1_pdf(0,3,0,'DK',z), [1e-11 1e-12 1e-13]);
check('ar1_pdf at n = 3, DK, z0 = 1e-12: f(0) = 3.4971978 and linear in log z0',abs(f3(2)-3.4971978406)+abs(f3(2)-(f3(1)+f3(3))/2),1e-8);
% n = 3 (DK, DU, SU) and n = 4 (DT, ST): the density by integrating out the last
% observation (AR1_PDF_RANK2), against the inversion where the latter converges,
% against the cdf where it does not (DK with z0 ~= 0), and the logarithmic
% growth at a singular point (a constant increase per decade of the distance)
hD = @(t1,t2) ar1_logcf(t1,t2,3,1,'DU',2);  hT = @(t1,t2) ar1_logcf(t1,t2,4,0.5,'DT',[0.3 0.2]);
d1 = max(abs(ar1_pdf([-0.7 0.1],3,1,'DU',2)-ratio_pdf(hD,[-0.7 0.1]-1)));
d2 = max(abs(ar1_pdf([-0.9 0.2],4,0.5,'DT',[0.3 0.2])-ratio_pdf(hT,[-0.9 0.2]-0.5)));
check('ar1_pdf at n = 3 (DU) and n = 4 (DT), conditioning vs inversion',max(d1,d2),1e-10);
d = 1e-3; F = ar1_cdf(0.3+d*[-2 -1 1 2],3,0.5,'DK',0.3);
check('ar1_pdf at n = 3, DK, z0 = 0.3 (inversion fails): vs derivative of the cdf',abs(ar1_pdf(0.3,3,0.5,'DK',0.3)-(F(1)-8*F(2)+8*F(3)-F(4))/(12*d)),1e-7);
% n = 4, DK, z0 ~= 0 (AR1_PDF_RANK3): against a reference computed independently
% (tanh-sinh step 1/16, agreeing with a fully adaptive evaluation to 3e-13)
check('ar1_pdf at n = 4, DK, z0 = 0.3 (three random dimensions): vs reference',abs(ar1_pdf(0.2,4,0.5,'DK',0.3)-0.63833091486627),1e-10);
dl = 2.^-[27 34 41];                          % exact steps from -1/2
fl = ar1_pdf(-0.5+dl,3,0.3,'DU',0.5);  sl = diff(fl)./diff(log(dl));
check('ar1_pdf at n = 3, DU: logarithmic growth near phihat = -1/2 (constant slope in log distance)',abs(diff(sl)),1e-7);
% drift: the computed log phi(0,0) at the unit root with a drift (the cancellation
% of order n^2 gamma^2 eps), and the modulus of the characteristic function
L = zeros(3,2); worst = 0;
for i = 1:3
    n = 10^(i+1);
    for j = 1:2
        g = 10^(j-1);
        L(i,j) = max(abs(ar1_logcf(0,0,n,1,'DU',g)),abs(ar1_logcf(0,0,n,1,'DK',g)));
        worst = max(worst,max(abs(exp(ar1_logcf([0.3 2 10]/n,[0.1 -1 3]/n^2,n,1,'DU',g))))-1);
        worst = max(worst,max(abs(exp(ar1_logcf([0.3 2 10]/n,[0.1 -1 3]/n^2,n,1,'DK',g))))-1);
    end
end
check('|log phi(0,0)| at phi = 1, DU and DK, n <= 1e4, gamma, z0 <= 10: below 1e-7',max(L(:)),1e-7);
check('   and below the heuristic n^2 gamma^2 eps at each point',max(max(L./((10.^(2:4)').^2*(10.^(0:1)).^2*eps))),1);
check('   |phi(s,t)| <= 1 at phi = 1, DU and DK, n <= 1e4, par <= 10',worst,1e-9);
% independent moment identities (spherical symmetry and radial integration; the
% reviewer's), case DK with phi = z0 = 0, d = n-1: E phihat^2 and E phihat^4
emax = 0;
for nn = [6 10 30]
    d = nn-1; m = ar1_mom(4,nn,0,'DK',0);
    m2 = (d-1)/(d*(d+2))+1/(d*(d-2));
    m4 = 3*(d^2+4*d-9)/(d*(d+2)*(d+4)*(d+6))+6*(d+1)/(d*(d+2)*(d+4)*(d-2))+9/(d*(d+2)*(d-2)*(d-4));
    emax = max([emax abs(m(2)-m2) abs(m(4)-m4) abs(m(1)) abs(m(3))]);
end
check('DK, phi = z0 = 0, n = 6, 10, 30: E phihat^2, E phihat^4 vs closed forms (odd moments 0)',emax,1e-12);
h = @(t1,t2) ar1_logcf(t1,t2,1e6,1,'DU',100); [~,~,~,~,L0] = ratio_scale(h);
[~,e6] = ar1_cdf(-3e-6,1e6,1,'DU',100,[],true);
check(sprintf('n = 1e6, gamma = 100: lost normalization L0 = %.2f reported in the cdf error',L0),double(~(L0 > 1e-3 && e6 >= L0)),0);

fprintf('\n=== 11. trend cases DT and ST (Online Supplement, Section S7) ===\n');
% finite n: the O(1) closed form against the dense evaluation, with a derivative
s0 = [0.3 -1.2 2.5 -4 7]; t0 = [0.4 -0.6 1.1 -2 3];
for cc = {{11,0.6,'DT',[0.4 -0.2]},{11,1,'DT',[0.3 0.1]},{11,-1,'DT',[0.2 0.5]},{11,1.05,'DT',[0.2 0.1]}, ...
          {40,0.95,'DT',[1 -0.05]},{40,-1.02,'DT',[0 0.3]},{40,0.5,'ST',[]},{40,-0.97,'ST',[]}}
    c = cc{1}; n = c{1}; phi = c{2};
    % points on the scale of the distribution (at n = 40 the unscaled points give
    % |cf| ~ e^{-80}, where the dense reference itself loses relative accuracy)
    s = s0*11/n; t = t0*(11/n)^2;
    L = ar1_logcf([s; ones(1,5)],[t; zeros(1,5)],n,phi,c{3},c{4});
    vd = cf_dense(s,t,n,phi,c{3},c{4});
    hh = 1e-4*11/n; vp = cf_dense(s+hh,t,n,phi,c{3},c{4}); vm = cf_dense(s-hh,t,n,phi,c{3},c{4});
    e1 = max(abs(exp(L(1,:))-vd)./abs(vd));
    e2 = max(abs(L(2,:)-(log(vp)-log(vm))./(2*hh))./max(1,abs(L(2,:))));
    check(sprintf('%s n=%d phi=%g par0=%s: closed form vs dense (rel)',c{3},n,phi,mat2str(c{4})),e1,2e-13*n);
    check('   d log cf/dt1 vs central difference of the dense evaluation',e2,1e-6);
end
s = s0; t = t0;
% explosive region: the cancellation-free forms against the high-precision dense reference
fn = fullfile(fileparts(which('ar1_logcf')),'validation','hp_trend_ref.txt');
if exist(fn,'file')
    R = dlmread(fn); cfg = unique(R(:,1:4),'rows'); e = 0;
    for k = 1:size(cfg,1)
        I = all(R(:,1:4) == cfg(k,:),2);
        L = ar1_logcf(R(I,5).',R(I,6).',cfg(k,2),cfg(k,1),'DT',cfg(k,3:4));
        e = max(e,max(abs(real(L).'-R(I,7))./max(1,abs(R(I,7)))));
        c2 = exp(2*L).'; r2 = R(I,8)+1i*R(I,9); ok = abs(r2) > 1e-290;
        e = max(e,max(abs(c2(ok)-r2(ok))./abs(r2(ok))));
    end
    check('DT, |phi| > 1, phi^{2n} up to 1e42: log|cf| and cf^2 vs the high-precision reference',e,1e-10);
end
% invariance: the estimator depends on (gamma, gamma_tau) only through the effective start
n = 20; phi = 0.8; v1 = cf_dense(s/n,t/n^2,n,phi,'DT',[1.3 0.2]);
xi = (1-phi)*1.3-((1-phi)*(n+1)/2+phi)*0.2;
v2 = cf_dense(s/n,t/n^2,n,phi,'DT',[xi/(1-phi) 0]);
check('DT: dense cf at (gamma, gamma_tau) = (1.3, 0.2) and (xi/(1-phi), 0), the same effective start',max(abs(v1-v2)),1e-14);
e = 0;
for n = [1000 20000]
    e = max(e,max(abs(exp(ar1_logcf(s/n,t/n^2,n,1,'DT',[10 0]))-exp(ar1_logcf(s/n,t/n^2,n,1,'DT',[0 0])))));
end
check('DT at phi = 1: the drift gamma = 10 has no effect (n = 1e3, 2e4)',e,1e-13);
% distributions
n = 30; x = 0.6; d = 1e-3;
Fv = ar1_cdf(x+[-2 -1 1 2]*d,n,0.9,'DT',[0.5 0.1],1e-12); fd = (-Fv(4)+8*Fv(3)-8*Fv(2)+Fv(1))/(12*d);
[f,ef] = ar1_pdf(x,n,0.9,'DT',[0.5 0.1]);
check('DT n=30 phi=0.9: pdf vs 4th-order difference of the cdf',abs(f-fd),1e-9+ef);
q = ar1_icdf([0.05 0.5 0.95],n,0.6,'ST'); F = ar1_cdf(q,n,0.6,'ST');
check('ST n=30 phi=0.6: cdf(icdf(p)) = p',max(abs(F-[0.05 0.5 0.95])),1e-9);
if ~quick
    R = 200000; n = 25; phi = 0.9; par = [0.5 0.1];
    rng_ = randn('state'); randn('state',11);
    ph = zeros(R,1); tt = (1:n)'-(n+1)/2; X = [ones(n,1) tt];
    for r = 1:R
        e_ = randn(n,1); w = filter(1,[1 -phi],par(1)+par(2)*tt+e_);
        y = w; yl = [0; w(1:end-1)];
        Z = [X yl]; b = Z\y; ph(r) = b(3);
    end
    randn('state',rng_);
    m = ar1_mom(2,n,phi,'DT',par); se = std(ph)/sqrt(R); se2 = std(ph.^2)/sqrt(R);
    check(sprintf('DT n=25: E phihat vs Monte Carlo (R = %d), in standard errors',R),abs(m(1)-mean(ph))/se,4);
    check('   E phihat^2 vs Monte Carlo, in standard errors',abs(m(2)-mean(ph.^2))/se2,4);
end
% limits: the closed form against Nabeya and Tanaka's (1990, Model 4) determinant
% at real moment generating function arguments (no branch involved)
e = 0;
for c = [-3 0.7 2]
    for u = [0 0.3 -0.5]
        for sb = [3 10 40]
            L = ar1lim_logcf(-1i*u,1i*sb,c,'DT',0);
            e = max(e,abs(L-ntdt(u,sb,c)));
        end
    end
end
check('DT limit: closed form vs Nabeya-Tanaka Model 4 at real mgf arguments',e,1e-12);
check('DT limit, c = 0: 5% quantile vs -21.711 (detrended Dickey-Fuller)',abs(ar1lim_icdf(0.05,0,'DT',0)+21.711),1e-3);
% the explosive side of the limit (c > 0), where the cf varies on t1 = O(e^{-c}),
% t2 = O(e^{-2c}): against 600-digit evaluations of the closed form (varkappa = 1.3)
ref = [40  1.2745062765874767e-17 -1.6243662490608737e-35 -5.7687421008381031e-04 3.0834597864361677e-03
       150 2.152528791949323e-65  -4.633380200170813e-131 -4.7412127139273766e-05 2.4657046742309100e-04];
e = 0;
for k = 1:2
    L = ar1lim_logcf(ref(k,2),ref(k,3),ref(k,1),'DT',1.3);
    e = max(e,abs(L-(ref(k,4)+1i*ref(k,5))));
end
check('DT limit, c = 40 and 150: log cf vs 600-digit reference',e,1e-12);
s = [0.3 1 2.5 6]; t = [0.5 -0.7 3 -4];
for cc = {{'DT',0,0.8},{'DT',-4,-1.5},{'DT',3,0.5},{'ST',-6,[]}}
    c = cc{1}; n = 4000; phi = 1+c{2}/n;
    % varkappa = sqrt(n)[c(gamma - gamma_tau(n+1)/2) + n phi gamma_tau]
    if strcmp(c{1},'ST'), par0 = [];
    elseif c{2} == 0, par0 = [0 c{3}/n^1.5];
    else, par0 = [c{3}/(c{2}*sqrt(n)) 0]; end
    e = max(abs(exp(ar1_logcf(s/n,t/n^2,n,phi,c{1},par0))-exp(ar1lim_logcf(s,t,c{2},c{1},c{3}))));
    check(sprintf('%s c=%g: |cf_n(n=%d) - cf_lim| (O(1/n))',c{1},c{2},n),e,20/n);
end
for cc = {{'DT',0,0},{'DT',-2,1.5},{'DT',4,0.5},{'ST',-5,0}}
    c = cc{1}; cl = ar1lim_ray(c{2},c{1},c{3});
    [F,eF] = ar1lim_cdf(-c{2}+1e-9,c{2},c{1},c{3}); f = ar1lim_pdf(-c{2},c{2},c{1},c{3});
    check(sprintf('%s c=%g par=%g: inversion at x = -c+1e-9 vs closed form (%.10f), minus f*1e-9',c{1},c{2},c{3},cl),abs(F-f*1e-9-cl),1e-10+eF);
end
% explosive: the effective start gives the Cauchy-type limit (approached like 1/n)
phi = 1.05; z0 = 2; X = [-1 0 0.5]; [~,Fl] = ar1explim(X,phi,z0); n = 1600;
F = ar1_cdf(X*(phi^2-1)/phi^n,n,phi,'DT',[(phi-1)*z0 0],[],true);
check('DT phi=1.05, n=1600: cdf of |phi|^n(phihat-phi)/(phi^2-1) vs ar1explim at the effective start',max(abs(F-Fl)),0.02);
% DT with a trend in the explosive region: the noncentral exponent in the
% flat-start border form has no cancellation (the earlier form lost about
% eps (gamma_tau n)^2): log psi(0,0) = 0 at any n, and the scaled cdf
% approaches the limit at the effective start like 1/n also for gamma_tau ~= 0
e = 0; for nn = [5e4 5e8 5e12], L = ar1_logcf_exps(0,0,nn,1.2,'DT',[0.4 1]); e = max(e,abs(L(1))); end
check('DT phi=1.2, gamma_tau=1: |log psi(0,0)| at n = 5e4, 5e8, 5e12 (scaled form)',e,1e-13);
phi = 1.2; gam = 0.4; gt = 1; x = [-2 -0.5 0.5 2]; e = [0 0];
for kk = 1:2
    nn = 5*10^(2*kk+2); geff = gam - gt*((nn+1)/2 + phi/(1-phi)); z0 = -geff/(1-phi); X = x/abs(z0);
    [~,Fl] = ar1explim(X,phi,z0); F = ar1_cdf(X,nn,phi,'DT',[gam gt],[],'scaled'); e(kk) = nn*max(abs(F-Fl));
end
check('DT phi=1.2, gamma_tau=1, n = 5e6 and 5e8: n |F - F_lim| the same (O(1/n), rel. diff)',abs(e(2)-e(1))/e(1),1e-3);


fprintf('\n=== 12. large t1 near the zeros of U_m and the rank drops of u - r v ===\n');
% At large t1, x = p/(2q) tends to -phihat.  Where phihat is near a zero
% -cos(k pi/n) of U_m, D is nearly singular relative to its scale; where it
% is near a rank drop of u - r v, Delta = D + kappa 1 1' (or D + Z C Z') is.
% The main assemblies then lost about eps t1^2 in relative terms (NaN, Inf
% or O(1) errors from t1 of order 1e8 on); the error is now the eps t1 that
% the rank drop makes inherent (the dense evaluation has it too).  Measured
% here as max |log phi - log phi_dense| (phase modulo 2 pi) / (1e-14 t1)
% over t1 = 1e2..1e10; it was of order 1e4 and more before.  (A nonzero
% start in case DK is left out: log phi then falls like -t1^2, and the
% dense evaluation underflows.)
cfg = {{'DK',4,0,0},{'DK',5,0.5,0},{'DU',4,0.5,0.5},{'DU',5,0,0.5},{'SK',4,0,0},{'SU',4,0,0},{'SU',5,0.5,0}, ...
       {'DT',5,0,[0.2 0.1]},{'DT',6,0.5,[0 0]},{'ST',5,0.5,0},{'ST',7,0.3,0},{'DU',6,1.5,0.5},{'DT',6,1.5,[0.2 0.1]}};
sv = 10.^(2:2:10);  worst = 0;  wl = '';
for ic = 1:numel(cfg)
    [ca,n,phi,p0] = cfg{ic}{:};
    xs = [rdpts(n,phi,ca) -cos((1:n-1)*pi/n)];  xs = xs(xs > -0.99 & xs < 0.99);
    for x = xs
        r = x-phi;
        d = ar1_logcf(sv,-r*sv,n,phi,ca,p0) - log(cf_dense(sv,-r*sv,n,phi,ca,p0));
        d = abs(real(d)) + abs(mod(imag(d)+pi,2*pi)-pi);
        e = max(d./(1e-14*sv));
        if ~(e <= worst), worst = e; wl = sprintf('%s n=%d phi=%g phihat=%.4f',ca,n,phi,x); end
    end
end
check(sprintf('log cf at the zeros of U_m and the rank drops, t1 = 1e2..1e10: error/(1e-14 t1) (worst %s)',wl),worst,50);
% the density where it was NaN, Inf, 0 or O(1)-wrong: finite, and continuous
% from at least one side (a square-root cusp is one-sided)
dp = {{'SK',4,0,0,0},{'SU',4,0.5,0,0},{'SU',5,0.5,0,cos(2*pi/5)},{'DU',4,0.5,0.5,0},{'DU',5,0,0.5,-cos(pi/5)},{'DT',6,1.5,[0.2 0.1],-0.4}};
bad = 0;
for ic = 1:numel(dp)
    [ca,n,phi,p0,x0] = dp{ic}{:};
    xs = [rdpts(n,phi,ca) -cos((1:n-1)*pi/n)];  [~,j] = min(abs(xs-x0));  x = xs(j);
    f = ar1_pdf(x+[-1e-12 0 1e-12],n,phi,ca,p0,1e-10);
    bad = bad + double(~all(isfinite(f)) || min(abs(f(2)-f([1 3]))) > 1e-6*abs(f(2)));
end
check('ar1_pdf at the former failures (SK, SU, DU, explosive DT): finite and continuous (number of failures)',bad,0);
% the assemblies about the core of size m-1 against the main ones (order-2
% jets, phase included) at moderate arguments, where both are accurate
randn('seed',5);  worst = 0;
for ca = {'DK','DU','SK','SU','DT','ST'}
    for n = [4 7 40]
        for phi = [0 0.6 -0.9]
            p0 = 0;  if ca{1} == "DK" || ca{1} == "DU", p0 = 0.7; elseif ca{1} == "DT", p0 = [0.4 0.2]; end
            sv = [0.02 0.5 3 20];  rr = 0.4*randn(1,4);
            sj = [sv; ones(1,4); zeros(1,4)];  tj = [-rr.*sv; -rr; zeros(1,4)];
            L0 = ar1_logcf(sj,tj,n,phi,ca{1},p0,struct('m1',false));
            L1 = ar1_logcf(sj,tj,n,phi,ca{1},p0,struct('m1',true));
            worst = max(worst,max(abs(L1(:)-L0(:))./max(1,abs(L0(:)))));
        end
    end
end
check('assemblies about the core of size m-1 vs the main ones, all cases (rel)',worst,1e-10);
% the moment formulas evaluate at imaginary arguments, where the switches
% are not made (the demo core once made them there and lost the third moment)
mm = ar1_mom(3,6,0,'ST',0,0);
check('case ST, n = 6, phi = 0: E(phihat - phi)^k, k = 1..3, vs -1/3, 13/45, -103/540',max(abs(mm-[-1/3 13/45 -103/540])),1e-10);
fprintf('\n%d checks, %d failed.\n',ntest,nfail);
if strict && nfail > 0
    error('ar1:test','%d of %d checks failed.',nfail,ntest);
end

    function check(name,val,tolv)
        ntest = ntest+1;
        ok = isfinite(val) && val <= tolv;
        if ~ok, nfail = nfail+1; end
        fprintf('  %-78s %10.2e <= %8.1e  %s\n',name,val,tolv,ifelse(ok,'PASS','FAIL'));
    end
end

function r = ifelse(c,a,b), if c, r = a; else r = b; end, end
function s = skewness_(x), x = x-mean(x); s = mean(x.^3)/mean(x.^2)^1.5; end
function k = kurtosis_(x), x = x-mean(x); k = mean(x.^4)/mean(x.^2)^2 - 3; end   % excess kurtosis

function L = ntdt(u,s,c)
% log E exp(u A - s B) for the detrended limit (varkappa = 0) from Nabeya and
% Tanaka's (1990) Model 4 determinant: E exp(i tA A' + i tB B) =
% exp(-i tA/2) D^{-1/2}, A' = A + cB, D = e^{c} [F0 + F1 lam + F2 lam^2],
% lam = -i tA, z = 2 i tB - b^2, b = -c; here at real arguments with |z| >= 4
b = -c;  lam = -u;  z = -2*(s+c*u) - b^2;
X = (z + b^2)/2;  th = sqrt(-z);  E = exp(-2*th);
C = (1+E)/2;  S = (1-E)/(2*th);  one = exp(-th);
T = (S + (C-one)/z)/z^3;
F2 = -4*(b^2+3*b+27)*S/z^2 + (192*X + 288*(b+1))*T - 32*(b^2+3*b+6)*C/z^3 - 16*(b^2+3*b-3)*one/z^3;
F1 = b^4*S/z^2 - 24*b^4*T + 8*b^4*C/z^3 + 4*b^4*one/z^3;
F0 = (b^5 - 8*(b^2-3*b-3)*X)*S/z^2 - 96*(b+1)*X^2*T + (b^4/z^2 + 16*b^3*X/z^3)*C + 8*b^2*(b+3)*X*one/z^3;
L = -u/2 - 0.5*(c + th + log(F0 + F1*lam + F2*lam^2));
end

function xs = rdpts(n,phi,cas)
%RDPTS  The values of phihat at which the quadratic part of u - r v loses
%   one rank: the real generalized eigenvalues of (C'A_u C, C'A_v C), plus
%   phi (the matrices of CF_DENSE).
cas = upper(cas);
Jt = [eye(n) zeros(n,1)];  P = [zeros(n,1) eye(n)];
if cas(2) == 'U', M = eye(n)-ones(n)/n;
elseif cas(2) == 'T', X = [ones(n,1) (1:n)'-(n+1)/2]; M = eye(n)-X*((X'*X)\X');
else, M = eye(n); end
Au = (Jt'*M*(P-phi*Jt) + (P-phi*Jt)'*M*Jt)/2;  Av = Jt'*M*Jt;
if cas(1) == 'D'
    L = toeplitz(phi.^(0:n-1), [1 zeros(1,n-1)]);  C = [zeros(1,n); L];
else
    C = chol(toeplitz(phi.^(0:n))/(1-phi^2))';
end
Gu = C'*Au*C;  Gv = C'*Av*C;
r = eig((Gu+Gu')/2,(Gv+Gv')/2);
r = real(r(isfinite(r) & abs(imag(r)) < 1e-10 & abs(r) < 1e6));
xs = sort(r(:)'+phi);
end
