function ar1_trend_tables(outdir,parts)
%AR1_TREND_TABLES  Tables of the trend cases (Online Supplement, Section S7).
%
%   AR1_TREND_TABLES prints the tables of Section S7 of the Online Supplement
%   to the paper, on the regression with an intercept and a linear trend
%   (cases 'DT' and 'ST'); AR1_TREND_TABLES(outdir) also writes their LaTeX
%   bodies to the files tabT1.tex, ..., tabT6.tex in the folder outdir.
%   AR1_TREND_TABLES(outdir,parts) computes only the tables listed in parts
%   (a subset of 1:6).
%
%    T1  accuracy of the O(1) characteristic function against the dense
%        eigenvalue evaluation (n = 60, 200) and, for |phi| > 1, against the
%        high-precision reference validation/hp_trend_ref.txt;
%    T2  exact quantiles of n(phihat-1) at the unit root (case DT, any drift)
%        and the comparison with the simulated table of Fuller (1996, Table
%        10.A.1, panel rho_tau);
%    T3  bias, standard deviation, skewness and excess kurtosis of phihat in
%        cases DT and ST, and of n(phihat-1) at the unit root with its limit;
%    T4  quantiles of the local-to-unity limits of n(phihat-phi) (DT, ST);
%    T5  the explosive region: cdf of |phi|^n(phihat-phi)/(phi^2-1) against
%        the Cauchy-type limit at the effective start (DT and DU);
%    T6  cost against the sample size (seconds).
%
%   T1, ..., T6 are Tables S11, S12, S13-S14, S15, S16 and S17 of the Online
%   Supplement.
%
%   Runs in MATLAB and Octave; the timings of T6 depend on the machine.
%
%   See also AR1_LOGCF, AR1LIM_LOGCF, AR1_PAPER.
if nargin < 1, outdir = ''; end
if nargin < 2 || isempty(parts), parts = 1:6; end
ws = warning('off','ratio:accuracy'); cl = onCleanup(@() warning(ws)); %#ok<NASGU>
here = fileparts(mfilename('fullpath'));

% ---------------------------------------------------------------- T1
if ismember(1,parts)
    fprintf('\nT1. Accuracy of the O(1) characteristic function (max abs difference)\n');
    cfg = {{'DT',0.5,[0 0],'\gamma=\gamma_\tau=0'},{'DT',0.9,[1 0.05],'(\gamma,\gamma_\tau)=(1,0.05)'}, ...
           {'DT',1,[0 0],'\gamma=\gamma_\tau=0'},{'DT',1,[0.5 0.02],'(\gamma,\gamma_\tau)=(0.5,0.02)'}, ...
           {'DT',-1,[0 0],'\gamma=\gamma_\tau=0'},{'ST',0.95,[],'--'},{'ST',0.999,[],'--'}};
    svec = logspace(-5,3,2000);
    body = '';
    for ic = 1:numel(cfg)
        c = cfg{ic}; e = zeros(1,2); ns = [60 200];
        for in = 1:2
            n = ns(in);
            for x = [-3 -0.5 -0.05 0.5]*5/n
                t = -x*svec;
                got = exp(ar1_logcf(svec,t,n,c{2},c{1},c{3}));
                ref = cf_dense(svec,t,n,c{2},c{1},c{3});
                e(in) = max(e(in),max(abs(got-ref)));
            end
        end
        fprintf('  %s phi=%6.3f par=%-14s  n=60: %8.1e  n=200: %8.1e\n',c{1},c{2},mat2str(c{3}),e);
        body = [body sprintf('\\textsf{%s} & $%g$ & $%s$ & %s & %s \\\\\n',c{1},c{2},c{4},sci(e(1)),sci(e(2)))]; %#ok<AGROW>
    end
    fn = fullfile(here,'validation','hp_trend_ref.txt');
    if exist(fn,'file')
        R = dlmread(fn); cfgx = unique(R(:,1:4),'rows');
        for k = 1:size(cfgx,1)
            I = all(R(:,1:4) == cfgx(k,:),2);
            L = ar1_logcf(R(I,5).',R(I,6).',cfgx(k,2),cfgx(k,1),'DT',cfgx(k,3:4));
            c2 = exp(2*L).'; r2 = R(I,8)+1i*R(I,9); ok = abs(r2) > 1e-290;
            er = max(abs(c2(ok)-r2(ok))./abs(r2(ok)));
            fprintf('  DT phi=%5.2f n=%3d par=%-12s explosive, vs high precision: rel. error of cf^2 %8.1e\n',cfgx(k,1),cfgx(k,2),mat2str(cfgx(k,3:4)),er);
            body = [body sprintf('\\textsf{DT} & $%g^{\\dagger}$ & $(\\gamma,\\gamma_\\tau)=(%g,%g)$ & \\multicolumn{2}{c}{%s \\ ($n=%d$)} \\\\\n', ...
                cfgx(k,1),cfgx(k,3),cfgx(k,4),sci(er),cfgx(k,2))]; %#ok<AGROW>
        end
    end
    wtab(outdir,'tabT1.tex',body);
end

% ---------------------------------------------------------------- T2
if ismember(2,parts)
    fprintf('\nT2. Exact quantiles of n(phihat-1), case DT, phi = 1\n');
    p = [0.01 0.025 0.05 0.10 0.50 0.90 0.95 0.975 0.99];
    body = '';
    for n = [25 50 100 250 500 1000]
        q = n*(ar1_icdf(p,n,1,'DT',[0 0])-1);
        fprintf('  n=%5d: %s\n',n,sprintf('%8.3f',q));
        body = [body sprintf('%d & & %s \\\\\n',n,strjoin(arrayfun(@(v) sprintf('$%.3f$',v),q,'UniformOutput',false),' & '))]; %#ok<AGROW>
    end
    q = ar1lim_icdf(p,0,'DT',0);
    fprintf('  limit  : %s\n',sprintf('%8.3f',q));
    body = [body sprintf('$\\infty$ & & %s \\\\\n',strjoin(arrayfun(@(v) sprintf('$%.3f$',v),q,'UniformOutput',false),' & '))];
    wtab(outdir,'tabT2a.tex',body);
    % Fuller (1996), Table 10.A.1, panel rho_tau (constructed by D. A. Dickey by
    % Monte Carlo; standard errors mostly below 0.10 in the left half and 0.02 in
    % the right half): row n against n/(n-1) times our row n-1
    Fu = [-22.5 -20.0 -17.9 -15.6 -8.49 -3.65 -2.51 -1.53 -0.46
          -25.8 -22.4 -19.7 -16.8 -8.80 -3.71 -2.60 -1.67 -0.67
          -27.4 -23.7 -20.6 -17.5 -8.96 -3.74 -2.63 -1.74 -0.76
          -28.5 -24.4 -21.3 -17.9 -9.05 -3.76 -2.65 -1.79 -0.83
          -28.9 -24.7 -21.5 -18.1 -9.08 -3.76 -2.66 -1.80 -0.86
          -29.4 -25.0 -21.7 -18.3 -9.11 -3.77 -2.67 -1.81 -0.88];
    p = [0.01 0.025 0.05 0.10 0.50 0.90 0.95 0.975 0.99];
    nF = [25 50 100 250 500 Inf];
    body = '';
    for i = 1:numel(nF)
        n = nF(i);
        if isinf(n), q = ar1lim_icdf(p,0,'DT',0); lab = '$\infty$';
        else, q = n*(ar1_icdf(p,n-1,1,'DT',[0 0])-1); lab = sprintf('%d',n); end
        fprintf('  Fuller n=%5g: %s\n  exact       : %s\n',n,sprintf('%8.2f',Fu(i,:)),sprintf('%8.2f',q));
        body = [body sprintf('%s & Fuller & %s \\\\\n & exact & %s \\\\\n',lab, ...
            strjoin([arrayfun(@(v) sprintf('$%.1f$',v),Fu(i,1:4),'UniformOutput',false), ...
                     arrayfun(@(v) sprintf('$%.2f$',v),Fu(i,5:9),'UniformOutput',false)],' & '), ...
            strjoin(arrayfun(@(v) sprintf('$%.2f$',v),q,'UniformOutput',false),' & '))]; %#ok<AGROW>
    end
    wtab(outdir,'tabT2b.tex',body);
end

% ---------------------------------------------------------------- T3
if ismember(3,parts)
    fprintf('\nT3. Moments of phihat: bias, sd, skewness, excess kurtosis\n');
    body = '';
    for cas = {'DT','ST'}
        for phi = [0 0.5 0.9 0.99 1]
            if strcmp(cas{1},'ST') && phi == 1, continue, end
            row = sprintf('\\textsf{%s} & $%g$',cas{1},phi);
            for n = [25 100 400]
                if strcmp(cas{1},'DT'), par = [0 0]; else, par = []; end
                [m,v,sk,ku] = ar1_cmom(n,phi,cas{1},par);
                fprintf('  %s phi=%4.2f n=%3d: %9.5f %8.5f %8.3f %8.3f\n',cas{1},phi,n,m-phi,sqrt(v),sk,ku);
                row = [row sprintf(' & $%.4f$ & $%.4f$ & $%.2f$ & $%.2f$',m-phi,sqrt(v),sk,ku)]; %#ok<AGROW>
            end
            body = [body row ' \\' newline]; %#ok<AGROW>
        end
    end
    wtab(outdir,'tabT3a.tex',body);
    % n(phihat - 1) at the unit root and its limit
    body = '';
    for n = [25 50 100 250 1000 10000]
        [m,v,sk,ku] = ar1_cmom(n,1,'DT',[0 0]);
        fprintf('  n(phihat-1), n=%6d: mean %9.4f sd %8.4f skew %8.4f exkurt %8.4f\n',n,n*(m-1),n*sqrt(v),sk,ku);
        body = [body sprintf('%d & $%.4f$ & $%.4f$ & $%.4f$ & $%.4f$ \\\\\n',n,n*(m-1),n*sqrt(v),sk,ku)]; %#ok<AGROW>
    end
    ml = ar1lim_mom(4,0,'DT',0);
    mu = ml(1); c2 = ml(2)-mu^2; c3 = ml(3)-3*mu*ml(2)+2*mu^3; c4 = ml(4)-4*mu*ml(3)+6*mu^2*ml(2)-3*mu^4;
    fprintf('  limit: mean %9.4f sd %8.4f skew %8.4f exkurt %8.4f\n',mu,sqrt(c2),c3/c2^1.5,c4/c2^2-3);
    body = [body sprintf('$\\infty$ & $%.4f$ & $%.4f$ & $%.4f$ & $%.4f$ \\\\\n',mu,sqrt(c2),c3/c2^1.5,c4/c2^2-3)];
    wtab(outdir,'tabT3b.tex',body);
end

% ---------------------------------------------------------------- T4
if ismember(4,parts)
    fprintf('\nT4. Quantiles (5%%, 50%%, 95%%) of the local-to-unity limits\n');
    p = [0.05 0.5 0.95];
    body = '';
    for c = [-20 -10 -5 -2 0 2 5]
        row = sprintf('$%g$',c);
        for kap = [0 10]
            q = ar1lim_icdf(p,c,'DT',kap);
            row = [row sprintf(' & $%.3f$',q)]; %#ok<AGROW>
            fprintf('  c=%4g DT kap=%g: %s\n',c,kap,sprintf('%9.3f',q));
        end
        if c < 0
            q = ar1lim_icdf(p,c,'ST');
            row = [row sprintf(' & $%.3f$',q)]; %#ok<AGROW>
            fprintf('  c=%4g ST      : %s\n',c,sprintf('%9.3f',q));
            q = 1000*(ar1_icdf(p,1000,1+c/1000,'ST')-1-c/1000);
            row = [row sprintf(' & $%.3f$',q)]; %#ok<AGROW>
            fprintf('  c=%4g ST n=1000: %s\n',c,sprintf('%9.3f',q));
        else
            row = [row repmat(' & --',1,6)]; %#ok<AGROW>
        end
        body = [body row ' \\' newline]; %#ok<AGROW>
    end
    wtab(outdir,'tabT4.tex',body);
end

% ---------------------------------------------------------------- T5
if ismember(5,parts)
    fprintf('\nT5. Explosive region, phi = 1.05, effective start z0 = 2\n');
    phi = 1.05; z0 = 2; X = [-1 0 0.5 2];
    [~,Fl] = ar1explim(X,phi,z0);
    body = '';
    for n = [100 200 400 800 1600 3200]
        d = X*(phi^2-1)/phi^n;
        F1 = ar1_cdf(d,n,phi,'DT',[(phi-1)*z0 0],[],true);
        F2 = ar1_cdf(d,n,phi,'DU',(phi-1)*z0,[],true);
        fprintf('  n=%5d DT: %s   DU: %s\n',n,sprintf('%8.4f',F1),sprintf('%8.4f',F2));
        body = [body sprintf('%d & %s & %s \\\\\n',n,strjoin(arrayfun(@(v) sprintf('$%.4f$',v),F1,'UniformOutput',false),' & '), ...
            strjoin(arrayfun(@(v) sprintf('$%.4f$',v),F2,'UniformOutput',false),' & '))]; %#ok<AGROW>
    end
    fprintf('  limit   : %s\n',sprintf('%8.4f',Fl));
    s = strjoin(arrayfun(@(v) sprintf('$%.4f$',v),Fl,'UniformOutput',false),' & ');
    body = [body sprintf('$\\infty$ & %s & %s \\\\\n',s,s)];
    wtab(outdir,'tabT5.tex',body);
end

% ---------------------------------------------------------------- T6
if ismember(6,parts)
    fprintf('\nT6. Cost against the sample size (seconds), case DT, phi = 1\n');
    body = '';
    ar1_cdf(1-20/100,100,1,'DT',[0 0]);                       % warm-up
    for n = 10.^(2:6)
        tm = zeros(1,5);
        tic; for r = 1:5, ar1_cdf(1-20/n,n,1,'DT',[0 0]); end, tm(1) = toc/5;
        tic; for r = 1:5, ar1_pdf(1-20/n,n,1,'DT',[0 0]); end, tm(2) = toc/5;
        tic; for r = 1:5, ar1_icdf(0.05,n,1,'DT',[0 0]); end, tm(3) = toc/5;
        tic; for r = 1:5, ar1_mom(4,n,1,'DT',[0 0],1); end, tm(4) = toc/5;
        tic; for r = 1:5, ar1_cdf(0.95,n,0.95,'ST'); end, tm(5) = toc/5;
        fprintf('  n=%8d: %s\n',n,sprintf('%8.4f',tm));
        body = [body sprintf('$10^{%d}$ & %s \\\\\n',round(log10(n)),strjoin(arrayfun(@(v) sprintf('%.4f',v),tm,'UniformOutput',false),' & '))]; %#ok<AGROW>
    end
    wtab(outdir,'tabT6.tex',body);
end
end

function wtab(outdir,name,body)
if isempty(outdir), return, end
fid = fopen(fullfile(outdir,name),'w');
fprintf(fid,'%% table body generated by ar1_trend_tables.m\n%s',body);
fclose(fid);
end

function s = sci(x)
% x in the form $a.b\times 10^{e}$
if x == 0, s = '$0$'; return, end
e = floor(log10(x)); m = x/10^e;
if round(m*10)/10 >= 10, m = m/10; e = e+1; end
s = sprintf('$%.1f\\times 10^{%d}$',m,e);
end
