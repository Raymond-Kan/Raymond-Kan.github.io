function [f,F] = ar1explim(x,phi,z0)
%AR1EXPLIM  Limit distribution of the least squares estimator in the explosive
%   AR(1) model with fixed start and no intercept (White 1958, Anderson 1959).
%
%   [f,F] = AR1EXPLIM(x,phi,z0) returns the density f and the cdf F at x of
%   the limit of X_n = |phi|^n (phihat - phi)/(phi^2 - 1) as n -> inf when
%   |phi| > 1, y_0 = z0 sigma fixed and alpha = 0:
%
%        X_n -> Z_1/Z_2,   Z_1 ~ N(0,1),  Z_2 ~ N(z0 sqrt(phi^2-1), 1) independent,
%
%   which is standard Cauchy when z0 = 0.  With q = z0^2 (phi^2-1)/2 and
%   w = q/(1+x^2),
%
%        f(x) = [e^{-q} + sqrt(pi w) e^{-q x^2/(1+x^2)} erf(sqrt w)] / (pi (1+x^2)),
%
%   in which the two exponents are combined before evaluation (the product
%   e^{-q} e^{w} overflows for q > 700, e.g. phi = 1.2 and z0 = 100), and F
%   is obtained by integrating f (f is symmetric about 0).  x = +-Inf give
%   f = 0 and F = 1, 0.
%
%   With an intercept (case 'DU', parameter gamma) the limit is the same
%   with z0 replaced by gamma/(phi-1) (Wang and Yu 2015, Theorem 2.3(b)):
%   AR1EXPLIM(x,phi,gamma/(phi-1)).  The approach to the limit is then
%   much slower, like 1/n rather than phi^(-n).  With an intercept and a
%   trend (case 'DT', par0 = [gamma gamma_tau]) the limit is again the same,
%   with z0 replaced by the effective start -a, a = [gamma - gamma_tau
%   (n+1)/2]/(1-phi) - phi gamma_tau/(1-phi)^2 (Online Supplement,
%   Proposition S7.7), which does not depend on n; the approach is again like 1/n.
%
%   See also AR1_CDF, AR1LIM_CDF.
if nargin < 3 || isempty(z0), z0 = 0; end
if ~(isnumeric(phi) && isscalar(phi) && isreal(phi) && isfinite(phi) && abs(phi) > 1)
    error('ar1:phi','phi must be a real scalar with |phi| > 1.');
end
if ~(isnumeric(z0) && isscalar(z0) && isreal(z0) && isfinite(z0))
    error('ar1:par0','z0 must be a finite real scalar.');
end
q  = z0^2*(phi^2-1)/2;
fd = @(y) (exp(-q) + sqrt(pi*q./(1+y.^2)).*exp(-q*y.^2./(1+y.^2)).*erf(sqrt(q./(1+y.^2))))./(pi*(1+y.^2));
f  = zeros(size(x));
fin = isfinite(x);
f(fin) = fd(x(fin));
if nargout > 1
    F = zeros(size(x));
    F(~fin) = (x(~fin) > 0);
    for i = find(fin(:)')
        if q == 0
            F(i) = 0.5+atan(x(i))/pi;
        else
            F(i) = 0.5+sign(x(i))*quadgk(fd,0,abs(x(i)),'AbsTol',1e-12,'RelTol',1e-10);
        end
    end
end
end
