function [F,err] = ar1lim_cdf(x,c,cas,par,tol)
%AR1LIM_CDF  Cdf of the local-to-unity limit of n(phihat - phi).
%
%   F = AR1LIM_CDF(x,c,cas,par) returns P[A/B < x] for the limit A/B of
%   n(phihat-phi) as n -> inf with phi = 1 + c/n, in the six cases of
%   AR1LIM_LOGCF ('DK' with par = gamma_0, 'DU' with par = kappa = b + c gamma_0,
%   'DT' with par = varkappa, 'SK', 'SU' and 'ST' with c < 0).  c = 0,
%   par = 0 give the Dickey-Fuller distributions.  tol (optional): absolute
%   tolerance of the quadrature (default 1e-10).  [F,err] also returns the
%   error estimate of RATIO_CDF (at x = -c, that of the quadrature of
%   AR1LIM_RAY).
%
%   Along the ray x = -c the variable A + cB is of chi-square type and its
%   characteristic function decays only algebraically (Section 6.1 of the
%   paper and Section S2 of the Supplement), so the inversion integral is
%   taken over a finite interval and completed by the asymptotic expansion
%   of RATIO_CDF, with w0 = 1/2 ((1 + gamma_0^2)/2 in case 'DK') the slope
%   of the dominant phase; at x = -c itself (to within 1e-12 relative) the
%   representation of AR1LIM_RAY is returned, with its own error estimate.
%   Elsewhere the tail is negligible and the expansion is harmless.
%
%   See also AR1LIM_PDF, AR1LIM_ICDF, AR1LIM_MOM, AR1LIM_LOGCF, AR1LIM_RAY, AR1_CDF.
if nargin < 4 || isempty(par), par = 0; end
if nargin < 5, tol = []; end
if ~(isnumeric(x) && isreal(x) && all(isfinite(x(:))))
    error('ar1lim:x','x must be real and finite.');
end
h = @(t1,t2) ar1lim_logcf(t1,t2,c,cas,par);
opts = ar1lim_opts(c,cas,par);
[F,err] = ratio_cdf(h,x,tol,opts);
on = abs(x+c) <= 1e-12*(1+abs(c));
if any(on)
    [Fr,er] = ar1lim_ray(c,cas,par);
    F(on) = Fr;
    err(on) = er;
end
end
