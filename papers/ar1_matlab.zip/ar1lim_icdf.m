function x = ar1lim_icdf(pr,c,cas,par,tol)
%AR1LIM_ICDF  Quantiles of the local-to-unity limit of n(phihat - phi).
%   x = AR1LIM_ICDF(pr,c,cas,par); inputs as in AR1LIM_CDF.  With c = 0 and
%   par = 0 these are the asymptotic Dickey-Fuller critical values.
%   See also AR1LIM_CDF, AR1LIM_PDF, RATIO_ICDF.
if nargin < 4 || isempty(par), par = 0; end
if nargin < 5, tol = []; end
h = @(t1,t2) ar1lim_logcf(t1,t2,c,cas,par);
x = ratio_icdf(h,pr,tol,ar1lim_opts(c,cas,par));
end
