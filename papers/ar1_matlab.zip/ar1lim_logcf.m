function L = ar1lim_logcf(sj,tj,c,cas,par)
%AR1LIM_LOGCF  Log joint characteristic function of the numerator and denominator
%   of the local-to-unity limit of n(phihat - phi), in Taylor-mode (jet) arithmetic.
%
%   L = AR1LIM_LOGCF(t1,t2,c,cas,par) returns log E[exp(i t1 A + i t2 B)]
%   where n(phihat - phi) => A/B as n -> inf with phi = 1 + c/n (c = 0 is the unit
%   root; c < 0 is the near-stationary and c > 0 the near-explosive side).
%   With J_c(r) = int_0^r e^{(r-s)c} dW(s) the Ornstein-Uhlenbeck process and
%   W a standard Brownian motion, the four cases are
%
%    'DK'  y_0 = sqrt(n) gamma_0 sigma fixed, no intercept (Perron 1991):
%            A = gamma_0 int_0^1 e^{cr} dW + int_0^1 J_c dW,
%            B = gamma_0^2 (e^{2c}-1)/(2c) + 2 gamma_0 int_0^1 e^{cr} J_c dr + int_0^1 J_c^2 dr;
%          par = gamma_0.  gamma_0 = 0 gives Phillips (1987), and c = 0 as
%          well gives the Dickey-Fuller (1979) / White (1958) limit.
%    'DU'  y_0 = sqrt(n) gamma_0 sigma, alpha = b sigma/sqrt(n), intercept
%          estimated (Zhou and Yu 2015; A and B depend on (b,gamma_0) only
%          through varkappa = b + c gamma_0; written A, B here for the
%          paper's Ahat, Bhat): with gamma_c = b/c + gamma_0 = varkappa/c,
%            A = int J_c dW + gamma_c int e^{cr} dW - W(1)[int J_c dr + gamma_c(e^c-1)/c],
%            B = gamma_c^2(e^{2c}-1)/(2c) + 2 gamma_c int e^{cr}J_c dr + int J_c^2 dr
%                - [int J_c dr + gamma_c(e^c-1)/c]^2;
%          par = varkappa.  varkappa = 0 gives the demeaned Dickey-Fuller limit
%          (c = 0) and Phillips (1987) (c ~= 0); at c = 0 varkappa = b (Haldrup
%          and Hylleberg 1995).
%    'SK'  stationary start, no intercept: the 'DK' functional with gamma_0
%          ~ N(0,-1/(2c)) independent of W; requires c < 0.  par unused.
%    'SU'  stationary start, intercept estimated: the 'DU' functional with
%          b = 0 and gamma_0 ~ N(0,-1/(2c)); requires c < 0.  par unused.
%    'DT'  intercept and trend estimated (Online Supplement, Section S7):
%          A = int Xh dW, B = int Xh^2 dr, with Xh the residual of the L2
%          projection of X = J_c + varkappa H_c, H_c(r) = (e^{cr}-1-cr)/c^2
%          (r^2/2 at c = 0), on span{1, r}; par = varkappa.  For the finite-n
%          model of AR1_LOGCF, case 'DT', varkappa = sqrt(n)[c(gamma -
%          gamma_tau(n+1)/2) + n phi gamma_tau].  varkappa = 0 gives the
%          detrended Dickey-Fuller limit (c = 0) and Nabeya and Tanaka's
%          (1990) Model 4.
%    'ST'  stationary start with a trend: 'DT' with varkappa ~ N(0,-c^3/2);
%          requires c < 0.  par unused.
%
%   t1 and t2 may be jets ((K+1) x N arrays of Taylor coefficients in one
%   scalar variable); the output is the jet of log E[exp(i t1 A + i t2 B)].  Complex
%   arguments are allowed, so the routine also evaluates the moment
%   generating function.
%
%   Formulas (Proposition 4 of the paper; Perron 1991, Nabeya and Tanaka
%   1990).  With omega = c + i t1, theta^2 = 2i t2 - 2ic t1 - c^2,
%   tau_0 = t1^2 - 2i t2, C = cos th, S = sin(th)/th, Ch = cos(th/2) and
%   Sh = sin(th/2)/(th/2),
%     'DK':  exp(-omega/2) (C - omega S)^{-1/2}
%            exp( -gamma_0^2 tau_0 S / (2(C - omega S)) ),
%     'DU':  exp(-omega/2) [th/sin(th/2)] (tau_3/th^2)^{-1/2}
%            exp( -2 varkappa^2 tau_0 (1 - Ch/Sh) / tau_3 ),
%   where tau_1 = 2(t1^2 + i c^2 t1 - 2ic t2), tau_2 = c^3 + i(c-2)c t1 - tau_0
%   and tau_3 = (2 tau_1 Sh^2 - 4c^2 C + 4 tau_2 S)/Sh^2
%   (= 2 tau_1 - c^2 th^2 C csc^2(th/2) + 2 tau_2 th cot(th/2)).
%   Every function of th is even, so it is a function of th^2 and no root of
%   th^2 is ever chosen.  For |th^2| < 4 the functions of th^2 are evaluated
%   by their power series, where the closed forms cancel.  Elsewhere they
%   are evaluated through vartheta = (-th^2)^{1/2} (Re vartheta >= 0) and
%   E = e^{-vartheta}, |E| <= 1, in forms in which no O(1) quantity is a
%   difference of quantities of order e^{vartheta}: at the origin, for
%   instance, C - omega S = cosh c - sinh c = e^{-c}, which
%   the naive assembly loses to rounding by a factor e^{2c}; the stable
%   forms write it as e^{c}[(vartheta-omega) + E^2(vartheta+omega)]/(2 vartheta)
%   with vartheta - c = (2ic t1 - 2i t2)/(vartheta+c) exact to rounding.  On
%   the explosive side c > 0, where the characteristic function varies on the
%   scale t1 = O(e^{-c}), t2 = O(e^{-2c}), vartheta - c and i t1 are O(e^{-c})
%   while vartheta - omega is O(e^{-2c}); it is formed as tau_0/(vartheta +
%   omega) (vartheta^2 - omega^2 = tau_0), and case 'DU' is rearranged
%   accordingly.
%   The branch: the continuous argument of cos th is the principal one
%   shifted by the multiple of 2 pi that brings it within pi/2 of
%   -sign(Im th) Re th, and the remaining factors under the square root are
%   off the negative real axis (Section 6 of the paper), so their principal
%   arguments are the continuous ones.
%
%   Cases 'DT' and 'ST' (Online Supplement, Section S7.5): with vartheta^2 = -theta^2,
%   E = e^{-vartheta}, h1 = (vartheta-2) + E(vartheta+2), h2 = -(vartheta^2-6
%   vartheta+12) + E(vartheta^2+6 vartheta+12),
%     'DT':  exp(-(omega+vartheta)/2) [D/(2 vartheta^8)]^{-1/2}
%            exp( varkappa^2 tau_0 h1 h2/(2D) ),
%   D = h1 h2 [c(c-2)(c^2-6c+12) i t1 - 4(c^2-3c+3) tau_0] + G, G a polynomial
%   in (vartheta, c, E) of degree two in E (subfunction TRENDLIM); the
%   phase is that of case 'DK' (par = 0) corrected by the principal
%   arguments of three factors that are off the negative real axis.
%
%   Range.  The result is accurate to a few units of rounding for every
%   c <= 300 or so (where e^{-c} is still representable) and all (t1,t2);
%   with c > 0 the limit variables are of order e^{2c}, so the inversion
%   routines rescale accordingly.
%
%   See also AR1LIM_CDF, AR1LIM_PDF, AR1LIM_MOM, AR1LIM_RAY, AR1_LOGCF.

if nargin < 5 || isempty(par), par = 0; end
if ~(isnumeric(c) && isscalar(c) && isreal(c) && isfinite(c))
    error('ar1lim:c','c must be a finite real scalar.');
end
if ~(isnumeric(par) && isscalar(par) && isreal(par) && isfinite(par))
    error('ar1lim:par','par must be a finite real scalar.');
end
if ~(ischar(cas) || isstring(cas)) || ~ismember(upper(char(cas)),{'DK','DU','SK','SU','DT','ST'})
    error('ar1lim:cas','cas must be one of ''DK'', ''DU'', ''SK'', ''SU'', ''DT'', ''ST''.');
end
cas = upper(char(cas));
if cas(1) == 'S' && c >= 0
    error('ar1lim:c','A stationary start requires c < 0.');
end
if size(sj,1) == 1 && size(tj,1) > 1, sj = [sj; zeros(size(tj,1)-1,size(sj,2))]; end
if size(tj,1) == 1 && size(sj,1) > 1, tj = [tj; zeros(size(sj,1)-1,size(tj,2))]; end
if size(sj,2) == 1 && size(tj,2) > 1, sj = repmat(sj,1,size(tj,2)); end
if size(tj,2) == 1 && size(sj,2) > 1, tj = repmat(tj,1,size(sj,2)); end
if any(size(sj) ~= size(tj))
    error('ar1lim:jets','s and t must be jets of the same order and width.');
end
K = size(sj,1)-1;  N = size(sj,2);

om   = jc(1i*sj,c);                         % c + is
zc   = 2i*tj-2i*c*sj;                       % theta^2 + c^2 (exact)
zeta = jc(zc,-c^2);                         % theta^2
tau0 = jm(sj,sj)-2i*tj;                     % s^2 - 2it
z0 = zeta(1,:);
small = abs(z0) < 4;
big   = ~small;
if cas(2) == 'T'
    L = trendlim(sj,tj,c,cas,par,om,zc,tau0,abs(z0) < 16);
    return
end

switch cas(2)
    case 'K'
        lC = zeros(K+1,N); lg = lC; Kf = lC;
        if any(small)
            i = small;
            [C,S] = jtrig(zeta(:,i));
            f  = C-jm(om(:,i),S);                       % cos th - (om/th) sin th
            g  = jc(-jd(jm(om(:,i),S),C),1);            % 1 - (om/th) tan th : off the negative axis
            lC(:,i) = logc(C,argcos(z0(i)));
            lg(:,i) = logp(g);
            Kf(:,i) = -jd(jm(tau0(:,i),S),2*f);         % (s^2-2it)/(2[om - th cot th])
        end
        if any(big)
            i = big;
            vt = jsq(-zeta(:,i));                       % vartheta, Re >= 0
            E2 = jexp(-2*vt);                           % e^{-2 vartheta}
            nu = vtmo(vt,zc(:,i),c,om(:,i),sj(:,i),tau0(:,i));   % vartheta - om, stably
            Bk = nu+jm(E2,vt+om(:,i));                  % (vartheta-om) + E^2 (vartheta+om)
            % cos th = cosh vartheta = e^{vartheta}(1+E^2)/2
            oe = jc(E2,1);
            lC(:,i) = jc(vt+jlog0(oe),-log(2));
            lC(1,i) = real(vt(1,:))+log(abs(oe(1,:)))-log(2)+1i*argcos(z0(i));
            % g = f/cos th = Bk/(vartheta (1+E^2)) : off the negative axis
            lg(:,i) = logp(jd(Bk,jm(vt,oe)));
            % om - th cot th = -Bk/(1-E^2)
            Kf(:,i) = -jd(jm(tau0(:,i),jc(-E2,1)),2*Bk);
        end
        L = -om/2-0.5*(lC+lg);
        if cas(1) == 'D'
            L = L+par^2*Kf;
        else
            L = L-0.5*logp(jc(Kf/c,1));                 % E exp(gamma_0^2 Kf), gamma_0 ~ N(0,-1/(2c))
        end
    case 'U'
        tau1 = 2*(jm(sj,sj)+1i*c^2*sj-2i*c*tj);
        tau2 = jc(1i*(c-2)*c*sj-tau0,c^3);
        lS = zeros(K+1,N); lT = lS; Q = lS; D2 = zeros(1,N); T0 = zeros(K+1,N);
        if any(small)
            i = small;
            [C,S,Sh,~,ShmCh] = jtrig(zeta(:,i));
            Nz = nquot(zeta(:,i),sj(:,i),c,tau1(:,i),tau2(:,i),C,S,Sh);   % N/zeta, N = tau_4 sin^2(th/2)
            T0(:,i) = jd(Nz,jm(Sh,Sh));                 % tau_4/th^2
            lS(:,i) = logp(Sh);
            Q(:,i)  = 2*jd(jm(jm(tau0(:,i),ShmCh),Sh),Nz);   % 2 tau0 [1-(th/2)cot(th/2)]/tau_4
            D2(i)   = Sh(1,:).^2./(2*S(1,:));           % tan(th/2)/th
        end
        if any(big)
            i = big;
            vt = jsq(-zeta(:,i));
            E  = jexp(-vt);
            E2 = jm(E,E);
            s_ = sj(:,i); t_ = tj(:,i);
            nu = vtmo(vt,zc(:,i),c,om(:,i),s_,tau0(:,i));   % vartheta - om, stably
            % tau_4 (1-E)^2/2 = Q0 - 2E tau1 + E^2 (tau1 - c^2 vt^2 - tau2 vt), with
            % Q0 = tau1 - c^2 vt^2 + tau2 vt written without the cancelling c^4
            % terms and, through vartheta - c = nu + i s, without the cancelling
            % O(e^{-c}) terms of the explosive side
            Q0  = (2-c)*(1+c)*jm(s_,s_)+2i*c*(c-1)*t_+jm(nu,tau2(:,i))-1i*jm(s_,tau0(:,i));
            vt2 = jm(vt,vt);
            Den = Q0-2*jm(E,tau1(:,i))+jm(E2,tau1(:,i)-c^2*vt2-jm(tau2(:,i),vt));
            omE = jc(-E,1);                             % 1 - E
            T0(:,i) = -2*jd(Den,jm(vt2,jm(omE,omE)));   % tau_4/th^2 = -tau_4/vt^2
            % sin(th/2)/(th/2) = sinh(vt/2)/(vt/2) = e^{vt/2}(1-E)/vt
            lS(:,i) = vt/2+jlog0(omE)-jlog0(vt);
            Sh0 = exp(1i*imag(vt(1,:))/2).*omE(1,:)./vt(1,:);   % unit-modulus e^{vt/2} for the phase
            lS(1,i) = real(vt(1,:))/2+log(abs(omE(1,:)))-log(abs(vt(1,:)))+1i*angle(Sh0);
            % 2 tau0 [1-(th/2)cot(th/2)]/tau_4 with (th/2)cot(th/2) = (vt/2)(1+E)/(1-E)
            br = jc(-vt/2,1)-jm(E,jc(vt/2,1));         % (1-vt/2) - E(1+vt/2)
            Q(:,i) = jd(jm(jm(tau0(:,i),br),omE),Den);
            D2(i)  = omE(1,:)./(jc(E(1,:),1).*vt(1,:)); % tanh(vt/2)/vt
        end
        lT = jlog0(T0);
        lT(1,:) = log(abs(T0(1,:)))+1i*argtau4(z0,zc(1,:),D2,T0(1,:));
        L = jc(-om/2-lS-0.5*lT,log(2));
        if cas(1) == 'D'
            L = L-par^2*Q;
        else
            L = L-0.5*logp(jc(-c*Q,1));                 % E exp(-c^2 gamma_0^2 Q), gamma_0 ~ N(0,-1/(2c))
        end
end
end

% =========================================================================
function e = vtmc(vt,zc,c)
%VTMC  vartheta - c without cancellation: for c >= 0 (where vartheta is close
%   to c near the origin) as (vartheta^2 - c^2)/(vartheta + c) = -zc/(vartheta + c);
%   for c < 0 the difference is of order 2|c| and is formed directly.
if c >= 0
    e = jd(-zc,jc(vt,c));
else
    e = jc(vt,-c);
end
end

function nu = vtmo(vt,zc,c,om,sj,tau0)
%VTMO  vartheta - om (om = c + i t1) without cancellation.  On the explosive
%   side (c > 0) the characteristic function varies on the scale t1 = O(e^{-c}),
%   t2 = O(e^{-2c}), where vartheta - c and i t1 are both O(e^{-c}) and their
%   difference is O(e^{-2c}); there it is formed as tau0/(vartheta + om)
%   (vartheta^2 - om^2 = tau0 = t1^2 - 2i t2), in the columns where
%   |vartheta + om| exceeds |vartheta - om|.  Elsewhere (in particular for c < 0,
%   where vartheta + om may be small) as (vartheta - c) - i t1.
nu = vtmc(vt,zc,c)-1i*sj;
if c > 0
    vpo = vt+om;
    q = abs(vpo(1,:)) > abs(nu(1,:));
    if any(q), nu(:,q) = jd(tau0(:,q),vpo(:,q)); end
end
end

function l = logp(a)
%LOGP  log of a jet with the principal argument of its constant coefficient.
l = jlog0(a);
l(1,:) = log(abs(a(1,:)))+1i*angle(a(1,:));
end

function l = logc(a,ph)
%LOGC  log of a jet with a prescribed (continuous) argument ph.
l = jlog0(a);
l(1,:) = log(abs(a(1,:)))+1i*ph;
end

% =========================================================================
function a = argtau4(z0,zc0,D2,T0)
%ARGTAU4  Continuous phase of tau_3/theta^2 as the sum of the principal
%   arguments of its three factors (paper, Section 6.1 and the Supplement):
%     tau_3/theta^2 = 4 W rho_inf S_inf,  W = (theta/2)cot(theta/2),
%   with Re W > 0, rho_inf (the limit of the rank-one factor 1 + kappa d_1)
%   off the closed negative real axis, and Re S_inf >= 0 (the limit of the
%   border Schur complement).  Each principal argument is continuous, hence
%   so is their sum.  D2 = tan(theta/2)/theta and zc0 = theta^2 + c^2.
D1 = zeros(size(z0)); sm = abs(z0) < 4;
D1(~sm) = (2*D2(~sm)-1)./z0(~sm);
if any(sm), D1(sm) = d1ser(z0(sm)); end     % (2 D2 - 1)/theta^2 by series
rho  = 1 + zc0.*D1;
Sinf = T0.*D2./(2*rho);
W    = 1./(2*D2);
a = angle(W)+angle(rho)+angle(Sinf);
end

function d = d1ser(z)
% D1 = (tan(u)/u - 1)/theta^2, u = theta/2: tan(u)/u = sum a_k u^{2k} by
% series division of sin(u)/u by cos(u); D1 = sum_{k>=1} (a_k/4)(z/4)^{k-1}
KM = 40; k = 0:KM;
sn = (-1).^k./factorial(2*k+1);  cs = (-1).^k./factorial(2*k);
a = zeros(1,KM+1);
for i = 0:KM
    acc = sn(i+1);
    for j = 1:i, acc = acc - cs(j+1)*a(i-j+1); end
    a(i+1) = acc;                            % cs(1) = 1
end
d = zeros(size(z)); w = z/4;
for i = KM:-1:1
    d = d.*w + a(i+1)/4;
end
end

function a = argcos(z)
%ARGCOS  Continuous argument of cos(theta) as a function of zeta = theta^2:
%   the principal argument shifted by the multiple of 2 pi that brings it
%   within pi/2 of -sign(theta_i) theta_r, which is where the continuous
%   argument lies (cos theta traces an ellipse of axes cosh theta_i and
%   sinh theta_i).  Even in theta, so any root may be used.
th = sqrt(z);
tr = real(th); ti = imag(th);
% the principal argument of cos th = cosh(ti)cos(tr) - i sinh(ti)sin(tr),
% computed from the sign pattern so that it cannot overflow
cz = cos(tr).*(1+exp(-2*abs(ti))) - 1i*sin(tr).*sign(ti).*(1-exp(-2*abs(ti)));
a  = angle(cz);
target = -sign(ti).*tr;
a  = a + 2*pi*round((target-a)/(2*pi));
end

% =========================================================================
function Nz = nquot(zeta,sj,c,tau1,tau2,C,S,Sh)
%NQUOT  N(zeta)/zeta with N = 2 tau1 Sh^2 - 4c^2 C + 4 tau2 S, which vanishes
%   at zeta = 0, by series (|zeta| < 4 only).
N  = size(zeta,2);  K = size(zeta,1)-1;
% tau1 = tau10 - 2c zeta, tau2 = tau20 + zeta with zeta-free parts
tau10 = tau1+2*c*zeta;
tau20 = tau2-zeta;
KM = 26;  k = 0:KM;
a = 2*(-1).^k./factorial(2*k+2);          % Sh^2 = 2(1-cos th)/zeta
b = (-1).^k./factorial(2*k);              % cos th
s = (-1).^k./factorial(2*k+1);            % sin th/th
% N/zeta = sum_{k>=1} n_k zeta^{k-1}, n_k = 2 tau10 a_k - 4c a_{k-1} - 4c^2 b_k + 4 tau20 s_k + 4 s_{k-1}
Nz = zeros(K+1,N);
for kk = KM:-1:1
    nk = jc(2*a(kk+1)*tau10 + 4*s(kk+1)*tau20, -4*c*a(kk) - 4*c^2*b(kk+1) + 4*s(kk));
    Nz = jm(Nz,zeta) + nk;
end
end

% =========================================================================
function [C,S,Sh,Ch,ShmCh] = jtrig(zeta)
%JTRIG  cos th, sin th/th, sin(th/2)/(th/2), cos(th/2) and (Sh-Ch)/th^2 as
%   functions of zeta = th^2 (all even in th), by series (|zeta| < 4 only).
KM = 26;  k = 0:KM;
cb  = (-1).^k./factorial(2*k);
cs  = (-1).^k./factorial(2*k+1);
csh = (-1).^k./(4.^k.*factorial(2*k+1));
cch = (-1).^k./(4.^k.*factorial(2*k));
cd  = zeros(1,KM+1);                      % (Sh-Ch)/zeta: sum_{k>=1} (-1)^{k+1} 2k zeta^{k-1}/(4^k (2k+1)!)
for kk = 1:KM+1
    cd(kk) = (-1)^(kk+1)*2*kk/(4^kk*factorial(2*kk+1));
end
C  = jser(cb,zeta);
S  = jser(cs,zeta);
Sh = jser(csh,zeta);
Ch = jser(cch,zeta);
ShmCh = jser(cd,zeta);
end

function y = jser(cf,z)
%JSER  sum_k cf(k+1) z^k for a jet z, by Horner.
y = zeros(size(z));
for k = numel(cf):-1:1
    y = jm(y,z);
    y(1,:) = y(1,:)+cf(k);
end
end

% =========================================================================
function L = trendlim(sj,tj,c,cas,par,om,zc,tau0,small)
%TRENDLIM  Cases 'DT' and 'ST' (intercept and linear trend; Online
%   Supplement, Theorem S7.2 and Section S7.5.3).  With vartheta^2 = c^2 - zc (Re vartheta >= 0),
%   E = e^{-vartheta}, h1 = (vartheta-2) + E(vartheta+2) and
%   h2 = -(vartheta^2-6 vartheta+12) + E(vartheta^2+6 vartheta+12),
%     psi = exp(-(om+vartheta)/2) [D3/(2 vartheta^8)]^{-1/2} exp(varkappa^2 tau0 h1 h2/(2 D3)),
%     D3 = h1 h2 Kb + (vartheta-c) B0(vartheta) + 8 zc B1 E - (vartheta+c) B0(-vartheta) E^2,
%   Kb = -4(c^2-3c+3) tau0 + c(c-2)(c^2-6c+12) i s, with the polynomials B0
%   (cubic in vartheta) and B1 (quadratic) below.  B0 is expanded about the
%   point vartheta = |c| at which vartheta -/+ c vanishes, and vartheta -/+ c
%   are formed without cancellation, so that nothing of order e^{2c} is lost
%   on the explosive side.  For |vartheta^2| < 16 the entire functions
%   e^{vartheta/2} h1/vartheta^3, e^{vartheta/2} h2/vartheta^5 and
%   e^{vartheta} G/vartheta^8 (G the last three terms of D3) are evaluated by
%   their power series in vartheta^2.  Branch: the phase is that of case 'DK'
%   (varkappa = 0) minus half the principal arguments of the three factors of
%   |K_DT|/|K_DK| = (1+k1)(1+k2) rho in the limit, each off the closed
%   negative real axis (Online Supplement, Proposition S7.6).
K = size(sj,1)-1;  N = size(sj,2);
is  = 1i*sj;
Kb  = -4*(c^2-3*c+3)*tau0 + c*(c-2)*(c^2-6*c+12)*is;
zv  = jc(-zc,c^2);                               % vartheta^2
Lr  = zeros(K+1,N);  Q = Lr;  g11 = zeros(1,N);  gll = g11;
if any(small)
    i = small;
    [f1,f2,Ge,ch,shc] = trendser(zv(:,i),c);
    f12 = jm(f1,f2);
    Psi = jm(f12,Kb(:,i)) + Ge;                  % e^{vartheta} D3/vartheta^8
    Lr(:,i) = -om(:,i)/2 - 0.5*logp(Psi);
    Lr(1,i) = Lr(1,i) + 0.5*log(2);
    Q(:,i)  = jd(jm(tau0(:,i),f12),2*Psi);
    g11(i)  = f1(1,:)./(2*ch);
    gll(i)  = -f2(1,:)./(24*shc);
end
big = ~small;
if any(big)
    i = big;
    vt  = jsq(zv(:,i));                          % Re vartheta >= 0
    E   = jexp(-vt);  E2 = jm(E,E);
    z_  = zc(:,i);
    if c >= 0
        vmc = jd(-z_,jc(vt,c));                  % vartheta - c
        vpc = jc(vt,c);
        Bp  = bpoly(vmc,c,1);                    % B0(vartheta)
        Bm  = bpoly(-vmc,c,-1);                  % B0(-vartheta)
    else
        vpc = jd(-z_,jc(vt,-c));                 % vartheta + c
        vmc = jc(vt,-c);
        Bp  = bpoly(vpc,c,-1);
        Bm  = bpoly(-vpc,c,1);
    end
    v2  = zv(:,i);
    B1  = jc((c-3)*(c^2-4*c+6)*v2,-6*(c^3-5*c^2+12*c-12));
    h1  = jc(vt,-2) + jm(E,jc(vt,2));
    h2  = -jc(v2-6*vt,12) + jm(E,jc(v2+6*vt,12));
    h12 = jm(h1,h2);
    if c > 0
        % Explosive side (Online Supplement, Section S7.5.3): on the scale
        % t1 = O(e^{-c}), t2 = O(e^{-2c}) the terms h1 h2 Kb and
        % (vartheta-c) B0(vartheta) are O(e^{-c}) and cancel, D3 being
        % O(e^{-2c}).  With K1 = c(c-2)(c^2-6c+12), P3 = vartheta^3 -
        % 8 vartheta^2 + 24 vartheta - 24, Pp = vartheta^3 + 8 vartheta^2 +
        % 24 vartheta + 24 and Qc = (c-3)vartheta - 3(c-2), the identities
        % i t1 = (vartheta-c) - tau0/(vartheta+om), h1 h2 = -P3 +
        % 8(vartheta^2-6)E + Pp E^2 and B0(vartheta) - K1 P3 =
        % 8(vartheta-c) Qc^2 give
        %   D3 = 8(vartheta-c)^2 Qc^2 + K1(vartheta-c)[8(vartheta^2-6)E + Pp E^2]
        %        - tau0 h1 h2 [K1/(vartheta+om) + 4(c^2-3c+3)]
        %        + 8 zc B1 E - (vartheta+c) B0(-vartheta) E^2,
        % in which every term is O(e^{-2c}); Re(vartheta+om) >= c > 0.
        K1  = c*(c-2)*(c^2-6*c+12);
        Pp  = jc(jm(vt,jc(v2+8*vt,24)),24);      % vt^3+8vt^2+24vt+24
        Qc  = jc((c-3)*vt,-3*(c-2));             % (c-3)vt - 3(c-2)
        vQ  = jm(vmc,Qc);
        T1  = 8*jm(vQ,vQ);
        T2  = K1*jm(vmc,8*jm(jc(v2,-6),E) + jm(Pp,E2));
        T3  = -jm(jm(tau0(:,i),h12),jc(jd(K1,vt+om(:,i)),4*(c^2-3*c+3)));
        D3  = T1 + T2 + T3 + 8*jm(z_,jm(B1,E)) - jm(vpc,jm(Bm,E2));
    else
        G   = jm(vmc,Bp) + 8*jm(z_,jm(B1,E)) - jm(vpc,jm(Bm,E2));
        D3  = jm(h12,Kb(:,i)) + G;
    end
    Lr(:,i) = -(om(:,i)+vt)/2 - 0.5*(logp(D3) - 8*logp(vt));
    Lr(1,i) = Lr(1,i) + 0.5*log(2);
    Q(:,i)  = jd(jm(tau0(:,i),h12),2*D3);
    v0 = vt(1,:);  e0 = E(1,:);
    g11(i) = h1(1,:)./(v0.^3.*(1+e0));
    gll(i) = -h2(1,:)./(12*v0.^4.*(1-e0));
end
% ---- the continuous phase from the factors ------------------------------
L0  = ar1lim_logcf(sj(1,:),tj(1,:),c,'DK',0);  % case DK at varkappa = 0
z1  = zc(1,:);  s1 = sj(1,:);
tr  = z1.*(g11+12*gll);
dt  = (12*z1.^2+144*s1.^2).*g11.*gll;
sq  = sqrt(tr.^2-4*dt);
k1  = (tr+sq)/2;  k2 = (tr-sq)/2;
rho = exp(2*(L0-Lr(1,:)))./(1+tr+dt);
ph  = imag(L0) - 0.5*(angle(1+k1)+angle(1+k2)+angle(rho));
L   = Lr;
L(1,:) = real(Lr(1,:)) + 1i*ph;
if strcmp(cas,'DT')
    if par ~= 0, L = L + par^2*Q; end
else
    L = L - 0.5*logp(jc(c^3*Q,1));             % varkappa ~ N(0,-c^3/2)
end
end

function B = bpoly(u,c,sg)
%BPOLY  B0(vartheta) expanded about vartheta = c (sg = 1) or vartheta = -c
%   (sg = -1), u = vartheta -/+ c.
c4 = c^4-8*c^3+32*c^2-72*c+72;
if sg > 0
    b0 = c*(c-2)^2*(c^2-6*c+12)^2;
    b1 = 3*c^6-40*c^5+232*c^4-744*c^3+1344*c^2-1152*c+288;
    b2 = 3*c^5-32*c^4+152*c^3-408*c^2+576*c-288;
else
    b0 = -c^7;
    b1 = 3*c^6-8*c^5+8*c^4+24*c^3-96*c^2+288;
    b2 = -3*c^5+16*c^4-40*c^3+24*c^2+144*c-288;
end
B = jc(jm(jc(jm(jc(c4*u,b2),u),b1),u),b0);
end

function [f1,f2,Ge,ch,shc] = trendser(zv,c)
%TRENDSER  Power series in zv = vartheta^2 (|zv| < 16) of
%   f1 = e^{vartheta/2} h1/vartheta^3, f2 = e^{vartheta/2} h2/vartheta^5,
%   Ge = e^{vartheta} G/vartheta^8, and (constants) cosh(vartheta/2),
%   sinh(vartheta/2)/vartheta.  With f = (vartheta-c) B0(vartheta) =
%   sum_j gam_j vartheta^j, e^{vartheta} G = f(vartheta)e^{vartheta} +
%   f(-vartheta)e^{-vartheta} + 8(c^2-vartheta^2)B1, whose coefficient of
%   vartheta^{2k} is 2 sum_j gam_j/(2k-j)! for k >= 4 (the lower ones vanish).
KM = 40;  j = 1:KM+2;
a1 = 4*j./(4.^j.*factorial(2*j+1));                       % zv^(j-1)
jj = 2:KM+3;
a2 = (12./factorial(2*jj) - 4./factorial(2*jj-1) - 12./factorial(2*jj+1))./4.^jj;  % zv^(jj-2)
gam = [24*c^2*(c-2)*(c^2-3*c+6), -24*c^2*(c-2)*(c^2-3*c+6), ...
       8*(c^5-4*c^4+6*c^3+6*c^2-36*c+36), -c^5+24*c^3-120*c^2+288*c-288, ...
       c^4-8*c^3+32*c^2-72*c+72];
k = 4:KM+4;  ag = zeros(1,numel(k));
for jg = 0:4
    ag = ag + 2*gam(jg+1)./factorial(2*k-jg);
end
f1 = jser(a1,zv);  f2 = jser(a2,zv);  Ge = jser(ag,zv);
z0 = zv(1,:);  kk = 0:KM;
ch  = polyval(fliplr(1./(4.^kk.*factorial(2*kk))),z0);
shc = polyval(fliplr(1./(2.^(2*kk+1).*factorial(2*kk+1))),z0);
end
