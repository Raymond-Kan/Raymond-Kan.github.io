function [m,err] = ar1lim_mom(k,c,cas,par,x0,tol)
%AR1LIM_MOM  Moments of the local-to-unity limit of n(phihat - phi).
%
%   m = AR1LIM_MOM(k,c,cas,par) returns m(j) = E[(A/B)^j], j = 1..k, for the
%   limit A/B of n(phihat-phi) (AR1LIM_LOGCF); m = AR1LIM_MOM(k,c,cas,par,x0)
%   returns the moments about x0; [m,err] also returns the error estimates
%   (RATIO_MOM).  All moments of the limit exist.
%
%   See also AR1LIM_CDF, AR1LIM_LOGCF, RATIO_MOM.
if nargin < 4 || isempty(par), par = 0; end
if nargin < 5 || isempty(x0), x0 = 0; end
if nargin < 6, tol = []; end
h = @(t1,t2) ar1lim_logcf(t1,t2,c,cas,par);
[m,err] = ratio_mom(h,k,x0,tol);
end
