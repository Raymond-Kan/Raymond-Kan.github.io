function opts = ar1lim_opts(c,cas,par)
%AR1LIM_OPTS  Quadrature options of the inversion engines for the limiting
%   distributions: a finite interval [0,S] completed by the asymptotic tail
%   expansion of RATIO_CDF / RATIO_PDF, with w0 the slope of the dominant
%   linear phase of the characteristic function along the inversion paths
%   (1/2 from the factor e^{-omega/2}, plus gamma_0^2/2 from the noncentral
%   factor in case 'DK'; in the trend cases the factor exp(-(omega+vartheta)/2)
%   D^{-1/2} has the same slope, and the exponent in varkappa is bounded),
%   and S such that w0 S = 400.
%   See also AR1LIM_CDF, AR1LIM_PDF, RATIO_CDF.
cas = upper(char(cas));
w0 = 0.5;
if strcmp(cas,'DK'), w0 = (1+par^2)/2; end
opts = struct('w0',w0,'S',400/w0,'K',8);
end
