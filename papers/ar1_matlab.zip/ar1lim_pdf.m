function [f,err] = ar1lim_pdf(x,c,cas,par,tol)
%AR1LIM_PDF  Density of the local-to-unity limit of n(phihat - phi).
%
%   f = AR1LIM_PDF(x,c,cas,par); inputs as in AR1LIM_CDF.  [f,err] also
%   returns the error estimate of RATIO_PDF.
%
%   Along the ray x = -c the characteristic function of A + cB decays only
%   algebraically (Section 6.1 of the paper), and the Geary integrand of the
%   density, which carries no factor 1/t1, is not even absolutely integrable
%   there; it converges conditionally.  The integral is therefore taken over
%   a finite interval and completed by the asymptotic tail expansion of
%   RATIO_PDF (see AR1LIM_CDF), which is valid uniformly in x and yields the
%   density at and near x = -c without numerical differentiation.
%
%   See also AR1LIM_CDF, AR1LIM_ICDF, AR1LIM_MOM, AR1LIM_LOGCF.
if nargin < 4 || isempty(par), par = 0; end
if nargin < 5, tol = []; end
if ~(isnumeric(x) && isreal(x) && all(isfinite(x(:))))
    error('ar1lim:x','x must be real and finite.');
end
h = @(t1,t2) ar1lim_logcf(t1,t2,c,cas,par);
[f,err] = ratio_pdf(h,x,tol,ar1lim_opts(c,cas,par));
end
