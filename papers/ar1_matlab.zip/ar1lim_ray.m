function [P,err] = ar1lim_ray(c,cas,par)
%AR1LIM_RAY  The local-to-unity limit cdf at the point x = -c in closed form.
%
%   [P,err] = AR1LIM_RAY(c,cas,par) returns P[A/B < -c] = P[A + cB < 0] for
%   the limit A/B of n(phihat - phi) (AR1LIM_LOGCF; cases and par as there),
%   and an estimate of the quadrature error.  Along the ray t2 = c t1 the
%   characteristic function of A + cB is that of a chi-square type variable
%   (Supplement, Section S2):
%
%     'DK'  A + cB = [c_0 chi^2_1(delta) - (1 + gamma_0^2)]/2,
%           c_0 = (e^{2c}-1)/(2c), delta = gamma_0^2 e^{2c}/c_0, so that
%           P = Phi_N(a - sqrt(delta)) - Phi_N(-a - sqrt(delta)), a = sqrt((1+gamma_0^2)/c_0);
%     'DU'  A + cB = lambda_1 X_1 - lambda_2 X_2 - 1/2, X_j ~ chi^2_1(mu_j)
%           independent, lambda_{1,2} = (varsigma +- c_5)/4, c_4 = (e^c-1)/c,
%           c_5 = c_0 - c_4^2, varsigma = (c_5^2 + 4c_5/c^2)^{1/2},
%           mu_1 = (varkappa^2/2)[1 - (c-4)c_5/(c varsigma)], mu_2 = varkappa^2 - mu_1,
%           so that P = P[lambda_1 X_1 - lambda_2 X_2 < 1/2], a one-dimensional
%           integral of the noncentral chi-square cdf F_1 against the standard
%           normal density: with X_2 = (Z + sqrt(mu_2))^2,
%             P = int F_1((1/2 + lambda_2 (z + sqrt(mu_2))^2)/lambda_1) phi_N(z) dz,
%           integrated over [-12, 12] (the omitted normal mass is below 4e-33)
%           with breakpoints at the kink z = -sqrt(mu_2) and where the argument
%           of F_1 crosses mu_1;
%     'SK'  A + cB = lambda_c (Z_1^2 - Z_2^2) - 1/2 with lambda_c =
%           sqrt(1 - e^{2c})/(-4c) (Supplement, Section S2), so that
%             P = P[Z_1^2 - Z_2^2 < 1/(2 lambda_c)] = int F_chi2(a + z^2) phi_N(z) dz,
%           a = 1/(2 lambda_c), F_chi2 the central chi^2_1 cdf;
%     'SU'  the mixture of case 'DU' over varkappa = c gamma_0 ~ N(0,-c/2),
%           integrated over the standardized variable on [-12, 12];
%     'DT'  A + cB = Y'Lam Y - 1/2 with Y = (X(1), int X, int r X) normal,
%           X = J_c + varkappa H_c (Online Supplement, Section S7.5.5),
%           and, given the last two coordinates, the event is a quadratic
%           inequality in X(1), whose probability is explicit; the remaining
%           two-dimensional normal integral is done by nested quadrature;
%     'ST'  as 'DT' with varkappa ~ N(0,-c^3/2) integrated out.
%
%   At c = 0 and par = 0 these are 2Phi(1)-1 = 0.68268949 and
%   P[X_1 - X_2 < 2 sqrt 3] = 0.95756559.  The routine is used by AR1LIM_CDF
%   at x = -c, where the inversion integral converges slowly, and serves as
%   a check of the asymptotic tail treatment of RATIO_CDF.
%
%   (An earlier version integrated the folded normal density over
%   [0, Inf) in the original variable, which missed the mass near
%   y = sqrt(mu_2) for large varkappa, e.g. varkappa = 200 at c = 0.)
%
%   See also AR1LIM_CDF, AR1LIM_LOGCF.
if nargin < 3 || isempty(par), par = 0; end
cas = upper(cas);
switch cas
    case 'DK', P = pfk(c,par); err = 4*eps;
    case 'DU', [P,err] = pfu(c,par);
    case 'SK'
        if c >= 0, error('ar1lim:c','A stationary start requires c < 0.'); end
        lc = sqrt(-expm1(2*c))/(-4*c);
        a  = 1/(2*lc);
        % P[Z1^2 - Z2^2 < a] = E[F_chi2(a + Z2^2)], F_chi2(y) = erf(sqrt(y/2))
        ig = @(z) erf(sqrt(max(a + z.^2,0)/2)).*npdf(z);
        wp = [];
        if a < 0 && sqrt(-a) < 12, wp = [-sqrt(-a) sqrt(-a)]; end
        [P,err] = quadgk(ig,-12,12,'Waypoints',wp,'AbsTol',1e-14,'RelTol',1e-12);
    case 'SU'
        if c >= 0, error('ar1lim:c','A stationary start requires c < 0.'); end
        sg = sqrt(-c/2);                       % kappa = c gamma_0 ~ N(0,-c/2)
        [P,err] = quadgk(@(z) arrayfun(@(zz) pfu(c,sg*zz),z).*npdf(z),-12,12,'AbsTol',1e-12,'RelTol',1e-10);
        err = err + 1e-13;                     % the inner quadratures
    case 'DT', [P,err] = pft(c,par,0);
    case 'ST'
        if c >= 0, error('ar1lim:c','A stationary start requires c < 0.'); end
        [P,err] = pft(c,0,-c^3/2);
    otherwise
        error('ar1lim:cas','cas must be one of ''DK'', ''DU'', ''SK'', ''SU'', ''DT'', ''ST''.');
end
end

function [P,err] = pft(c,kap,vk)
%PFT  Cases 'DT' and 'ST': A + cB = int Xhat dX = Y'Lam Y - 1/2 with
%   Y = (X(1), int X, int r X), X = J_c + varkappa H_c, and
%   Lam = [1/2 1 -3; 1 -6 6; -3 6 0] (Online Supplement, Section S7.5.5).  Y is normal
%   with covariance Sig (that of the Ornstein-Uhlenbeck functionals) and mean
%   varkappa m; in case 'ST' varkappa ~ N(0,vk) is integrated out, giving
%   covariance Sig + vk m m'.  For c > 2 the coordinates are changed to
%   Yt = (X(1), int X - X(1)/c, int r X - (1/c - 1/c^2) X(1)), whose last two
%   kernels, -1/c and -1/c + 1/c^2 + (1-s)/c, do not grow like e^{c(1-s)}, so
%   that the covariance is well conditioned for every c.  Given the last two
%   coordinates, X(1) is normal and the event is a quadratic inequality in
%   it, whose probability is explicit; the remaining two-dimensional normal
%   integral is done by nested adaptive quadrature with breakpoints at the
%   kinks (where the discriminant vanishes).
Lam = [1/2 1 -3; 1 -6 6; -3 6 0];
[Sg,m,T] = oumom(c);
Lt = T'*Lam*T;
Sg = Sg + vk*(m*m');
mu = kap*m;
% Yt1 | (Yt2,Yt3) ~ N(mu1 + B (y - mu23), s1^2)
S23 = Sg(2:3,2:3);  B = Sg(1,2:3)/S23;
s1 = sqrt(max(Sg(1,1) - B*Sg(2:3,1),0));
R = chol(S23)';                                % S23 = R R'
f = @(w2,w3) condp(w2,w3,mu,B,s1,R,Lt);
[P,err] = quadgk(@(w3) arrayfun(@(z) inner(z,f,mu,B,s1,R,Lt),w3).*npdf(w3),-12,12, ...
    'AbsTol',1e-15,'RelTol',1e-12);
err = err + 1e-13;
end

function v = inner(w3,f,mu,B,s1,R,Lt)
% int f(w2,w3) phi(w2) dw2 with breakpoints where the discriminant vanishes
% (it is quadratic in w2)
dsc = @(w2) disc(w2,w3,mu,B,s1,R,Lt);
d0 = dsc(0); d1 = dsc(1); dm = dsc(-1);
qa = (d1+dm)/2-d0;  qb = (d1-dm)/2;  qc = d0;
wp = [];
if abs(qa) > 0
    dd = qb^2-4*qa*qc;
    if dd > 0
        r = [(-qb-sqrt(dd))/(2*qa), (-qb+sqrt(dd))/(2*qa)];
        wp = r(r > -12 & r < 12);
    end
elseif qb ~= 0
    r = -qc/qb; if abs(r) < 12, wp = r; end
end
v = quadgk(@(w2) f(w2,w3).*npdf(w2),-12,12,'AbsTol',1e-16,'RelTol',1e-12,'Waypoints',sort(wp));
end

function [D,l,q,m1] = quadco(w2,w3,mu,B,R,Lt)
% Yt'Lt Yt - 1/2 = L11 y^2 + 2 y l + q in y = Yt1, whose roots are real when
% D = l^2 - L11 q > 0; m1 is the conditional mean of Yt1
y = mu(2:3) + R*[w2(:)'; w3*ones(1,numel(w2))];   % 2 x N
m1 = mu(1) + B*(y - mu(2:3));
l = Lt(1,2:3)*y;
q = sum(y.*(Lt(2:3,2:3)*y),1) - 1/2;
D = l.^2 - Lt(1,1)*q;
end

function d = disc(w2,w3,mu,B,~,R,Lt)
d = quadco(w2,w3,mu,B,R,Lt);
end

function p = condp(w2,w3,mu,B,s1,R,Lt,~)
% P[L11 Yt1^2 + 2 Yt1 l + q < 0] with Yt1 ~ N(m1, s1^2), L11 > 0
[D,l,q,m1] = quadco(w2,w3,mu,B,R,Lt);
L11 = Lt(1,1);
p = zeros(size(D));
k = D > 0;
sd = sqrt(D(k));
ya = -(l(k) + sign(l(k)+(l(k)==0)).*sd)/L11;     % stable roots
yb = q(k)./(L11*ya);
lo = (min(ya,yb) - m1(k))/s1;  hi = (max(ya,yb) - m1(k))/s1;
p(k) = pint(lo,hi);
p = reshape(p,size(w2));
end

function p = pint(a,b)
% Phi(b) - Phi(a), b >= a, without loss when b - a is small
d = b - a;  mid = (a + b)/2;
p = Phi(b) - Phi(a);
sm = d < 1e-3;
p(sm) = npdf(mid(sm)).*d(sm).*(1 + (mid(sm).^2-1).*d(sm).^2/24);
tl = ~sm & a > 0;                               % upper tail: use the complements
p(tl) = Phi(-a(tl)) - Phi(-b(tl));
end

function [S,m,T] = oumom(c)
%OUMOM  Covariance S and mean m (per unit varkappa) of the coordinates
%   T^{-1} Y, Y = (X(1), int X, int r X): T = I for c <= 2 (64-point
%   Gauss-Legendre for |c| <= 20, closed forms below -20), and for c > 2 the
%   well-conditioned coordinates of PFT, in closed form.
T = eye(3);
if c > 2
    E = exp(c);  al = -1/c + 1/c^2;
    S = zeros(3);
    S(1,1) = expm1(2*c)/(2*c);
    S(1,2) = -expm1(c)/c^2;
    S(1,3) = al*expm1(c)/c + (E*(c-1)+1)/c^3;
    S(2,2) = 1/c^2;
    S(2,3) = -(al + 1/(2*c))/c;
    S(3,3) = al^2 + al/c + 1/(3*c^2);
    S = S + triu(S,1).';
    m = [(E-1-c)/c^2; -1/(2*c); 1/(2*c^2) - 1/(3*c)];
    T = [1 0 0; 1/c 1 0; 1/c-1/c^2 0 1];
elseif c >= -20
    [x,w] = glnodes(64);  s = (x+1)/2;  w = w/2;
    u = 1-s;
    E1 = ex1(c*u).*u;                          % (e^{cu}-1)/c
    E2 = ex2(c*u).*u.^2;                       % (e^{cu}-1-cu)/c^2
    k = [exp(c*u), E1, E1-E2];                 % kernels of X(1), int X, int r X
    S = k'*(k.*w);
    H = ex2(c*s).*s.^2;
    m = [ex2(c); sum(w.*H); sum(w.*s.*H)];
else
    th = c;  E = exp(th);
    S = zeros(3);
    S(1,1) = (E^2-1)/(2*th);
    S(1,2) = (E^2/2-E+1/2)/th^2;
    S(1,3) = E^2/(2*th^2)-E^2/(2*th^3)+1/(2*th^2)+1/(2*th^3);
    S(2,2) = E^2/(2*th^3)-2*E/th^3+1/th^2+3/(2*th^3);
    S(2,3) = E^2/(2*th^3)-E^2/(2*th^4)-E/th^3+E/th^4+1/(2*th^2)+1/(2*th^3)-1/(2*th^4);
    S(3,3) = E^2/(2*th^3)-E^2/th^4+E^2/(2*th^5)+1/(3*th^2)+1/(2*th^3)-1/(2*th^5);
    S = S+triu(S,1).';
    m = [(E-1-c)/c^2; ((E-1)/c-1-c/2)/c^2; ((E*(c-1)+1)/c^2-1/2-c/3)/c^2];
end
end

function v = ex1(x)
% (e^x - 1)/x
v = ones(size(x));  nz = x ~= 0;  v(nz) = expm1(x(nz))./x(nz);
end

function v = ex2(x)
% (e^x - 1 - x)/x^2, by series for |x| < 0.5
v = zeros(size(x));  sm = abs(x) < 0.5;
xs = x(sm);  acc = zeros(size(xs));
for k = 20:-1:0, acc = acc.*xs + 1/factorial(k+2); end
v(sm) = acc;
xb = x(~sm);  v(~sm) = (expm1(xb)-xb)./xb.^2;
end

function [x,w] = glnodes(N)
% Gauss-Legendre nodes and weights on [-1,1] (Golub-Welsch)
b = (1:N-1)./sqrt(4*(1:N-1).^2-1);
[V,D] = eig(diag(b,1)+diag(b,-1));
x = diag(D);  w = 2*V(1,:)'.^2;
end

function P = pfk(c,g0)
c0 = cexp(2*c);                                % (e^{2c}-1)/(2c)
dl = g0^2*exp(2*c)/c0;
a  = sqrt((1+g0^2)/c0);
P  = Phi(a-sqrt(dl))-Phi(-a-sqrt(dl));
end

function [P,err] = pfu(c,kap)
c0 = cexp(2*c);  c1 = cexp(c);
if abs(c) < 0.25
    % c_5 = c_0 - c_4^2 cancels to O(c^2); its series about c = 0
    co = [1/12 1/12 17/360 7/360 43/6720 107/60480 769/1814400 163/1814400 ...
          4097/239500800 709/239500800 6827/14529715200 15019/217945728000 ...
          19661/2092278988800 1139/951035904000];
    c2 = c^2*polyval(co(end:-1:1),c);
    q  = polyval(co(end:-1:1),c);              % c_5/c^2
else
    c2 = c0-c1^2;  q = c2/c^2;
end
vs = sqrt(c2^2+4*q);
l1 = (vs+c2)/4;
l2 = q/(vs+c2);                                % = (vs - c2)/4 without cancellation at large c
if c == 0, d1 = kap^2/2; else d1 = kap^2/2*(1-(c-4)*c2/(c*vs)); end
d2 = kap^2-d1;
sd1 = sqrt(d1);  sd2 = sqrt(d2);
F1 = @(y) Phi(sqrt(y)-sd1)-Phi(-sqrt(y)-sd1);  % noncentral chi^2_1(d1) cdf
% X_2 = (z + sqrt(d2))^2 with z standard normal:
% P[l1 X1 - l2 X2 < 1/2] = int F1((1/2 + l2 (z + sqrt d2)^2)/l1) phi_N(z) dz
ig = @(z) F1((0.5+l2*(sd2+z).^2)/l1).*npdf(z);
wp = [];
if sd2 < 12, wp(end+1) = -sd2; end             % the kink of |z + sqrt d2|
ys = (l1*d1-0.5)/l2;                           % where the argument of F1 equals d1
if ys > 0
    for sg = [-1 1]
        zz = sg*sqrt(ys)-sd2;
        if abs(zz) < 12, wp(end+1) = zz; end  %#ok<AGROW>
    end
end
[P,err] = quadgk(ig,-12,12,'Waypoints',sort(wp),'AbsTol',1e-14,'RelTol',1e-12);
end

function v = cexp(x)
% (e^x - 1)/x, equal to 1 at x = 0
if x == 0, v = 1; else v = expm1(x)/x; end
end

function p = Phi(x)
p = 0.5*erfc(-x/sqrt(2));
end

function f = npdf(x)
f = exp(-x.^2/2)/sqrt(2*pi);
end
