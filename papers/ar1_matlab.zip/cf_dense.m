function val = cf_dense(s,t,n,phi,cas,par0)
%CF_DENSE  Dense O(n^3) reference for the joint characteristic function of (u,v)
%   by eigen-decomposition (used by AR1_TEST only).
%   val = CF_DENSE(t1,t2,n,phi,cas,par0) returns phi(t1,t2) = E exp(i t1 u + i t2 v)
%   by brute-force eigen-decomposition (O(n^3)); one decomposition per ray
%   t2 = -r t1 when t1, t2 are vectors along a ray.
cas = upper(cas);
Jt = [eye(n) zeros(n,1)]; P = [zeros(n,1) eye(n)];
if cas(2)=='U', M = eye(n)-ones(n)/n;
elseif cas(2)=='T', X = [ones(n,1) (1:n)'-(n+1)/2]; M = eye(n)-X*((X'*X)\X');
else M = eye(n); end
Au = (Jt'*M*(P-phi*Jt) + (P-phi*Jt)'*M*Jt)/2;
Av = Jt'*M*Jt;
if cas(1)=='D'
  L = toeplitz(phi.^(0:n-1), [1 zeros(1,n-1)]);
  if cas(2)=='K'
    z0 = par0; mu = [z0; z0*phi.^(1:n)'];
  elseif cas(2)=='U'
    gam = par0; % w_t = gam + phi w_{t-1} + e_t, w_0 = 0
    mu = [0; L*(gam*ones(n,1))];
  else
    % w_t = gam + gtau (t-(n+1)/2) + phi w_{t-1} + e_t, w_0 = 0
    if numel(par0) < 2, par0 = [par0 0]; end
    mu = [0; L*(par0(1) + par0(2)*((1:n)'-(n+1)/2))];
  end
  C = [zeros(1,n); L];   % (n+1) x n
else
  V = toeplitz(phi.^(0:n))/(1-phi^2);
  C = chol(V)'; mu = zeros(n+1,1);
end
val = zeros(size(s));
% along a ray t = -r s the matrix of s u + t v is s (A_u - r A_v): one
% eigen-decomposition serves all the points
if numel(s) > 1 && all(s ~= 0) && all(abs(t + (-t(1)/s(1))*s) <= 4*eps*abs(t))
  r = -t(1)/s(1);
  A = Au - r*Av; G = C'*A*C; G = (G+G')/2;
  [Q,D] = eig(G); lam = diag(D);
  bt = Q'*(C'*A*mu); q0 = mu'*A*mu;
  for k = 1:numel(s)
    val(k) = prod((1-2i*s(k)*lam).^(-1/2)) * exp(1i*s(k)*q0 - 2*s(k)^2*sum(bt.^2./(1-2i*s(k)*lam)));
  end
  return
end
for k = 1:numel(s)
  A = s(k)*Au + t(k)*Av;
  G = C'*A*C; G = (G+G')/2;
  [Q,D] = eig(G); lam = diag(D);
  b = C'*A*mu;
  bt = Q'*b;
  val(k) = prod((1-2i*lam).^(-1/2)) * exp(1i*mu'*A*mu - 2*sum(bt.^2./(1-2i*lam)));
end
end
