function dfcompare(outfile)
%DFCOMPARE  Compare adftest (Econometrics Toolbox; simulated tables, 5e6
%   replications per tabulated sample size, interpolated) with the exact
%   distribution of the normalized-bias Dickey-Fuller statistic.
%   adftest 'Test','t2' with 'Lags',0 is (T-1)(phihat-1) from the regression
%   of y_t on y_{t-1} over t = 2..T; 'AR' has no intercept, 'ARD' has one.
%   Exact counterparts: 'ARD' = case DU with n = T-1 (the distribution at
%   phi = 1 does not depend on y_0); 'AR' = case DK with n = T and z0 = 0
%   (the term t = 1 contributes nothing), statistic scaled by (T-1)/T.
fid = fopen(outfile,'w');
Ts = [11 15 20 25 30 40 50 75 100 150 200 250 500 1000 2000 5000 10000];
al = [0.01 0.025 0.05 0.10];
for mdl = {'AR','ARD'}
    for T = Ts
        y = cumsum(randn(T,1));
        adftest(y,'Model',mdl{1},'Test','t2','Lags',0,'Alpha',al);
        tic; [~,~,~,cv] = adftest(y,'Model',mdl{1},'Test','t2','Lags',0,'Alpha',al); t1 = toc;
        if strcmp(mdl{1},'ARD')
            tic; q = (T-1)*(ar1_icdf(al,T-1,1,'DU',0)-1); t2 = toc;
        else
            tic; q = (T-1)*(ar1_icdf(al,T,1,'DK',0)-1); t2 = toc;
        end
        fprintf(fid,'cv %s & %d &%s &%s & %.4f & %.4f \\\\\n', mdl{1}, T, sprintf(' %.3f',cv), sprintf(' %.3f',q), t1, t2);
    end
end
R = 2000;
for mdl = {'AR','ARD'}
    for T = [25 100 500]
        rng(T); e = randn(T,R); Y = cumsum(e); pm = zeros(1,R); st = zeros(1,R);
        tic; for r = 1:R, [~,pm(r),st(r)] = adftest(Y(:,r),'Model',mdl{1},'Test','t2','Lags',0); end; tm = toc/R;
        if strcmp(mdl{1},'ARD')
            tic; pe = ar1_cdf(1+st/(T-1),T-1,1,'DU',0); te = toc/R;
        else
            tic; pe = ar1_cdf(1+st/(T-1),T,1,'DK',0); te = toc/R;
        end
        d = pm-pe; tail = pe < 0.1;
        fprintf(fid,'pv %s T=%d: max|d| %.4f, rms %.4f; p<0.1: max|d| %.4f, rms %.4f, mean d %.4f (%d pts); time/call adftest %.2e exact %.2e\n', ...
            mdl{1}, T, max(abs(d)), sqrt(mean(d.^2)), max(abs(d(tail))), sqrt(mean(d(tail).^2)), mean(d(tail)), nnz(tail), tm, te);
        % a few extreme points
        [~,ix] = sort(pe); ix = ix(1:5);
        fprintf(fid,'   smallest: stat %s | adftest p %s | exact p %s\n', mat2str(st(ix),5), mat2str(pm(ix),4), mat2str(pe(ix),4));
    end
end
fclose(fid);
end
