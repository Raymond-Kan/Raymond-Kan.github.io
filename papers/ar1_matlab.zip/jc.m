function c = jc(a,v)
%JC  Add a constant to a jet (truncated power series): its constant coefficient only.
%   A jet is a (K+1) x N array whose k-th row holds the coefficient of order k-1.
c = a;
c(1,:) = c(1,:) + v;
end
