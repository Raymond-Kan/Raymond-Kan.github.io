function [c,s] = jcos(a)
%JCOS  Cosine and sine of a jet (truncated power series).
K = size(a,1)-1;
c = zeros(size(a)); s = c;
c(1,:) = cos(a(1,:)); s(1,:) = sin(a(1,:));
for k = 1:K
    accc = zeros(1,size(a,2)); accs = accc;
    for j = 1:k
        accc = accc - (j/k)*a(j+1,:).*s(k-j+1,:);
        accs = accs + (j/k)*a(j+1,:).*c(k-j+1,:);
    end
    c(k+1,:) = accc; s(k+1,:) = accs;
end
end
