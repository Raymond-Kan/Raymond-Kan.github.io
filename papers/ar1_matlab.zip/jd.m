function c = jd(a,b)
%JD  Quotient of two jets (truncated power series).
if size(a,1) == 1 && size(b,1) > 1, a = [a; zeros(size(b,1)-1,size(a,2))]; end
if size(b,1) == 1 && size(a,1) > 1, b = [b; zeros(size(a,1)-1,size(b,2))]; end
if size(a,2) == 1 && size(b,2) > 1, a = repmat(a,1,size(b,2)); end
if size(b,2) == 1 && size(a,2) > 1, b = repmat(b,1,size(a,2)); end
K = size(b,1)-1;
c = zeros(size(b));
c(1,:) = a(1,:)./b(1,:);
for k = 1:K
    acc = a(k+1,:);
    for j = 1:k
        acc = acc - b(j+1,:).*c(k-j+1,:);
    end
    c(k+1,:) = acc./b(1,:);
end
end
