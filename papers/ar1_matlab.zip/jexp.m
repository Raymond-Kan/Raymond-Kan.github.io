function e = jexp(a)
%JEXP  Exponential of a jet (truncated power series).
e = jexp0(a).*exp(a(1,:));
end
