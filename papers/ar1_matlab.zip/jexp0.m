function e = jexp0(a)
%JEXP0  Exponential of a jet whose constant coefficient is ignored (set to zero).
K = size(a,1)-1;
e = zeros(size(a));
e(1,:) = 1;
for k = 1:K
    acc = zeros(1,size(a,2));
    for j = 1:k
        acc = acc + (j/k)*a(j+1,:).*e(k-j+1,:);
    end
    e(k+1,:) = acc;
end
end
