function L = jlog0(a)
%JLOG0  Logarithm of a jet with its constant coefficient set to zero.
%   The derivative coefficients of log a depend on a alone and carry no
%   branch; the constant coefficient (the branch) is left to the caller.
K = size(a,1)-1;
L = zeros(size(a));
for m = 1:K
    acc = a(m+1,:);
    for i = 1:m-1
        acc = acc - (i/m)*L(i+1,:).*a(m-i+1,:);
    end
    L(m+1,:) = acc./a(1,:);
end
end
