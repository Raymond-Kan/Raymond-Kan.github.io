function c = jm(a,b)
%JM  Product of two jets (truncated power series): the Cauchy product.
%   Either argument may be a plain row (a jet with a single coefficient),
%   or have a single column, which is then broadcast.
if size(a,1) == 1 && size(b,1) > 1, a = [a; zeros(size(b,1)-1,size(a,2))]; end
if size(b,1) == 1 && size(a,1) > 1, b = [b; zeros(size(a,1)-1,size(b,2))]; end
if size(a,2) == 1 && size(b,2) > 1, a = repmat(a,1,size(b,2)); end
if size(b,2) == 1 && size(a,2) > 1, b = repmat(b,1,size(a,2)); end
K = size(a,1)-1;
c = zeros(size(a));
for k = 0:K
    acc = zeros(1,size(a,2));
    for j = 0:k
        acc = acc + a(j+1,:).*b(k-j+1,:);
    end
    c(k+1,:) = acc;
end
end
