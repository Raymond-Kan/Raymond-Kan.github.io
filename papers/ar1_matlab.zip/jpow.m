function c = jpow(a,m)
%JPOW  Integer power a^m of a jet, without a branch decision.
%   c = JPOW(a,m) returns the jet of a^m for a nonnegative integer m, where
%   a is a (K+1) x N array of Taylor coefficients (one column per point).
%
%   For m <= 12 the power is formed by repeated multiplication, which is
%   exact and needs no logarithm.  Otherwise, for each column, the leading
%   power of the jet variable is factored out exactly: if a = x^l b with
%   b(0) ~= 0 (l the number of leading coefficients that are exactly zero),
%   then a^m = x^{lm} b^m, and b^m = b(0)^m (b/b(0))^m, where the power of
%   the normalized jet u = b/b(0), u(0) = 1, comes from the exact
%   recurrence for powers of a power series,
%       k w_k = sum_{j=1}^k [(m+1) j - k] u_j w_{k-j},   w_0 = 1.
%   The recurrence uses power-of-two rescaling of the input coefficients.
%   This reduces their magnitudes but is not a universal range or relative-
%   accuracy guarantee: coefficients of the powered jet may still grow.
%   The factor b(0)^m is formed as 2^(m log2|b(0)|) exp(i m arg b(0)) with
%   a separate binary exponent, at a cost that does not depend on m.
%   A column whose recurrence result is nonfinite is retried by repeated
%   squaring of the original jet. This recovers some high-order cases with
%   finite coefficients; if the retry is also nonfinite, it is propagated.
%   Only exact leading zeros are factored out, including when the constant
%   is tiny relative to the other coefficients.
%
%   (An earlier version factored out the first coefficient exceeding 1e-14
%   times the largest one, which is not invariant under rescaling of the
%   jet variable and returned [0;0] in that example.)
K = size(a,1)-1;
N = size(a,2);
if m == 0
    c = zeros(size(a)); c(1,:) = 1; return
end
if K == 0, c = a.^m; return, end          % scalars
if m <= 12
    c = zeros(size(a)); c(1,:) = 1;
    b = a;  e = m;
    while e > 0
        if mod(e,2) == 1, c = jm(c,b); end
        e = floor(e/2);
        if e > 0, b = jm(b,b); end
    end
    return
end
c = zeros(size(a));
% leading power l of the jet variable in each column (exact zeros only)
[hasnz,f] = max(a ~= 0,[],1);            % first nonzero coefficient
l = f-1; l(~hasnz) = K+1;
todo = find(l <= K & l*m <= K);          % the others are zero jets
if isempty(todo), return, end
% group the columns by l (usually all l = 0), vectorized within a group
for lv = unique(l(todo))
    cols = todo(l(todo) == lv);
    b = [a(lv+1:end,cols); zeros(lv,numel(cols))];      % b(0) ~= 0
    b0 = b(1,:);
    % rescaling of the jet variable by an exact power of two, s = 2^e2, with
    % max_{j>=1} |u_j| s^j <= 1 for u = b/b(0); the scaled coefficients
    % u_j s^j = (b_j 2^{e2 j})/b(0) are formed without intermediate overflow
    % (|b_j 2^{e2 j}| <= |b(0)|) and with a single rounding each
    lu = log(abs(b(2:end,:)))-log(abs(b0));             % log|u_j|, -Inf for zeros
    e2 = floor(-max(lu./(1:K)',[],1)/log(2));           % s = 2^e2
    e2(~isfinite(e2)) = 0;                              % constant jets
    E2 = e2.*(0:K)';                                    % the exponents e2 j
    ut = (complex(pow2(real(b),E2),pow2(imag(b),E2)))./b0;    % u_j s^j, |.| <= 1
    % powers of the normalized rescaled jet by the recurrence
    w = zeros(K+1,numel(cols)); w(1,:) = 1;
    for k = 1:K
        jj = (1:k)';
        w(k+1,:) = sum(((m+1)*jj-k).*ut(jj+1,:).*w(k-jj+1,:),1)/k;
    end
    % b(0)^m = P 2^E in O(1) operations, independent of m: with
    % lm = m log2|b(0)| and E = floor(lm), P = 2^(lm - E) exp(i m arg b(0)),
    % |P| in [1,2), so that the binary exponent E is carried separately and
    % the factor neither overflows nor underflows (range protection, as
    % before).  For a real negative b(0) the sign (-1)^m is applied exactly.
    % The relative error is about eps |m log b(0)|, the same order as the
    % error m eps that the rounding of b(0) itself propagates into b(0)^m
    % by any method.  (Binary powering, used until November 2026, took
    % O(log2 m) multiplications.)
    lm = m*log2(abs(b0));  E = floor(lm);
    ngr = imag(b0) == 0 & real(b0) < 0;                 % real negative
    ph = exp(1i*m*angle(b0));  ph(ngr) = (-1)^m;  ph(imag(b0) == 0 & real(b0) > 0) = 1;
    P = pow2(lm-E).*ph;
    % the coefficients b(0)^m w_k s^{-k}, scaled exactly by the power of two
    % (range also depends on the intermediate recurrence coefficients)
    pw = P.*w;  EE = E-E2;
    bm = complex(pow2(real(pw),EE),pow2(imag(pw),EE));
    if isreal(a), bm = real(bm); end
    cj = zeros(K+1,numel(cols));
    cj(lv*m+1:end,:) = bm(1:K+1-lv*m,:);
    % Retry nonfinite columns using the original jet. Neither route is an
    % unrestricted range guarantee, so retain the original nonfinite result
    % when the retry cannot produce an entirely finite jet.
    retry = find(any(~isfinite(cj),1));
    for jj = retry
        aa = a(:,cols(jj)); cc = zeros(size(aa)); cc(1) = 1;
        ee = m;
        while ee > 0
            if mod(ee,2) == 1, cc = jm(cc,aa); end
            ee = floor(ee/2);
            if ee > 0, aa = jm(aa,aa); end
        end
        if all(isfinite(cc)), cj(:,jj) = cc; end
    end
    c(:,cols) = cj;
end
end
