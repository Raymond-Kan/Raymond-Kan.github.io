function c = jsq(a)
%JSQ  Principal square root of a jet (truncated power series).
K = size(a,1)-1;
c = zeros(size(a));
c(1,:) = sqrt(a(1,:));
for k = 1:K
    acc = a(k+1,:);
    for j = 1:k-1
        acc = acc - c(j+1,:).*c(k-j+1,:);
    end
    c(k+1,:) = acc./(2*c(1,:));
end
end
