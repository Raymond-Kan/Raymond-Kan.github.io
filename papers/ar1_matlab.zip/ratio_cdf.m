function [F,err,Fraw] = ratio_cdf(h,r,tol,opts)
%RATIO_CDF  P[u/v < r] for a ratio with positive denominator, from the jet-valued
%   log joint characteristic function h(t1,t2) = log phi(t1,t2) of (u,v)
%   (Gil-Pelaez 1951, Imhof 1961):
%
%      P[u/v < r] = 1/2 - (1/pi) int_0^inf Im( exp(h(t1,-r t1)) )/t1 dt1.
%
%   [F,err,Fraw] = RATIO_CDF(h,r,tol,opts)
%
%   The removable singularity at the origin is handled by replacing the
%   integrand on a short initial interval by its Taylor polynomial, whose
%   coefficients are exact (a jet of order 8 of phi(t1,-r t1) in t1 at t1 = 0);
%   the interval is halved (at most 40 times) until the last two retained
%   terms of the polynomial are below tol/100.  The variable of integration
%   is scaled by {Var u + r^2 Var v}^{-1/2}, a proxy for 1/sd(u - rv) (the
%   covariance term is omitted so that the scale never degenerates), on
%   which the integrand decays.
%
%   tol is the absolute tolerance requested from the quadrature (default
%   1e-10); the relative tolerance is opts.reltol (default max(tol,1e-14)).
%   err is an estimate of the total error of each value (the quadrature's own estimate
%   plus the truncation error of the asymptotic tail when one is used); a
%   warning 'ratio:accuracy' is issued when it exceeds tol, unless
%   opts.warn = false.  Fraw is the value before clipping to [0,1]; F is
%   clipped only when the excursion outside [0,1] is within the error
%   estimate (an excursion beyond it is a failure and is returned as is).
%   Non-finite integrand values are propagated (the result is then NaN)
%   unless they are genuine underflows, i.e. Re h < -700.
%
%   Slowly decaying tails.  When the characteristic function along the
%   path decays only algebraically (the limiting distributions along the
%   ray r = -c, where u - rv is a chi-square type variable), the integral
%   over [0,inf) cannot be done by adaptive quadrature.  With opts.S (the
%   cutoff tbar of the paper) and opts.w0 given, the integral is taken over
%   [0,tbar] by quadrature and the remainder by the asymptotic expansion
%
%      int_tbar^inf psi(t1) e^{-i w0 t1} dt1
%            = e^{-i w0 tbar} sum_k psi^{(k)}(tbar)/(i w0)^{k+1},
%
%   where psi(t1) = exp(h(t1,-r t1)) e^{i w0 t1}/t1 is slowly varying once the
%   dominant linear phase -w0 t1 of the characteristic function has been
%   removed (w0 is supplied by the caller: 1/2 for the demeaned and
%   stationary limits, (1+gamma_0^2)/2 for the fixed-start limit), and the
%   derivatives psi^{(k)}(tbar) come from a jet of order opts.K (default 8) in t1.
%   The magnitude of the first omitted term is added to err, and tbar is
%   doubled (at most 5 times) while it exceeds tol/10.
%
%   See also RATIO_PDF, RATIO_ICDF, RATIO_MOM, AR1_CDF, AR1LIM_CDF.
if nargin < 3 || isempty(tol), tol = 1e-10; end
if nargin < 4, opts = struct; end
reltol = getopt(opts,'reltol',max(tol,1e-14));
maxint = getopt(opts,'maxint',20000);
dowarn = getopt(opts,'warn',true);
S0     = getopt(opts,'S',Inf);
w0     = getopt(opts,'w0',[]);
Kt     = getopt(opts,'K',8);
if isfinite(S0) && isempty(w0)
    error('ratio:opts','opts.w0 (asymptotic frequency) is required with a finite opts.S.');
end
cl = quiet_quadgk();                                   %#ok<NASGU> restores warnings on exit
F = zeros(size(r)); err = F;
[Eu,Ev,sdv,Vu,L0] = ratio_scale(h);
for i = 1:numel(r)
    ri = r(i);
    % the integrand decays on the scale of 1/sd(u - r v); the variable of
    % integration is z = s/sc with sc = 1/sqrt(Var u + r^2 Var v)
    vv = Vu+ri^2*sdv^2;  if ~isfinite(vv), vv = Vu; end   % Var v may have overflowed
    sc = 1/sqrt(vv);
    % the removable singularity at the origin: Im phi(s,-rs)/s is replaced on
    % [0,z0] by its Taylor polynomial, read off a jet of order Kp of
    % phi(s,-rs) in s at s = 0 (exact coefficients), with z0 chosen so that
    % the truncation error of the polynomial is below tol/100
    Kp = 8;
    xj = zeros(Kp+1,1); xj(2) = sc;           % s = sc z: the jet is taken in z
    phj = jexp(h(xj,-ri*xj));                 % Taylor coefficients of phi(s,-rs) in z
    pp = imag(phj(2:end)).';                  % Im phi/z = sum_k pp(k) z^(k-1)
    z0 = 0.1;
    for kk = 1:40
        tail2 = abs(pp(Kp))*z0^(Kp-1)+abs(pp(Kp-1))*z0^(Kp-2);
        if tail2 <= tol/100, break, end
        z0 = z0/2;
    end
    % the mismatch between the polynomial and the computed integrand at z0
    % measures the rounding noise of the characteristic function (a relative
    % error of order eps n near the unit root, see AR1_LOGCF), which enters
    % the integrand as an absolute error of the same order on the scale of
    % its support; three times it is added to the error estimate
    dy = abs(polyval(pp(end:-1:1),z0)-integ(z0,ri));
    enoise = 3*dy;
    % the quadrature cannot resolve the integrand below its noise: asking it
    % to do so only multiplies the function evaluations (and, in Octave,
    % QUADGK returns a wrong value once its interval limit is reached)
    tq = max(tol,3*dy);  rq = max(reltol,tq);
    if ~isfinite(S0)
        nev = 0;
        [I,e] = quadgk(@(z) counted(z,ri),0,Inf,'AbsTol',tq,'RelTol',rq,'MaxIntervalCount',maxint);
        if nev >= 15*maxint/2
            % QUADGK reached its interval limit, after which its error
            % estimate is not reliable (Octave can return a wrong value with
            % a small estimate): integrate decade by decade instead
            [I,e] = decades(@(z) patched(z,ri,pp,z0),Inf,tq,rq,maxint);
        end
        T = 0; et = 0;
    else
        S = S0;
        for dbl = 0:5
            [T,et] = tail(ri,S);
            if et <= tol/10 || dbl == 5, break, end
            S = 2*S;
        end
        % decade by decade in z, so that a power-law stretch of the integrand
        % (the algebraic decay along the ray) is resolved on every scale
        [I,e] = decades(@(z) patched(z,ri,pp,z0),S/sc,tq,rq,maxint);
    end
    F(i) = 0.5-(I+T)/pi;
    % L0: the computed log phi(0,0), a relative error of the characteristic
    % function (nonzero start or drift at large n, see RATIO_SCALE)
    err(i) = (e+et+enoise)/pi+L0;
end
Fraw = F;
clipok = (F >= -err-tol & F < 0) | (F > 1 & F <= 1+err+tol);
F(clipok) = max(0,min(1,F(clipok)));
if dowarn && any(err(:) > tol)
    [em,im] = max(err);
    warning('ratio:accuracy','ratio_cdf: estimated error %.1e at r = %g exceeds the tolerance %.1e.',em,r(im),tol);
end

    function y = integ(z,ri)
        sz = size(z);  z = z(:).';
        s = z*sc;
        L = h(s,-ri*s);
        L = L(1,:);
        y = exp(real(L)).*sin(imag(L))./z;
        under = ~isfinite(y) & real(L) < -700;    % genuine underflow of exp(Re L)
        y(under) = 0;
        y = reshape(y,sz);
    end
    function y = counted(z,ri)
        nev = nev+numel(z);
        y = patched(z,ri,pp,z0);
    end
    function y = patched(z,ri,pp,z0)
        y = integ(z,ri);
        small = z < z0;
        if any(small), y(small) = polyval(pp(end:-1:1),z(small)); end
    end
    function [T,et] = tail(ri,S)
        % int_S^inf Im(phi(s,-rs))/s ds by the asymptotic expansion in the
        % derivatives of g(s) = phi(s,-rs) e^{i w0 (s-S)}/s at s = S; the jet
        % variable is x = (s-S) sc, so that the coefficients are balanced
        lam = 1/sc;
        x = zeros(Kt+1,1); x(2) = lam;              % s - S = lam x
        sj = x; sj(1) = S;
        ph = jexp(h(sj,-ri*sj));                    % phi(s,-rs)
        g  = jd(jm(ph,jexp(1i*w0*x)),sj);           % g, with x = (s-S)/lam
        % g^{(k)}(S) = k! g_k / lam^k
        gk = factorial(0:Kt)'.*g./lam.^((0:Kt)');
        terms = gk./(1i*w0).^((1:Kt+1)');
        T  = imag(sum(terms(1:Kt)));
        et = abs(terms(Kt+1));
    end
end

function [I,e] = decades(f,b,tol,reltol,maxint)
%DECADES  int_0^b f by QUADGK over [0,10], [10,100], ..., [10^k, b], summing
%   the error estimates; the absolute tolerance is shared out over the pieces.
%   With b = Inf the last piece is [10^30, Inf).
if isinf(b)
    ends = [10.^(1:30) Inf];
else
    ends = [10.^(1:floor(log10(b)-0.5)) b];
    if numel(ends) > 1 && ends(end-1) >= b, ends = ends(ends < b); ends(end+1) = b; end
end
I = 0; e = 0; a = 0; small = 0;
for k = 1:numel(ends)
    [Ik,ek] = quadgk(f,a,ends(k),'AbsTol',tol/10,'RelTol',reltol,'MaxIntervalCount',maxint);
    I = I+Ik; e = e+ek; a = ends(k);
    % the contributions of successive decades decrease at least like 10^{-1/2}
    % (algebraic tails) and usually much faster: two consecutive negligible
    % decades mean that the rest is negligible as well
    if abs(Ik)+ek <= tol/20, small = small+1; else small = 0; end
    if small >= 2, break, end
end
end

function v = getopt(o,f,d)
if isfield(o,f) && ~isempty(o.(f)), v = o.(f); else v = d; end
end

function cl = quiet_quadgk()
% silence quadgk's own warnings (MATLAB and Octave ids); the error estimate
% it returns is used instead, and the previous state is restored on exit
if exist('OCTAVE_VERSION','builtin')
    ids = {'Octave:quadgk:warning-termination'};
else
    ids = {'MATLAB:quadgk:MaxIntervalCountReached','MATLAB:quadgk:MinStepSize','MATLAB:quadgk:NonFiniteValue'};
end
ws = warning;
for k = 1:numel(ids), warning('off',ids{k}); end
cl = onCleanup(@() warning(ws));
end
