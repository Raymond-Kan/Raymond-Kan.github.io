function r = ratio_icdf(h,pr,tol,opts)
%RATIO_ICDF  Quantiles of u/v: r with P[u/v < r] = pr, by bracketing and FZERO
%   on RATIO_CDF.  tol and opts are passed to RATIO_CDF (whose accuracy
%   warning is left on, so that an inaccurate cdf is reported); the root is
%   located to a tolerance of 1e-11 times the scale of the ratio, and the
%   error in r is about err_F/f(r) where err_F is the cdf error.
%   See also RATIO_CDF, AR1_ICDF, AR1LIM_ICDF.
if nargin < 3 || isempty(tol), tol = 1e-10; end
if nargin < 4, opts = struct; end
if ~(isnumeric(pr) && isreal(pr) && all(pr(:) > 0 & pr(:) < 1))
    error('ratio:icdf','probabilities must be in (0,1)');
end
r = zeros(size(pr));
[Eu,Ev,~,Vu] = ratio_scale(h);
if ~(isfinite(Ev) && Ev > 0 && isfinite(Vu))
    error('ratio:scale','the mean of the denominator or the variance of the numerator is not finite.');
end
sd0 = sqrt(Vu)/Ev+abs(Eu)/Ev;
for i = 1:numel(pr)
    g  = @(x) ratio_cdf(h,x,tol,opts)-pr(i);
    c0 = Eu/Ev;  d = 2*sd0;
    lo = c0-d;  hi = c0+d;
    k = 0;
    glo = g(lo);
    while glo > 0 && k < 60, lo = lo-d; d = 2*d; glo = g(lo); k = k+1; end
    ghi = g(hi);
    while ghi < 0 && k < 120, hi = hi+d; d = 2*d; ghi = g(hi); k = k+1; end
    if ~(isfinite(glo) && isfinite(ghi)) || glo > 0 || ghi < 0
        error('ratio:icdf','could not bracket the quantile for p = %g (cdf not finite or not monotone).',pr(i));
    end
    % the tolerance is relative to the scale of the ratio: in the explosive
    % region r is of order phi^{-n} and an absolute tolerance would be useless
    r(i) = fzero(g,[lo hi],optimset('TolX',1e-11*sd0));
end
end
