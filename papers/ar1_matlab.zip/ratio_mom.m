function [m,err] = ratio_mom(h,k,c,tol)
%RATIO_MOM  Moments about c of a ratio u/v with positive denominator, from the
%   jet-valued log joint characteristic function h(t1,t2) = log phi(t1,t2)
%   of (u,v), by Sawa's (1978) representation
%
%      E[(u/v - c)^j] = 1/Gamma(j) int_0^inf s2^{j-1}
%                       [d^j M_c(s1,-s2)/ds1^j]_{s1=0} ds2,   j = 1..k,
%
%   where M_c(s1,s2) = E exp(s1(u-cv)+s2 v) = exp(h(-i s1, -i(s2 - s1 c))).
%   (AR1_MOM passes the center c - phi of u/v = phihat - phi.)  The
%   derivatives are read off the jet of h in s1 at t1 = -i s1,
%   t2 = i(s2 + s1 c), s1 = 0: j! times its j-th coefficient is the j-th
%   cumulant of u-cv under the measure tilted by exp(-s2 v), and one jet
%   exponential turns the cumulants into the derivatives of M_c relative to
%   M_c (Section 5 of the paper).
%   The caller is responsible for the existence of the moments.
%
%   [m,err] = RATIO_MOM(h,k,c,tol): tol is the absolute tolerance of the
%   quadrature for the moments of the standardized ratio (see below; default
%   1e-10); err holds the quadrature error estimates on the scale of the
%   returned moments, plus estimates of the omitted tails of the integral,
%   from the integrand at each end and at a point two units inside it (the
%   decay rate there gives the tail; near the moment-existence boundary it
%   is only 1/2); the interval is extended while a tail is not negligible.
%   These tail estimates are diagnostics, not bounds.  A warning 'ratio:accuracy' is issued when err exceeds the
%   tolerance on the standardized scale (absolute, or relative when the
%   standardized moment exceeds one).  Each moment is a separate
%   quadrature, whose integrand uses a jet of the order of that moment (the
%   jets are not shared between the k integrals: all derivatives come from
%   one jet at a node, but each moment has its own set of nodes).
%
%   The integration is carried out in log(s2 E[v]).  The integrand lives on
%   two scales: s2 of order 1/E[v], where the tilted measure starts to feel
%   the largest eigenvalue of the quadratic form v, and s2 of order one over
%   the remaining eigenvalues, where the decay s2^{-rank(v)/2} that makes the
%   higher moments finite sets in.  In the explosive region the two scales
%   are phi^{2n} apart and a substitution scaled by 1/E[v] alone cannot
%   resolve the second; the logarithmic variable covers both, and the
%   interval reaches 40 units beyond each scale, with waypoints every 10.
%   The quadrature is asked for the absolute tolerance max(tol, 10 x the
%   rounding noise of the integrand) and the relative tolerance tol.  (A
%   relative tolerance equal to the absolute noise floor, as in an earlier
%   version, let QUADGK stop at a few per cent error for high orders, whose
%   standardized integrals are large.)  The integrand combines the
%   logarithm of the derivative factor with the exponential weight before
%   exponentiating, so that it neither overflows nor underflows before the
%   moment itself does.  Three further measures keep the explosive region
%   in range (all four moments up to phi^{2n} of about 1e300; AR1_MOM
%   returns NaN beyond):
%   (i) the jet variable is rescaled by rho = sqrt(1 + s2 E[v]), the inverse
%   of the spread of the standardized numerator under the tilt exp(-s2 v):
%   at the second scale that spread is of order |phi|^(-n), and without the
%   rescaling the coefficient of order j of the jet, of order |phi|^(-jn),
%   underflows (orders 3 and 4 beyond phi^{2n} of about 1e200 and 1e150);
%   the factor rho^j is removed in logarithms;
%   (ii) the moments of the standardized ratio grow like |phi|^{(j-1)n}
%   (they are dominated by the far tail, where phihat - phi is of order
%   one), so the integral of order j is divided by the peak of its
%   integrand, in logarithms, when that peak exceeds e^50, and the factor
%   is restored at the end (elsewhere nothing changes);
%   (iii) far beyond the second scale (log(s2 E[v]) > log E[v] + 10) the
%   trend assembly with a drift in the trend can lose all its digits, where
%   the integrand is negligible; log E exp(-s2 v) must be real and <= 0,
%   and a value that is not is replaced by zero there.
%   The scale factor (su/Ev)^j, of order |phi|^(-jn), is applied in
%   logarithms, so that it does not underflow before the moment.
if nargin < 3 || isempty(c), c = 0; end
if nargin < 4 || isempty(tol), tol = 1e-10; end
if ~(isnumeric(k) && isreal(k) && isscalar(k) && isfinite(k) && k >= 1 && k == fix(k))
    error('ratio:mom','k must be a finite positive integer.');
end
if ~(isnumeric(c) && isreal(c) && isscalar(c) && isfinite(c))
    error('ratio:mom','the centering constant must be finite and real.');
end
if ~(isnumeric(tol) && isreal(tol) && isscalar(tol) && isfinite(tol) && tol > 0)
    error('ratio:mom','tol must be positive and finite.');
end
% The pair is standardized before integration: ut = u/sd(u), vt = v/E[v],
% so that ut/vt and its moments are O(1) and the tolerance refers to that
% scale (at the unit root the raw moments of order j are O(n^{-j}) and an
% absolute tolerance would otherwise be meaningless for large n).  Then
%   E[(u/v - c)^j] = (su/Ev)^j E[(ut/vt - ct)^j],  ct = c Ev/su.
[Eu,Ev,sdv,Vu,L0] = ratio_scale(h);
if ~(Vu > 0) || ~isfinite(Vu), su = max(abs(Eu),1); else su = sqrt(Vu); end
if ~(Ev > 0) || ~isfinite(Ev)
    error('ratio:mom','E[v] is not a positive finite number; the moments cannot be scaled.');
end
ht = @(s,t) h(s/su,t/Ev);
ct = c*Ev/su;
% A center far from the ratio (more than a few standardized units from
% E[u]/E[v]) makes the tilted integrand sharply peaked and the quadrature
% slow; the moments are then computed about mu0 = E[u]/E[v] and shifted by the
% binomial expansion E[(X-c)^j] = sum_i C(j,i) E[(X-mu0)^i] (mu0-c)^{j-i},
% which is exact (the cancellation it may involve is intrinsic to moments
% about a far point).
mu0 = Eu/su;
shift = abs(ct-mu0) > 3;
if shift, ct0 = ct; ct = mu0; end
Evt = 1;                                % E[vt] = 1 by construction
u0 = -log(Evt);
% The second scale: the remaining eigenvalues of v are at least of order
% one on the original scale, so the decay s2^{-rank(v)/2} sets in by
% s2 ~ 1, that is, at u = log(E[v]) + O(1) in the standardized variable; in
% the explosive region this is about 2 n log|phi|, far beyond the first
% scale, and the interval must reach it (it is extended further below while
% the integrand at the end is not negligible)
ua = u0-40;
ub = min(log(realmax)-4,max(u0+40,log(Ev)+40));
wp = unique(sort([ua:10:ub, -10 -5 0 5]));
wp = wp(wp > ua & wp < ub);
if exist('OCTAVE_VERSION','builtin')
    ids = {'Octave:quadgk:warning-termination'};
else
    ids = {'MATLAB:quadgk:MaxIntervalCountReached','MATLAB:quadgk:MinStepSize','MATLAB:quadgk:NonFiniteValue'};
end
ws = warning; for i = 1:numel(ids), warning('off',ids{i}); end
cl = onCleanup(@() warning(ws));                           %#ok<NASGU>
m = zeros(1,k); err = m;
lEv = log(Ev);
Lam = 0;                                  % log normalization of the current order
for j = 1:k
    % (ii) the peak of the integrand of order j, in logarithms, on a grid
    % over the initial interval; the integral is normalized by it when it is
    % large (the explosive region), and not otherwise
    Lam = 0;
    lgp = integ_log(linspace(ua,ub,401),j);
    Lam = max(lgp(isfinite(lgp)));
    if isempty(Lam) || Lam <= 50, Lam = 0; end
    % rounding noise of the integrand (relative error of order eps n in the
    % characteristic function near the unit root), from second differences on
    % a fine grid at two points of the bump; the quadrature is not asked to
    % resolve the integrand below it, and ten times it (the width of the
    % bump in u) enters the error estimate
    dy = 0;
    for uu = [-1 1]
        yy = integ(uu+1e-4*(0:4),j);
        dy = max(dy,std(diff(yy,2))/sqrt(6));
    end
    if ~isfinite(dy), dy = 0; end
    tq = max(tol,10*dy);
    a = ua; b = ub;
    for ext = 0:32
        % the omitted tails, estimated from the decay of the integrand over
        % the last two units at each end (TAIL_EST); an end is moved out by
        % 20 while its tail is not negligible
        ga = abs(integ([a a+2],j));
        gb = abs(integ([b b-2],j));
        ge = [tail_est(ga) tail_est(gb)];
        if all(ge <= tol/10) || ext == 32, break, end
        olda = a; oldb = b;
        if ge(1) > tol/10, a = max(-700,a-20); end
        if ge(2) > tol/10, b = min(log(realmax)-4,b+20); end
        if a == olda && b == oldb, break, end
    end
    wpj = unique([wp(wp > a & wp < b), a+10:10:b-1]);
    [I,e] = quadgk(@(u) integ(u,j),a,b,'Waypoints',wpj,'AbsTol',tq,'RelTol',max(tol,1e-14),'MaxIntervalCount',20000);
    etot   = e+sum(ge)+10*dy;
    % the scale factor (su/Ev)^j is applied in logarithms: in the explosive
    % region it is of order |phi|^(-jn) and underflows long before the
    % moment, which is of order |phi|^(-n)
    lsc    = j*log(su/Ev)-gammaln(j)+Lam;
    m(j)   = sign(I)*exp(log(abs(I))+lsc);          % I = 0 (a moment that vanishes by symmetry) gives 0
    err(j) = exp(log(etot+L0*abs(I))+lsc);          % L0: see RATIO_SCALE
    if etot+L0*abs(I) > tol*max(gamma(j),abs(I))
        warning('ratio:accuracy','ratio_mom: estimated relative error %.1e of the standardized moment of order %d exceeds the tolerance %.1e.',(etot+L0*abs(I))/max(gamma(j),abs(I)),j,tol);
    end
end
if shift
    d = (mu0-ct0)*(su/Ev);                    % (mu0 - c) on the original scale
    ms = [1 m]; es = [0 err];                 % moments about mu0, orders 0..k
    for j = 1:k
        acc = 0; eacc = 0;
        for i = 0:j
            acc  = acc +nchoosek(j,i)*ms(i+1)*d^(j-i);
            eacc = eacc+nchoosek(j,i)*es(i+1)*abs(d)^(j-i);
        end
        m(j) = acc; err(j) = eacc;
    end
end

    function e = tail_est(g)
        % g = |integrand| at an end and two units inside it: with decay rate
        % rate = log(g(2)/g(1))/2, the omitted tail is about g(1)/rate; twice
        % that is returned (a diagnostic, not a bound), Inf when no decay is seen
        if g(1) == 0, e = 0; return, end
        rate = log(g(2)/g(1))/2;
        if ~isfinite(rate) || rate <= 0
            e = Inf;
        else
            e = 2*g(1)/rate;
        end
    end

    function g = integ(u,j)
        sz = size(u);
        [lg,sg] = integ_log(u(:).',j);
        g = sg.*exp(lg-Lam);
        g(sg == 0) = 0;
        if any(~isfinite(g))
            error('ratio:mom','Non-finite log-scaled moment integrand; reduce the order or use higher precision.');
        end
        g  = reshape(g,sz);
    end

    function [lg,sg] = integ_log(u,j)
        % log|integrand| and its sign, before the normalization Lam
        v  = exp(u);
        N  = numel(v);
        % (i) a jet of order j in the rescaled variable xi = s1/rho
        rho = sqrt(1+v);
        sj = zeros(j+1,N);  sj(2,:) = -1i*rho;
        tj = zeros(j+1,N);  tj(1,:) = 1i*v;  tj(2,:) = 1i*ct*rho;
        L  = ht(sj,tj);
        % the jet of exp(L - L(1)): its j-th coefficient times j! is rho^j
        % times the j-th derivative of M_c relative to M_c (cumulants to moments)
        Q = jexp0(L);
        Dj = factorial(j)*real(Q(j+1,:));
        % v^{j-1} ... dv = v^j ... du; the logarithms are combined before
        % exponentiating, so a huge Dj against a tiny exp(Re L) neither
        % overflows nor underflows prematurely; a remaining non-finite value
        % is an error, not silently set to zero
        lg = j*u+real(L(1,:))+log(abs(Dj))-j*log(rho);
        sg = sign(Dj);
        % (iii) far beyond the second scale an unphysical value of
        % log E exp(-s2 v) (not real and <= 0) marks a breakdown of the
        % assembly where the integrand is negligible
        L1 = L(1,:);
        bad = u > lEv+10 & ~(real(L1) <= 1e-8 & abs(imag(L1)) <= 1e-6*(1+abs(real(L1))) & all(isfinite(L),1));
        lg(bad) = -Inf;  sg(bad) = 0;
        lg(Dj == 0) = -Inf;
    end
end
