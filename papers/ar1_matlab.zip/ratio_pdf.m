function [f,err,fraw] = ratio_pdf(h,r,tol,opts)
%RATIO_PDF  Density of u/v at r from the jet-valued log joint characteristic
%   function h(t1,t2) = log phi(t1,t2) of (u,v) (Geary 1944):
%
%      f(r) = (1/pi) int_0^inf Im( d/dt2 exp(h(t1,t2)) |_{t2=-r t1} ) dt1,
%
%   the t2-derivative being the second coefficient of a first-order jet in t2.
%
%   [f,err,fraw] = RATIO_PDF(h,r,tol,opts): tol, opts.reltol, opts.warn,
%   err and fraw as in RATIO_CDF (f is clipped at zero only when the
%   negative excursion is within the error estimate).  The density is of
%   order E[v]/sd(u) (the reciprocal of the scale of u/v: n at the unit
%   root, phi^n in the explosive region), and tol is applied relative to
%   that scale.
%
%   Slowly decaying tails (opts.S, opts.w0, opts.K as in RATIO_CDF).  The
%   remainder int_S^inf Im H(t1) dt1, H(t1) = d/dt2 phi(t1,t2)|_{t2=-r t1}, is
%   evaluated by the asymptotic expansion in the derivatives of
%   G(t1) = H(t1) e^{i w0 t1}.  The t1-derivatives of H at S are mixed
%   derivatives of phi; they are read off single-variable jets of
%   x -> phi(S + x, -r(S + x) + xi x) at K+1 complex values xi on a circle:
%   the k-th derivative is a polynomial of degree k in xi whose linear
%   coefficient is k H^{(k-1)}(S), extracted exactly by a discrete Fourier
%   transform.
%
%   See also RATIO_CDF, AR1_PDF, AR1LIM_PDF.
if nargin < 3 || isempty(tol), tol = 1e-10; end
if nargin < 4, opts = struct; end
reltol = getopt(opts,'reltol',max(tol,1e-14));
maxint = getopt(opts,'maxint',20000);
dowarn = getopt(opts,'warn',true);
S0     = getopt(opts,'S',Inf);
w0     = getopt(opts,'w0',[]);
Kt     = getopt(opts,'K',8);
if isfinite(S0) && isempty(w0)
    error('ratio:opts','opts.w0 (asymptotic frequency) is required with a finite opts.S.');
end
cl = quiet_quadgk();                                   %#ok<NASGU>
f = zeros(size(r)); err = f;
[~,Ev,sdv,Vu,L0] = ratio_scale(h);
fs = max(1,Ev/sqrt(max(Vu,realmin)));          % the scale of the density
sc = 1;
for i = 1:numel(r)
    vv = Vu+r(i)^2*sdv^2;  if ~isfinite(vv), vv = Vu; end   % Var v may have overflowed
    sc = 1/sqrt(vv);                          % scale of s: ~1/sd(u - r v)
    % rounding noise of the integrand (a relative error of order eps n in the
    % characteristic function near the unit root), from second differences
    % on a very fine grid; the quadrature is not asked to resolve below it
    % (the spacing 1e-6 keeps the curvature term, O(1e-12 y''), below the
    % noise; the density is of order fs = E[v]/sd(u), the reciprocal of the
    % scale of u/v, and the tolerance refers to that scale)
    zz = [0.3*(1+1e-6*(0:4)) 1+1e-6*(0:4)];
    yy = integ(zz,r(i));
    dy = max(std(diff(yy(1:5),2)),std(diff(yy(6:10),2)))/sqrt(6);
    if ~isfinite(dy), dy = 0; end
    enoise = 3*dy;  tq = max(tol*fs,3*dy);  rq = max(reltol,tq/fs);
    if ~isfinite(S0)
        nev = 0;
        [I,e] = quadgk(@(z) counted(z,r(i)),0,Inf,'AbsTol',tq,'RelTol',rq,'MaxIntervalCount',maxint);
        if nev >= 15*maxint/2
            % interval limit reached: see RATIO_CDF
            [I,e] = decades(@(z) integ(z,r(i)),Inf,tq,rq,maxint);
        end
        T = 0; et = 0;
    else
        S = S0;
        for dbl = 0:5
            [T,et] = tail(r(i),S);
            if et <= tol/10 || dbl == 5, break, end
            S = 2*S;
        end
        [I,e] = decades(@(z) integ(z,r(i)),S/sc,tq,rq,maxint);   % decade by decade, see RATIO_CDF
    end
    f(i) = (I+T)/pi;
    err(i) = (e+et+enoise)/pi+L0*abs(f(i));     % L0: see RATIO_SCALE
end
fraw = f;
clipok = f < 0 & f >= -err-tol;
f(clipok) = 0;
if dowarn && any(err(:) > tol*fs)
    [em,im] = max(err);
    warning('ratio:accuracy','ratio_pdf: estimated error %.1e at r = %g exceeds the tolerance %.1e (times the scale %.1e of the density).',em,r(im),tol,fs);
end

    function y = counted(z,ri)
        nev = nev+numel(z);
        y = integ(z,ri);
    end
    function y = integ(z,ri)
        sz = size(z);  z = z(:).';
        s = z*sc;
        L = h(s,[-ri*s; ones(size(s))]);          % first-order jet in t
        d = L(2,:);                                % d log phi/dt
        y = sc*imag(exp(L(1,:)).*d);               % ds = sc dz
        under = ~isfinite(y) & real(L(1,:)) < -700;
        y(under) = 0;
        y = reshape(y,sz);
    end
    function [T,et] = tail(ri,S)
        % int_S^inf Im H(s) ds, H(s) = phi_t(s,-rs), by the asymptotic
        % expansion of int_S^inf G(s) e^{-i w0 s} ds, G = H e^{i w0 s}:
        %   e^{-i w0 S} G^{(k)}(S) = sum_l C(k,l) (i w0)^{k-l} H^{(l)}(S),
        %   int_S^inf H ds = sum_k e^{-i w0 S} G^{(k)}(S)/(i w0)^{k+1}.
        % H^{(k-1)}(S) from jets of x -> phi(S + lam x, -r(S + lam x) + xi x):
        % (d/dx)^k = sum_j C(k,j) xi^j lam^{k-j} (d_s - r d_t)^{k-j} d_t^j, whose
        % xi^1 coefficient is k lam^{k-1} H^{(k-1)}(S).
        lam = 1/sc;  rho = 1/Ev;
        M = Kt+1;  xi = rho*exp(2i*pi*(0:Kt)/M);
        x = zeros(Kt+1,1); x(2) = 1;
        sj = lam*x; sj(1) = S;
        P = zeros(Kt+1,M);
        for m = 1:M
            ph = jexp(h(sj,-ri*sj+xi(m)*x));
            P(:,m) = factorial(0:Kt)'.*ph;          % P_k(xi_m) = (d/dx)^k phi
        end
        a1 = (P*(1./xi(:)))/M;                      % coefficient of xi^1, rows k = 0..Kt
        H = a1(2:Kt+1)./((1:Kt)'.*lam.^((0:Kt-1)'));   % H^{(0..Kt-1)}(S)
        terms = zeros(Kt,1);
        for k = 0:Kt-1
            acc = 0;
            for l = 0:k, acc = acc + nchoosek(k,l)*(1i*w0)^(k-l)*H(l+1); end
            terms(k+1) = acc/(1i*w0)^(k+1);
        end
        T  = imag(sum(terms(1:Kt-1)));
        et = abs(terms(Kt));
    end
end

function [I,e] = decades(f,b,tol,reltol,maxint)
if isinf(b)
    ends = [10.^(1:30) Inf];
else
    ends = [10.^(1:floor(log10(b)-0.5)) b];
    if numel(ends) > 1 && ends(end-1) >= b, ends = ends(ends < b); ends(end+1) = b; end
end
I = 0; e = 0; a = 0; small = 0;
for k = 1:numel(ends)
    [Ik,ek] = quadgk(f,a,ends(k),'AbsTol',tol/10,'RelTol',reltol,'MaxIntervalCount',maxint);
    I = I+Ik; e = e+ek; a = ends(k);
    % the contributions of successive decades decrease at least like 10^{-1/2}
    % (algebraic tails) and usually much faster: two consecutive negligible
    % decades mean that the rest is negligible as well
    if abs(Ik)+ek <= tol/20, small = small+1; else small = 0; end
    if small >= 2, break, end
end
end

function v = getopt(o,f,d)
if isfield(o,f) && ~isempty(o.(f)), v = o.(f); else v = d; end
end

function cl = quiet_quadgk()
if exist('OCTAVE_VERSION','builtin')
    ids = {'Octave:quadgk:warning-termination'};
else
    ids = {'MATLAB:quadgk:MaxIntervalCountReached','MATLAB:quadgk:MinStepSize','MATLAB:quadgk:NonFiniteValue'};
end
ws = warning;
for k = 1:numel(ids), warning('off',ids{k}); end
cl = onCleanup(@() warning(ws));
end
