function [Eu,Ev,sdv,Vu,L0] = ratio_scale(h)
%RATIO_SCALE  Means and variances of (u,v) from the jets of their log joint
%   characteristic function h(t1,t2) at the origin:
%   h = i t1 E[u] + i t2 E[v] - (t1^2 Var u + t2^2 Var v)/2 + ...
%   Var v may overflow (in the explosive region it is of order phi^{4n});
%   sdv is then Inf, and the callers fall back on Var u alone for scaling.
%   L0 = |h(0,0)|, the computed value of log phi(0,0), which is exactly zero
%   in exact arithmetic: with a nonzero start or drift the exponent
%   beta'K^{-1}beta/2 + eta of the characteristic function is a difference of
%   two terms of order n gamma^2 (n z0^2), and its rounding error, of order
%   n^2 gamma^2 eps near the unit root, shows up in L0, which the callers add
%   to their error estimates (a relative error of the characteristic
%   function of that size).
Lt  = h(0,[0;1;0]);
L0  = abs(Lt(1));
Ev  = real(Lt(2)/1i);
Vv  = real(-2*Lt(3));
if isfinite(Vv), sdv = sqrt(max(Vv,0)); else sdv = Inf; end
Ls  = h([0;1;0],0);
Eu  = real(Ls(2)/1i);
Vu  = real(-2*Ls(3));
end
