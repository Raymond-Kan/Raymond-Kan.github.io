function [d1,d2,d3,d4,lgi,info,ec,wcc] = ttprimsj(p,q,p2q,m,thr,pm2q)
%TTPRIMSJ  Primitives of a tridiagonal Toeplitz matrix, in Taylor-mode (jet) arithmetic.
%
%   [d1,d2,d3,d4,lgi] = TTPRIMSJ(p,q,p2q,m) returns, for the m x m complex
%   symmetric tridiagonal Toeplitz matrix D with diagonal p and off-diagonal
%   q, the four bilinear forms of D^{-1},
%
%       d1 = 1'D^{-1}1,   d2 = e1'D^{-1}1,   d3 = e1'D^{-1}e1,   d4 = e1'D^{-1}em,
%
%   and lgi = log(1/|D|).  Every input and output is a truncated power
%   series ("jet") in one scalar variable, stored as a (K+1) x N array whose
%   k-th row holds the coefficient of order k-1, so that the rows of the
%   outputs are the derivatives (divided by k!) of the primitives with
%   respect to that variable, exactly, to machine precision, at every order.
%   With K = 0 the routine is an ordinary (vectorized) evaluator.  The third
%   argument is p+2q supplied by the caller in a form that does not cancel
%   (see below); pass [] to have it formed as p+2q.
%
%   The constant coefficient of lgi carries the CONTINUOUS phase of 1/|D|
%   (its imaginary part is the continuous argument, not the principal one),
%   which is what the inversion integrals need; the higher coefficients of
%   lgi, being derivatives of a logarithm, carry no branch at all.
%
%   Numerical design.  With x = p/(2q) and U_k the Chebyshev polynomial of
%   the second kind, |D| = q^m U_m(x), d3 = U_{m-1}/(q U_m), d4 =
%   (-1)^{m+1}/(q U_m), d2 = Q/(2 q U_m) and d1 = S/(2 q U_m), where
%   U_m + U_{m-1} + (-1)^{m+1} = (x+1) Q and m U_m + Q = (x+1) S hold as
%   polynomial identities.  Nothing here is singular: U_m is entire.  The
%   difficulty is numerical only: the closed forms in the characteristic
%   roots r+- = (p +- sqrt(p^2-4q^2))/2 lose all accuracy when the roots
%   coalesce, i.e. when x is near -1 (p+2q ~ 0) or near +1 (p-2q ~ 0),
%   which is exactly what happens along the integration paths when phi is
%   near 1 (resp. near -1) and the transform variables are small.
%
%   Three regimes, split on tau = n^2 |x -+ 1| with n = m+1 and threshold
%   thr (default 2.5):
%     generic   (tau >= thr at both points): closed forms in the roots,
%               written in w = q/r1 (|w| <= 1) so that the n-th powers are
%               exponentially small and nothing overflows at any m; the
%               phase of 1/|D| is arg(h) - arg(1-w^{2n}) - n*arg(r1), each
%               principal argument being continuous along the paths of the
%               AR(1) paper of Bao and Kan (Section 4.2).
%     confluent (tau < thr at x = -1 or at x = +1): the two Chebyshev values
%               are evaluated from their Taylor expansions at the confluent
%               point, whose coefficients are explicit, U_m^{(k)}(-1)/k! =
%               (-1)^{m+k} f_k, f_0 = m+1, f_{k+1}/f_k = (m-k)(m+k+2)/
%               ((2k+3)(k+1)), and U_m(1+e) = sum f_k e^k.  Twenty terms
%               give machine precision on tau < 2.5 for every m.  The
%               divisions by x+1 in d1 and d2 are carried out on the
%               coefficients (an index shift), so no cancellation survives.
%
%   On the conditioning of the argument: on the band p ~ -2q, so forming
%   p+2q by subtraction loses about eps*n^2/5 in relative accuracy of every
%   primitive; a caller that knows p+2q in closed form should pass it.
%
%   info.regime is a row vector with 0 (generic), -1 or +1 (confluent at
%   x = -1 or x = +1) for every column.
%
%   Trend primitives (outputs 7 and 8, computed only when requested): with
%   c = l - (m+1)/2 1 the centered index vector, l = (1,...,m)',
%       ec  = em'D^{-1}c,    wcc = c'D^{-1}c
%   (1'D^{-1}c = 0 and e1'D^{-1}c = -ec by persymmetry).  From
%   D c = (p+2q) c - q(m+1)(em - e1)/2,
%       ec  = [(m-1)/2 + q(m+1)(d3-d4)/2]/(p+2q),
%       wcc = [m(m^2-1)/12 + q(m+1) ec]/(p+2q),
%   and in the confluent regime at x = -1, ec = Pc/(4 q U_m) and
%   wcc = Rc/(8 q U_m), where (m-1)U_m + (m+1)(U_{m-1}+(-1)^m) = (x+1) Pc and
%   4 c'c U_m + (m+1) Pc = (x+1) Rc are polynomial identities, carried out on
%   the coefficients like the divisions in d1 and d2.
%
%   The trend primitives are used by AR1_LOGCF in cases 'DT' and 'ST' (and by
%   TR_LOGCF of the t-ratio programs).
%
%   See also AR1_LOGCF, TTPRIMS (the scalar predecessor in the predictive
%   regression suite of Kan, Pan and Tang).

if nargin < 5 || isempty(thr), thr = 2.5; end
if nargin < 6, pm2q = []; end
if size(p,2) == 1 && size(q,2) > 1, p = repmat(p,1,size(q,2)); end
if size(q,2) == 1 && size(p,2) > 1, q = repmat(q,1,size(p,2)); end
if isempty(p2q), p2q = p+2*q; end
if size(p2q,2) == 1 && size(p,2) > 1, p2q = repmat(p2q,1,size(p,2)); end
% p-2q is supplied in closed form by the caller when it has one (it is
% (1+phi)^2 + 2i((phi+1)s - t), which protects the band at phi = -1 as
% p+2q protects the one at phi = 1); otherwise it is formed by subtraction
if isempty(pm2q), pm2q = p2q-4*q; end
if size(pm2q,2) == 1 && size(p,2) > 1, pm2q = repmat(pm2q,1,size(p,2)); end
p = p2q-2*q;                 % every primitive is that of one and the same matrix
K = size(p,1)-1;  N = size(p,2);
n = m+1;
xm = p2q(1,:)./(2*q(1,:));          % x+1 at the base point
xp = pm2q(1,:)./(2*q(1,:));         % x-1 at the base point
tm = abs(xm)*n^2;  tp = abs(xp)*n^2;
regime = zeros(1,N);
regime(tm < thr) = -1;
regime(tm >= thr & tp < thr) = 1;

d1 = zeros(K+1,N); d2 = d1; d3 = d1; d4 = d1; lgi = d1; ec = d1; wcc = d1;
wantT = nargout > 6;
ig = regime == 0;
if any(ig)
    [d1(:,ig),d2(:,ig),d3(:,ig),d4(:,ig),lgi(:,ig)] = ...
        tt_generic(p(:,ig),q(:,ig),p2q(:,ig),pm2q(:,ig),n);
    if wantT, [ec(:,ig),wcc(:,ig)] = trend_generic(q(:,ig),p2q(:,ig),d3(:,ig),d4(:,ig),n); end
end
for sgn = [-1 1]
    ic = regime == sgn;
    if any(ic)
        [d1(:,ic),d2(:,ic),d3(:,ic),d4(:,ic),lgi(:,ic),ecx,wcx] = ...
            tt_conf(p(:,ic),q(:,ic),p2q(:,ic),pm2q(:,ic),n,K,sgn,wantT);
        if wantT
            if sgn == -1, ec(:,ic) = ecx; wcc(:,ic) = wcx;
            else, [ec(:,ic),wcc(:,ic)] = trend_generic(q(:,ic),p2q(:,ic),d3(:,ic),d4(:,ic),n); end
        end
    end
end
info = struct('regime',regime);
end

% =========================================================================
function [d1,d2,d3,d4,lgi] = tt_generic(p,q,p2q,pm2q,n)
%TT_GENERIC  Closed forms in the roots, written in w = q/r1 with |w| <= 1.
h  = jsq(jm(pm2q,p2q));             % sqrt((p-2q)(p+2q)) without cancelling
r1 = (p+h)/2;  r2 = (p-h)/2;
sw = abs(r2(1,:)) > abs(r1(1,:));   % r1 is the root of larger modulus
if any(sw)
    tmp = r1(:,sw); r1(:,sw) = r2(:,sw); r2(:,sw) = tmp; h(:,sw) = -h(:,sw);
end
w    = jd(q,r1);                    % |w| <= 1, and r2/r1 = w^2
A2n  = jpow(w,2*n);
A2n2 = jpow(w,2*n-2);
An2  = jpow(w,n-2);
den  = jc(-A2n,1);                  % 1 - (r2/r1)^n
d3   = jd(jd(jc(-A2n2,1),r1),den);
d4   = ((-1)^n)*jd(jm(An2,h),jm(jm(r1,r1),den));
d2   = jd(jc(jm(q,d3+d4),1),p2q);
d1   = jd(jc(2*jm(q,d2),n-1),p2q);
% log(1/|D|) = log h - log(1-w^{2n}) - n log r1, continuous phase in the
% constant coefficient, derivative coefficients from jlog0
lgi  = jlog0(h)-jlog0(den)-n*jlog0(r1);
lgi(1,:) = log(abs(h(1,:)))+1i*angle(h(1,:)) ...
         - log(abs(den(1,:)))-1i*angle(den(1,:)) ...
         - n*(log(abs(r1(1,:)))+1i*angle(r1(1,:)));
end

% =========================================================================
function [d1,d2,d3,d4,lgi,ecx,wcx] = tt_conf(p,q,p2q,pm2q,n,K,sgn,wantT)
%TT_CONF  Expansion at the confluent point x = sgn (x = -1 for sgn = -1,
%   x = +1 for sgn = +1), in the scaled variable tau = n^2 (x - sgn).
m  = n-1;
JT = 20;
if nargin < 8, wantT = false; end
L  = K+JT+2+2*wantT;                 % two more terms for the trend primitives (two shifts)
ecx = []; wcx = [];
% Taylor coefficients of U_m and U_{m-1} at x = -1, carried against powers
% of tau = n^2 (x+1) rather than of x+1: the ratio of successive
% coefficients is then -(m-i)(m+i+2)/(n^2 (2i+3)(i+1)), of modulus below
% one, so no coefficient overflows at any m
eA = zeros(1,L+1);  eA(1) = (-1)^m*(m+1);
for i = 0:L-1
    eA(i+2) = -eA(i+1)*((m-i)/n)*((m+i+2)/n)/((2*i+3)*(i+1));
end
eB = zeros(1,L+1);  eB(1) = (-1)^(m-1)*m;
for i = 0:L-1
    eB(i+2) = -eB(i+1)*((m-1-i)/n)*((m+i+1)/n)/((2*i+3)*(i+1));
end
if sgn == -1
    % tau = n^2 (x+1) = n^2 p2q/(2q), directly from the closed-form p+2q
    dl = n^2*jd(p2q,2*q);
    % U_m+U_{m-1}+(-1)^{m+1} = (x+1) Q = (tau/n^2) Q, so the tau-coefficients
    % of Q are n^2 times the shifted ones; likewise m U_m + Q = (x+1) S
    eQ = n^2*(eA(2:end)+eB(2:end));
    eR = m*eA(1:L)+eQ;
    eS = n^2*eR(2:end);
    u0 = dl(1,:);  u = dl;  u(1,:) = 0;
    A  = jhorner(shiftc(eA,u0,K,JT),u);
    B  = jhorner(shiftc(eB,u0,K,JT),u);
    Qj = jhorner(shiftc(eQ,u0,K,JT),u);
    Sj = jhorner(shiftc(eS,u0,K,JT),u);
    if wantT
        % (m-1)U_m + (m+1)(U_{m-1} + (-1)^m) = (x+1) Pc, and
        % 4 c'c U_m + (m+1) Pc = (x+1) Rc, c'c = m(m^2-1)/12
        eN  = (m-1)*eA + (m+1)*eB;  eN(1) = eN(1) + (m+1)*(-1)^m;   % eN(1) = 0
        ePc = n^2*eN(2:end);
        eT  = 4*(m*(m^2-1)/12)*eA(1:end-1) + (m+1)*ePc;             % eT(1) = 0
        eRc = n^2*eT(2:end);
        Pc  = jhorner(shiftc(ePc,u0,K,JT),u);
        Rc  = jhorner(shiftc(eRc,u0,K,JT),u);
        qAt = jm(q,A);
        ecx = jd(Pc,4*qAt);
        wcx = jd(Rc,8*qAt);
    end
else
    % tau = n^2 (x-1) = n^2 (p-2q)/(2q), from the closed-form p-2q;
    % U_m(1+e) = (-1)^m U_m(-1-e): coefficients (-1)^{m+k} eA(k+1) = f_k > 0
    kk = 0:L;
    fA = eA.*(-1).^(m+kk);
    fB = eB.*(-1).^(m-1+kk);
    dl = n^2*jd(pm2q,2*q);
    u0 = dl(1,:);  u = dl;  u(1,:) = 0;
    A  = jhorner(shiftc(fA,u0,K,JT),u);
    B  = jhorner(shiftc(fB,u0,K,JT),u);
    xp1 = jc(dl/n^2,2);                       % x+1 = (x-1)+2, no cancellation here
    Qj = jd(jc(A+B,(-1)^(m+1)),xp1);
    Sj = jd(m*A+Qj,xp1);
end
qA  = jm(q,A);
d3  = jd(B,qA);
d4  = jd(jc(0*qA,(-1)^(m+1)),qA);
d2  = jd(Qj,2*qA);
d1  = jd(Sj,2*qA);
sq = sgn;
qs = q*sq;
W  = A.*(sq.^m)/(m+1);
lgi = -(m*jlog0(qs)+jlog0(W));
lgi(1,:) = -(m*(log(abs(qs(1,:)))+1i*angle(qs(1,:))) ...
           + log(abs(W(1,:)))+1i*angle(W(1,:)) + log(m+1));
end

% =========================================================================
function [ec,wcc] = trend_generic(q,p2q,d3,d4,n)
%TREND_GENERIC  em'D^{-1}c and c'D^{-1}c from the closed forms (away from x = -1).
m = n-1;
ec  = jd(jc(jm(q,d3-d4)*((m+1)/2),(m-1)/2),p2q);
wcc = jd(jc(jm(q,ec)*(m+1),m*(m^2-1)/12),p2q);
end

% =========================================================================
function G = shiftc(e,u0,K,JT)
%SHIFTC  Move a Taylor expansion from the confluent point to the base point.
N  = numel(u0);  Le = numel(e);
G  = zeros(K+1,N);
for k = 0:K
    acc = zeros(1,N);  up = ones(1,N);  cb = 1;
    for j = 0:JT
        if k+j+1 > Le, break; end
        acc = acc + (cb*e(k+j+1))*up;
        up  = up.*u0;
        cb  = cb*(k+j+1)/(j+1);
    end
    G(k+1,:) = acc;
end
end

function J = jhorner(G,u)
%JHORNER  sum_k G(k+1,:) u^k for a jet u with zero constant coefficient.
K = size(G,1)-1;
J = zeros(size(G));  J(1,:) = G(K+1,:);
for k = K-1:-1:0
    J = jm(J,u);
    J(1,:) = J(1,:)+G(k+1,:);
end
end
