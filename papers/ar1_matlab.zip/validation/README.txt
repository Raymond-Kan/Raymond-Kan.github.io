validation/ -- the high-precision reference of the explosive region

  hp_ref.py        the backward pivot recursion of ../ar1_logcf_piv.m in
                   mpmath at 250 significant digits (see the docstring for
                   the precision budget: 2 n log10|phi| digits are lost, at
                   most 211 on the grid, leaving at least 39 correct digits)
  run_grid.py      the parameter grid of the paper, Section 4.3:
                   cases DK (z0 = 0.5) and DU (gamma = 0.4),
                   phi in {-1.5, 1.1, 1.3, 1.5}, n in {25, 100, 300, 600}
                   (phi^{2n} up to 1.5^1200 = 2.0e211), ten (s,t) per (phi,n)
  hp_ref_grid.txt  its output (320 points, 20 digits)
  check_grid.m     evaluates ar1_logcf at the same points and prints the
                   largest deviation per (case, phi, n); on the whole grid the
                   deviation is below 2.5e-13 in absolute terms where the
                   characteristic function exceeds 1e-17, and 1e-14 typically

  hp_acc.py        the dense eigenvalue reference of Table 2 of the paper for
                   the explosive rows (phi = 1.1, z0 = gamma = 0.5, n = 60 and
                   200, four rays t = -r s, 2000 points each) in mpmath at 40
                   digits: in double precision that reference is itself
                   inaccurate at n = 200 (the covariance matrix has entries
                   of order phi^{2n} = 3.6e16); the 40-digit values agree with
                   the 250-digit pivot recursion to 1e-38
  hp_acc_ref.txt   its output (32000 points), read by ../ar1_paper.m ('acc')

  python3 run_grid.py > hp_ref_grid.txt      (about 20 s; needs mpmath)
  python3 hp_acc.py > hp_acc_ref.txt         (about 25 min)
  >> addpath('..'); check_grid                (MATLAB or Octave)
