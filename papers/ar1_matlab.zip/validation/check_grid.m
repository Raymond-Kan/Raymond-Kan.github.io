function worst = check_grid(file)
%CHECK_GRID  Compare AR1_LOGCF with the 250-digit reference values of
%   validation/hp_ref_grid.txt (produced by run_grid.py) and report the
%   largest absolute error of log phi_{u,v}, overall and per (case, phi, n).
%   The reference values are exact to 20 digits.  AR1_LOGCF agrees to about
%   1e-13 in absolute terms where the characteristic function is not
%   negligible, and to about 1e-14 relative to |log cf| where that is large
%   (the point (s,t) = (0.3,-0.7) has |log cf| of order n), on the whole
%   grid (phi^{2n} up to 2e211).
if nargin < 1, file = fullfile(fileparts(mfilename('fullpath')),'hp_ref_grid.txt'); end
fid = fopen(file,'r'); C = textscan(fid,'%s %f %f %f %f %f %f %f','CommentStyle','#'); fclose(fid);
cas = C{1}; phi = C{2}; n = C{3}; par0 = C{4}; s = C{5}; t = C{6}; ref = C{7}+1i*C{8};
worst = 0;
[grp,~,ig] = unique([phi n strcmp(cas,'DU')],'rows');
for k = 1:size(grp,1)
    i = find(ig == k);
    L = ar1_logcf(s(i).',t(i).',n(i(1)),phi(i(1)),cas{i(1)},par0(i(1)));
    d = abs(L(1,:)-ref(i).');
    rel = max(d./max(1,abs(ref(i).')));             % relative to |log cf| when that is large
    ab  = max(d(real(ref(i).') > -40));             % absolute, where the cf is not negligible
    worst = max(worst,max(rel,ab));
    fprintf('%s phi=%5.2f n=%4d (phi^2n = %8.1e): max |dlogcf| = %.1e (cf > 1e-17), max |dlogcf|/|logcf| = %.1e\n',cas{i(1)},phi(i(1)),n(i(1)),abs(phi(i(1)))^(2*n(i(1))),ab,rel);
end
fprintf('worst over the grid: %.1e\n',worst);
end
