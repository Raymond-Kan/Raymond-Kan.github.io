import mpmath as mp
mp.mp.dps = 60
def mats(n,phi):
    N=n+1
    Sx=mp.zeros(n,N); Se=mp.zeros(n,N)
    for t in range(n):           # rows t=1..n -> index t
        Sx[t,t]=1                 # lag of y_{t+1} is y_t
        Se[t,t+1]=1; Se[t,t]=-phi
    c=[ (t+1)-mp.mpf(n+1)/2 for t in range(n)]
    Z=mp.matrix(n,2)
    for t in range(n): Z[t,0]=1; Z[t,1]=c[t]
    Q=(Z.T*Z)**-1
    P=Z*Q*Z.T
    M=mp.eye(n)-P
    return Sx,Se,M,P
def Kext(n,phi,t1,t2,t3=0,reg=True):
    Sx,Se,M,P=mats(n,phi)
    MM = M if reg else mp.eye(n)
    A = Se.T*Se
    Th = t1*(Sx.T*MM*Se + Se.T*MM*Sx)/2 + t2*(Sx.T*MM*Sx) + t3*(Se.T*MM*Se)
    return A - 2j*Th
def border(Ke):
    # Lemma-1: first coord y0, core 1..n-1, corner n
    N=Ke.rows; n=N-1
    D=Ke[1:n,1:n]; a=Ke[1:n,0]; b=Ke[1:n,n]
    Di=D**-1
    d1=Ke[0,0]-(a.T*Di*a)[0]; d2=Ke[0,n]-(a.T*Di*b)[0]; d3=Ke[n,n]-(b.T*Di*b)[0]
    return d1,d2,d3,D
n=40; phi=mp.mpf('1.25'); se=abs(phi)**(-n); eps=se**2
for (a,b) in [(1e-3,2e-3),(0.3,-0.2),(2,1),(1e-6,3e-6)]:
    t1=se*a; t2=eps*b; tau=t1**2-2j*t2
    KD=Kext(n,phi,t1,t2,reg=False); KT=Kext(n,phi,t1,t2,reg=True)
    d1D,d2D,d3D,_=border(KD); d1T,d2T,d3T,_=border(KT)
    d4D=d1D*d3D-d2D**2; d4T=d1T*d3T-d2T**2
    Xi11=d1T-d1D; Xi12=d2T-d2D; Xi22=d3T-d3D
    print(f'a={a} b={b}: d4DK/tau-1 = {mp.nstr(abs(d4D/tau-1),3)}')
    print('   sizes/eps: tau %s  d1D*Xi22 %s  d2D*Xi12 %s  Xi12^2 %s  d3D*Xi11 %s  Xi11Xi22 %s  d4T %s'%tuple(mp.nstr(abs(x)/eps,3) for x in [tau,d1D*Xi22,2*d2D*Xi12,Xi12**2,d3D*Xi11,Xi11*Xi22,d4T]))
    print('   Xi11/se %s  Xi12/se %s  Xi22/eps %s  d1D %s d2D/se %s d3D/eps %s'%tuple(mp.nstr(abs(x),3) for x in [Xi11/se,Xi12/se,Xi22/eps,d1D,d2D/se,d3D/eps]))
# --- dt_border_check.py (2 November 2026): 60-digit checks of the flat-start border form of the
# noncentral exponent in case DT (AR(1) package: t3 = 0; t-ratio: t3 ~= 0).  Run: python dt_border_check.py
import mpmath as mp

def check(n,phi,a,b,t3):
    se=abs(phi)**(-n); eps=se**2; t1=se*a; t2=eps*b
    m=n-1; om=1-phi; k0=-(1+phi)/2; G=[mp.mpf(1)/n, mp.mpf(12)/(n*(n**2-1))]
    KD=Kext(n,phi,t1,t2,t3,reg=False); KT=Kext(n,phi,t1,t2,t3,reg=True)
    d1D,d2D,d3D,_=border(KD); d1T,d2T,d3T,_=border(KT)
    X11=d1T-d1D; X12=d2T-d2D
    D=KD[1:n,1:n]; q=KD[1,0]; Di=D**-1
    Z=mp.matrix(m,2)
    for j in range(m): Z[j,0]=1; Z[j,1]=(j+1)-mp.mpf(n)/2
    e1=mp.zeros(m,1); e1[0]=1; em=mp.zeros(m,1); em[m-1]=1
    W=Z.T*Di*Z
    jv=[mp.matrix([1,0]),mp.matrix([0.5,1])]; kv=[mp.matrix([om,0]),mp.matrix([k0,om])]
    beta=[1,mp.mpf(m)/2]; lam0=[1,-mp.mpf(m)/2]; kap0=[-phi,phi*m/mp.mpf(2)]
    C=mp.zeros(2,2); bv=mp.zeros(2,1); ar=mp.zeros(2,1); c00=0; c0n=0
    for i in range(2):
        C+=G[i]*(1j*t1*(jv[i]*kv[i].T+kv[i]*jv[i].T)+2j*t2*jv[i]*jv[i].T+2j*t3*kv[i]*kv[i].T)
        bv+=G[i]*(1j*t1*jv[i]+2j*t3*kv[i])*beta[i]
        ar+=G[i]*(1j*t1*(jv[i]*kap0[i]+kv[i]*lam0[i])+2j*t2*jv[i]*lam0[i]+2j*t3*kv[i]*kap0[i])
        c00+=G[i]*(2j*t1*lam0[i]*kap0[i]+2j*t2*lam0[i]**2+2j*t3*kap0[i]**2)
        c0n+=G[i]*beta[i]*(1j*t1*lam0[i]+2j*t3*kap0[i])
    H1=q*Z.T*Di*e1; H2=q*Z.T*Di*em
    I2=mp.eye(2); A=(I2+C*W)**-1; B=(I2+W*C)**-1
    h0=mp.matrix([1/om,(mp.mpf(m)/2-k0/om)/om]); dh=H2-h0
    r=C*H2-bv; rho0=C*h0-bv
    T11=[c00,(H1.T*A*C*H1)[0],-2*(H1.T*A*ar)[0],-(ar.T*B*W*ar)[0]]
    jh0=[(jv[i].T*h0)[0] for i in range(2)]
    T12=[-sum(G[i]*jh0[i]*(1j*t1*kap0[i]+2j*t2*lam0[i]) for i in range(2)),(H1.T*A*r)[0],(ar.T*B*(W*rho0-dh))[0]]
    print(f'n={n} a={a} t3n={mp.nstr(t3*n,3)}: Xi11 err {mp.nstr(abs(sum(T11)-X11)/abs(X11),3)} terms/|Xi11| '+' '.join(mp.nstr(abs(x)/abs(X11),3) for x in T11))
    print(f'          Xi12 err {mp.nstr(abs(sum(T12)-X12)/abs(X12),3)} terms/|Xi12| '+' '.join(mp.nstr(abs(x)/abs(X12),3) for x in T12)+f'  |rho0 - (C h0 - bv)| check, |H1 parts| {mp.nstr(abs(H1[0]),3)} {mp.nstr(abs(H1[1]),3)}')
for args in [(40,mp.mpf('1.25'),0.3,-0.2,0.5/40),(40,mp.mpf('1.25'),1e-6,3e-6,0.5/40),(80,mp.mpf('-1.15'),0.3,0.2,-2/80),(40,mp.mpf('1.25'),0.3,-0.2,0)]:
    check(*args)
