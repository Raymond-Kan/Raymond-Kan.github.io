here = fileparts(mfilename('fullpath')); addpath(fullfile(here,'..')); warning('off','all');
phi = 1.2; gam = 0.4; old = 'C:\work\ar1\dev\backup_dtnc_20261102';
for gt = [1 0.1]
 for n = [5e4 5e6 5e8]
  geff = gam - gt*((n+1)/2 + phi/(1-phi)); z0 = -geff/(1-phi);
  x = [-2 -0.5 0 0.5 2]; X = x/abs(z0);
  [~,Fl] = ar1explim(X,phi,z0);
  [F,eF] = ar1_cdf(X,n,phi,'DT',[gam gt],[],'scaled');
  addpath(old); clear functions; Fo = ar1_cdf(X,n,phi,'DT',[gam gt],[],'scaled'); rmpath(old); clear functions;
  fprintf('gt=%g n=%g z0=%.3g: new-lim %s (est %.0e)  old-lim %s\n',gt,n,z0,mat2str(F-Fl,2),max(eF),mat2str(Fo-Fl,2));
 end
end
