"""High-precision version of the dense eigenvalue reference of Table 2 of the
paper (ar1_paper.m, item 'acc') for the explosive rows, phi = 1.1, where the
double-precision dense evaluation loses accuracy at n = 200: the covariance
matrix of the data has entries of order phi^{2n} = 3.6e16, so the small
eigenvalues of the matrix of the quadratic form u - r v are lost in double
precision.

The construction is that of cf_dense.m, carried out in mpmath at 40
significant digits: with C = [0; L] (L the lower triangular Toeplitz matrix
of powers of phi) and mu the mean vector, the matrix of u - r v in the
coordinates of the innovations is G = C'(A_u - r A_v)C, its symmetric
eigen-decomposition G = Q diag(lambda) Q' is computed once per r, and along
the path t = -r s

   phi(s,-rs) = prod_j (1 - 2 i s lambda_j)^{-1/2}
                exp( i s mu'(A_u - r A_v)mu - 2 s^2 sum_j b_j^2/(1 - 2 i s lambda_j) ),

b = Q'C'(A_u - r A_v)mu, each factor on its principal branch (the real part
of 1 - 2 i s lambda is 1, so the product is on the continuous branch).  The
eigenvalues are of size up to 1e16 and are needed to about 1e-20 absolute;
40 digits leave a wide margin, and the pivot recursion of hp_ref.py (an
independent method, 250 digits) agrees with these values to 1e-30 at the
points checked.

Output (hp_acc_ref.txt): one line per point,
   cas phi par0 n r s Re_cf Im_cf
where s runs over the 2000 points of logspace(-5,3) scaled by the proxy
{Var u + r^2 Var v}^{-1/2} for 1/sd(u - r v) that ratio_cdf.m uses (the
characteristic function lives on the scale phi^{-2n} along these rays, far
below the unscaled grid at n = 200), with r and s written in full double precision (they are read back by
ar1_paper.m, which evaluates ar1_logcf at exactly these points), and the
characteristic function to 18 digits.  The rows of Table 2 at phi = 1.1 are
the maximum of |cf_O(1) - cf_ref| over these points.  Takes about 25
minutes (eight 200 x 200 and eight 60 x 60 eigen-decompositions in software
arithmetic).

   python3 hp_acc.py > hp_acc_ref.txt
"""
import sys
from mpmath import mp, mpf, mpc, matrix, eigsy, sqrt, exp, pi

mp.dps = 40

def model(n, phi, cas, par0):
    """G_u, G_v (matrices of u and v in the coordinates of the innovations),
    the linear terms b_u, b_v and the constants: u = z'G_u z + 2 b_u'z + k_u."""
    N = n+1
    phi = mpf(phi); par0 = mpf(par0)
    # A_u, A_v in the (n+1) coordinates of y_0..y_n (cf_dense.m)
    # B = M (P - phi Jt): n x (n+1); P picks y_1..y_n, Jt picks y_0..y_{n-1}; M = I - 11'/n for 'U'
    B = matrix(n, N)
    for i in range(n):
        B[i, i+1] += 1
        B[i, i] += -phi
    Mv = matrix(n, N)        # M Jt
    for i in range(n):
        Mv[i, i] = 1
    if cas[1] == 'U':
        def demean(X):
            Y = matrix(n, N)
            for j in range(N):
                m = sum(X[i, j] for i in range(n))/n
                for i in range(n):
                    Y[i, j] = X[i, j]-m
            return Y
        B = demean(B); Mv = demean(Mv)
    Au = matrix(N, N); Av = matrix(N, N)
    for i in range(n):
        for j in range(N):
            Au[i, j] += B[i, j]/2
            Au[j, i] += B[i, j]/2
            Av[i, j] += Mv[i, j]
    Av = (Av+Av.T)/2
    L = matrix(n, n)
    for i in range(n):
        for j in range(i+1):
            L[i, j] = phi**(i-j)
    mu = matrix(N, 1)
    if cas == 'DK':
        for t in range(N):
            mu[t] = par0*phi**t
    else:
        for i in range(n):
            mu[i+1] = par0*sum(L[i, j] for j in range(n))
    C = matrix(N, n)
    for i in range(n):
        for j in range(n):
            C[i+1, j] = L[i, j]
    Gu = C.T*Au*C; Gu = (Gu+Gu.T)/2
    Gv = C.T*Av*C; Gv = (Gv+Gv.T)/2
    bu = C.T*(Au*mu); bv = C.T*(Av*mu)
    ku = (mu.T*Au*mu)[0]; kv = (mu.T*Av*mu)[0]
    return Gu, Gv, bu, bv, ku, kv

def variance(G, b):
    """Var(z'Gz + 2b'z) for z standard normal: 2 tr(G^2) + 4 b'b."""
    n = G.rows
    tr2 = sum(G[i, j]*G[j, i] for i in range(n) for j in range(n))
    return 2*tr2+4*sum(b[i]*b[i] for i in range(n))

def dense_setup(mdl, r):
    Gu, Gv, bu, bv, ku, kv = mdl
    r = mpf(r); n = Gu.rows
    G = Gu-r*Gv
    lam, Q = eigsy(G)
    b = Q.T*(bu-r*bv)
    quad0 = ku-r*kv
    return [lam[j] for j in range(n)], [b[j] for j in range(n)], quad0

def cf_path(lam, b, quad0, s):
    s = mpf(s)
    logdet = mpc(0); q = mpc(0)
    for l, bj in zip(lam, b):
        d = 1-2j*s*l
        logdet += mp.log(d)
        q += bj*bj/d
    return exp(-logdet/2 + 1j*s*quad0 - 2*s*s*q)

if __name__ == '__main__':
    import math
    print('# cas phi par0 n r s Re_cf Im_cf')
    svec = [10**(-5+8*k/1999) for k in range(2000)]      # logspace(-5,3,2000) in double
    for cas, par0 in (('DK', 0.5), ('DU', 0.5)):
        phi = 1.1
        for n in (60, 200):
            mdl = model(n, repr(phi), cas, repr(par0))
            Vu = variance(mdl[0], mdl[2]); Vv = variance(mdl[1], mdl[3])
            g = phi**(-n)*(phi**2-1)                        # double, as in ar1_paper.m
            for rr in (-2, -0.1, 0.1, 2):
                r = rr*g
                # the grid is scaled by the proxy {Var u + r^2 Var v}^{-1/2} for
                # 1/sd(u - r v) (ratio_cdf.m): the characteristic function lives
                # on the scale phi^{-2n} along these rays
                sc = float(1/sqrt(Vu+mpf(repr(r))**2*Vv))
                lam, b, quad0 = dense_setup(mdl, repr(r))
                for s0 in svec:
                    s = s0*sc
                    v = cf_path(lam, b, quad0, repr(s))
                    print(cas, phi, par0, n, repr(r), repr(s), mp.nstr(v.real, 18), mp.nstr(v.imag, 18))
                sys.stdout.flush()
