"""High-precision reference for the AR(1) joint characteristic function in the
explosive region (fixed-start cases 'DK' and 'DU'), by the backward pivot
recursion of ar1_logcf_piv.m evaluated in mpmath at 250 significant digits.

Precision budget.  The recursion eliminates from the last coordinate; its
fixed point is unstable with multiplier phi^2 per step, so the result loses
about 2 n log10|phi| digits, i.e. up to 211 of the 250 digits on the grid
below (|phi| <= 1.5, n <= 600, phi^{2n} <= 1.5^1200 = 2.0e211), leaving at
least 39 correct digits, far more than the 15 of double precision that are
being certified.  The phase is the sum of the principal logarithms of the
pivots, which have positive real part (Schur complements of a matrix with
positive definite real part), so it is the continuous phase.

Usage:
  python3 hp_ref.py cas phi n par0 s1 t1 s2 t2 ...
    prints Re and Im of log phi_{u,v}(s_k,t_k) to 20 digits, one line per point
  python3 run_grid.py > hp_ref_grid.txt
    the parameter grid used in the paper (Section 4.3); check_grid.m compares
    ar1_logcf with the file.
Requires mpmath (pip install mpmath).
"""
import sys
from mpmath import mp, mpc, mpf, log, pi

def logcf(s, t, n, phi, cas, par0):
    m = n-1
    om = 1-phi
    q = -(phi+1j*s)
    p = 1+phi**2+2j*(phi*s-t)
    z = mpc(0)
    one = mpc(1)
    if cas == 'DK':
        c=one; al=z; a2=z; c1n=z; kap=z; b1=z; b2=q; cnn=one
        b0=z; bc=z; be1=-par0*q; bem=z; bn=z
        cst = -mpf(par0)**2/2*(p-1)
    elif cas == 'DU':
        c=one; al=z; a2=z; c1n=z; kap=2j*(om*s+t)/n; b1=1j*s/n; b2=q; cnn=one
        b0=z; bc=mpc(par0*om); be1=z; bem=z; bn=mpc(par0)
        cst = mpc(-n*mpf(par0)**2/2)
    else:
        raise ValueError
    logdet = z; quad = z
    piv = cnn; logdet += log(piv); bj = bn; quad += bj*bj/piv
    ka = kap - b1*b1/piv; mu = -b1*b2/piv; nu = -b2*b2/piv
    al = al - c1n*b1/piv; be = -c1n*b2/piv; c = c - c1n*c1n/piv
    bc = bc - bj*b1/piv; bem = bem - bj*b2/piv; b0 = b0 - bj*c1n/piv
    for j in range(m, 0, -1):
        if j > 1:
            piv = p+ka+2*mu+nu; colc = ka+mu; colq = q; colb = al+be; bj = bc+bem
        else:
            piv = p+ka+2*mu+nu; colb = al+be+a2; bj = bc+bem+be1
        logdet += log(piv); quad += bj*bj/piv
        if j > 1:
            ka = ka - colc*colc/piv; mu = -colc*colq/piv; nu = -colq*colq/piv
            al = al - colb*colc/piv; be = -colb*colq/piv; c = c - colb*colb/piv
            bc = bc - bj*colc/piv; bem = -bj*colq/piv; b0 = b0 - bj*colb/piv
        else:
            c = c - colb*colb/piv; b0 = b0 - bj*colb/piv
    logdet += log(c); quad += b0*b0/c
    return -logdet/2 + quad/2 + cst

if __name__ == '__main__':
    mp.dps = 250
    cas = sys.argv[1]; phi = mpf(sys.argv[2]); n = int(sys.argv[3]); par0 = mpf(sys.argv[4])
    vals = [mpf(x) for x in sys.argv[5:]]
    for k in range(0, len(vals), 2):
        L = logcf(vals[k], vals[k+1], n, phi, cas, par0)
        print(mp.nstr(L.real, 20), mp.nstr(L.imag, 20))
