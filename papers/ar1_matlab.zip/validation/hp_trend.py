"""High-precision reference for the trend case 'DT' in the explosive region.

Dense evaluation in mpmath of the characteristic function of (u, v) for the
regression of y_t on 1, t and y_{t-1}, with
    w_t = gamma + gamma_tau (t-(n+1)/2) + phi w_{t-1} + e_t,  w_0 = 0,
in the coordinates of the innovations: x = e + mu (mu_t the deterministic
part of the innovation), w = T x with T = (I - phi J)^{-1}, so that
    u = x'T'J'M x,   v = x'T'J'M J T x,   M = I - X(X'X)^{-1}X',  X = [1, t-(n+1)/2],
and with A = i t1 sym(T'J'M) + i t2 T'J'MJT,
    E exp(x'Ax) = det(I - 2A)^{-1/2} exp(mu'A mu + 2 mu'A (I-2A)^{-1} A mu).
The working precision is 2 n log10|phi| + 60 digits, so the result is exact
to far more digits than double precision.  Because the determinant is
evaluated as a whole, its square root is determined only up to sign; the
comparison (validation/check_trend.m) is therefore on log|phi| and on
phi^2.  Output lines:
    phi n gamma gamma_tau t1 t2 log|cf| Re(cf^2) Im(cf^2)
    python3 hp_trend.py > hp_trend_ref.txt
"""
import sys
from mpmath import mp, mpf, mpc, matrix, eye, det, lu_solve, log, fabs, exp

def cf(n, phi, gam, gtau, t1, t2):
    phi = mpf(phi)
    T = matrix(n, n)
    for i in range(n):
        for j in range(i+1):
            T[i, j] = phi**(i-j)
    J = matrix(n, n)
    for i in range(1, n):
        J[i, i-1] = 1
    c = [mpf(t+1) - mpf(n+1)/2 for t in range(n)]
    # M = I - X (X'X)^{-1} X', X'X = diag(n, sum c^2)
    sc2 = sum(x*x for x in c)
    M = matrix(n, n)
    for i in range(n):
        for j in range(n):
            M[i, j] = (1 if i == j else 0) - mpf(1)/n - c[i]*c[j]/sc2
    JT = J*T
    B = JT.T*M            # u = x'B x
    V = JT.T*M*JT         # v = x'V x
    A = matrix(n, n)
    for i in range(n):
        for j in range(n):
            A[i, j] = mpc(0, 1)*t1*(B[i, j]+B[j, i])/2 + mpc(0, 1)*t2*V[i, j]
    mu = matrix(n, 1)
    for i in range(n):
        mu[i] = mpf(gam) + mpf(gtau)*c[i]
    IA = eye(n) - 2*A
    d = det(IA)
    Amu = A*mu
    sol = lu_solve(IA, Amu)
    ex = (mu.T*Amu)[0] + 2*(Amu.T*sol)[0]
    cf2 = exp(2*ex)/d                     # cf^2
    lab = -log(fabs(d))/2 + ex.real        # log|cf|
    return lab, cf2

def main():
    pts = []
    for (phi, n, gam, gtau) in [(1.2, 60, 0.0, 0.0), (1.2, 120, 0.7, 0.3), (1.5, 50, 0.4, -0.2),
                                (-1.3, 80, 0.5, 0.1), (1.05, 200, 0.0, 0.2), (1.5, 120, 1.0, 0.0)]:
        mp.dps = int(2*n*abs(__import__('math').log10(abs(phi)))) + 60
        sd = mpf(abs(phi))**n/(mpf(phi)**2-1)       # scale of u - r v on the paths
        for r in (-0.3, 0.0, 0.2):
            for z in (0.01, 0.1, 0.4, 1.0, 3.0, 10.0):
                t1 = mpf(z)/sd
                t2 = -mpf(r)*(mpf(phi)**2-1)/mpf(abs(phi))**n*t1
                lab, c2 = cf(n, phi, gam, gtau, t1, t2)
                print('%g %d %g %g %s %s %s %s %s' % (phi, n, gam, gtau, mp.nstr(t1, 20), mp.nstr(t2, 20),
                      mp.nstr(lab, 20), mp.nstr(c2.real, 20), mp.nstr(c2.imag, 20)))
                sys.stdout.flush()

if __name__ == '__main__':
    main()
