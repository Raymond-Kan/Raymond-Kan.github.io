cd /d C:\work\ar1\public
matlab -batch "nf = ar1_test(false); disp(nf)" > C:\work\ar1\public\validation\ar1_test_full_20261103_yong.log 2>&1
