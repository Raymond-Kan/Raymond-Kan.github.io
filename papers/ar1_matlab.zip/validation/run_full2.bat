cd /d C:\work\ar1\public
matlab -batch "tic; nf = ar1_test(false); disp([toc nf])" > C:\work\ar1\public\validation\ar1_test_full_20261103_rankdrop.log 2>&1
