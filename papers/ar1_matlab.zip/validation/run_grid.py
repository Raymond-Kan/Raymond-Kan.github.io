"""The parameter grid of the explosive-region validation (paper, Section 4.3):
cases DK (z0 = 0.5) and DU (gamma = 0.4), phi in {-1.5, 1.1, 1.3, 1.5},
n in {25, 100, 300, 600}, and for each (phi,n) nine points (s,t) on the
scale of the inversion integrals, s = 10^k/g, t = s/g, g = |phi|^n/(phi^2-1),
k = -2,-1.5,...,2, plus the pair (s,t) = (0.3,-0.7) (an O(1) point far from the
inversion scale).  Output: one line per point,
   cas phi n par0 s t Re(logcf) Im(logcf)
to 20 digits.  Takes about a minute."""
import sys
from mpmath import mp, mpf
sys.path.insert(0, __file__.rsplit('/',1)[0] if '/' in __file__ else '.')
from hp_ref import logcf
mp.dps = 250
print('# cas phi n par0 s t Re_logcf Im_logcf')
for cas, par0 in (('DK', mpf('0.5')), ('DU', mpf('0.4'))):
    for phi in (mpf('-1.5'), mpf('1.1'), mpf('1.3'), mpf('1.5')):
        for n in (25, 100, 300, 600):
            g = abs(phi)**n/(phi**2-1)
            pts = [(mpf(10)**(k/2)/g, mpf(10)**(k/2)/g**2) for k in range(-4, 5)] + [(mpf('0.3'), mpf('-0.7'))]
            for s, t in pts:
                L = logcf(s, t, n, phi, cas, par0)
                print(cas, mp.nstr(phi, 5), n, mp.nstr(par0, 5), mp.nstr(s, 20), mp.nstr(t, 20), mp.nstr(L.real, 20), mp.nstr(L.imag, 20))
