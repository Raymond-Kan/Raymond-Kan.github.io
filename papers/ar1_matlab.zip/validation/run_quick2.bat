cd /d C:\work\ar1\public
matlab -batch "tic; nf = ar1_test(true); disp([toc nf])" > C:\work\ar1\public\validation\ar1_test_quick_20261103_rankdrop.log 2>&1
