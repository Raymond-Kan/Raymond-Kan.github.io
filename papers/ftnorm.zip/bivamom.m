%
%  bivamom.m   Date: 1/25/2016
%  This program computes E[|X_1|^r*|X_2|^s], where (X_1,X_2) 
%  follows a bivariate normal distribution with mean (mu1,mu2)
%  and correlation \rho.
%  Input:
%  r: power of |X_1|
%  s: power of |X_2|
%  mu1: E[X_1]
%  mu2: E[X_2]
%  rho: correlation between X_1 and X_2
%  Output
%  y: an (r+1)*(s+1) matrix of  E[|X_1^{i-1}*X_2^{j-1}|]
%
function y = bivamom(r,s,mu1,mu2,rho)
if r==0&&s==0
   y = 1;
   return
end
if r==0||s==0
   if r==0
      mu = mu2;
      y = ones(1,s+1);
   else
      mu = mu1;
      y = ones(r+1,1);
   end
   m = max(r,s);
   y(2) = mu*erf(mu/sqrt(2))+2*normpdf(mu);
   if m>1
      y(3) = mu^2+1;
      if m>2
         y(4) = (mu^3+3*mu)*erf(mu/sqrt(2))+(2*mu^2+4)*normpdf(mu);
         for k=4:m
             y(k+1) = (mu^2+2*k-3)*y(k-1)-(k-2)*(k-3)*y(k-3);
         end
      end
   end
else
   y = f(mu1,mu2,rho)+f(mu1,-mu2,-rho)+f(-mu1,mu2,-rho)+f(-mu1,-mu2,rho);
end

function M = f(m1,m2,r1)
b = (m2-r1*m1)/sqrt(1-r1^2);
c = (m1-r1*m2)/sqrt(1-r1^2);
%
%  first construct G_i = I_{0,i} and H_i = I_{i,0}
%
G = zeros(s,1);
G(1) = normcdf(b);
G(2) = (m2-r1*m1)*G(1)+sqrt(1-r1^2)*normpdf(b);
for i=2:s-1
    G(i+1) = (m2-r1*m1)*G(i)+(1-r1^2)*(i-1)*G(i-1);
end
H = zeros(r,1);
H(1) = normcdf(c);
H(2) = (m1-r1*m2)*H(1)+sqrt(1-r1^2)*normpdf(c);
for i=2:r-1
    H(i+1) = (m1-r1*m2)*H(i)+(1-r1^2)*(i-1)*H(i-1);
end
G = normpdf(m1)*G;
H = normpdf(m2)*H;
%
%  construct M(1,j) and M(2,j)
%
M = ones(r+1,s+1);
M(1,1) = bnorm(m1,m2,r1);
M(1,2) = m2*M(1,1)+r1*G(1)+H(1);
M(2,1) = m1*M(1,1)+G(1)+r1*H(1);
M(2,2) = m1*M(1,2)+G(2)+r1*M(1,1);
for j=3:s+1
    M(1,j) = m2*M(1,j-1)+(j-2)*M(1,j-2)+r1*G(j-1);
    M(2,j) = m2*M(2,j-1)+(j-2)*M(2,j-2)+r1*M(1,j-1);
end
%
%  construct M(i,j) for i>2
%
if r>1
   for i=3:r+1
       M(i,1) = m1*M(i-1,1)+(i-2)*M(i-2,1)+r1*H(i-1);
       for j=2:s+1
           M(i,j) = m1*M(i-1,j)+(i-2)*M(i-2,j)+r1*(j-1)*M(i-1,j-1);
       end
   end
end
end

end
