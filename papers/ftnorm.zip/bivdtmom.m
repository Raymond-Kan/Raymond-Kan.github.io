%
%  bivdtmom.m   Date: 1/25/2016
%  This program computes E[X1^i*X2^j|a1<X1<b1,a2<X2<b2], where (X1,X2) 
%  follows a bivariate normal distribution with mean (mu_1,mu_2) 
%  and correlation \rho.
%  Input:
%  r: highest power of X1
%  s: lowest power of X2
%  a: lower truncation point of (X1,X2)
%  b: upper truncation point of (X1,X2)
%  mu1: mean of X1
%  mu2: mean of X2
%  rho: correlation between X1 and X2
%  Output
%  M: an (r+1)*(s+1) matrix of E[X1^{i-1}X2^{j-1}|a1<X1<b1,a2<X2<b2] 
%  Note: For the cases that there is no lower or upper truncations, we
%        can set some elements of a and b to be -Inf and Inf.
%
function M = bivdtmom(r,s,a,b,mu1,mu2,rho)
a1 = a(1);
a2 = a(2);
b1 = b(1);
b2 = b(2);
e1 = mu1-a1;
e2 = mu2-a2;
f1 = mu1-b1;
f2 = mu2-b2;
ss = sqrt(1-rho^2);
if isinf(a1)
   a1 = 0;
   pdfgaa = 0;
   pdfgab = 0;
else
   pdfgaa = normpdf((e2-rho*e1)/ss);
   pdfgab = normpdf((f2-rho*e1)/ss);
end
if isinf(b1)
   b1 = 0;
   pdfgba = 0;
   pdfgbb = 0;
else
   pdfgba = normpdf((e2-rho*f1)/ss);
   pdfgbb = normpdf((f2-rho*f1)/ss);
end
if isinf(a2)
   a2 = 0;
   pdfhaa = 0;
   pdfhab = 0;
else
   pdfhaa = normpdf((e1-rho*e2)/ss);
   pdfhab = normpdf((f1-rho*e2)/ss);
end
if isinf(b2)
   b2 = 0;
   pdfhba = 0;
   pdfhbb = 0;
else
   pdfhba = normpdf((e1-rho*f2)/ss);
   pdfhbb = normpdf((f1-rho*f2)/ss);
end
%
%  first construct G_{a,s}, G_{b,s}, H_{a,s}, and H_{b,s}
%
Ga = zeros(s,1);
Gb = zeros(s,1);
Ha = zeros(r+1,1);
Hb = zeros(r+1,1);
if ~isinf(e1)
   Ga(1) = normcdf((e2-rho*e1)/ss)-normcdf((f2-rho*e1)/ss);
   if s>0
      Ga(2) = (mu2-rho*e1)*Ga(1)+ss*(pdfgaa-pdfgab);
      for i=2:s-1
          Ga(i+1) = (mu2-rho*e1)*Ga(i)+ss^2*(i-1)*Ga(i-1)+ss*(a2^(i-1)*pdfgaa-b2^(i-1)*pdfgab);
      end
   end
   Ga = normpdf(e1)*Ga;
end
if ~isinf(f1)
   Gb(1) = normcdf((e2-rho*f1)/ss)-normcdf((f2-rho*f1)/ss);
   if s>0
      Gb(2) = (mu2-rho*f1)*Gb(1)+ss*(pdfgba-pdfgbb);
      for i=2:s-1
          Gb(i+1) = (mu2-rho*f1)*Gb(i)+ss^2*(i-1)*Gb(i-1)+ss*(a2^(i-1)*pdfgba-b2^(i-1)*pdfgbb);
      end
   end
   Gb = normpdf(f1)*Gb;
end
if ~isinf(e2)
   Ha(1) = normcdf((e1-rho*e2)/ss)-normcdf((f1-rho*e2)/ss);
   Ha(2) = (mu1-rho*e2)*Ha(1)+ss*(pdfhaa-pdfhab);
   for i=2:r
       Ha(i+1) = (mu1-rho*e2)*Ha(i)+ss^2*(i-1)*Ha(i-1)+ss*(a1^(i-1)*pdfhaa-b1^(i-1)*pdfhab);
   end
   Ha = normpdf(e2)*Ha;
end
if ~isinf(f2)
   Hb(1) = normcdf((e1-rho*f2)/ss)-normcdf((f1-rho*f2)/ss);
   Hb(2) = (mu1-rho*f2)*Hb(1)+ss*(pdfhba-pdfhbb);
   for i=2:r
       Hb(i+1) = (mu1-rho*f2)*Hb(i)+ss^2*(i-1)*Hb(i-1)+ss*(a1^(i-1)*pdfhba-b1^(i-1)*pdfhbb);
   end
   Hb = normpdf(f2)*Hb;
end
%
%  construct M(1,j) 
%
M = zeros(r+1,s+1);
M(1,1) = mvncdf([f1 f2],[e1 e2],[0 0],[1 rho; rho 1]);
if s>0
   M(1,2) = mu2*M(1,1)+rho*(Ga(1)-Gb(1))+Ha(1)-Hb(1);
   for j=3:s+1
       M(1,j) = mu2*M(1,j-1)+a2^(j-2)*Ha(1)-b2^(j-2)*Hb(1)+(j-2)*M(1,j-2)+rho*(Ga(j-1)-Gb(j-1));
   end
end
%
%  construct M(i,j) for i>1
%
for i=2:r+1
    if i==2
       M(2,1) = mu1*M(1,1)+Ga(1)-Gb(1)+rho*(Ha(1)-Hb(1));
    else
       M(i,1) = mu1*M(i-1,1)+a1^(i-2)*Ga(1)-b1^(i-2)*Gb(1)+(i-2)*M(i-2,1)+rho*(Ha(i-1)-Hb(i-1));
    end
    if s>0
       M(i,2) = mu2*M(i,1)+Ha(i)-Hb(i)+ ...
                rho*(a1^(i-1)*Ga(1)-b1^(i-1)*Gb(1)+(i-1)*M(i-1,1));
       for j=3:s+1
           M(i,j) = mu2*M(i,j-1)+a2^(j-2)*Ha(i)-b2^(j-2)*Hb(i)+(j-2)*M(i,j-2)+ ...
                    rho*(a1^(i-1)*Ga(j-1)-b1^(i-1)*Gb(j-1)+(i-1)*M(i-1,j-1));
       end
   end
end
M = M/M(1);
