%
%  bivutmom.m   Date: 1/25/2016
%  This program computes E[X1^i*X2^j|X1<a1,X2<a2], where (X1,X2) 
%  follows a bivariate normal distribution with mean (mu_1,mu_2) 
%  and correlation \rho.
%  Input:
%  r: highest power of X1
%  s: lowest power of X2
%  a1: upper truncation point of X1
%  a2: upper truncation point of X2
%  mu1: mean of X1
%  mu2: mean of X2
%  rho: correlation between X1 and X2
%  Output
%  M: an (r+1)*(s+1) matrix of E[X1^{i-1}X2^{j-1}|X1<a1,X2<a2] 
%
function M = bivutmom(r,s,a1,a2,mu1,mu2,rho)
e1 = mu1-a1;
e2 = mu2-a2;
ss = sqrt(1-rho^2);
b = (e2-rho*e1)/ss;
c = (e1-rho*e2)/ss;
pdfb = normpdf(b);
pdfc = normpdf(c);
%
%  first construct G_s and H_s
%
G = zeros(s,1);
if a1==Inf&&a2==Inf
   G(1) = 1;
else
   G(1) = normcdf(-b);
end
if s>0&&a1~=Inf
   G(2) = (mu2-rho*e1)*G(1)-ss*pdfb;
   for i=2:s-1
       if a2==Inf
          G(i+1) = (mu2-rho*e1)*G(i)+ss^2*(i-1)*G(i-1);
       else
          G(i+1) = (mu2-rho*e1)*G(i)+ss^2*(i-1)*G(i-1)-ss*a2^(i-1)*pdfb;
       end
   end
end
H = zeros(r+1,1);
if a1==Inf&&a2==Inf
   H(1) = 1;
else
   H(1) = normcdf(-c);
end
if r>0&&a2~=Inf
   H(2) = (mu1-rho*e2)*H(1)-ss*pdfc;
   for i=2:r
       if a1==Inf
          H(i+1) = (mu1-rho*e2)*H(i)+ss^2*(i-1)*H(i-1);
       else
          H(i+1) = (mu1-rho*e2)*H(i)+ss^2*(i-1)*H(i-1)-ss*a1^(i-1)*pdfc;
       end
   end
end
G = normpdf(e1)*G;
H = normpdf(e2)*H;
%
%  construct M(1,j)
%
M = zeros(r+1,s+1);
M(1,1) = bnorm(-e1,-e2,rho);
if s>0
   M(1,2) = mu2*M(1,1)-rho*G(1)-H(1);
   for j=3:s+1
       if a2==Inf
          M(1,j) = mu2*M(1,j-1)+(j-2)*M(1,j-2)-rho*G(j-1);
       else
          M(1,j) = mu2*M(1,j-1)-a2^(j-2)*H(1)+(j-2)*M(1,j-2)-rho*G(j-1);
       end
   end
end
%
%  construct M(i,j) for i>1
%
for i=2:r+1
    if i==2
       M(2,1) = mu1*M(1,1)-G(1)-rho*H(1);
    else
       if a1==Inf   
          M(i,1) = mu1*M(i-1,1)+(i-2)*M(i-2,1)-rho*H(i-1);
       else
          M(i,1) = mu1*M(i-1,1)+(i-2)*M(i-2,1)-a1^(i-2)*G(1)-rho*H(i-1);
       end
    end
    if s>0
       if a1==Inf
          M(i,2) = mu2*M(i,1)-H(i)+rho*(i-1)*M(i-1,1);
       else
          M(i,2) = mu2*M(i,1)-H(i)+rho*((i-1)*M(i-1,1)-a1^(i-1)*G(1));
       end
       for j=3:s+1
           M(i,j) = mu2*M(i,j-1)+(j-2)*M(i,j-2)+rho*(i-1)*M(i-1,j-1);
           if a1~=Inf
              M(i,j) = M(i,j)-rho*a1^(i-1)*G(j-1);
           end
           if a2~=Inf
              M(i,j) = M(i,j)-a2^(j-2)*H(i);
           end
       end
    end
end
M = M/M(1);
