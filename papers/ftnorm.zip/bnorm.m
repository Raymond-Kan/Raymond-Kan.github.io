function z = bnorm(x,y,r)
%
%   A function to compute the cumulative bivariate normal density
%   with parameter r.
%
if isinf(x)||isinf(y)
   if x==-Inf||y==-Inf
      z = 0;
   else
      if isinf(x)
         z = normcdf(y);
      else
         z = normcdf(x);
      end
   end
   return
end
if abs(r)~=1
   if x==0&&y==0
      z = 0.25+asin(r)/(2*pi);
      return
   end
   temp = 1/sqrt(1-r*r);
   if x~=0
      t1 = tfun(x,y*temp/x-r*temp);
   else
      t1 = (1-2*(y<0))/4;       % tfun(0,(-)inf) = (-)1/4
   end
   if y~=0
      t2 = tfun(y,x*temp/y-r*temp);
   else
      t2 = (1-2*(x<0))/4;
   end
   z = max(0,0.5*(normcdf(x)+normcdf(y)-((x*y<0)|((x*y==0)&(x+y<0))))-t1-t2);
else
   if r==1
      z = normcdf(min(x,y));                 % P[X<x;X<y]=P[X<min(x,y)]
   else
      z = max(normcdf(x)-normcdf(-y),0);     % P[X<x;-X<y]=P[-y<X<x]
   end
end

