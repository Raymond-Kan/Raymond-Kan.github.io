%
%  dtmvnmom.m   Date: 1/25/2016
%  This program computes the mean and covariance matrix of Y,
%  where Y is a doubly truncated multivariate normal with parameters
%  mu and S, and lower and upper truncation limits of a and b.
%  Input:
%  a: lower truncation limits
%  b: upper truncation limits
%  mu: an nx1 vector of mean of X
%  S: an nxn covariance matrix of X
%  Output
%  muY: E[Y] = E[X|a<X<b]
%  varY: Var[Y] = Var[X|a<X<b]
%
function [muY,varY] = dtmvnmom(a,b,mu,S)
if size(a,2)>1
   a = a';
end
if size(b,2)>1
   b = b';
end
if size(mu,2)>1
   mu = mu';
end
n = length(mu);
s = sqrt(diag(S));
if n==1
   a1 = (a-mu)/s;
   b1 = (b-mu)/s;
   p = normcdf(b1)-normcdf(a1);
   muY = mu+(normpdf(a1)-normpdf(b1))*s/p;
   if isinf(a)
      a = 0;
   end
   if isinf(b)
      b = 0;
   end
   varY = S+(mu-muY)*muY+(a*normpdf(a1)-b*normpdf(b1))*s/p;
   return
end
a1 = a-mu;
b1 = b-mu;
if n==4
   p = quadncdfab(a1,b1,S);
else
   p = mvncdf(a,b,mu,S);
end
[qa,qb] = qfun(a1,b1,S);
q = qa-qb;
muY = mu+S*q/p;
D = zeros(n);
for i=1:n
    if ~isinf(a(i))
       D(i,i) = a(i)*qa(i);
    end
    if ~isinf(b(i))
       D(i,i) = D(i,i)-b(i)*qb(i);
    end
    ind = 1:n;
    ind(i) = [];           
    RR = S(ind,ind)-S(ind,i)*S(i,ind)/S(i,i);
    if isinf(a(i))
       wa = zeros(n-1,1);
    else
       ma = mu(ind)+S(ind,i)/S(i,i)*a1(i);
       [qa1,qb1] = qfun(a(ind)-ma,b(ind)-ma,RR);
       wa = qa(i)*ma+normpdf(a(i),mu(i),s(i))*RR*(qa1-qb1);
    end
    if isinf(b(i))
       wb = zeros(n-1,1);
    else
       mb = mu(ind)+S(ind,i)/S(i,i)*b1(i);
       [qa2,qb2] = qfun(a(ind)-mb,b(ind)-mb,RR);
       wb = qb(i)*mb+normpdf(b(i),mu(i),s(i))*RR*(qa2-qb2);
    end
    D(i,ind) = wa-wb;
end
varY = S+S*(D-q*muY')/p;
end

function [qa,qb] = qfun(a,b,S)
n = length(a);
s = sqrt(diag(S));
if n==1
   qa = normpdf(a/s)/s;
   qb = normpdf(b/s)/s;
   return
end
qa = zeros(n,1);
qb = zeros(n,1);
for i=1:n
    ind = 1:n;
    ind(i) = [];
    B = S(ind,i)/S(i,i);
    RR = S(ind,ind)-B*S(i,ind);
    a1 = a(ind);
    b1 = b(ind);
    if ~isinf(a(i))
       if n==5
          qa(i) = normpdf(a(i),0,s(i))*quadncdfab(a1-B*a(i),b1-B*a(i),RR);
       else
          qa(i) = normpdf(a(i),0,s(i))*mvncdf(a1,b1,B*a(i),RR);
       end
    end
    if ~isinf(b(i))
       if n==5
          qb(i) = normpdf(b(i),0,s(i))*quadncdfab(a1-B*b(i),b1-B*b(i),RR);
       else
          qb(i) = normpdf(b(i),0,s(i))*mvncdf(a1,b1,B*b(i),RR);
       end
    end
end

end
