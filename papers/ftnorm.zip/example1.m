%
%  example1.m
%  This program illustrates how to use various bivariate
%  moment programs
%
delete example1.out
diary example1.out
m1 = 0.2;   % mean of X_1
m2 = 0.4;   % mean of X_2
rho = 0.3;  % correlation coefficient between X_1 and X_2
fprintf(' Mean of X_1 = %5.2f\n',m1)
fprintf(' Mean of X_2 = %5.2f\n',m2)
fprintf(' Correlation between X_1 and X_2 = %5.2f\n\n',rho)
fprintf(' E[|X_1^i*X_2^j|], i=0,...,4, j=0,...,5:\n')
ma = bivamom(4,5,m1,m2,rho)
fprintf(' E[X_1^i*X_2^j|X_1>0.5,X_2>1], i=0,...,4, j=0,...,5:\n')
mb = bivltmom(4,5,0.5,1,m1,m2,rho)
fprintf(' E[X_1^i*X_2^j|X_1<0.5,X_2<1], i=0,...,4, j=0,...,5:\n')
mc = bivutmom(4,5,0.5,1,m1,m2,rho)
fprintf(' E[X_1^i*X_2^j|-2<X_1<0.5,-3<X_2<1], i=0,...,4, j=0,...,5:\n')
md = bivdtmom(4,5,[-2 -3],[0.5 1],m1,m2,rho)
fprintf(' E[X_1^i*X_2^j|-2<X_1<Inf,-Inf<X_2<1], i=0,...,4, j=0,...,5:\n')
me = bivdtmom(4,5,[-2 -Inf],[Inf 1],m1,m2,rho)
diary off
