%
%  example2.m
%  This program illustrates how to use various multivariate
%  moment programs
%
delete example2.out
diary example2.out
mu = [0.1 0.2 0.3 0.4]';   % mean of X
S = [1 0.2 0.3 0.1; 0.2 1 0.4 -0.1; 0.3 0.4 1 0.2; 0.1 -0.1 0.2 1];  % covariance matrix of X
fprintf(' E[|X_1^i*X_2^j*X_3^k*X_4^l|], i=0,...,6, j=0,...,5, k=0,...,3, l=0,...,2:\n')
ma = multivamom([6 5 3 2],mu,S)
fprintf(' E[X_1^i*X_2^j*X_3^k*X_4^l|X_1>0.5,X_2>0.6,X_3>0.7,X_4>0.8], i=0,...,6, j=0,...,5, k=0,...,3, l=0,...,2:\n')
mb = multivltmom([6 5 3 2],[0.5 0.6 0.7 0.8],mu,S)
fprintf(' E[X_1^i*X_2^j*X_3^k*X_4^l|X_1>0.5,X_2>0.6,X_3>0.7,X_4>0.8], i=0,...,6, j=0,...,5, k=0,...,3, l=0,...,2:\n')
mb1 = multivltmomi([6 5 3 2],[0.5 0.6 0.7 0.8],mu,S)
fprintf(' E[X_1^i*X_2^j*X_3^k*X_4^l|X_1<0.5,X_2<0.6,X_3<0.7,X_4<0.8], i=0,...,6, j=0,...,5, k=0,...,3, l=0,...,2:\n')
mc = multivutmom([6 5 3 2],[0.5 0.6 0.7 0.8],mu,S)
fprintf(' E[X_1^i*X_2^j*X_3^k*X_4^l|X_1<0.5,X_2<0.6,X_3<0.7,X_4<0.8], i=0,...,6, j=0,...,5, k=0,...,3, l=0,...,2:\n')
mc1 = multivutmomi([6 5 3 2],[0.5 0.6 0.7 0.8],mu,S)
fprintf(' E[X_1^i*X_2^j*X_3^k*X_4^l|-0.8<X_1<0.5,-0.7<X_2<0.6,-0.6<X_3<0.7,-0.5<X_4<0.8], i=0,...,6, j=0,...,5, k=0,...,3, l=0,...,2:\n')
md = multivdtmom([6 5 3 2],[-0.8 -0.7 -0.6 -0.5],[0.5 0.6 0.7 0.8],mu,S)
fprintf(' E[X_1^i*X_2^j*X_3^k*X_4^l|-Inf<X_1<0.5,-0.7<X_2<0.6,-0.6<X_3<0.7,-0.5<X_4<Inf], i=0,...,6, j=0,...,5, k=0,...,3, l=0,...,2:\n')
me = multivdtmom([6 5 3 2],[-Inf -0.7 -0.6 -0.5],[0.5 0.6 0.7 Inf],mu,S)
diary off
