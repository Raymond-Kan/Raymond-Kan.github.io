%
%  fnormcdf.m   Date: 1/25/2016
%  This program computes the cumulative distribution function of |X|,
%  where X ~ N(mu,S).
%
function F = fnormcdf(y,mu,S)
F = 0;
if any(y<=0)
   return
end
if any(isinf(y))
   ind = find(~isinf(y));
   y = y(ind);
   mu = mu(ind);
   S = S(ind,ind);
end
if length(mu)==4
   F = quadncdfab(-y-mu,y-mu,S);
else
   F = mvncdf(-y,y,mu,S);
end