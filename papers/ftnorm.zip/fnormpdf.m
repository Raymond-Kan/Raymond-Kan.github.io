%
%  fnormpdf.m   Date: 1/25/2016
%  This program computes the density function of |X|,
%  where X ~ N(mu,S).
%
function f = fnormpdf(y,mu,S)
f = 0;
if any(y<=0)
   return
end
n = length(mu);
if size(mu,1)>1
   mu = mu';
end
if size(y,1)>1
   y = y';
end
ys = ones(2^n,1)*y.*(2*(dec2bin(0:2^n-1,n)-'0')-1);
f = sum(mvnpdf(ys,mu,S)); 
    