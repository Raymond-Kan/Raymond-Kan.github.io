%
%  multivamom.m   Date: 1/25/2016
%  This program computes E[prod_{i=1}^n|X_i|^{k_i}], where (X_1,..,X_n) 
%  follows a multivariate normal distribution with mean mu and covariance
%  matrix S.
%  Input:
%  kappa: power of X_i's
%  mu: E[X]
%  S: Var[X]
%  Output
%  M: E[\prod_{i=1}^n|X_i^{I_i}|], where I_i ranges from 0 to k_i
%
function M = multivamom(kappa,mu,S)
if size(kappa,1)>1
   kappa = kappa';
end
if size(mu,2)>1
   mu = mu';
end
n = length(mu);
if n==1
   M = ones(kappa+1,1);
   s = sqrt(S);
   mu = mu/s;
   M(2) = mu*erf(mu/sqrt(2))+2*normpdf(mu);
   if kappa>1
      M(3) = mu^2+1;
      if kappa>2
         M(4) = (mu^3+3*mu)*erf(mu/sqrt(2))+(2*mu^2+4)*normpdf(mu);
         for k=4:kappa
             M(k+1) = (mu^2+2*k-3)*M(k-1)-(k-2)*(k-3)*M(k-3);
         end
      end
   end
   M(2:end) = M(2:end).*s.^[1:kappa]';
   return
end
M = zeros(kappa+1);
pk = prod(kappa+1);
for i=0:2^n-1
    ind1 = 2*(dec2bin(i,n)-'0')-ones(1,n);  % this is the array for s, which has values of -1 or 1
    M = M+recint(kappa,mu.*ind1',S.*(ind1'*ind1));
end
M(1) = 1;
