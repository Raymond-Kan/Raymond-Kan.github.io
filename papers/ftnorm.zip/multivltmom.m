%
%  multivltmom.m   Date: 1/25/2016
%  This program computes E[prod_{i=1}^nX_i^{k_i}|X_i>a_i], where (X_1,..,X_n) 
%  follows a multivariate normal distribution with mean mu and covariance
%  matrix S, and lower truncation limits of a_i.
%  Input:
%  kappa: power of X_i's
%  a: lower truncation limits
%  mu: E[X]
%  S: Var[X]
%  Output
%  M: E[\prod_{i=1}^nX_i^{I_i}|X_i>a_i], where I_i ranges from 0 to k_i
%
function M = multivltmom(kappa,a,mu,S)
if size(kappa,1)>1
   kappa = kappa';
end
if size(a,2)>1
   a = a';
end
if size(mu,2)>1
   mu = mu';
end
%
%  Compute the moments of lower truncated multivariate normal
%
n = length(mu);
M = recintab(kappa,a,Inf(n,1),mu,S);
M = M/M(1);
   