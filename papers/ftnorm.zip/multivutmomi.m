%
%  multivutmomi.m   Date: 1/25/2016
%  This program computes E[prod_{i=1}^nX_i^{k_i}|X_i<a_i], where (X_1,..,X_n) 
%  follows a multivariate normal distribution with mean mu and covariance
%  matrix S, and upper truncation limits of a_i.  It is based on a binomial
%  expansion of the I integrals. 
%  Input:
%  kappa: power of X_i's
%  a: upper truncation limits
%  mu: E[X]
%  S: Var[X]
%  Output
%  M: E[\prod_{i=1}^nX_i^{I_i}|X_i<a_i], where I_i ranges from 0 to k_i
%
function M = multivutmomi(kappa,a,mu,S)
if size(kappa,1)>1
   kappa = kappa';
end
if size(a,2)>1
   a = a';
end
if size(mu,2)>1
   mu = mu';
end
n = length(mu);
ind = find(isinf(a));
m = length(ind);
a(ind) = 0;
aa = -a;
M = zeros(kappa+1);
cs = 0;
ck = [1 cumprod(kappa(1:n-1)+1)]';
for ii=0:2^m-1
    ind1 = 2*(dec2bin(ii,m)-'0')-ones(1,m);  % this is the array for s, which has values of -1 or 1
    ind2 = ones(n,1);
    ind2(ind) = ind1;
    mu1 = mu.*ind2;
    S1 = S.*(ind2*ind2');
    eta = a-mu1;
    M1 = recint(kappa,eta,S1);
    pk = prod(kappa+1);
    [out{1:n}] = ind2sub(kappa+1,[1:pk]');
    kappa1 = cell2mat(out)-1;
%
%  Compute the moments of truncated multivariate normal
%
    M2 = zeros(kappa+1);
    M2(1) = M1(1);
    ind3 = find(ind2==-1);
    for i=2:pk
        sk = sum(kappa1(i,ind3));
        M2(i) = binom(kappa1(i,:))*(-1)^sk;
    end
    M = M+M2;
    cs = cs+M1(1);
end
M = M/cs;    

function y = binom(nu)
   x = zeros(1,n);
   c = 1;
   y = M1(nu*ck+1);  % first element
   ind1 = find(nu>0&aa'~=0);
   for j=2:prod(nu(ind1)+1)
       for k=ind1
           if x(k)<nu(k)
              x(k) = x(k)+1;
              c = c*aa(k)*(nu(k)-x(k)+1)/x(k);
              break
           else
              x(k) = 0;
              c = c/aa(k)^nu(k);
           end
       end
       y = y+c*M1((nu-x)*ck+1);
   end
   y = y*(-1)^sum(nu);    
end
       
end    
    
    