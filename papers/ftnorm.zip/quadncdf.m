%
%  quadncdf.m   Date: 1/25/2016
%  This program computes P[X_i<a_i, i=1,...,4], where (X_1,X_2,X_3,X_4)
%  follows a multivariate normal distribution with zero mean and 
%  covariance matrix S.
%
function y = quadncdf(a,S)
if size(a,2)>1
   a = a';
end
n = length(a);
s = sqrt(diag(S));
a = a./s;
S = S./(s*s');
S12 = S(1,2:end);
S21 = S12';
S22 = S(2:end,2:end);
Sa = S22-S21*S12;
a2 = a(2:end);
y = integral(@intgd,-Inf,a(1),'AbsTol',1e-10,'RelTol',1e-10);

function w = intgd(x)
   m = length(x);
   mua = a2*ones(1,m)-S21*x;
   w = normpdf(x).*mvncdf(mua',zeros(1,n-1),Sa)';
end

end
