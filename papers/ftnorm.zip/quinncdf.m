%
%  quinncdf.m   Date: 1/25/2016
%  This program computes P[X_i<a_i, i=1,...,5], where (X_1,...,X_5)
%  follows a multivariate normal distribution with zero mean and
%  covariance matrix S.
%
function y = quinncdf(a,S)
if size(a,2)>1
   a = a';
end
s = sqrt(diag(S));
a = a./s;
S = S./(s*s');
r = S(1,2)/(s(1)*s(2));
C = S(1:2,1:2);
Sa = S(3:5,3:5)-S(3:5,1:2)*inv(C)*S(1:2,3:5);
q = S(3:5,1:2)*inv(C);
y = integral2(@(x1,x2) intgd(x1,x2),-Inf,a(1),-Inf,a(2),'AbsTol',1e-10,'RelTol',1e-10);

function w = intgd(x1,x2)
   m = length(x1);
   f = mvnpdf([x1(:) x2(:)],zeros(1,2),C);
   ma = [a(3)*ones(1,m)-q(1,1)*x1-q(1,2)*x2; a(4)*ones(1,m)-q(2,1)*x1-q(2,2)*x2; a(5)*ones(1,m)-q(3,1)*x1-q(3,2)*x2];
   w = f'.*mvncdf(ma',zeros(1,3),Sa)';
end

end
