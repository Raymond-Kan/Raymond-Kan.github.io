%
%  quinncdfab.m   Date: 1/25/2016
%  This program computes P[a_i<X_i<b_i, i=1,...,5], where (X_1,...,X_5)
%  follows a multivariate normal distribution with zero mean and  
%  covariance matrix S.
%
function y = quinncdfab(a,b,S)
if size(a,2)>1
   a = a';
end
if size(b,2)>1
   b = b';
end
s = sqrt(diag(S));
a = a./s;
b = b./s;
S = S./(s*s');
C = S(1:2,1:2);
Sa = S(3:5,3:5)-S(3:5,1:2)*inv(C)*S(1:2,3:5);
q = S(3:5,1:2)*inv(C);
y = integral2(@(x1,x2) intgd(x1,x2),a(1),b(1),a(2),b(2),'AbsTol',1e-10,'RelTol',1e-10);

function w = intgd(x1,x2)
   [n,m] = size(x1);
   x1 = x1(:);
   x2 = x2(:);
   mm = [-q(1,1)*x1-q(1,2)*x2 -q(2,1)*x1-q(2,2)*x2 -q(3,1)*x1-q(3,2)*x2]';
   ma = a(3:5)*ones(1,m*n)+mm;
   mb = b(3:5)*ones(1,m*n)+mm;
   f = mvnpdf([x1 x2],zeros(1,2),C);
   w = reshape(f.*mvncdf(ma',mb',zeros(1,3),Sa),n,m);
end

end
