These are programs for the paper "On Moments of of Folded and Truncated Multivariate
Normal Distributions."  If you have questions, comments, or bug reports, please send 
them to kan@chass.utoronto.ca

Raymond Kan
Rotman School of Management
University of Toronto

Version 1.0: 3/15/2016, initial release
Version 1.1: 3/27/2016, add dtmvnmom.m
Version 1.2: 4/21/2018, modify bivltmom.m, bivutmom.m, multivltmomi.m and multivutmomi.m 
             to handle cases with a_i=-Inf or b_i=Inf.
             Add quinncdf.m and quinncdfab.m and modify recint.m and recintab.m to use these
             new programs to improve accuracy for the 5-variate case.
Version 1.3: 6/15/2020, modify recintab.m to potentially improve the computation when
             normcdf or mvncdf returns zero probability.
Version 1.4: 8/19/2020, minor fix of calling mvncdf in recint.m

Folded normal distribution:
bivamom.m: Compute absolute moments of a bivariate normal, using the recursive algorithm
fnormcdf.m: Compute cdf of a folded mulativariate normal distribution
fnormpdf.m: Compute pdf of a folded mulativariate normal distribution
fnormmom.m: Compute mean and covariance matrix of a folded multivariate normal distribution
multivamom.m: Compute absolute moments of a multivariate normal, using the recursive algorithm
             
Truncated normal distribution:             
bivltmom.m: Compute moments of a lower truncated bivariate normal, using the recursive algorithm
bivutmom.m: Compute moments of an upper truncated bivariate normal, using the recursive algorithm
bivdtmom.m: Compute moments of a doubly truncated bivariate normal, using the recursive algorithm
dtmvnmom.m: Compute mean and covariance matrix of a doubly truncated multivariate normal
multivdtmom.m: Compute moments of a doubly truncated multivariate normal, using the recursive algorithm
multivltmom.m: Compute moments of a lower truncated multivariate normal, using the recursive algorithm
multivltmomi.m: Compute moments of a lower truncated multivariate normal, using the recursive algorithm but
                based on a binomial expansion
multivutmom.m: Compute moments of an upper truncated multivariate normal, using the recursive algorithm
multivutmomi.m: Compute moments of an upper truncated multivariate normal, using the recursive algorithm but
                based on a binomial expansion

Common programs:
bnorm.m: Compute cdf of a standard bivariate normal with correlation rho
quadncdf.m: Compute the cdf of a 4-variate normal distribution using numerical integration,
            this provides a more accurate answer than mvncdf
quadncdfab.m: Compute P[a<X<b] for a 4-variate normal distribution using numerical integration,
              this provides a more accurate answer than mvncdf
quinncdf.m: Compute the cdf of a 5-variate normal distribution using numerical integration,
            this provides a more accurate answer than mvncdf
quinncdfab.m: Compute P[a<X<b] for a 5-variate normal distribution using numerical integration,
              this provides a more accurate answer than mvncdf
recint.m: Compute a multivariate integral (which integrates from 0 to Inf) using recursive algorithm 
recintab.m: Compute a multivariate integral (which integrates from a to b) using recursive algorithm
tfun.m: Compute Owen's T-function, used by bnorm.m

Sample programs:
example1.m: A sample program that demonstrates how to call the bivariate moment programs
example2.m: A sample program that demonstrates how to call the multivariate moment programs
