%
%  recint.m   Date: 1/25/2016
%  This program computes the integral of int_0^\inf x^\kappa f(x)dx,
%  where f(x) is the multivariate normal density with
%  mean mu and covariance matrix S.
%  Input:
%  kappa: power of X
%  mu: Expected value of X (a column vector)
%  S: Covariance matrix of X
%  Output
%  M: A matrix of dimension (k_1+2)*..*(k_n+2) of the integrals,
%     with its \nu-th element corresponds to 
%     int_0^\inf x^{\nu-2} f(x)dx.  For any element of nu that is 
%     equal to 1, the submatrix is actually not this integral but 
%     is in fact a submatrix of integrals of lower dimension.  They
%     are stored there for the purpose of doing the recursion.
%
function M = recint(kappa,mu,S)
n = length(kappa);
if n==1
   M = zeros(kappa+1,1);
   s1 = sqrt(S);
   mu = mu/s1;
   M(1) = normcdf(mu);
   if kappa>0
      M(2) = s1*(mu*M(1)+normpdf(mu));
      for i=2:kappa
          M(i+1) = s1*(mu*M(i)+(i-1)*s1*M(i-1));
      end
   end
else
%
%  Create a matrix M, with its nu-th element correpsonds to F_{nu-2}^n(mu,S).
%
   M = zeros(kappa+1);
   pk = prod(kappa+1);
%
%  We create a long vector G to store the set of integrals with
%  dimension n-1.
%
   nn = round(pk./(kappa+1));   
   begind = cumsum([0 nn]);  
%  Each row of cp corresponds to a vector that allows us to map the subscripts
%  to index in the long G vector
   cp = zeros(n);           
   for i=1:n
       kk = kappa;
       kk(i) = 0;
       cp(i,:) = [1 cumprod(kk(1:n-1)+1)];
   end
   G = zeros(begind(n+1),1);
   pdfm = normpdf(mu,0,sqrt(diag(S)));
   for i=1:n
       ind2 = 1:n;
       ind2(i) = [];
       mua = mu(ind2)-S(ind2,i)/S(i,i)*mu(i);
       Sa = S(ind2,ind2)-S(ind2,i)*S(i,ind2)/S(i,i);
       ind = begind(i)+1:begind(i+1);
       G(ind) = pdfm(i)*recint(kappa(ind2),mua,Sa);
   end    
%
%  Use recursion to obtain M(nu).
%  For the 4 and 5-dimensional casee, we use a direct integration
%  method to obtain a more accurate answer as mvncdf uses
%  simulation for n>3.       
%
   if n<=3
      M(1) = mvncdf(mu,zeros(n,1),S);
   elseif n==4
      M(1) = quadncdf(mu,S);
   elseif n==5
      M(1) = quinncdf(mu,S);
   else
      options = statset('TolFun',1e-6,'MaxFunEvals',5e7);
      M(1) = mvncdf(mu,zeros(n,1),S,options);
   end
   cp1 = cp(n,:)';
   for i=2:pk
       [out{1:n}] = ind2sub(kappa+1,i);
       kk = cell2mat(out);
       ii = (kk-1)*cp1+1;
       i1 = min(find(kk>1));  % find a nonzero element to start the recursion
       kk1 = kk;
       kk1(i1) = kk1(i1)-1;
       ind3 = ii-cp1(i1);
       M(ii) = mu(i1)*M(ind3);
       for j=1:n
           kk2 = kk1(j)-1;
           if kk2>0
              M(ii) = M(ii)+S(i1,j)*kk2*M(ind3-cp1(j));
           else
              ind4 = begind(j)+cp(j,:)*(kk1-1)'-cp(j,j)*kk2+1;
              M(ii) = M(ii)+S(i1,j)*G(ind4);
           end
       end
   end
end
