%
%  recintab.m   Date: 4/43/2020
%  This program computes the integral of int_a^b x^\kappa f(x)dx,
%  where f(x) is the multivariate normal density with
%  mean mu and covariance matrix S.
%  Input:
%  kappa: power of X
%  a: lower limit of integration
%  b: upper limit of integration
%  mu: Expected value of X (a column vector)
%  S: Covariance matrix of X
%  Output
%  M: A matrix of dimension (k_1+1)*..*(k_n+1) of the integrals,
%     with its \nu-th element corresponds to 
%     int_a^a x^{\nu-1} f(x)dx.  
%
function M = recintab(kappa,a,b,mu,S)
n = length(kappa);
if n==1
   M = zeros(kappa+1,1);
   s1 = sqrt(S);
   aa = (a-mu)/s1;
   bb = (b-mu)/s1;
   M(1) = normcdf(bb)-normcdf(aa);
   if M(1)==0
      M(1) = normcdf(-aa)-normcdf(-bb);
      if M(1)==0
         fprintf(' Numerical error in computing NORMCDF!\n')
      end
   end
   if kappa>0
      pdfa = s1*normpdf(aa);
      pdfb = s1*normpdf(bb);
      M(2) = mu*M(1)+pdfa-pdfb;
      if isinf(a)
         a = 0;
      end
      if isinf(b)
         b = 0;
      end
      for i=2:kappa
          pdfa = pdfa*a;
          pdfb = pdfb*b;
          M(i+1) = mu*M(i)+(i-1)*S*M(i-1)+pdfa-pdfb;
      end
   end
else
%
%  Create a matrix M, with its nu-th element correpsonds to F_{nu-2}^n(mu,S).
%
   M = zeros(kappa+1);
   pk = prod(kappa+1);
%
%  We create two long vectors G and H to store the two different sets
%  of integrals with dimension n-1.
%
   nn = round(pk./(kappa+1));   
   begind = cumsum([0 nn]);  
   pk1 = begind(n+1);   % number of (n-1)-dimensional integrals
%  Each row of cp corresponds to a vector that allows us to map the subscripts
%  to the index in the long vectors G and H
   cp = zeros(n);           
   for i=1:n
       kk = kappa;
       kk(i) = 0;
       cp(i,:) = [1 cumprod(kk(1:n-1)+1)];
   end
   G = zeros(pk1,1);
   H = zeros(pk1,1);
   s = sqrt(diag(S));
   pdfa = normpdf(a,mu,s);
   pdfb = normpdf(b,mu,s);
   for i=1:n
       ind2 = 1:n;
       ind2(i) = [];
       kappai = kappa(ind2);
       ai = a(ind2);
       bi = b(ind2);
       mui = mu(ind2);
       Si = S(ind2,i);
       SSi = S(ind2,ind2)-Si*Si'/S(i,i);      
       ind = begind(i)+1:begind(i+1);
       if ~isinf(a(i))
          mai = mui+Si/S(i,i)*(a(i)-mu(i));
          G(ind) = pdfa(i)*recintab(kappai,ai,bi,mai,SSi);
       end
       if ~isinf(b(i))
          mbi = mui+Si/S(i,i)*(b(i)-mu(i));
          H(ind) = pdfb(i)*recintab(kappai,ai,bi,mbi,SSi);
       end
   end    
%
%  Use recursion to obtain M(nu).
%  For the 4 and 5-dimensional cases, we use a direct integration
%  method to obtain a more accurate answer as mvncdf uses
%  simulation for n>3.       
%
   if n<=3
      M(1) = mvncdf(a,b,mu,S);
      if M(1)==0
         M(1) = mvncdf(-b,-a,-mu,S);
         if M(1)==0
            fprintf(' Numerical error in computing MVNCDF!\n')
         end
      end
   elseif n==4
      M(1) = quadncdfab(a-mu,b-mu,S);
   elseif n==5
      M(1) = quinncdfab(a-mu,b-mu,S);
   else
      options = statset('TolFun',1e-6,'MaxFunEvals',5e7);
      if all(b==Inf)
         M(1) = mvncdf(-b,-a,-mu,S,options);
      else
         M(1) = mvncdf(a,b,mu,S,options);
      end
   end
   a(isinf(a)) = 0;
   b(isinf(b)) = 0;    
   cp1 = cp(n,:)';
   for i=2:pk
       [out{1:n}] = ind2sub(kappa+1,i);
       kk = cell2mat(out);
       ii = (kk-1)*cp1+1;
       i1 = min(find(kk>1));  % find a nonzero element to start the recursion
       kk1 = kk;
       kk1(i1) = kk1(i1)-1;
       ind3 = ii-cp1(i1);
       M(ii) = mu(i1)*M(ind3);
       for j=1:n
           kk2 = kk1(j)-1;
           if kk2>0
              M(ii) = M(ii)+S(i1,j)*kk2*M(ind3-cp1(j));
           end
           ind4 = begind(j)+cp(j,:)*(kk1-1)'-cp(j,j)*kk2+1;
           M(ii) = M(ii)+S(i1,j)*(a(j)^kk2*G(ind4)-b(j)^kk2*H(ind4));
       end    
   end
end
