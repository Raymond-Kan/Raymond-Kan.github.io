function t = tfun(h,a)
%
%   A Matlab program to compute the Owen's T function
%   Source: Patfield and Tandy, Journal of Statistical Software (2005)
%
%
%   Take care of two special cases first
%
if a==0
   t = 0;
   return
end
if h==0&&isinf(a)
   t = sign(a)/4;
   return
end
rroot2 = 0.70710678118654752440;
absh = abs(h);
absa = abs(a);
ah = absa*absh;
if absa<=1
   t = tf1(absh,absa,ah);
else
   if absh<=0.67
      t = 0.25-0.25*erf(absh*rroot2)*erf(ah*rroot2)-tf1(ah,1/absa,absh);
   else
      normh = 0.5*erfc(absh*rroot2);
      normah = 0.5*erfc(ah*rroot2);
      t = 0.5*(normh+normah)-normh*normah-tf1(ah,1/absa,absh);
   end
end
if a<0
   t = -t;
end

function tf = tf1(h,a,ah)
rtwopi = 0.15915494309189533577;
rrtpi = 0.39894228040143267794;
c2= [0.99999999999999987510d+00 -0.99999999999988796462d+00 0.99999999998290743652d+00 ...
     -0.99999999896282500134d+00 0.99999996660459362918d+00 -0.99999933986272476760d+00 ...
     0.99999125611136965852d+00 -0.99991777624463387686d+00 0.99942835555870132569d+00 ...
     -0.99697311720723000295d+00 0.98751448037275303682d+00 -0.95915857980572882813d+00 ...
     0.89246305511006708555d+00 -0.76893425990463999675d+00 0.58893528468484693250d+00 ...
     -0.38380345160440256652d+00 0.20317601701045299653d+00 -0.82813631607004984866d-01 ...
     0.24167984735759576523d-01 -0.44676566663971825242d-02 0.39141169402373836468d-03];
pts = [0.35082039676451715489d-02 0.31279042338030753740d-01 0.85266826283219451090d-01 ...
       0.16245071730812277011d+00 0.25851196049125434828d+00 0.36807553840697533536d+00 ...
       0.48501092905604697475d+00 0.60277514152618576821d+00 0.71477884217753226516d+00 ...
       0.81475510988760098605d+00 0.89711029755948965867d+00 0.95723808085944261843d+00 ...
       0.99178832974629703586d+00]; 
wts = [0.18831438115323502887d-01 0.18567086243977649478d-01 0.18042093461223385584d-01 ...
       0.17263829606398753364d-01 0.16243219975989856730d-01 0.14994592034116704829d-01 ...
       0.13535474469662088392d-01 0.11886351605820165233d-01 0.10070377242777431897d-01 ...
       0.81130545742299586629d-02 0.60419009528470238773d-02 0.38862217010742057883d-02 ...
       0.16793031084546090448d-02];
meth = [1 1 1 1 1 1 1 1 2 2 2 3 4 4 4 4 5 6];
ord = [2 3 4 5 7 10 12 18 10 20 30 20 4 7 8 20 13 0];
hrange = [0.02 0.06 0.09 0.125 0.26 0.4 0.6 1.6 1.7 2.33 2.4 3.36 3.4 4.8 Inf];
arange = [0.025 0.09 0.15 0.36 0.5 0.9 0.99999 1];
select = [1 1 2 13 13 13 13 13 13 13 13 16 16 16 9; 1 2 2 3 3 5 5 14 14 15 15 16 16 16 9; ...
          2 2 3 3 3 5 5 15 15 15 15 16 16 16 10; 2 2 3 5 5 5 5 7 7 16 16 16 16 16 10; ...
          2 3 3 5 5 6 6 8 8 17 17 17 12 12 11; 2 3 5 5 5 6 6 8 8 17 17 17 12 12 12; ...
          2 3 4 4 6 6 8 8 17 17 17 17 17 12 12; 2 3 4 4 6 6 18 18 18 18 17 17 17 12 12]';
%
%  determine appropriate method from t1...t6
%
for ihint=1:15
    if h<=hrange(ihint)
       break
    end
end
for iaint=1:8
    if a<=arange(iaint)
       break
    end
end
icode = select(ihint,iaint);
m = ord(icode);
if icode<=8
%
%  t1(h,a,m);  m = 2, 3, 4, 5, 7, 10, 12 or 18
%  jj = 2j - 1; gj = exp(-h*h/2)*(-h*h/2)**j/j!
%  aj = a**(2j-1)/(2*pi)
%
   hs = -0.5*h*h;
   dhs = exp(hs);
   as = a*a;
   aj = rtwopi*a;
   dj = dhs-1;
   gj = hs*dhs;
   tf = rtwopi*atan(a)+dj*aj;
   for j=2:m
       aj = aj*as;
       dj = gj-dj;
       gj = gj*hs/j;
       tf = tf+dj*aj/(2*j-1);
   end
elseif icode<=11
%
%  t2(h,a,m) ; m = 10, 20 or 30
%  z = (-1)**(i-1)*zi ; ii = 2i - 1
%  vi = (-1)**(i-1)*a**(2i-1)*exp[-(a*h)**2/2]/sqrt(2*pi)
%
   hs = h*h;
   as = -a*a;
   vi = rrtpi*a*exp(-0.5*ah*ah);
   z = 0.5*erf(ah*rroot2)/h;
   y = 1/hs;
   tf = z;
   for ii=1:2:2*m-1
       z = y*(vi-ii*z);
       vi = as*vi;
       tf = tf+z;
   end
   tf = tf*rrtpi*exp(-0.5*hs);
elseif icode==12
%
%  t3(h,a,m) ; m = 20
%  ii = 2i - 1 
%  vi = a**(2i-1)*exp[-0.5*(a*h)^2]/sqrt(2*pi)
%
   hs = h*h;
   as = a*a;
   vi = rrtpi*a*exp(-0.5*ah*ah);
   zi = 0.5*erf(ah*rroot2)/h;
   y = 1/hs;
   tf = zi*c2(1);
   for i=2:m+1  
       zi = y*((2*i-3)*zi-vi);
       vi = as*vi;
       tf = tf+zi*c2(i);
   end 
   tf = tf*rrtpi*exp(-0.5*hs);
elseif icode<=16
%
%  t4(h,a,m) ; m = 4, 7, 8 or 20;  ii = 2i + 1
%  ai = a*exp[-h*h*(1+a*a)/2]*(-a*a)**i/(2*pi)
%
   hs = h*h;
   as = -a*a;
   ai = rtwopi*a*exp(-0.5*hs*(1-as));
   tf = ai;
   yi = 1;
   for ii=3:2:2*m+1
       yi = (1-hs*yi)/ii;
       ai = ai*as;
       tf = tf+ai*yi;
   end
elseif icode==17
%
%  t5(h,a,m) ; m = 13
%  2m - point gaussian quadrature
%
   tf = 0;
   as = a*a;
   hs = -0.5*h*h;
   for i=1:m
       r = 1+as*pts(i);
       tf = tf+wts(i)*exp(hs*r)/r;
   end
   tf = a*tf;
else
%
%  t6(h,a);  approximation for a near 1 (a<=1)
%
   normh = 0.5*erfc(h*rroot2);
   tf = 0.5*normh*(1-normh);
   y = 1-a;
   r = atan(y/(1+a));
   if r~=0
      tf = tf-rtwopi*r*exp(-0.5*y*h*h/r);
   end
end
end

end