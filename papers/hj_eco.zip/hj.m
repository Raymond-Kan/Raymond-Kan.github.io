%
% hj.m
% This MATLAB M-file is to compute the sample HJ-distance for
% a linear SDF model.
% R is the random payoff of N test assets, q is the current price, 
% f is the factor
%
% Input:
% R: Payoffs of base test assets
% f: Common factors
% q: Cost of base test assets (default is a vector of ones)
% lag: Number of lags of Newey-West adjustment
%
% Output:
% d: HJ-distance
% pval: p-value of testing d=0
% dse: Standard error of d
% c: Estimate of parameters in the linear stochastic factor
% tratc: t-ratio of gammac when the model is correctly specified
% trat: t-ratio of c when the model is potentially misspecified
% lam: Lagrange multiplier
%
function [d,pval,dse,c,tratc,trat,lam] = hj(R,F,q,lag)
index = any(isnan(F),2);
F(index,:) = [];
R(index,:) = [];
[T,K] = size(F);
[T,N] = size(R);
if nargin<3
   q = ones(N,1);
end
if nargin<4
   lag = 0;
end
G = inv((R'*R)./T);  
D = (R'*F)./T;
G1 = chol(G);
G1D = G1*D;
H = inv(G1D'*G1D);
c = H*D'*G*q;
ge = D*c-q;		      % Pricing Errors 
d = sqrt(ge'*G*ge); % HJ-distance
y = F*c;
E = R.*(y*ones(1,N))-ones(T,1)*q';
S = nw(E,lag);
GSG = G1*S*G1';
mu2 = mean(R);
%Rd = R-ones(T,1)*mu2;
%
% Correctly specified model
%
ht = (R.*(y*ones(1,N)))*G*D*H-ones(T,1)*c';  % h_t for correctly specified model
V = nw(ht,lag) ;
tratc = c./sqrt(diag(V/T));
%
% Potentially misspecified model
%
lam = G*ge;
u = R*lam;
ht = (R.*(y*ones(1,N)))*G*D*H-ones(T,1)*c'-((R*G*D-F)*H).*(u*ones(1,K));  % h_t for misspecified model
V = nw(ht,lag) ;
trat = c./sqrt(diag(V/T));
P = null(G1D');
e = eig(P'*GSG*P);
pval = 1-linchi2(T*d*d,e); 
%
% Standard error of delta
%
qt = 2*y.*u-u.^2+d^2;
vq = nw(qt,lag) ;
dse = sqrt(vq)/(2*d*sqrt(T)); 
