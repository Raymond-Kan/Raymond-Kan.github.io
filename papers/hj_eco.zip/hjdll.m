%
%   	HJDLL.M
% This MATLAB M-file is to compute the population HJ-distance of a 
% log-linear SDF model, assuming [f', r']' ~ N(mu,V).
% f is a K-vector of systematic factors, and r is an n-vector
% of continuously compounded returns of test assets.
% Input:
% mu1: mean of factors
% mu2: mean of continuously compounded returns
% V11: covariance matrix of factors
% V21: covariance matrix between contnuously compounded returns and
%      factors
% V22: covariance matrix of contnuously compounded returns
% Output:
% hjd: population HJ-distance 
% gam: pseudo SDF parameters
%
function [hjd,gam] = hjdll(mu1,mu2,V11,V21,V22)
K = size(V11,1);
n = size(V22,1);
q = ones(n,1);
%
%   Figure out the second moment of gross returns
%   It is based on the following result:
%   If x and y are bivariate normally distributed
%   E[exp(x+y)] = exp(mu_x+mu_y+sigma_x^2/2+sigma_y^2/2+sigma_{xy})
%               = E[exp(x)]E[exp(y)]exp(sigma_{xy})
%
vr = diag(V22);
c0 = mu2+0.5*vr;
muR = exp(c0);  % Expected gross returns
Ui = inv(muR*muR'.*exp(V22));  % inverse of second moment matrix of gross returns
qUq = q'*Ui*q;
if K==0
   b = muR'*Ui*q;
   c = muR'*Ui*muR;
   gam = log(b/c);
   hjd = sqrt(qUq-b^2/c);
   return
end
options = optimset('Display','off','GradObj','on','TolX',1e-10,'TolFun',1e-10);
[gam1,hjdsq] = fminunc(@gwg,zeros(K,1),options);
d = exp(c0+V21*gam1);
c = (d'*Ui*q)/(d'*Ui*d);
gam0 = log(c)-gam1'*mu1-0.5*gam1'*V11*gam1;
gam = [gam0; gam1];
hjd = sqrt(max(0,hjdsq));

function [y,dy] = gwg(g1)
   d = exp(c0+V21*g1);
   qUd = q'*Ui*d;
   dUd = d'*Ui*d;
   if qUd>0
      y = qUq-qUd^2/dUd;
      dl = (d*ones(1,K)).*V21;
      dy = 2*(qUd)/(dUd)^2*(qUd*(dl'*Ui*d)-dUd*(dl'*Ui*q));
   else
      y = qUq;
      dy = zeros(K,1);
   end
end

end
