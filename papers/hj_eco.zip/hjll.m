%
%   	HJLL.M
% This MATLAB M-file is to compute the sample HJ-distance of a 
% log-linear SDF model.
% x is the random payoff of N test assets, q is the current price, 
% f is systematic factors
%
% Input:
% x: Payoffs of test assets
% f: factors
% q: Cost of test assets 
% lag: Number of lags of Newey-West adjustment
%
% Output:
% hjd: HJ-distance (\hat\delta)
% pval1: p-value of testing \delta=0
% pval2: p-value of testing \lambda=0_n
% dse: Standard error of \hat\delta (assuming delta>0)
% gam: Estimate of parameters \gamma in the log-linear SDF
% tratc: t-ratio of \gamma when the model is correctly specified
% trat: t-ratio of \gamma when the model is potentially misspecified
% lam: Lagrange multiplier
% qt1
% phi
% Hm: C+D'*Ui*D
% Vm: variance matrix under misspecification
% Dy: first derivative of y
% y: SDF
% m: y-x*lam
% D: first derivative matrix of phi w.r.t. gamma
% C: second derivative matrix of phi w.r.t. gamma
% htm: for computing Sigma
%
function [hjd,pval1,pval2,dse,gam,tratc,trat,lam,qt1,phi,Hm,Vm,Dy,y,m,D,C,htm] = hjll(x,f,q,lag)
[T,n] = size(x);
K = size(f,2);
if nargin<3
   q = ones(n,1);
end
if nargin<4
   lag = 0;
end
Ui = inv((x'*x)/T);
U1 = chol(Ui);
%
%   Initial estimate of gamma_1
%
Y = [f x];
V = cov(Y,1);
D = [mean(x)' V(K+1:end,1:K)];
c0 = (U1*D)\(U1*q);
gam1 = c0(2:end)/c0(1);
muf = mean(f)';
f1 = f-ones(T,1)*muf';   % de-mean factors
d = (x'*exp(f1*gam1))/T;
if q'*Ui*d<0
   gam1 = -gam1;
end
%
%   Find optimal parameters
%
qUq = q'*Ui*q;
options = optimset('Display','off','GradObj','on','TolX',1e-8,'TolFun',1e-8);
% Use the following line to check derivatives
% options = optimset('Display','on','GradObj','on','TolX',1e-8,'TolFun',1e-8,'FinDiffType','central','DerivativeCheck','on');
[gam1,hjdsq] = fminunc(@gwg,gam1,options);
hjd = sqrt(hjdsq);
h = exp(f1*gam1);
d = (x'*h)/T;
c = (d'*Ui*q)/(d'*Ui*d);
gam0 = log(c)-gam1'*muf;
gam = [gam0; gam1];
y = c*h;  % SDF
E = x.*(y*ones(1,n))-ones(T,1)*q';
ge = mean(E)';    % Pricing errors
lam = Ui*ge;
%
%   Compute the p-values of two specification tests
%
S = (E'*E)/T;		% This can be cov(E,1)
for i=1:lag
    S1 = (E(i+1:end,:)'*E(1:end-i,:))/T;
    S = S+((lag+1-i)/(lag+1))*(S1+S1');
end
USU = U1*S*U1';
Dy = [y repmat(y,1,K).*f];  % First derivative
D = (x'*Dy)/T;
U1D = U1*D;
P = null(U1D');
W0 = P'*USU*P;
e = eig(W0);
pval1 = 1-linchi2(T*hjdsq,e); 
lam1 = P'*inv(U1)'*lam;
wald = T*lam1'*inv(W0)*lam1;
pval2 = 1-chi2cdf(wald,n-K-1);
%
%   Compute standard error of \hat\delta
%
u = x*lam;
lam1 = ((T-n-2)/T)*lam;
qt1 = y.*y-(y-x*lam1).*(y-x*lam1)-2*lam1'*q-hjdsq;
m = y-x*lam;
phi = y.*y-m.*m-2*lam'*q;
qt = phi-hjdsq;
vq = (qt'*qt)/T;
for i=1:lag
    vq = vq+(2/T)*(1-i/(lag+1))*qt(1:T-i)'*qt(i+1:T);
end
dse = sqrt(vq)/(2*hjd*sqrt(T)); 
%
%   Compute t-ratios of \hat\gamma, first for correctly
%   specified model, then for misspecified model.
%
H = D'*Ui*D;
E1 = E*Ui*D;
ht = E1*inv(H);   % h_t for correctly specified model
Vc = (ht'*ht)/T;
for i=1:lag
    Vc1 = (ht(i+1:end,:)'*ht(1:end-i,:))/T;
    Vc = Vc+((lag+1-i)/(lag+1))*(Vc1+Vc1');
end
tratc = gam./sqrt(diag(Vc)/T);
%
%  Note that the first row and column of C is zero because
%  of the FOC: \hat{D}'\hat{U}^{-1}\hat{e} = 0_{K+1}
%
C = zeros(K+1);
for i=1:K
    for j=1:i
        C(i+1,j+1) = (u'*(y.*f(:,i).*f(:,j)))/T;
        if i>j
           C(j+1,i+1) = C(i+1,j+1);
        end
    end
end
Hm = H+C;
E1 = E1+(Dy-x*Ui*D).*(u*ones(1,K+1));
htm = E1*inv(Hm);
Vm = (htm'*htm)/T;
for i=1:lag
    Vm1 = (htm(i+1:end,:)'*htm(1:end-i,:))/T;
    Vm = Vm+((lag+1-i)/(lag+1))*(Vm1+Vm1');
end
trat = gam./sqrt(diag(Vm)/T);

function [y,dy] = gwg(g1)
   h = exp(f1*g1);
   d = (x'*h)/T;
   qUd = q'*Ui*d;
   dUd = d'*Ui*d;
   if qUd>0
      y = qUq-qUd^2/dUd;
      dl = (x'*(repmat(h,1,K).*f1))/T;
      dy = 2*(qUd)/(dUd)^2*(qUd*(dl'*Ui*d)-dUd*(dl'*Ui*q));
   else
      y = qUq;
      dy = zeros(K,1);
   end
end

end
