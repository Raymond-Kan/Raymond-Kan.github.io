function gam = musetll(mu2r,V11,V21,V22)
%
%   This function picks parameters gam such
%   that the log-linear SDF is a correctly
%   specified model and minimizes the distance
%   between mu2 and mu2r.
%
options = optimset('Display','off','GradObj','on','TolX',1e-10,'TolFun',1e-10);
V22i = inv(V22);
mur = mu2r+0.5*diag(V22);
K = size(V11,1);
if K==0
   gam = -sum(V22i)*mur/sum(sum(V22i));
else
   n = size(V22,1);
   D = [ones(n,1) V21];
   gam = -inv(D'*V22i*D)*(D'*V22i*mur);
   g1 = gam(2:end);
   gam(1) = gam(1)-0.5*g1'*V11*g1;
end
