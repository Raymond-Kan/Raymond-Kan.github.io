function mu2 = musetllm(mu2h,pgam,V11,V21,V22)
%
%   This function picks parameters gam such
%   that the log-linear SDF is a misspecified model 
%   and minimizes the distance between mu2 and mu2r.
%
options = optimset('Display','off','Algorithm','active-set','TolX',1e-10,'TolFun',1e-10);
V22i = inv(V22);
vr = diag(V22);
mur = mu2h+0.5*vr;
[n,K] = size(V21);
q = ones(n,1);
g1 = pgam(2:end);
g0 = pgam(1)+0.5*g1'*V11*g1;
mut = -g0*q-V21*g1;
d0 = mut-mur;
%
%   Choose z such that the pseudo
%   SDF parameters are as close to mu2r as possible.
%
e = mur-mut;  % initial estimate
z = fmincon(@qdist,e,[],[],[],[],[],[],@zcon,options);
mu2 = mut+z-0.5*vr;

function [f,df] = qdist(z)
   d = d0+z;
   f = d'*V22i*d;
   if nargout>1
      df = 2*V22i*d;
   end
end

function [c,ceq] = zcon(z)
   z1 = exp(z);
   e = z1-q;
   Ui = inv((exp(mut)*exp(mut)').*exp(V22).*(z1*z1'));
   D = [z1 V21.*(z1*ones(1,K))];
   ceq = D'*Ui*e;
   c = [];
end

end
