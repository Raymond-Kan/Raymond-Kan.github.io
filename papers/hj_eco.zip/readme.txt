Table 1. t-tests under model misspecification
  
table1_a1b1:   t-ratio of H_0:\gamma_i=0 (for the first factor  of linear YOGO)     under misspecified models, size
table1_a2b2:   t-ratio of H_0:\gamma_i=0 (for the second factor of linear YOGO)     under misspecified models, size
table1_a3b3:   t-ratio of H_0:\gamma_i=0 (for the third factor  of linear YOGO)     under misspecified models, size
table1_c1d1:   t-ratio of H_0:\gamma_i=0 (for the first factor  of nonlinear YOGO)  under misspecified models, size
table1_c2d2:   t-ratio of H_0:\gamma_i=0 (for the second factor of nonlinear YOGO)  under misspecified models, size
table1_c3d3:   t-ratio of H_0:\gamma_i=0 (for the third factor  of nonlinear YOGO)  under misspecified models, size


Table 2. Specification tests

table2_a1a3: model specification tests, size,  linear YOGO
table2_a2a4: model specification tests, power, linear YOGO
table2_b1b3: model specification tests, size,  nonlinear YOGO
table2_b2b4: model specification tests, power, nonlinear YOGO


Table 3. Model selection tests for nested SDFs

table3_a1a3: nested model selection tests when models are misspecified, size  (YOGO vs CCAPM), pairwise
table3_a2a4: nested model selection tests when models are misspecified, power (YOGO vs CCAPM), pairwise
table3_b1:   nested model selection tests when models are misspecified, size  (YOGO and LL vs CCAPM), multiple
table3_b2:   nested model selection tests when models are misspecified, power (YOGO and LL vs CCAPM), multiple
table3_c1c3: nested model selection tests when models are misspecified, size  (nonlinear YOGO vs nonlinear CCAPM), pairwise
table3_c2c4: nested model selection tests when models are misspecified, power (nonlinear YOGO vs nonlinear CCAPM), pairwise
table3_d1:   nested model selection tests when models are misspecified, size  (nonlinear YOGO (benchmark), nonlinear external habit, nonlinear CCAPM), multiple
table3_d2:   nested model selection tests when models are misspecified, power (nonlinear YOGO, nonlinear external habit vs nonlinear CCAPM (benchmark)), multiple


Table 4. Model selection tests for non-nested SDFs

table4_a1a3: overlapping models, size,  (FF3 vs YOGO)
table4_a2a4: overlapping models, power, (FF3 vs YOGO)
table4_b1b3: pairwise and multiple model comparison tests when models are misspecified and 
       have different SDFs, size (mkt factor plus noise+constant+smb+hml)
table4_b2b4: pairwise and multiple model comparison tests when models are misspecified and 
       have different SDFs, power (FF3, YOGO, LL).  The benchmark is FF3
table4_c1c3: overlapping models, size,  (nonlinear external habit vs nonlinear YOGO)
table4_c2c4: overlapping models, power, (nonlinear external habit vs nonlinear YOGO)
table4_d1d3: pairwise and multiple model comparison tests when models are misspecified and 
       have different SDFs, size (mkt factor plus noise+constant)
table4_d2d4: pairwise and multiple model comparison tests when models are misspecified and 
       have different SDFs, power (nonlinear CCAPM, the linear FF3 model, and the nonlinear CAPM). The benchmark is nonlinear CCAPM


Table 5. Model selection tests for nested models (separate appendix)

Panel A: see table3_a1a3.m and see table3_a2a4.m
Panel B: see table3_c1c3.m and see table3_c2c4.m


Table 6. Model selection tests for non-nested models (separate appendix)

Panel A: see table4_a1a3.m and see table4_a2a4.m
Panel B: see table4_c1c3.m and see table4_c2c4.m


Table 7. Joint tests of correct specification (separate appendix)

table7_a1a3a5a7a9:  correctly specified models, size,  
                    (model 1: [constant plus mkt factor+noise_1]; model 2: [constant plus mkt factor+noise_2])
table7_a2a4a6a8a10: correctly specified models, power, (model 1 above vs model2 above)
table7_b1b3b5b7b9:  correctly specified models, size,  
                    (model 1: [constant plus mkt factor+noise_1]; model 2: [constant plus mkt factor+noise_2])
table7_b2b4b6b8b10: correctly specified models, power, (model 1 above vs model2 above) 


Table 8. t-tests under model misspecification and specification tests (separate appendix)

table8_a1b1: t-ratio of H_0:\gamma_i=0 (for the first factor of YOGO) under misspecified model, size
table8_a2b2: t-ratio of H_0:\gamma_i=0 (for the second factor of YOGO) under misspecified model, size
table8_a3b3: t-ratio of H_0:\gamma_i=0 (for the third factor of YOGO) under misspecified model, size
table8_c1c3: model specification tests, size, YOGO
table8_c2c4: model specification tests, power, YOGO
 

Table 9. Model selection tests for nested and non-nested SDFs (separate appendix)

table9_a1a3: nested model selection tests when models are misspecified, size  (YOGO vs CCAPM), pairwise
table9_a2a4: nested model selection tests when models are misspecified, power (YOGO vs CCAPM), pairwise
table9_b1:   nested model selection tests when models are misspecified, size  (YOGO and LL vs CCAPM), multiple
table9_b2:   nested model selection tests when models are misspecified, power (YOGO and LL vs CCAPM), multiple
table9_c1c3: overlapping models, size,  (FF3 vs YOGO)
table9_c2c4: overlapping models, power, (FF3 vs YOGO)
table9_d1d3: pairwise and multiple model comparison tests when models are misspecified and 
       have different SDFs, size (mkt factor plus noise+constant+smb+hml)
table9_d2d4: pairwise and multiple model comparison tests when models are misspecified and 
       have different SDFs, power (FF3, YOGO, LL). The benchmark is FF3









