%
%  table1_a1b1.m   Date: 1/14/2011
%  Unconstrained HJ-distance; test of H_0:\gamma_{1i}=0
%  The model is misspecified and it is based on 
%  the sample estimates from the linear YOGO model.
%  The first element of the population gamma_1 is set equal to
%  zero.
%
clear all
load quarterly
ii = 1;
R = R(1:195,:);
[T,N] = size(R);
F = [mkt(1:195) ndur(1:195) dur(1:195)];
[T,K] = size(F);
V = cov([F R],1);
V21 = V(K+1:end,1:K);
V22 = V(K+1:end,K+1:end);
V22i = inv(V22);
mu2h = mean(R)';
q = ones(N,1);
D = [mu2h V21];
e = D*inv(D'*V22i*D)*(D'*V22i*q)-q;
%
%   Set parameters 
%
Xc = [q V21];
Xc(:,ii+1) = [];
eta = inv(Xc'*V22i*Xc)*(Xc'*V22i*mu2h);   % This is equation (10)
mu2 = Xc*eta+e*eta(1);                    % This is equation (14) 
D = [mu2 V21];
e = D*inv(D'*V22i*D)*(D'*V22i*q)-q;
hjd = sqrt(e'*V22i*e);
ns = 100000;
TT = [120:120:600];
maxT = max(TT);
nT = length(TT);
mu = repmat([zeros(1,K) mu2'],maxT,1);
p = [0.1 0.05 0.01];
ncut = norminv(1-p/2);
gammas = zeros(ns,nT);
sec = zeros(ns,nT);
sem = zeros(ns,nT);
Vhalf = chol(V);
for i=1:ns
    Ys = mu+randn(maxT,N+K)*Vhalf;
    F = [ones(maxT,1) Ys(:,1:K)];
    R = Ys(:,K+1:end);
    for jj=1:nT
        T1 = TT(jj);
        Fs = F(1:T1,:);
        Rs = R(1:T1,:);
%
%   Unconstrained HJ-distance for the model under the null
%        
        W = inv(Rs'*Rs./T1);  
        D = (Rs'*Fs)./T1;
        H = inv(D'*W*D);
        c = H*D'*W*q;
        gammas(i,jj) = c(ii+1);
        ge = D*c-q;		       % Pricing Errors 
        y = Fs*c;
%
%   Correctly specified model
%
        ht = (Rs.*(y*ones(1,N)))*W*D*H-ones(T1,1)*c';  % h_t for correctly specified model
        V = (ht'*ht)/T1;
        sec(i,jj) = sqrt(V(ii+1,ii+1)/T1);
%
%   Potentially misspecified model
%
        lam = W*ge;
        u = Rs*lam;
        ht = (Rs.*(y*ones(1,N)))*W*D*H-ones(T1,1)*c'-((Rs*W*D-Fs)*H).*(u*ones(1,K+1));  % h_t for misspecified model
        V = (ht'*ht)/T1;
        sem(i,jj) = sqrt(V(ii+1,ii+1)/T1);
    end
end  
delete table1_a1b1.out
diary table1_a1b1.out
fprintf(' YOGO Model, SDF Parameter of Factor %1.0f is Equal to Zero\n',ii)
fprintf(' HJ-distance = %7.4f\n',hjd)
fprintf(' N = %2.0f, K = %2.0f\n',N,K)
fprintf(' Test of \\gamma=0\n')
fprintf(' Number of simulations = %7.0f\n',ns)
fprintf(' Standard error is based on correctly specified model\n')
fprintf('   T     10%%      5%%      1%%    \n')
for jj=1:nT
    tratioc = abs(gammas(:,jj))./sec(:,jj);
    fprintf(' %4.0f  %6.3f  %6.3f  %6.3f   \n',TT(jj), ...
            mean(tratioc>ncut(1)),mean(tratioc>ncut(2)),mean(tratioc>ncut(3)))
end
fprintf(' Standard error is based on potentially misspecified model\n')
fprintf('   T     10%%      5%%      1%%    \n')
for jj=1:nT
    tratiom = abs(gammas(:,jj))./sem(:,jj);
    fprintf(' %4.0f  %6.3f  %6.3f  %6.3f   \n',TT(jj), ...
            mean(tratiom>ncut(1)),mean(tratiom>ncut(2)),mean(tratiom>ncut(3)))
end
diary off
 