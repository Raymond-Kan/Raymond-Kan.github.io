%
%  table1_c1d1.m   Date: 1/14/2011
%  Unconstrained HJ-distance; test of H_0:\gamma_{1i}=0
%  The model is misspecified and it is based on 
%  the sample estimates from the nonlinear YOGO model.
%  The first element of the population gamma_1 is set equal to
%  zero.
%
clear all
load quarterly
warning off;
ii = 1;
R = R(1:195,:);
[T,N] = size(R);
F = [log(mkt(1:195)+R(1:195,1)) dur(1:195) ndur(1:195)];
K = size(F,2);
q = ones(N,1);
r = log(R);
mu2h = mean(r)';
V = cov([F r],1);
V11 = V(1:K,1:K);
V21 = V(K+1:end,1:K);
V22 = V(K+1:end,K+1:end);
V11a = V11;
V21a = V21;
V11a(ii,:) = [];
V11a(:,ii) = [];
V21a(:,ii) = [];
vr = diag(V22);
%
%  Choose parameters such that the asset pricing model 
%  is misspecified
%
gam = musetll(mu2h,V11a,V21a,V22);
pgam = [gam(1:ii); 0; gam(ii+1:end)];   % pseudo SDF parameters
mur = musetllm(mu2h,pgam,V11,V21,V22);
%
%   The following line is to check if the model has
%   the required pseudo SDF parameters
%
[hjd,g] = hjdll(zeros(K,1),mur,V11,V21,V22);
ns = 100000;
TT = [120:120:600];
maxT = max(TT);
nT = length(TT);
mu = repmat([zeros(1,K) mur'],maxT,1);
p = [0.1 0.05 0.01];
ncut = norminv(1-p/2);
tratioc = zeros(ns,nT);
tratiom = zeros(ns,nT);
Vhalf = chol(V);
for i=1:ns
    Ys = mu+randn(maxT,N+K)*Vhalf;
    F = Ys(:,1:K);
    R = exp(Ys(:,K+1:end));
    for jj=1:nT
        T1 = TT(jj);
        Fs = F(1:T1,:);
        Rs = R(1:T1,:);
        [~,~,~,~,~,tratc,tratm] = hjll(Rs,Fs,q);
        tratioc(i,jj) = tratc(ii+1);
        tratiom(i,jj) = tratm(ii+1);
    end
end  
delete table1_c1d1.out
diary table1_c1d1.out
tratioc = abs(tratioc);
tratiom = abs(tratiom);
fprintf(' Nonlinear YOGO Model, SDF Parameter of Factor %1.0f is Equal to Zero\n',ii)
fprintf(' HJ-distance = %7.4f\n',hjd)
fprintf(' N = %2.0f, K = %2.0f\n',N,K)
fprintf(' Test of \\gamma=0\n')
fprintf(' Number of simulations = %7.0f\n',ns)
fprintf(' Standard error is based on correctly specified model\n')
fprintf('   T     10%%      5%%      1%%    \n')
for jj=1:nT
    fprintf(' %4.0f  %6.3f  %6.3f  %6.3f   \n',TT(jj), ...
            mean(tratioc(:,jj)>ncut(1)),mean(tratioc(:,jj)>ncut(2)),mean(tratioc(:,jj)>ncut(3)))
end
fprintf(' Standard error is based on potentially misspecified model\n')
fprintf('   T     10%%      5%%      1%%    \n')
for jj=1:nT
    fprintf(' %4.0f  %6.3f  %6.3f  %6.3f   \n',TT(jj), ...
            mean(tratiom(:,jj)>ncut(1)),mean(tratiom(:,jj)>ncut(2)),mean(tratiom(:,jj)>ncut(3)))
end
diary off
 