%
%  table2_b2b4.m   Date: 1/14/2011
%  Power of the tests of H0: \delta^2=0 and H0: \lambda=0_n
%  Gross returns case. 
%  Parametes are set based on the nonlinear YOGO model.
%  
clear all
load quarterly
R = R(1:195,:);
[T,N] = size(R);
F = [log(mkt(1:195)+R(1:195,1)) dur(1:195) ndur(1:195)];
K = size(F,2);
q = ones(N,1);
r = log(R);
mu2h = mean(r)';
V = cov([F r],1);
V11 = V(1:K,1:K);
V21 = V(K+1:end,1:K);
V22 = V(K+1:end,K+1:end);
V22i = inv(V22);
ns = 100000;
TT = [120:120:600];
maxT = max(TT);
nT = length(TT);
mu = repmat([zeros(1,K) mu2h'],maxT,1);
Vhalf = chol(V);
pval0 = NaN(ns,nT);   % Test of delta=0, imposing the null
pval1 = NaN(ns,nT);   % Test of lambda=0_n
for i=1:ns
if rem(i,1000)==0
i
end
    Ys = mu+randn(maxT,N+K)*Vhalf;
    F = Ys(:,1:K);
    R = exp(Ys(:,K+1:end));
    for jj=1:nT
        T1 = TT(jj);
        Fs = F(1:T1,:);
        Rs = R(1:T1,:);
        [hjd,pval0(i,jj),pval1(i,jj)] = hjll(Rs,Fs,q);
    end
end  
delete table2_b2b4.out
diary table2_b2b4.out
hjd = hjdll(zeros(K,1),mu2h,V11,V21,V22);
fprintf(' Number of Simulations = %7.0f\n',ns)
fprintf(' HJ-Distance = %7.4f\n',hjd)
fprintf(' N = %3.0f,  K = %3.0f\n',N,K)
fprintf(' Power of the tests\n')
fprintf('          delta=0 (using S)          \n')
fprintf('  T      10%%      5%%      1%%      \n') 
for jj=1:nT
    fprintf(' %3.0f   %6.3f  %6.3f  %6.3f     \n',...
    TT(jj),mean(pval0(:,jj)<0.1),mean(pval0(:,jj)<0.05),mean(pval0(:,jj)<0.01))
end
fprintf('              lambda=0_n             \n')
fprintf('  T      10%%      5%%      1%%      \n') 
for jj=1:nT
    fprintf(' %3.0f   %6.3f  %6.3f  %6.3f     \n',...
    TT(jj),mean(pval1(:,jj)<0.1),mean(pval1(:,jj)<0.05),mean(pval1(:,jj)<0.01))
end
diary off
