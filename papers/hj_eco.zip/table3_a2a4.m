%
%  table3_a2a4.m   Date: 2/10/2012
%  Unconstrained HJ-distance; nested models
%  This program compares the probability of rejection under the null of
%  y_F=y_G of 5 tests:
%  (1) GKR test,
%  (2) LXZ test, 
%  (3) chi-squared test of GKR, 
%  (4) unrestricted Golden's test on \sigma^2_d, 
%  (5) restricted test based on \sigma^2_d as in the footnote of the paper.
%  We have y_F = \lambda_0
%  and y_G = \lambda_0+vwr*\lambda_1
%  We have y_F = \gamma_0+ndur*\gmama_1 (CCAPM)
%  and y_G = \gamma_0+ndur*\gamma_1+vwr*\gamma_2+dur*\gamma_3 (YOGO)
%  The mean returns are generated based on historical average return, 
%  such that y_F is not equal to y_G and both models are
%  misspecified. 
%
clear all
load quarterly
R = R(1:195,:);
[T,N] = size(R);
F = [ndur(1:195) mkt(1:195) dur(1:195)];
[T,K] = size(F);
Y = [F R];
mu2 = mean(R);
V = cov(Y,1);
Vhalf = chol(V);
V11 = V(1:K,1:K);
V12 = V(1:K,K+1:end);
V21 = V12';
V22 = V(K+1:end,K+1:end);
V22i = inv(V22);
q = ones(N,1);
TT = [120:120:600];
maxT = max(TT);
mu = [zeros(K,1); mu2'];    
mu = repmat(mu',maxT,1);
nT = length(TT);
nobs = 100000;
p = [0.1 0.05 0.01];
pval1 = zeros(nobs,nT,3);  % GKR test
pval2 = zeros(nobs,nT,3);  % LXZ test
pval3 = zeros(nobs,nT,3);  % chi-squared test of GKR
pval4 = zeros(nobs,nT,3);  % unrestricted sigma^2_d test
pval5 = zeros(nobs,nT,3);  % restricted sigma^2_d test
K1 = 2;
K2 = 4;
Psi = [zeros(K2-K1,K1) eye(K2-K1)];
for i=1:nobs
    if rem(i,1000)==0
    i
    end
    Ys = mu+randn(maxT,N+3)*Vhalf;
    for j=1:nT
        T = TT(j);
        R = Ys(1:T,4:end);
        F1 = [ones(T,1) Ys(1:T,1)];
        F2 = [ones(T,1) Ys(1:T,1:3)];
%
%   Construct unconstrained HJ-distances for both models
%
        U = (R'*R)/T;
        Ui = inv(U);
        sUi = Ui*q;
        U1 = sqrtm(Ui);
        D1 = (R'*F1)/T;
        U1D1 = U1*D1;
        H1 = inv(U1D1'*U1D1);
        gam1 = H1*D1'*sUi;
        lam1 = Ui*(D1*gam1-q);
        y1 = F1*gam1;
        m1 = y1-R*lam1;
        D2 = (R'*F2)/T;
        U1D2 = U1*D2;
        H2 = inv(U1D2'*U1D2);
        gam2 = H2*D2'*sUi;
        lam2 = Ui*(D2*gam2-q);
        y2 = F2*gam2;
        m2 = y2-R*lam2;
        phi1 = y1.*y1-m1.*m1-2*ones(1,N)*lam1;
        phi2 = y2.*y2-m2.*m2-2*ones(1,N)*lam2;
        phid = phi1-phi2; % note that we are using the current definition of d_t in the paper 
        d2d = sum(phid); 
        sigma2d = mean(phid.^2);
%        
%       GKR test
%        
        mat = inv(Psi*H2*Psi');
        ha = (F2.*((y2-m2)*ones(1,K2))+(R.*(m2*ones(1,N))-ones(T,1)*q')*Ui*D2)*H2; 
        Lambda = (ha'*ha)/T;
        A = mat*(Psi*Lambda*Psi');
        e = eig(A);
        pvalue = 1-linchi2(d2d,e);
        ind = pvalue<p;
        pval1(i,j,ind) = pval1(i,j,ind)+1;
%
%       Restricted \sigma^2d test 
%
        pvalue = 1-linchi2(T*sigma2d,4*e.^2);
        ind = pvalue<p;
        pval5(i,j,ind) = pval5(i,j,ind)+1;    
%
%       chi-squared test of GKR
%       
        psi = gam2(K1+1:end);
        wald = T*(psi'*inv(Psi*Lambda*Psi')*psi);
        pvalue = 1-chi2cdf(wald,K2-K1);
        ind = pvalue<p;
        pval3(i,j,ind) = pval3(i,j,ind)+1;        
%
%       LXZ test 
%
        h = [F1.*((y1-m1)*ones(1,K1)) R.*(m1*ones(1,N))-ones(T,1)*q' ....
             F2.*((y2-m2)*ones(1,K2)) R.*(m2*ones(1,N))-ones(T,1)*q'];
        Lambda = (h'*h)/T;
        Gamma1 = [zeros(K1) D1'; D1 -U];
        Gamma2 = [zeros(K2) D2'; D2 -U];
%        Lambdah = sqrtm(Lambda);
%        A = Lambdah*[-inv(Gamma1) zeros(N+K1,N+K2); zeros(N+K2,N+K1) inv(Gamma2)]*Lambdah;
%        e = eig(0.5*(A+A'));
        e = real(eig(Lambda,[-Gamma1 zeros(N+K1,N+K2); zeros(N+K2,N+K1) Gamma2]));
        pvalue = 1-linchi2(d2d,e);
        ind = pvalue<p;
        pval2(i,j,ind) = pval2(i,j,ind)+1;
%
%       Unrestricted \sigma_d^2 test 
%
        pvalue = 1-linchi2(T*sigma2d,4*e.^2);
        ind = pvalue<p;
        pval4(i,j,ind) = pval4(i,j,ind)+1;                    
    end
end
pval1 = squeeze(mean(pval1,1));
pval2 = squeeze(mean(pval2,1));
pval3 = squeeze(mean(pval3,1));
pval4 = squeeze(mean(pval4,1));
pval5 = squeeze(mean(pval5,1));
delete table3_a2a4.out
diary table3_a2a4.out
fprintf(' Number of Simulations = %6.0f\n',nobs)
fprintf(' GKR Test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval1(i,:))
end    
fprintf(' LXZ Test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval2(i,:))
end    
fprintf(' chi-squared GKR Test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval3(i,:))
end
fprintf(' unrestricted sigma^2_d test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval4(i,:))
end
fprintf(' restricted sigma^2_d test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval5(i,:))
end
diary off