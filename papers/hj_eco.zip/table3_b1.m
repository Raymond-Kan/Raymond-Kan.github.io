%
%  table3_b1.m   Date: 2/10/2012
%  This program computes the probability of rejection of a multiple
%  model comparison test of nested models.  The benchmark model
%  (model 1) is nested by the alternative models (models 2 and 3),
%  where the models are give by
%  model 1: [const ndur]
%  model 2: [const ndur cay cay.*ndur]
%  model 3: [const ndur market dur]
%  The expected returns are chosen such that the benchmark model
%  has the same HJ-distance as the alternative models.
%
clear all
load quarterly
R = R(1:195,:);
[T,N] = size(R);
F = [ndur(1:195) cay(1:195) cay(1:195).*ndur(1:195) mkt(1:195) dur(1:195)];
model1 = 1;
model2 = [1 2 3];
model3 = [1 4 5];
K1 = length(model1);
K2 = length(model2);
K3 = length(model3);
[T,K] = size(F);
Y = [F R];
V = cov(Y,1);
Vhalf = chol(V);
V21 = V(K+1:end,1:K);
V22 = V(K+1:end,K+1:end);
V22i = inv(V22);
mu2h = mean(R)';
q = ones(N,1);
D = [mu2h V21];
e = D*inv(D'*V22i*D)*(D'*V22i*q)-q;
%
%   Set parameters 
%
Xc = [q V21];
Xc(:,3:end) = [];
eta = inv(Xc'*V22i*Xc)*(Xc'*V22i*mu2h);   % This is equation (10)
mu2 = Xc*eta+e*eta(1);                    % This is equation (14) 
D = [mu2 V21];
e = D*inv(D'*V22i*D)*(D'*V22i*q)-q;
hjd = sqrt(e'*V22i*e);
TT = [120:120:600];
maxT = max(TT);
nT = length(TT);
mu = repmat([zeros(1,K) mu2'],maxT,1);
nobs = 100000;
p = [0.1 0.05 0.01];
pval = zeros(nobs,nT,3);  % chi-squared mutiple model comparison test 
for i=1:nobs
    if rem(i,1000)==0
    i
    end
    Ys = mu+randn(maxT,N+K)*Vhalf;
    for j=1:nT
        T = TT(j);
        R = Ys(1:T,K+1:end);
        F1 = [ones(T,1) Ys(1:T,model1)];
        F2 = [ones(T,1) Ys(1:T,model2)];   
        F3 = [ones(T,1) Ys(1:T,model3)];   
        U = (R'*R)/T;
        Ui = inv(U);
        Uiq = Ui*q;
        U1 = sqrtm(Ui);
        D1 = (R'*F1)./T;
        U1D1 = U1*D1;
        H1 = inv(U1D1'*U1D1);
        gam1 = H1*D1'*Uiq;
        lam1 = Ui*(D1*gam1-q);
        y1 = F1*gam1;
        m1 = y1-R*lam1;
        D2 = (R'*F2)/T;
        U1D2 = U1*D2;
        H2 = inv(U1D2'*U1D2);
        gam2 = H2*D2'*Uiq;
        lam2 = Ui*(D2*gam2-q);
        y2 = F2*gam2;
        m2 = y2-R*lam2;
        D3 = (R'*F3)/T;
        U1D3 = U1*D3; 
        H3 = inv(U1D3'*U1D3);
        gam3 = H3*D3'*Uiq;
        lam3 = Ui*(D3*gam3-q);
        y3 = F3*gam3;
        m3 = y3-R*lam3;
        ha2 = (F2.*((y2-m2)*ones(1,K2+1))+(R.*(m2*ones(1,N))-ones(T,1)*q')*Ui*D2)*H2;
        ha3 = (F3.*((y3-m3)*ones(1,K3+1))+(R.*(m3*ones(1,N))-ones(T,1)*q')*Ui*D3)*H3;
        ha = [ha2(:,K1+2:end) ha3(:,K1+2:end)];
        Lambda = (ha'*ha)/T;
        psi = [gam2(K1+2:end); gam3(K1+2:end)];
        wald = T*(psi'*inv(Lambda)*psi);
        pvalue = 1-chi2cdf(wald,K2+K3-2*K1);
        ind = pvalue<p;
        pval(i,j,ind) = pval(i,j,ind)+1;        
    end
end
pval = squeeze(mean(pval,1));
delete table3_b1.out
diary table3_b1.out
fprintf(' HJ-distance = %7.4f\n',hjd)
fprintf(' N = %2.0f, K1 = %2.0f, K2 = %2.0f, K3 = %2.0f\n',N,K1,K2,K3)
fprintf(' Number of Simulations = %6.0f\n',nobs)
fprintf(' Size of Multiple Nested Model Comparison Test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval(i,:))
end    
diary off
