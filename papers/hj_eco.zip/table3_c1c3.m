%
%  table3_c1c3.m   Date: 2/16/2012
%  Unconstrained HJ-distance; nonlinear nested models
%  This program compares the probability of rejection under the null of
%  y_F=y_G of 5 tests:
%  (1) GKR test,
%  (2) LXZ test, 
%  (3) chi-squared test of GKR, 
%  (4) unrestricted Golden's test on \sigma^2_d, 
%  (5) restricted test based on \sigma^2_d as in the footnote of the paper.
%  We have y_F = exp(\gamma_0+ndur*\gmama_1) (CCAPM)
%  and y_G = exp(\gamma_0+ndur*\gamma_1+vw*\gamma_2+dur*\gamma_3) (YOGO)
%  The mean returns are generated such that y_F=y_G but both models are
%  misspecified 
%
clear all
warning off
load quarterly
R = R(1:195,:);
[T,N] = size(R);
mkt = mkt(1:195);         % market excess return
dur = dur(1:195);         % growth rate of durable consumption
ndur = ndur(1:195);       % growth rate of non-durable consumption
vw = log(mkt+R(1:195,1)); % continuously compounded gross market return
f = [ndur dur vw];
[T,K] = size(f);
r = log(R);
Y = [f r];
V = cov(Y,1);
Vhalf = chol(V);
V11 = V(1:K,1:K);
V21 = V(K+1:end,1:K);
V22 = V(K+1:end,K+1:end);
V22i = inv(V22);
mu2h = mean(r)';
q = ones(N,1);
V21a = V21(:,1:1);
V11a = V11(1:1,1:1);
K1 = 2;
K2 = 4;
Psi = [zeros(K2-K1,K1) eye(K2-K1)];
TT = [120:120:600];
maxT = max(TT);
nT = length(TT);
nobs = 100000;
p = [0.1 0.05 0.01];
%
%  Choose parameters such that the asset pricing model 
%  is misspecified
%
gam = musetll(mu2h,V11a,V21a,V22);
pgam = [gam; zeros(K2-K1,1)];   % pseudo SDF parameters
mur = musetllm(mu2h,pgam,V11,V21,V22);
%
%   The following line is to check if the model has
%   the required pseudo SDF parameters
%
[hjd,g] = hjdll(zeros(K,1),mur,V11,V21,V22);
mu = repmat([zeros(1,K) mur'],maxT,1);
pval1 = zeros(nobs,nT,3);  % GKR test
pval2 = zeros(nobs,nT,3);  % LXZ test
pval3 = zeros(nobs,nT,3);  % chi-squared test of GKR
pval4 = zeros(nobs,nT,3);  % unrestricted sigma^2_d test
pval5 = zeros(nobs,nT,3);  % restricted sigma^2_d test
for i=1:nobs
    if rem(i,1000)==0
    i
    end
    Ys = mu+randn(maxT,N+K)*Vhalf;
    for j=1:nT
        T = TT(j);
        R = exp(Ys(1:T,K+1:end));
        F1 = Ys(1:T,1);
        F2 = Ys(1:T,1:3);
%
%   Construct unconstrained HJ-distances for both models
%
        [~,~,~,~,gam1,~,~,~,~,phi1,H1,Lambda1,Dy1,y1,m1,D1,C1] = hjll(R,F1,q);
        [~,~,~,~,gam2,~,~,~,~,phi2,H2,Lambda2,Dy2,y2,m2,D2,C2] = hjll(R,F2,q);
        phid = phi1-phi2; % note that we are using the current definition of d_t in the paper 
        d2d = sum(phid); 
        sigma2d = mean(phid.^2);
%        
%       GKR test
%        
        mat = inv(Psi*inv(H2)*Psi');
        A = mat*(Psi*Lambda2*Psi');
        e = eig(A);
        pvalue = 1-linchi2(d2d,e);
        ind = pvalue<p;
        pval1(i,j,ind) = pval1(i,j,ind)+1;
%
%       Restricted sigma^2d test 
%
        pvalue = 1-linchi2(T*sigma2d,4*e.^2);
        ind = pvalue<p;
        pval5(i,j,ind) = pval5(i,j,ind)+1;    
%
%       chi-squared test of GKR
%       
        psi = gam2(K1+1:end);
        wald = T*(psi'*inv(Psi*Lambda2*Psi')*psi);
        pvalue = 1-chi2cdf(wald,K2-K1);
        ind = pvalue<p;
        pval3(i,j,ind) = pval3(i,j,ind)+1;        
%
%       LXZ test 
%
        h = [Dy1.*((y1-m1)*ones(1,K1)) R.*(m1*ones(1,N))-ones(T,1)*q' ....
             Dy2.*((y2-m2)*ones(1,K2)) R.*(m2*ones(1,N))-ones(T,1)*q'];
        Lambda = (h'*h)/T;
        U = (R'*R)/T;
        Gamma1 = [C1 D1'; D1 -U];
        Gamma2 = [C2 D2'; D2 -U];
        e = real(eig(Lambda,[-Gamma1 zeros(N+K1,N+K2); zeros(N+K2,N+K1) Gamma2]));
        pvalue = 1-linchi2(d2d,e);
        ind = pvalue<p;
        pval2(i,j,ind) = pval2(i,j,ind)+1;
%
%       Unrestricted sigma_d^2 test 
%
        pvalue = 1-linchi2(T*sigma2d,4*e.^2);
        ind = pvalue<p;
        pval4(i,j,ind) = pval4(i,j,ind)+1;                 
    end
end
pval1 = squeeze(mean(pval1,1));
pval2 = squeeze(mean(pval2,1));
pval3 = squeeze(mean(pval3,1));
pval4 = squeeze(mean(pval4,1));
pval5 = squeeze(mean(pval5,1));
delete table3_c1c3.out
diary table3_c1c3.out
fprintf(' Number of Simulations = %6.0f\n',nobs)
fprintf(' GKR Test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval1(i,:))
end    
fprintf(' LXZ Test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval2(i,:))
end    
fprintf(' chi-squared GKR Test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval3(i,:))
end
fprintf(' unrestricted sigma^2_d test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval4(i,:))
end
fprintf(' restricted sigma^2_d test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval5(i,:))
end
diary off