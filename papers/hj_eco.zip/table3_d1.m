%
%  table3_d1.m   Date: 2/10/2012
%  This program computes the probability of rejection of a multiple
%  model comparison test of nested models.  The benchmark model
%  (model 1) is nested by the alternative models (models 2 and 3),
%  where the models are give by
%  model 1: [const ndur] nonlinear CCAPM
%  model 2: [const ndur ndur_t1] nonlinear external habit model
%  model 3: [const ndur vw dur] nonlinear YOGO
%  The expected returns are chosen such that the benchmark model
%  has the same HJ-distance as the alternative models.
%
clear all
load quarterly
R = R(1:195,:);
[T,N] = size(R);
mkt = mkt(1:195);                 % market excess return
dur = dur(1:195);                 % growth rate of durable consumption
ndur = ndur(1:195);               % growth rate of non-durable consumption
ndur_t1 = [0.0173; ndur(1:194)];  % lagged growth rate of non-durable consumption
vw = log(mkt+R(1:195,1));         % continuously compounded gross market return
f = [ndur vw dur ndur_t1];
model1 = 1;
model2 = [1 4];
model3 = [1 2 3];
K1 = length(model1);
K2 = length(model2);
K3 = length(model3);
[T,K] = size(f);
r = log(R);
Y = [f r];
V = cov(Y,1);
Vhalf = chol(V);
V11 = V(1:K,1:K);
V21 = V(K+1:end,1:K);
V22 = V(K+1:end,K+1:end);
V22i = inv(V22);
mu2h = mean(r)';
V21a = V21(:,1:1);
V11a = V11(1:1,1:1);
q = ones(N,1);
%
%  Choose parameters such that the asset pricing model 
%  is misspecified
%
gam = musetll(mu2h,V11a,V21a,V22);
pgam = [gam; zeros(K2+K3-2*K1,1)];   % pseudo SDF parameters
mur = musetllm(mu2h,pgam,V11,V21,V22);
%
%   The following line is to check if the model has
%   the required pseudo SDF parameters
%
[hjd,g] = hjdll(zeros(K,1),mur,V11,V21,V22);
TT = [120:120:600];
maxT = max(TT);
nT = length(TT);
mu = repmat([zeros(1,K) mur'],maxT,1);
nobs = 100000;
p = [0.1 0.05 0.01];
pval = zeros(nobs,nT,3);  % chi-squared mutiple model comparison test 
for i=1:nobs
    if rem(i,1000)==0
    i
    end
    Ys = mu+randn(maxT,N+K)*Vhalf;
    for j=1:nT
        T = TT(j);
        R = exp(Ys(1:T,K+1:end));
        F2 = Ys(1:T,model2);   
        F3 = Ys(1:T,model3);   
        [~,~,~,~,gam2,~,~,~,~,phi2,H2,Lambda2,Dy2,y2,m2,D2,C2,ht2] = hjll(R,F2,q);
        [~,~,~,~,gam3,~,~,~,~,phi3,H3,Lambda3,Dy3,y3,m3,D3,C3,ht3] = hjll(R,F3,q);
        ha = [ht2(:,K1+2:end) ht3(:,K1+2:end)];
        Lambda = (ha'*ha)/T;
        psi = [gam2(K1+2:end); gam3(K1+2:end)];
        wald = T*(psi'*inv(Lambda)*psi);
        pvalue = 1-chi2cdf(wald,K2+K3-2*K1);
        ind = pvalue<p;
        pval(i,j,ind) = pval(i,j,ind)+1;        
    end
end
pval = squeeze(mean(pval,1));
delete table3_d1.out
diary table3_d1.out
fprintf(' HJ-distance = %7.4f\n',hjd)
fprintf(' N = %2.0f, K1 = %2.0f, K2 = %2.0f, K3 = %2.0f\n',N,K1,K2,K3)
fprintf(' Number of Simulations = %6.0f\n',nobs)
fprintf(' Size of Multiple Nested Model Comparison Test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval(i,:))
end    
diary off
