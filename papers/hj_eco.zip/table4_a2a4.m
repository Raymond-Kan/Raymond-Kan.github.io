%
%  table4_a2a4.m   Date: 2/10/2012
%  Unconstrained HJ-distance; overlapping models
%  This program evaluates the probability of rejection under the alternative of
%  y_F \neq y_G of 5 tests (1) GKR test, (2) chi-squared test of GKR, 
%  (3) LXZ test, (4) unrestricted Golden's test on \sigma^2_d, 
%  (5) restricted test based on on \sigma^2_d as in the footnote of the
%  paper.
%  We have y_F = \lambda_0F+\lambda_1F f_1 + \lambda_2F f_2
%  and     y_G = \lambda_0G+\lambda_1G f_1 + \lambda_2G f_3
%  The mean returns are generated based on historical average return, 
%  such that y_F is not equal to y_G and both models are
%  misspecified. 
%
clear all
load quarterly
R = R(1:195,:);
[T,N] = size(R);
F1 = mkt(1:195);
[T,K1] = size(F1);
F2 = [smb(1:195) hml(1:195)];
[T,K2] = size(F2);
F3 = [ndur(1:195) dur(1:195)];
[T,K3] = size(F3);
F = [F1 F2 F3];
[T,K] = size(F);
Y = [F R];
V = cov(Y,1);
Vhalf = chol(V);
V11 = V(1:K,1:K);
V12 = V(1:K,K+1:end);
V21 = V12';
V22 = V(K+1:end,K+1:end);
V22i = inv(V22);
q = ones(N,1);
mu = mean(Y)';
TT = [120:120:600];
maxT = max(TT);
nT = length(TT);
nobs = 100000;
p = [0.1 0.05 0.01];
pval1 = zeros(nobs,nT,3);  % GKR test
pval2 = zeros(nobs,nT,3);  % chi-squared test of GKR
pval3 = zeros(nobs,nT,3);  % LXZ test
pval4 = zeros(nobs,nT,3);  % unrestricted sigma^2_d test
pval5 = zeros(nobs,nT,3);  % unrestricted sigma^2_d test
Psi0f = [zeros(K2,K1+1) eye(K2)];
Psi0g = [zeros(K3,K1+1) eye(K3)];
Psi0fg = [Psi0f zeros(K2,K1+K3+1); zeros(K3,K1+K2+1) Psi0g];
for i=1:nobs
    if rem(i,1000)==0
    i
    end
    Ys = ones(maxT,1)*mu'+randn(maxT,N+K)*Vhalf;
    for j=1:nT
        T = TT(j);
        R = Ys(1:T,K+1:end);
        F1 = [ones(T,1) Ys(1:T,1:K1+K2)];
        F2 = [ones(T,1) Ys(1:T,1:K1) Ys(1:T,K1+K2+1:K)];   
        X1 = F1;
        X2 = F2;
%
%   Construct the unconstrained HJ-distances for both models
%
        U = (R'*R)/T;
        Ui = inv(U);
        sUi = Ui*q;
        U1 = sqrtm(Ui);
        D1 = (R'*F1)/T;
        U1D1 = U1*D1;
        H1 = inv(U1D1'*U1D1);
        gam1 = H1*D1'*sUi;
        lam1 = Ui*(D1*gam1-q);
        y1 = F1*gam1;
        m1 = y1-R*lam1;
        D2 = (R'*F2)/T;
        U1D2 = U1*D2;
        H2 = inv(U1D2'*U1D2);
        gam2 = H2*D2'*sUi;
        lam2 = Ui*(D2*gam2-q);
        y2 = F2*gam2;
        m2 = y2-R*lam2;
        phi1 = y1.*y1-m1.*m1-2*ones(1,N)*lam1;
        phi2 = y2.*y2-m2.*m2-2*ones(1,N)*lam2;
        phid = phi1-phi2; % note that we are using the current definition of d_t in the paper 
        d2d = sum(phid); 
        sigma2d = mean(phid.^2);
%        
%       GKR test
%        
        Hftilde = inv(D1'*inv(U)*D1);
        Hgtilde = inv(D2'*inv(U)*D2);
        mat = [-inv(Psi0f*Hftilde*Psi0f') zeros(K2,K3); zeros(K3,K2) inv(Psi0g*Hgtilde*Psi0g')];
        h = [(X1.*((y1-m1)*ones(1,K1+K2+1))+(R.*(m1*ones(1,N))-ones(T,1)*q')*inv(U)*D1)*Hftilde ...
        (X2.*((y2-m2)*ones(1,K1+K3+1))+(R.*(m2*ones(1,N))-ones(T,1)*q')*inv(U)*D2)*Hgtilde]; 
        Lambda = (h'*h)/T;
        A = mat*Psi0fg*Lambda*Psi0fg';
        e = eig(A);
        pp = linchi2(d2d,e);
        pvalue = 2*min(pp,1-pp);
        ind = pvalue<p;
        pval1(i,j,ind) = pval1(i,j,ind)+1;
%        
%       Restricted sigma^2_d test
%        
        pvalue = 1-linchi2(T*sigma2d,4*e.^2);
        ind = pvalue<p;
        pval5(i,j,ind) = pval5(i,j,ind)+1;
%
%       chi-squared test of GKR
%       
        psi = [gam1(K1+2:end); gam2(K1+2:end)];
        wald = T*(psi'*inv(Psi0fg*Lambda*Psi0fg')*psi);
        pvalue = 1-chi2cdf(wald,K2+K3);
        ind = pvalue<p;
        pval2(i,j,ind) = pval2(i,j,ind)+1;        
%
%       LXZ test
%
        h = [F1.*((y1-m1)*ones(1,K1+K2+1)) R.*(m1*ones(1,N))-ones(T,1)*q' ....
        F2.*((y2-m2)*ones(1,K1+K3+1)) R.*(m2*ones(1,N))-ones(T,1)*q'];
        Lambda = (h'*h)/T;
        Gamma1 = [zeros(K1+K2+1) D1'; D1 -U];
        Gamma2 = [zeros(K1+K3+1) D2'; D2 -U];
        Lambdah = sqrtm(Lambda);
        A = Lambdah*[-inv(Gamma1) zeros(N+K1+K2+1,N+K1+K3+1); zeros(N+K1+K3+1,N+K1+K2+1) inv(Gamma2)]*Lambdah;
        e = eig(0.5*(A+A'));
        pp = linchi2(d2d,e);
        pvalue= 2*min(pp,1-pp);
        ind = pvalue<p;
        pval3(i,j,ind) = pval3(i,j,ind)+1;
%        
%       Unrestricted sigma^2_d test
%        
        pvalue = 1-linchi2(T*sigma2d,4*e.^2);
        ind = pvalue<p;
        pval4(i,j,ind) = pval4(i,j,ind)+1;                
        
    end
end
pval1 = squeeze(mean(pval1,1));
pval2 = squeeze(mean(pval2,1));
pval3 = squeeze(mean(pval3,1));
pval4 = squeeze(mean(pval4,1));
pval5 = squeeze(mean(pval5,1));
delete table4_a2a4.out
diary table4_a2a4.out
fprintf(' Number of Simulations = %6.0f\n',nobs)
fprintf(' GKR Test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval1(i,:))
end    
fprintf(' chi-squared GKR Test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval2(i,:))
end
fprintf(' LXZ Test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval3(i,:))
end    
fprintf(' unrestricted sigma^2_d test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval4(i,:))
end
fprintf(' restricted sigma^2_d test \n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),pval5(i,:))
end
diary off
