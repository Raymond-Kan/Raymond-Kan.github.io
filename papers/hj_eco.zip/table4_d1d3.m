%
%   table4_d1d3.m
%   This Matlab program evaluates the Wolak's test by comparing 3 nonlinear 
%   misspecified 1-factor models with the same HJ-distance but different 
%   SDFs.  The three 1-factor models are based on the nonlinear CAPM
%   of Braun and Gibbons (1985) with the market factor being contaminated with noise.
%   The program reports the size of Wolak's test for different sample
%   sizes.
%
clear all
warning off
load quarterly
R = R(1:195,:);
F = log(mkt(1:195)+R(1:195,1)); % continuously compounded gross market return
c = 0.2;
stdn = sqrt(c)*std(F(:,1));
maxr = 2;
nmodel = maxr+1;
ns = 100000;
TT = [120:120:600];
maxT = max(TT);
nT = length(TT);
N = size(R,2);
q = ones(N,1);
[T,N] = size(R);
K = size(F,2);
Y = [F log(R)];
V = cov(Y,1);
mu = mean(Y)';
mu = repmat(mu',maxT,1);
Vhalf = chol(V);
p = [0.10 0.05 0.01];
count1 = zeros(maxr,nT,3);
d2 = zeros(nmodel,1);
for i=1:ns
if rem(i,1000)==0
i
end
    Ys = mu+randn(maxT,N+K)*Vhalf;
    et = randn(maxT,nmodel)*stdn;   % measurement errors   
    for jj=1:nT
        T1 = TT(jj);
        Rs = exp(Ys(1:T1,K+1:end));
        nt1 = zeros(T1,nmodel);
        for j=1:nmodel
            Fs = Ys(1:T1,1:K);
            Fs(:,1:K) = [Fs(:,1)+et(1:T1,j)];  % Add different noises for different models
            [hjd,~,~,dse,gam,~,~,~,qt] = hjll(Rs,Fs,q);
            d2(j) = hjd^2;
            nt1(:,j) = qt;   % n_t for model i
        end
%
%   Model comparison using Wolak's test
%
        d = d2(1)-d2(2:end);
        dt = nt1(:,1)*ones(1,maxr)-nt1(:,2:end);
        Sd = (dt'*dt)/T1;
        for j=1:maxr
            d1 = d(1:j);
            w = waldweight(Sd(1:j,1:j));                        
            if all(d1<=0)
               pval = 1-w(end);
            else
               [lam,obj] = quadprog(Sd(1:j,1:j),-sqrt(T1)*d1,-eye(j),zeros(j,1),[],[],[],[],[], ...
                           optimset('Display','off','Diagnostics','off','Algorithm','interior-point-convex'));
               pval = gammainc(-obj,[1:j]./2,'upper')*w(j:-1:1);
            end
            ind = pval<p;
            count1(j,jj,ind) = count1(j,jj,ind)+1;
        end
    end  
end
count1 = count1/ns;
delete table4_d1d3.out
diary table4_d1d3.out
fprintf(' Number of simulations = %7.0f\n',ns)
fprintf(' Size of Multiple Model Comparison Using Wolak Test\n')
fprintf(' r      %7.0f %7.0f  \n',1:maxr)
for i=1:nT
    fprintf(' T = %4.0f\n',TT(i))
    fprintf(' 10%%     %7.3f %7.3f  \n',count1(:,i,1))
    fprintf(' 5%%      %7.3f %7.3f  \n',count1(:,i,2))
    fprintf(' 1%%      %7.3f %7.3f  \n',count1(:,i,3))
end
diary off



