%
%   table4_d2d4.m
%   This Matlab program evaluates the Wolak's test by comparing three 
%   misspecified models with different HJ-distances.  The three 
%   model are based, in the order, on the nonlinear CCAPM (the benchmark), the FF3 model, and the nonlinear CAPM. 
%   The program reports the power of Wolak's test for different sample
%   sizes.
%
clear all
load quarterly
R = R(1:195,:);
F = [ndur(1:195) log(mkt(1:195)+R(1:195,1)) log(mkt(1:195)+1) log(smb(1:195)+1) log(hml(1:195)+1)];
maxr = 2;
nmodel = maxr+1;
ns = 100000;
TT = [120:120:600];
maxT = max(TT);
nT = length(TT);
N = size(R,2);
q = ones(N,1);
[T,N] = size(R);
K = size(F,2);
Y = [F log(R)];
hjdist1 = hjll(R,F(:,1),q);                        % nonlinear CCAPM (benchmark,model~1)
hjdist2 = hj(R,[ones(T,1) exp(F(:,3:5))-1],q);     % linear FF3 (alternative model, model~2)
hjdist3 = hjll(R,F(:,2),q);                        % nonlinear CAPM (alternative model, model~3)
hjdist = [hjdist1 hjdist2 hjdist3];
V = cov(Y,1);
mu = repmat(mean(Y),maxT,1);
Vhalf = chol(V);
p = [0.10 0.05 0.01];
count1 = zeros(maxr,nT,3);
d2 = zeros(nmodel,1);
for i=1:ns
if rem(i,1000)==0
i
end
    Ys = mu+randn(maxT,N+K)*Vhalf;
    for jj=1:nT
        T1 = TT(jj);
        Rs = exp(Ys(1:T1,K+1:end));
        nt1 = zeros(T1,nmodel);
        W = inv((Rs'*Rs)/T1);
        for j=1:nmodel
            if j==1
                Fs = Ys(1:T1,1);
                [hjd,~,~,dse,gam,~,~,~,qt] = hjll(Rs,Fs,q);
                d2(j) = hjd^2;
                nt1(:,j) = qt;
            elseif j==2
                Fs = exp(Ys(1:T1,j+1:K))-1;
                X = [ones(T1,1) Fs];
                D = (Rs'*X)./T1;
                gamma = inv(D'*W*D)*D'*W*q;
                yt = X*gamma;
                e = D*gamma-q;
                lam = W*e;
                mt = yt-Rs*lam;
                phi = yt.*yt-mt.*mt-2*q'*lam;
                d2(j) = mean(phi);
                ut = ((T1-N-2)/T1)*Rs*W*e;
                nt1(:,j) = 2*ut.*yt-ut.^2+d2(j);     
            else
                Fs = Ys(1:T1,j-1);
                [hjd,~,~,dse,gam,~,~,~,qt] = hjll(Rs,Fs,q);
                d2(j) = hjd^2;
                nt1(:,j) = qt;
            end   
        end
%
%   Model comparison using Wolak's test
%
        d = d2(1)-d2(2:end);
        dt = nt1(:,1)*ones(1,maxr)-nt1(:,2:end);
        Sd = (dt'*dt)/T1;
        for j=1:maxr
            d1 = d(1:j);
            w = waldweight(Sd(1:j,1:j));                        
            if all(d1<=0)
               pval = 1-w(end);
            else
               [lam,obj] = quadprog(Sd(1:j,1:j),-sqrt(T1)*d1,-eye(j),zeros(j,1),[],[],[],[],[], ...
                           optimset('Display','off','Diagnostics','off','Algorithm','interior-point-convex'));
               pval = gammainc(-obj,[1:j]./2,'upper')*w(j:-1:1);
            end
            ind = pval<p;
            count1(j,jj,ind) = count1(j,jj,ind)+1;
        end
    end    
end  
count1 = count1/ns;
delete table4_d2d4.out
diary table4_d2d4.out
fprintf(' Number of simulations = %7.0f\n',ns)
fprintf(' Power of Multiple Model Comparison Using Wolak Test\n')
fprintf(' hjdist  %7.4f %7.4f %7.4f\n',hjdist)
fprintf(' r      %7.0f %7.0f  \n',1:maxr)
for i=1:nT
    fprintf(' T = %4.0f\n',TT(i))
    fprintf(' 10%%     %7.3f %7.3f  \n',count1(:,i,1))
    fprintf(' 5%%      %7.3f %7.3f  \n',count1(:,i,2))
    fprintf(' 1%%      %7.3f %7.3f  \n',count1(:,i,3))
end
diary off
