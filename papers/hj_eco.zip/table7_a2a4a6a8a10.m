%
%  table7_a2a4a6a8a10.m   Date: 2/10/2012
%  Unconstrained HJ-distance; non-nested models
%  This program computes the power of the joint test that 
%  two non-nested models are correctly specified.
%  Five tests are considered: 
%  (1) The test of phi_F=phi_G based on a weighted chi-squared
%  test without restrictions on eigenvalues,  
%  (2) A Wald test of lambda_F=lambda_G=0_n,
%  (3) The test of delta_F=delta_G=0 based on a weighted chi-squared
%  test with restrictions on eigenvalues,
%  (4) A test of sigma_d^2=0 based on a weighted chi-squared
%      test without restrictions on eigenvalues,
%  (5) A test of sigma_d^2=0 based on a weighted chi-squared
%      test with restrictions on eigenvalues.
%  The parameters are based on the CAPM and the factor
%  in each model is equal to the MKT factor plus a noise.
%
clear all
load quarterly
R = R(1:195,:);
[T,N] = size(R);
mu2h = mean(R)';
F = mkt(1:195);
K = size(F,2);
Y = [F R];
V = cov(Y,1);
V21 = V(K+1:end,1:K);
V22 = V(K+1:end,K+1:end);
V11 = V(1:K,1:K);
V22i = inv(V22);
q = ones(N,1);
X = [q V21];
eta = inv(X'*V22i*X)*(X'*V22i*mu2h);
mu2 = X*eta;
K1 = 2;
K2 = 2;
mu = [zeros(K,1); mu2h]; % we are setting mu2 such that the CAPM with an intercept does not hold
ns = 100000;
TT = [120:120:600];
maxT = max(TT);
nT = length(TT);
mu = repmat(mu',maxT,1);
Vhalf = chol(V);
% count1: asymptotic weighted chi-squared test in Theorem 2
% count2: asymptotic chi-squared test in Theorem 2
% count3: asymptotic weighted chi-squared test (unrestricted)
% count4: asymptotic weighted chi-squared test (unrestricted) of H_0: \sigma^2_d=0
% count5: asymptotic weighted chi-squared test (restricted) of H_0: \sigma^2_d=0
p = [0.10 0.05 0.01];
cutoff = chi2inv(1-p,2*N-K1-K2);
count1 = zeros(nT,3);
count2 = zeros(nT,3);
count3 = zeros(nT,3);
count4 = zeros(nT,3);
count5 = zeros(nT,3);
c = 0.2;
stdn = sqrt(c)*std(F(:,1),1);
for i=1:ns
if rem(i,1000)==0
i
end
    Ys = mu+randn(maxT,N+K)*Vhalf;
    es1 = stdn*randn(maxT,1);  % measurement error
    es2 = stdn*randn(maxT,1);  % measurement error
    for jj=1:nT
        T  = TT(jj);
        F1 = Ys(1:T,1)+es1(1:T);
        F2 = Ys(1:T,1)+es2(1:T);
        R = Ys(1:T,K+1:end);
        U = (R'*R)./T;
        W = inv(U);
        Xf = [ones(T,1) F1];
        Xg = [ones(T,1) F2];
        Df = (R'*Xf)/T;
        Hf = inv(Df'*W*Df);
        gammaf = Hf*Df'*W*q;
        Dg = (R'*Xg)/T;
        Hg = inv(Dg'*W*Dg);
        gammag = Hg*Dg'*W*q;
        gef = Df*gammaf-q;
        geg = Dg*gammag-q;
        yf = Xf*gammaf;
        yg = Xg*gammag;
        lamf = W*gef;
        lamg = W*geg;
        mf = yf-R*lamf;
        mg = yg-R*lamg;
        phif = yf.*yf-mf.*mf-2*q'*lamf;
        phig = yg.*yg-mg.*mg-2*q'*lamg;
        phid = phif-phig;
        d2d = mean(phid);
        phid1 = phif+phig;
        d2dplus = mean(phid1);
        sigma2d = mean(phid.^2);
        Whalf = sqrtm(W);
        % Theorem 2
        Pf = Whalf*null(Df'*Whalf);
        Pg = Whalf*null(Dg'*Whalf);
        gf = R.*(yf*ones(1,N))-ones(T,1)*q'; 
        gg = R.*(yg*ones(1,N))-ones(T,1)*q'; 
        g = [gf gg];
        S = g'*g./T;
        Sf = S(1:N,1:N);
        Sfg = S(1:N,N+1:2*N); 
        Sgf = Sfg';
        Sg = S(N+1:2*N,N+1:2*N);
        A = [Pf'*Sf*Pf -Pf'*Sfg*Pg; ...
             Pg'*Sgf*Pf -Pg'*Sg*Pg];
        e = real(eig(A));
        pp = linchi2(T*d2d,e);
        pval = 2*min(pp,1-pp);
        count1(jj,:) = count1(jj,:)+(pval<p);        
        lambdafg = [lamf; lamg];
        Pfg = [Pf'*U zeros(N-K1,N); zeros(N-K2,N) Pg'*U]; 
        A1 = [Pf'*Sf*Pf Pf'*Sfg*Pg; ...
              Pg'*Sgf*Pf Pg'*Sg*Pg];
        chi2 = T*lambdafg'*Pfg'*inv(A1)*Pfg*lambdafg;
        count2(jj,:) = count2(jj,:)+(chi2>cutoff);
% Asymptotic weighted chi-squared test (restricted) based on
% sigma^2_d
        pval = 1-linchi2(T*sigma2d,4*(e.^2));
        count5(jj,:) = count5(jj,:)+(pval<p); %restricted sigma^2_d=0
% Asymptotic weighted chi-squared test (unrestricted) based on
% \hat\delta_F^2-\hat\delta_G^2 and \hat\sigma^2_d
        Hfmat = 2*[zeros(K1) Df'; Df -U];
        Hgmat = 2*[zeros(K2) Dg'; Dg -U];
        h = 2*[Xf.*((yf-mf)*ones(1,K1)) R.*(mf*ones(1,N))-ones(T,1)*q' ...
               Xg.*((yg-mg)*ones(1,K2)) R.*(mg*ones(1,N))-ones(T,1)*q'];
        M = (h'*h)/T;
        Mf = M(1:N+K1,1:N+K1);
        Mg = M(N+K1+1:end,N+K1+1:end);
        Mfg = M(1:N+K1,N+K1+1:end);
        Mgf = Mfg';
        mat = 0.5*[-inv(Hfmat)*Mf -inv(Hfmat)*Mfg;...
                   inv(Hgmat)*Mgf inv(Hgmat)*Mg];
        e = real(eig(mat));
        pp = linchi2(T*d2d,e);
        pval = 2*min(pp,1-pp);
        count3(jj,:) = count3(jj,:)+(pval<p);        
        pval = 1-linchi2(T*sigma2d,4*(e.^2));
        count4(jj,:) = count4(jj,:)+(pval<p);
    end
end  
delete table7_a2a4a6a8a10.out
diary table7_a2a4a6a8a10.out
fprintf(' Power of Test of Correct Specification for Two Non-nested Models:\n')
fprintf(' Number of simulations = %7.0f\n',ns)
fprintf(' GKR Test\n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),count1(i,:)/ns)
end    
fprintf(' chi-squared GKR Test\n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),count2(i,:)/ns)
end
fprintf(' LXZ Test\n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),count3(i,:)/ns)
end    
fprintf(' unrestricted sigma^2_d test\n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),count4(i,:)/ns)
end
fprintf(' restricted sigma^2_d test\n')
fprintf('  T     10%%      5%%      1%%\n')
for i=1:nT
    fprintf('%4.0f %7.3f %7.3f %7.3f\n',TT(i),count5(i,:)/ns)
end
diary off
