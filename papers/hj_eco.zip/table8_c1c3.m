%
%  table8_c1c3.m   Date: 2/10/2012
%  Size of the tests of H0: \delta^2=0 and H0: \lambda=0_n.
%  For the test of H0: \delta^2=0, we have two cases: imposing the null 
%  on S and not imposing the null on S.
%  Gross returns case. 
%  Parametes are set based on the YOGO model.
%
clear all
load quarterly
df = 8;
R = R(1:195,:);
[T,N] = size(R);
F = [mkt(1:195) dur(1:195) ndur(1:195)]; % YOGO 3-factor model
K = size(F,2);
q = ones(N,1);
mu2h = mean(R)';
V = cov([F R],1);
V21 = V(K+1:end,1:K);
V22 = V(K+1:end,K+1:end);
V22i = inv(V22);
X = [q V21];
mu2 = X*inv(X'*V22i*X)*X'*V22i*mu2h;
ns = 100000;
TT = [120:120:600];
maxT = max(TT);
nT = length(TT);
mu = repmat([zeros(1,K) mu2'],maxT,1);
Vhalf = chol(V);
pval = NaN(ns,nT);    % Test of delta=0, not imposing the null
pval0 = NaN(ns,nT);   % Test of delta=0, imposing the null
pval1 = NaN(ns,nT);   % Test of lambda=0_n
for i=1:ns
if rem(i,1000)==0
i
end
    U = sqrt(chi2rnd(df,maxT,1)/(df-2));	% Set it to df-2 so Var[E]=I_N
    E = randn(maxT,N+K)./(U*ones(1,N+K));
    Ys = mu+E*Vhalf;
    F = [ones(maxT,1) Ys(:,1:K)];
    R = Ys(:,K+1:end);
    for jj=1:nT
        T1 = TT(jj);
        Fs = F(1:T1,:);
        Rs = R(1:T1,:);
%
%   Unconstrained HJ-distance for the model under the null
%        
        W = inv((Rs'*Rs)/T1);  
        D = (Rs'*Fs)/T1;
        G1 = chol(W);
        G1D = G1*D;
        H = inv(G1D'*G1D);
        c = H*D'*W*q;
        ge = D*c-q;		       % Pricing Errors 
        lambda = W*ge;
        Td2 = T1*(ge'*W*ge); % Squared HJ-distance
        y = Fs*c;
        m = y-Rs*lambda;
        E = Rs.*(y*ones(1,N))-ones(T1,1)*q';   % imposing the null
        E1 = Rs.*(m*ones(1,N))-ones(T1,1)*q';  % not imposing the null
        S = (E'*E)/T1;		% This can be cov(E,1)
        S1 = (E1'*E1)/T1;	
        P = null(G1D');
        PGSGP = P'*G1*S*G1'*P;
        PGSGP1 = P'*G1*S1*G1'*P;
        e = eig(PGSGP);
        e1 = eig(PGSGP1);
        pval0(i,jj) = 1-linchi2(Td2,e); 
        pval(i,jj) = 1-linchi2(Td2,e1); 
        lam = P'*inv(G1)'*lambda;
        wald = T1*lam'*inv(PGSGP)*lam;
        pval1(i,jj) = 1-chi2cdf(wald,N-K-1);
    end
end  
delete table8_c1c3.out
diary table8_c1c3.out
fprintf(' Number of Simulations = %7.0f\n',ns)
fprintf(' HJ-Distance = %7.4f\n',0)
fprintf(' N = %3.0f,  K = %3.0f\n',N,K)
fprintf(' Size of the tests\n')
fprintf('          delta=0 (using S)          \n')
fprintf('  T      10%%      5%%      1%%      \n') 
for jj=1:nT
    fprintf(' %3.0f   %6.3f  %6.3f  %6.3f     \n',...
    TT(jj),mean(pval0(:,jj)<0.1),mean(pval0(:,jj)<0.05),mean(pval0(:,jj)<0.01))
end
fprintf('         delta=0 (using S_A)         \n')
fprintf('  T      10%%      5%%      1%%      \n') 
for jj=1:nT
    fprintf(' %3.0f   %6.3f  %6.3f  %6.3f     \n',...
    TT(jj),mean(pval(:,jj)<0.1),mean(pval(:,jj)<0.05),mean(pval(:,jj)<0.01))
end
fprintf('              lambda=0_n             \n')
fprintf('  T      10%%      5%%      1%%      \n') 
for jj=1:nT
    fprintf(' %3.0f   %6.3f  %6.3f  %6.3f     \n',...
    TT(jj),mean(pval1(:,jj)<0.1),mean(pval1(:,jj)<0.05),mean(pval1(:,jj)<0.01))
end
diary off

 