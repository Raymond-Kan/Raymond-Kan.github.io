%
% hjbound.m		Date: 5/9/2006
% This Matlab program computes the sample constrained and
% unconstrained HJ-bound and their confidence intervals.
% Input:
% R: TxN matrix of gross returns of N risky assets
% R0: Gross risk-free rate
% alpha: coverage rate of confidence interval
% Ouput:
% v0: unconstrained sample HJ-bound
% v0l: alpha% lower confidence interval for unconstrained HJ-bound
% v0h: alpha% upper confidence interval for unconstrained HJ-bound
% vc: MLE constrained HJ-bound
% vcl: alpha% lower confidence interval for constrained HJ-bound
% vch: alpha% upper confidence interval for constrained HJ-bound
% vcn: nonparametric estimate of constrained HJ-bound
% avc: approximate unbiased constrained HJ-bound
%
function [v0,v0l,v0h,vc,vcl,vch,vcn,avc]=hjbound(R,R0,alpha)
if nargin<3
   alpha = 0.95;
end
[T,N] = size(R);
mu = mean(R)';
V = cov(R,1);
Vi = inv(V);
a = mu'*Vi*mu;
b = sum(Vi*mu);
c = sum(sum(Vi));
mum = 1/R0;
thetasq = a-2*b*R0+c*R0^2;
theta = sqrt(thetasq);
v0 = a*mum^2-2*b*mum+c;
v0u = ((T-N-2)*v0-N*mum*mum)/T;  % unbiased estimator
%
%   The key is to find a confidence interval for
%   theta0^2 as both v0 and vc are monotonic functions
%   of theta0.
%   Note that \hat\theta_0^2 \sim \chi^2_N(T\theta_0^2)/\chi^2_{T-N}.
%   We first construct confidence interval for theta_0^2
%
x = (T-N)*thetasq/N;
p = 0.5*(1-alpha);
cfpval = fcdf(x,N,T-N);
init = 10*(T-N-2)*thetasq;
%
%   (t2l,t2u) is the confidence interval for theta_0^2
%
if cfpval<1-p
   t2l = 0;
else
   t2l = fzero(@(d) ncfcdf(x,N,T-N,d)-(1-p),[eps init])/T;
end
if cfpval<p
   t2h = 0;
else
   t2h = fzero(@(d) ncfcdf(x,N,T-N,d)-p,[eps init])/T;
end
v0l = t2l/R0^2;
v0h = t2h/R0^2;
%
%   MLE Constrained HJ-bound
%
if nargout>3
   options = optimset('Display','off','TolFun',1e-10);
   a1 = 1/theta;
   eta = fzero(@(u) u+normpdf(u)/normcdf(u)-a1,[a1-theta,a1],options); 
   vc = theta*(eta+theta)/(R0^2*normcdf(eta))-1/R0^2;
   if t2l==0
      vcl = 0;
   else
      t = sqrt(t2l);
      a1 = 1/t;
      eta = fzero(@(u) u+normpdf(u)/normcdf(u)-a1,[a1-t,a1],options); 
      vcl = t*(eta+t)/(R0^2*normcdf(eta))-1/R0^2;
   end
   if t2h==0
      vch = 0;
   else
      t = sqrt(t2h);
      a1 = 1/t;
      eta = fzero(@(u) u+normpdf(u)/normcdf(u)-a1,[-30,a1],options); 
      vch = t*(eta+t)/(R0^2*normcdf(eta))-1/R0^2;
   end
end
%
%   Nonparametric constrained HJ-bound
%
if nargout>6
%
%  First check if vcn is inifnity by finding an
%  in-sample arbitrage portfolio, i.e., a portfolio that
%  has negative excess return in every period.
%
   r = R-R0;
   [x,fval,exitflag] = linprog(ones(N,1),r,-ones(T,1),[],[],[],[],[],optimset('Display','off'));
   if exitflag~=-5&&exitflag~=-2
      vcn = Inf;
   else
%
%  Solve primal problem
%
      [m,fval,exitflag] = quadprog(eye(T),[],-eye(T),zeros(T,1),[R0*ones(1,T); R'],T*ones(N+1,1),[],[],[], ...
                          optimset('Display','off','Diagnostics','off','Algorithm','interior-point-convex'));
      vcn = 2*fval/T-1/R0^2;
%
%  Solve dual problem
%   
%      w0 = -(1/(theta*(eta+theta)))*Vi*(mu-R0);   % initial estimate
%      what = fsolve(@(y) mean(max(0,1+r*y)*ones(1,N).*r),w0,options);
%      vcn = (1/mean(max(0,1+r*what).^2)-1)/R0^2;
   end
end
%
%   Approximate unbiased constrained HJ-bound
%
if nargout>7
   theta2adj = max(0,(T-N-2)*theta^2/T-N/T);
   if theta2adj==0
      etaadj = Inf;
   else
      a1 = 1/sqrt(theta2adj);
      etaadj = fzero(@(u) u+normpdf(u)/normcdf(u)-a1,[-30,a1]);
   end    
   avc = max(0,vc-(N+(N+2)*theta2adj)/((T-N-2)*normcdf(etaadj)*R0^2));
end
