%
%   This Matlab function computes the cdf of the maximum
%   eigenvalue of Beta-MANOVA matrix
%   Input: 
%   MAX: number of terms to be evaluated in mhg
%   beta: beta coefficient
%   a: first parameter of Beta-MANOVA matrix (tyically p*beta/2)
%   b: second parameter of Beta-MANOVA matrix (typically n*beta/2) 
%   Sigma: a vector of the eigenvalues of the covariance matrix
%   x: values of the maximum eigenvalue
%   Output:
%   F: cdf of the maximum eigenvalue evaluated at x 
%
function F=MANOVAmaxEV_cdf(MAX,beta,a,b,Sigma,x)
m = length(Sigma);
if m==1
   F = fcdf(x*Sigma*b/a./(1-x),2*a,2*b);
   return
end
r = (m-1)*beta/2+1;
t = b-r;
F = zeros(size(x));
if fix(t)==t&&t>=0
   MAX = m*t;
   for i=1:numel(x)
       F(i) = prod(1+(1-x(i))/x(i)./Sigma)^(-a)* ...
              mhg([MAX,t],2/beta,a,[],(1-x(i))./(1-x(i)+x(i)*Sigma));
   end
else 
   c1 = 1;
   for i=0:m-1
       c1 = c1*gamma(a+b-i*beta/2)*gamma(r-i*beta/2)...
              /(gamma(a+r-i*beta/2)*gamma(b-i*beta/2));
   end 
   for i=1:numel(x)
       c = 1./(1+(1-x(i))/x(i)./Sigma);  % C = x*((1-x)*Sigma^{-1}+x*I_m)^{-1}
       F(i) = mhg(MAX,2/beta,[-t a],a+r,c)*prod(c)^a;
   end
   F = c1*F;
end
F(x<=0) = 0;
F(x>=1) = 1;

