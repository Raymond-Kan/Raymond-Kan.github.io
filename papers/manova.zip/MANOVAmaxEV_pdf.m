%
%   This Matlab function computes the pdf of the maximum
%   eigenvalue of Beta-MANOVA matrix
%   Input: 
%   MAX: number of terms to be evaluated in mhg
%   beta: beta coefficient
%   a: first parameter of Beta-MANOVA matrix (tyically p*beta/2)
%   b: second parameter of Beta-MANOVA matrix (typically n*beta/2) 
%   Sigma: a vector of the eigenvalues of the covariance matrix
%   x: values of the maximum eigenvalue
%   Output:
%   f: pdf of the maximum eigenvalue evaluated at x 
%
function f=MANOVAmaxEV_pdf(MAX,beta,a,b,Sigma,x)
m = length(Sigma);
if m==1
   Sigma = Sigma*b/a;
   f = fpdf(x*Sigma./(1-x),2*a,2*b)*Sigma./(1-x).^2;
   return
end
r = (m-1)*beta/2+1;
t = b-r;
f = zeros(size(x)); 
c1 = prod(Sigma)^a;
for i=0:m-1
    c1 = c1*gamma(a+b-i*beta/2)*gamma(r-i*beta/2)...
           /(gamma(a+r-i*beta/2)*gamma(b-i*beta/2));
end  
if fix(t)==t&&t>=0
   MAX = m*t;
   for i=1:numel(x)
       xx = x(i)/(1-x(i));
       [~,cc] = mhg([MAX,t],2/beta,[-t r],a+r,-xx*Sigma);
       c2 = m*a-(a+t)*sum((xx*Sigma)./(1+xx*Sigma));
       f1 = c1*sum(cc.*(c2+[0:MAX]));
       f(i) = f1*xx^(m*a-1)/(1-x(i))^2/prod(1+xx*Sigma)^(t+a);     
   end
else
   for i=1:numel(x)
       f(i) = (prod(1-x(i)+x(i)*Sigma))^(-a-b)*x(i)^(m*a-1)*(1-x(i))^(m*b-1);
       c = 1./(1+(1-x(i))/x(i)./Sigma);  % C = ((1-x)/x*Sigma^{-1}+I_m)^{-1}
       lambda = MAX./[1:m-1];
       f(i) = f(i)*mhg([MAX MAX lambda],2/beta,[a+b,r+beta/2,r-1],[a+r,m*beta/2],c);
   end
   f = m*a*c1*f;
end
f(x<=0|x>=1) = 0;
