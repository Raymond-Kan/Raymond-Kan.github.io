nn = 1000000;
beta = 3;
Omega = [1 1.5];
n = 4;
p = 6;
a = beta*p/2;
b = beta*n/2;
MAX = 300;
r = zeros(1,nn);
set(groot,'DefaultTextInterpreter','latex')
set(groot,'DefaultLegendInterpreter','latex')
for i=1:nn
    s = rMANOVASVD(beta,n,p,Omega);
    r(i) = s(1)^2; 
end

clf
subplot(1,2,1)
xx = [0.01:0.01:0.99];
x = [0:0.05:0.4 0.5:0.025:0.95 1];
c = ksdensity(r,xx,'Support',[0 1],'Function','cdf');
d = ksdensity(r,xx,'Support',[0 1],'Function','pdf');
y = MANOVAmaxEV_pdf(MAX,beta,a,b,Omega,x);
yyaxis left
plot(xx,d,'r--',x,y,'ko')
set(gca,'TickDir','out','TicklabelInterpreter','latex') 
xlabel('$\lambda_{\max}$')
ylabel('Density')
title('$\beta=3,\;a=6,\;b=9,\;\Sigma=\mbox{diag}(1,1.5)$')
yyaxis right
y = MANOVAmaxEV_cdf(MAX,beta,a,b,Omega,x);
plot(xx,c,'b',x,y,'kx')
legend('emp.~PDF','theor.~PDF','emp.~CDF','theor.~CDF','Location','NorthWest')
set(gca,'TickDir','out','TicklabelInterpreter','latex') 
ylabel('Cumulative Distribution')

beta = 1.5;
Omega = [1 0.8 0.3];
n = 4;
p = 6;
a = beta*p/2;
b = beta*n/2;
MAX = 300;
r = zeros(1,nn);
for i=1:nn
    s = rMANOVASVD(beta,n,p,Omega);
    r(i) = s(end)^2; 
end
subplot(1,2,2)
xx = [0.01:0.01:0.99];
x = [0:0.05:0.9 1];
c = ksdensity(r,xx,'Support',[0 1],'Function','cdf');
d = ksdensity(r,xx,'Support',[0 1],'Function','pdf');
y = MANOVAmaxEV_pdf(MAX,beta,b,a,1./Omega,1-x);
yyaxis left
plot(xx,d,'r--',x,y,'ko')
set(gca,'TickDir','out','TicklabelInterpreter','latex') 
xlabel('$\lambda_{\min}$')
ylabel('Density')
title('$\beta=1.5,\;a=4.5,\;b=3,\;\Sigma=\mbox{diag}(1,0.8,0.3)$')
yyaxis right
y = 1-MANOVAmaxEV_cdf(MAX,beta,b,a,1./Omega,1-x);
plot(xx,c,'b',x,y,'kx')
legend('emp.~PDF','theor.~PDF','emp.~CDF','theor.~CDF','Location','East')
set(gca,'TickDir','out','TicklabelInterpreter','latex') 
ylabel('Cumulative Distribution')
set(gcf,'PaperPosition',[0 0 10 5]);
print -depsc figure1.eps
!epstopdf figure1.eps
