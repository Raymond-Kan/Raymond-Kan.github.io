function s=rMANOVASVD(beta,n,p,Omega)
L = rWishartSVD(beta,n,Omega,1);
M = rWishartSVD(beta,p,L.^(-2),1);
s = (M.^(-2)+1).^(-1/2);


