% function s = rWishartSVD(beta,n,Sigma,N)
%
% Provides N realizations of the singular values of an mxm 
% beta-Wishart matrix with n degrees of freedom and 
% covariance diag(Sigma). Sigma is assumed to be a vector
% of length m.
%
% n need not be an integer, but must be >=m
%
% The output, s, is mxN with each realization being s(:,i)
%
% Alexander Dubbs, Alan Edelman, Plamen Koev, Praveen Venkataramana
% (c) 2015

function s = rWishartSVD(beta,n,Sigma,N)

if nargin<4
   N=1;
end
m=length(Sigma);
s=zeros(m,N);

if n < m
    s = [];
else
  % generate all chi_betas we'll need
  cb=chi2rnd(beta,m-1,(m-1)*N);
  for i=2:m
      cb(i-1,:)=sqrt(Sigma(i)*cb(i-1,:));
  end

  cb2=zeros(m,N);
  for i=1:m
      cb2(i,:)=sqrt(Sigma(i)*chi2rnd(beta*(n-i+1),1,N));
  end

  % now run through the recursive process
  
  s(1,:)=cb2(1,:);
  for k=1:N
    for i=2:m
        s(1:i,k)=svd([[diag(s(1:i-1,k)),zeros(i-1,1)];...
                     [cb(i-1,(m-1)*(k-1)+(1:i-1)),cb2(i,k)]]);
         % this is the transpose of the matrix in the paper               
    end
  end
  s=s/sqrt(beta);
end

% % Based on Alex's recursive algorithm to generate one SVD:
%
% if m == 1
%    s = sqrt(Sigma(1)*chi2rnd(n*beta));
% else
%    sv_0 = rWishartSVD(n,beta,Sigma(1:m-1));
%    s = svd([ [diag(sv_0); zeros(n-m+1,m-1)], ...
%               sqrt(Sigma(m)*chi2rnd(beta,n,1)) ]);
% end
% s=s/sqrt(beta);