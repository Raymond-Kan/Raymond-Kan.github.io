These are Matlab programs for my Random Matrices: Theory and Applications paper 
"Densities of the Extreme Eigenvalues of Beta-MANOVA Matrices" (with 
Plamen Koev).  If you have questions, comments, or bug reports, please 
send them to kan@chass.utoronto.ca

Raymond Kan
Rotman School of Management
University of Toronto

Version 1.0: 6/17/2018, initial release

Note: You need the first download the mhg package which is availabe at
http://www.math.sjsu.edu/~koev/software/mhgref.html

figure1.m: program to generate the figure in the paper
MANOVAmaxEV_cdf.m: program to compute the cdf of the maximum eigenvalue
                   of Beta-MANOVA matrix 
MANOVAmaxEV_pdf.m: program to compute the pdf of the maximum eigenvalue
                   of Beta-MANOVA matrix  
rWishartSVD.m: program to simulate the singular values of a Beta-Wishart
               matrix
rMANOVASVD.m: program to simulate the singular values of a Beta-MANOVA
              matrix
                                                    