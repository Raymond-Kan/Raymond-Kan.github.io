#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*),prhs(*)
      integer nlhs,nrhs
      mwpointer mxcreatedoublematrix,mxgetpr
      mwsize mxgetm,n,pa
      mwpointer a,b,c,d,e,f,mu
      real*8 rpa

      a = mxgetpr(prhs(1))
      b = mxgetpr(prhs(2))
      mu = mxgetpr(prhs(3))
      c = mxgetpr(prhs(4))
      n = mxgetm(prhs(1))
      call mxcopyptrtoreal8(c,rpa,1)
      pa = nint(rpa)
      pa = min(pa,2*n)
      plhs(1) = mxcreatedoublematrix(pa+1,2*n+1,0)
      plhs(2) = mxcreatedoublematrix(pa+1,2*n+1,0)
      plhs(3) = mxcreatedoublematrix(pa+1,2*n+1,0)
      d = mxgetpr(plhs(1))
      e = mxgetpr(plhs(2))
      f = mxgetpr(plhs(3))
      call eandc(%val(d),%val(e),%val(f),%val(a),%val(b),%val(mu),n,pa)
      return
      end

      SUBROUTINE EANDC(C,C1,ECOEFF,AD,BD,MUD,N,PA)
      INTEGER I,J,K,N,PA
      REAL*8 AD(N,N),BD(N),MUD(N),C(PA+1,2*N+1),C1(PA+1,2*N+1)
      REAL*8 ECOEFF(PA+1,2*N+1)
      REAL*16 X(:,:),P(:,:),E(:,:),A(:,:),B(:),MU(:),B1(:)
      REAL*16 P1(:,:),DELTA,ETA
      ALLOCATABLE :: X,P,P1,E,A,B,B1,MU
      ALLOCATE(A(N,N))
      ALLOCATE(B(N))
      ALLOCATE(MU(N))
      ALLOCATE(X(N,PA+1))
      ALLOCATE(P(PA+1,2*N+1))
      ALLOCATE(P1(PA+1,2*N+1))
      ALLOCATE(E(PA+1,2*N+1))
      A = AD
      B = BD
      P = 0q0
      IF (PA.EQ.0) THEN
         ALLOCATE(B1(N))
         B1 = 1q0
         DO 100 I=2,2*N+1
         B1 = B1*B
  100    P(1,I) = SUM(B1)
      ELSE
C
C     Compute p_{i,j}'s
C
         P(2,1) = SUM((/(A(I,I),I=1,N)/))
         P(1,2) = SUM(B)         
         DO 101 I=1,N
         X(:,1) = A(:,I)
         X(:,2) = 0q0
         X(I,2) = B(I)
         DO 102 J=2,PA
         X(:,J+1) = B*X(:,J)
         DO 103 K=J,2,-1
  103    X(:,K) = MATMUL(A,X(:,K))+B*X(:,K-1)
         X(:,1) = MATMUL(A,X(:,1))
         DO 102 K=0,J
  102    P(J-K+1,K+1) = P(J-K+1,K+1)+X(I,K+1)   
         DO 107 J=1,2*N-PA
         DO 108 K=1,PA
  108    X(:,K) = MATMUL(A,X(:,K+1))+B*X(:,K)
         X(:,PA+1) = B*X(:,PA+1)
         DO 107 K=0,PA
  107    P(PA-K+1,J+K+1) = P(PA-K+1,J+K+1)+X(I,K+1)   
  101    CONTINUE
      END IF
C
C     Use multivariate Newton-Girard formula to
C     compute e_{i,j} from p_{i,j} 
C
      E = 0q0
      E(1,1) = 1q0
      DO 104 I=1,PA+1
      DO 104 J=MAX(1,3-I),2*N+2-I
  104 E(I,J) = -2q0*SUM(E(1:I,1:J)*P(I:1:-1,J:1:-1))/QFLOAT(I+J-2)
      ECOEFF = E
C
C     Compute pcoeff's 
C
      MU = MUD
      DELTA = DOT_PRODUCT(MU,MU)
      P1 = P
      P(1,2) = P(1,2)-DELTA
      P1(1,2) = P1(1,2)+DELTA      
      X(:,1) = MU
      IF (PA.GT.0) X(:,2) = MU
      DO 116 J=1,PA
      X(:,J+1) = B*X(:,J)
      DO 117 K=J,2,-1
  117 X(:,K) = MATMUL(A,X(:,K))+B*X(:,K-1)
      X(:,1) = MATMUL(A,X(:,1))
      DO 116 K=0,J
      ETA = DOT_PRODUCT(MU,X(:,K+1))
      P(J-K+1,K+1) = P(J-K+1,K+1)+QFLOAT(J)*ETA
      P1(J-K+1,K+1) = P1(J-K+1,K+1)+QFLOAT(J)*ETA
      IF (J.LT.2*N) THEN
         P(J-K+1,K+2) = P(J-K+1,K+2)-QFLOAT(J+1)*ETA
         P1(J-K+1,K+2) = P1(J-K+1,K+2)+QFLOAT(J+1)*ETA
      END IF
  116 CONTINUE
      DO 119 J=1,2*N-PA
      DO 120 K=1,PA
  120 X(:,K) = MATMUL(A,X(:,K+1))+B*X(:,K)
      X(:,PA+1) = B*X(:,PA+1)
      DO 119 K=0,PA
      ETA = DOT_PRODUCT(MU,X(:,K+1))
      P(PA-K+1,J+K+1) = P(PA-K+1,J+K+1)+QFLOAT(PA+J)*ETA   
      P1(PA-K+1,J+K+1) = P1(PA-K+1,J+K+1)+QFLOAT(PA+J)*ETA   
      IF (PA+J.LT.2*N) THEN
         P(PA-K+1,J+K+2) = P(PA-K+1,J+K+2)-QFLOAT(PA+J+1)*ETA
         P1(PA-K+1,J+K+2) = P1(PA-K+1,J+K+2)+QFLOAT(PA+J+1)*ETA
      END IF
  119 CONTINUE
C
C     Compute ccoeff's 
C     c(v1,v2} = (v1+v2)e(v1,v2)+0.5*\sum_{i,j}e(i,j)p(v1-i,v2-j)
C
      DO 130 I=1,PA+1
      DO 130 J=MAX(1,3-I),2*N+2-I
      C(I,J) = QFLOAT((I+J-2))*E(I,J)+
     *         0.5q0*SUM(E(1:I,1:J)*P(I:1:-1,J:1:-1))
  130 C1(I,J) = QFLOAT((I+J-2))*E(I,J)+
     *          0.5q0*SUM(E(1:I,1:J)*P1(I:1:-1,J:1:-1))
      RETURN
      END
