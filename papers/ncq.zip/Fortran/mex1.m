arch = computer('arch');
lapacklib = fullfile(matlabroot,'extern','lib',arch,'microsoft','libmwlapack.lib');
blaslib = fullfile(matlabroot,'extern','lib',arch,'microsoft','libmwblas.lib');
if strcmp(arch,'win32') 
   mex('-v','-compatibleArrayDims','ecq.f')
   mex('-v','-compatibleArrayDims','qmomf.f',lapacklib,blaslib)
   mex('-v','-compatibleArrayDims','qmomncf.f',lapacklib,blaslib)
   mex('-v','-compatibleArrayDims','qmomnclf.f',lapacklib,blaslib)
   mex('-v','-compatibleArrayDims','qmomncsf.f',lapacklib,blaslib)
end
if strcmp(arch,'win64') 
   mex('-v','-largeArrayDims','ecq.f')
   mex('-v','-largeArrayDims','qmomf.f',lapacklib,blaslib)
   mex('-v','-largeArrayDims','qmomncf.f',lapacklib,blaslib)
   mex('-v','-largeArrayDims','qmomnclf.f',lapacklib,blaslib)
   mex('-v','-largeArrayDims','qmomncsf.f',lapacklib,blaslib)
end
