#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*),prhs(*)
      integer nlhs,nrhs,p,q,M
      mwpointer mxgetpr,mxcreatedoublescalar
      mwsize mxgetm,n
      mwpointer r1,r2,r3,r4,r5,r6,l1,l2,l3
      real*8 temp,E

      r1 = mxgetpr(prhs(1))
      r2 = mxgetpr(prhs(2))
      r3 = mxgetpr(prhs(3))
      r4 = mxgetpr(prhs(4))
      r5 = mxgetpr(prhs(5))
      r6 = mxgetpr(prhs(6))
      plhs(1) = mxcreatedoublescalar(0)
      plhs(2) = mxcreatedoublescalar(0)
      plhs(3) = mxcreatedoublescalar(0)
      l1 = mxgetpr(plhs(1))
      l2 = mxgetpr(plhs(2))
      l3 = mxgetpr(plhs(3))
      n = mxgetm(prhs(1))
      call mxcopyptrtoreal8(r3,temp,1)
      p = nint(temp)
      call mxcopyptrtoreal8(r4,temp,1)
      q = nint(temp)
      call mxcopyptrtoreal8(r5,E,1)
      call mxcopyptrtoreal8(r6,temp,1)
      M = nint(temp)
      call mratio(%val(l1),%val(l2),%val(l3),%val(r1),%val(r2),
     *            p,q,E,M,n)
      return
      end

      SUBROUTINE MRATIO(MOMD,ERRD,M0,A,B,P,Q,ED,M,N)
      MWSIGNEDINDEX N,LWORK,INFO
      INTEGER P,Q,M,CR,PEND,K1
      REAL*8 M0,MOMD,ERRD,A(N,N),B(N),ED,X0(:,:),WORK(:),EAD(:)
      REAL*16 MOM,ERR,MAXEA,MAXEB,E0,N2P,E,CONST
      REAL*16 EA(:),EB(:),G(:,:,:),GA(:,:,:),AT(:,:)
      REAL*16 QC(:),AD(:,:),DD(:,:),EBD(:,:),G1(:,:)
      REAL*16 D(:),D1(:)
      
      ALLOCATABLE :: D,D1,WORK,X,X0,EA,EB,AT,EAD,EBD,G1
      ALLOCATABLE :: G,GA,QC,AD,DD
      E = ED
      N2P = QFLOAT(N)/2q0+QFLOAT(P)
      PEND = P+1
      ALLOCATE(AD(N,N))
      ALLOCATE(DD(N,N))
      ALLOCATE(EBD(N,N))
      ALLOCATE(G(N,N,PEND))
      ALLOCATE(D(PEND))
      ALLOCATE(X0(N,N))
      ALLOCATE(G1(N,N))
      ALLOCATE(EAD(N))
      ALLOCATE(EA(N))
      ALLOCATE(EB(N))
      LWORK = 3*N
      ALLOCATE(WORK(LWORK))
C
C     Call LAPACK dsyev to produce the eigenvalues of A
C
      X0 = A
      CALL DSYEV('N','U',N,X0,N,EAD,WORK,LWORK,INFO)
      CR = 1
      MAXEA = MAXVAL(ABS(EAD))
      AD = A/MAXEA
      IF (ALL(EAD.LE.0d0)) THEN
         CR = 2
         AD = -AD
      ELSEIF ((MOD(P,2).EQ.1).AND.(MAXVAL(EAD)*MINVAL(EAD).LT.0d0)) THEN
         CR = 3
         ALLOCATE(AT(N,N))
         ALLOCATE(GA(N,N,PEND))
         ALLOCATE(D1(PEND))
         GA = 0q0
      END IF
      MAXEB = MAXVAL(B)
      EB = B/MAXEB
      E0 = 1/SQRT(PRODUCT(EB))
      IF (P.GT.0) THEN
         IF (CR.LT.3) THEN
            DO 103 I=1,N
  103       X0(I,:) = AD(I,:)/SQRT(EB(I)*EB)
         ELSE
            X0 = AD
            CALL DSYEV('V','U',N,X0,N,EAD,WORK,LWORK,INFO)
            EA = EAD
            DO 104 I=1,N
  104       AT(:,I) = ABS(EA(I))*X0(:,I)
            AT = MATMUL(AT,TRANSPOSE(X0))
            DO 105 I=1,N
  105       X0(I,:) = AT(I,:)/SQRT(EB(I)*EB)
         END IF
         CALL DSYEV('N','U',N,X0,N,EAD,WORK,LWORK,INFO)
C
C     Generate d_p(\tilde{A}*inv(B)) for error bound
C
         ALLOCATE(QC(N))
         QC = 0q0
         EA = EAD
         DO 106 I=1,P
         QC = EA*(E0+QC)
  106    E0 = SUM(QC)/QFLOAT(2*I)
      END IF
      EB = 1q0-EB
      EBD = 0q0
      DO 107 I=1,N
      EBD(I,I) = EB(I)
  107 DD(I,:) = EB(I)
C
C     Generate d's and m's
C
      D = 0q0
      G = 0q0
      D(1) = 1q0
      IF (CR.EQ.3) D1 = D
C
C     k=0
C
      CONST = 1q0
      DO 108 I=1,P
      G(:,:,I+1) = D(I)*AD+MATMUL(AD,G(:,:,I))
      D(I+1) = SUM((/(G(J,J,I+1),J=1,N)/))/QFLOAT(2*I)
      IF (CR.EQ.3) THEN
         GA(:,:,I+1) = D1(I)*AT+MATMUL(AT,GA(:,:,I))
         D1(I+1) = SUM((/(GA(J,J,I+1),J=1,N)/))/QFLOAT(2*I)
      END IF
  108 CONST = QFLOAT(2*I)*MAXEA*CONST
      DO 109 I=1,Q
  109 CONST = CONST/(QFLOAT(N+2*(P-I))*MAXEB)
      MOM = CONST*D(PEND)
      CONST = CONST*QFLOAT(Q)/N2P
      IF (CR.EQ.3) THEN
         E0 = E0-D1(PEND)
      ELSE
         E0 = E0-D(PEND)
      END IF
      ERR = E0*CONST
C
C     k>0
C
      K1 = 1
      DO 112 WHILE (ERR.GT.E.AND.K1.LE.M)
      G1 = D(1)*EBD+DD*G(:,:,1)
      D(1) = SUM((/(G1(J,J),J=1,N)/))/QFLOAT(2*K1)
      G(:,:,1) = G1
      DO 110 I=1,P
      G1 = D(I)*AD+D(I+1)*EBD+MATMUL(AD,G1)+DD*G(:,:,I+1)
      D(I+1) = SUM((/(G1(J,J),J=1,N)/))/QFLOAT(2*(I+K1))
  110 G(:,:,I+1) = G1
      IF (CR.EQ.3) THEN
         G1 = D1(1)*EBD+DD*GA(:,:,1)
         D1(1) = SUM((/(G1(J,J),J=1,N)/))/QFLOAT(2*K1)
         GA(:,:,1) = G1
         DO 111 I=1,P
         G1 = D1(I)*AT+D1(I+1)*EBD+MATMUL(AT,G1)+DD*GA(:,:,I+1)
         D1(I+1) = SUM((/(G1(J,J),J=1,N)/))/QFLOAT(2*(I+K1))
  111    GA(:,:,I+1) = G1
      END IF 
      MOM = MOM+CONST*D(PEND)
      CONST = CONST*QFLOAT(Q+K1)/(N2P+QFLOAT(K1))
      IF (CR.EQ.3) THEN
         E0 = E0-D1(PEND)
      ELSE
         E0 = E0-D(PEND)
      END IF
      ERR = E0*CONST
      K1 = K1+1
  112 END DO
      M0 = QFLOAT(K1-1)
      ERRD = ERR
      MOMD = MOM
      IF (CR.EQ.2) MOMD = -MOMD
      RETURN
      END
