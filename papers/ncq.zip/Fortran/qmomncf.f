#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*),prhs(*)
      integer nlhs,nrhs
      mwpointer mxgetpr,mxcreatedoublescalar
      mwsize mxgetm,n,p,q,M
      mwpointer r1,r2,r3,r4,r5,r6,r7,l1,l2,l3
      real*8 temp,E

      r1 = mxgetpr(prhs(1))
      r2 = mxgetpr(prhs(2))
      r3 = mxgetpr(prhs(3))
      r4 = mxgetpr(prhs(4))
      r5 = mxgetpr(prhs(5))
      r6 = mxgetpr(prhs(6))
      r7 = mxgetpr(prhs(7))
      plhs(1) = mxcreatedoublescalar(0)
      plhs(2) = mxcreatedoublescalar(0)
      plhs(3) = mxcreatedoublescalar(0)
      l1 = mxgetpr(plhs(1))
      l2 = mxgetpr(plhs(2))
      l3 = mxgetpr(plhs(3))
      n = mxgetm(prhs(1))
      call mxcopyptrtoreal8(r4,temp,1)
      p = nint(temp)
      call mxcopyptrtoreal8(r5,temp,1)
      q = nint(temp)
      call mxcopyptrtoreal8(r6,E,1)
      call mxcopyptrtoreal8(r7,temp,1)
      M = nint(temp)
      call mratio(%val(l1),%val(l2),%val(l3),%val(r1),%val(r2),
     *            %val(r3),p,q,E,M,n)
      return
      end

      SUBROUTINE MRATIO(MOMD,ERRD,M0,A,B,MUD,P,Q,ED,M,N)
      MWSIGNEDINDEX N,LWORK,INFO
      INTEGER P,Q,M,CR,PEND,K1
      REAL*8 M0,MOMD,ERRD,A(N,N),B(N),MUD(N),ED,EAD(:),XD(:,:),WORK(:)
      REAL*16 MOM,ERR,E,MAXEA,MAXEB,E0,N2P,CONST,DELTA
      REAL*16 MU(:),EB(:),G(:,:,:),GA(:,:,:),AT(:,:)
      REAL*16 H(:,:),HA(:,:),AD(:,:),MU1(:)
      REAL*16 TC(:),D(:),D1(:),X0(:,:),DD(:,:),G1(:,:)
      
      ALLOCATABLE :: TC,D,D1,WORK,X0,DD,EB,AT
      ALLOCATABLE :: AD,EAD,XD,MU,MU1,G,GA,H,HA,G1
      PEND = P+1
      ALLOCATE(AD(N,N))
      ALLOCATE(AT(N,N))
      ALLOCATE(G(N,N,PEND))
      ALLOCATE(GA(N,N,PEND))
      ALLOCATE(H(N,PEND))
      ALLOCATE(HA(N,PEND))
      ALLOCATE(DD(N,N))
      ALLOCATE(D(PEND))
      ALLOCATE(D1(PEND))
      ALLOCATE(XD(N,N))
      ALLOCATE(X0(N,N))
      ALLOCATE(EAD(N))
      ALLOCATE(EB(N))
      ALLOCATE(MU(N))
      ALLOCATE(MU1(N))
      ALLOCATE(G1(N,N))
      LWORK = 3*N
      ALLOCATE(WORK(LWORK))
      E = ED
      MU = MUD
      DELTA = DOT_PRODUCT(MU,MU)
      N2P = QFLOAT(N)/2q0+QFLOAT(P)
C
C     Call LAPACK dsyev to produce the eigenvalues of A
C
      XD = A
      CALL DSYEV('N','U',N,XD,N,EAD,WORK,LWORK,INFO)
      CR = 1
      MAXEA = MAXVAL(ABS(EAD))
      AD = A/MAXEA
      IF (ALL(EAD.LE.0d0)) THEN
         CR = 2
         AD = -AD
      ELSEIF ((MOD(P,2).EQ.1).AND.(MAXVAL(EAD)*MINVAL(EAD).LT.0d0)) THEN
         CR = 3
      END IF
      MAXEB = MAXVAL(B)
      EB = B/MAXEB
      D(1) = 1q0
      IF (P.GT.0) THEN
         IF (CR.LT.3) THEN
            AT = AD
         ELSE
            XD = AD
            CALL DSYEV('V','U',N,XD,N,EAD,WORK,LWORK,INFO)
            DO 104 I=1,N
  104       AT(:,I) = ABS(EAD(I))*XD(:,I)
            AT = MATMUL(AT,TRANSPOSE(XD))
         END IF
         DO 121 I=1,N
  121    X0(I,:) = AT(I,:)/SQRT(EB(I)*EB)
C
C     Generate \tilde{d}_p(B^{-\frac{1}{2}}\tilde{A}*B^{-\frac{1}{2}}) for error bound
C
         ALLOCATE(TC(P))
         DD = X0
         MU1 = SQRT(2q0/EB)*MU
         DO 114 I=1,P
         TC(I) = QFLOAT(I)*DOT_PRODUCT(MATMUL(DD,MU1),MU1)+
     *           SUM((/(DD(J,J),J=1,N)/))
         IF (I.LT.P) DD = MATMUL(DD,X0)
  114    D(I+1) = DOT_PRODUCT(TC(I:1:-1),D(1:I))/QFLOAT(2*I)
      END IF
      E0 = D(PEND)*EXP(SUM(MU*MU/EB)-0.5q0*DELTA)/SQRT(PRODUCT(EB))
      EB = 1q0-EB
      X0 = 0q0
      DO 106 I=1,N
      X0(I,I) = EB(I)
  106 DD(I,:) = EB(I)
C
C     Generate d's and m's
C
      D = 0q0
      G = 0q0
      H = 0q0
      D(1) = 1q0
C
C     k=0
C
      CONST = 1q0
      DO 107 I=1,P
      G1 = D(I)*AD+MATMUL(AD,G(:,:,I))
      H(:,I+1) = MATMUL(G1,MU)+MATMUL(AD,H(:,I))
      D(I+1) = (SUM((/(G1(J,J),J=1,N)/))+
     *         DOT_PRODUCT(MU,H(:,I+1)))/QFLOAT(2*I)
      G(:,:,I+1) = G1
  107 CONST = QFLOAT(2*I)*MAXEA*CONST
      MOMD = CONST
      D1 = D
      IF (CR.EQ.3) THEN
         GA = 0q0
         HA = 0q0
         DO 108 I=1,P
         G1 = D1(I)*AT+MATMUL(AT,GA(:,:,I))
         HA(:,I+1) = MATMUL(G1,MU)+MATMUL(AT,HA(:,I))
         D1(I+1) = (SUM((/(G1(J,J),J=1,N)/))+
     *             DOT_PRODUCT(MU,HA(:,I+1)))/QFLOAT(2*I)
  108    GA(:,:,I+1) = G1
      ELSE
         GA = G
         HA = H
      END IF
      DO 109 I=1,Q
  109 CONST = CONST/(QFLOAT(N+2*(P-I))*MAXEB)
      MOM = CONST*D(PEND)
      CONST = CONST*QFLOAT(Q)/N2P
      E0 = E0-D1(PEND)
      ERR = E0*CONST
C
C     k>0
C
      K1 = 1
      DO 112 WHILE (ERR.GT.E.AND.K1.LE.M)
      G1 = D(1)*X0+DD*G(:,:,1)
      H(:,1) = MATMUL(G1-G(:,:,1),MU)-D(1)*MU+EB*H(:,1)
      D(1) = (SUM((/(G1(J,J),J=1,N)/))+
     *       DOT_PRODUCT(MU,H(:,1)))/QFLOAT(2*K1)
      G(:,:,1) = G1
      DO 110 I=1,P
      G1 = D(I)*AD+D(I+1)*X0+MATMUL(AD,G1)+DD*G(:,:,I+1)
      H(:,I+1) = MATMUL(G1-G(:,:,I+1),MU)-D(I+1)*MU+
     *           MATMUL(AD,H(:,I))+EB*H(:,I+1)
      D(I+1) = (SUM((/(G1(J,J),J=1,N)/))+
     *         DOT_PRODUCT(MU,H(:,I+1)))/QFLOAT(2*(I+K1))
  110 G(:,:,I+1) = G1
      G1 = D1(1)*X0+DD*GA(:,:,1)
      HA(:,1) = MATMUL(G1+GA(:,:,1),MU)+D1(1)*MU+EB*HA(:,1)
      D1(1) = (SUM((/(G1(J,J),J=1,N)/))+
     *        DOT_PRODUCT(MU,HA(:,1)))/QFLOAT(2*K1)
      GA(:,:,1) = G1
      DO 111 I=1,P
      G1 = D1(I)*AT+D1(I+1)*X0+MATMUL(AT,G1)+DD*GA(:,:,I+1)
      HA(:,I+1) = MATMUL(G1+GA(:,:,I+1),MU)+D1(I+1)*MU+
     *            MATMUL(AT,HA(:,I))+EB*HA(:,I+1)
      D1(I+1) = (SUM((/(G1(J,J),J=1,N)/))+
     *          DOT_PRODUCT(MU,HA(:,I+1)))/QFLOAT(2*(I+K1))
  111 GA(:,:,I+1) = G1
      MOM = MOM+CONST*D(PEND)
      CONST = CONST*QFLOAT(Q+K1)/(N2P+QFLOAT(K1))
      E0 = E0-D1(PEND)
      ERR = E0*CONST
      K1 = K1+1
  112 END DO
      M0 = DFLOAT(K1-1)
      ERRD = ERR
      MOMD = MOM
      IF (CR.EQ.2) MOMD = -MOMD
      RETURN
      END
