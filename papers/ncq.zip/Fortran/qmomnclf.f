#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*),prhs(*)
      integer nlhs,nrhs
      mwpointer mxgetpr,mxcreatedoublescalar
      mwsize mxgetm,n,p,q,M
      mwpointer r1,r2,r3,r4,r5,r6,r7,l1,l2,l3
      real*8 temp,E

      r1 = mxgetpr(prhs(1))
      r2 = mxgetpr(prhs(2))
      r3 = mxgetpr(prhs(3))
      r4 = mxgetpr(prhs(4))
      r5 = mxgetpr(prhs(5))
      r6 = mxgetpr(prhs(6))
      r7 = mxgetpr(prhs(7))
      plhs(1) = mxcreatedoublescalar(0)
      plhs(2) = mxcreatedoublescalar(0)
      plhs(3) = mxcreatedoublescalar(0)
      l1 = mxgetpr(plhs(1))
      l2 = mxgetpr(plhs(2))
      l3 = mxgetpr(plhs(3))
      n = mxgetm(prhs(1))
      call mxcopyptrtoreal8(r4,temp,1)
      p = nint(temp)
      call mxcopyptrtoreal8(r5,temp,1)
      q = nint(temp)
      call mxcopyptrtoreal8(r6,E,1)
      call mxcopyptrtoreal8(r7,temp,1)
      M = nint(temp)
      call mratio(%val(l1),%val(l2),%val(l3),%val(r1),%val(r2),
     *            %val(r3),p,q,E,M,n)
      return
      end

      SUBROUTINE MRATIO(MOMD,ERRD,M0,A,B,MUD,P,Q,ED,M,N)
      MWSIGNEDINDEX N,LWORK,INFO
      INTEGER P,Q,M,CR,PEND,P1,K1
      REAL*8 M0,MOMD,ERRD,A(N,N),B(N),MUD(N),ED,EAD(:),XD(:,:),WORK(:)
      REAL*16 MOM,ERR,E,MAXEA,MAXEB,E0,SX,N2P,CONST,DELTA,ETA2
      REAL*16 MU(:),EB(:),X(:,:,:),X1(:,:,:),AT(:,:)
      REAL*16 TC(:),AD(:,:),MU1(:),XX(:,:),XX1(:,:)
      REAL*16 PCOEFF(:,:),PCOEFF1(:,:),D(:,:),D1(:,:),X0(:,:)
      REAL*16 ETA(:),ETA1(:),DD(:,:)
      
      ALLOCATABLE :: PCOEFF,PCOEFF1,D,D1,WORK,X,X0,X1,DD,EB,AT,MU1
      ALLOCATABLE :: TC,AD,EAD,XD,MU,XX,XX1,ETA,ETA1
      PEND = P+1
      ALLOCATE(AD(N,N))
      ALLOCATE(PCOEFF(PEND,PEND+M))
      ALLOCATE(PCOEFF1(PEND,PEND+M))
      ALLOCATE(X(N,N,PEND))
      ALLOCATE(XX(N,PEND))
      ALLOCATE(DD(N,N))
      ALLOCATE(ETA(PEND))
      ALLOCATE(D(PEND,M+1))
      ALLOCATE(D1(PEND,M+1))
      ALLOCATE(XD(N,N))
      ALLOCATE(X0(N,N))
      ALLOCATE(EAD(N))
      ALLOCATE(EB(N))
      ALLOCATE(MU(N))
      ALLOCATE(MU1(N))
      LWORK = 3*N
      ALLOCATE(WORK(LWORK))
      E = ED
      MU = MUD
      DELTA = DOT_PRODUCT(MU,MU)
      N2P = QFLOAT(N)/2q0+QFLOAT(P)
C
C     Call LAPACK dsyev to produce the eigenvalues of A
C
      XD = A
      CALL DSYEV('N','U',N,XD,N,EAD,WORK,LWORK,INFO)
      CR = 1
      MAXEA = MAXVAL(ABS(EAD))
      AD = A/MAXEA
      IF (ALL(EAD.LE.0d0)) THEN
         CR = 2
         AD = -AD
      ELSEIF ((MOD(P,2).EQ.1).AND.(MAXVAL(EAD)*MINVAL(EAD).LT.0d0)) THEN
         CR = 3
         ALLOCATE(AT(N,N))
         ALLOCATE(ETA1(PEND))
         ALLOCATE(X1(N,N,PEND))
         ALLOCATE(XX1(N,PEND))
      END IF
      MAXEB = MAXVAL(B)
      EB = B/MAXEB
      ETA(1) = 1q0
      IF (P.GT.0) THEN
         IF (CR.LT.3) THEN
            DO 120 I=1,N
  120       X0(I,:) = AD(I,:)/SQRT(EB(I)*EB)
         ELSE
            XD = AD
            CALL DSYEV('V','U',N,XD,N,EAD,WORK,LWORK,INFO)
            DO 104 I=1,N
  104       AT(:,I) = ABS(EAD(I))*XD(:,I)
            AT = MATMUL(AT,TRANSPOSE(XD))
            DO 121 I=1,N
  121       X0(I,:) = AT(I,:)/SQRT(EB(I)*EB)
         END IF
C
C     Generate \tilde{d}_p(B^{-\frac{1}{2}}\tilde{A}*B^{-\frac{1}{2}}) for error bound
C
         ALLOCATE(TC(P))
         DD = X0
         MU1 = SQRT(2q0/EB)*MU
         DO 109 I=1,P
         TC(I) = QFLOAT(I)*DOT_PRODUCT(MATMUL(DD,MU1),MU1)+
     *           SUM((/(DD(J,J),J=1,N)/))
         IF (I.LT.P) DD = MATMUL(DD,X0)
  109    ETA(I+1) = DOT_PRODUCT(TC(I:1:-1),ETA(1:I))/QFLOAT(2*I)
      END IF
      E0 = ETA(PEND)*EXP(SUM(MU*MU/EB)-0.5q0*DELTA)/SQRT(PRODUCT(EB))
C
C     Generate p_{i,j} for recursive algorithm
C
      EB = 1q0-EB
      MU1 = EB*MU
      PCOEFF = 0q0
      PCOEFF1 = 0q0
      X = 0q0
      DO 130 I=1,N
      DD(I,:) = EB(I)
      IF (P.GT.0) X(I,I,2) = 1q0
  130 X(I,I,1) = 1q0
      XX(:,1) = MU
      IF (P.GT.0) XX(:,2) = MU     
      ETA = 0q0
      ETA(1) = DELTA
      IF (CR.EQ.3) THEN
         X1 = X
         XX1 = XX
         ETA1 = ETA
      END IF
      DO 116 J=1,P
      X(:,:,J+1) = DD*X(:,:,J)
      XX(:,J+1) = EB*XX(:,J)
      DO 117 K=J,2,-1
      X(:,:,K) = MATMUL(AD,X(:,:,K))+DD*X(:,:,K-1)
  117 XX(:,K) = MATMUL(AD,XX(:,K))+EB*XX(:,K-1)
      X(:,:,1) = MATMUL(AD,X(:,:,1))
      XX(:,1) = MATMUL(AD,XX(:,1))
      DO 118 K=1,J+1
      ETA2 = DOT_PRODUCT(MU,XX(:,K))
      PCOEFF(J+2-K,K) = QFLOAT(J)*(ETA2-ETA(J+2-K))
      DO 119 I=1,N
  119 PCOEFF(J+2-K,K) = PCOEFF(J+2-K,K)+X(I,I,K)
      IF (CR.LT.3) PCOEFF1(J+2-K,K) = PCOEFF(J+2-K,K)+
     *   QFLOAT(2*J)*ETA(J+2-K)
  118 ETA(J+2-K) = ETA2
  116 CONTINUE
      IF (CR.EQ.3) THEN
         DO 134 J=1,P
         X1(:,:,J+1) = DD*X1(:,:,J)
         XX1(:,J+1) = EB*XX1(:,J)
         DO 131 K=J,2,-1
         X1(:,:,K) = MATMUL(AT,X1(:,:,K))+DD*X1(:,:,K-1)
  131    XX1(:,K) = MATMUL(AT,XX1(:,K))+EB*XX1(:,K-1)
         X1(:,:,1) = MATMUL(AT,X1(:,:,1))
         XX1(:,1) = MATMUL(AT,XX1(:,1))
         DO 132 K=1,J+1
         ETA2 = DOT_PRODUCT(MU,XX1(:,K))
         PCOEFF1(J+2-K,K) = QFLOAT(J)*(ETA2+ETA1(J+2-K))
         DO 133 I=1,N
  133    PCOEFF1(J+2-K,K) = PCOEFF1(J+2-K,K)+X1(I,I,K)
  132    ETA1(J+2-K) = ETA2
  134    CONTINUE
      END IF
C
C     Generate d's and m's
C
      D = 0q0
      D(1,1) = 1q0
      D1 = D
C
C     k=0
C
      CONST = 1q0
      DO 110 I=1,P
      D(I+1,1) = SUM(D(1:I+1,1)*PCOEFF(I+1:1:-1,1))/QFLOAT(2*I)
      D1(I+1,1) = SUM(D1(1:I+1,1)*PCOEFF1(I+1:1:-1,1))/QFLOAT(2*I)
  110 CONST = QFLOAT(2*I)*MAXEA*CONST
      DO 111 I=1,Q
  111 CONST = CONST/(QFLOAT(N+2*(P-I))*MAXEB)
      MOM = CONST*D(PEND,1)
      CONST = CONST*QFLOAT(Q)/N2P
      E0 = E0-D1(PEND,1)
      ERR = E0*CONST
C
C     k>0
C
      K1 = 2
      DO 114 WHILE (ERR.GT.E.AND.K1.LE.M+1)
      P1 = P+K1-1 
      DO 141 K=1,P
      X(:,:,K) = MATMUL(AD,X(:,:,K+1))+DD*X(:,:,K)
  141 XX(:,K) = MATMUL(AD,XX(:,K+1))+EB*XX(:,K)
      X(:,:,PEND) = DD*X(:,:,PEND)
      XX(:,PEND) = EB*XX(:,PEND)
      DO 142 K=1,PEND
      ETA2 = DOT_PRODUCT(MU,XX(:,K))
      PCOEFF(P+2-K,K1+K-1) = QFLOAT(P1)*(ETA2-ETA(P+2-K))
      DO 143 I=1,N
  143 PCOEFF(P+2-K,K1+K-1) = PCOEFF(P+2-K,K1+K-1)+X(I,I,K)
      IF (CR.LT.3) PCOEFF1(P+2-K,K1+K-1) = PCOEFF(P+2-K,K1+K-1)+
     *   QFLOAT(2*P1)*ETA(P+2-K)
  142 ETA(P+2-K) = ETA2
      IF (CR.EQ.3) THEN
         DO 144 K=1,P
         X1(:,:,K) = MATMUL(AT,X1(:,:,K+1))+DD*X1(:,:,K)
  144    XX1(:,K) = MATMUL(AT,XX1(:,K+1))+EB*XX1(:,K)
         X1(:,:,PEND) = DD*X1(:,:,PEND)
         XX1(:,PEND) = EB*XX1(:,PEND)
         DO 145 K=1,PEND
         ETA2 = DOT_PRODUCT(MU,XX1(:,K))
         PCOEFF1(P+2-K,K1+K-1) = QFLOAT(P1)*(ETA2+ETA1(P+2-K))
         DO 146 I=1,N
  146    PCOEFF1(P+2-K,K1+K-1) = PCOEFF1(P+2-K,K1+K-1)+X1(I,I,K)
  145    ETA1(P+2-K) = ETA2
      END IF
      DO 113 P1=1,PEND
      SX = QFLOAT(2*(P1+K1-2))
      D(P1,K1) = SUM(D(1:P1,1:K1)*PCOEFF(P1:1:-1,K1:1:-1))/SX
  113 D1(P1,K1) = SUM(D1(1:P1,1:K1)*PCOEFF1(P1:1:-1,K1:1:-1))/SX
      MOM = MOM+CONST*D(PEND,K1)
      CONST = CONST*QFLOAT(Q+K1-1)/(N2P+QFLOAT(K1-1))
      E0 = E0-D1(PEND,K1)
      ERR = E0*CONST
      K1 = K1+1
  114 END DO
      M0 = DFLOAT(K1-2)
      ERRD = ERR
      MOMD = MOM
      IF (CR.EQ.2) MOMD = -MOMD
      RETURN
      END
