#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*),prhs(*)
      integer nlhs,nrhs
      mwpointer mxgetpr,mxcreatedoublescalar
      mwsize mxgetm,n,p,q,M
      mwpointer r1,r2,r3,r4,r5,r6,r7,l1,l2,l3
      real*8 temp,E

      r1 = mxgetpr(prhs(1))
      r2 = mxgetpr(prhs(2))
      r3 = mxgetpr(prhs(3))
      r4 = mxgetpr(prhs(4))
      r5 = mxgetpr(prhs(5))
      r6 = mxgetpr(prhs(6))
      r7 = mxgetpr(prhs(7))
      plhs(1) = mxcreatedoublescalar(0)
      plhs(2) = mxcreatedoublescalar(0)
      plhs(3) = mxcreatedoublescalar(0)
      l1 = mxgetpr(plhs(1))
      l2 = mxgetpr(plhs(2))
      l3 = mxgetpr(plhs(3))
      n = mxgetm(prhs(1))
      call mxcopyptrtoreal8(r4,temp,1)
      p = nint(temp)
      call mxcopyptrtoreal8(r5,temp,1)
      q = nint(temp)
      call mxcopyptrtoreal8(r6,E,1)
      call mxcopyptrtoreal8(r7,temp,1)
      M = nint(temp)
      call mratio(%val(l1),%val(l2),%val(l3),%val(r1),%val(r2),
     *            %val(r3),p,q,E,M,n)
      return
      end

      SUBROUTINE MRATIO(MOMD,ERRD,M0,A,B,MUD,P,Q,ED,M,N)
      MWSIGNEDINDEX N,LWORK,INFO
      INTEGER P,Q,M,CR,PEND,K1,P1
      REAL*8 M0,MOMD,ERRD,A(N,N),B(N),MUD(N),ED,X0(:,:),WORK(:),EAD(:)
      REAL*16 MOM,ERR,MAXEA,MAXEB,E0,SX,N2P,E,CONST,DELTA
      REAL*16 EB(:),AT(:,:)
      REAL*16 EE(:),TC(:),AD(:,:),X1(:,:),MU(:),MU1(:)
      REAL*16 ECOEFF(:,:),ECOEFF1(:,:),D(:,:),D1(:,:)
      REAL*16 CCOEFF(:,:),CCOEFF1(:,:),CCOEFF2(:,:)
      
      ALLOCATABLE :: D,D1,WORK,X0,X1,EB,AT,EAD,MU,MU1
      ALLOCATABLE :: ECOEFF,ECOEFF1,CCOEFF,CCOEFF1,CCOEFF2,EE,TC,AD
      PEND = P+1
      P1 = MIN(P,2*N)
      ALLOCATE(AD(N,N))
      ALLOCATE(ECOEFF(P1+1,2*N+1))
      ALLOCATE(ECOEFF1(P1+1,2*N+1))
      ALLOCATE(CCOEFF(P1+1,2*N+1))
      ALLOCATE(CCOEFF1(P1+1,2*N+1))
      ALLOCATE(D(PEND,2*N+1))
      ALLOCATE(D1(PEND,2*N+1))
      ALLOCATE(X0(N,N))
      ALLOCATE(X1(N,N))
      ALLOCATE(EAD(N))
      ALLOCATE(EB(N))
      ALLOCATE(EE(PEND))
      ALLOCATE(MU(N))
      ALLOCATE(MU1(N))
      LWORK = 3*N
      ALLOCATE(WORK(LWORK))
      E = ED
      MU = MUD
      DELTA = DOT_PRODUCT(MU,MU)
      N2P = QFLOAT(N)/2q0+QFLOAT(P)      
C
C     Call LAPACK dsyev to produce the eigenvalues of A
C
      X0 = A
      CALL DSYEV('N','U',N,X0,N,EAD,WORK,LWORK,INFO)
      CR = 1
      MAXEA = MAXVAL(ABS(EAD))
      AD = A/MAXEA
      IF (ALL(EAD.LE.0d0)) THEN
         CR = 2
         AD = -AD
      ELSEIF ((MOD(P,2).EQ.1).AND.(MAXVAL(EAD)*MINVAL(EAD).LT.0d0)) THEN
         CR = 3
         ALLOCATE(AT(N,N))
         ALLOCATE(CCOEFF2(P1+1,2*N+1))
      END IF
      MAXEB = MAXVAL(B)
      EB = B/MAXEB
      EE(1) = 1q0
      IF (P.GT.0) THEN
         IF (CR.LT.3) THEN
            DO 100 I=1,N
  100       X0(I,:) = AD(I,:)/SQRT(EB(I)*EB)
         ELSE
            X0 = AD
            CALL DSYEV('V','U',N,X0,N,EAD,WORK,LWORK,INFO)
            DO 101 I=1,N
  101       AT(:,I) = ABS(EAD(I))*X0(:,I)
            AT = MATMUL(AT,TRANSPOSE(X0))
            DO 102 I=1,N
  102       X0(I,:) = AT(I,:)/SQRT(EB(I)*EB)
         END IF
C
C     Generate \tilde{d}_p(B^{-\frac{1}{2}}\tilde{A}*B^{-\frac{1}{2}}) for error bound
C
         ALLOCATE(TC(P))
         X1 = X0
         MU1 = SQRT(2q0/EB)*MU
         DO 103 I=1,P
         TC(I) = QFLOAT(I)*DOT_PRODUCT(MATMUL(X1,MU1),MU1)+
     *           SUM((/(X1(J,J),J=1,N)/))
         IF (I.LT.P) X1 = MATMUL(X1,X0)
  103    EE(I+1) = DOT_PRODUCT(TC(I:1:-1),EE(1:I))/QFLOAT(2*I)
      END IF
      E0 = EE(PEND)*EXP(SUM(MU*MU/EB)-0.5q0*DELTA)/SQRT(PRODUCT(EB))
C
C     Generate e_{i,j} and c_{i,j} for recursive algorithm
C
      EB = 1q0-EB
      CALL ECQ(CCOEFF,CCOEFF1,ECOEFF,AD,EB,MU,N,P1)      
      IF (CR.LT.3) THEN
         ECOEFF1 = ECOEFF
      ELSE
         CALL ECQ(CCOEFF2,CCOEFF1,ECOEFF1,AT,EB,MU,N,P1)
      END IF
C
C     Generate d's and m's
C
      D = 0q0
      D(1,1) = 1q0
      D1 = D
C
C     k=0
C
      CONST = 1q0
      DO 105 I=1,P
      N1 = MIN(2*N,I)
      D(I+1,1) = SUM((CCOEFF(2:N1+1,1)/QFLOAT(I)-ECOEFF(2:N1+1,1))*
     *           D(I:I+1-N1:-1,1))
      D1(I+1,1) = SUM((CCOEFF1(2:N1+1,1)/QFLOAT(I)-ECOEFF1(2:N1+1,1))*
     *            D1(I:I+1-N1:-1,1))
  105 CONST = QFLOAT(2*I)*MAXEA*CONST
      DO 106 I=1,Q
  106 CONST = CONST/(QFLOAT(N+2*(P-I))*MAXEB)
      MOM = CONST*D(PEND,1)
      CONST = CONST*QFLOAT(Q)/N2P
      E0 = E0-D1(PEND,1)
      ERR = E0*CONST
C
C     k>0
C
      K = 1
      DO 107 WHILE (ERR.GT.E.AND.K.LE.M)
      IF (K.GT.2*N) THEN
         K1 = 2*N+1
         D(:,1:2*N) = D(:,2:2*N+1)
         D(:,2*N+1) = 0q0
         D1(:,1:2*N) = D1(:,2:2*N+1)
         D1(:,2*N+1) = 0q0
      ELSE
         K1 = K+1
      END IF
      DO 108 P1=1,PEND
      SX = QFLOAT(P1+K-1)
      DO 109 J=0,MIN(2*N-1,K)
      DO 109 I=MAX(0,1-J),MIN(P1-1,2*N-J)
      D(P1,K1) = D(P1,K1)+(CCOEFF(I+1,J+1)/SX-ECOEFF(I+1,J+1))*
     *           D(P1-I,K1-J)
  109 D1(P1,K1) = D1(P1,K1)+(CCOEFF1(I+1,J+1)/SX-ECOEFF1(I+1,J+1))*
     *            D1(P1-I,K1-J)
  108 CONTINUE
      MOM = MOM+CONST*D(PEND,K1)
      CONST = CONST*QFLOAT(Q+K)/(N2P+QFLOAT(K))
      E0 = E0-D1(PEND,K1)
      ERR = E0*CONST
      K = K+1
  107 END DO
      M0 = DFLOAT(K-1)
      ERRD = ERR
      MOMD = MOM
      IF (CR.EQ.2) MOMD = -MOMD
      RETURN
      END

      SUBROUTINE ECQ(C,C1,E,A,B,MU,N,PA)
      INTEGER I,J,K,N,PA
      REAL*16 A(N,N),B(N),MU(N),C(PA+1,2*N+1),C1(PA+1,2*N+1)
      REAL*16 E(PA+1,2*N+1)
      REAL*16 X(:,:),P(:,:),B1(:)
      REAL*16 P1(:,:),DELTA,ETA
      ALLOCATABLE :: X,P,P1,B1
      ALLOCATE(X(N,PA+1))
      ALLOCATE(P(PA+1,2*N+1))
      ALLOCATE(P1(PA+1,2*N+1))
      P = 0q0
      IF (PA.EQ.0) THEN
         ALLOCATE(B1(N))
         B1 = 1q0
         DO 105 I=2,2*N+1
         B1 = B1*B
  105    P(1,I) = SUM(B1)
      ELSE
C
C     Compute p_{i,j}'s
C
         DO 100 I=1,N
         P(2,1) = P(2,1)+A(I,I)
  100    P(1,2) = P(1,2)+B(I)
         DO 101 I=1,N
         X(:,1) = A(:,I)
         X(:,2) = 0q0
         X(I,2) = B(I)
         DO 102 J=2,PA
         X(:,J+1) = B*X(:,J)
         DO 103 K=J,2,-1
  103    X(:,K) = MATMUL(A,X(:,K))+B*X(:,K-1)
         X(:,1) = MATMUL(A,X(:,1))
         DO 102 K=0,J
  102    P(J-K+1,K+1) = P(J-K+1,K+1)+X(I,K+1)   
         DO 107 J=1,2*N-PA
         DO 108 K=1,PA
  108    X(:,K) = MATMUL(A,X(:,K+1))+B*X(:,K)
         X(:,PA+1) = B*X(:,PA+1)
         DO 107 K=0,PA
  107    P(PA-K+1,J+K+1) = P(PA-K+1,J+K+1)+X(I,K+1)   
  101    CONTINUE
      END IF
C
C     Use multivariate Newton-Girard formula to
C     compute e_{i,j} from p_{i,j} 
C
      E = 0q0
      E(1,1) = 1q0
      DO 104 I=1,PA+1
      DO 104 J=MAX(1,3-I),2*N+2-I
  104 E(I,J) = -2q0*SUM(E(1:I,1:J)*P(I:1:-1,J:1:-1))/QFLOAT(I+J-2)
C
C     Compute pcoeff's 
C
      DELTA = DOT_PRODUCT(MU,MU)
      P1 = P
      P(1,2) = P(1,2)-DELTA
      P1(1,2) = P1(1,2)+DELTA      
      X(:,1) = MU
      IF (PA.GT.0) X(:,2) = MU
      DO 116 J=1,PA
      X(:,J+1) = B*X(:,J)
      DO 117 K=J,2,-1
  117 X(:,K) = MATMUL(A,X(:,K))+B*X(:,K-1)
      X(:,1) = MATMUL(A,X(:,1))
      DO 116 K=0,J
      ETA = DOT_PRODUCT(MU,X(:,K+1))
      P(J-K+1,K+1) = P(J-K+1,K+1)+QFLOAT(J)*ETA
      P1(J-K+1,K+1) = P1(J-K+1,K+1)+QFLOAT(J)*ETA
      IF (J.LT.2*N) THEN
         P(J-K+1,K+2) = P(J-K+1,K+2)-QFLOAT(J+1)*ETA
         P1(J-K+1,K+2) = P1(J-K+1,K+2)+QFLOAT(J+1)*ETA
      END IF
  116 CONTINUE
      DO 119 J=1,2*N-PA
      DO 120 K=1,PA
  120 X(:,K) = MATMUL(A,X(:,K+1))+B*X(:,K)
      X(:,PA+1) = B*X(:,PA+1)
      DO 119 K=0,PA
      ETA = DOT_PRODUCT(MU,X(:,K+1))
      P(PA-K+1,J+K+1) = P(PA-K+1,J+K+1)+QFLOAT(PA+J)*ETA   
      P1(PA-K+1,J+K+1) = P1(PA-K+1,J+K+1)+QFLOAT(PA+J)*ETA   
      IF (PA+J.LT.2*N) THEN
         P(PA-K+1,J+K+2) = P(PA-K+1,J+K+2)-QFLOAT(PA+J+1)*ETA
         P1(PA-K+1,J+K+2) = P1(PA-K+1,J+K+2)+QFLOAT(PA+J+1)*ETA
      END IF
  119 CONTINUE
C
C     Compute ccoeff's 
C     c(v1,v2} = (v1+v2)e(v1,v2)+0.5*\sum_{i,j}e(i,j)p(v1-i,v2-j)
C
      DO 121 I=1,PA+1
      DO 121 J=MAX(1,3-I),2*N+2-I
      C(I,J) = QFLOAT((I+J-2))*E(I,J)+
     *         0.5q0*SUM(E(1:I,1:J)*P(I:1:-1,J:1:-1))
  121 C1(I,J) = QFLOAT((I+J-2))*E(I,J)+
     *          0.5q0*SUM(E(1:I,1:J)*P1(I:1:-1,J:1:-1))
      RETURN
      END
