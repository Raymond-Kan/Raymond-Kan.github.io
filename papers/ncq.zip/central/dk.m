%
% This program computes d_k(A) for k=0,...,M
% using a super-short recursive algorithm due to
% Brown (1986).
% a: unique eigenvalues of A
% n: multiplicities of a (default is a vector of ones)
%
function y = dk(M,a,n)
if M==0
   y = 1;
   return
end
y = ones(M+1,1);
q = zeros(size(a));
if nargin<3
   for i=1:M
       q = a.*(y(i)+q);
       y(i+1) = sum(q)/(2*i);
   end
else
   for i=1:M
       q = a.*(y(i)+q);
       y(i+1) = sum(q.*n)/(2*i);
   end
end
