n = 20;
p = 10;
q = 10;
A = zeros(n);
for i=1:n
    for j=1:n
        A(i,j) = (-1+abs(i-j))/n^2;
    end
end
B = diag([1:n]./n^2);
delete example1.out
diary example1.out
%
%   Super-short recursion
%
t = cputime;
[m,err,M0] = qratiomom(A,B,p,q,1e-5,800);
t = cputime-t;
fprintf('\n\nSuper-short Recursions:\n')
fprintf('CPU Time = %10.3fs\n',t)
fprintf('Moments:\n')
for i=0:p
    for j=0:q
        fprintf('%17.5f',m(i+1,j+1))
    end
    fprintf('\n')
end
fprintf('\nError Bounds:\n')
for i=0:p
    for j=0:q
        fprintf('%17.6e',err(i+1,j+1))
    end
    fprintf('\n')
end
fprintf('\nNumber of Terms:\n')
for i=0:p
    for j=0:q
        fprintf('%6.0f',M0(i+1,j+1))
    end
    fprintf('\n')
end
%
%   Long recursion
%
t = cputime;
[m,err,M0] = qratiomoml(A,B,p,q,1e-5,800);
t = cputime-t;
fprintf('\n\nLong Recursions:\n')
fprintf('CPU Time = %10.3fs\n',t)
fprintf('Moments:\n')
for i=0:p
    for j=0:q
        fprintf('%17.5f',m(i+1,j+1))
    end
    fprintf('\n')
end
fprintf('\nError Bounds:\n')
for i=0:p
    for j=0:q
        fprintf('%17.6e',err(i+1,j+1))
    end
    fprintf('\n')
end
fprintf('\nNumber of Terms:\n')
for i=0:p
    for j=0:q
        fprintf('%6.0f',M0(i+1,j+1))
    end
    fprintf('\n')
end
diary off
