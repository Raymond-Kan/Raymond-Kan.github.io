%
% This program computes the top order invariant polynomials
% d_{k1,k2,...,kr}(A1,A2,...,Ar) using an efficient version
% of the long recursive algorithm.  All input matrices are 
% symmetric matrices.
%
function d = mdk(A,k)
index = find(k>0);
A = A(:,:,index);
k = k(index);
r = length(k);
%
%   Quick return if r=0 or 1 or n=1
%
if r==0
   d = 1;
   return
end
if r==1
   d = dk(k,eig(0.5*(A+A')));
   return
end
s = k+1;
cs = [1; cumprod(s(1:r-1))'];
nind = cs(r)*s(r);
sk = cumsum(k);
M = sk(r);
n = size(A,1);
if n==1
   d = zeros(nind,1);
   q = cumprod([1:2:2*M-1]);
   fac = cumprod([1:max(k)]);
   x = zeros(1,r);
   sx = 0;    % sx = sum(x), it is updated instead of computed every time.
   c = 1;
   A = A./2;
   d(1) = 1;
   for i=2:nind
       for ii=1:r
           if x(ii)<k(ii)
              x(ii) = x(ii)+1;
              sx = sx+1;
              c = c*A(ii)/x(ii);
              break
           else
              x(ii) = 0;
              sx = sx-k(ii);
              c = c*fac(k(ii))/A(ii)^k(ii);
           end
       end
       d(i) = c*q(sx);
    end
    return
end
%
%   F(i,j) is a matrix of the number of elements of nu's such 
%   that 0<=|nu|<=i and nu<=k(1:j)
%
F = zeros(M,r);
F(1,:) = 1;
F(2:k(1),1) = 2:k(1);
F(s(1):M,1) = s(1);
for j=2:r
    for i=1:k(j)
        F(i+1,j) = F(i+1,j-1)+F(i,j);
    end
    for i=k(j)+1:M-1
        F(i+1,j) = F(i+1,j-1)+F(i,j)-F(i-k(j),j-1);
    end
end
%
%   d's are originally stored in blocks of |kappa| with
%   the same length.  pind allows us to reshuffle the d's
%   such that d's are organized based on ascending order
%   of elements of kappa.
%
pind = zeros(nind,1);      
pind(1) = 1;
pind(nind-r:nind-1) = nind-cs;
pind(nind) = nind;
%
%  k = 0 and 1
%  partitions are sorted in reverse lexicographical order
%
ta = zeros(1,r);
d = zeros(nind,1);
d(1) = 1;
for i=1:r
    ta(i) = trace(A(:,:,i));
    d(r+2-i) = 0.5*ta(i);
end
G = A(:,:,r:-1:1);
% Loop through all possible nu's with nu<=k
% S is the cumulative sum of the index of nu
S = zeros(1,r);
lk0 = diff(F(:,r));           % lk0 tells us the length of each block
for k1=2:M-1
    G1 = G;
    G = zeros(n,n,lk0(k1));
    for i=1:lk0(k1-1)         % Update from the last block to the current block
        df = i;               % Position of S in its own block
        i1 = F(k1-1,r)+i;
% Create next S
        j = 1;
        while j<r&&(S(j)==S(j+1)||S(j)==sk(j))
           j = j+1;
        end  
        S(j) = S(j)+1;
        for ss=j:-1:2
            S(ss-1) = max(0,S(ss)-k(ss));
        end
        pind(i1) = S(1)+diff(S)*cs(2:r)+1;
        for j=r-1:-1:1    
            b = S(j+1)-k(j+1);
            if b>0
               df = df+F(b,j)-F(b+1,j);
            elseif b==0
               df = df-1;
            end
            if b<S(j)   % Check constraint for the 2nd to last element
               G(:,:,df) = G(:,:,df)+A(:,:,j+1)*d(i1)+A(:,:,j+1)*G1(:,:,i);
            end
            df = df+F(S(j)+1,j);
            if S(j)>0
               df = df-F(S(j),j);
            end 
        end               
        if S(1)<k(1)  % Check constraint for the first element
           G(:,:,df) = G(:,:,df)+A(:,:,1)*d(i1)+A(:,:,1)*G1(:,:,i);
        end
    end
    for i=1:lk0(k1)
        d(F(k1,r)+i) = trace(G(:,:,i))/(2*k1);
    end
end
%
%  k = M, no need to update G
%
d(nind) = (ta*d(nind-r:nind-1)+sum(sum(sum(A.*G))))/(2*M);
d(pind) = d;
