%
% This program computes d_{i,j}(A,B) for 0<=i<=k1 and
% 0<=j<=k2 using a modified version of the long recursive 
% algorithm.
%
function d = mdk2(A,B,k1,k2)
n = size(A,1);
%
%   Quick return for n=1, k1=0 or k2=0
%   For n=1, d_{i,j}=(1/2)_{i+j}(a^i/i!)(b^j/j!).
%
if n==1
   d = zeros(k1+1,k2+1);
   d(1,1) = 1;
   for i=1:k2
       d(1,i+1) = B*d(1,i)*(i-0.5)/i;
   end
   for i=2:k1+1
       d(i,:) = (A/(i-1))*(d(i-1,:).*(i+[0:k2]-1.5));
   end
   return
end
A = 0.5*(A+A');
if k2==0
   d = dk(k1,eig(A));
   return
end
B = 0.5*(B+B');
if k1==0
   d = dk(k2,eig(B))';
   return
end
%
%   Cases when n>1, k1>0, and k2>0
%   Switch k1 and k2 if k1<k2.
%
if k1<k2
   swap = 1;
   C = A;
   A = B;
   B = C;
   k3 = k1;
   k1 = k2;
   k2 = k3;
else
   swap = 0;
end
d = zeros(k1+1,k2+1);
d(1,1) = 1;
G = zeros(n,n,k2+1);
%
%  row 0
%
for j=1:k2
    G1 = B*d(1,j)+B*G(:,:,j);
    d(1,j+1) = trace(G1)/(2*j);
    G(:,:,j+1) = G1;
end
%
%  row 1 to row k1-1
%
for i=1:k1-1
    G1 = A*d(i,1)+A*G(:,:,1);
    d(i+1,1) = trace(G1)/(2*i);
    G(:,:,1) = G1;
    for j=1:k2
        G1 = A*d(i,j+1)+B*d(i+1,j)+A*G(:,:,j+1)+B*G1;
        d(i+1,j+1) = trace(G1)/(2*(i+j));
        G(:,:,j+1) = G1;
    end
end
%
%   last row, no need to update G
%
G1 = A*d(k1,1)+A*G(:,:,1);
d(k1+1,1) = trace(G1)/(2*k1);
for j=1:k2
    G1 = A*d(k1,j+1)+B*d(k1+1,j)+A*G(:,:,j+1)+B*G1;
    d(k1+1,j+1) = trace(G1)/(2*(k1+j));
end
if swap
   d = d';
end
