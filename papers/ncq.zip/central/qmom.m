%
% qmom.m   Date: 2007/01/15
% This program computes E[(z'A'z)^p/(z'Bz)^q] when z ~ N(0,I), following
% Smith (1993)'s identity.
% B is assumed to be positive definite.
% This program uses a super-short recursive algorithm and calls an external
% Fortran program that computes the answer using quadruple precision.
% Input: 
% A, B: matrix of the quadratic forms in the numerator and the denominator
% p, q: power of the quadratic forms in the numerator and the denominator,
%       both are assumed to be integers
% E: precision, default is 1e-10
% M: maximum number of terms, default is 1000
% Output:
% m: E[(z'Az)^p/(z'Bz)^q] 
% err: upper bound of the approximation errors in m
% M0: number of terms to reach the desired level of precision
%
function [m,err,M0] = qmom(A,B,p,q,E,M)
n = size(A,1);
M0 = 0;
err = 0;
if n/2+p<=q
   m = NaN;
   return
end
if q==0
   d = dk(p,eig(A));
   m = prod([2:2:2*p])*d(end);
   return
end
%
% Set max times of iteration and tolerance level
%
if nargin<5
   E = 1e-10; 
end
if nargin<6
   M = 1000;
end
[P,B] = eig(B);
b = diag(B);
if any(b<=0)
   m = NaN;
   fprintf('B matrix must be positive definite!\n')
   return
else
   [m,err,M0] = qmomf(P'*A*P,b,p,q,E,M);
end
