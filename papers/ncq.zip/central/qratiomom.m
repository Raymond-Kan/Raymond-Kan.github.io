%
% qratiomom.m   Date: 2012/01/15
% This program computes E[(z'A'z)^p/(z'Bz)^q] when z ~ N(0,I), following
% Smith (1993)'s identity.
% B is assumed to be positive definite.
% This program uses a super-short recursive algorithm and 
% generates the entire table.
% Input: 
% A, B: matrix of the quadratic forms in the numerator and the denominator
% p, q: power of the quadratic forms in the numerator and the denominator
% E: precision, default is 1e-10
% M: maximum number of terms, default is 1000
% Output:
% m: E[(z'Az)^i/(z'Bz)^j] for i=0,...,p and j=0,...,q
% err: upper bound of the approximation errors in m
% M0: number of terms to reach the desired level of precision
%
function [m,err,M0] = qratiomom(A,B,p,q,E,M)
pend = p+1;
M0 = zeros(pend,q+1);
err = M0;
if q==0
   m = cumprod([1 2:2:2*p]').*dk(p,eig(A));
   return
end
n = size(A,1);
m = NaN(pend,q+1); 
m(1,1) = 1;
%
%   Normalization of A and B such that
%   their largest eigenvalue is 1.
%
[P,B] = eig(B);
b = diag(B);
if any(b<=0)
   fprintf('B matrix must be positive definite!\n')
   return
end
A = P'*A*P;
ea = eig(A);
maxea = max(abs(ea));
A = A./maxea;
ch = 1;
if all(ea<=0)    % when A is negative semi-definite
   ch = 2;
   A = -A;
elseif max(ea)*min(ea)<0&&p>0
   ch = 3;
   pend1 = pend-rem(pend,2);
end
maxeb = max(b);
b = b./maxeb;
eb = 1-b;   % nonzero eigenvalues of I_n-B
%
% Set max times of iteration and tolerance level
%
if nargin<5
   E = 1e-10;
end
if nargin<6
   M = 1000;
end
G = zeros(n,n,pend);
D = eb*ones(1,n);
eb = diag(eb);
if ch==3
   Ga = zeros(n,n,pend1);
   [P,D1] = eig(A);
   At = P*abs(D1)*P';
end
%
% generate d_p(tilde{A}*B) for error bound 
%
c = eig(A./sqrt(b*b'));
qc = zeros(n,1);
e = ones(pend,1);
for i=1:p
    qc = c.*(e(i)+qc);
    e(i+1) = sum(qc)/(2*i);
end
d = zeros(pend,1);
d(1) = 1;
if ch==3
   c = eig(At./sqrt(b*b'));
   e2 = ones(pend1,1);
   qc = zeros(n,1);
   for i=1:pend1-1
       qc = c.*(e2(i)+qc);
       e2(i+1) = sum(qc)/(2*i);
       if rem(i,2)==1;
          e(i+1) = e2(i+1);   % when p odd, the bound is different
       end
   end
   d1 = zeros(pend1,1);
   d1(1) = 1;
end
e = e./sqrt(prod(b));
%
% when j==0
%
n2 = n/2;
const = ones(pend,q);
xx = 1;
e(1) = e(1)-1;
for i=1:min(q,fix(n2-1/2))     % for p=0
    xx = xx/((n-2*i)*maxeb);
    const(1,i) = xx*i/n2;
    err(1,i+1) = e(1)*const(1,i);
    m(1,i+1) = xx;
end
x0 = 1;
for i=1:p             % for p>0
    G1 = A*d(i)+A*G(:,:,i);
    d(i+1) = trace(G1)/(2*i);
    G(:,:,i+1) = G1;
    if ch==3&&i<pend1
       G1 = At*d1(i)+At*Ga(:,:,i);
       d1(i+1) = trace(G1)/(2*i);
       Ga(:,:,i+1) = G1;
    end
    x0 = 2*maxea*x0*i;
    xx = x0;
    m(i+1,1) = xx*d(i+1,1);
    if ch==3&&rem(i,2)==1
       e(i+1) = e(i+1)-d1(i+1,1);
    else
       e(i+1) = e(i+1)-d(i+1,1);
    end     
    for j=1:min(q,fix(n2+i-1/2))
        xx = xx/((n+2*(i-j))*maxeb);
        const(i+1,j) = xx*j/(n2+i);
        m(i+1,j+1) = xx*d(i+1,1);
        err(i+1,j+1) = e(i+1)*const(i+1,j);
    end
end
%
%  j>0
%
j = 1;
while any(any(err>E))&&j<=M
   G1 = eb*d(1)+D.*G(:,:,1);
   d(1) = trace(G1)/(2*j);
   G(:,:,1) = G1;
   for i=1:pend-1
       G1 = A*d(i)+eb*d(i+1)+A*G1+D.*G(:,:,i+1);
       d(i+1) = trace(G1)/(2*(i+j));
       G(:,:,i+1) = G1;
   end
   if ch==3
      G1 = eb*d1(1)+D.*Ga(:,:,1);
      d1(1) = trace(G1)/(2*j);
      Ga(:,:,1) = G1;
      for i=1:pend1-1
          G1 = At*d1(i)+eb*d1(i+1)+At*G1+D.*Ga(:,:,i+1);
          d1(i+1) = trace(G1)/(2*(i+j));
          Ga(:,:,i+1) = G1;
      end
   end
   for i=1:pend
       if ch==3&&rem(i,2)==0
          e(i) = e(i)-d1(i);
       else
          e(i) = e(i)-d(i);
       end
       for q1=2:min(q+1,fix(n2+i-1/2))
           if err(i,q1)>E
              m(i,q1) = m(i,q1)+const(i,q1-1)*d(i);
              const(i,q1-1) = const(i,q1-1)*(q1+j-1)/(n2+i+j-1);
              M0(i,q1) = M0(i,q1)+1;
              err(i,q1) = e(i)*const(i,q1-1);
           end
       end
   end
   if all(err(pend,:)<E)
      if ch==3&&pend==pend1
         pend1 = pend1-2;
      end
      pend = pend-1;
   end   
   j = j+1;
end
if ch==2
   m(2:2:end,:) = -m(2:2:end,:); 
end
