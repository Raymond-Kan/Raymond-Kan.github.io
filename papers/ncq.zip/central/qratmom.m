%
% qratmom.m   Date: 2012/01/15
% This program computes E[(z'A'z)^p/(z'Bz)^q] when z ~ N(0,I), following
% Smith (1993)'s identity.
% B is assumed to be positive definite.
% This program uses a super-short recursive algorithm.
% Input: 
% A, B: matrix of the quadratic forms in the numerator and the denominator
% p, q: power of the quadratic forms in the numerator and the denominator
% E: precision, default is 1e-10
% M: maximum number of terms, default is 1000
% Output:
% m: E[(z'Az)^p/(z'Bz)^q] 
% err: upper bound of the approximation errors in m
% M0: number of terms to reach the desired level of precision
%
function [m,err,M0] = qratmom(A,B,p,q,E,M)
pend = p+1;
n = size(A,1);
M0 = 0;
err = 0;
n2p = n/2+p;
if n2p<=q
   m = NaN;
   return
end
if q==0
   d = dk(p,eig(A));
   m = prod([2:2:2*p])*d(end);
   return
end
%
%   Normalization of A and B such that
%   their largest eigenvalue is 1.
%
[P,B] = eig(B);
b = diag(B);
if any(b<=0)
   m = NaN;
   fprintf('B matrix must be positive definite!\n')
   return
end
A = P'*A*P;
ea = eig(A);
maxea = max(abs(ea));
A = A./maxea;
ch = 1;
if all(ea<=0)    % when A is negative semi-definite
   ch = 2;
   A = -A;
elseif rem(p,2)==1&&max(ea)*min(ea)<0
   ch = 3;
end
maxeb = max(b);
b = b./maxeb;
eb = 1-b;   % nonzero eigenvalues of I_n-B
%
% Set max number of terms and tolerance level
%
if nargin<5
   E = 1e-10; 
end
if nargin<6
   M = 1000;
end
G = zeros(n,n,pend);
D = eb*ones(1,n);
eb = diag(eb);
if ch==3
   Ga = G;
   [P,D1] = eig(A);
   At = P*abs(D1)*P';
end
%
% generate d_p(tilde{A}*B) for error bound 
%
e = 1/sqrt(prod(b));
if p>0
   if ch==3
      c = eig(At./sqrt(b*b'));
   else
      c = eig(A./sqrt(b*b'));
   end
   qc = zeros(n,1);
   for i=1:p
       qc = c.*(e+qc);
       e = sum(qc)/(2*i);
   end
end
%
% generate d's and m's
%
d = zeros(pend,1);
d(1) = 1;
if ch==3
   d1 = d;
end
%
% when j==0
%
const = 1;
for i=1:p    
    G1 = A*d(i)+A*G(:,:,i);
    d(i+1) = trace(G1)/(2*i); 
    G(:,:,i+1) = G1;       
    if ch==3
       G1 = At*d1(i)+At*Ga(:,:,i);
       d1(i+1) = trace(G1)/(2*i); 
       Ga(:,:,i+1) = G1;       
    end
    const = 2*maxea*const*i;
end
if rem(q,1)==0  % q is an integer
   for j=1:q
       const = const/((n+2*(p-j))*maxeb);
   end
else
   const = const*exp(gammaln(n2p-q)-gammaln(n2p))/(2*maxeb)^q;
end 
m = const*d(pend);     
const = const*q/n2p;
if ch==3
   e = e-d1(pend);
else
   e = e-d(pend);
end
err = e*const;
%
%   j>0
%
j = 1;
while err>E&&j<=M
   G1 = eb*d(1)+D.*G(:,:,1);
   d(1) = trace(G1)/(2*j);
   G(:,:,1) = G1;
   for i=1:p
       G1 = A*d(i)+eb*d(i+1)+A*G1+D.*G(:,:,i+1);
       d(i+1) = trace(G1)/(2*(i+j));
       G(:,:,i+1) = G1;
   end
   if ch==3
      G1 = eb*d1(1)+D.*Ga(:,:,1);
      d1(1) = trace(G1)/(2*j);
      Ga(:,:,1) = G1;
      for i=1:p
          G1 = At*d1(i)+eb*d1(i+1)+At*G1+D.*Ga(:,:,i+1);
          d1(i+1) = trace(G1)/(2*(i+j));
          Ga(:,:,i+1) = G1;
      end
   end
   m = m+const*d(pend);
   const = const*(q+j)/(n2p+j);
   if ch==3
      e = e-d1(pend);
   else
      e = e-d(pend);
   end
   err = e*const;
   j = j+1;
end
M0 = j-1;
if ch==2
   m = -m; 
end
