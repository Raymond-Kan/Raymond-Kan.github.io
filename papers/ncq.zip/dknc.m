%
% This program computes \tilde{d}_k(A) for k=0,...,M
% using a super short recursive algorithm due to
% Brown (1986).
% a: unique eigenvalues of A
% delta: noncentrality parameter of the chi^2 random variables 
% n: multiplicities of a (default is a vector of ones)
%
function y = dknc(M,a,delta,n)
if M==0
   y = 1;
   return
end
y = ones(M+1,1);
q = zeros(size(a));
h = q;
if nargin<4
   for i=1:M
       q = a.*(y(i)+q);
       h = delta.*q+a.*h;
       y(i+1) = sum(q+h)/(2*i);
   end
else
   for i=1:M
       q = a.*(y(i)+q);
       h = delta.*q+a.*h;
       y(i+1) = sum(q.*n+h)/(2*i);
   end
end
