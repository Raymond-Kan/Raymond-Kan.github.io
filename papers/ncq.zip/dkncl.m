%
% This program computes \tilde{d}_k(A) for k=0,...,M
% using the long recursive algorithm.
% a: unique eigenvalues of A
% delta: noncentrality parameter of the chi^2 random variables 
% n: multiplicities of a (default is a vector of ones)
%
function y = dkncl(M,a,delta,n)
if M==0
   y = 1;
   return
end
y = ones(M+1,1);
t = zeros(M,1);
if nargin<4
   n = ones(size(a));
end
for i=1:M
    n = n.*a;
    delta = delta.*a;
    t(i) = sum(n)+i*sum(delta);
    y(i+1) = (y(i:-1:1)'*t(1:i))/(2*i);
end
