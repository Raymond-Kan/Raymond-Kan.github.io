%
% This Matlab function computes \tilde{d}_k(A) for k=0,...,M
% using the short recursive algorithm,
% a: unique eigenvalues of A
% delta: noncentrality parameter of the chi^2 random variables 
% n: multiplicities of a (default is a vector of ones)
%
function y = dkncs(M,a,delta,n)
y = ones(M+1,1);
nzd = find(delta>0);
s = length(a)+length(nzd);
L = min(M,s);
if nargin<4
   n = ones(size(a));
end
t = zeros(L,1);
if M==L
   for i=1:M
       n = n.*a;
       delta = delta.*a;
       t(i) = sum(n)+i*sum(delta);
       y(i+1) = (y(i:-1:1)'*t(1:i))/(2*i);
   end
   return
end
%
%   We flip p for programming convenience
%
p = conv(poly(a),poly(a(nzd)));
p = fliplr(p(2:L+1));
c = zeros(1,L);
for i=1:L
    n = n.*a;
    delta = delta.*a;
    t(i) = sum(n)+i*sum(delta);
    c(L+1-i) = i*p(L+1-i)+(t(i)+p(L+2-i:end)*t(1:i-1))/2;
%
%   For the first L elements of dk, can use either Ruben's
%   recursive relation or ours.
%   Ruben: y(i+1) = (y(i:-1:1)'*t(1:i))/(2*i);
%   Ours:  y(i+1) = (c(L-i+1:end)./i-p(L-i+1:end))*y(1:i);
%
    y(i+1) = (y(i:-1:1)'*t(1:i))/(2*i);
end
for i=L+1:M
    y(i+1) = (c/i-p)*y(i-s+1:i);
end
