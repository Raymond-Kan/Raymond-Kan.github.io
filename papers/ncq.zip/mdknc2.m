%
% This program computes tilde{d}_{i,j}(A,B) for 0<=i<=k1 and
% 0<=j<=k2 using a super-short recursion algorithm.
%
function d = mdknc2(A,B,mu,k1,k2)
n = size(A,1);
%
%   Quick return for n=1, k1=0 or k2=0
%
if n==1
   d = zeros(k1+1,k2+1);
   d(1,1) = 1;
   M = k1+k2;
   q = zeros(1,M);
   mu2 = mu^2;
   q(1) = 1+mu2;
   q(2) = mu2^2+6*mu2+3;
   for i=3:M
       q(i) = (mu2-3+4*i)*q(i-1)-(2*i-2)*(2*i-3)*q(i-2);
   end
   A = A/2;
   B = B/2;
   d(1,2:k2+1) = cumprod(B*ones(1,k2)./[1:k2]);
   for i=1:k1
       d(i+1,:) = (A/i)*d(i,:);
   end
   d(1,2:k2+1) = d(1,2:k2+1).*q(1:k2);
   for i=1:k1
       d(i+1,:) = d(i+1,:).*q(i:i+k2);
   end
   return
end
if k2==0
   [P,D] = eig(0.5*(A+A'));
   mu = P'*mu;
   d = dknc(k1,diag(D),mu.*mu);
   return
end
if k1==0
   [P,D] = eig(0.5*(B+B'));
   mu = P'*mu;
   d = dknc(k2,diag(D),mu.*mu)';
   return
end
%
%   Cases when n>1, k1>0, and k2>0
%   Switch k1 and k2 if k1<k2.
%
if k1<k2
   swap = 1;
   C = A;
   A = B;
   B = C;
   k3 = k1;
   k1 = k2;
   k2 = k3;
else
   swap = 0;
end
d = zeros(k1+1,k2+1);
d(1,1) = 1;
G = zeros(n,n,k2+1);
h = zeros(n,k2+1);
%
%  row 0
%
for j=1:k2
    G1 = B*d(1,j)+B*G(:,:,j);
    h(:,j+1) = G1*mu+B*h(:,j);
    d(1,j+1) = (trace(G1)+mu'*h(:,j+1))/(2*j);
    G(:,:,j+1) = G1;
end
%
%  row 1 to row k1-1
%
for i=1:k1-1
    G1 = A*d(i,1)+A*G(:,:,1);
    h(:,1) = G1*mu+A*h(:,1);
    d(i+1,1) = (trace(G1)+mu'*h(:,1))/(2*i);
    G(:,:,1) = G1;
    for j=1:k2
        G1 = A*d(i,j+1)+B*d(i+1,j)+A*G(:,:,j+1)+B*G1;
        h(:,j+1) = G1*mu+A*h(:,j+1)+B*h(:,j);
        d(i+1,j+1) = (trace(G1)+mu'*h(:,j+1))/(2*(i+j));
        G(:,:,j+1) = G1;
    end
end
%
%   last row, no need to update G and h
%
G1 = A*d(k1,1)+A*G(:,:,1);
h1 = G1*mu+A*h(:,1);
d(k1+1,1) = (trace(G1)+mu'*h1)/(2*k1);
for j=1:k2
    G1 = A*d(k1,j+1)+B*d(k1+1,j)+A*G(:,:,j+1)+B*G1;
    h1 = G1*mu+A*h(:,j+1)+B*h1;
    d(k1+1,j+1) = (trace(G1)+mu'*h1)/(2*(k1+j));
end
if swap
   d = d';
end
