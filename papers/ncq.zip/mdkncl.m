%
% This program computes the top order invariant polynomials
% \tilde{d}_{k1,k2,...,kr}(A1,A2,...,Ar) using the long recursive
% algorithm.  All input matrices are symmetric matrices.
%
function d = mdkncl(A,mu,k)
index = find(k>0);
A = A(:,:,index);
k = k(index);
r = length(k);
%
%   Quick return if r=0 or 1 or n=1
%
if r==0
   d = 1;
   return
end
if r==1
   d = dkncl(k,eig(A),mu.*mu);
   return
end
s = k+1;
cs = [1; cumprod(s(1:r-1))'];
nind = cs(r)*s(r);
sk = cumsum(k);
M = sk(r);
n = size(A,1);
if n==1
   d = zeros(nind,1);
   q = zeros(1,M);
   mu2 = mu^2;
   q(1) = 1+mu2;
   q(2) = mu2^2+6*mu2+3;
   for i=3:M
       q(i) = (mu2-3+4*i)*q(i-1)-(2*i-2)*(2*i-3)*q(i-2);
   end
   fac = cumprod([1:max(k)]);
   x = zeros(1,r);
   sx = 0;    % sx = sum(x), it is updated instead of computed every time.
   c = 1;
   A = A/2;
   a = fac(k)./A(:)'.^k;
   d(1) = 1;
   for i=2:nind
       for ii=1:r
           if x(ii)==k(ii)
              x(ii) = 0;
              sx = sx-k(ii);
              c = c*a(ii);
           else
              x(ii) = x(ii)+1;
              sx = sx+1;
              c = c*A(ii)/x(ii);
              break
           end
       end
       d(i) = c*q(sx);
    end
    return
end
%
%   F(i,j) is a matrix of the number of elements of nu's such 
%   that 0<=|nu|<=i and nu<=k(1:j)
%
F = zeros(M,r);
F(1,:) = 1;
F(2:k(1),1) = 2:k(1);
F(s(1):M) = s(1);
for j=2:r
    for i=1:k(j)
        F(i+1,j) = F(i+1,j-1)+F(i,j);
    end
    for i=k(j)+1:M-1
        F(i+1,j) = F(i+1,j-1)+F(i,j)-F(i-k(j),j-1);
    end
end
pind = zeros(1,nind);
pind(1) = 1;
pind(2) = cs(r)+1;
index = zeros(F(end),r);   % F(end) = nind-1
index(1,:) = r:-1:1;
S = [zeros(1,r-1) 1];  % Can set first S to this because k_r>0
% Loop through all possible nu's with |nu|<=2n and nu<=k
for i=2:F(M,r)
    df = i-F(S(r),r);  % Position of S in its own block
    for ss=r-1:-1:1    % Going backward by setting index(i,r) first
        b = S(ss+1)-k(ss+1);
        if b>0
           df = df+F(b,ss)-F(b+1,ss);
        elseif b==0
           df = df-1;
        end
        if b<S(ss)   % Check constraint for the 2nd to last element
           index(i,ss+1) = df;
        end
        df = df+F(S(ss)+1,ss);
        if S(ss)>0
           df = df-F(S(ss),ss);
        end 
    end               
    if S(1)<k(1)  % Check constraint for the first element
       index(i,1) = df;
    end
% Create next S
    j = 1;
    while j<r&&(S(j)==S(j+1)||S(j)==sk(j))
       j = j+1;
    end  
    S(j) = S(j)+1;
    for ss=j:-1:2
        S(ss-1) = max(0,S(ss)-k(ss));
    end
    pind(i+1) = S(1)+diff(S)*cs(2:r)+1;
end
%
% Start computing p_nu's.
% When k=1, p(2:r+1) are trace of A_r to trace of A_1
%
p = zeros(1,nind);
for i=1:r
    p(i+1) = trace(A(:,:,r-i+1))+mu'*A(:,:,r-i+1)*mu;
end
F = F(:,r);
lk0 = diff(F);
lx0 = max(lk0);
x = zeros(n,lx0);
for i=1:n         % trace of a matrix is equal to the sum of the diagonal elements
    x0 = zeros(n,lx0);
    x0(:,1:r) = A(:,i,r:-1:1);
    for k1=2:M-1          % |nu|=k1
        x(:,1:lk0(k1-1)) = x0(:,1:lk0(k1-1));           % copy the old x0 to x
        x0(:) = 0;
        for j=1:r
            h = index(F(k1-1)+1:F(k1),j);
            lh = find(h>0);
            lh0 = h(lh);
            x0(:,lh0) = x0(:,lh0)+A(:,:,j)*x(:,lh);
        end
        p(F(k1)+1:F(k1+1)) = p(F(k1)+1:F(k1+1))+x0(i,1:lk0(k1));
    end
    for j=1:r   % For k1=M, there is only one element of p
        p(nind) = p(nind)+x0(:,j)'*A(:,i,j);
    end
end
%
% Start computing eta_nu's. eta_nu = mu'A_{nv}mu *|nu|
%
x = zeros(n,lx0);
x0 = zeros(n,lx0);
for i=1:r
    x0(:,i) = A(:,:,r-i+1)*mu;
end
for k1=2:M-1          % |nu|=k1
    x(:,1:lk0(k1-1)) = x0(:,1:lk0(k1-1));           % copy the old x0 to x
    x0(:) = 0;
    for j=1:r
        h = index(F(k1-1)+1:F(k1),j);
        lh = find(h>0);
        lh0 = h(lh);
        x0(:,lh0) = x0(:,lh0)+A(:,:,j)*x(:,lh);
    end
    p(F(k1)+1:F(k1+1)) = p(F(k1)+1:F(k1+1))+k1*(mu'*x0(:,1:lk0(k1)));
end
for j=1:r   % For k1=M, there is only one element of p
    p(nind) = p(nind)+M*(mu'*A(:,:,j)*x0(:,j));
end
p(pind) = p;   % rearrange p
%
% Compute d(i) using the long recursion
% x is the vector for k_i, y is the vector for nu_i
%
d = p;
d(1) = 1;
x = zeros(1,r);
sx = 0;    % sx = sum(x), it is updated instead of computed every time.
for i=2:nind
    for ii=1:r
        if x(ii)==k(ii)
           x(ii) = 0;
           sx = sx-k(ii);
        else
           x(ii) = x(ii)+1;
           sx = sx+1;
           break
        end
    end
    y = zeros(1,r);
    j = 1;
    px = prod(x+1)-2;
    for l=1:px
        for i1=ii:r
            if y(i1)==x(i1)
               y(i1) = 0;
               j = j-x(i1)*cs(i1);
            else
               y(i1) = y(i1)+1;
               j = j+cs(i1);
               d(i) = d(i)+d(j)*p(i-j+1);
               break
            end
        end
    end
    d(i) = d(i)/(2*sx);
end
