%
% This program computes \tilde{d}_{i,j}(A,B) for 0<=i<=k1 and
% 0<=j<=k2 using a different version of the long recursive 
% algorithm.
%
function d = mdkncl2a(A,B,mu,k1,k2)
n = size(A,1);
%
%   Quick return for n=1, k1=0 or k2=0
%
if n==1
   d = zeros(k1+1,k2+1);
   d(1,1) = 1;
   M = k1+k2;
   q = zeros(1,M);
   mu2 = mu^2;
   q(1) = 1+mu2;
   q(2) = mu2^2+6*mu2+3;
   for i=3:M
       q(i) = (mu2-3+4*i)*q(i-1)-(2*i-2)*(2*i-3)*q(i-2);
   end
   A = A/2;
   B = B/2;
   d(1,2:k2+1) = cumprod(B*ones(1,k2)./[1:k2]);
   for i=1:k1
       d(i+1,:) = (A/i)*d(i,:);
   end
   d(1,2:k2+1) = d(1,2:k2+1).*q(1:k2);
   for i=1:k1
       d(i+1,:) = d(i+1,:).*q(i:i+k2);
   end
   return
end
A = 0.5*(A+A');
if k2==0
   [P,D] = eig(A);
   mu = P'*mu;
   d = dkncl(k1,diag(D),mu.*mu);
   return
end
[P,D] = eig(0.5*(B+B'));
b = diag(D);
mu = P'*mu;
if k1==0
   d = dkncl(k2,b,mu.*mu)';
   return
end
%
%   Cases when n>1, k1>0, and k2>0
%
A = P'*A*P;
bmu = b.*mu;
Amu = A*mu;
p = zeros(k1+1,k2+1);
p(2,1) = trace(A)+mu'*Amu;
p(1,2) = sum(b)+mu'*bmu;
%
%   Compute p_{ij}
%
x = zeros(n,k2+1);
for i=1:n
    x(:,1:2) = [A(:,i) zeros(n,1)];
    x(i,2) = b(i);
    for j=2:k1+k2-1
        if j<=k2
           x(:,j+1) = b.*x(:,j);
        end
        for k=min(j,k2+1):-1:max(2,j-k1+1)
            x(:,k) = A*x(:,k)+b.*x(:,k-1);
        end
        if j<=k1
           x(:,1) = A*x(:,1);
        end
        for k=max(0,j-k1):min(j,k2)
            p(j-k+1,k+1) = p(j-k+1,k+1)+x(i,k+1);
        end
    end
    %
    %   Treat the last one differently as there is no need to carry
    %   the matrix x any further.
    %
    p(k1+1,k2+1) = p(k1+1,k2+1)+A(i,:)*x(:,k2+1)+b(i)*x(i,k2);
end
%
%   Compute eta_{ij}
%
x(:,1:2) = [Amu bmu];
for j=2:k1+k2-1
    if j<=k2
       x(:,j+1) = b.*x(:,j);
    end
    for k=min(j,k2+1):-1:max(2,j-k1+1)
        x(:,k) = A*x(:,k)+b.*x(:,k-1);
    end
    if j<=k1
       x(:,1) = A*x(:,1);
    end
    for k=max(0,j-k1):min(j,k2)
        p(j-k+1,k+1) = p(j-k+1,k+1)/j+mu'*x(:,k+1);
    end
end
p(k1+1,k2+1) = p(k1+1,k2+1)/(k1+k2)+Amu'*x(:,k2+1)+bmu'*x(:,k2);
%
%   Start the recursion of d's
%
d = zeros(k1+1,k2+1);
d(1,1) = 1;
for i=1:k1
    d(i+1,1) = [1:i]*(p(2:i+1,1).*d(i:-1:1,1))/(2*i);
end
for i=1:k2
    d(1,i+1) = (p(1,2:i+1).*d(1,i:-1:1))*[1:i]'/(2*i);
end
for i=1:k1
    for j=1:min(i,k2)
        d(i+1,j+1) = (sum(d(i+1:-1:1,j:-1:1).*p(1:i+1,2:j+1))*[1:j]')/(2*j);
    end
    for j=i+1:k2;
        d(i+1,j+1) = ([1:i]*sum(d(i:-1:1,j+1:-1:1).*p(2:i+1,1:j+1),2))/(2*i);
    end    
end
