%
% This program computes the top order invariant polynomials
% \tilde{d}_{k1,k2,...,kr}(A1,A2,...,Ar) using the short recursive
% algorithm.  All input matrices are symmetric matrices.
%
function d = mdkncs(A,mu,k)
index = find(k>0);
A = A(:,:,index);
k = k(index);
r = length(k);
%
%   Quick return if r=0 or 1 or n=1
%
if r==0
   d = 1;
   return
end
if r==1
   d = dkncs(k,eig(A),mu.*mu);
   return
end
n = size(A,1);
s = k+1;
cs = [1; cumprod(s(1:r-1))'];
nind = cs(r)*s(r);
d = zeros(nind,1);
d(1) = 1;
if n==1
   q = zeros(1,sum(k));
   mu2 = mu^2;
   q(1) = 1+mu2;
   q(2) = mu2^2+6*mu2+3;
   for i=3:M
       q(i) = (mu2-3+4*i)*q(i-1)-(2*i-2)*(2*i-3)*q(i-2);
   end
   fac = cumprod([1:max(k)]);
   x = zeros(1,r);
   sx = 0;    % sx = sum(x), it is updated instead of computed every time.
   c = 1;
   A = A/2;
   a = fac(k)./A(:)'.^k;
   for i=2:nind
       for ii=1:r
           if x(ii)==k(ii)
              x(ii) = 0;
              sx = sx-k(ii);
              c = c*a(ii);
           else
              x(ii) = x(ii)+1;
              sx = sx+1;
              c = c*A(ii)/x(ii);
              break
           end
       end
       d(i) = c*q(sx);
   end
   return
end
%
%   F(i,j) is a matrix of the number of elements of nu's such
%   that 0<=|nu|<=i and nu<=k(1:j)
%
n2 = 2*n;
kappa = min(k,n2);
sk = cumsum(kappa);
M = min(sk(r),n2);
F = zeros(M+1,r);
F(1,:) = 1;
F(2:kappa(1),1) = 2:kappa(1);
F(kappa(1)+1:M+1,1) = kappa(1)+1;
for j=2:r
    for i=1:kappa(j)
        F(i+1,j) = F(i+1,j-1)+F(i,j);
    end
    for i=kappa(j)+1:M
        F(i+1,j) = F(i+1,j-1)+F(i,j)-F(i-kappa(j),j-1);
    end
end
%
%   Compute the index for the updating from one block to the
%   next block.
%
l = F(end);
pind = zeros(1,l);
pind(1) = 1;
pind(2) = cs(r)+1;
index = zeros(l,r);
index(1,:) = r:-1:1;
S = [zeros(1,r-1) 1];  % Can set first S to this because kappa_r>0
% Loop through all possible nu's with |nu|<=2n and nu<=kappa
for i=2:F(M,r)
    ind = i-F(S(r),r);  % Position of S in its own block
    for j=r-1:-1:1    % Going backward by setting index(i,r) first
        b = S(j+1)-kappa(j+1);
        if b>0
           ind = ind+F(b,j)-F(b+1,j);
        elseif b==0
           ind = ind-1;
        end
        if b<S(j)   % Check constraint for the 2nd to last element
           index(i,j+1) = ind;
        end
        ind = ind+F(S(j)+1,j);
        if S(j)>0
           ind = ind-F(S(j),j);
        end
    end
    if S(1)<kappa(1)  % Check constraint for the first element
       index(i,1) = ind;
    end
    % Create next S
    j = 1;
    while j<r&&(S(j)==S(j+1)||S(j)==sk(j))
       j = j+1;
    end
    S(j) = S(j)+1;
    for i1=j:-1:2
        S(i1-1) = max(0,S(i1)-kappa(i1));
    end
    pind(i+1) = S(1)+diff(S)*cs(2:r)+1;
end
for i=F(M,r)+1:l-1
    j = 1;
    while j<r&&(S(j)==S(j+1)||S(j)==sk(j))
       j = j+1;
    end  
    S(j) = S(j)+1;
    for i1=j:-1:2
        S(i1-1) = max(0,S(i1)-kappa(i1));
    end
    pind(i+1) = S(1)+diff(S)*cs(2:r)+1;
end
%
% Start computing p_nu's.
% When k=1, p(2:r+1) are trace of A_r to trace of A_1
%
p = zeros(l,1);
for i=1:r
    p(i+1) = trace(A(:,:,r-i+1));
end
F = F(:,r);
lk0 = diff(F(1:end-1));
lx0 = max(lk0);
x = zeros(n,lx0);
for i=1:n         % trace of a matrix is equal to the sum of the diagonal elements
    x0 = zeros(n,lx0);
    x0(:,1:r) = A(:,i,r:-1:1);
    for k1=2:M-1          % |nu|=k1
        x(:,1:lk0(k1-1)) = x0(:,1:lk0(k1-1));           % copy the old x0 to x
        x0(:) = 0;
        for j=1:r
            h = index(F(k1-1)+1:F(k1),j);
            lh = find(h>0);
            lh0 = h(lh);
            x0(:,lh0) = x0(:,lh0)+A(:,:,j)*x(:,lh);
        end
        p(F(k1)+1:F(k1+1)) = p(F(k1)+1:F(k1+1))+x0(i,1:lk0(k1))';
    end
    %
    %   Separately for k1=M as there is no need to update x0 anymore
    %
    for j=1:r
        h = index(F(M-1)+1:F(M),j);
        lh = find(h>0);
        lh0 = h(lh);
        p(F(M)+lh0) = p(F(M)+lh0)+x0(:,lh)'*A(:,i,j);
    end
end
%
%     Compute y = |\nu|\eta_\nu
%
y = zeros(1,l);
Amu = zeros(n,r);
for i=1:r
    Amu(:,i) = A(:,:,i)*mu;
end
for i=1:r
    y(i+1) = mu'*Amu(:,r-i+1);
end
x = zeros(n,lx0);
x0 = zeros(n,lx0);
x0(:,1:r) = Amu(:,r:-1:1);
for k1=2:M-1          % |nu|=k1
    x(:,1:lk0(k1-1)) = x0(:,1:lk0(k1-1));           % copy the old x0 to x
    x0(:) = 0;
    for j=1:r
        h = index(F(k1-1)+1:F(k1),j);
        lh = find(h>0);
        lh0 = h(lh);
        x0(:,lh0) = x0(:,lh0)+A(:,:,j)*x(:,lh);
    end
    y(F(k1)+1:F(k1+1)) = k1*mu'*x0(:,1:lk0(k1));
end
%
%   Separately for k1=M as there is no need to update x0 anymore
%
for j=1:r
    h = index(F(M-1)+1:F(M),j);
    lh = find(h>0);
    lh0 = h(lh);
    y(F(M)+lh0) = y(F(M)+lh0)+M*Amu(:,j)'*x0(:,lh);
end
%
%   Use multivariate Newton-Girard formula to obtain the
%   e coefficients.  The dimension of e is prod(kappa+1).
%   The elements of e corresponding to |nu|>M
%   are equal to zero.  Although this is
%   not the most efficient way of storing e,
%   it can make the computation more efficient.
%
p1 = zeros(1,nind);
p1(pind) = p;
y1 = zeros(1,nind);
y1(pind) = y;
sx = zeros(1,nind);
sx(pind) = 1;
e = zeros(1,nind);
c = zeros(1,nind);
e(1) = 1;
c(1) = 0.75;
x = zeros(1,r);
sx0 = 0;
for i=2:nind
    for ii=1:r
        if x(ii)==k(ii)
           x(ii) = 0;
           sx0 = sx0-k(ii);
        else
           x(ii) = x(ii)+1;
           sx0 = sx0+1;
           break
        end
    end
    y = zeros(1,r);
    j = 1;
    x1 = min(x,n2);
    cx = cumprod(x1+1);
    count = cx(end)-1;
    if sx0<=n2    % Needs to compute e, c, and d
       for i1=2:count
           for i2=ii:r
               if y(i2)==x1(i2)
                  j = j-y(i2)*cs(i2);
                  y(i2) = 0;
               else
                  y(i2) = y(i2)+1;
                  j = j+cs(i2);
                  e(i) = e(i)-p1(i-j+1)*e(j);
                  c(i) = c(i)+y1(i-j+1)*e(j);
                  d(i) = d(i)+(p1(i-j+1)+y1(i-j+1))*d(j);
                  break
               end
           end
       end
       e(i) = 2*(e(i)-p1(i))/sx0;
       if sx0==n2
          c(i) = 0.75*e(i)*sx0;
       else
          c(i) = 0.5*(c(i)+y1(i))+0.75*e(i)*sx0;
       end
       d(i) = (d(i)+p1(i)+y1(i))/(2*sx0);
    else      % Only computes d
       if all(x>=kappa)     % can work with the entire list of e's
          for i1=2:l
              j = pind(i1);
              d(i) = d(i)+d(i-j+1)*(c(j)/sx0-e(j));
          end
       else
          i1 = 0;
          while i1<count
             for i2=ii:r
                 if y(i2)~=x1(i2)
                    y(i2) = y(i2)+1;
                    j = j+cs(i2);
                    if sx(j)==1
                       d(i) = d(i)+d(i-j+1)*(c(j)/sx0-e(j));
                       i1 = i1+1;
                       break
                    end
                    if i2==ii
                       i1 = i1+x1(ii)-y(ii)+1;
                    else
                       i1 = i1+cx(i2)-cx(i2-1)*y(i2);
                    end
                    if i1==count
                       break
                    end
                 end
                 j = j-y(i2)*cs(i2);
                 y(i2) = 0;
             end
          end
       end
    end
end
