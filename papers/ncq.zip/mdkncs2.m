%
% This program computes \tilde{d}_{i,j}(A,B) for 0<=i<=k1 and
% 0<=j<=k2 using the short recursive algorithm.
%
function d = mdkncs2(A,B,mu,k1,k2)
n = size(A,1);
%
%   Quick return for n=1, k1=0 or k2=0
%
if n==1
   d = zeros(k1+1,k2+1);
   d(1,1) = 1;
   M = k1+k2;
   q = zeros(1,M);
   mu2 = mu^2;
   q(1) = 1+mu2;
   q(2) = mu2^2+6*mu2+3;
   for i=3:M
       q(i) = (mu2-3+4*i)*q(i-1)-(2*i-2)*(2*i-3)*q(i-2);
   end
   A = A/2;
   B = B/2;
   d(1,2:k2+1) = cumprod(B*ones(1,k2)./[1:k2]);
   for i=1:k1
       d(i+1,:) = (A/i)*d(i,:);
   end
   d(1,2:k2+1) = d(1,2:k2+1).*q(1:k2);
   for i=1:k1
       d(i+1,:) = d(i+1,:).*q(i:i+k2);
   end
   return
end
A = 0.5*(A+A');
if k2==0
   [P,D] = eig(A);
   mu = P'*mu;
   d = dkncs(k1,diag(D),mu.*mu);
   return
end
[P,D] = eig(0.5*(B+B'));
b = diag(D);
mu = P'*mu;
if k1==0
   d = dkncs(k2,b,mu.*mu)';
   return
end
%
%   Cases when k1>0, and k2>0
%
n2 = 2*n;
i1 = min(n2,k1)+1;
j1 = min(n2,k2)+1;
k3 = min(n2,k1+k2);
k4 = min(n2,k2+1);
p = zeros(i1,j1);
p(2,1) = trace(A);
p(1,2) = sum(b);
A = P'*A*P;
%
%   Compute p_{ij}
%
x = zeros(n,k4);
for i=1:n
    x(:,1:2) = [A(:,i) zeros(n,1)];
    x(i,2) = b(i);
    for j=2:k3-1
        if j<=k2
           x(:,j+1) = b.*x(:,j);
        end
        for k=min(j,k4):-1:max(2,j-i1+2)
            x(:,k) = A*x(:,k)+b.*x(:,k-1);
        end
        if j<i1
           x(:,1) = A*x(:,1);
        end
        for k=max(0,j+1-i1):min(j,k2)
            p(j-k+1,k+1) = p(j-k+1,k+1)+x(i,k+1);
        end
    end
    %
    %   Treat the last one differently as there is no need to carry
    %   the matrix x any further.
    %
    if k1>=n2
       p(n2+1,1) = p(n2+1,1)+A(i,:)*x(:,1);
    end
    if k2>=n2
       p(1,n2+1) = p(1,n2+1)+b(i)*x(i,n2);
    end
    for j=max(1,k3-k1):k4-1
        p(k3-j+1,j+1) = p(k3-j+1,j+1)+A(i,:)*x(:,j+1)+b(i)*x(i,j);
    end
end
%
%     Use multivariate Newton-Girard formula to
%     compute e_{i,j} from p_{i,j}
%
e = zeros(i1,j1);
e(1,1) = 1;
v = e;
for i=1:i1
    for j=1+(i==1):min(j1,n2+2-i)
        v(i,j) = -2*sum(sum(e(1:i,1:j).*p(i:-1:1,j:-1:1)));
        e(i,j) = v(i,j)/(i+j-2);
    end
end
%
%   Compute (i+j)\eta_{ij}
%
bmu = b.*mu;
Amu = A*mu;
h = zeros(i1,j1);
h(2,1) = mu'*Amu;
h(1,2) = mu'*bmu;
x(:,1:2) = [Amu bmu];
ii1 = min(n2,k1+1);       % we only need \eta up to |\nu|=2n-1
jj1 = min(n2,k2+1);
kk3 = min(n2-1,k1+k2);
kk4 = min(n2-1,k2+1);
for j=2:kk3-1        
    if j<=k2
        x(:,j+1) = b.*x(:,j);
    end
    for k=min(j,kk4):-1:max(2,j-ii1+2)
        x(:,k) = A*x(:,k)+b.*x(:,k-1);
    end
    if j<ii1
        x(:,1) = A*x(:,1);
    end
    for k=max(0,j+1-ii1):min(j,k2)
        h(j-k+1,k+1) = j*(mu'*x(:,k+1));
    end
end
%
%   Treat the last one differently as there is no need to carry
%   the matrix x any further.
%
if k1>=n2-1&&n~=1        % when n=1, we may have 2n-1=1, no need to calculate h(2,1) again.
   h(n2,1) = (n2-1)*(Amu'*x(:,1));
end
if k2>=n2-1&&n~=1
   h(1,n2) = (n2-1)*(bmu'*x(:,n2-1));
end
for j=max(1,kk3-k1):kk4-1
    h(kk3-j+1,j+1) = kk3*(Amu'*x(:,j+1)+bmu'*x(:,j));
end
%
%   Compute v_{ij}, using \eta and e
%
v = 0.75*v;
for i=1:ii1
    for j=1+(i==1):min(jj1,n2+1-i)
        v(i,j) = v(i,j)+0.5*sum(sum(e(1:i,1:j).*h(i:-1:1,j:-1:1)));
    end
end
%
%   Start the recursion of d's
%
p = p+h;
d = zeros(k1+1,k2+1);
d(1,1) = 1;
for i=1:k1+1
    i1 = min(i,n2+1);
    for j=1+(i==1):k2+1
        sij = i+j-2;
        j1 = min(j,n2+1);
        for i2=1:i1
            for j2=1:min(j1,n2+2-i2)
                if sij==n2
                   d(i,j) = d(i,j)+(v(i2,j2)-e(i2,j2)*sij)*d(i-i2+1,j-j2+1);
                else
                   d(i,j) = d(i,j)+0.5*p(i2,j2)*d(i-i2+1,j-j2+1);
                end
            end
        end
        d(i,j) = d(i,j)/sij;
    end
end
