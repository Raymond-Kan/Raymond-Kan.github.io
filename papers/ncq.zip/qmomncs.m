%
% qmomncs.m   Date: 2008/03/15
% This program computes E[(z'A'z)^p/(z'Bz)^q] when z ~ N(mu,I)
% using an identity that involves h_{p,j}.
% B is assumed to be positive definite.
% This program uses the short recursive algorithm and calls an external
% Fortran program that computes the answer using quadruple precision.
% Input: 
% A, B: matrix of the quadratic forms in the numerator and the denominator
% mu: mean of z
% p, q: power of the quadratic forms in the numerator and the denominator,
%       both are assumed to be integers
% E: precision, default is 1e-10
% M: maximum number of terms, default is 1000
% Output:
% m: E[(z'Az)^p/(z'Bz)^q] 
% err: upper bound of the approximation errors in m
% M0: number of terms to reach the desired level of precision
%
function [m,err,M0] = qmomncs(A,B,mu,p,q,E,M)
n = size(A,1);
M0 = 0;
err = 0;
if n/2+p<=q
   m = NaN;
   return
end
if q==0
   [P,D] = eig(A);
   delta = (P'*mu).^2;
   d = dkncs(p,diag(D),delta);
   m = prod([2:2:2*p])*d(end);
   return
end
%
% Set max number of terms and tolerance level
%
if nargin<6
   E = 1e-10; 
end
if nargin<7
   M = 1000;
end
[P,B] = eig(B);
b = diag(B);
if any(b<=0)
   m = NaN;
   fprintf('B matrix must be positive definite!\n')
   return
end
[m,err,M0] = qmomncsf(P'*A*P,b,P'*mu,p,q,E,M);
