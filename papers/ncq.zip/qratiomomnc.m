%
% qratiomomnc.m   Date: 2012/01/12
% This program computes E[(z'A'z)^p/(z'Bz)^q] when z ~ N(mu,I)
% using an identity that involves h_{p,j}.
% B is assumed to be positive definite.
% This program uses a super-short recursive algorithm.
% Input: 
% A, B: matrix of the quadratic forms in the numerator and the denominator
% mu: mean of z
% p, q: power of the quadratic forms in the numerator and the denominator,
%       both are assumed to be integers
% E: precision, default is 1e-10
% M: maximum number of terms, default is 1000
% Output:
% m: E[(z'Az)^p/(z'Bz)^q] 
% err: upper bound of the approximation errors in m
% M0: number of terms to reach the desired level of precision
%
function [m,err,M0] = qratiomomnc(A,B,mu,p,q,E,M)
pend = p+1;
M0 = zeros(pend,q+1);
err = M0;
if q==0   
   [P,D] = eig(A);
   delta = (P'*mu).^2;
   m = cumprod([1 2:2:2*p]').*dknc(p,diag(D),delta);
   return
end
n = size(A,1);
m = NaN(pend,q+1);
m(1) = 1; 
%
%   Normalization of A and B such that
%   their largest eigenvalue is 1.
%
[P,B] = eig(B);
b = diag(B);
if any(b<=0)
   fprintf('B matrix must be positive definite!\n')
   return
end
delta = mu'*mu;
mu = P'*mu;
A = P'*A*P;
ea = eig(A);
maxea = max(abs(ea));
A = A./maxea;
ch = 1;
if all(ea<=0)    % when A is negative semi-definite
   ch = 2;
   A = -A;
elseif max(ea)*min(ea)<0&&p>0
   ch = 3;
   pend1 = pend-rem(pend,2);
end
maxeb = max(b);
b = b./maxeb;
eb = 1-b;   % nonzero eigenvalues of I_n-B
%
% Set max times of iteration and tolerance level
%
if nargin<6
   E = 1e-10;
end
if nargin<7
   M = 1000;
end
G = zeros(n,n,pend);
h = zeros(n,pend);
n2 = n/2;
if ch==3
   [P,D] = eig(A);
   At = P*abs(D)*P';
   Gb = zeros(n,n,pend1);
   hb = zeros(n,pend1);
end
D = eb*ones(1,n);
ebd = diag(eb);
%
% generate \tilde{d}_p(tilde{A}) for error bound 
%
mu1 = sqrt(2)*mu./sqrt(b);
[Q1,D1] = eig(A./sqrt(b*b'));
delta1 = (Q1'*mu1).^2;
e = dknc(p,diag(D1),delta1);
if ch==3
   [Q1,D1] = eig(At./sqrt(b*b'));
   delta1 = (Q1'*mu1).^2;
   e1 = dknc(pend1-1,diag(D1),delta1);
   e(2:2:pend1) = e1(2:2:pend1);
end
e = (exp((mu1'*mu1)/2-delta/2)/sqrt(prod(b)))*e;
%
% generate d's and m's
%
d = zeros(pend,1);
d(1) = 1;
d1 = d;
if ch==3
   d2 = zeros(pend1,1);
   d2(1) = 1;
end
%
% when j==0
%
const = ones(pend,q);
x2 = 1;
e(1) = e(1)-1;
for i=1:min(q,fix(n2-1/2))     % for p=0
    x2 = x2/((n-2*i)*maxeb);
    const(1,i) = x2*i/n2;
    err(1,i+1) = e(1)*const(1,i);
    m(1,i+1) = x2;
end
x0 = 1;
for i=1:p             % for p>0
    G1 = A*d(i)+A*G(:,:,i);
    h(:,i+1) = G1*mu+A*h(:,i);
    d(i+1) = (trace(G1)+mu'*h(:,i+1))/(2*i);
    G(:,:,i+1) = G1;
    x0 = 2*maxea*x0*i;
    x2 = x0;
    m(i+1,1) = x2*d(i+1);
    if ch==3&&i<pend1
       G1 = At*d2(i)+At*Gb(:,:,i);
       hb(:,i+1) = G1*mu+At*hb(:,i);
       d2(i+1) = (trace(G1)+mu'*hb(:,i+1))/(2*i);
       Gb(:,:,i+1) = G1;
    end
    if ch==3&&rem(i,2)==1
       e(i+1) = e(i+1)-d2(i+1);
    else
       e(i+1) = e(i+1)-d(i+1);
    end
    for j=1:min(q,fix(n2+i-1/2))
        x2 = x2/((n+2*(i-j))*maxeb);
        const(i+1,j) = x2*j/(n2+i);
        m(i+1,j+1) = x2*d(i+1);
        err(i+1,j+1) = e(i+1)*const(i+1,j);
    end
end
d1 = d;
Ga = G;
ha = h;
%
% when j>0
%
j = 1;
while any(any(err>E))&&j<=M
   G1 = ebd*d(1)+D.*G(:,:,1);
   h(:,1) = (G1-G(:,:,1))*mu-d(1)*mu+eb.*h(:,1);
   d(1) = (trace(G1)+mu'*h(:,1))/(2*j);
   G(:,:,1) = G1;
   G1a = ebd*d1(1)+D.*Ga(:,:,1);
   ha(:,1) = (G1a+Ga(:,:,1))*mu+d1(1)*mu+eb.*ha(:,1);
   d1(1) = (trace(G1a)+mu'*ha(:,1))/(2*j);
   Ga(:,:,1) = G1a;
   if ch==3
      G1b = G1a;
      d2(1) = d1(1);
      Gb(:,:,1) = G1b;
      hb(:,1) = ha(:,1);
   end
   for i=1:pend-1
       G1 = A*d(i)+ebd*d(i+1)+A*G1+D.*G(:,:,i+1);
       h(:,i+1) = (G1-G(:,:,i+1))*mu-d(i+1)*mu+A*h(:,i)+eb.*h(:,i+1);
       d(i+1) = (trace(G1)+mu'*h(:,i+1))/(2*(i+j));
       G(:,:,i+1) = G1;
       G1a = A*d1(i)+ebd*d1(i+1)+A*G1a+D.*Ga(:,:,i+1);
       ha(:,i+1) = (G1a+Ga(:,:,i+1))*mu+d1(i+1)*mu+A*ha(:,i)+eb.*ha(:,i+1);
       d1(i+1) = (trace(G1a)+mu'*ha(:,i+1))/(2*(i+j));
       Ga(:,:,i+1) = G1a;
   end
   if ch==3
      for i=1:pend1-1
          G1b = At*d2(i)+ebd*d2(i+1)+At*G1b+D.*Gb(:,:,i+1);
          hb(:,i+1) = (G1b+Gb(:,:,i+1))*mu+d2(i+1)*mu+At*hb(:,i)+eb.*hb(:,i+1);
          d2(i+1) = (trace(G1b)+mu'*hb(:,i+1))/(2*(i+j));
          Gb(:,:,i+1) = G1b;
       end
   end
   for i=1:pend
       if ch==3&&rem(i,2)==0
          e(i) = e(i)-d2(i);
       else
          e(i) = e(i)-d1(i);
       end
       for q1=2:min(q+1,fix(n2+i-1/2))
           if err(i,q1)>E
              m(i,q1) = m(i,q1)+const(i,q1-1)*d(i);
              const(i,q1-1) = const(i,q1-1)*(q1+j-1)/(n2+i+j-1);
              M0(i,q1) = M0(i,q1)+1;
              err(i,q1) = e(i)*const(i,q1-1);
           end
       end
   end
   if all(err(pend,:)<E)
      if ch==3&&pend==pend1
         pend1 = pend1-2;
      end
      pend = pend-1;
   end   
   j = j+1;
end
if ch==2
   m(2:2:end,:) = -m(2:2:end,:); 
end
