%
% qratiomomncl.m   Date: 2008/03/15
% This program computes E[(z'A'z)^p/(z'Bz)^q] when z ~ N(mu,I)
% using an identity that involves h_{p,j}.
% B is assumed to be positive definite.
% This program uses the long recursive algorithm.
% Input: 
% A, B: matrix of the quadratic forms in the numerator and the denominator
% mu: mean of z
% p, q: power of the quadratic forms in the numerator and the denominator,
%       both are assumed to be integers
% E: precision, default is 1e-10
% M: maximum number of terms, default is 1000
% Output:
% m: E[(z'Az)^p/(z'Bz)^q] 
% err: upper bound of the approximation errors in m
% M0: number of terms to reach the desired level of precision
%
function [m,err,M0] = qratiomomncl(A,B,mu,p,q,E,M)
pend = p+1;
M0 = zeros(pend,q+1);
err = M0;
if q==0   
   [P,D] = eig(A);
   delta = (P'*mu).^2;
   m = cumprod([1 2:2:2*p]').*dkncl(p,diag(D),delta);
   return
end
n = size(A,1);
m = NaN(pend,q+1);
m(1) = 1; 
%
%   Normalization of A and B such that
%   their largest eigenvalue is 1.
%
[P,B] = eig(B);
b = diag(B);
if any(b<=0)
   fprintf('B matrix must be positive definite!\n')
   return
end
delta = mu'*mu;
mu = P'*mu;
A = P'*A*P;
ea = eig(A);
maxea = max(abs(ea));
A = A./maxea;
ch = 1;
if all(ea<=0)    % when A is negative semi-definite
   ch = 2;
   A = -A;
elseif max(ea)*min(ea)<0&&p>0
   ch = 3;
   pt = pend-rem(pend,2);
end
maxeb = max(b);
b = b./maxeb;
eb = 1-b;   % nonzero eigenvalues of I_n-B
%
% Set max times of iteration and tolerance level
%
if nargin<6
   E = 1e-10;
end
if nargin<7
   M = 1000;
end
%
% generate p_{i,j} for recursive algorithm
%
n2 = n/2;
pcoeff = zeros(pend,pend+M);
pcoeff1 = zeros(pend,pend+M);
x = zeros(n,n,pend);
x(:,:,1) = eye(n);
xx = zeros(n,pend);
xx(:,1) = mu;
eta = [delta; zeros(p,1)];
if p>0
   x(:,:,2) = eye(n);
   xx(:,2) = mu;
end
if ch==3
   pcoeff2 = zeros(pt,pt+M);
   x1 = x(:,:,1:pt);
   xx1 = xx(:,1:pt);
   eta1 = [delta; zeros(pt,1)];
   [P,D] = eig(A);
   At = P*abs(D)*P';
end
D = eb*ones(1,n);
for j=1:p
    x(:,:,j+1) = D.*x(:,:,j);
    xx(:,j+1) = eb.*xx(:,j);
    for k=j:-1:2
        x(:,:,k) = A*x(:,:,k)+D.*x(:,:,k-1);
        xx(:,k) = A*xx(:,k)+eb.*xx(:,k-1);
    end
    x(:,:,1) = A*x(:,:,1);
    xx(:,1) = A*xx(:,1);
    for k=1:j+1
        eta2 = mu'*xx(:,k);
        pcoeff(j+2-k,k) = trace(x(:,:,k))+j*(eta2-eta(j+2-k));
        pcoeff1(j+2-k,k) = pcoeff(j+2-k,k)+2*j*eta(j+2-k);
        eta(j+2-k) = eta2;
    end
end
pbeg = 1;
if ch==3
   for j=1:pt-1
       x1(:,:,j+1) = D.*x1(:,:,j);
       xx1(:,j+1) = eb.*xx1(:,j);
       for k=j:-1:2
           x1(:,:,k) = At*x1(:,:,k)+D.*x1(:,:,k-1);
           xx1(:,k) = At*xx1(:,k)+eb.*xx1(:,k-1);
       end
       x1(:,:,1) = At*x1(:,:,1);
       xx1(:,1) = At*xx1(:,1);
       for k=1:j+1
           eta2 = trace(x1(:,:,k))+j*eta1(j+2-k);
           eta1(j+2-k) = mu'*xx1(:,k);
           pcoeff2(j+2-k,k) = eta2+j*eta1(j+2-k);
       end
   end
%
%  Deal with the last one differently if p is even because
%  pcoeff1 has only p columns, but not p+1 columns.
%
   if pt<pend
      for k=1:pt-1
          x1(:,:,k) = At*x1(:,:,k+1)+D.*x1(:,:,k);
          xx1(:,k) = At*xx1(:,k+1)+eb.*xx1(:,k);
      end
      x1(:,:,pt) = D.*x1(:,:,pt);
      xx1(:,pt) = eb.*xx1(:,pt);
      for k=1:pt
          eta2 = trace(x1(:,:,k))+pt*eta1(pend-k);
          eta1(pend-k) = mu'*xx1(:,k);
          pcoeff2(pend-k,k+1) = eta2+pt*eta1(pend-k);
      end
   end
   pbeg1 = 1;
   pend1 = pt-1;
end
%
% generate \tilde{d}_p(tilde{A}) for error bound 
%
mu1 = sqrt(2)*mu./sqrt(b);
[Q1,D1] = eig(A./sqrt(b*b'));
delta1 = (Q1'*mu1).^2;
e = dkncl(p,diag(D1),delta1);
if ch==3
   [Q1,D1] = eig(At./sqrt(b*b'));
   delta1 = (Q1'*mu1).^2;
   e1 = dkncl(pt-1,diag(D1),delta1);
   e(2:2:pt) = e1(2:2:pt);
end
e = (exp((mu1'*mu1)/2-delta/2)/sqrt(prod(b)))*e;
%
% generate d's and m's
%
d = zeros(pend,M+1);
d(1,1) = 1;
d1 = d;
if ch==3
   d2 = zeros(pt,M+1);
   d2(1,1) = 1;
end
%
% when k==0
%
const = ones(pend,q);
x2 = 1;
e(1) = e(1)-1;
for i=1:min(q,fix(n2-1/2))     % for p=0
    x2 = x2/((n-2*i)*maxeb);
    const(1,i) = x2*i/n2;
    err(1,i+1) = e(1)*const(1,i);
    m(1,i+1) = x2;
end
x0 = 1;
for i=1:p             % for p>0
    d(i+1,1) = (d(1:i+1,1)'*pcoeff(i+1:-1:1,1))/(2*i);
    d1(i+1,1) = (d1(1:i+1,1)'*pcoeff1(i+1:-1:1,1))/(2*i);
    if ch==3&&i<pt
       d2(i+1,1) = (d2(1:i+1,1)'*pcoeff2(i+1:-1:1,1))/(2*i);
    end
    x0 = 2*maxea*x0*i;
    x2 = x0;
    m(i+1,1) = x2*d(i+1,1);
    if ch==3&&rem(i,2)==1
       e(i+1) = e(i+1)-d2(i+1,1);
    else
       e(i+1) = e(i+1)-d1(i+1,1);
    end     
    for j=1:min(q,fix(n2+i-1/2))
        x2 = x2/((n+2*(i-j))*maxeb);
        const(i+1,j) = x2*j/(n2+i);
        m(i+1,j+1) = x2*d(i+1,1);
        err(i+1,j+1) = e(i+1)*const(i+1,j);
    end
end
%
% when k>0
%
k1 = 2;
while any(any(err>E))&&k1<=M+1
   p1 = p+k1-1;
   for k=pbeg:p
       x(:,:,k) = A*x(:,:,k+1)+D.*x(:,:,k);
       xx(:,k) = A*xx(:,k+1)+eb.*xx(:,k);
   end
   x(:,:,end) = D.*x(:,:,end);
   xx(:,end) = eb.*xx(:,end);
   for k=pbeg:pend
       eta2 = mu'*xx(:,k);
       pcoeff(p+2-k,k1+k-1) = trace(x(:,:,k))+p1*(eta2-eta(p+2-k));
       pcoeff1(p+2-k,k1+k-1) = pcoeff(p+2-k,k1+k-1)+2*p1*eta(p+2-k);
       eta(p+2-k) = eta2;
   end
   if ch==3
      for k=pbeg1:pend1
          x1(:,:,k) = At*x1(:,:,k+1)+D.*x1(:,:,k);
          xx1(:,k) = At*xx1(:,k+1)+eb.*xx1(:,k);
      end
      x1(:,:,end) = D.*x1(:,:,end);
      xx1(:,end) = eb.*xx1(:,end);
      for k=pbeg1:pend1+1
          eta2 = trace(x1(:,:,k))+p1*eta1(pend1+2-k);
          eta1(pend1+2-k) = mu'*xx1(:,k);
          pcoeff2(pend1+2-k,k1+k) = eta2+p1*eta1(pend1+2-k);
      end
   end
   for p1=1:pend
       sx = 2*(p1+k1-2);
       d(p1,k1) = sum(sum(d(1:p1,1:k1).*pcoeff(p1:-1:1,k1:-1:1)))/sx;
       d1(p1,k1) = sum(sum(d1(1:p1,1:k1).*pcoeff1(p1:-1:1,k1:-1:1)))/sx;
       if ch==3&&p1<=pt
          d2(p1,k1) = sum(sum(d2(1:p1,1:k1).*pcoeff2(p1:-1:1,k1:-1:1)))/sx;
       end
       if ch==3&&rem(p1,2)==0
          e(p1) = e(p1)-d2(p1,k1);
       else
          e(p1) = e(p1)-d1(p1,k1);
       end
       for q1=2:min(q+1,fix(n2+p1-1/2))
           if err(p1,q1)>E
              m(p1,q1) = m(p1,q1)+const(p1,q1-1)*d(p1,k1);
              const(p1,q1-1) = const(p1,q1-1)*(q1+k1-2)/(n2+p1+k1-2);
              M0(p1,q1) = M0(p1,q1)+1;
              err(p1,q1) = e(p1)*const(p1,q1-1);
           end
       end
   end
   if all(err(pend,:)<E)
      if ch==3&&pend==pt
         pbeg1 = pbeg1+1;
         pt = pt-1;
      end
      pbeg = pbeg+1;
      pend = pend-1;
   end   
   k1 = k1+1;
end
if ch==2
   m(2:2:end,:) = -m(2:2:end,:); 
end
