%
% qratmomnc.m   Date: 2012/01/10
% This program computes E[(z'A'z)^p/(z'Bz)^q] when z ~ N(mu,I)
% using an identity that involves h_{p,j}.
% B is assumed to be positive definite.
% This program uses a super-short recursive algorithm.
% Input: 
% A, B: matrix of the quadratic forms in the numerator and the denominator
% mu: mean of z
% p, q: power of the quadratic forms in the numerator and the denominator,
%       p is assumed to be a non-negative integer, 
%       q is assumed to be a non-negative real number
% E: precision, default is 1e-10
% M: maximum number of terms, default is 1000
% Output:
% m: E[(z'Az)^p/(z'Bz)^q] 
% err: upper bound of the approximation errors in m
% M0: number of terms to reach the desired level of precision
%
function [m,err,M0] = qratmomnc(A,B,mu,p,q,E,M)
pend = p+1;
n = size(A,1);
M0 = 0;
err = 0;
n2p = n/2+p;
if n2p<=q
   m = NaN;
   return
end
if q==0
   [P,D] = eig(A);
   dc = diag(D);
   delta = (P'*mu).^2;
   qc = zeros(n,1);
   hc = zeros(n,1);
   m = prod([2:2:2*p]);
   for i=1:p
       qc = dc.*(m+qc);
       hc = delta.*qc+dc.*hc;
       m = sum(qc+hc)/(2*i);
   end
   return
end
%
%   Normalization of A and B such that
%   their largest eigenvalue is 1.
%
[P,B] = eig(B);
b = diag(B);
if any(b<=0)
   m = NaN;
   fprintf('B matrix must be positive definite!\n')
   return
end
delta = mu'*mu;
mu = P'*mu;
A = P'*A*P;
ea = eig(A);
maxea = max(abs(ea));
A = A./maxea;
ch = 1;
if all(ea<=0)    % when A is negative semi-definite
   ch = 2;
   A = -A;
elseif rem(p,2)==1&&max(ea)*min(ea)<0
   ch = 3;
end
maxeb = max(b);
b = b./maxeb;
eb = 1-b;   % nonzero eigenvalues of I_n-B
%
% Set max number of terms and tolerance level
%
if nargin<6
   E = 1e-10;
end
if nargin<7
   M = 1000;
end
G = zeros(n,n,pend);
h = zeros(n,pend);
D = eb*ones(1,n);
ebd = diag(eb);
%
% generate \tilde{d}_p(B^{-\frac{1}{2}}tilde{A}B^{-\frac{1}{2}}) for error bound 
%
mu1 = sqrt(2)*mu./sqrt(b);
if p>0
   if ch==3
      [P,D1] = eig(A);
      At = P*abs(D1)*P';
   else
      At = A;
   end
   [Q1,D1] = eig(At./sqrt(b*b'));
   dc = diag(D1);
   delta1 = (Q1'*mu1).^2;
   qc = zeros(n,1);
   hc = zeros(n,1);
   e = 1;
   for i=1:p
       qc = dc.*(e+qc);
       hc = delta1.*qc+dc.*hc;
       e = sum(qc+hc)/(2*i);
   end
   e = (exp((mu1'*mu1)/2-delta/2)/sqrt(prod(b)))*e;
else
   e = (exp((mu1'*mu1)/2-delta/2)/sqrt(prod(b)));
end
%
% generate d's and m's
%
d = zeros(pend,1);
d(1) = 1;
%
% when j==0
%
const = 1;
for i=1:p             % for p>0
    G1 = A*d(i)+A*G(:,:,i);
    h(:,i+1) = G1*mu+A*h(:,i);
    d(i+1) = (trace(G1)+mu'*h(:,i+1))/(2*i);
    G(:,:,i+1) = G1;
    const = 2*maxea*const*i;
end
d1 = d;
if ch==3
   Ga = zeros(n,n,pend);
   ha = zeros(n,pend);
   for i=1:p
       G1 = At*d1(i)+At*Ga(:,:,i);
       ha(:,i+1) = G1*mu+At*ha(:,i);
       d1(i+1) = (trace(G1)+mu'*ha(:,i+1))/(2*i);
       Ga(:,:,i+1) = G1;
   end
else
   Ga = G;
   ha = h;
end
if rem(q,1)==0  % q is an integer
   for j=1:q
       const = const/((n+2*(p-j))*maxeb);
   end
else
   const = const*exp(gammaln(n2p-q)-gammaln(n2p))/(2*maxeb)^q;
end
m = const*d(pend);
const = const*q/n2p;
e = e-d1(pend);
err = e*const;
%
%   j>0
%
j = 1;
while err>E&&j<=M
   G1 = ebd*d(1)+D.*G(:,:,1);
   h(:,1) = (G1-G(:,:,1))*mu-d(1)*mu+eb.*h(:,1);
   d(1) = (trace(G1)+mu'*h(:,1))/(2*j);
   G(:,:,1) = G1;
   for i=1:p
       G1 = A*d(i)+ebd*d(i+1)+A*G1+D.*G(:,:,i+1);
       h(:,i+1) = (G1-G(:,:,i+1))*mu-d(i+1)*mu+A*h(:,i)+eb.*h(:,i+1);
       d(i+1) = (trace(G1)+mu'*h(:,i+1))/(2*(i+j));
       G(:,:,i+1) = G1;
   end
   G1 = ebd*d1(1)+D.*Ga(:,:,1);
   ha(:,1) = (G1+Ga(:,:,1))*mu+d1(1)*mu+eb.*ha(:,1);
   d1(1) = (trace(G1)+mu'*ha(:,1))/(2*j);
   Ga(:,:,1) = G1;
   for i=1:p
       G1 = At*d1(i)+ebd*d1(i+1)+At*G1+D.*Ga(:,:,i+1);
       ha(:,i+1) = (G1+Ga(:,:,i+1))*mu+d1(i+1)*mu+At*ha(:,i)+eb.*ha(:,i+1);
       d1(i+1) = (trace(G1)+mu'*ha(:,i+1))/(2*(i+j));
       Ga(:,:,i+1) = G1;
   end
   m = m+const*d(pend);
   const = const*(q+j)/(n2p+j);
   e = e-d1(pend);
   err = e*const;
   j = j+1;
end
M0 = j-1;
if ch==2
   m = -m;
end
