%
% qratmomncl.m   Date: 2008/03/15
% This program computes E[(z'A'z)^p/(z'Bz)^q] when z ~ N(mu,I)
% using an identity that involves h_{p,j}.
% B is assumed to be positive definite.
% This program uses the long recursive algorithm.
% Input: 
% A, B: matrix of the quadratic forms in the numerator and the denominator
% mu: mean of z
% p, q: power of the quadratic forms in the numerator and the denominator,
%       p is assumed to be a non-negative integer, 
%       q is assumed to be a non-negative real number
% E: precision, default is 1e-10
% M: maximum number of terms, default is 1000
% Output:
% m: E[(z'Az)^p/(z'Bz)^q] 
% err: upper bound of the approximation errors in m
% M0: number of terms to reach the desired level of precision
%
function [m,err,M0] = qratmomncl(A,B,mu,p,q,E,M)
pend = p+1;
n = size(A,1);
M0 = 0;
err = 0;
n2p = n/2+p;
if n2p<=q
   m = NaN;
   return
end
if q==0
   [P,D] = eig(A);
   delta = (P'*mu).^2;
   d = dkncl(p,diag(D),delta);
   m = prod([2:2:2*p])*d(end);
   return
end
%
%   Normalization of A and B such that
%   their largest eigenvalue is 1.
%
[P,B] = eig(B);
b = diag(B);
if any(b<=0)
   m = NaN;
   fprintf('B matrix must be positive definite!\n')
   return
end
delta = mu'*mu;
mu = P'*mu;
A = P'*A*P;
ea = eig(A);
maxea = max(abs(ea));
A = A./maxea;
ch = 1;
if all(ea<=0)    % when A is negative semi-definite
   ch = 2;
   A = -A;
elseif rem(p,2)==1&&max(ea)*min(ea)<0
   ch = 3;
end
maxeb = max(b);
b = b./maxeb;
eb = 1-b;   % nonzero eigenvalues of I_n-B
%
% Set max times of iteration and tolerance level
%
if nargin<6
   E = 1e-10;
end
if nargin<7
   M = 1000;
end
%
% generate p_{i,j} for recursive algorithm
%
pcoeff = zeros(pend,pend+M);
pcoeff1 = zeros(pend,pend+M);
x = zeros(n,n,pend);
x(:,:,1) = eye(n);
xx = zeros(n,pend);
xx(:,1) = mu;
eta = [delta; zeros(p,1)];
if p>0
   x(:,:,2) = eye(n);
   xx(:,2) = mu;
end
if ch==3
   x1 = x;
   xx1 = xx;
   eta1 = eta;
   [P,D] = eig(A);
   At = P*abs(D)*P';
end
D = eb*ones(1,n);
for j=1:p
    x(:,:,j+1) = D.*x(:,:,j);
    xx(:,j+1) = eb.*xx(:,j);
    for k=j:-1:2
        x(:,:,k) = A*x(:,:,k)+D.*x(:,:,k-1);
        xx(:,k) = A*xx(:,k)+eb.*xx(:,k-1);
    end
    x(:,:,1) = A*x(:,:,1);
    xx(:,1) = A*xx(:,1);
    for k=1:j+1
        eta2 = mu'*xx(:,k);
        pcoeff(j+2-k,k) = trace(x(:,:,k))+j*(eta2-eta(j+2-k));
        if ch<3
           pcoeff1(j+2-k,k) = pcoeff(j+2-k,k)+2*j*eta(j+2-k);
        end
        eta(j+2-k) = eta2;
    end
end
if ch==3
   for j=1:p
       x1(:,:,j+1) = D.*x1(:,:,j);
       xx1(:,j+1) = eb.*xx1(:,j);
       for k=j:-1:2
           x1(:,:,k) = At*x1(:,:,k)+D.*x1(:,:,k-1);
           xx1(:,k) = At*xx1(:,k)+eb.*xx1(:,k-1);
       end
       x1(:,:,1) = At*x1(:,:,1);
       xx1(:,1) = At*xx1(:,1);
       for k=1:j+1
           eta2 = trace(x1(:,:,k))+j*eta1(j+2-k);
           eta1(j+2-k) = mu'*xx1(:,k);
           pcoeff1(j+2-k,k) = eta2+j*eta1(j+2-k);
       end
   end
end
%
% generate \tilde{d}_p(B^{-\frac{1}{2}}tilde{A}B^{-\frac{1}{2}}) for error bound 
%
mu1 = sqrt(2)*mu./sqrt(b);
if p>0
   if ch<3
      [Q1,D1] = eig(A./sqrt(b*b'));
   else
      [Q1,D1] = eig(At./sqrt(b*b'));
   end
   delta1 = (Q1'*mu1).^2;
   e = dkncl(p,diag(D1),delta1);
   e = (exp((mu1'*mu1)/2-delta/2)/sqrt(prod(b)))*e(end);
else
   e = (exp((mu1'*mu1)/2-delta/2)/sqrt(prod(b)));
end
%
% generate d's and m's
%
d = zeros(pend,M+1);
d(1,1) = 1;
d1 = d;
%
% when k==0
%
const = 1;
for i=1:p             % for p>0
    d(i+1,1) = (d(1:i+1,1)'*pcoeff(i+1:-1:1,1))/(2*i);
    d1(i+1,1) = (d1(1:i+1,1)'*pcoeff1(i+1:-1:1,1))/(2*i);
    const = 2*maxea*const*i;
end
if rem(q,1)==0  % q is an integer
   for j=1:q
       const = const/((n+2*(p-j))*maxeb);
   end
else
   const = const*exp(gammaln(n2p-q)-gammaln(n2p))/(2*maxeb)^q;
end
m = const*d(pend,1);
const = const*q/n2p;
e = e-d1(pend,1);
err = e*const;
%
%   k>0
%
k1 = 2;
while err>E&&k1<=M+1
   p1 = p+k1-1;
   for k=1:p
       x(:,:,k) = A*x(:,:,k+1)+D.*x(:,:,k);
       xx(:,k) = A*xx(:,k+1)+eb.*xx(:,k);
   end
   x(:,:,end) = D.*x(:,:,end);
   xx(:,end) = eb.*xx(:,end);
   for k=1:pend
       eta2 = mu'*xx(:,k);
       pcoeff(p+2-k,k1+k-1) = trace(x(:,:,k))+p1*(eta2-eta(p+2-k));
       if ch<3
% Change the following line to 
%          pcoeff1(p+2-k,k1+k-1) = p1*eta(p+2-k)+trace(x(:,:,k))+p1*eta2;
% may improve precision
          pcoeff1(p+2-k,k1+k-1) = pcoeff(p+2-k,k1+k-1)+2*p1*eta(p+2-k);
       end
       eta(p+2-k) = eta2;
   end
   if ch==3
      for k=1:p
          x1(:,:,k) = At*x1(:,:,k+1)+D.*x1(:,:,k);
          xx1(:,k) = At*xx1(:,k+1)+eb.*xx1(:,k);
      end
      x1(:,:,end) = D.*x1(:,:,end);
      xx1(:,end) = eb.*xx1(:,end);
      for k=1:pend
          eta2 = trace(x1(:,:,k))+p1*eta1(pend+1-k);
          eta1(pend+1-k) = mu'*xx1(:,k); 
          pcoeff1(pend+1-k,k1+k-1) = eta2+p1*eta1(pend+1-k);
      end
   end
   for p1=1:pend
       sx = 2*(p1+k1-2);
       d(p1,k1) = sum(sum(d(1:p1,1:k1).*pcoeff(p1:-1:1,k1:-1:1)))/sx;
       d1(p1,k1) = sum(sum(d1(1:p1,1:k1).*pcoeff1(p1:-1:1,k1:-1:1)))/sx;
   end
   m = m+const*d(pend,k1);
   const = const*(q+k1-1)/(n2p+k1-1);
   e = e-d1(pend,k1);
   err = e*const;
   k1 = k1+1;
end
M0 = k1-2;
if ch==2
   m = -m;
end
