%
% qratmomncs.m   Date: 2008/03/15
% This program computes E[(z'A'z)^p/(z'Bz)^q] when z ~ N(mu,I)
% using an identity that involves h_{p,j}.
% B is assumed to be positive definite.
% This program uses the short recursive algorithm.
% Input: 
% A, B: matrix of the quadratic forms in the numerator and the denominator
% mu: mean of z
% p, q: power of the quadratic forms in the numerator and the denominator,
%       p is assumed to be a non-negative integer, 
%       q is assumed to be a non-negative real number
% E: precision, default is 1e-10
% M: maximum number of terms, default is 1000
% Output:
% m: E[(z'Az)^p/(z'Bz)^q] 
% err: upper bound of the approximation errors in m
% M0: number of terms to reach the desired level of precision
%
function [m,err,M0] = qratmomncs(A,B,mu,p,q,E,M)
pend = p+1;
n = size(A,1);
M0 = 0;
err = 0;
n2p = n/2+p;
if n2p<=q
   m = NaN;
   return
end
if q==0
   [P,D] = eig(A);
   delta = (P'*mu).^2;
   d = dkncs(p,diag(D),delta);
   m = prod([2:2:2*p])*d(end);
   return
end
%
%   Normalization of A and B such that
%   their largest eigenvalue is 1.
%
[P,B] = eig(B);
b = diag(B);
if any(b<=0)
   m = NaN;
   fprintf('B matrix must be positive definite!\n')
   return
end
delta = mu'*mu;
mu = P'*mu;
A = P'*A*P;
ea = eig(A);
maxea = max(abs(ea));
A = A./maxea;
ch = 1;
if all(ea<=0)    % when A is negative semi-definite
   ch = 2;
   A = -A;
elseif rem(p,2)==1&&max(ea)*min(ea)<0
   ch = 3;
end
maxeb = max(b);
b = b./maxeb;
eb = 1-b;   % nonzero eigenvalues of I_n-B
%
% Set max times of iteration and tolerance level
%
if nargin<6
   E = 1e-10;
end
if nargin<7
   M = 1000;
end
%
% generate the bound for different p
%
[ccoeff,ccoeff1,ecoeff] = ecq(A,eb,mu,p);
if ch<3
   ecoeff1 = ecoeff;
else
   [P,D] = eig(A);
   At = P*abs(D)*P';
   [ccoeff2,ccoeff1,ecoeff1] = ecq(At,eb,mu,p);
end
%
% generate \tilde{d}_p(B^{-\frac{1}{2}}tilde{A}B^{-\frac{1}{2}}) for error bound 
%
mu1 = sqrt(2)*mu./sqrt(b);
if p>0
   if ch<3
      [Q1,D1] = eig(A./sqrt(b*b'));
   else
      [Q1,D1] = eig(At./sqrt(b*b'));
   end
   delta1 = (Q1'*mu1).^2;
   e = dkncs(p,diag(D1),delta1);
   e = (exp((mu1'*mu1)/2-delta/2)/sqrt(prod(b)))*e(end);
else
   e = (exp((mu1'*mu1)/2-delta/2)/sqrt(prod(b)));
end
%
% generate d's and m's
%
d = zeros(pend,2*n+1);
d(1,1) = 1;
d1 = d;
%
% when k==0
%
const = 1;
for i=1:p             % for p>0
    index = [1:min(2*n,i)];
    d(i+1,1) = sum((ccoeff(index+1,1)./i-ecoeff(index+1,1)).*d(i+1-index,1));
    d1(i+1,1) = sum((ccoeff1(index+1,1)./i-ecoeff1(index+1,1)).*d1(i+1-index,1));
    const = 2*maxea*const*i;
end
if rem(q,1)==0  % q is an integer
   for j=1:q
       const = const/((n+2*(p-j))*maxeb);
   end
else
   const = const*exp(gammaln(n2p-q)-gammaln(n2p))/(2*maxeb)^q;
end
m = const*d(pend,1);
const = const*q/n2p;
e = e-d1(pend,1);
err = e*const;
%
%   k>0
%
k = 1;
while err>E&&k<=M
   if k>2*n
      k1 = 2*n+1;
      d = [d(:,2:end) zeros(pend,1)];
      d1 = [d1(:,2:end) zeros(pend,1)];
   else
      k1 = k+1;
   end 
   for p1=1:pend
       sx = p1+k-1;
       for v2=0:min(2*n-1,k)    % Normally, it should be min(2*n,k) but ccoeff and ecoeff have zero elements in its last column
           for v1=1-sign(v2):min(p1-1,2*n-v2)
               d(p1,k1) = d(p1,k1)+(ccoeff(v1+1,v2+1)/sx-ecoeff(v1+1,v2+1))*d(p1-v1,k1-v2);
               d1(p1,k1) = d1(p1,k1)+(ccoeff1(v1+1,v2+1)/sx-ecoeff1(v1+1,v2+1))*d1(p1-v1,k1-v2);
           end
       end
   end
   m = m+const*d(pend,k1);
   const = const*(q+k)/(n2p+k);
   e = e-d1(pend,k1);
   err = e*const;
   k = k+1;
end
M0 = k-1;
if ch==2
   m = -m;
end
