%
%  This program computes E[(z'Az)^p/(z'z)^q] when z~N(mu,I_n)
%  p is a non-negative integer and q is a non-negative real number
%  It uses a long recursive algorithm.
%
function y = ratiomoml(A,mu,p,q)
n = size(A,1);
if q>=n/2+p
   y = NaN;
   return
end
[P,D] = eig(A);
d = diag(D);
mu = P'*mu;
mu2 = mu.*mu;
tau = zeros(p,1);
eta = zeros(p,1);
di = ones(n,1);
a = zeros(p+1,1);
%
%  r=0, a(p+1) is a_{0,0}, a(p) is a_{1,0}, ..., a(1) is a_{p,0}
%
a(p+1) = 1;
for i=1:p
    di = d.*di;
    eta(i) = sum(di.*mu2);
    tau(i) = sum(di);
    a(p+1-i) = (a(p+2-i:end)'*tau(1:i))/(2*i);
end
%
%  r=1 to p.  After r=1 is finished, a(2) is a_{p,1}.
%  After r=2 is finished, a(3) is is a_{p,2}, and so on.
%
for r=1:p
    for i=r:p
        a(i+1) = a(i+1:end)'*eta(1:p+1-i);
    end
end
lam = -0.5*sum(mu2);
n2 = n/2;
c = 2^(p-q)*gamma(p+1)*gamma(n2+p-q)/gamma(n2+p);
y = c*a(1)*hypergeom(q,n2+p,lam);
for r=1:p
    c = c*(n2+p-q+r-1)/(n2+p+r-1)/(2*r);
    y = y+c*a(r+1)*hypergeom(q,n2+p+r,lam);
end
