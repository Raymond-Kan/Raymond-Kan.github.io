%
%  This program computes E[(z'Az)^p/(z'z)^q] when z~N(mu,I_n)
%  p is a non-negative integer and q is a non-negative real number
%  It uses a short recursive alogrithm.
%
function y = ratiomoms(A,mu,p,q)
n = size(A,1);
if q>=n/2+p
   y = NaN;
   return
end
[P,D] = eig(A);
d = diag(D);
mu = P'*mu;
mu2 = mu.*mu;
l = min(p,2*n-1);
eta = zeros(l,1);
z = zeros(l,1);
di = ones(n,1);
p0 = poly(d);
p1 = conv(p0,p0);
for i=1:l
    di = d.*di;
    eta(i) = i*sum(di.*mu2);
    z(i) = p1(1:i)*eta(i:-1:1);
end
a = zeros(p+1,1);
a(p+1) = 1;
%
%  r=0
%
for k=1:p
    l = min(k,n);
    a(p+1-k) = (([1:l]./(2*k)-1).*p0(2:l+1))*a(p-k+2:p-k+1+l);
end
%
%  r>0
%
for r=1:p
    a1 = a;  % a1 is a_{i,r-1}.
    for i=0:p-r  % i is k-r
        l = min(i,2*n);
        l1 = min(i+1,2*n-1);
        a(p+1-i) = ((3*[1:l]./(4*(r+i))-1).*p1(2:l+1))*a(p+2-i:p+1-i+l)+ ...
                   z(1:l1)'*a1(p+1-i:p-i+l1)/(2*(r+i));
    end
end
lam = -0.5*sum(mu2);
n2 = n/2;
c = 2^(p-q)*gamma(p+1)*gamma(n2+p-q)/gamma(n2+p);
y = c*a(1)*hypergeom(q,n2+p,lam);
for r=1:p
    c = c*(n2+p-q+r-1)/(n2+p+r-1);
    y = y+c*a(r+1)*hypergeom(q,n2+p+r,lam);
end
