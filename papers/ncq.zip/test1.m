n = 10;
x = randn(200,n);
A = (x'*x)./200;
x = randn(200,n);
B = (x'*x)./200;
C = cat(3,A,B);
mu = randn(n,1);
k = [28 100];
delete test1.out
diary test1.out
tic, a = mdknc2(A,B,mu,k(1),k(2)); toc
tic, b = mdkncs2(A,B,mu,k(1),k(2)); toc
tic, c = mdkncl2(A,B,mu,k(1),k(2)); toc
tic, d = mdkncl2a(A,B,mu,k(1),k(2)); toc
tic, e = mdknc(C,mu,k); toc
tic, f = mdkncs(C,mu,k); toc
tic, g = mdkncl(C,mu,k); toc
tic, h = mdkncla(C,mu,k); toc
e = reshape(e,k+1);
f = reshape(f,k+1);
g = reshape(g,k+1);
h = reshape(h,k+1);
format long
a(end) 
b(end) 
c(end) 
d(end)
e(end) 
f(end) 
g(end)
h(end)
diary off
