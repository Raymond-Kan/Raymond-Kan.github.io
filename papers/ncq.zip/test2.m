n = 14;
k = [14 6 18 13];
r = length(k);
A = zeros(n,n,r);
for i=1:r,
    x = randn(200,n);
    A(:,:,i) = (x'*x)./200;
end
mu = randn(n,1);
delete test2.out
diary test2.out
tic, a = mdknc(A,mu,k); toc
tic, b = mdkncs(A,mu,k); toc
tic, c = mdkncl(A,mu,k); toc
tic, d = mdkncla(A,mu,k); toc
tic, e = mdknc_kan(A,mu,k); toc
a = reshape(a,k+1);
b = reshape(b,k+1);
c = reshape(c,k+1);
d = reshape(d,k+1);
format long
[a(end) b(end) c(end) d(end) e]
diary off
