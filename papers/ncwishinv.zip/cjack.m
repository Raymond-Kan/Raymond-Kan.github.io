%
%   A matlab function that computes the "C" normalized 
%   Jack function of parameter alpha=2.  This is identical
%   to the zonal polynomial.
%   When only one output argument is specified, then
%   the function returns C_\lambda(x).
%   When two output arguments are specified,
%   J returns C_\kappa(x) with kappa<=lambda.
%   When three output arguments are specified,
%   then the output part will contain the partitions.
%   However, J does not store C_\kappa in lexicographic
%   order, so in order to recover the C_\kappa in
%   lexicographical order, we output a vector ind
%   such that J(ind(i)) gives us the ith partition
%   of kappa, with kappa^1 = [0] and kappa^i < kappa^{i+1}.
%   To get the zonal polynomials in lexicographical
%   order, just do J = J(ind) afterward.
%
function [J,ind,part]=cjack(MAX,x,lambda)
n = length(x);
if nargin<3
   lambda = floor(MAX./(1:n));
else
   lam = floor(MAX./(1:n));
   if length(lambda)<=n
      lambda = min(lambda,lam(1:length(lambda)));
   else
      lambda(1:n) = min(lambda(1:n),lam);
   end
   MAX = min(sum(lambda),MAX);
end
Lp = length(lambda);
while Lp>0&&lambda(Lp)==0
   Lp = Lp-1;
end % number of parts in l
lambda = lambda(1:Lp);
if Lp==0
   J = 1;
   if nargout>1
      ind = 1;
   end
   return
end
if Lp>n
   if nargout<=1
      J = 0;
      return
   end
   lambda = lambda(1:n);   % Only output the nonzero Jack functions
   Lp = n;
end
f = fn(lambda);
%
%  Let N(kappa) be the index for partition kappa
%  D(N(kappa)) stores N((kappa,1))
%  J(i,1:n) stores various jack functions of X
%  with the first entry J_kappa(x_1), second entry
%  J_kappa(x_1,x_2), and so on.
% 
D = zeros(f,1);
ind = zeros(f,1);
J = zeros(f,n);
J(1,:) = 1;
J1 = J(:,n);
xn = ones(n,MAX+1);
if size(x,2)>1
   x = x'; 
end
for i=2:MAX+1
    xn(:,i) = xn(:,i-1).*x;
end
prodx = cumprod(x);
l = zeros(1,Lp);
z = ones(1,Lp);
if nargout==3
   part = zeros(f,Lp);
end
kt = -(1:Lp);   % kt(i)=alpha*l(i)-i, it is updated instead of recomputed every time
sl = 1;  % sl = sum(l), it is updated instead of recomputed every time
fsl = 1; % fsl = factorial(sl);
%
% Note that h is the number of nonzero parts of l,
% w is N(l), i.e., the index for partition l.
% heap tells us where next block of memory is available after the current
% l(h)=1,..,m is stored, where m is the number of possible elements
% for l(h).
%
h = 1;
ww = ones(1,Lp);
heap = lambda(1)+2;  
d = zeros(1,Lp);   % d=l-[l(2:Lp) 0], it is the places we will be adding boxes
count = 1;
ind(count) = 1;
while h>0
   if (l(h)<lambda(h))&&((h==1&&l(1)<MAX)||(h>1&&l(h)<l(h-1)))&&(sl<=MAX)&&(z(h)~=0)
      l(h) = l(h)+1;
%  See Eq.(7) of Chan et al (2019) for the update from Q_{\kappa(h)} to Q_\kappa
      zn = 2/(kt(h)+h+1);
      kt(h) = kt(h)+2;
      for j=1:h-1
          delta = kt(j)-kt(h);
          zn = zn*delta/(delta+1);
      end
      z(h) = z(h)*zn;
      sl = sl+1;
      if l(h)==1&&h>1
         D(ww(h)) = heap;
         ww(h) = heap;
         m = min(lambda(h),MAX-sl+2);
         heap = heap+min(m,l(h-1));   
      else
         ww(h) = ww(h)+1;
      end
      w = ww(h);
      count = count+1;
      ind(count) = w; 
      if nargout==3
         part(w,:) = l;
      end
      cc = prod(h-1+kt(1:h))/prod(h+kt(1:h));
      % pp is the index of l-ones(1,Lp)
      pp = l(1);
      k = 2;
      while k<=h&&l(k)>1
         pp = D(pp)+l(k)-2;
         k = k+1;
      end
      J(w,h) = cc*prodx(h)*J(pp,h);
%
%    Only need to do work when number of nonzero
%    parts in l is less than n.
%
      if h<n
         if h>1
            d(h-1) = d(h-1)-1;
         end
         d(h) = l(h);
         g = find(d(1:h)>0);   % g are the indices of places we will be adding 
         lg = length(g);
         slm = 1;              % this is sum(l-mu)+1 which we will be updating
         nhstrip = prod(d(g)+1)-1;  % number of mu that are horizontal strips of l
         mu = l;
         mt = kt;              % mt(i)=alpha*m(i)-i   
         blm = ones(1,lg);     % This is a vector to store the beta_{lambda,mu} update
         lmd = l(g)-d(g);      % This gives us the lower bound of mu
         for i=1:nhstrip
             j = lg;
             gz = g(lg);    
             while mu(gz)==lmd(j)
                mu(gz) = l(gz);
                mt(gz) = kt(gz);
                slm = slm-d(gz);
                j = j-1;
                gz = g(j);  
             end
             t = kt(gz)-mt(gz);
             blm(j) = blm(j)*(1+t);
             dn = t+2;
             for r=1:gz-1
                 q1 = mt(r)-mt(gz);
                 q2 = kt(r)-mt(gz);
                 blm(j) = blm(j)*(1+q1)*(1+q2);
                 dn = dn*q1*(2+q2);
             end
             blm(j) = blm(j)/dn;
             mu(gz) = mu(gz)-1;
             mt(gz) = mt(gz)-2;
             slm = slm+1;
%           
%    Push blm(j) all the way to the end because subsequent partitions
%    of mu will be smaller than the current one. 
%  
             if j<lg      
                blm(j+1:end) = blm(j);
             end
%
%    Find out the index for partition mu. 
% 
             nmu = mu(1)+1;
             for k=2:h-(mu(h)==0)
                 nmu = D(nmu)+mu(k)-1;
             end
             for k=h+1:n
                 J(w,k) = J(w,k)+blm(j)*J(nmu,k-1)*xn(k,slm);
             end
         end
         for k=h+1:n
             J(w,k) = J(w,k)+J(w,k-1);
         end
      end
      J1(w) = fsl*z(h)*J(w,n);
      fsl = fsl*sl;
      if h<Lp            % increase the length of the partition if possible
         z(h+1) = z(h);  % carry over Q_kappa and index pointer
         ww(h+1) = w;
         h = h+1;
      end
   else
      sl = sl-l(h);
      fsl = fsl/prod(sl+1:sl+l(h));
      l(h) = 0;
      kt(h) = -h;
      h = h-1;
   end
end
if nargout>1
   J = J1(1:count,:);
   ind = ind(1:count);
   if nargout==3
      part = part(1:count,:);
   end
else
   J = J1(w);
end


function p=fn(kappa)
%
%   A Matlab function to find out the number of
%   partitions that is less than or equal to kappa.
%
n = length(kappa);
s = sum(kappa==kappa(1));
p = nchoosek(kappa(1)+n,n);
if s<n
   f = zeros(1,n);
   f(n) = kappa(n)+1;
% sn keeps track of the number of repeated elements at the
% beginning of the subvector kappa(i:n)
% c and d are the first term and the last term in the
% recursive relation, they are updated when sn>1.
   sn = 1;   
   c = kappa(n-1)+1;
   d = 1;
   kt = kappa-[1:n];
   for i=n-1:-1:s+2
       if kappa(i)==kappa(i+1)
          sn = sn+1;
          c = c*(n+1+kt(i))/(n+1-i);
          if kappa(i)>kappa(n)
             d = d*(kt(i)-kt(n))/(n+1-i);
          else
             d = 0;
          end
       else
          sn = 1;
          c = nchoosek(n+1+kt(i),n+1-i);
          d = nchoosek(kt(i)-kt(n),n+1-i);
       end
       f(i) = c-d;
       for j=sn+i:n-1
           f(i) = f(i)-nchoosek(kt(i)-kt(j),j-i+1)*f(j+1);
       end
   end
   for i=s+1:n-1
       p = p-nchoosek(kt(1)-kt(i),i)*f(i+1);
   end
   p = p-nchoosek(kt(1)-kt(n),n);
end
