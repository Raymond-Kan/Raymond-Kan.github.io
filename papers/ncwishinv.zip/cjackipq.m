%
%   A matlab function that computes C_\kappa(I_n)
%   for |\kappa|<=M.  Optionally, if p and q (two vectors) 
%   are specified, we multiply C_\kappa(I_n) by
%   \prod_{i=1} (p_i)_\kappa/\prod_{i=1} (q_i)_\kappa.
%   If lambda is specified, we will limit the \kappa
%   to be less than or equal to \lambda.
%   When three output arguments are specified,
%   then the output part will contain the partitions.
%   However, J does not store C_\kappa in lexicographical
%   order, so in order to recover the C_\kappa in
%   lexicographical order, we output a vector ind
%   such that J(ind(i)) gives us the ith partition
%   of kappa, with kappa^1 = [0] and kappa^i < kappa^{i+1}.
%   To get the zonal polynomials in lexicographical
%   order, just do J = J(ind) afterward.
%
function [J,ind,part]=cjackipq(MAX,n,p,q,lambda)
if nargin<5
   lambda = floor(MAX./(1:n));
else
   lam = floor(MAX./(1:n));
   if length(lambda)<=n
      lambda = min(lambda,lam(1:length(lambda)));
   else
      lambda(1:n) = min(lambda(1:n),lam);
   end
   MAX = min(sum(lambda),MAX);
end
Lp = length(lambda);
while Lp>0&&lambda(Lp)==0
   Lp = Lp-1;
end % number of parts in l
lambda = lambda(1:Lp);
if Lp==0
   J = 1;
   if nargout>1
      ind = 1;
   end
   return
end
if Lp>n
   if nargout<=1
      J = 0;
      return
   end
   lambda = lambda(1:n);   % Only output the nonzero Jack functions
   Lp = n;
end
f = fn(lambda);
%
%  Let N(kappa) be the index for partition kappa
%  D(N(kappa)) stores N((kappa,1))
%  J(i,1:n) stores various jack functions of X
%  with the first entry J_kappa(x_1), second entry
%  J_kappa(x_1,x_2), and so on.
% 
D = zeros(f,1);
ind = zeros(f,1);
J = zeros(f,1);
J(1) = 1;
l = zeros(1,Lp);
z = ones(1,Lp);
if nargout==3
   part = zeros(f,Lp);
end
kt = -(1:Lp);   % kt(i)=alpha*l(i)-i, it is updated instead of recomputed every time
sl = 1;  % sl = sum(l), it is updated instead of recomputed every time
fsl = 1; % fsl = factorial(sl);
%
% Note that h is the number of nonzero parts of l,
% w is N(l), i.e., the index for partition l.
% heap tells us where next block of memory is available after the current
% l(h)=1,..,m is stored, where m is the number of possible elements
% for l(h).
%
h = 1;
ww = ones(1,Lp);
heap = lambda(1)+2;  
d = zeros(1,Lp);   % d=l-[l(2:Lp) 0], it is the places we will be adding boxes
count = 1;
ind(count) = 1;
while h>0
   if (l(h)<lambda(h))&&((h==1&&l(1)<MAX)||(h>1&&l(h)<l(h-1)))&&(sl<=MAX)&&(z(h)~=0)
      l(h) = l(h)+1;
      c = (kt(h)+1)/2;
      zn = prod(p+c)/prod(q+c)*(n+kt(h)+1)/l(h)/(kt(h)+h+1);
      kt(h) = kt(h)+2;
      for j=1:h-1
          delta = kt(j)-kt(h);
          zn = zn*delta/(delta+2);
      end
      z(h) = z(h)*zn;
      sl = sl+1;
      if l(h)==1&&h>1
         D(ww(h)) = heap;
         ww(h) = heap;
         m = min(lambda(h),MAX-sl+2);
         heap = heap+min(m,l(h-1));   
      else
         ww(h) = ww(h)+1;
      end
      w = ww(h);
      count = count+1;
      ind(count) = w; 
      if nargout==3
         part(w,:) = l;
      end
      J(w) = fsl*z(h);
      fsl = fsl*sl;
      if h<Lp            % increase the length of the partition if possible
         z(h+1) = z(h);  % carry over Q_kappa and index pointer
         ww(h+1) = w;
         h = h+1;
      end
   else
      sl = sl-l(h);
      fsl = fsl/prod(sl+1:sl+l(h));
      l(h) = 0;
      kt(h) = -h;
      h = h-1;
   end
end
if nargout>1
   J = J(1:count,:);
   ind = ind(1:count);
   part = part(1:count,:);
else
   J = J(w);
end


function p=fn(kappa)
%
%   A Matlab function to find out the number of
%   partitions that is less than or equal to kappa.
%
n = length(kappa);
s = sum(kappa==kappa(1));
p = nchoosek(kappa(1)+n,n);
if s<n
   f = zeros(1,n);
   f(n) = kappa(n)+1;
% sn keeps track of the number of repeated elements at the
% beginning of the subvector kappa(i:n)
% c and d are the first term and the last term in the
% recursive relation, they are updated when sn>1.
   sn = 1;   
   c = kappa(n-1)+1;
   d = 1;
   kt = kappa-[1:n];
   for i=n-1:-1:s+2
       if kappa(i)==kappa(i+1)
          sn = sn+1;
          c = c*(n+1+kt(i))/(n+1-i);
          if kappa(i)>kappa(n)
             d = d*(kt(i)-kt(n))/(n+1-i);
          else
             d = 0;
          end
       else
          sn = 1;
          c = nchoosek(n+1+kt(i),n+1-i);
          d = nchoosek(kt(i)-kt(n),n+1-i);
       end
       f(i) = c-d;
       for j=sn+i:n-1
           f(i) = f(i)-nchoosek(kt(i)-kt(j),j-i+1)*f(j+1);
       end
   end
   for i=s+1:n-1
       p = p-nchoosek(kt(1)-kt(i),i)*f(i+1);
   end
   p = p-nchoosek(kt(1)-kt(n),n);
end
