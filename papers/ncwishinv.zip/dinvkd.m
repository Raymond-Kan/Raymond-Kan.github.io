%
%  This Matlab function expresses C_\kappa as a
%  linear combination of power-sum symmetric 
%  polynomials.
%
function Di = dinvkd(kappa)
   kappa(kappa==0) = [];
   m1 = length(kappa);
   k = sum(kappa);
   s = ip_desc(k);
   l = sum(s>0,2);   % l is a vector of number of parts for each integer partition of k
   f = cumprod(1:2*k);
   s1 = cumsum(s,2);
   m = size(s,1);
   for ii=1:m
       if m1==l(ii)&&all(s(ii,1:l(ii))==kappa)
          break
       end
   end
   if ii==m
      ck1 = 2^k/f(k+1);
   else
      ck1 = 1; 
      kappa1 = 2*kappa-(1:m1);
      for i1=1:m1-1
          ck1 = ck1*prod(kappa1(i1)-kappa1(i1+1:m1));
      end
      ck1 = 2^k*f(k)*ck1/prod(f(kappa1+m1));
   end
   rho = zeros(m-ii+1,1);
   for i=ii:m
       rho(i-ii+1) = sum(s(i,1:l(i)).*(s(i,1:l(i))-(1:l(i))));
   end
   rho = rho(1)-rho;
   C = zeros(1,m-ii+1);
   C(end) = f(k);
   if ii<m
      C(1) = 1;
      for i1=1:m1
          for j1=i1:m1-1
              if kappa(j1)>kappa(j1+1)
                 C(1) = C(1)*prod(kappa1(i1)-kappa1(j1)+1:2:kappa1(i1)-kappa1(j1+1)-2);
              end
          end
          C(1) = C(1)*prod(kappa1(i1)-kappa1(m1)+1:2:kappa1(i1)+m1-1);
      end
   end
   d = ones(m-ii+1,1);
   d(end) = f(k);
   v = zeros(k,1);
   if m<3
      m1 = fix(m*(m-1)/4);
   else
      m1 = round(m^(7/5)+6);  % An approximate length of vector a
   end
%  a is a vector which is used to store a_{\lambda}(\mu) for \kappa>=\mu>\lambda
%  alist is used to store the index for \mu
%  count is used to store the number of admissible \mu's for a given \lambda for
%  kappa>\lambda>=(1^k)
   a = zeros(m1,1);
   alist = zeros(m1,1);
   count = zeros(m-ii,1);
   for jj=max(2,ii):m-1
       jj1 = jj-ii+1;
       if jj>ii
          count(jj1) = count(jj1-1);
       end
       m1 = l(jj);
       lam = s(jj,1:m1);
%  Convert lam=(lam_1,lam_2,...) to [1^{v_1}2^{v_2}...]
       for i=1:lam(1)
           v(i) = sum(lam==i);
           if v(i)>0
              d(jj1) = d(jj1)*f(v(i));
           end
       end
       for kk=ii:jj-1
           if check2(lam,s(kk,1:l(kk)))
              for q2=m1:-1:2
                  if lam(q2)~=s(kk,q2)
                     break
                  end
              end
              t = s(kk,q2);
              while lam(q2)==s(kk,q2-1)
                 q2 = q2-1;
              end
              t = lam(q2)-t;
              for q1=q2-1:-1:1
                  if s(kk,q1)==lam(q1)+t||(lam(q1)~=s(kk,q1)&&lam(q1-1)==s(kk,q1))
                     break
                  end
              end
              if lam(q1)==lam(q2)
                 w = v(lam(q1));
                 w = w*(w-1)/2;
              else
                 w = v(lam(q1))*v(lam(q2));
              end
              count(jj1) = count(jj1)+1;
              a(count(jj1)) = (lam(q1)-lam(q2)+2*t)*w;
              alist(count(jj1)) = kk-ii;
           end
       end
   end
   for jj=ii+1:m-1
       if all(s1(ii,:)>=s1(jj,:))
          jj1 = jj-ii+1;
          alist1 = alist(count(jj1-1)+1:count(jj1));
          ind = find(alist1>=0);
          C(jj1) = round(C(alist1(ind)+1)*a(count(jj1-1)+ind)/rho(jj1));
       end
   end
   T = mtop2(k);
   Di = ck1*C*diag(1./d)*T(ii:end,:);
end

function y = check2(a,b)
   m1 = length(a);
   m2 = length(b);
   if m2<m1-1||m2>m1
      y = false;
      return
   end
   i1 = 1;
   i2 = 1;
   c = 0;
   while i2<=m2&&i1<=m1
      if a(i1)==b(i2)
         i1 = i1+1;
         i2 = i2+1;
      elseif a(i1)<b(i2)
         i2 = i2+1;
      else
         i1 = i1+1;
         c = c+1;
      end
   end
   c = c+m1-i1+1;
   y = c<=2;
end
