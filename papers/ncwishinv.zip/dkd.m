%
%  This Matlab function produces transition matrices
%  from power-sum symmetric functions to zonal 
%  polynomials (D) and from zonal polynomials to
%  power-sum polynomials (Di).  This is a double precision
%  version, can do up to k=16 with pretty good precision.
%
function [D,Di] = dkd(k)
   s = ip_desc(k);
   f = cumprod(1:k);
   s1 = cumsum(s,2);
   m = size(s,1);
   rho = zeros(m-1,1);
   rho(1) = k*(k-1);
%  C is the transistion matrix from C_kappa to monomials
   C = eye(m)*2^k*f(k);
   C(m,m) = 2^k/(k+1);
   l = sum(s>0,2);   % l is a vector of number of parts for each integer partition of k
   for i=2:m
       rho(i) = sum(s(i,1:l(i)).*(s(i,1:l(i))-[1:l(i)]));
   end
   d = ones(m,1);
%  Convert lambda=(lambda_1,lambda_2,...) to [1^{v_1}2^{v_2}...]
   v = zeros(k,1);
   if m<3
      m1 = fix(m*(m-1)/4);
   else
      m1 = round(m^(7/5)+6);  % An approximate length of vector a
   end
%  a is a vector which is used to store a_{\lambda}(\mu) for (k)>=\mu>\lambda
%  alist is used to store the index for \mu
%  count is used to store the number of admissible \mu's for a given \lambda
   a = zeros(m1,1);
   alist = zeros(m1,1);
   count = zeros(m,1);
   for jj=2:m
       count(jj) = count(jj-1);
       m1 = l(jj);
       kappa = s(jj,1:m1);
       for i=1:kappa(1)
           v(i) = sum(kappa==i);
           if v(i)>0
              d(jj) = d(jj)*f(v(i));
           end
       end
       for kk=1:jj-1   
           if check2(kappa,s(kk,1:l(kk)))
              for q2=m1:-1:2
                  if kappa(q2)~=s(kk,q2)
                     break
                  end
              end
              t = s(kk,q2);
              while kappa(q2)==s(kk,q2-1)
                 q2 = q2-1;
              end
              t = s(jj,q2)-t;
              for q1=q2-1:-1:1
                  if s(kk,q1)==kappa(q1)+t||(kappa(q1)~=s(kk,q1)&&kappa(q1-1)==s(kk,q1))
                     break
                  end
              end
              if kappa(q1)==kappa(q2)
                 w = v(kappa(q1));
                 w = w*(w-1)/2;
              else
                 w = v(kappa(q1))*v(kappa(q2));
              end                      
              count(jj) = count(jj)+1;
              a(count(jj)) = (kappa(q1)-kappa(q2)+2*t)*w;
              alist(count(jj)) = kk;
           end
       end
   end
   for ii=1:m-1
       m1 = l(ii);
       kappa = s(ii,1:m1);
       kappa1 = 2*kappa-[1:m1];
       for i1=1:m1
           for j1=i1:m1-1
               if kappa(j1)>kappa(j1+1)
                  C(ii,ii) = C(ii,ii)/prod((kappa1(i1)-kappa1(j1)+2):2:(kappa1(i1)-kappa1(j1+1)-1));
               end
           end
           C(ii,ii) = C(ii,ii)/prod((kappa1(i1)-kappa1(m1)+2):2:(kappa1(i1)+m1));
       end
       for jj=ii+1:m
           if all(s1(ii,:)>=s1(jj,:))
              alist1 = alist(count(jj-1)+1:count(jj));
              ind = find(alist1>=ii);
              C(ii,jj) = C(ii,alist1(ind))*a(count(jj-1)+ind)/(rho(ii)-rho(jj));
           end
       end
   end
   Di = C*diag(1./d)*mtop2(k);
   D = Di./(Di(:,m)*ones(1,m));
   D = D'./(D(1,:)'*ones(1,m));

function y = check2(a,b)
   m1 = length(a);
   m2 = length(b);
   if m2<m1-1||m2>m1
      y = false;
      return
   end
   i1 = 1;
   i2 = 1;
   c = 0;
   while i2<=m2&&i1<=m1
      if a(i1)==b(i2)
         i1 = i1+1;
         i2 = i2+1;
      elseif a(i1)<b(i2)
         i2 = i2+1;
      else
         i1 = i1+1;
         c = c+1;
      end
   end
   c = c+m1-i1+1;
   y = c<=2;
