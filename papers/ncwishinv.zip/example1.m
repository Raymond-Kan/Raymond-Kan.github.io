%
%   This program demonstrates how to compute E[W^{-1}] for
%   W~W_m(n,I_m,\Lambda)
%
format long
delete example1.out
diary example1.out
d = [1 2 4];   % This is a diagonal matrix of the eigenvalues of \Lambda
n = 20;
%  This returns the diagonal elements of W^{-1}
Wd = invwish(n,d)
%
%  Here we do it for a general Wishart matrix with W~W_m(n,S,Lambda)
%
S = [3 1 1; 1 2 1; 1 1 4];
Lam = [4 2 1; 2 5 2; 1 2 6];
Sh = sqrtm(inv(S));  % S^{-1/2}
Lam1 = Sh*Lam*Sh;
Lam1 = 0.5*(Lam1+Lam1');
[L,D] = eig(Lam1);
Wd = invwish(n,diag(D));
EWinv = Sh*L*diag(Wd)*L'*Sh
%
%   For the case of \Lambda = a*I_m, we can use invwisha.
%   E[W^{-1}] is wd*I_m.
%
m = 4;
a = 2;
wd = invwisha(n,m,a)
%
%   For the case of m=2, we can do it faster with invwish2
%   and invwisha2
%
Wd = invwish2(n,[4 2])
wd = invwisha2(n,3)
diary off
