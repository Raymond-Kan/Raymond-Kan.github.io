%
%   This program demonstrates how to compute E[C_\kappa(W^{-1})].
%   W~W_m(n,I_m,D)
%
format long
delete example2.out
diary example2.out
d = [1 2 4];   % This is a diagonal matrix of the eigenvalues of \Lambda
n = 20;
k = 3;
%  This returns E[tr(W^{-k})]
y = invwisht(k,n,d)
%  This returns E[tr(W^{-k})] for the special case of m=2
y = invwisht2(k,n,d(1:2))
%  This returns E[|W^{-1}|^k]
y = invwishdet(k,n,d)
%  This returns E[C_k(W^{-1})], i.e., top-order zonal polynomial of W^{-1}
y = invwishck(k,n,d)
%  This returns E[C_\kappa(W^{-1})] for kappa = (3,2), we only sum up to 20 terms.
y = invwishzonal([3 2],n,d,20)
%  This returns E[C_{k_1,k_2}(W^{-1})] for the special case of k_1=3, k_2=2, and m=2
y = invwishzonal2(3,2,n,d(1:2))
diary off


