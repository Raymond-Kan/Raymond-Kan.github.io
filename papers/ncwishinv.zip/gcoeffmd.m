% 
%  This Matlab function computes the matrix of coefficients 
%  g_{kappa,lam}^\phi for a given kappa and |\lam|=l, where 
%  C_{kappa}*C_{lam} = \sum_{\phi}g_{\kappa,\lam}^\phi C_\phi.
%  The output is a matrix with dimension of p(l)xp(f), where
%  p(l) is the number of integer partition of l and f=|kappa|+l.
%
function g = gcoeffmd(kappa,l)
   kappa(kappa==0) = [];
   k = sum(kappa);
   if k==0
      sl = ip_desc(l);
      m2 = size(sl,1);
      g = eye(m2);
      return
   end
   if l==0
      sk = ip_desc(k);
      lk = sum(sk>0,2);
      m1 = size(sk,1);
      g = zeros(1,m1);
      lkappa = length(kappa);
      for i=1:size(sk,1)
          if lk(i)==lkappa&&all(sk(i,1:lk(i))==kappa);
             g(i) = 1;
             return
          end
      end
   end
   f = k+l;
   F = ones(f);
   for j=2:f
       F(:,j) = F(:,j-1);
       F(j,j) = F(j,j)+1;
       for i=j+1:f
           F(i,j) = F(i,j)+F(i-j,j);
       end
   end
   s1 = ip_desc(k);
   lk = sum(s1>0,2);
   if k==l
      s2 = s1;
      ll = lk;
   else
      s2 = ip_desc(l);
      ll = sum(s2>0,2);
   end
   m1 = F(k,k);
   m2 = F(l,l);
   m3 = F(f,f);
   c = zeros(m2,m3);
   Dki = dinvkd(kappa);
   [~,Dli] = dkd(l);
   for i1=1:m1
       s1a = s1(i1,1:lk(i1));
       if Dki(i1)~=0
          for j1=1:m2
              phi = sort([s1a s2(j1,1:ll(j1))],2,'descend');
              kk = part_ind(phi);
              c(:,kk) = c(:,kk)+Dki(i1)*Dli(:,j1);
          end
       end 
   end
   g = c*dkd(f);
%  Cleaning up the matrix by finding out which one ought to be zero   
   s3 = ip_desc(f);
   l3 = sum(s3>0,2);
   for i1=1:m3
       phi = s3(i1,1:l3(i1));
       ind = lrcoeff(phi,kappa);
       g(find(ind==0),i1) = 0;
   end 
   
function y = part_ind(nu)
%
%  This function takes nu, an integer partition of k, and returns the location of 
%  nu within the list of integer partitions with |kappa|=k.
%
   n1 = sum(nu);
   y = F(n1,n1);
   for i2=1:length(nu)
       k1 = nu(i2);
       if k1>1
          y = y-F(n1,k1-1);
          n1 = n1-k1;
       else
          break
       end
   end
end

end
