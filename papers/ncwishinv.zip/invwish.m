function y = invwish(n,d)
%
%  This function computes the diagonal elements of
%  E[W^{-1}], where W ~ W_m(n,I_m,diag(d)).
%
m = length(d);
M = 80;  % number of terms to be evaluated in 2F2
y = zeros(m,1);
for i=1:m
    d1 = d(i)/2;
    d2 = d/2;
    d2(i) = [];
    c = 1;
    y(i) = c*exp(sum(d2));
    for k=1:1000
        c = -c*d1/(n/2+k-1);
        c1 = c*mhg(M,2,[n/2 (n-1)/2+k],[(n-1)/2 n/2+k],d2);
        y(i) = y(i)+c1;
        if abs(c1/y(i))<1e-12
           break
        end
    end
    y(i) = y(i)*exp(-sum(d2))/(n-m-1);
end
