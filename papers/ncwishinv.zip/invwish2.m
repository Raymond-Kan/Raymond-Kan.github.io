%
%   This function computes the diagonal elements of
%   E[W^{-1}], where W ~ W_2(n,I_2,Diag(d_1,d_2)).
%
function y = invwish2(n,d)
m = 2;
maxiter = 10000;
y = ones(2,1);
d1 = d(1);
d2 = d(2);
if d1==0
   y(1) = 1/(n-3);
   y(2) = hypergeom(1,n/2,-d2/2)/(n-3);
   return
end
if d2==0
   y(1) = hypergeom(1,n/2,-d1/2)/(n-3);
   y(2) = 1/(n-3);
   return
end
for ii=1:2   
    if ii==2
       d2 = d(1);
       d1 = d(2);
    end
    c1 = 1;
    for r=1:maxiter
        c1 = c1*(-d1/2)/(n/2+r-1);
        c2 = 1;
        c3 = 1;
        for k=1:r
            c2 = c2*(-d2/d1)*((n-1)/2+r-k)*(n/2+k-1)/((n-3)/2+k)/k;
            c3 = c3+c2;
        end
        c = c1*c3;
        y(ii) = y(ii)+c;
        if abs(c)/y(ii)<1e-12
           break
        end
    end
    y(ii) = y(ii)*exp(-d2/2)/(n-3);
end
