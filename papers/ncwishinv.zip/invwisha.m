function y = invwisha(n,m,a)
%
%  This function computes the diagonal element of
%  E[W^{-1}], where W ~ W_m(n,I_m,a*I_m)
%
M = 80;  % number of terms to be evaluated
g = (n-1)/(n-m-1)*exp(-m*a/2)*mhgi(M,2,[(n+1)/2 (n-2)/2],[n/2 (n-1)/2],m,a/2);
y = (g-1)/m;
