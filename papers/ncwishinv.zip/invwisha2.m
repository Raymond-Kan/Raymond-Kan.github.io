function y = invwisha2(n,a)
%
%  This function computes the diagonal element of 
%  E[W^{-1}], where W ~ W_2(n,I_2,a*I_2)
%
M = 100;  % maximum number of terms to be evaluated
g = 1;
w0 = 0;
w1 = 1;
ca = 1;
cb = 1;
a2 = a^2/4;
for k=1:M
    w = a*w1-a2*w0+a/2*cb;
    cb = cb*((n-2)/2+k)*((n-5)/2+k)/((n-3)/2+k)/((n-4)/2+k)*a2/k;
    w = w+cb;
    ca = ca*((n-1)/2+k)*((n-4)/2+k)/((n-2)/2+k)/((n-3)/2+k)/(1/2+k);
    c = ca*w;
    g = g+c;
    if abs(c/g)<1e-12
       break
    end
    w0 = w1;
    w1 = w;
end    
y = (exp(-a)*(n-1)/(n-3)*g-1)/2;
