%
%   This function computes E[C_k(W^{-1})], where W ~ W_m(n,I_m,diag(d))
%
function y = invwishck(k,n,d)
   m = length(d);
   if k>=(n-m+1)/2
      y = NaN;
      return
   end
   M = 80;  % number of terms to be evaluated in 2F2
   y = (-1)^k/prod(1:2:2*k-1);
   c = exp(-sum(d)/2)*y;
   for i=1:k
       psi = mhg(M,2,[(n+1)/2 n/2-i],[n/2 (n+1)/2-i],d/2);
       c = -c*(k+1-i)/i*(n+1-2*i)/(n-m+1-2*i);
       y = y+c*psi;
   end
      