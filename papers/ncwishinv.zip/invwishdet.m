%
%   This function computes E[|W|^{-k}], where W ~ W_m(n,I_m,diag(d))
%
function y = invwishdet(k,n,d)
   m = length(d);
   if k>=(n-m+1)/2
      y = NaN;
      return
   end
   M = 80;  % number of terms to be evaluated in 1F1
   y = prod(gamma((n-m-2*k+[1:2*k])/2)./gamma((n-2*k+[1:2*k])/2))/2^(m*k)*mhg(M,2,k,n/2,-d/2);
      