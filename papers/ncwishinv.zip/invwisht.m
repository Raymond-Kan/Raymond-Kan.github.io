function y = invwisht(k,n,d)
%
%  This function computes E[tr(W^{-k})], where W ~ W_m(n,I_m,diag(d)).
%
y = invwishck(k,n,d);
if k>1
   m = length(d);
   p = ip_desc(k);
   lp = sum(p>0,2);
   M = 20;
   for i=2:size(p,1)
       if lp(i)<=m
          p1 = p(i,1:lp(i));
          d1 = 1/prod(p1(1):k-1);
          for j=2:lp(i)
              d1 = d1*prod(-(j-1)/2:p1(j)-(j+1)/2);
          end
          if d1~=0
             y = y+d1*invwishzonal(p1,n,d,M);
          end
       end
   end
end

