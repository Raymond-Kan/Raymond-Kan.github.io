function y = invwisht2(k,n,d)
%
%  This function computes E[tr(W^{-k})], where 
%  W ~ W_2(n,I_2,diag(d))
%
if k>=(n-3)/2
   y = NaN;
   return
end
M = 100;  % maximum number of terms to be evaluated
a = acoeff(k);
y = 0;
for i=0:length(a)-1
    [c,s] = mhg(M,2,(n-2*(k-i))/2,n/2,d/2);
    for j=1:k-2*i
        c0 = n-2*(k-i)+j-1;
        s = s.*[c0:c0+M];
    end  
    c1 = gamma(n/2-k+i)/gamma(n/2)*gamma((n-1)/2-k+i)/gamma((n-1)/2);
    y = y+a(i+1)*c1*sum(s);
end
y = y*exp(-sum(d)/2)/2^k;
      
function a = acoeff(k)
k1 = floor(k/2);
a = zeros(1,k1+1);
a(1) = 1;
for j=1:k1
    for i=1:j
        a(j+1) = a(j+1)-a(i)*nchoosek(k-2*i+2,j-i+1);
    end
end
