%
%  This function computes E[C_\kappa(W^{-1})], where W ~ W_m(n,I_m,diag(d))
%
function y = invwishzonal(kappa,n,d,M)
   m = length(d);
   k1 = kappa(1);
   if k1>=(n-m+1)/2
      y = NaN;
      return
   end
   kappa(kappa==0) = [];
   lk = length(kappa);
   if lk>m
      y = 0;
      return
   end
   k = sum(kappa);
   r = k1;
   kappar = r*ones(1,m)-[zeros(1,m-lk) fliplr(kappa)];
   m1 = m*r-k;
   if nargin<4
      M = 22-m1;  % maximum number of terms to be evaluated
      if M<=0
         y = NaN;
         fprintf(' Consider increasing the number of terms!\n')
         return
      end
   end
%
%  Create a matrix for part_ind
%
   F = ones(M);
   for j=2:M
       F(:,j) = F(:,j-1);
       F(j,j) = F(j,j)+1;
       for i=j+1:M
           F(i,j) = F(i,j)+F(i-j,j);
       end
   end
%
%  Obtain C_\alpha(d/2) and C_\alpha(I_m)
%
   [J,ind,part] = cjack(M,d/2);
   [J1,ind,part] = cjackipq(M,m,n/2,[]);
   [J2,ind1,part1] = cjackipq(M+m1,m,n/2-r,[]);
   J = J./J1;
%
%  Keep only partitions with |\lambda|>=|\kappa_r|+1
%
   ind2 = sum(part1,2)>=m1;
   J2 = J2(ind2);
   part1 = part1(ind2,:);
   ind2 = find(all(part1==kappar,2),1);
   y = J2(ind2);
   kappar(kappar==0) = [];
   sp = sum(part,2);
   c = exp(-sum(d)/2)*prod(gamma((n-m-2*r+[1:2*r])/2)./gamma((n-2*r+[1:2*r])/2))*cjackipq(k,m,[],[],kappa)*poch(n/2-r,kappar)/y/2^k;
   fj = cumprod(1:M);
   for j=1:M
       g = gcoeffmd(kappar,j);
       p = ip_desc(m1+j);
       lp = sum(p>0,2);
       for i=1:size(g,2);
           if lp(i)<=m&&any(g(:,i)~=0)
              if m1+j<m
                 p1 = [p(i,:) zeros(1,m-m1-j)];
              else
                 p1 = p(i,1:m);
              end
              ind3 = find(all(part1==p1,2),1);
              g(:,i) = g(:,i)*J2(ind3);
           end
       end
       ind2 = find(sp==j);
       for i=1:length(ind2)
           alpha = part(ind2(i),:);
           alpha(alpha==0) = [];
           ind3 = part_ind(alpha);
           y = y+J(ind2(i))*sum(g(ind3,:))/fj(j);
       end
   end
   y = c*y;

function y = part_ind(nu)
%
%  This function takes nu, an integer partition of k, and returns the location of 
%  nu within the list of integer partitions with |kappa|=k.
%
   n1 = sum(nu);
   y = F(n1,n1);
   for i2=1:length(nu)
       kk = nu(i2);
       if kk>1
          y = y-F(n1,kk-1);
          n1 = n1-kk;
       else
          break
       end
   end
end

end
