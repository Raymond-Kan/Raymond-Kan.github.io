%
%  This function computes E[C_{(k1,k2)}W^{-1}], where W ~ W_2(n,I_2,diag(d))
%
function y = invwishzonal2(k1,k2,n,d)
   if k1>=(n-1)/2
      y = NaN;
      return
   end
   M = 100;  % maximum number of terms to be evaluated
   k = k1+k2;
   y = 0;
   for r=0:floor((k1-k2)/2)
       v1 = k1-k2-2*r;
       c1 = (-1)^r*gamma(1/2+k1-k2-r)/factorial(v1)/factorial(r)*ef(k1-r,v1);
       y = y+c1;
   end
   y = exp(-sum(d)/2)*factorial(k)*(k1-k2+1/2)/factorial(k2)/gamma(3/2+k1)*y;

function y1 = ef(h,j)
%
%  This function computes E[|W|^{-h}(tr(W))^j]
%
   [c,s] = mhg(M,2,n/2-h,n/2,d/2);
   c2 = prod(n-2*h:n-2*h+j-1);
   for ii=1:M+1
       s(ii) = s(ii)*c2;
       c2 = c2*(n-2*h+ii+j-1)/(n-2*h+ii-1);
   end
   y1 = sum(s)*2^j/prod(n-1-2*h:n-2);
end

end