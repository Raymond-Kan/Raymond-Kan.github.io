%
%   This function computes the Littlewood-Richardson
%   coefficients.  For a given lam>mu, we find the 
%   LR coefficients c_{mu,kappa}^lam such that
%   s_lam = sum_{kappa} c_{mu,kappa}^lam s_mu*s_kappa.
%   The coefficients are stored in a vector with
%   kappa's arranged in reverse lexicographical order.
%   This is modified based on LR_rule.m from John Stembridge:
%   http://www.math.lsa.umich.edu/~jrs/software/SFexamples.html
%
function lr=lrcoeff(lam,mu)
   lam(lam==0) = [];
   mu(mu==0) = [];
   ll = length(lam);
   lm = length(mu);
   ld = ll-lm;
   sd = sum(lam)-sum(mu);
   F = ones(sd);
   for j=2:sd
       F(:,j) = F(:,j-1);
       F(j,j) = F(j,j)+1;
       for i=j+1:sd
           F(i,j) = F(i,j)+F(i-j,j);
       end
   end
   F1 = F(end,end);
   mu = [mu zeros(1,ld)];
   if ld<0||any(lam<mu)
      lr = zeros(F1,1);
      return
   end
   dgrm = zeros(sd,2);
   count = 0;
   for i=1:ll
       for j=-lam(i):-1-mu(i)
           count = count+1;
           dgrm(count,:) = [i -j];
       end
   end
   T{1}{1} = [];
   T{1}{2} = [];
   for i=1:sd
       dgrm1 = dgrm(1:i,:);
       x = dgrm(i,:);
       upper = find(all(dgrm1==[x(1) x(2)+1],2),1);
       lower = find(all(dgrm1==[x(1)-1 x(2)],2),1);
       if isempty(lower)
          lower = 0;
       end
       if isempty(upper)
          upper = 0;
       end
       T1 = {};
       for j=1:length(T)
           T1 = [T1 nextletter(T{j}{1},T{j}{2},lower,upper)];
       end
       T = T1;
   end
   n1 = length(T);
   lr = zeros(F1,1);
   for i=1:n1
       ind = partind(T{i}{1});
       lr(ind) = lr(ind)+1;
   end

function y = partind(kappa)
   r = 0;
   n = sd;
   y = F1;
   for ii=1:length(kappa)
       if kappa(ii)>1
          k = kappa(ii);
          r = r+F(n,k-1);
          n = n-k;
       else
          break
       end
   end
   y = y-r;
end

end   

  
function y=nextletter(Ta,Tb,lower,upper)
   shape = [Ta 0];
   lp = Tb;
   ub = length(shape);
   if lower==0
      lb = 0;
   else
      lb = lp(lower);
   end
   if upper>0
      ub = min(lp(upper),ub);
   end
   j = 0;
   for i=lb+1:ub
       if i==1||shape(i-1)>shape(i)
          j = j+1;
          y{j}{2} = [lp i];
          shape1 = shape;
          shape1(i) = shape1(i)+1;
          shape1(shape1==0) = [];
          y{j}{1} = shape1;
       end
   end
end