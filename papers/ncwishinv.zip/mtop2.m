%
%  This program computes transition matrix from power-sum
%  symmetric functions to augmented monomial symmetric functions. 
%  The matrix is a lower triangular matrix with ones on the digaonal.  
%  Reference: Mircea Merca, Augmented monomials in terms of power sums,
%             Springer Plus (2015)4:724.
%  Input
%  k: Maximum order of transition matrix
%  Output
%  T: a transition matrix T^{(k)} which maps augmented monomial
%     symmetric polynomials of order k to power-sum symmetric
%     polynomials of order k.
%  Note: At double precision, T is inaccurate for k>22.  The first
%        element of the last row of T is equal to (-1)^(k-1)*(k-1)!  
%        When k>23, (k-1)! does not have an accurate representation 
%        in double precision.
%
function T = mtop2(k)
   if k<=2
      if k==1
         T = 1;
      else
         T = [1 0; -1 1];
      end
      return
   end
%
%  F(i,j) is the number of integer partitions of i with j parts or less,
%  it is also the number of integer partitions of i whose first part
%  is j or less.
%
   k1 = k+rem(k,2);
   F = ones(k1);
   for j=2:k1
       F(:,j) = F(:,j-1);
       F(j,j) = F(j,j)+1;
       for i=j+1:k1
           F(i,j) = F(i,j)+F(i-j,j);
       end
   end
   m = F(k,k);
   T = zeros(k,m,m);
   T(1,1,1) = 1;
   T(2,1:2,1:2) = [1 0; -1 1];
   f = cumprod(1:k);  % f(i) = i!
   pp = cell(1,k-1);
   pp{1} = 1;
   pp{2} = [2 0; 1 1];
   rr = 2;
%  Skip T^{(k-1)} to save time
   for r=[3:k-2 k]
       p = ip_desc(r);
       if r<k
          pp{r} = p;
       end
       l = sum(p>0,2);   % number of parts of p
       m = size(p,1);
       T(r,1:m,1:m) = eye(m);
%  Copy the first part of the matrix T^{(r)} from T^{(r-1)}.  The part
%  to be copied is up to and not including the partition with (r/2,r/2) for 
%  r even and ((r-1)/2,(r-1)/2,1) for r odd.
       if r==k&&r>3
          T(r,1:rr,1:rr) = T(r-2,1:rr,1:rr);
       elseif rem(r,2)==1
          rr = F(r+1,r+1)-F(r+1,(r-1)/2)-F((r+1)/2,(r-1)/2)-1;
          T(r,1:rr,1:rr) = T(r-1,1:rr,1:rr);
       else
          T(r,1:rr,1:rr) = T(r-1,1:rr,1:rr);
          rr = rr+1;
          T(r,rr,1) = -1;
       end
       for i1=rr+1:m-1
           T(r,i1,1) = (-1)^(l(i1)-1)*f(l(i1)-1);
           lam0 = p(i1,1);
           lam1 = p(i1,2:l(i1));
           ind1 = part_ind(lam1);
           r0 = r-lam0;
           for i=1:ind1-1
               bb = pp{r0}(i,:);
               bb(bb==0) = [];
               ind2 = part_ind(sort([lam0 bb],'descend'));
               T(r,i1,ind2) = T(r0,ind1,i);
           end
           j = 1;
           while j<l(i1)
              lam1(j) = lam1(j)+lam0;
              ind1 = part_ind(sort(lam1,'descend'));
              lam1(j) = lam1(j)-lam0;
              c = sum(lam1==lam1(j));
              for i=2:ind1
                  if T(r,ind1,i)~=0
                     T(r,i1,i) = T(r,i1,i)-c*T(r,ind1,i);
                  end
              end
              j = j+c;
           end
       end
       for j1=1:m-1
           c = 1;
           for i2=1:p(j1,1)
               v = sum(p(j1,:)==i2);
               if v>0
                  c = c*f(v)*i2^v;
               end
           end
           T(r,m,j1) = (-1)^(r-l(j1))*round(f(r)/c);
       end
   end
   T = squeeze(T(k,:,:));

function y = part_ind(lam)
%
%  This function takes an integer partition lam of k and returns the location of 
%  lam within the list of integer partitions with |kappa|=k, where kappa is 
%  arranged in reverse lexicographical order.
%
   n1 = sum(lam);
   y = F(n1,n1);
   for ii=1:length(lam)
       if lam(ii)>1
          k2 = lam(ii);
          y = y-F(n1,k2-1);
          n1 = n1-k2;
       else
          break
       end
   end
end

end
