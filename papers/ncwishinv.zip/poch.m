function y = poch(a,k,alpha)
if nargin==2
   alpha = 2;
end
y = 1;
for i=1:length(k)
    y = y*prod(a-(i-1)/alpha+[0:k(i)-1]);
end
