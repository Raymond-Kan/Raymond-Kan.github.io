These are programs for my paper "Properties of the Inverse of a Noncental
Wishart Matrix" (with Grant Hillier)
If you have questions, comments, or bug reports, please send them to 
Raymond.Kan@rotman.utoronto.ca

Raymond Kan
Rotman School of Management
University of Toronto

Note 1: For the comptuation of hypergeometric function with matrix argument,
        you need mhg.m and mhgi.m.  I include the mex files for 64 bits Window.
        The programs can be downloaded from Plaemn Koev's website at
        http://math.mit.edu/~plamen/software/mhgref.html
        
Note 2: Currently, invwishzonal.m defaults to truncate the infinite series at M=22.
        Larger M would take a much longer time to finish.

Version 1.0: 4/10/2018, initial release
Version 1.1: 4/20/2021, minor update of dk.m

Main programs:
invwish.m: Compute the diagonal elements of E[W^{-1}], where W~W_m(n,I_m,diag(d))
invwish2.m: Compute the diagonal elements of E[W^{-1}], where W~W_2(m,I_2,diag(d))
invwisha.m: Compute the diagonal elements of E[W^{-1}], where W~W_m(n,I_m,a*I_m)
invwisha2.m: Compute the diagonal elements of E[W^{-1}], where W~W_2(n,I_2,a*I_2)
invwishdet.m: Compute E[|W|^{-k}], where W~W_m(n,I_m,diag(d))
invwisht.m: Compute E[tr(W^{-k})], where W~W_m(n,I_m,diag(d))
invwisht2.m: Compute E[tr(W^{-k})], where W~W_2(n,I_2,diag(d))
invwishck.m: Compute E[C_k(W^{-1})] (top order zonal polynomial), where W~W_m(n,I_m,diag(d))
invwishzonal.m: Compute E[C_\kappa(W^{-1})], where W~W_m(n,I_m,diag(d))
invwishzonal2.m: Compute E[C_{(k1,k2)}(W^{-1})], where W~W_2(n,I_2,diag(d))

Auxiliary programs:
cjack.m: Compute zonal polynomials
cjackpqi.m: Compute the product of zonal polynomials of identity matrix and the hypegeometric 
            function coefficients
dinvkd.m: Compute expansion of zonal polynomials in terms of power-sum symmetric functions
dkd.m: Compute transition matrices between zonal polynomials and power-sum symmetric 
       functions
gcoeffmd.m: Compute linearization coefficient g^{\kappa,\lambda}^\phi for a fixed \kappa
            and all |\lambda|=l.
ip_desc.m: Create integer partitions for an integer k, sorted in reverse lexicographical
           order
lrcoeff.m: Compute Littlewood-Richardson coefficients
mtop2.m: Compute transition matrix that expresses augmented monomial symmetric functions as
         linear combination of power-sum symmetric functions
poch.m: Compute generalized Pochhammer symobol

Demo programs:
example1.m: Compute E[W^{-1}]
example2.m: Compute E[C_\kappa(W^{-1})]

