%
%   This program enumerates bracelets with length of n
%   and k colors, permutations are in lexicographical order.
%   Reference: Generating bracelets in constant amortized time,
%   J. Sawada, SIAM Journal on Computing, Vol. 31, No. 1 
%   (2001) 259-268
%
function y = bracegen(n,k)
a = ones(1,n);
d = divisor(n);
nk = 0;
for i=1:length(d)
    nk = nk+totient(d(i))*k^(n/d(i));
end
if rem(n,2)==0
   bk = nk/(2*n)+0.25*(k+1)*k^(n/2);
else
   bk = nk/(2*n)+0.5*k^((n+1)/2);
end
y = zeros(bk,n);
count = 0;
gen(1,1,1,0,0,false)

function gen(t,p,r,u,v,RS)
if t-1>(n-r)/2+r
   if a(t-1)>a(n-t+2+r)
      RS = false;
   elseif a(t-1)<a(n-t+2+r)
      RS = true;
   end
end
if t>n
   if ~RS&&mod(n,p)==0
      count = count+1;
      y(count,:) = a-1;
   end
else
   if t-p==0
      a(t) = 1;
   else
      a(t) = a(t-p);
   end
   if a(t)==a(1)
      v = v+1;
      if u==t-1
         u = t;
      end
   else
      v = 0;
   end
   if t~=n||u==n||a(n)~=a(1)
      if u==v    % testing starts when we find u=v
         rev = 0;
         j = u+1;
         while rev==0&&j<(t+1)/2
            rev = sign(a(j)-a(t-j+1));
            j = j+1;            
         end
         if rev<=0  
            if rev<0
               gen(t+1,p,r,u,v,RS)
            else
               gen(t+1,p,t,u,v,false)
            end
         end
      else
         gen(t+1,p,r,u,v,RS)
      end
   end 
   if u==t  
      u = u-1;
   end  
   for j=a(t)+1:k
       a(t) = j;
       if t==1
% in the paper, it is gen(t+1,t,r,1,1,RS),
% but this is corrected on Joe Sawada's website
          gen(t+1,t,1,1,1,RS)
       else
          gen(t+1,t,r,u,0,RS)
       end
   end
end

end
end