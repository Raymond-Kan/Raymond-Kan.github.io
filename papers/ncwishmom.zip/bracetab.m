%
%   This Matlab function produces the tables of the binary bracelets
%   of length 1 to k.  A binary string of length i (0 for Sigma and 1
%   for Lambda) is identified by its code, i.e., the integer that has
%   the string as its binary representation (the first element is the
%   most significant bit), and it is stored at position 2^i-1+code of
%   the tables.  Two strings belong to the same bracelet when one is a
%   rotation or the reverse of a rotation of the other, and the
%   lowest representation of a bracelet is the string with the
%   smallest code.  The bracelets of a given length are listed in
%   increasing order of their lowest representations, which is the
%   order produced by Sawada's algorithm.
%   Input
%   k: maximum length
%   Output
%   bid: bid(2^i-1+code) is the index of the bracelet of the string
%        among the bracelets of length 1 to k (bracelets of length i
%        have indices tcount(i)+1 to tcount(i+1))
%   low: low(2^i-1+code) is true when the string is the lowest
%        representation of its bracelet
%   rlow: rlow(2^i-1+code) is true when the reverse of the string is
%         the lowest representation of its bracelet
%   tcount: tcount(i+1) is the number of bracelets of length 1 to i
%   bind: bind{i} is the matrix whose rows are the lowest
%         representations of the bracelets of length i
%
function [bid,low,rlow,tcount,bind] = bracetab(k)
   nt = 2*(2^k-1);
   bid = zeros(nt,1);
   low = false(nt,1);
   rlow = false(nt,1);
   tcount = zeros(k+1,1);
   bind = cell(1,k);
   for i=1:k
       ni = 2^i;
       code = (0:ni-1)';
%  Rows of w are the binary strings of length i
       w = rem(floor(code*2.^(1-i:0)),2);
       p2 = 2.^(i-1:-1:0)';
       wr = w(:,i:-1:1);
       rcode = wr*p2;
%  Smallest code among the rotations of the string and of its reverse
       cmin = min(code,rcode);
       for j=1:i-1
           w = w(:,[2:i 1]);
           wr = wr(:,[2:i 1]);
           cmin = min(cmin,min(w*p2,wr*p2));
       end
       islow = cmin==code;
       ind = zeros(ni,1);
       ind(islow) = 1:sum(islow);
       ii = ni-1+code;
       bid(ii) = tcount(i)+ind(cmin+1);
       low(ii) = islow;
       rlow(ii) = islow(rcode+1);
       tcount(i+1) = tcount(i)+sum(islow);
       cl = code(islow);
       bind{i} = rem(floor(cl*2.^(1-i:0)),2);
   end
