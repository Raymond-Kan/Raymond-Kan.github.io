%
%  This Matlab function produces transition matrices
%  from power-sum symmetric functions to zonal 
%  polynomials (D) and from zonal polynomials to
%  power-sum polynomials (Di).
%  Input
%  k: order of the polynomials
%  opt: (optional) when opt is 'factors', the program returns the
%       three factors of Di instead of D and Di,
%       [C,ck1,T] = dk(k,'factors'), where Di = diag(ck1)*C*T. 
%       C is the matrix of the coefficients of Z_kappa in terms of 
%       the monomial symmetric functions (a matrix of integers, in 
%       double precision when it is exact and symbolic otherwise),
%       ck1 is the vector of C_kappa/Z_kappa, and T is the 
%       transition matrix from the monomial symmetric functions to 
%       the power-sum symmetric functions.  This saves the two 
%       matrix multiplications when only a few linear combinations 
%       of the rows or columns of D and Di are needed.
%  Output
%  D: transition matrix from power-sum symmetric functions to 
%     zonal polynomials
%  Di: transition matrix from zonal polynomials to power-sum 
%      symmetric functions
%  Note: The outputs are exact (symbolic).  To keep the number of
%        symbolic operations small, the integers that are needed 
%        are computed in double precision whenever they are less 
%        than 2^53, and the symbolic operations are applied to 
%        whole vectors and matrices.
%
function [D,Di,T] = dk(k,opt)
   s = ip_desc(k);
   f = cumprod(sym(1:2*k));
   s1 = cumsum(s,2);
   m = size(s,1);
   l = sum(s>0,2);   % l is a vector of number of parts for each integer partition of k
   rho = sum(s.*(s-repmat(1:k,m,1)),2);
%  v(i,j) is the number of parts of the ith partition that are equal to j
   v = zeros(m,k);
   for j=1:k
       v(:,j) = sum(s==j,2);
   end
   d = prod(reshape(f(max(v(:),1)),m,k),2);
%  Exact length of the vector a:  the number of admissible pairs
%  (\lambda,\mu) with \lambda < \mu <= (k) is
%     N(k) = sum_{s=2}^{k} T(floor(s/2))*p(k-s),
%  where T(n) = n(n+1)/2 and p(j) is the number of integer partitions
%  of j.  See note26a.tex for the derivation.
   pp = [1 zeros(1,k)];   % pp(j+1) = p(j)
   for i=1:k
       for j=i:k
           pp(j+1) = pp(j+1)+pp(j-i+1);
       end
   end
   w = floor((2:k)/2);
   m1 = sum(w.*(w+1)/2.*pp(k-1:-1:1));
%  a is a vector which is used to store a_{\lambda}(\mu) for (k)>=\mu>\lambda
%  alist is used to store the index for \mu
%  count is used to store the number of admissible \mu's for a given \lambda
   a = zeros(m1,1);
   alist = zeros(m1,1);
   count = zeros(max(m-1,1),1);
   for jj=2:m-1
       count(jj) = count(jj-1);
       m1 = l(jj);
       kappa = s(jj,1:m1);
       for kk=1:jj-1
           if check2(kappa,s(kk,1:l(kk)))
              for q2=m1:-1:2
                  if kappa(q2)~=s(kk,q2)
                     break
                  end
              end
              t = s(kk,q2);
              while kappa(q2)==s(kk,q2-1)
                 q2 = q2-1;
              end
              t = kappa(q2)-t;
              for q1=q2-1:-1:1
                  if s(kk,q1)==kappa(q1)+t||(kappa(q1)~=s(kk,q1)&&kappa(q1-1)==s(kk,q1))
                     break
                  end
              end
              if kappa(q1)==kappa(q2)
                 w = v(jj,kappa(q1));
                 w = w*(w-1)/2;
              else
                 w = v(jj,kappa(q1))*v(jj,kappa(q2));
              end
              count(jj) = count(jj)+1;
              a(count(jj)) = (kappa(q1)-kappa(q2)+2*t)*w;
              alist(count(jj)) = kk;
           end
       end
   end
%
%  ck1(i) = 2^k*k!*prod_{i1<j1}(kappa1(i1)-kappa1(j1))/prod_{i1}(kappa1(i1)+m1)!,
%  where kappa1(i1) = 2*kappa(i1)-i1 and m1 is the number of parts of
%  kappa, and C(i,i) is a product of k integers.  The integers are 
%  stored in the rows of dif and fac (after multiplying them 
%  together as long as the product is less than 2^53), and arg 
%  stores kappa1+m1. 
%
   dif = ones(m,1);
   fac = ones(m,1);
   arg = ones(m,k);
   for ii=1:m
       m1 = l(ii);
       kappa = s(ii,1:m1);
       kappa1 = 2*kappa-(1:m1);
       arg(ii,1:m1) = kappa1+m1;
       x = zeros(1,m1*(m1-1)/2);
       c = 0;
       for i1=1:m1-1
           x(c+1:c+m1-i1) = kappa1(i1)-kappa1(i1+1:m1);
           c = c+m1-i1;
       end
       x = packprod(x);
       dif(ii,1:length(x)) = x;
       x = zeros(1,k);
       c = 0;
       for i1=1:m1
           for j1=i1:m1-1
               if kappa(j1)>kappa(j1+1)
                  g = 2*kappa(i1)-2*kappa(j1)-i1+j1+1:2:2*kappa(i1)-2*kappa(j1+1)-i1+j1-1;
                  x(c+1:c+length(g)) = g;
                  c = c+length(g);
               end
           end
           g = 2*kappa(i1)-2*kappa(m1)-i1+m1+1:2:2*kappa(i1)-i1+m1-1;
           x(c+1:c+length(g)) = g;
           c = c+length(g);
       end
       x = packprod(x);
       fac(ii,1:length(x)) = x;
   end
   dif(dif==0) = 1;
   fac(fac==0) = 1;
   ck1 = 2^k*f(k)*prod(sym(dif,'f'),2)./prod(reshape(f(arg(:)),m,k),2);
%
%  C is the transition matrix from Z_kappa to monomials
%  diag(ck1)*C is the transition matrix from C_kappa to monomials   
%  C is a matrix of integers.  It is computed in double precision
%  when this is exact, and symbolically otherwise.
%
   ok = size(fac,2)==1&&k<=18;
   if ok
      C = diag(fac);
      C(:,m) = prod(1:k);
      [C,ok] = zcoef(C,rho,s1,a,alist,count);
   end
   if ~ok
      C = diag(prod(sym(fac,'f'),2));
      C(:,m) = f(k);
      C = zcoef(C,rho,s1,a,alist,count);
   end
   T = mtops(k);
   T = T./repmat(d,1,m);
   if nargin>1&&strcmpi(opt,'factors')
      D = C;
      Di = ck1;
   else
      Di = C*T;
      D = Di.'./repmat(Di(1,:).',1,m);
      Di = repmat(ck1,1,m).*Di;
   end
end

%
%  zcoef: fill in the elements of C above the diagonal, one column
%  at a time.  For a column mu, the element of row kappa is nonzero 
%  only when kappa dominates mu, and it is a linear combination of 
%  the elements of row kappa in the columns in alist, divided by
%  rho(kappa)-rho(mu).  When C is in double precision, ok is false
%  when an integer that is not less than 2^53 is met.
%
function [C,ok] = zcoef(C,rho,s1,a,alist,count)
   m = size(C,1);
   ok = true;
   isd = isa(C,'double');
   for jj=2:m-1
       ii = find(all(s1(1:jj-1,:)>=repmat(s1(jj,:),jj-1,1),2));
       i1 = count(jj-1)+1:count(jj);
       x = C(ii,alist(i1))*a(i1);
       if isd&&max(abs(x))>=2^53
          ok = false;
          return
       end
       C(ii,jj) = x./(rho(ii)-rho(jj));
   end
end

%
%  packprod: multiply the positive integers in x together as long as
%  the product is less than 2^53, so that prod(y) = prod(x) and y has
%  fewer elements than x
%
function y = packprod(x)
   y = 1;
   j = 1;
   for i=1:length(x)
       if y(j)*x(i)>=2^53
          j = j+1;
          y(j) = 1;
       end
       y(j) = y(j)*x(i);
   end
end

function y = check2(a,b)
   m1 = length(a);
   m2 = length(b);
   if m2<m1-1||m2>m1
      y = false;
      return
   end
   i1 = 1;
   i2 = 1;
   c = 0;
   while i2<=m2&&i1<=m1
      if a(i1)==b(i2)
         i1 = i1+1;
         i2 = i2+1;
      elseif a(i1)<b(i2)
         i2 = i2+1;
      else
         i1 = i1+1;
         c = c+1;
      end
   end
   c = c+m1-i1+1;
   y = c<=2;
end
