%
%   This Matlab function takes an index with n
%   elements and determines if it has the lowest
%   representation of the bracelet.  
%   Input
%   A: an array of n elements 
%   Output
%   brace: a logical variable, which is equal
%          to True when A has the lowest 
%          representation of the bracelet
%   y: lowest representation of the bracelets
%      that can be constructed from A.
%
function [brace,y] = isbrace(A)
   n = length(A);
   y = A;
   A1 = A(n:-1:1);
   for i=1:n
       if y(i)~=A1(i)
          if y(i)>A1(i)
             y = A1;
          end
          break
       end
   end
   A0 = A;
   for i=1:n-1
       A0 = circshift(A0,-1);
       for j=1:n
           if y(j)~=A0(j)
              if y(j)>A0(j)
                 y = A0;
              end
              break
           end
       end
       A1 = circshift(A1,-1);
       for j=1:n
           if y(j)~=A1(j)
              if y(j)>A1(j)
                 y = A1;
              end
              break
           end
       end
   end
   brace = all(y==A);
   