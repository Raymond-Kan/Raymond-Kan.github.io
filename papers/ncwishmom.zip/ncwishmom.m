%
%   This Matlab function computes E[W^k], where
%   W ~ W_m(n,\Sigma,\Sigma^{-1}*Lambda).  It
%   makes use of a numerical algorithm that is
%   based on the expectation of product of
%   quadratic forms, and it is slow when the size
%   of W is large.
%   Input
%   k: order of the moment
%   n: degrees of freedom
%   S: Sigma
%   L: Lambda
%   Output
%   y: E[W^k]
%
function y = ncwishmom(k,n,S,L)
   if k<=1
      y = n*S+L;
      return
   end
   m = size(S,1);
   nm = m*(m+1)/2;   % number of unique elements in W
   count = 0;
   A0 = zeros(m,m,nm);
   for j=1:m
       for i=j:m
           count = count+1;
           A0(i,j,count) = 0.5;
           A0(j,i,count) = A0(j,i,count)+0.5;
       end
   end
   Q = qprodmom(A0,S,L,n,k);
%
%   Create a matrix of binomial coefficients of C(i,j) = nchoosek(i-1,j-1)
%
   C = zeros(nm+k+1,nm+1);
   C(:,1) = 1;
   for j=2:nm+1
       C(j:end,j) = cumsum(C(j-1:nm+k,j-1));
   end
   y = zeros(m);
   x = [0 ones(1,k)];  
   nind = m^(k+1);
   for i=1:nind
       for ii=1:k+1
           if x(ii)<m
              x(ii) = x(ii)+1;
              break
           else
              x(ii) = 1;
           end
       end
%  Only compute the lower diagonal part of E[W^k]
       if x(1)>=x(k+1)
          y(x(1),x(k+1)) = y(x(1),x(k+1))+Q(kindex(x));
       end
   end
%  Get the upper triangular part of E[W^k] by symmetry
   for i1=1:m-1
       for j1=i1+1:m
           y(i1,j1) = y(j1,i1);
       end
   end      

function y1 = kindex(x1)
%
%  x1=[i1,...,i_{k+1}] is a (k+1)-vector, y1 tells us 
%  the location where E[Q_{i1,i2}*Q_{i2,i3}*...*Q_{i_k,i_k+1}]
%  is stored within the Q vector.
% 
   x2 = [x1(1) kron(x1(2:k),[1 1]) x1(k+1)];
   x2ind = zeros(1,nm);
   for k1=1:k
       x3 = x2(2*k1-1:2*k1);
       if x3(1)<x3(2)
          x3 = fliplr(x3);
       end
       j = x3(1)+(x3(2)-1)*(2*m-x3(2))/2;
       x2ind(j) = x2ind(j)+1;
   end
   y1 = 1;
   s = cumsum(fliplr(x2ind));
   for rr=1:nm-1
       if x2ind(rr)>0
          n1 = nm-rr+1;
          y1 = y1+C(s(n1)+n1,n1)-C(s(n1-1)+n1,n1);
       end
   end
end


end