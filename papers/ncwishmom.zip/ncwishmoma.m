%
%   This Matlab function computes E[W^k], where
%   W ~ W_m(n,\Sigma,\Sigma^{-1}*Lambda).  It uses
%   the analytical formula of E[W^k] from ncwishmoms.m.
%   Input
%   k: order of the moment
%   n: degrees of freedom
%   S: Sigma
%   L: Lambda
%   nn: (optional) first output of ncwishmoms(k)
%   cc: (optional) second output of ncwishmoms(k)
%   Output
%   y: E[W^k]
%   Note: When nn and cc are not provided, they are loaded from
%         the file q<k>.mat (the output of q2.m to q10.m) when it
%         is on the path, and they are computed by ncwishmoms(k)
%         otherwise.  When E[W^k] is needed for many different
%         (n,S,L), it is faster to call ncwishmoms(k) once and
%         provide nn and cc.
%
function y = ncwishmoma(k,n,S,L,nn,cc)
   if k==0
      y = eye(size(S,1));
      return
   elseif k==1
      y = n*S+L;
      return
   end
   if nargin<6
      qfile = sprintf('q%d.mat',k);
      if exist(qfile,'file')
         q = load(qfile,'nn','cc');
         nn = q.nn;
         cc = q.cc;
      else
         [nn,cc] = ncwishmoms(k);
      end
   end
%
%  bid gives the index of the bracelet of each binary string (0 for
%  Sigma and 1 for Lambda), and low tells us whether a string is the
%  lowest representation of its bracelet.
%
   [bid,low,~,tcount] = bracetab(k);
%
%  Create a vector of the traces of the bracelets with length less
%  than k
%
   [~,tr] = prodsum(S,L,k-1,bid,low,[],tcount(k));
%
%  Obtain the coefficients.  The terms of all the bracelets are put 
%  together: term i is the polynomial of n in nn1{i} times the 
%  product of the traces in cc1{i}.
%
   tc = tcount(k+1);
   nn1 = [nn{:}];
   cc1 = [cc{:}];
   nt = length(nn1);
   ln = cellfun('length',nn1);
   i1 = repelem(1:nt,ln);                 % term of each coefficient
   c1 = cumsum(ln)-ln;
   pw = (1:sum(ln))-c1(i1)-1;             % power of n of each coefficient
   v = accumarray(i1(:),reshape([nn1{:}].*n.^pw,[],1),[nt 1]);
   i1 = repelem(1:nt,cellfun('length',cc1));
   if ~isempty(i1)
      v = v.*accumarray(i1(:),reshape(tr([cc1{:}]),[],1),[nt 1],@prod,1);
   end
   i1 = repelem(1:tc,cellfun('length',nn));
   c = accumarray(i1(:),v,[tc 1]);
%
%  E[W^k] is the sum of the products of at most k of Sigma and Lambda,
%  with each product multiplied by the coefficient of its bracelet
%
   y = prodsum(S,L,k,bid,low,c,0);
end

%
%  prodsum: go through the products of at most K of S and L.  A
%  product of i matrices is a binary string of length i (0 for S and
%  1 for L), and the strings of length K are visited in ascending
%  order, so that each product is obtained from a shorter one with
%  one matrix multiplication.
%  Output
%  y: sum of c(index of the bracelet of the product)*product (not
%     computed when c is empty)
%  tr: tr(i) is the trace of the product for the ith bracelet,
%      i=1,...,nt
%
function [y,tr] = prodsum(S,L,K,bid,low,c,nt)
   m = size(S,1);
   y = zeros(m);
   tr = zeros(nt,1);
   A = cat(3,S,L);
   P = zeros(m,m,K);        % P(:,:,i) is the product of the first i matrices
   for x=0:2^K-1
%  The first i0-1 elements of the string are the same as in the previous string
       if x==0
          i0 = 1;
       else
          i0 = K+1-find(bitget(x,1:K),1);
       end
       for i=i0:K
           if i==1
              P(:,:,1) = A(:,:,bitget(x,K)+1);
           else
              P(:,:,i) = P(:,:,i-1)*A(:,:,bitget(x,K+1-i)+1);
           end
           ii = 2^i-1+floor(x/2^(K-i));
           if isempty(c)
              if low(ii)
                 tr(bid(ii)) = trace(P(:,:,i));
              end
           else
              y = y+c(bid(ii))*P(:,:,i);
           end
       end
   end
end
