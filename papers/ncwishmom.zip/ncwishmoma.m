%
%   This Matlab function computes E[W^k], where
%   W ~ W_m(n,\Sigma,\Sigma^{-1}*Lambda).  It uses
%   analytical formula but it can only compute
%   E[W^k] for k<=10.
%   Input
%   k: order of the moment
%   n: degrees of freedom
%   S: Sigma
%   L: Lambda
%   Output
%   y: E[W^k]
%
function y = ncwishmoma(k,n,S,L)
   if k==1
      y = n*S+L;
      return
   end
   if k>10
      fprintf(' Cannot handle k>10 for the moment!\n')
      y = NaN;
      return
   end
   nn = [];
   cc = [];
   eval(['load q' num2str(k) ' nn cc'])  
%
%  Create a vector of trace of the bracelets 
%
   m = size(S,1);
   SS = zeros(m,m,length(nn));
   count = 0;
   tr = [];
   for i=1:k
       ci = 2^i;
       ind2 = [];
       count1 = 0;
       for j=1:ci
           ind0 = dec2bin(j-1,i)-'0';
           Q = matprod(ind0);
           if isbrace(ind0)
              count1 = count1+1;
              ind2 = [ind2; ind0];
              if i<k
                 tr = [tr; trace(Q)];
              end
              SS(:,:,count+count1) = Q;
           else
              [~,indb] = isbrace(ind0);
              ii = find(ismember(ind2,indb,'rows'),1);        
              SS(:,:,count+ii) = SS(:,:,count+ii)+Q;
           end
       end
       count = count+count1;
   end
%
%  Obtain the coefficients   
%
   y = zeros(m);
   for i=1:count
       c = 0;
       for j=1:length(nn{i})
           nnj = polyval(fliplr(nn{i}{j}),n);
           if length(cc{i}{j})>0
              c = c+nnj*prod(tr(cc{i}{j}));
           else
              c = c+nnj;
           end
       end
       y = y+c*SS(:,:,i);
   end

function y1=matprod(inda)
   y1 = eye(m);
   for jj=1:length(inda)
       if inda(jj)==0
          y1 = y1*S;
       else
          y1 = y1*L;
       end
   end
end

end