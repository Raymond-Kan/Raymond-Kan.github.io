%
%   This Matlab function computes E[W^k], where
%   W ~ W_m(n,\Sigma,\Sigma^{-1}*Lambda).  The 
%   program provides symbolic expression of E[W^k].  
%   It is expressed in the form of
%   E[W^k] = sum_{i=1}^C(k) tind(i)*sind(i),
%   where C(k) is the number of terms, 
%   tind(i) are scalar coefficients, and 
%   sind(i) are sum of various products
%   of Sigma and Lambda that belong to the
%   same necklace.
%   Input
%   k: order of moment of W
%   Output
%   nn: polynomial of n, which is multiplied to each term
%       in tt to obtain the coefficients
%   tt: different product of traces, represented by a cell
%       array, with each element as a vector that correponds 
%       to the traces in the product
%   sind: sum of products of Sigma and Lambda that has the
%         same bracelet
%   tind: coefficients that are multiplied to sind to obtain
%         E[W^k] 
%
function [nn,tt,sind,tind] = ncwishmoms(k)
   [c,s,ahind] = qprodind(k);
   p = ip_desc(k);
   np = size(p,1);
   ck = 2^k;
   ind0 = [0 kron(1:k-1,[1 1]) k];
%  Each row of ind contains rotations of different pairs 
%  of elements in ind0.  There are altogether 2^k
%  possible combinations of rotations.
   ind = repmat(ind0,ck,1);
   for ii=1:ck
       rev = dec2bin(ii-1,k)-'0';
       for jj=1:k
           if rev(jj)==1
              ind(ii,[2*jj-1 2*jj]) = ind(ii,[2*jj 2*jj-1]);
           end
       end
   end
%
%  Create the bracelets. bind{i} stores the unique binary bracelets
%  with with length i, bind1{i} stores the index for each binary
%  bracelet.
%
   tcount = zeros(k+1,1);
   sind = cell(1,k);
   bind = cell(1,k);
   bind1 = cell(1,k);
   cc2 = 2.^(k-1:-1:0)';
   for i=1:k
       bind{i} = bracegen(i,2);
       bind1{i} = zeros(2^i,1);
       lb = size(bind{i},1);
       bb1 = bind{i}*cc2(k-i+1:k)+1;
       bind1{i}(bb1) = 1:lb;
       tcount(i+1) = tcount(i)+lb;
   end
   tc = tcount(end);
%
%  Create the bracelet index.  
%  
   for i=1:k
       for j=1:2^i
           ind0 = dec2bin(j-1,i)-'0';
           ii = bind1{i}(j);
%  For entries that are not the smallest bracelet, find 
%  the mapping to the smallest bracelet.
           if ii==0
              [~,tt1] = isbrace(ind0);
              bb1 = tt1*cc2(k-i+1:k)+1;
              ii = bind1{i}(bb1);
%  Negative sign indicates that it is not the smallest bracelet
              bind1{i}(j) = -ii;
           end
       end
   end
%
%  Compute the coefficients associated with each bracelet.
%  nn and tt together deterimines the coefficients associated
%  with each sind.  nn stores the polynomial of n, i.e.,
%  nn(1)+nn(2)*n+nn(3)*n^2+ ... that is multiplied to each
%  cell of tt, where the numbers in the each of tt represent
%  the trace of different products of Sigma and Lambda.
%
   tt = cell(tc,1);
   nn = cell(tc,1);
   v = uint8(1:k);
   ii = 0;
   count = 0;
   for i=1:np
       kappa = p(i,:);
       kappa(kappa==0) = [];
       r = length(kappa);
       p2 = cumsum(kappa);
       p1 = [1 p2(1:r-1)+1];
       ku = sort(unique(kappa),'descend');  % unique kappa_i, in descending order
       pf = 1;
       for j=1:length(ku)
           pf = pf*(1+sum(kappa==ku(j)));
       end
       ah = cell(1,r);
       for j=1:pf
           count = count+1;
           sij = s{count};
           ahindij = ahind(count,1:r);
           na = sum(~ahindij);
           for ii=1:length(sij)
               ah1 = nthperm(v,sij(ii));
               for j1=1:r
                   ah{j1} = ah1(p1(j1):p2(j1));
               end
               [ss1,tind] = qprodc(ah(~ahindij),ah(ahindij),ind,bind1,tcount);
               for i1=1:length(ss1)
                   ssi = ss1(i1);
                   if ssi>0       
%
%  Check if the elements of tt2 are already in the list
%                      
                       tt2j = tind{i1};
                       aa = NaN;
                       ttl = length(tt{ssi});
                       for jj=1:ttl
                           if isequal(tt{ssi}{jj},tt2j)
                              aa = jj;
                              break
                           end
                       end
                       if isnan(aa) 
                          aa = ttl+1;
                          tt{ssi}{aa} = tt2j;
                          nn{ssi}{aa} = zeros(1,k+1);
                       end
                       nn{ssi}{aa}(na+1) = nn{ssi}{aa}(na+1)+c(count);
                   end
               end
           end
       end
   end  
%
%  Cleanup the entiries of nn to remove trailing zeros
%
   for i=1:tc
       for j=1:length(nn{i})
           n1 = nn{i}{j};
           nn{i}{j} = n1(1:find(n1,1,'last'))/ck;
       end
   end
%
%  Create the string for each bracelet
%  
   if nargout>2
      SL = char('SL');
      sind = cell(1,k);
      for i=1:k
          nb = tcount(i+1)-tcount(i);
          ss = strings(nb,1);
          for j=1:2^i
              ind0 = dec2bin(j-1,i)-'0';
              ii = abs(bind1{i}(j));
              if strlength(ss(ii))>0
                 ss(ii) = append(ss(ii),'+');
              end
              ss(ii) = append(ss(ii),SL(ind0+1));
          end
          sind{i} = ss;
      end
   end
%
%  Create the string representation of the coefficient
%
   if nargout>3
      ssind = cell(tc,1);
      tind = cell(tc,1);
      for i=1:k-1
          for j=1:size(bind{i},1)
              ssind{tcount(i)+j} = append('t',SL(bind{i}(j,:)+1));
          end
      end
      for i=1:tc
          tt2 = tt{i};
          tt1 = '';
          for j=1:length(tt2) 
              nn1 = nn{i}{j};
              lnn1 = length(nn1);
%  Terms that do not involve traces.  For this case, the length(tt2) is equal to 1,
%  and we can directly set tt1.
              if isempty(tt2{j})
                 j1 = find(nn1,1);
                 if j1==1
                    tt1 = num2str(nn1(1));
                    j1 = 2;
                    if lnn1>1
                       if nn1(2)==1
                          tt1 = append(tt1,'+n');
                       elseif nn1(2)>1
                          tt1 = append(tt1,'+',num2str(nn1(2)),'*n');
                       end
                    end
                 else
                    if nn1(j1)==1
                       tt1 = 'n';
                    else
                       tt1 = append(num2str(nn1(j1)),'*n');
                    end
                    if j1>2
                       tt1 = append(tt1,'^',num2str(j1-1));
                    end
                 end                     
                 for jj=j1+1:lnn1
                     if nn1(jj)~=0
                        if nn1(jj)==1
                           tt1 = append(tt1,'+n^',num2str(jj-1));
                        else
                           tt1 = append(tt1,'+',num2str(nn1(jj)),'*n^',num2str(jj-1));
                        end
                     end
                 end
              else
%  Terms that involve traces
%  tt3 stores the string for the product of traces
                 j1 = 1;
                 ltt2 = length(tt2{j});
                 tt3 = '';
                 while j1<=ltt2 
                     tt2j = tt2{j}(j1);
                     if j1==1
                        tt3 = ssind{tt2j};
                     else
                        tt3 = append(tt3,'*',ssind{tt2j});
                     end
                     j1 = j1+1;
                     if j1<=ltt2&&isequal(tt2{j}(j1),tt2j)
                        cc = 2;
                        while j1<=ltt2
                           j1 = j1+1;
                           if j1>ltt2||~isequal(tt2{j}(j1),tt2j)
                              tt3 = append(tt3,'^',num2str(cc));
                              break
                           end
                           cc = cc+1;
                        end
                     end
                 end
%   tt4 stores the string for the polynomial of n
                 j1 = find(nn1,1);
                 if j1==1
                    tt4 = num2str(nn1(1));
                    j1 = 2;
                    if lnn1>1
                       if nn1(2)==1
                          tt4 = append(tt4,'+n');
                       elseif nn1(2)>1
                          tt4 = append(tt4,'+',num2str(nn1(2)),'*n');
                       end
                    end
                 else
                    if nn1(j1)==1
                       tt4 = 'n';
                    else
                       tt4 = append(num2str(nn1(j1)),'*n');
                    end
                    if j1>2
                       tt4 = append(tt4,'^',num2str(j1-1));
                    end
                 end                     
                 for jj=j1+1:lnn1
                     if nn1(jj)~=0
                        if nn1(jj)==1
                           tt4 = append(tt4,'+n^',num2str(jj-1));
                        else
                           tt4 = append(tt4,'+',num2str(nn1(jj)),'*n^',num2str(jj-1));
                        end
                     end
                 end
                 if nnz(nn1)==1
                    if isequal(tt4,'1')
                       tt1 = append(tt1,'+',tt3);
                    else
                       tt1 = append(tt1,'+',tt4,'*',tt3);
                    end
                 else
                    tt1 = append(tt1,'+(',tt4,')*',tt3);
                 end
              end
          end
%  Get rid of the initial plus sign if it is present
          if tt1(1)=='+'
             tt1(1) = [];
          end
          tind{i} = tt1;
      end
   end        
