k = 10;
[nn,cc,ss,tt] = ncwishmoms(k);
save q10 nn cc ss tt 
delete q10.out
diary q10.out
vertcat(ss{:})
string(tt)
diary off

