k = 2;
[nn,cc,ss,tt] = ncwishmoms(k);
save q2 nn cc ss tt 
delete q2.out
diary q2.out
vertcat(ss{:})
string(tt)
diary off

