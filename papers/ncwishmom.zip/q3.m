k = 3;
[nn,cc,ss,tt] = ncwishmoms(k);
save q3 nn cc ss tt 
delete q3.out
diary q3.out
vertcat(ss{:})
string(tt)
diary off

