k = 4;
[nn,cc,ss,tt] = ncwishmoms(k);
save q4 nn cc ss tt 
delete q4.out
diary q4.out
vertcat(ss{:})
string(tt)
diary off

