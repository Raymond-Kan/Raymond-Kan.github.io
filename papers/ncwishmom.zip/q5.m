k = 5;
[nn,cc,ss,tt] = ncwishmoms(k);
save q5 nn cc ss tt 
delete q5.out
diary q5.out
vertcat(ss{:})
string(tt)
diary off

