k = 6;
[nn,cc,ss,tt] = ncwishmoms(k);
save q6 nn cc ss tt 
delete q6.out
diary q6.out
vertcat(ss{:})
string(tt)
diary off

