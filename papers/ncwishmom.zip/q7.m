k = 7;
[nn,cc,ss,tt] = ncwishmoms(k);
save q7 nn cc ss tt 
delete q7.out
diary q7.out
vertcat(ss{:})
string(tt)
diary off

