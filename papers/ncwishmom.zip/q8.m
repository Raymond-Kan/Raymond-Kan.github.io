k = 8;
[nn,cc,ss,tt] = ncwishmoms(k);
save q8 nn cc ss tt 
delete q8.out
diary q8.out
vertcat(ss{:})
string(tt)
diary off

