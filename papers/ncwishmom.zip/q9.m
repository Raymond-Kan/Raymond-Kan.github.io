k = 9;
[nn,cc,ss,tt] = ncwishmoms(k);
save q9 nn cc ss tt 
delete q9.out
diary q9.out
vertcat(ss{:})
string(tt)
diary off

