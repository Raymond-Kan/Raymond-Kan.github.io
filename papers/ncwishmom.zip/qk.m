%
%   This Matlab function computes E[W^k] symbolically with
%   ncwishmoms.m, saves the output to qk.mat (e.g., q5.mat
%   for k=5) and writes the expressions to qk.out (e.g.,
%   q5.out for k=5).  The .mat file is used by ncwishmoma.m.
%   Input
%   k: order of the moment
%   Note: The first part of qk.out gives the linear combinations
%         of products of Sigma and Lambda (S stands for Sigma and
%         L stands for Lambda), and the second part gives their 
%         coefficients (tSSL stands for the trace of 
%         Sigma*Sigma*Lambda).  The strings are written with 
%         fprintf, so long strings are written in full.
%
function qk(k)
   [nn,cc,ss,tt] = ncwishmoms(k);
   save(sprintf('q%d.mat',k),'nn','cc','ss','tt');
   fid = fopen(sprintf('q%d.out',k),'w');
   s = cellstr(vertcat(ss{:}));
   fprintf(fid,'%s\n',s{:});
   fprintf(fid,'\n');
   s = cellstr(tt);
   fprintf(fid,'%s\n',s{:});
   fclose(fid);
end
