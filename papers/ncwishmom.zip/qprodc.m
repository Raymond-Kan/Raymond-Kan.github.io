%
%   This Matlab function produces the appropriate
%   coefficients and product of matrices which
%   corresponds to a particular product of a and
%   h variables.
%   Input:
%   a: a cell array that tells us the indices associated
%      with different \tau terms
%   h: a cell array that tells us the indices associated 
%      with different \theta terms
%   ind: a 2^k times 2k matrix that gives us all combinations
%        of rotating different pairs in (1:2*k)
%   bind1: a cell array that stores the index for each binary
%          bracelet.  When the bracelet is not the the smallest
%          bracelet, the index is set to be a negative number, which
%          maps to the smallest bracelet.
%   tcount: cumulative sum of number of bracelets from i=1 to k
%   Output:
%   ss0: an array that tells us the index for the product of
%        of Sigma and Lambda.
%   tind: a cell array that tells us the product of trace terms
%         that asscoiated with the corresponding elements of ss0
%
function [ss0,tind] = qprodc(a,h,ind,bind1,tcount)
   [nk,k2] = size(ind);
   k = k2/2; 
   na = length(a);
   nh = length(h);
   lam_ind = false(1,k);   % 0 means sigma, 1 means lambda
   key = zeros(1,k2);
   count = 0;
   for j=1:na
       aa = a{j};
       laa = length(aa);
       bb = zeros(1,2*laa);
       bb(1:2:end) = 2*aa-1;
       bb(2:2:end) = 2*aa;
       key(2*count+1:2*(count+laa)) = circshift(bb,-1);
       count = count+laa;
   end
   for j=1:nh
       aa = h{j};
       laa = length(aa);
       bb = zeros(1,2*laa);
       bb(1:2:end) = 2*aa-1;
       bb(2:2:end) = 2*aa;
       key(2*count+1:2*(count+laa)) = circshift(bb,-1);
       count = count+laa;
       lam_ind(count) = true;
   end
   ind = ind(:,key);
   ss0 = zeros(nk,1);
   tind = cell(nk,1);
   count = 0;
   ss = zeros(1,k);
   tt1 = zeros(1,k);
   tti = zeros(1,k);  % index for traces, lined up as a row vector 
   cc2 = 2.^(k-1:-1:0)';
   for ii=1:nk
       seq = ind(ii,:);
% Construct cycles based on seq
% First construct the term related to the product of Sigma and Lambda
       i1 = find(seq==0);
       m1 = ceil(i1/2);
       if rem(i1,2)==0
          j1 = i1-1;
       else
          j1 = i1+1;
       end
       sj1 = seq(j1);
% Set the element to zero to indicate that it has been used
       seq(j1) = 0; 
% ss stores the products of different S or L, with 0 for S and 1 for L
       cc = 1;
       ss(cc) = lam_ind(m1);
       while sj1<k
          i1 = find(seq==sj1,1);
          m1 = ceil(i1/2);
          if rem(i1,2)==0
             j1 = i1-1;
          else
             j1 = i1+1;
          end
          cc = cc+1;
          ss(cc) = lam_ind(m1);
          sj1 = seq(j1);
          seq(i1) = 0;
          seq(j1) = 0;
       end
%
%  Construct the coefficients which are products of traces of Sigma and Lambda
%  We do only once for each set of bracelets to reduce the computation time.
%
       count = count+1;
       jj = bind1{cc}(ss(1:cc)*cc2(k-cc+1:end)+1);
       if jj>0
          count = count+1;
          ss0(count) = jj+tcount(cc);
          cc1 = 0;   
          while any(seq)
             i1 = find(seq,1);
             m1 = ceil(i1/2);
             i0 = seq(i1);
             j1 = i1+1;
             cc = 1;
             tt1(cc) = lam_ind(m1);
             sj1 = seq(j1);
             seq(i1) = 0;
             seq(j1) = 0;
             while sj1~=i0
                i1 = find(seq==sj1,1);
                m1 = ceil(i1/2);
                if rem(i1,2)==0
                   j1 = i1-1;
                else
                   j1 = i1+1;
                end
                cc = cc+1;
                tt1(cc) = lam_ind(m1);
                sj1 = seq(j1);
                seq(i1) = 0;
                seq(j1) = 0;   
             end
             if cc==1
                jj = tt1(1)+1;
             else
                jj = abs(bind1{cc}(tt1(1:cc)*cc2(k-cc+1:end)+1))+tcount(cc);
             end
             cc1 = cc1+1;
             tti(cc1) = jj;   
          end
          tind{count} = sort(tti(1:cc1));
       end
   end
  
