%
%  This Matlab function computes the coefficients
%  and product of tau's (or a's) and theta's (or h's) 
%  for constructing the expression of expectation of a 
%  product of k quadratic forms in noncentral normal 
%  random variables.
%  Input
%  k: number of quadratic forms
%  Output
%  c: coefficient for the terms associated with a given 
%     integer partition of k and nu.
%  s: an index which tells us which permutation
%     that a term belongs to (from 1 to k!)
%  ahind: a logical array that tells us for each kappa and nu,
%         which entry is tau (false), and which entry is theta (true)
%
function [c,s,ahind] = qprodind(k)
   if k==1
% E[Q1]=a_1+h_1, where a_1=trace(A1*S) and h_1=mu'*A1*mu 
      c = [1; 1];
      s{1} = 1;
      s{2} = 1;
      ahind = [false; true];
      return
   end
   p = ip_desc(k);
   np = size(p,1);
%  ppf is to store how many nu's are possible for each partition
   ppf = zeros(np,1);                       
   for i=1:np
       kappa = p(i,:);
       kappa(kappa==0) = [];
       ku = sort(unique(kappa),'descend');  % unique kappa_i, in descending order
       pf = 1;
       for j=1:length(ku)
           pf = pf*(1+sum(kappa==ku(j)));
       end
       ppf(i) = pf;
   end
   tcount = sum(ppf);
   p1 = zeros(np,k);
   p2 = zeros(np,k);
   r = zeros(np,1);
   nn = zeros(tcount,1);
   c = zeros(tcount,1);
   s = cell(1,tcount);
   ahind = false(tcount,k);
   fack = cumprod(1:k);
   ii = 0;
   for i=1:np
       kappa = p(i,:);
       p2(i,:) = cumsum(kappa);
       p1(i,:) = [1 p2(i,1:k-1)+1];
       kappa(kappa==0) = [];
       r(i) = length(kappa);
       ku = sort(unique(kappa),'descend');  % unique kappa_i, in descending order
       kl = length(ku);
       f = zeros(1,kl);
       kf12 = k-sum(kappa==1|kappa==2);     % k-f_1-f_2
       for j=1:kl
           f(j) = sum(kappa==ku(j));
       end
       f1 = 1+f;
       h = fack(k)/prod(fack(kappa))/prod(fack(f));
       nu = zeros(1,kl);
       for j=1:ppf(i)
%  Get the nu that corresponds to j
           ii = ii+1;
%  nc tells us how many admissible permutations for (kappa,nu)
           nc = h;          
           index = j-1; % convert to 0-based indexing
           c0 = 0;
%  Below is equivalent to ind2sub in Matlab, with the first
%  subscript changes more often.           
           for d=1:kl
               nu(d) = rem(index,f1(d));
               cc = f(d)-nu(d);
               index = (index-nu(d))/f1(d);
               nc = nc*nchoosek(f(d),nu(d));
               if ku(d)>2
                  nc = nc*(fack(ku(d))/2)^nu(d)*(fack(ku(d)-1)/2)^cc;
               end
               ahind(ii,c0+cc+1:c0+f(d)) = true;   % put tau ahead of theta
               c0 = c0+f(d);
           end
           nn(ii) = round(nc);
           ind = find(ku==2);
           if length(ind)>0
              c(ii) = 2^(kf12+nu(ind));
           else
              c(ii) = 2^kf12;
           end
           s{ii} = [1 zeros(1,nc-1)];
       end
   end   
   v = uint8(1:k);
%  (1:k) is always admissible 
   count = ones(tcount,1);
   count1 = 1;
   ccount = sum(nn)-tcount;
   while ccount>0
      count1 = count1+1;
      perm = nthperm(v,count1);
      ii = 0;
      for i=1:np
          kappa = p(i,:);
          for j=1:ppf(i)
              ii = ii+1;
              if count(ii)<nn(ii)
                 pass = true;
                 perm2 = perm(p1(i,1):p2(i,1));
                 for jj=1:r(i)
                     perm1 = perm2;
                     if kappa(jj)>1
                        if ahind(ii,jj)
                           if perm1(1)>perm1(end)
                              pass = false;
                              break
                           end
                        else
                           if min(perm1)~=perm1(1)||perm1(2)>perm1(end)
                              pass = false;
                              break
                           end
                        end
                     end
                     if jj<r(i)
                        perm2 = perm(p1(i,jj+1):p2(i,jj+1));
                        if kappa(jj)==kappa(jj+1)&&ahind(ii,jj)==ahind(ii,jj+1)&&perm1(1)>perm2(1)
                           pass = false;
                           break
                        end
                     end
                 end
                 if pass
                    count(ii) = count(ii)+1;
                    s{ii}(count(ii)) = count1;
                    ccount = ccount-1;
                 end     
              end
          end    
      end
   end
