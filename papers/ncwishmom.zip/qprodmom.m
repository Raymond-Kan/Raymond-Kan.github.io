%
% This program computes 
% E[Q_1^{k_1}*Q_2^{k_2}*...*Qr^{k_r}], where
% k_1+...+k_r = k,
% Qi = vec(Z)'*kron(A_i,I_n)*vec(Z), and Z is
% an nxm matrix of independent normal random 
% variables with mean E[Z] and covariance matrix of 
% kron(Sigma,I_n).  
% It makes use of a super-short recursive algorithm.  
% All input matrices A_i are symmetric matrices.
% Input
% A: m by m by r symmetric matrices, with A(:,:,i) = A_i
% S: covariance matrix of rows of Z
% L: E[Z]'*E[Z]
% n: degrees of freedom
% k: k_1+...+k_r
% Output
% y: E[Q_1^{k_1}*Q_2^{k_2}*...*Q_r^{k_r}] with the 
%    compositions of k generated in lexicographical order.
% Note: Some adjustment to the algorithm is made to allow
%       for the possibility that S is positive semi-definite
%
function y = qprodmom(A,S,L,n,k)
m = size(A,1);
r = size(A,3);
B = zeros(m,m,r);
for i=1:r
    B(:,:,i) = A(:,:,i)*S;
end
%
%   Create a matrix of binomial coefficients of C(i,j) = nchoosek(i-1,j-1)
%
C = zeros(r+k+1,r+1);
C(:,1) = 1;
for j=2:r+1
    C(j:end,j) = cumsum(C(j-1:r+k,j-1));
end
%
%  generate d_\kappa with |kappa|=1
%
d = zeros(r,1);
G = A(:,:,r:-1:1);
H = G;
for i=1:r
    d(r+1-i) = 0.5*(n*trace(B(:,:,i))+trace(A(:,:,i)*L));
end
lk1 = r;
E = eye(r);
for k1=2:k-1
    d1 = d;
    G1 = G;
    H1 = H;
    lk0 = lk1;
    lk1 = C(k1+r,r);
    d = zeros(lk1,1);
    G = zeros(m,m,lk1);
    H = zeros(m,m,lk1);
    for i=1:lk0 
% Create next S
        if i==1
           ind = [zeros(1,r-1) k1-1];
           t = k1-1;
           h = r+1;
        else
           if t>1
              h = r;
           else
              h = h-1;
           end
           t = ind(h);
           ind(h) = 0;
           ind(r) = t-1;
           ind(h-1) = ind(h-1)+1;
        end
        i1 = colexind(ones(r,1)*ind+E);
        for j=1:r
            i2 = i1(j);
            G(:,:,i2) = G(:,:,i2)+A(:,:,j)*d1(i)+B(:,:,j)*G1(:,:,i);
            H(:,:,i2) = H(:,:,i2)+B(:,:,j)*H1(:,:,i);
        end
    end
    H = H+G;
    for i=1:lk1
        d(i) = (n*trace(G(:,:,i)*S)+trace(H(:,:,i)*L))/(2*k1);
    end
end
lk0 = lk1;
lk1 = C(k+r,r);
y = zeros(lk1,1);
c = zeros(lk1,1);
kfac = [1 cumprod(1:k)];
for i=1:lk0 
% Create next S
    if i==1
       ind = [zeros(1,r-1) k-1];
       t = k-1;
       h = r+1;
    else
       if t>1
          h = r;
       else
          h = h-1;
       end
       t = ind(h);
       ind(h) = 0;
       ind(r) = t-1;
       ind(h-1) = ind(h-1)+1;
    end
    i1 = colexind(ones(r,1)*ind+E);
    for j=1:r
        i2 = i1(j);
        G1 = A(:,:,j)*d(i)+B(:,:,j)*G(:,:,i);
        H1 = B(:,:,j)*H(:,:,i)+G1;
        y(i2) = y(i2)+n*trace(G1*S)+trace(H1*L);
        if c(i2)==0
           c(i2) = prod(kfac(ind+E(j,:)+1));
        end
    end
end
y = 2^(k-1)/k*c.*y;

function y1=colexind(kk)
   [m1,nn] = size(kk);
   y1 = ones(m1,1);
   for jj=1:m1
       s = cumsum(kk(jj,nn:-1:1));
       for rr=1:nn-1
           if kk(jj,rr)>0
              n1 = nn-rr+1;
              y1(jj) = y1(jj)+C(s(n1)+n1,n1)-C(s(n1-1)+n1,n1);
           end
       end
   end
end

end
