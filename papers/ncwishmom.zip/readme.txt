These are programs for my paper "Moments of a Wishart Matrix" (with 
Grant Hillier).  If you have questions, comments, or bug reports, 
please send them to Raymond.Kan@rotman.utoronto.ca

Raymond Kan
Rotman School of Management
University of Toronto

Version 1.0: 1/10/2021, initial release
Version 1.1: 3/15/2021, update qmom.m to get rid of the use of FindRow
Version 1.2: 5/8/2021, update ncwishmoms.m to speed up the calculations
Version 1.3: 7/15/2023, update qprodmom.m to reduce the storage requirement, 
             colex.m is no longer needed
Version 1.4: 7/21/2023, update qmom.m to use an explicit expression for
             E[(z'*A*z)^k], qprodind.m is updated to use an explicit
             expression for the coefficients
Version 1.5: 7/25/2023, improve qprodind.m and ncwishmoms.m, fix a bug in
             bracegen.m
Version 1.6: 7/5/2025, minor changes on qprodind.m and ncwishmoms.m,
             improve ncwishmoma.m, remove qmom.m from the package
Version 1.7: 7/14/2025, rewrite ncwishmoms.m and qprodc.m to improve
             efficieny

Main programs:
wishmoms.m: Symbolically compute E[W^k] when W is a central Wishart.
wishmoms1.m: Symbolically compute E[W^k] when W is a central Wishart.
             This produces the coefficients in the form of Table 1.
ncwishmom.m: Numerically compute E[W^k] when W is a noncentral Wishart.
             It is slow when the dimension of W is large.
ncwishmoma.m: Numerically compute E[W^k] when W is a noncentral Wishart.
              This is based on analytical formula but it can only compute
              E[W^k] for k up to 10.
ncwishmoms.m: Symbolically compute E[W^k] when W is a noncentral Wishart.
              It outputs the coefficients that are multiplied to 
              various linear combinations of products of Sigma and Lambda
              to obtain E[W^k].
q2.m to q10.m: Programs to compute E[W^k] for k=2 to 10.  
               Warning: q10.m can take a couple of days to run.
q2.out to q10.out: Output of q2.m to q10.m             
q2.mat to q10.mat: Data output file for q2.m to q10.m.  These file are used 
                   by ncwishmoma.m for fast computation of E[W^k].

Auxiliary programs:
dk.m: A function to produce the transition matrices from power-sum symmetric
      function to zonal polynomials and vice versa
mtops.m: A function to produce a transition matrix from
         augmented monomial symmetric functions to power-sum
         symmetric functions      
ip_desc.m: A function to generate integer partition in descending 
           lexicographical order
nthprem.m: A function that returns the n-th lexicogrphical permutation of 
           a vector
bracegen.m: A function that enumerates bracelets with length of n and k 
            colors
isbrace.m: A logical function that checks if a sequence has
           the lowest representation of the bracelet
totient.m: A function to compute the totient function
divisor.m: A function to compute the divisors of an integer
qprodind.m: A function that expresses product of k quadratic forms 
            in z~N(\mu,I) in terms of \tau's and \theta's
qprodc.m: A function that produces the appropriate coefficients and 
          product of matrices which corresponds to a particular \tau and
          \theta term from qprodind.m
qprodmom.m: A function to compute E[Q_1^{k_1}Q_2^{k_2}...Q_r^{k_r}], 
            where Q_i = vec(Z)'*kron(A_i,I_m)*vec(Z) and Z is an nxm
            matrix of normal random variables with mean E[Z]
            and covraince matrix kron(Sigma,I_n).  This 
            function is called by ncwishmom.m.
Note: nthperm.m was downloaded from Matlab Central FileExchange
      
                  
            