%
%   This Matlab program checks the programs of this package against
%   each other and against the data files q2.mat to q10.mat.
%   Input
%   kmax: (optional) maximum order of the moment for the checks of
%         ncwishmoms.m against q2.mat to q10.mat (default: 8; it
%         takes about a minute for kmax = 9, and 10 to 20 minutes 
%         for kmax = 10)
%   Output
%   nfail: number of checks that fail
%   The checks are
%   (1) ncwishmoms(k) gives the same coefficients as the ones in
%       q<k>.mat, k=2,...,kmax;
%   (2) ncwishmoma.m (analytical formula) and ncwishmom.m (numerical
%       algorithm) give the same E[W^k], k=1,...,5;
%   (3) wishmoms1.m (Letac and Massam, 2004) gives the same 
%       coefficients as the set partitions of (1:k) (wishterms.m 
%       for the central case), k=1,...,7, wishmoms.m agrees with 
%       ncwishmoma.m when Lambda is a zero matrix, and the two
%       outputs of dk.m are inverses of each other (this part needs 
%       the Symbolic Math Toolbox).
%
function nfail = wishcheck(kmax)
   if nargin<1
      kmax = 8;
   end
   nfail = 0;
   ncheck = 0;
   tol = 1e-10;
%
%  (1) ncwishmoms.m against q2.mat to q10.mat
%
   for k=2:min(kmax,10)
       qfile = sprintf('q%d.mat',k);
       if ~exist(qfile,'file')
          fprintf('%s is not found, check is skipped\n',qfile);
          continue
       end
       q = load(qfile,'nn','cc');
       tic
       [nn,cc] = ncwishmoms(k);
       t = toc;
       ok = length(nn)==length(q.nn);
       if ok
          for i=1:length(nn)
              ok = ok&&isequal(termmat(nn{i},cc{i},k),termmat(q.nn{i},q.cc{i},k));
          end
       end
       report(sprintf('ncwishmoms(%d) = q%d.mat (%.2f seconds)',k,k,t),ok);
   end
%
%  (2) ncwishmoma.m against ncwishmom.m
%
   m = 2;
   n = 5.5;
   S = [2 0.6; 0.6 1];
   L = [1 -0.5; -0.5 3];
   for k=1:5
       y1 = ncwishmoma(k,n,S,L);
       y2 = ncwishmom(k,n,S,L);
       report(sprintf('ncwishmoma = ncwishmom, k = %d',k),max(abs(y1(:)-y2(:)))<=tol*max(abs(y2(:))));
   end
   m = 3;
   S = [2 0.6 -0.3; 0.6 1 0.2; -0.3 0.2 1.5];
   L = [1 1 0; 1 2 1; 0 1 1];
   for k=1:4
       y1 = ncwishmoma(k,n,S,L);
       y2 = ncwishmom(k,n,S,L);
       report(sprintf('ncwishmoma = ncwishmom, k = %d, m = 3',k),max(abs(y1(:)-y2(:)))<=tol*max(abs(y2(:))));
   end
%
%  (3) Central case
%
   if exist('sym')
      S = [2 1 0; 1 3 1; 0 1 2];
      for k=1:7
          tic
          y1 = wishmoms1(k);
          t = toc;
          y2 = spterms(k);
          ok = true;
          for r=1:k
              ok = ok&&isequal(size(y1{r}),size(y2{r}))&&all(isAlways(y1{r}==y2{r}));
          end
          report(sprintf('wishmoms1(%d) = terms from the set partitions (%.2f seconds)',k,t),ok);
%  Numerical value of E[W^k] from wishmoms.m
          y1 = wishmoms(k);
          ts = sym('ts%d',[1 k]);
          P = eye(m);
          tr = zeros(1,k);
          for i=1:k
              P = P*S;
              tr(i) = trace(P);
          end
          yn = double(subs(y1,[sym('n') ts],[n tr]));
          y3 = zeros(m);
          P = eye(m);
          for i=1:k
              P = P*S;
              y3 = y3+yn(i)*P;
          end
          y4 = ncwishmoma(k,n,S,zeros(m));
          report(sprintf('wishmoms(%d) = ncwishmoma with Lambda = 0',k),max(abs(y3(:)-y4(:)))<=tol*max(abs(y4(:))));
      end
      for k=1:5
          [D,Di] = dk(k);
          report(sprintf('dk(%d): D*Di is an identity matrix',k),all(all(isAlways(D*Di==eye(size(D,1))))));
      end
   else
      fprintf('Symbolic Math Toolbox is not found, the checks of wishmoms.m and wishmoms1.m are skipped\n');
   end
   fprintf('%d checks, %d failed\n',ncheck,nfail);

   function report(msg,ok)
      ncheck = ncheck+1;
      if ok
         fprintf('passed: %s\n',msg);
      else
         nfail = nfail+1;
         fprintf('FAILED: %s\n',msg);
      end
   end
end

%
%  spterms: E[W^k] for the central case in the form of the output of
%  wishmoms1.m, from the set partitions of (1:k)
%
function y = spterms(k)
   [wid,tr,cf] = wishterms(k,true);
%  A term is S^a times a product of traces of powers of S, and 
%  bracelet tcount(i)+1 is S^i.  len gives the power of S of the
%  product and of the traces of each term.
   [~,~,~,tcount] = bracetab(k);
   len = zeros(tcount(k+1)+1,1);
   len(tcount(1:k)+2) = 1:k;
   len = reshape(len([wid tr]+1),size(tr,1),[]);
   a = len(:,1);
   lam = sort(len(:,2:end),2,'descend');
   c = cf*sym('n').^(0:k).';
   y = cell(k,1);
   for r=1:k
       s1 = ip_desc(r-1);
       s1 = [s1 zeros(size(s1,1),size(lam,2)-r+1)];
       ind = find(a==k+1-r);
       [~,loc] = ismember(lam(ind,:),s1,'rows');
       y{r} = sym(zeros(size(s1,1),1));
       y{r}(loc) = c(ind);
   end
end

%
%  termmat: put the terms of a bracelet in a matrix, with one row for
%  each term (coefficients of the polynomial of n, followed by the 
%  indices of the traces), and sort the rows
%
function A = termmat(nn,cc,k)
   A = zeros(length(nn),2*k+1);
   for j=1:length(nn)
       A(j,1:length(nn{j})) = nn{j};
       A(j,k+1+(1:length(cc{j}))) = cc{j};
   end
   A = sortrows(A);
end
