%
%  This Matlab function computes E[W^k], where
%  W ~ W_m(n,Sigma).
%  Input
%  k: power of W
%  Output
%  y: a k-vector such that E[W^k] = y(1)*S+y(2)*S^2+...+y(k)*S^k.
%  Reference: Letac and Massam (SJS 2004, Theorem 4)
%             All Invariant Moments of the Wishart Distribution
%  Note: In the output, ts1 stands for tr(S), ts2 stands for
%        tr(S^2), ts3 stands for tr(S^3), and so on.
%
function y = wishmoms(k)
   [D,Di] = dk(k);
   syms n
   ts = sym('ts%d',[1 k]);
   s = ip_desc(k);
   m = size(s,1);
   l = sum(s>0,2);
   c = zeros(1,m,'sym');
   for i=1:m
       c1 = 1;
       for j=1:l(i)
           c1 = c1*prod(n-j+1:2:n-j-1+2*s(i,j));
       end
       c(i) = D(1,i)*c1;
   end
   Di = c*Di;
   y = zeros(k,1,'sym');
   for i=1:m
       s1 = s(i,1:l(i));
       Di(i) = Di(i)*prod(ts(s1));
       for j=1:s1(1)
           ij = sum(s1==j);
           if ij>0
              y(j) = y(j)+Di(i)*j*ij/ts(j);
           end
       end
   end
   y = simplify(y/k);
   