%
%  This Matlab function computes E[W^k], where
%  W ~ W_m(n,Sigma).
%  Input
%  k: power of W
%  Output
%  y: a k-vector such that E[W^k] = y(1)*S+y(2)*S^2+...+y(k)*S^k.
%  Reference: Letac and Massam (SJS 2004, Theorem 4)
%             All Invariant Moments of the Wishart Distribution
%  Note: In the output, ts1 stands for tr(S), ts2 stands for
%        tr(S^2), ts3 stands for tr(S^3), and so on.
%
function y = wishmoms(k)
   y1 = wishmoms1(k);
   ts = sym('ts%d',[1 k]);
   y = sym(zeros(k,1));
   y(k) = y1{1};
   for r=2:k
%  p is the vector of the products of traces for the partitions of r-1
       s = ip_desc(r-1);
       p = sym(ones(size(s,1),1));
       for i=1:size(s,1)
           p(i) = prod(ts(s(i,s(i,:)>0)));
       end
       y(k+1-r) = y1{r}.'*p;
   end
end
