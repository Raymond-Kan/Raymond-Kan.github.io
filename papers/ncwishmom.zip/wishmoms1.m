%
%  This Matlab function computes E[W^k], where
%  W ~ W_m(n,Sigma).
%  Input
%  k: power of W
%  Output
%  y: a cell array with k elements such that 
%  E[W^k] = \sum{r=1}^{k} [y{r}'*p_{r-1}(S)]*S^{k+1-r}.
%  Reference: Letac and Massam (SJS 2004, Theorem 4)
%             All Invariant Moments of the Wishart Distribution
%  Note: Let h_kappa be the coefficient of p_kappa(S) in 
%        E[tr(W^k)], where kappa is a partition of k.  It is the 
%        (1,kappa) element of D*A*Di, where D and Di are the 
%        transition matrices from dk.m, and A is a diagonal matrix
%        of polynomials of n.  Since only the first row is needed
%        and Di = diag(ck1)*C*T, we do not compute D and Di.  The
%        coefficients of the polynomials of n are kept in a matrix 
%        H with k+1 columns, which is obtained with one multiplication
%        by C' and one by T'.
%
function y = wishmoms1(k)
   [C,ck1,T] = dk(k,'factors');
   s = ip_desc(k);
   m = size(s,1);
%
%  The diagonal element of A for the ith partition is the product 
%  of n+cst(i,j), j=1,...,k.  E(i,:) are its coefficients of 
%  n^0,...,n^k, which are integers less than (2k-1)!!.
%
   cst = zeros(m,k);
   for i=1:m
       c = 0;
       for j=1:sum(s(i,:)>0)
           cst(i,c+1:c+s(i,j)) = 1-j+2*(0:s(i,j)-1);
           c = c+s(i,j);
       end
   end
   E = [ones(m,1) zeros(m,k)];
   if prod(1:2:2*k-1)>=2^53
      E = sym(E);
   end
   for j=1:k
       E = [zeros(m,1) E(:,1:k)]+repmat(cst(:,j),1,k+1).*E;
   end
%
%  First row of D is the first column of C*T divided by its first
%  element.  The integers in double precision are converted to 
%  symbolic with the flag 'f', which keeps their exact values.
%
   if isa(C,'double')
      C = sym(C,'f');
   end
   if isa(E,'double')
      E = sym(E,'f');
   end
   g = C*T(:,1);
   g = ck1.*g/g(1);
   H = T.'*(C.'*(repmat(g,1,k+1).*E));
%
%  E[W^k] is obtained by differentiating E[tr(W^k)]/k with respect
%  to S: a partition kappa with j parts equal to r contributes
%  r*j/k times h_kappa to the coefficient of S^r.
%
   n = sym('n');
   pn = n.^(0:k).';
   y = cell(k,1);
   y{1} = H(1,:)*pn;
   for r=1:k-1
       s1 = ip_desc(k-r);
       m1 = size(s1,1);
%  Add a part r to each partition of k-r
       kappa = sort([s1 r*ones(m1,1)],2,'descend');
       kappa = [kappa zeros(m1,r-1)];
       [~,loc] = ismember(kappa,s,'rows');
       c = r*sum(kappa==r,2)/sym(k);
       y{k-r+1} = (repmat(c,1,k+1).*H(loc,:))*pn;
   end
end
