%
%  This Matlab function computes E[W^k], where
%  W ~ W_m(n,Sigma).
%  Input
%  k: power of W
%  Output
%  y: a cell array with k elements such that 
%  E[W^k] = \sum{r=1}^{k} [y{r}'*p_{r-1}(S)]*S^{k+1-r}.
%  Reference: Letac and Massam (SJS 2004, Theorem 4)
%             All Invariant Moments of the Wishart Distribution
%
function y = wishmoms1(k)
   [D,Di] = dk(k);
   syms n
   s = ip_desc(k);
   m = size(s,1);
   l = sum(s>0,2);
   c = zeros(1,m,'sym');
   for i=1:m
       c1 = 1;
       for j=1:l(i)
           c1 = c1*prod(n-j+1:2:n-j-1+2*s(i,j));
       end
       c(i) = D(1,i)*c1;
   end
   h = simplify(c*Di);
   y = cell(k,1);
   y{1} = h(1);
   for r=k-1:-1:1
       s1 = ip_desc(k-r);
       m1 = size(s1,1);
       c1 = zeros(m1,1,'sym');
       for j=1:m1
           kappa = sort([s1(j,:) r],2,'descend');
           kappa = [kappa zeros(1,k-length(kappa))];
           jr = sum(kappa==r);
           i1 = FindRow(s,kappa);
           c1(j) = r*jr/k*h(i1);
       end
       y{k-r+1} = c1;
   end  
   