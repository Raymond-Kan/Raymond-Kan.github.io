%
%   This Matlab function generates the terms of E[W^k], where
%   W ~ W_m(n,Sigma,Sigma^{-1}*Lambda), from the expression of the
%   expectation of a product of k quadratic forms in normal random
%   variables.  It is called by ncwishmoms.m.  It can also generate
%   the terms for the central case, which wishcheck.m uses to check 
%   wishmoms1.m.
%
%   The (i,j)th element of W^k is a sum over c_2,...,c_k of the
%   product of the k quadratic forms w_{c_1 c_2}, ..., w_{c_k c_{k+1}},
%   where c_1 = i and c_{k+1} = j.  Its expectation is a sum over the
%   set partitions of (1:k).  For a block with p elements, we need
%   (a) an arrangement of its elements in a cycle together with a
%       reading (c_t,c_{t+1}) or (c_{t+1},c_t) of each element, which
%       links the second index of each element to the first index of
%       the next one with an element of Sigma; there are 1, 2 and
%       (p-1)!*2^(p-1) different sets of links for p = 1, p = 2 and
%       p > 2, and
%   (b) a choice between keeping all the p links as Sigma, which
%       contributes a factor n (a tau term), and replacing one of the
%       p links by Lambda (a theta term).
%   After summing over c_2,...,c_k, the links that are met when we
%   move from index i to index j give a product of Sigma and Lambda,
%   and the remaining links form cycles, which give traces of products
%   of Sigma and Lambda.
%
%   The set partitions are grouped by their type (the sizes of their
%   blocks).  The choices in (a) only depend on the type, and they are
%   combined with all the set partitions of the type in batches.  The
%   path and the cycles are traced once for each combination (there
%   are (2k-1)!! of them).  This tells us in which order the links
%   are met, so that a choice in (b) is turned into a binary string of
%   length k (0 for Sigma and 1 for Lambda) by one matrix
%   multiplication for all the choices of a batch, and a table then
%   gives the product and the traces that the binary string stands
%   for.  In addition, we use the following two facts:
%   (1) The products of Sigma and Lambda in the same bracelet have
%       the same coefficient, so we only keep the terms whose product
%       is the lowest representation of its bracelet.
%   (2) The mirror image t -> k+1-t of a set partition gives the same
%       terms with the product of Sigma and Lambda reversed, so only
%       one of a set partition and its mirror image is processed.
%
%   Input
%   k: order of the moment of W
%   central: true for the central case (Lambda = 0), in which case
%            only the tau terms are generated (default: false)
%   Output
%   wid: a vector with the index of the bracelet of the product of
%        Sigma and Lambda of each term (see bracetab.m)
%   tr: a matrix with max(k-1,1) columns; each row has the indices of
%       the bracelets of the traces of a term in ascending order,
%       padded with zeros
%   cf: a matrix with k+1 columns; each row has the coefficient of a
%       term, which is cf(1)+cf(2)*n+...+cf(k+1)*n^k
%   The terms are sorted by wid, then by the number of traces, and
%   then by the indices of the traces.
%
function [wid,tr,cf] = wishterms(k,central)
   if nargin<2
      central = false;
   end
   ck = 2^k;
   kt = max(k-1,1);
   [bid,low,rlow,tcount] = bracetab(k);
%
%  Shapes.  A shape is the length a of the path from i to j followed
%  by the lengths of the cycles in descending order.  A shape is a
%  composition of k, and it is identified by the binary number that
%  has ones at the positions of its partial sums.
%
   ns = 0;
   for a=1:k
       ns = ns+size(ip_desc(k-a),1);
   end
   shape = zeros(ns,k);
   shapeid = zeros(2^(k-1),1);
   ii = 0;
   for a=1:k
       p = ip_desc(k-a);
       for j=1:size(p,1)
           ii = ii+1;
           shape(ii,1:k-a+1) = [a p(j,:)];
           c = cumsum(shape(ii,:));
           shapeid(sum(2.^(c(c<k)-1))+1) = ii;
       end
   end
%
%  Classes.  A class is a product of Sigma and Lambda (up to its
%  bracelet) together with a product of traces.  cw and ct give the
%  index of the bracelet of the product and those of the traces.
%  In the noncentral case, a term is described by its shape and by a
%  binary string x of length k: the first a elements of x give the
%  product of Sigma and Lambda and the following elements give the
%  traces.  tab(x+1+(s-1)*2^k) is the class of the term for shape s
%  when the product is the lowest representation of its bracelet, and
%  it is zero otherwise.  The second half of tab is for the set
%  partitions that also stand for their mirror image: it gives the
%  class when the product or its reverse is the lowest representation,
%  and big is added when both of them are.
%
   big = 2^40;
   if central
      tab = [];
      nc = ns;
      cw = tcount(shape(:,1))+1;
      ct = zeros(ns,kt);
      for s=1:ns
          lam = shape(s,2:end);
          lam = lam(lam>0);
          ct(s,1:length(lam)) = sort(tcount(lam)+1);
      end
   else
      tab = zeros(2*ns*ck,1);
      x = (0:ck-1)';
      cw = cell(ns,1);
      ct = cell(ns,1);
      nc = 0;
      for s=1:ns
          a = shape(s,1);
          ii = 2^a-1+floor(x/2^(k-a));
          lam = shape(s,2:end);
          lam = lam(lam>0);
          t = zeros(ck,kt);
          off = a;
          for j=1:length(lam)
              off = off+lam(j);
              t(:,j) = bid(2^lam(j)-1+rem(floor(x/2^(k-off)),2^lam(j)));
          end
          t = sort(t,2);
          t = t(:,[kt-length(lam)+1:kt 1:kt-length(lam)]);
          [u,~,g] = unique([bid(ii) t],'rows');
          g = nc+g(:);
          w1 = low(ii);
          w2 = w1+rlow(ii);
          tab((s-1)*ck+x+1) = w1.*g;
          tab((ns+s-1)*ck+x+1) = (w2>0).*g+(w2>1)*big;
          cw{s} = u(:,1);
          ct{s} = u(:,2:end);
          nc = nc+size(u,1);
      end
      cw = vertcat(cw{:});
      ct = vertcat(ct{:});
   end
%
%  Arrangements of the elements of a block with p elements in a cycle
%  (first element is the smallest one, and the second element is
%  smaller than the last one), and the number of readings
%
   arr = cell(1,k);
   nread = ones(1,k);
   narr = ones(1,k);
   arr{1} = 1;
   if k>1
      arr{2} = [1 2];
      nread(2) = 2;
   end
   for p=3:k
       pm = perms(2:p);
       pm = pm(pm(:,1)<pm(:,p-1),:);
       arr{p} = [ones(size(pm,1),1) pm];
       narr(p) = size(pm,1);
       nread(p) = 2^p;
   end
   nrow = narr.*nread;      % number of different sets of links
%
%  Types.  The type of a set partition is the integer partition of k
%  formed by the sizes of its blocks.  For each type, the blocks are
%  put in descending order of their sizes and the elements of the
%  blocks are numbered from 1 to k in that order (slots).  A link is
%  given the slot of the element that it leaves.  ind{i} has a column
%  for each choice in (b): the slots whose links are replaced by
%  Lambda, at most one for each block.  npow{i} is the corresponding
%  power of n, and bmax(i) is the maximum size of a batch.
%
   typ = ip_desc(k);
   ntyp = size(typ,1);
   typeid = zeros(2^(k-1),1);
   ind = cell(ntyp,1);
   npow = cell(ntyp,1);
   bmax = zeros(ntyp,1);
   for i=1:ntyp
       kappa = typ(i,typ(i,:)>0);
       c = cumsum(kappa);
       typeid(sum(2.^(c(c<k)-1))+1) = i;
       if central
          bmax(i) = 30000;
       else
          y = zeros(k,1);
          for j=1:length(kappa)
              p = kappa(j);
              ny = size(y,2);
              y = repmat(y,1,p+1);
              for q=1:p
                  y(c(j)-p+q,q*ny+1:(q+1)*ny) = 1;
              end
          end
          ind{i} = [y; ones(1,size(y,2))];
          npow{i} = length(kappa)-sum(y,1);
          bmax(i) = max(1,min(30000,floor(2e6/size(y,2))));
       end
   end
%
%  Set partitions of (1:k).  Row i of Q gives the block of each
%  element, with the blocks numbered in the order of their smallest
%  elements.  Only one of a set partition and its mirror image is
%  kept: sm is 0 when a set partition is its own mirror image, and 1
%  when it also stands for its mirror image.
%
   Q = 1;
   mx = 1;
   for i=2:k
       rep = mx+1;
       c = cumsum(rep);
       j = zeros(c(end),1);
       j(c-rep+1) = 1;
       j = cumsum(j);                     % row of Q that a new row comes from
       lab = (1:c(end))'-c(j)+rep(j);     % block of element i
       Q = [Q(j,:) lab];
       mx = max(mx(j),lab);
   end
   N = size(Q,1);
   ri = (1:N)';
   d = Q-relabel(Q(:,k:-1:1));
   [~,j] = max(d~=0,[],2);
   d = d(ri+(j-1)*N);
   Q = Q(d<=0,:);
   sm = double(d(d<=0)<0);
   N = size(Q,1);
   ri = (1:N)';
%
%  Sizes of the blocks in descending order, the type, and the slot of
%  each element
%
   bs = zeros(N,k);
   for i=1:k
       j = ri+(Q(:,i)-1)*N;
       bs(j) = bs(j)+1;
   end
   [bs,o] = sort(bs,2,'descend');
   c = cumsum(bs,2);
   tid = typeid(sum((c<k).*2.^(c-1),2)+1);
   rk = zeros(N,k);
   rk(ri+(o-1)*N) = repmat(1:k,N,1);      % rank of a block
   c = c-bs;                              % number of slots before a block
   cnt = zeros(N,k);
   sl = zeros(N,k);
   for i=1:k
       j = ri+(Q(:,i)-1)*N;
       cnt(j) = cnt(j)+1;
       sl(:,i) = c(ri+(rk(j)-1)*N)+cnt(j);
   end
%
%  Sides.  Side 2s-1 and side 2s are the first and the second index
%  of the element with slot s.  The second index of element t and the
%  first index of element t+1 are the same index: adj gives the side
%  that has the same index as a given side (0 for the first index of
%  element 1, which is index i, and for the second index of element
%  k, which is index j).
%
   adj = zeros(N,2*k);
   for i=1:k-1
       adj(ri+(2*sl(:,i)-1)*N) = 2*sl(:,i+1)-1;
       adj(ri+(2*sl(:,i+1)-2)*N) = 2*sl(:,i);
   end
   st = 2*sl(:,1)-1;                      % side of index i
%
%  Go through the types.  The sets of links of a type are numbered
%  from 0 to prod(nr)-1 in a mixed radix system, with one digit for
%  each block.
%
   acc = zeros(nc*(k+1),1);
   for it=1:ntyp
       ip = find(tid==it);
       np = length(ip);
       if np==0
          continue
       end
       sz = typ(it,typ(it,:)>0);
       nb = length(sz);
       s0 = cumsum(sz)-sz;
       nr = nrow(sz);
       rad = [1 cumprod(nr(1:nb-1))];
       tot = prod(nr);
       pc = min(np,bmax(it));
       rc = max(1,floor(bmax(it)/pc));
       for r0=0:rc:tot-1
           r = (r0:min(r0+rc,tot)-1)';
           n1 = length(r);
           lk = zeros(n1,2*k);     % side at the other end of the link of each side
           ls = zeros(n1,2*k);     % slot of the link of each side
           lf = zeros(n1,k);       % one of the two sides of the link of each slot
           for j=1:nb
               p = sz(j);
               [d,e,f] = blocklinks(rem(floor(r/rad(j)),nr(j))+1,arr{p},nread(p));
               lk(:,2*s0(j)+1:2*(s0(j)+p)) = d+2*s0(j);
               ls(:,2*s0(j)+1:2*(s0(j)+p)) = e+s0(j);
               lf(:,s0(j)+1:s0(j)+p) = f+2*s0(j);
           end
           for p0=0:pc:np-1
               i1 = ip(p0+1:min(p0+pc,np));
               acc = acc+termsum(lk,ls,lf,adj(i1,:),st(i1),sm(i1),k,nc,ns,shapeid,nb, ...
                                 central,tab,big,ind{it},npow{it});
           end
       end
   end
%
%  Collect the terms
%
   cf = reshape(acc,nc,k+1);
   i1 = any(cf,2);
   wid = cw(i1);
   tr = ct(i1,:);
   cf = cf(i1,:);
   [~,i1] = sortrows([wid sum(tr>0,2) tr]);
   wid = wid(i1);
   tr = tr(i1,:);
   cf = cf(i1,:);
end

%
%  relabel: number the blocks of each set partition (a row of Q) in
%  the order in which they appear
%
function R = relabel(Q)
   [N,k] = size(Q);
   ri = (1:N)';
   map = zeros(N,k);
   nb = zeros(N,1);
   R = zeros(N,k);
   for i=1:k
       j = ri+(Q(:,i)-1)*N;
       new = map(j)==0;
       nb(new) = nb(new)+1;
       map(j(new)) = nb(new);
       R(:,i) = map(j);
   end
end

%
%  blocklinks: sets of links of a block with p elements, which are
%  numbered from 1 to p.  Side 2q-1 and side 2q are the first and the
%  second index of element q.
%  Input
%  r: a column vector with the indices of the sets of links that are
%     requested (from 1 to size(A,1)*nread)
%  A: arrangements of (1:p) in a cycle
%  nread: number of readings (1 when p = 1, 2 when p = 2, and 2^p
%         when p > 2)
%  Output (row i is for the r(i)th set of links)
%  d: d(i,s) is the side at the other end of the link of side s
%  e: e(i,s) is the element that the link of side s leaves
%  f: f(i,q) is the side where the link that leaves element q starts
%
function [d,e,f] = blocklinks(r,A,nread)
   p = size(A,2);
   N = length(r);
   if p==1
      d = repmat([2 1],N,1);
      e = ones(N,2);
      f = 2*ones(N,1);
      return
   end
   o = reshape(A(floor((r-1)/nread)+1,:),N,p);
   ir = rem(r-1,nread);
%  rd(i,j) = 1 when the jth element of the cycle is read as (c_{t+1},c_t)
   if p==2
      rd = [zeros(N,1) ir];
   else
      rd = rem(floor(ir*2.^(1-p:0)),2);
   end
   d = zeros(N,2*p);
   e = zeros(N,2*p);
   f = zeros(N,p);
   ri = (1:N)';
   for j=1:p
       jn = rem(j,p)+1;
%  The second index of the jth element of the cycle is linked to the
%  first index of the next element
       s1 = 2*o(:,j)-rd(:,j);
       s2 = 2*o(:,jn)-1+rd(:,jn);
       d(ri+(s1-1)*N) = s2;
       d(ri+(s2-1)*N) = s1;
       e(ri+(s1-1)*N) = o(:,j);
       e(ri+(s2-1)*N) = o(:,j);
       f(ri+(o(:,j)-1)*N) = s1;
   end
end

%
%  termsum: sum of the coefficients of each class and each power of n
%  for a batch, which combines the sets of links in the rows of lk, ls
%  and lf with the set partitions in the rows of adj, st and sm.  nblk
%  is the number of blocks, ind has a column for each choice of the
%  links that are replaced by Lambda, and npow is the corresponding
%  power of n.
%
function y = termsum(lk,ls,lf,adj,st,sm,k,nc,ns,shapeid,nblk,central,tab,big,ind,npow)
   sm = repmat(sm,size(lk,1),1);
   if central
%  The class is the shape and the power of n is the number of blocks
      sid = tracelinks(lk,ls,lf,adj,st,k,shapeid);
      y = accumarray(sid+nc*nblk,1+sm,[nc*(k+1) 1]);
   else
      [sid,wt] = tracelinks(lk,ls,lf,adj,st,k,shapeid);
      N = length(sid);
%  Binary string of each term, shifted to the part of tab for its shape
      v = tab([wt (sid-1+ns*sm)*2^k+1]*ind);
      [~,j,v] = find(reshape(v,N,[]));
      w = 1+(v>big);
      v = v-(w-1)*big;
      y = accumarray(v(:)+nc*npow(j(:))',w(:),[nc*(k+1) 1]);
   end
end

%
%  tracelinks: trace the path from index i to index j and the cycles
%  for each combination of a set of links and a set partition.
%  Input
%  lk: lk(r,s) is the side at the other end of the link of side s in
%      the rth set of links
%  ls: ls(r,s) is the slot of the link of side s
%  lf: lf(r,t) is one of the two sides of the link with slot t
%  adj: adj(q,s) is the side that has the same index as side s in the
%       qth set partition
%  st: st(q) is the side of index i in the qth set partition
%  k: order of the moment
%  shapeid: table that gives the index of a shape
%  Output (the qth set partition with the rth set of links is in row
%  q+(r-1)*size(adj,1))
%  sid: index of the shape
%  wt: wt(i,t) = 2^(k-b), where b is the position of the link with
%      slot t when the links are listed in the order in which they
%      are met: first the path, and then the cycles in descending
%      order of their lengths
%
function [sid,wt] = tracelinks(lk,ls,lf,adj,st,k,shapeid)
   nr = size(lk,1);
   np = size(adj,1);
   N = np*nr;
   kt = max(k-1,1);
   ri = (1:N)';
   iq = repmat((1:np)',nr,1);             % set partition of each row
   ir = reshape(repmat(1:nr,np,1),N,1);   % set of links of each row
%  A side s is stored as (s-1)*nr, a slot t as (t-1)*N, and lk as
%  (lk-1)*np, so that they can be used as indices directly.  The end
%  of the path is stored as -nr.
   lk = (lk-1)*np;
   ls = (ls-1)*N;
   lf = (lf-1)*nr;
   adj = (adj-1)*nr;
   st = (st-1)*nr;
   pos = zeros(N,k);        % position of a link in its path or cycle
   cyc = repmat(ri,1,k);    % row+j*N, where j = 0 for the path and j for the jth cycle
%  The path: start from index i, cross the link, move to the other
%  side with the same index, and stop when we arrive at index j
   a = zeros(N,1);
   act = ri;
   q = iq;
   r = ir;
   cur = st(iq);
   for s=1:k
       i1 = r+cur;
       pos(act+col(ls(i1))) = s;
       cur = col(adj(q+col(lk(i1))));
       fin = cur<0;
       a(act(fin)) = s;
       act = act(~fin);
       if isempty(act)
          break
       end
       cur = cur(~fin);
       q = q(~fin);
       r = r(~fin);
   end
%  The cycles: start from a link that has not been met
   clen = zeros(N,kt);
   na = a;
   nc = 0;
   while true
      left = find(na<k);
      if isempty(left)
         break
      end
      nc = nc+1;
      [~,t0] = max(pos(left,:)==0,[],2);
      q = iq(left);
      r = ir(left);
      c0 = col(lf(r+(t0-1)*nr));
      cur = c0;
      act = left;
      for s=1:k
          i1 = r+cur;
          i2 = act+col(ls(i1));
          pos(i2) = s;
          cyc(i2) = act+nc*N;
          cur = col(adj(q+col(lk(i1))));
          fin = cur==c0;
          clen(act(fin)+(nc-1)*N) = s;
          act = act(~fin);
          if isempty(act)
             break
          end
          cur = cur(~fin);
          c0 = c0(~fin);
          q = q(~fin);
          r = r(~fin);
      end
      na(left) = na(left)+clen(left+(nc-1)*N);
   end
%  Put the cycles in descending order of their lengths
   [sl,o] = sort(clen,2,'descend');
   c = [a a+cumsum(sl,2)];
   p2 = 2.^(0:k)';
   sid = shapeid(sum((c<k).*reshape(p2(c),N,kt+1),2)+1);
   if nargout>1
%  off = k+1-(number of links that are met before the path or the cycle)
      off = (k+1)*ones(N,kt+1);
      off(ri+o*N) = k+1-c(:,1:kt);
      wt = reshape(p2(off(cyc)-pos),N,k);
   end
end

%
%  col: turn the result of an indexing operation into a column vector
%  (the result is a row vector when the matrix that is indexed has
%  only one row)
%
function x = col(x)
   x = x(:);
end
