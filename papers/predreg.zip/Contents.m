% Exact finite-sample distributions and moments of predictive regressions
% MATLAB programs accompanying
%
%   Kan, R., Pan, J., and Tang, T., "Computing the Exact Distribution of
%   Predictive Regression," University of Toronto.
%
% Model: r_t = alpha + beta*z_{t-1} + u_t, with z_t a stationary AR(1)
% (coefficient phi, |phi| < 1) and (u_t,v_t) i.i.d. bivariate normal
% with correlation ruv.  See the user manual (manual.pdf) for details
% and examples.  All routines cost O(1) per integrand evaluation,
% independent of the sample size T.
%
% Distribution functions (exact, O(1) integrand)
%   bhat_pdf      - density of the OLS slope estimator betahat
%   bhat_cdf      - cdf of betahat
%   trat_pdf      - density of the OLS t-ratio
%   trat_cdf      - cdf of the OLS t-ratio
%   rsq_pdf       - density of the regression R^2
%   rsq_cdf       - cdf of the regression R^2
%
% Exact moments
%   bmom          - moments of b = (sigma_v/sigma_u)*(betahat-beta)
%   bhatmom       - moments of betahat
%   tratmom       - moments of the OLS t-ratio
%   tratmom_odd   - a single odd moment of the OLS t-ratio, by the
%                   two-dimensional representation of the paper
%   rsqmom        - moments of R^2
%
% Internal computational routines
%   bhat_int      - O(1) inversion integrand for the distribution of b
%   r1r2_gh       - O(1) integrand for the joint distribution of (R1,R2)
%   ttprims       - primitives of tridiagonal Toeplitz matrices, by the
%                   closed forms in the roots or, near the confluent
%                   point, by Chebyshev expansions (paper, Section 3.3)
%   bordered_phase- certified continuous phase via LU pivots (option)
%   r2_upper      - truncation point and scale for the outer integral
%   r2_trunc      - certified truncation point: the smallest r2max with
%                   P[R2 > r2max] <= eps, by a Chernoff bound on the
%                   exact mgf (paper, Section 4.3)
%   r2_scale      - delta-method centering and scaling of the outer
%                   quadrature variable (no accuracy claim attached)
%   qfmgf_setup   - structure of the moment generating function
%   qfmgf_logpsi_f- log of the mgf, O(1) closed-form evaluation (default)
%   qfmgf_logpsi  - log of the mgf, banded O(T) evaluation (cross-check)
%   qfmgf_pd      - log of the mgf with an exact positive-definiteness
%                   certificate, used by r2_trunc to stay inside the
%                   domain of the mgf
%   qfmgf_dp      - derivatives of the mgf (complex step at order one,
%                   Taylor-mode series above; Cauchy circle as option)
%   qfmgf_dj      - Taylor-mode (jet) evaluation of the derivatives in r
%   qfmgf_djs     - Taylor-mode (jet) evaluation of the derivatives in s,
%                   used by tratmom_odd
%   qfmgf_jetok   - diagnostic: which branch of the primitives a node
%                   falls in, and its tau
%
% Benchmarks (classical eigenvalue approach, O(T^3) per point)
%   bhat_pdf_eig, bhat_cdf_eig, trat_pdf_eig, trat_cdf_eig,
%   rsq_pdf_eig, rsq_cdf_eig, bhat_eig_setup, r1r2_eig_setup,
%   r1r2_g_eig, r1r2_h_eig
%
% Validation and examples
%   demo_predreg     - worked examples (start here)
%   test_correctness - validation suite for the distribution programs
%   test_moments     - validation suite for the moment programs
%   test_o1          - O(1) mgf evaluator vs the banded and dense routes
%   test_margin      - the two branches of ttprims against dense inversion
%                      above and below their switching threshold
%   test_largen      - ttprims at large n against the exact spectral sums,
%                      where dense inversion is no longer a reference
%   test_o1_all      - measures the cost of every routine across four
%                      orders of magnitude in T, and checks it is flat
%   test_oddmom      - the s-derivative jets against a 40-digit
%                      reference, and tratmom_odd against tratmom
%   test_certify     - end-to-end certification at hard configurations
%                      (small T, phi near one, |ruv| near one, negative
%                      phi): the certified truncation bound, density
%                      nonnegativity, cdf monotonicity, total mass, the
%                      cdf against the integrated density, the density
%                      against a central difference of the cdf, and the
%                      sensitivity to tolerance and truncation
%
% Scripts that reproduce material in the paper
%   make_tab_grid    - Table 3: exact size and quantile error over a
%                      grid in (phi, ruv, T)
%   r2quant_job      - the exact median and 95th percentile of R^2
%                      quoted in Section 2.3
%   check_cdstep     - the step-halving diagnostic quoted in Section
%                      5.7: the gap between rsq_pdf and a central
%                      difference of rsq_cdf is O(h^2) truncation of
%                      the difference, not disagreement between the two
