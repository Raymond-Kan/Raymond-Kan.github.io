function F = bhat_cdf(x,T,b,phi,c0,ruv,tol,engine)
%BHAT_CDF  Exact cdf of the OLS slope estimator of a predictive regression.
%
%   F = BHAT_CDF(x,T,b,phi,c0,ruv) returns P[betahat < x] for the
%   predictive regression r_t = alpha + beta*z_{t-1} + u_t with a
%   stationary AR(1) predictor and i.i.d. bivariate normal errors.
%   Inputs as in BHAT_PDF.
%
%   The integrand Im(phi(s,-rs))/s has a removable singularity at the
%   origin with limit tr((A-rB)V) (known in closed form); the integrand
%   is replaced on a small adaptively-chosen interval [0,s0] by the
%   quadratic through the limit and the computed values at s0/2 and s0.
%   (SPLINE on three points returns that parabola, not a cubic: three
%   interpolation conditions determine a polynomial of degree two.)
%   O(1) per quadrature point, overflow-free for any T.
%
%   See also BHAT_PDF, BHAT_CDF_EIG, BHAT_INT.

if nargin < 7, tol = 1e-8; end
if nargin < 8, engine = 'fast'; end    % strict O(1) default; 'auto' adds pivot fallback
if ~isscalar(phi) || ~isreal(phi) || abs(phi) >= 1
    error('predreg:phi',['The predictor must be a stationary AR(1): ' ...
        '|phi| < 1 is required.  The unit-root case has no stationary ' ...
        'distribution for z_0 and is a different problem.']);
end
F  = zeros(size(x));
xb = (x-b)/c0;

% closed-form traces for the origin limit
if phi > 0
    omphiT = -expm1(T*log(phi));            % 1-phi^T, stable
else
    omphiT = 1-phi^T;
end
trAV = -ruv/(1-phi)+ruv*omphiT/(T*(1-phi)^2);
trBV = (T-1)/(1-phi^2)-2*phi/((1-phi)*(1-phi^2))*(1-omphiT/(T*(1-phi)));

for i = 1:numel(xb)
    r  = xb(i);
    L0 = trAV-r*trBV;                       % lim_{s->0} Im(phi)/s
    % adaptive choice of the patch width s0
    s0 = 1/(1+sqrt(abs(trBV))*(1+abs(r)));
    fs0 = bhat_int(s0,r,T,phi,ruv,'cdf',engine);
    k = 0;
    while abs(fs0-L0) > 0.01*(abs(L0)+1e-12) && k < 50
        s0 = s0/2; k = k+1;
        fs0 = bhat_int(s0,r,T,phi,ruv,'cdf',engine);
    end
    pp = spline([0 s0/2 s0],[L0 bhat_int(s0/2,r,T,phi,ruv,'cdf',engine) fs0]);
    F(i) = 0.5-integral(@(s) patched(s,r,pp,s0),0,Inf, ...
                        'AbsTol',tol,'RelTol',1e-6)/pi;
end
F = max(0,min(1,F));

    function y = patched(s,r,pp,s0)
        y = bhat_int(s,r,T,phi,ruv,'cdf',engine);
        small = s < s0;
        if any(small)
            y(small) = ppval(pp,s(small));
        end
    end
end
