function F = bhat_cdf_eig(x,T,b,phi,c0,ruv,tol)
%BHAT_CDF_EIG  Cdf of betahat via the classical eigenvalue approach.
%
%   Same inputs/outputs as BHAT_CDF.  For each evaluation point:
%   O(T^3) eigenvalue decomposition, then Imhof (1961) inversion with
%   an O(T) integrand.  Benchmark for the timing comparisons in the
%   paper; use BHAT_CDF in applications.

if nargin < 7, tol = 1e-8; end
[A,B] = bhat_eig_setup(T,b,phi,c0,ruv);
F = zeros(size(x));
for i = 1:numel(x)
    lam = eig(A-x(i)*B);                   % O(T^3) per evaluation point
    F(i) = 0.5-integral(@(u) imhof_int(u,lam),0,Inf, ...
                        'AbsTol',tol,'RelTol',1e-6)/pi;
end
F = max(0,min(1,F));
end

function y = imhof_int(u,lam)
p     = lam*u;
theta = 0.5*sum(atan(p),1);
logrho = 0.25*sum(log1p(p.*p),1);
y     = sin(theta).*exp(-logrho)./u;
y(u==0) = 0.5*sum(lam);                    % removable singularity
end
