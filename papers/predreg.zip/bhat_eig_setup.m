function [A,B] = bhat_eig_setup(T,b,phi,c0,ruv)
%BHAT_EIG_SETUP  (2T-2)-dimensional quadratic-form matrices for betahat.
%
%   [A,B] = BHAT_EIG_SETUP(T,b,phi,c0,ruv) builds symmetric matrices A
%   and B such that x'Ax/x'Bx with x ~ N(0,I_{2T-2}) has the
%   distribution of betahat itself.  Used by the eigenvalue-approach
%   benchmarks BHAT_PDF_EIG and BHAT_CDF_EIG.  (Setup cost is O(T^3)
%   but is incurred once; the per-point eigendecomposition dominates.)

if ~isscalar(phi) || ~isreal(phi) || abs(phi) >= 1
    error('predreg:phi',['The predictor must be a stationary AR(1): ' ...
        '|phi| < 1 is required.  The unit-root case has no stationary ' ...
        'distribution for z_0 and is a different problem.']);
end
c1 = ruv*c0;                                    % sigma_uv/sigma_v^2
P  = null(ones(1,T));
W = toeplitz(phi.^(0:T-1))/(1-phi^2);
K  = toeplitz([0 phi.^(0:T-2)]);
G  = toeplitz(zeros(1,T),[0 phi.^(0:T-2)]);
Vz = P'*W*P;   Vz = 0.5*(Vz+Vz');
Vy = P'*(c0^2*eye(T)+b*c1*K+b^2*W)*P;
Vyz= P'*(b*W+c1*G)*P;
Sy = Vy-Vyz/Vz*Vyz';  Sy = 0.5*(Sy+Sy');
Vy1= chol(Sy);
[Q,D] = eig(Vz);
A12 = Vyz*Q/sqrt(D);
A = [zeros(T-1,2*T-2); sqrt(D)*Q'*Vy1' sqrt(D)*Q'*A12];
A = 0.5*(A+A');
B = [zeros(T-1,2*T-2); zeros(T-1) D];
B = 0.5*(B+B');
end
