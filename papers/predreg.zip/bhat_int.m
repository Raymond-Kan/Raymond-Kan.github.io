function y = bhat_int(s,r,T,phi,ruv,mode,engine)
%BHAT_INT  Integrand for the distribution of b.
%
%   y = BHAT_INT(s,r,T,phi,ruv,mode) evaluates, for a vector of
%   quadrature points s, the integrand of the inversion formula for the
%   distribution of b = (sigma_v/sigma_u)*(betahat - beta):
%
%     mode = 'cdf':  Im(phi_{U,W}(s,-r*s))/s      [P(b<r) = 1/2 - int/pi]
%     mode = 'pdf':  Re(d phi_{U,W}/dt |_{t=-r*s})  [f_b(r) = int/pi]
%
%   The characteristic function is evaluated through the bordered
%   tridiagonal-Toeplitz reduction of the paper (Section 3).  The
%   optional argument engine selects the phase computation:
%
%     'fast'  (default) the pure O(1) closed-form assembly
%             (provably continuous by the accretivity proposition of
%             the paper); every
%             quadrature point costs a fixed number of operations,
%             independent of T;
%     'auto'  the O(1) assembly plus O(1) cancellation indicators;
%             the rare flagged points (the phi -> 1 mid-band) are
%             recomputed with the stable pivot recursion for uniform
%             accuracy, at O(T) cost on those points only;
%     'pivot' the certified continuous branch of |C|^{-1/2} computed
%             from the LU pivots of C via BORDERED_PHASE.  Since C is
%             accretive along the path, every pivot lies in the open
%             right half plane and the sum of principal pivot
%             arguments is provably the continuous phase -- pointwise,
%             with no branch condition.  Costs O(T) per point (scalar
%             recursion, no matrix operations).
%
%   Moduli are assembled in logs, so both engines are overflow-free
%   for any T.
%
%   See also BHAT_PDF, BHAT_CDF, TTPRIMS, BORDERED_PHASE.

if nargin < 7, engine = 'fast'; end
if ~isscalar(phi) || ~isreal(phi) || abs(phi) >= 1
    error('predreg:phi',['The predictor must be a stationary AR(1): ' ...
        '|phi| < 1 is required.  The unit-root case has no stationary ' ...
        'distribution for z_0 and is a different problem.']);
end
m  = T-2;                            % interior block dimension
is_pdf = strcmpi(mode,'pdf');
order  = 1 + is_pdf;                 % pdf needs D^{-2} forms

s  = s(:).';
s2 = s.^2;
pref = sqrt(1-phi^2);
c11  = 1+(1+(T*(T-1)-1)*(1-ruv^2))/T^2*s2+2i*(ruv*phi+r)*s*(1-1/T);
c1n = -(T-ruv^2)/T^2*s2+1i*((1-phi)*ruv-2*r)*s/T;
cnn = 1+(T-1)*(T-ruv^2)/T^2*s2+2i*(ruv/T+(1-1/T)*r)*s;
% Delta = D - kap*1*1'; a = a1*1+q*e_1; b = b1*1+q*e_m
kap = (T*(1-ruv^2)-ruv^2)/T^2*s2-2i*((1-phi)*ruv-r)*s/T;
a1  = (ruv^2-T*(1-ruv^2))/T^2*s2+1i*((1-2*phi)*ruv-2*r)*s/T;
b1  = -(T-ruv^2)/T^2*s2+1i*((2-phi)*ruv-2*r)*s/T;
p   = 1+phi^2+(1-ruv^2)*s2+2i*(phi*ruv+r)*s;
q   = -phi-1i*ruv*s;
% p+2q in closed form.  Formed by subtraction it is a cancellation of
% order (1-phi)^2 against p ~ 2, which costs the primitives a relative
% error of about eps*T^2/5; written this way it is exact to rounding,
% 1-phi itself being exact in floating point for phi >= 1/2.
om  = 1-phi;
p2q = om^2+(1-ruv^2)*s2+2i*(r-om*ruv)*s;

P = ttprims(p,q,m,order,[],p2q);
d1 = P.d1; d2 = P.d2; d3 = P.d3; d4 = P.d4;

% Sherman-Morrison: Delta^{-1} forms
den = 1-kap.*d1;                     % rank-one factor
c1  = kap./den;                      % so Delta^{-1}=D^{-1}+c1*D^{-1}11'D^{-1}
w1  = d1./den;
w2  = d2./den;
w3  = d3+c1.*d2.^2;
w4  = d4+c1.*d2.^2;
% border bilinear forms
g1  = a1.^2.*w1+2*a1.*q.*w2+q.^2.*w3;      % a'Di a
g2  = a1.*b1.*w1+(a1+b1).*q.*w2+q.^2.*w4;  % a'Di b
g3  = b1.^2.*w1+2*b1.*q.*w2+q.^2.*w3;      % b'Di b
e1  = c11-g1;
e2  = c1n-g2;
e3  = cnn-g3;
e4  = e1.*e3-e2.^2;                  % border factor
% |C|^{-1/2} in log-modulus / continuous-phase form
if strcmpi(engine,'pivot')
    [labsC,argC] = bordered_phase(p,q,kap,c11,c1n,cnn,a1,b1,T);
    logmag = -0.5*labsC+log(pref);
    ph     = -0.5*argC;
else
    logmag = 0.5*(P.logabs_invD-log(abs(den))-log(abs(e4)))+log(pref);
    ph     = 0.5*(P.arg_invD-angle(den)-angle(e4));
    if strcmpi(engine,'auto')
        % O(1) cancellation indicators: the achievable relative error
        % of the assembled factors is roughly (primitive accuracy)*amp,
        % so flag generously; recompute flagged points with the stable
        % pivot recursion (rare => amortized O(1))
        amp = max(max(abs(kap.*d1)./abs(den), ...
                      (abs(c11)+abs(g1))./abs(e1)), ...
                  max((abs(cnn)+abs(g3))./abs(e3), ...
                      (abs(e1.*e3)+abs(e2).^2)./abs(e4)));
        idx = amp > 1e3 | ~isfinite(amp);
        if any(idx)
            [labsC,argC] = bordered_phase(p(idx),q(idx),kap(idx), ...
                            c11(idx),c1n(idx),cnn(idx),a1(idx),b1(idx),T);
            logmag(idx) = -0.5*labsC+log(pref);
            ph(idx)     = -0.5*argC;
        end
    end
end

if ~is_pdf
    y = exp(logmag).*sin(ph)./s;
    y(~isfinite(y)) = 0;
    return
end

% ---- pdf: multiply by trace(C^{-1}M) = tr(C^{-1}) - 1'C^{-1}1/T ---------
d1t = P.d1t; d2t = P.d2t; d3t = P.d3t; d4t = P.d4t;
% Delta^{-2} forms (differentiate Sherman-Morrison)
w0t = c1.*d2.*(c1.*d2.*d1t+2*d2t);
w1t = d1t./den.^2;
w2t = (d2t+c1.*d2.*d1t)./den;
w3t = d3t+w0t;
w4t = d4t+w0t;
ww1 = a1.^2.*w1t+2*a1.*q.*w2t+q.^2.*w3t;   % a'Di^2 a
ww2 = a1.*b1.*w1t+(a1+b1).*q.*w2t+q.^2.*w4t;
ww3 = b1.^2.*w1t+2*b1.*q.*w2t+q.^2.*w3t;
zz1 = a1.*w1+q.*w2;                        % 1'Di a
zz2 = b1.*w1+q.*w2;                        % 1'Di b
trC  = P.tr1+kap.*d1t./den ...
     + (e3.*ww1+e1.*ww3-2*e2.*ww2)./e4+(e1+e3)./e4;
oneC = (e1+e3-2*e2+2*(e2-e3).*zz1+2*(e2-e1).*zz2)./e4 ...
     + w1+(e3.*zz1.^2+e1.*zz2.^2-2*e2.*zz1.*zz2)./e4;
tr  = trC-oneC/T;
y   = exp(logmag+log(abs(tr))).*cos(ph+angle(tr));
y(~isfinite(y)) = 0;
end
