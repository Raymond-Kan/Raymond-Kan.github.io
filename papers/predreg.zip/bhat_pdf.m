function f = bhat_pdf(x,T,b,phi,c0,ruv,tol,engine)
%BHAT_PDF  Exact density of the OLS slope estimator of a predictive regression.
%
%   f = BHAT_PDF(x,T,b,phi,c0,ruv) returns the exact finite-sample
%   density of betahat evaluated at the points in x, for the predictive
%   regression r_t = alpha + beta*z_{t-1} + u_t with a stationary AR(1)
%   predictor (correlation phi) and i.i.d. bivariate normal errors.
%
%   Input:
%     x    vector of evaluation points (values of betahat)
%     T    sample size
%     b    true beta
%     phi  AR(1) coefficient of the predictor (|phi|<1)
%     c0   sigma_u/sigma_v
%     ruv  correlation between u_t and v_t
%     tol  absolute tolerance of the quadrature (default 1e-8)
%
%   The integrand is evaluated with O(1) operations per quadrature
%   point independent of T (see paper, Section 3).  Replaces
%   pbetac_pdf; overflow-free for any T.
%
%   See also BHAT_CDF, BHAT_PDF_EIG, BHAT_INT.

if nargin < 7, tol = 1e-8; end
if nargin < 8, engine = 'fast'; end    % strict O(1) default; 'auto' adds pivot fallback
if ~isscalar(phi) || ~isreal(phi) || abs(phi) >= 1
    error('predreg:phi',['The predictor must be a stationary AR(1): ' ...
        '|phi| < 1 is required.  The unit-root case has no stationary ' ...
        'distribution for z_0 and is a different problem.']);
end
f  = zeros(size(x));
xb = (x-b)/c0;                        % work in b-space
for i = 1:numel(xb)
    f(i) = integral(@(s) bhat_int(s,xb(i),T,phi,ruv,'pdf',engine), ...
                    0,Inf,'AbsTol',tol,'RelTol',1e-6);
end
f = max(0,f)/(c0*pi);
end
