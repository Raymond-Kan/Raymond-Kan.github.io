function f = bhat_pdf_eig(x,T,b,phi,c0,ruv,tol)
%BHAT_PDF_EIG  Density of betahat via the classical eigenvalue approach.
%
%   Same inputs/outputs as BHAT_PDF.  For each evaluation point the
%   distribution of the ratio of quadratic forms is computed by an
%   O(T^3) eigenvalue decomposition followed by Geary-type numerical
%   inversion with an O(T) integrand (Imhof 1961; Broda and Paolella
%   2009).  Provided as the benchmark for the timing comparisons in the
%   paper; use BHAT_PDF in applications.

if nargin < 7, tol = 1e-8; end
[A,B] = bhat_eig_setup(T,b,phi,c0,ruv);
f = zeros(size(x));
r2pi = 1/(2*pi);
for i = 1:numel(x)
    [P,L] = eig(A-x(i)*B,'vector');        % O(T^3) per evaluation point
    lam = L;
    hh  = sum(P.*(B*P),1).';               % diag(P'*B*P)
    f(i) = r2pi*integral(@(u) geary_int(u,lam,hh),0,Inf, ...
                         'AbsTol',tol,'RelTol',1e-6);
end
f = abs(f);
end

function y = geary_int(u,lam,hh)
p    = lam*u;
d1   = 1./(1+p.*p);
beta = 0.5*sum(atan(p),1);
rho  = hh.'*d1;
del  = hh.'*(d1.*lam);
y    = (cos(beta).*rho-u.*sin(beta).*del).*exp(0.25*sum(log(d1),1));
end
