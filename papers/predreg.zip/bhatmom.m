function m = bhatmom(p,T,beta,phi,sigu,sigv,ruv,engine)
%BHATMOM  Exact moments of the OLS slope estimate betahat.
%
%   m = BHATMOM(p,T,beta,phi,sigu,sigv,ruv) returns m(j) = E[betahat^j]
%   for j = 1..p, in the original (unstandardized) regression
%       r_t = alpha + beta z_{t-1} + u_t,
%       z_t = mu_z(1-phi) + phi z_{t-1} + v_t,
%   with sd(u) = sigu, sd(v) = sigv, corr(u,v) = ruv and |phi| < 1.
%
%   Since betahat = beta + (sigu/sigv) b holds identically, with
%   b = (sigv/sigu)(betahat - beta) whose distribution depends only on
%   (T, phi, ruv), the moments follow from the exact binomial identity
%
%       E[betahat^j] = sum_{i=0}^{j} C(j,i) beta^{j-i} (sigu/sigv)^i E[b^i].
%
%   E[betahat^j] exists if and only if j < T-1.

if nargin < 8 || isempty(engine), engine = 'fast'; end
mb = [1, bmom(p,T,phi,ruv,[],engine)];   % E[b^0..b^p]
c  = sigu/sigv;
m  = zeros(1,p);
for j = 1:p
    v = 0;
    for i = 0:j
        v = v + nchoosek(j,i)*beta^(j-i)*c^i*mb(i+1);
    end
    m(j) = v;
end
end
