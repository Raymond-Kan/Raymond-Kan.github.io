function m = bmom(p,T,phi,ruv,nq,engine)
%BMOM  Exact moments of b = (sigma_v/sigma_u)(betahat - beta).
%
%   m = BMOM(p,T,phi,ruv) returns m(j) = E[b^j] for j = 1..p.
%
%   The distribution of b depends only on (T, phi, ruv): it is the
%   centered slope estimate of the standardized regression and is free of
%   beta, sigma_u and sigma_v.  The representation is the classical
%   gamma-integral linearisation of the denominator,
%
%       E[b^j] = E[U_A^j U_B^{-j}]
%              = 1/Gamma(j) int_0^inf s^{j-1} E[U_A^j e^{-s U_B}] ds,
%
%   with U_A = z'Mu, U_B = z'Mz, and the inner expectation is a
%   derivative of the mgf, evaluated by QFMGF_DP.  E[b^j] exists if and
%   only if j < T-1.
%
%   nq (optional) is the number of Gauss-Legendre nodes (default 64).
%   engine (optional) selects the mgf evaluator: 'fast' (default, O(1)
%   per point) or 'banded' (O(T) per point, retained as a check).

if nargin < 5 || isempty(nq), nq = 64; end
if nargin < 6 || isempty(engine), engine = 'fast'; end
if p >= T-1
    error('predreg:mom','E[b^p] exists only for p < T-1.');
end
par = qfmgf_setup(T,phi,ruv,0,engine);

[q,w] = gauss01(nq);
sv  = (q./(1-q))/par.cB;
jac = 1./(par.cB*(1-q).^2);
[D,lp0] = qfmgf_dp(p, zeros(1,nq), sv, zeros(1,nq), par, max(24,4*p));

m = zeros(1,p);
for j = 1:p
    m(j) = real(sum(w.*jac.*exp((j-1)*log(sv)+lp0).*D(j,:)))/gamma(j);
end
end

function [x,w] = gauss01(n)
j = 1:n-1; b = j./sqrt(4*j.^2-1);
[V,Dg] = eig(diag(b,1)+diag(b,-1));
[x,ix] = sort(diag(Dg).'); w = 2*V(1,ix).^2;
x = (x+1)/2; w = w/2;
end
