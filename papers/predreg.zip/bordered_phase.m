function [logabsC,argC] = bordered_phase(p,q,kap,c11,c1n,cnn,a1,b1,T)
%BORDERED_PHASE  Certified continuous phase of a bordered determinant.
%
%   [logabsC,argC] = BORDERED_PHASE(p,q,kap,c11,c1n,cnn,a1,b1,T)
%   computes log|C| and the CONTINUOUS phase of |C| for the T x T
%   bordered matrix
%
%       C = [ c11   a'      c1n  ]
%           [ a     D-kap*J b    ]      a = a1*1 + q*e_1,
%           [ c1n   b'      cnn  ]      b = b1*1 + q*e_m,   J = 11',
%
%   with D the m x m (m = T-2) symmetric tridiagonal Toeplitz matrix
%   with diagonal p and off-diagonal q.  All inputs may be arrays of
%   the same size (vectorized over quadrature points).
%
%   METHOD (paper, Proposition on the pivot phase): along the
%   integration paths the matrix C is accretive (Re C > 0), so every
%   LU pivot p_k = |C_k|/|C_{k-1}| lies in the open right half plane
%   and the pointwise sum of PRINCIPAL arguments
%       argC = sum_k arg(p_k)
%   is provably the unique continuous determination of the phase --
%   no path tracking, no branch conditions, no jump monitoring.  The
%   pivots are obtained from scalar forward recursions of the bordered
%   closed forms (O(T) per point):
%       pi_{j+1}  = p - q^2/pi_j                     (pivot of D_j)
%       gam_{j+1} = (1-q*gam_j)/pi_{j+1}             (1'D^{-1}e_last)
%       rho_{j+1} = -q*rho_j/pi_{j+1}                (e_1'D^{-1}e_last)
%       u_{j+1}   = u_j+(q*gam_j-1)^2/pi_{j+1}       (1'D^{-1}1)
%       v_{j+1}   = v_j+q*rho_j*(q*gam_j-1)/pi_{j+1} (e_1'D^{-1}1)
%       f_{j+1}   = f_j+q^2*rho_j^2/pi_{j+1}         (e_1'D^{-1}e_1)
%   with pivots of C assembled through the rank-one and border
%   corrections at each size.
%
%   See also TTPRIMS, BHAT_INT, R1R2_GH.

sz = size(p);
p = p(:).'; q = q(:).'; kap = kap(:).';
c11 = c11(:).'; c1n = c1n(:).'; cnn = cnn(:).';
a1 = a1(:).'; b1 = b1(:).';
N = numel(p);
m = T-2;

% first pivot of C
logabsC = log(abs(c11));
argC    = angle(c11);

% states for D_j (j = 0 start)
piv = p;                        % pi_1
gam = 1./piv; rho = gam; u = gam; v = gam; f = gam;   % j = 1 states
u_prev = zeros(1,N); g_prev = zeros(1,N);             % u_0, g_0
% g_j = a'Delta_j^{-1}a
for j = 1:m
    if j > 1
        piv = p-q.^2./piv;                    % pivot of D_j
        gm1 = gam; rh1 = rho;
        u   = u+(q.*gm1-1).^2./piv;
        v   = v+q.*rh1.*(q.*gm1-1)./piv;
        f   = f+q.^2.*rh1.^2./piv;
        gam = (1-q.*gm1)./piv;
        rho = -q.*rh1./piv;
    end
    den = 1-kap.*u;
    g   = a1.^2.*u./den+2*a1.*q.*v./den+q.^2.*(f+kap.*v.^2./den);
    % pivot of C at size j+1: |C_{j+1}|/|C_j|
    pC  = piv.*(den./(1-kap.*u_prev)).*((c11-g)./(c11-g_prev));
    logabsC = logabsC+log(abs(pC));
    argC    = argC+angle(pC);
    u_prev  = u; g_prev = g;
end
% last pivot: pC_T = delta3 - delta2^2/delta1  (full border assembly)
den = 1-kap.*u;
fend = 1./piv;                                % e_m'D_m^{-1}e_m
d1b  = c11-g_prev;                            % delta_1
d2b  = c1n-(a1.*b1.*u./den+a1.*q.*gam./den+b1.*q.*v./den ...
       +q.^2.*(rho+kap.*v.*gam./den));        % delta_2
d3b  = cnn-(b1.^2.*u./den+2*b1.*q.*gam./den ...
       +q.^2.*(fend+kap.*gam.^2./den));       % delta_3
pC   = d3b-d2b.^2./d1b;
logabsC = logabsC+log(abs(pC));
argC    = argC+angle(pC);

logabsC = reshape(logabsC,sz);
argC    = reshape(argC,sz);
end
