function check_cdstep
%CHECK_CDSTEP  Is the R^2 density/central-difference gap truncation error?
%
%   Part C of TEST_CERTIFY compares rsq_pdf against a central difference
%   of rsq_cdf and finds agreement of about 1 to 2 percent, an order of
%   magnitude worse than for the t-ratio.  The R^2 density is very
%   sharply curved near the origin -- it carries a w^{-1/2} singularity
%   at zero and decays by a factor of 400 between w = 0.05 and w = 0.15 --
%   so the O(h^2) truncation of a central difference should dominate
%   there.  If that is the explanation, halving h must cut the gap by
%   four, and Richardson extrapolation of the two differences must land
%   on the density.  If instead the two routines disagree, the gap will
%   be insensitive to h.
%
%   Writes cdstep.txt incrementally.

fid = fopen('cdstep.txt','w'); out = [1 fid];
    function pr(varargin)
        for o = out, fprintf(o,varargin{:}); end
    end

T = 120; bt = 0; phi = 0.99; ruv = -0.856; w = 0.05;
pr('T=%d phi=%.4f ruv=%.3f  w=%.3f\n\n',T,phi,ruv,w);

tt = tic; f = rsq_pdf(w,T,bt,phi,ruv,1e-5);
pr('rsq_pdf                      = %.8f   (%.1fs)\n',f,toc(tt));

hs = [0.005 0.0025];
cd = zeros(size(hs));
for i = 1:numel(hs)
    h = hs(i); tt = tic;
    cd(i) = (rsq_cdf(w+h,T,bt,phi,ruv,1e-6) ...
            -rsq_cdf(w-h,T,bt,phi,ruv,1e-6))/(2*h);
    pr('central difference h=%.4f  = %.8f   gap %+.8f  (%.1fs)\n', ...
       h,cd(i),cd(i)-f,toc(tt));
end

pr('\ngap ratio h to h/2           = %.3f   (4.00 if O(h^2) truncation)\n', ...
   (cd(1)-f)/(cd(2)-f));
rich = (4*cd(2)-cd(1))/3;
pr('Richardson (4c(h/2)-c(h))/3  = %.8f   vs density %.8f  (rel %.2e)\n', ...
   rich,f,abs(rich-f)/f);
fclose(fid);
end
