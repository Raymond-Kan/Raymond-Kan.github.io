function demo_predreg
%DEMO_PREDREG  Worked examples for the predictive-regression programs.
%
%   Reproduces a small set of exact finite-sample quantities for a
%   monthly-style calibration and prints them with timings.  Runs in
%   a few minutes; see manual.pdf for the interpretation.

fprintf('Calibration: T = 120, phi = 0.95, ruv = -0.856,\n');
fprintf('             beta = 0 (null) and population R^2 = 2%% (alternative)\n\n');
T = 120; phi = 0.95; ruv = -0.856;
btA = sqrt(0.02/0.98*(1-phi^2));       % normalized slope, population R^2 = 2%

% ---- distribution of betahat (through b), beta = 0, sigu = sigv = 1 ---
tic;
p5  = bhat_cdf(-0.0326,T,0,phi,1,ruv); % P[betahat < -0.0326]
d0  = bhat_pdf(0,T,0,phi,1,ruv);       % density at 0
fprintf('betahat  (null):  P[betahat < -0.0326] = %.6f,  f(0) = %.4f   (%.2fs)\n', ...
    p5,d0,toc);

% ---- t-ratio: exact size of the nominal 5%% two-sided test -------------
tic;
sz = trat_cdf(-1.96,T,0,phi,ruv) + 1 - trat_cdf(1.96,T,0,phi,ruv);
fprintf('t-ratio  (null):  exact size of the |t|>1.96 test = %.4f      (%.1fs)\n', ...
    sz,toc);

% ---- R^2: how often does a 5%% sample R^2 arise with no predictability? -
tic;
pr = 1 - rsq_cdf(0.05,T,0,phi,ruv);
fprintf('R^2      (null):  P[R^2 > 0.05] = %.4f                        (%.1fs)\n', ...
    pr,toc);

% ---- exact moments ----------------------------------------------------
tic;
mb = bmom(2,T,phi,ruv);
mt = tratmom(2,T,phi,ruv,0);
mr = rsqmom(1,T,phi,ruv,0);
mtA = tratmom(1,T,phi,ruv,btA);
mrA = rsqmom(1,T,phi,ruv,btA);
fprintf('\nExact moments (%.1fs):\n',toc);
fprintf('  E[b]      = %+.6f   (Stambaugh approx %+.6f)\n', ...
    mb(1),-ruv*(1+3*phi)/T);
fprintf('  sd(b)     =  %.6f\n',sqrt(mb(2)-mb(1)^2));
fprintf('  E[t]      = %+.6f   (null)      %+.6f  (population R^2 = 2%%)\n', ...
    mt(1),mtA(1));
fprintf('  sd(t)     =  %.6f   (null)\n',sqrt(mt(2)-mt(1)^2));
fprintf('  E[R^2]    =  %.6f   (null)       %.6f  (population R^2 = 2%%)\n', ...
    mr(1),mrA(1));

% ---- moments of betahat itself, unstandardized ------------------------
beta = 0.05; sigu = 15.83; sigv = 1;   % monthly calibration scale
m = bhatmom(2,T,beta,phi,sigu,sigv,ruv);
fprintf('  With beta = %.2f, sigu/sigv = %.2f:  E[betahat] = %.4f, sd = %.4f\n', ...
    beta,sigu/sigv,m(1),sqrt(m(2)-m(1)^2));
end
