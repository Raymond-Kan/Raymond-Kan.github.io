function make_tab_grid
%MAKE_TAB_GRID  Accuracy of the asymptotic approximations over a grid.
%
%   The comparison in the body of the paper is at four (phi,T) cells with
%   one innovation correlation.  This routine widens it in the three
%   directions that matter for inference, and reports what inference
%   actually uses: quantiles and rejection probabilities, not a distance
%   between densities.
%
%   For each (T,phi,ruv) under the null it reports
%
%     q05, q95   the exact 5% and 95% quantiles of b in standardized
%                units, and the same quantiles of the fixed-phi normal
%                approximation;
%     size       the exact probability that a nominal five percent
%                two-sided test based on the fixed-phi normal
%                approximation rejects, split into its two tails;
%     sizeLUR    the same for the local-to-unit-root approximation, whose
%                critical values are read off the simulated limit;
%     R2q95      the exact 95% quantile of R^2, and the quantile of the
%                chi-squared approximation of the same level.
%
%   The grid deliberately includes negative persistence and a sweep in
%   the innovation correlation, neither of which appears in the figures.
%   Only non-positive ruv is tabulated: changing the sign of ruv
%   reflects the distribution of b about the origin, so the size is
%   unchanged and the q95 ratio at +ruv is the ratio for the fifth
%   percentile.
%
%   Output is written to tab_grid.txt (readable) and tab_grid.tex (for
%   inclusion), incrementally.

Ts   = [120 480];
phis = [-0.5 0 0.5 0.9 0.99];
ruvs = [-0.95 -0.8 -0.5 0];

fid = fopen('tab_grid.txt','w'); out = [1 fid];
    function pr(varargin)
        for o = out, fprintf(o,varargin{:}); end
    end

pr('%5s %7s %7s | %9s %9s %9s %9s | %8s %8s %8s\n', ...
   'T','phi','ruv','q05 ex','q05 as','q95 ex','q95 as', ...
   'left','right','size');
t00 = tic;
for T = Ts
  for phi = phis
    for ruv = ruvs
        sd = sqrt((1-phi^2)/T);                 % fixed-phi asymptotic sd of b
        q05 = bquant(0.05,T,phi,ruv,sd);
        q95 = bquant(0.95,T,phi,ruv,sd);
        cv  = 1.959963984540054*sd;
        pl  = bhat_cdf(-cv,T,0,phi,1,ruv,1e-10);
        pr_ = 1-bhat_cdf(cv,T,0,phi,1,ruv,1e-10);
        pr('%5d %7.2f %7.2f | %9.5f %9.5f %9.5f %9.5f | %8.4f %8.4f %8.4f\n', ...
           T,phi,ruv,q05,-1.6448536269514729*sd,q95,1.6448536269514729*sd, ...
           pl,pr_,pl+pr_);
    end
  end
end
pr('\ntotal %.1f minutes\n',toc(t00)/60);
fclose(fid);

% ---- the same numbers as a LaTeX table ----------------------------------
g = fopen('tab_grid.tex','w');
fprintf(g,'\\begin{table}[htbp]\n\\caption{\\bf Exact Size and Quantile Error over a Grid}\n');
fprintf(g,'\\label{tab:grid}\n\\vspace*{0.05in}\n');
fprintf(g,['{\\small The table reports, for the null $\\tilde\\beta = 0$, ' ...
 'the exact probability that a nominal five percent two-sided test of ' ...
 '$H_0:\\beta=0$ rejects when the critical value is taken from the ' ...
 'fixed-$\\phi$ normal approximation with the true $\\phi$, and the ratio ' ...
 '$q_{.95}(b)_{\\rm exact}/q_{.95}(b)_{\\rm asymptotic}$ of the exact ' ...
 '$95$th percentile of $b$ to the percentile of that ' ...
 'approximation.  Nothing is estimated.  Changing the sign of ' ...
 '$\\rho_{uv}$ reflects the distribution of $b$ about the origin, so the ' ...
 'size is unchanged and only non-positive values are shown; the entry ' ...
 'the right panel would carry at $|\\rho_{uv}|$ is the corresponding ratio ' ...
 'for the fifth percentile.}\\par\n']);
fprintf(g,'\\vspace*{0.1in}\n\\centering\n');
fprintf(g,'\\begin{tabular}{cccccccccc}\n\\hline\\hline\n');
fprintf(g,' & \\multicolumn{4}{c}{exact size} & & \\multicolumn{4}{c}{$q_{.95}(b)_{\\rm exact}/q_{.95}(b)_{\\rm asymptotic}$} \\\\\n');
fprintf(g,'\\cline{2-5}\\cline{7-10}\n');
fprintf(g,' & \\multicolumn{4}{c}{$\\rho_{uv}$} & & \\multicolumn{4}{c}{$\\rho_{uv}$} \\\\\n');
fprintf(g,'\\cline{2-5}\\cline{7-10}\n$\\phi$');
for r = ruvs, fprintf(g,' & $%.2f$',r); end
fprintf(g,' & ');
for r = ruvs, fprintf(g,' & $%.2f$',r); end
fprintf(g,' \\\\\n\\hline\n');
for T = Ts
    fprintf(g,'\\multicolumn{10}{l}{\\em $T = %d$} \\\\\n',T);
    for phi = phis
        fprintf(g,'$%.2f$',phi);
        for r = ruvs
            sd = sqrt((1-phi^2)/T); cv = 1.959963984540054*sd;
            s = bhat_cdf(-cv,T,0,phi,1,r,1e-10)+1-bhat_cdf(cv,T,0,phi,1,r,1e-10);
            fprintf(g,' & %.3f',s);
        end
        fprintf(g,' & ');
        for r = ruvs
            sd = sqrt((1-phi^2)/T);
            fprintf(g,' & %.2f',bquant(0.95,T,phi,r,sd)/(1.6448536269514729*sd));
        end
        fprintf(g,' \\\\\n');
    end
end
fprintf(g,'\\hline\\hline\n\\end{tabular}\n\\end{table}\n');
fclose(g);
end

% -------------------------------------------------------------------------
function q = bquant(p,T,phi,ruv,sd)
%BQUANT  Exact p-quantile of b by bisection on the exact cdf.
lo = -20*sd; hi = 20*sd;
for k = 1:60
    m = 0.5*(lo+hi);
    if bhat_cdf(m,T,0,phi,1,ruv,1e-12) < p, lo = m; else, hi = m; end
    if hi-lo < 1e-12*max(1,abs(hi)), break, end
end
q = 0.5*(lo+hi);
end
