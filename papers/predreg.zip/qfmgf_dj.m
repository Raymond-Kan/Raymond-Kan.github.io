function [D,lp0,info] = qfmgf_dj(pmax,r0,s,t,par)
%QFMGF_DJ  r-derivatives of the mgf by Taylor-mode (jet) arithmetic.
%
%   [D,lp0] = QFMGF_DJ(pmax,r0,s,t,par) returns exactly what QFMGF_DP
%   returns,
%
%       D(m,:) = [d^m Psi(r,s,t)/dr^m]_{r=r0} / Psi(r0,s,t),  m = 1..pmax,
%       lp0    = log Psi(r0,s,t),
%
%   but computes it differently.  QFMGF_DP samples Psi on a circle in the
%   complex r-plane and reads the derivatives off a discrete Fourier
%   transform; the radius of that circle is a tuning parameter, and the
%   accuracy it delivers is a compromise between the p!/h^p amplification
%   of rounding and the (h/R)^{n-p} aliasing error.  This routine has no
%   tuning parameter.  It runs the same O(1) assembly as QFMGF_LOGPSI_F
%   with every scalar replaced by a truncated power series in r, so the
%   coefficients of the resulting series are the derivatives of log Psi
%   exactly, to machine precision, at every order.
%
%   Three facts make this cheap.  First, r enters the assembly only
%   through sc = -i r, and i*sc = r, so k1, k2 and k5 are affine in r and
%   everything downstream of them --- c11, c1n, cnn, a1, b1, cc, pF, qF
%   --- is a quadratic polynomial in r whose jet is exact and finite.
%   Second, the only transcendental step is TTPRIMS, and along the paths
%   these integrals take, every node lies in its generic regime, whose
%   closed forms are compositions of sqrt, log, exp and division: all of
%   them have standard series recursions.  Third, only the coefficients
%   of order one and above are needed, so the constant coefficient of
%   every logarithm may be discarded and no branch question arises
%   anywhere; log Psi itself is taken from QFMGF_LOGPSI_F, which settles
%   its own branch.
%
%   The generic-regime formulas are rewritten in w = q/r1, the ratio of
%   the smaller symbol root to the larger, which satisfies |w| <= 1.  In
%   that variable the n-th powers that TTPRIMS carries as r1^n --- of
%   modulus one, but with jet coefficients growing like n^k --- appear
%   only as w^{2n} and w^{n-2}, which are exponentially small, so no
%   intermediate quantity is larger than the answer it contributes to.
%
%   Series arithmetic has two traps and both are worth naming, since a
%   coefficient array looks exactly like an ordinary array.  Adding a
%   constant to a series touches its constant coefficient only, not
%   every coefficient; and the product of two series is the Cauchy
%   product JM, not the elementwise one.  Multiplying a series by a
%   constant, on the other hand, does scale every coefficient, so a
%   quantity free of r may be carried as a plain row throughout.
%
%   The primitives are functions of the single variable x = p/(2q).  With
%   U the Chebyshev polynomial of the second kind and m the order of the
%   core, d3 = U_{m-1}/(q U_m), d4 = (-1)^{m+1}/(q U_m), and D = q^m U_m,
%   so nothing in them is singular: U_m is entire and does not vanish
%   near the confluent point.  The two remaining primitives are written
%   with a factor x+1 in the denominator, but their numerators vanish
%   there,
%
%       U_m + U_{m-1} + (-1)^{m+1} = (x+1) Q,     m U_m + Q = (x+1) S,
%
%   so d2 = Q/(2 q U_m) and d1 = S/(2 q U_m) have no singularity either.
%   Two branches suffice, and they differ only in how U_m and U_{m-1} are
%   evaluated: away from confluence by the closed forms in the roots,
%   near it by their Taylor expansion at x = -1, whose coefficients are
%   explicit.  info.regime reports the fraction taken by the first.
%
%   See also QFMGF_DP, QFMGF_LOGPSI_F, TTPRIMS.

r0 = r0(:).'; s = s(:).'; t = t(:).';
N  = max([numel(r0) numel(s) numel(t)]);
if isscalar(r0), r0 = repmat(r0,1,N); end
if isscalar(s),  s  = repmat(s,1,N);  end
if isscalar(t),  t  = repmat(t,1,N);  end
K = pmax;
T = par.T; phi = par.phi; ruv = par.ruv; bt = par.bt;
n = T-1;

lp0 = real(qfmgf_logpsi_f(r0,s,t,par));

% ---- the jet of r, and the quantities that do not depend on it ---------
R  = zeros(K+1,N); R(1,:) = r0; if K >= 1, R(2,:) = 1; end
sc = -1i*R;                                  % cf argument for U_A
tc =  1i*t;                                  % cf argument for U_C, constant
c0 =  2*s/T;                                 % U_B contribution, constant

lam1 = 1/(1-ruv^2)-2i*tc;
lam2 = 1-2i*tc;
sli  = n./lam1+1./lam2;
cS   = 2i*tc./(T+2i*tc.*sli);
k4   = -ruv/(1-ruv^2);

% ---- the assembly, in jet arithmetic ----------------------------------
k1 = jc(-1i*sc, (ruv*phi-bt)/(1-ruv^2));     % affine in r
k2 = 1i*sc/T;
k5 = -jc(1i*sc, bt);
k3 = k1./lam1 + k2.*sli;
k6 = jc(k5./lam2 + k2.*sli, k4./lam1);
k1k4 = jc(-1i*sc, -(ruv*(1-phi)+bt)/(1-ruv^2));   % = k1+k4, no cancellation

c11 = jc(-( jm(k1./lam1, k1+2*k2) + jm(k2,k2).*sli - cS.*jm(k3,k3) ), ...
         1+(bt-ruv*phi)^2/(1-ruv^2)+n*c0);
c1n = jc(-( jm(k2./lam1, k1k4) + jm(k2,k5)./lam2 ...
          + jm(k2,k2).*sli - cS.*jm(k3,k6) ), -c0);
cnn = jc(-(k4./lam1).*jc(2*k2,k4) - jm(k5, k5+2*k2)./lam2 ...
         - jm(k2,k2).*sli + cS.*jm(k6,k6), 1/(1-ruv^2)+bt^2+n*c0);
q0e = k1k4./lam1 + k2.*sli;
a1  = jc(-jm(k1,k2)./lam1 - jm(k2-cS.*k3, q0e), -c0);
b1  = jc(-jm(k2,k1k4)./lam1 - jm(k2-cS.*q0e, k6), -c0);
cc  = jc( 2*jm(k1k4,k2)./lam1 + jm(k2,k2).*sli - cS.*jm(q0e,q0e), c0);
pF  = jc(-jc(jm(k1,k1), k4^2)./lam1, ...
         (1+phi^2+bt^2-2*bt*ruv*phi)/(1-ruv^2)+T*c0);
qF  = jc(-(k1*k4)./lam1, (bt*ruv-phi)/(1-ruv^2));

% pF+2qF in closed form.  Formed as pF+2qF it is a cancellation of order
% (1-phi)^2 against pF ~ 2, and the primitives amplify the loss by T^2;
% written this way it is exact to rounding.  See TTPRIMS.
om  = 1-phi;  wr = 1-ruv^2;  uu = -1i*sc;  Lam = 1-2i*tc*wr;
pq2 = jc(2*uu*((ruv*om+bt)) - wr*jm(uu,uu), ...
         om^2-2i*tc*((om+bt*ruv)^2+bt^2*wr)+T*c0.*Lam)./Lam;

% ---- primitives of the tridiagonal Toeplitz core, in jet arithmetic ----
thr = 2.5;                                   % TTPRIMS's own branch test
if isfield(par,'ttsplit'), thr = par.ttsplit; end
[d1,d2,d3,d4,lgi,frac] = ttprims_jet(pF,qF,n,K,thr,pq2);

% ---- Sherman-Morrison for the demeaning term, then the 2x2 border ------
c1 = jd(cc, jc(jm(cc,d1),-1));
rr = jc(-jm(c1,d1), 1);
w1 = jm(rr,d1);
w2 = jm(rr,d2);
d2sq = jm(d2,d2);
w3 = d3 - jm(c1,d2sq);
w4 = d4 - jm(c1,d2sq);
qq = jm(qF,qF);
g1 = jm(jm(a1,a1),w1) + 2*jm(jm(a1,qF),w2) + jm(qq,w3);
g2 = jm(jm(a1,b1),w1) +   jm(jm(a1+b1,qF),w2) + jm(qq,w4);
g3 = jm(jm(b1,b1),w1) + 2*jm(jm(b1,qF),w2) + jm(qq,w3);
cr = jc(-jm(cc,d1), 1);
e1 = c11-g1;  e2 = c1n-g2;  e3 = cnn-g3;
e4 = jm(e1,e3) - jm(e2,e2);

% ---- log Psi, derivative coefficients only ----------------------------
% the terms in lam1, lam2 and sli carry no r at all, so they contribute
% to the constant coefficient alone and are dropped here
L = 0.5*(lgi - jlog0(cr) - jlog0(e4));

% ---- cumulants, then the moment-cumulant recursion --------------------
kap = zeros(K,N);
for j = 1:K, kap(j,:) = factorial(j)*L(j+1,:); end
D    = zeros(K,N);
Dall = zeros(K+1,N);  Dall(1,:) = 1;
for m = 1:K
    acc = zeros(1,N);
    for j = 1:m
        acc = acc + nchoosek(m-1,j-1)*kap(j,:).*Dall(m-j+1,:);
    end
    Dall(m+1,:) = acc;
    D(m,:) = acc;
end
D = real(D);
info = struct('regime',frac,'cumulants',real(kap));
end

% =========================================================================
function [d1,d2,d3,d4,lgi,frac] = ttprims_jet(p,q,n,K,thr,p2q)
%TTPRIMS_JET  Primitives of the tridiagonal Toeplitz core, in series form.
%   The quantities TTPRIMS returns at order one, as truncated power
%   series, with lgi the derivative part of log(1/|D|).  The split is on
%   the same test TTPRIMS applies, and is a question of how to evaluate
%   the two Chebyshev values, not of which formulas hold.  The threshold
%   is exposed as par.ttsplit so that the two branches can be run against
%   each other on the same nodes.
p    = p2q-2*q;                 % keep every primitive that of one matrix
xd   = p2q(1,:)./(2*q(1,:));
gen  = abs(xd)*n^2 >= thr;
frac = mean(gen);
N    = size(p,2);
d1 = zeros(K+1,N); d2 = d1; d3 = d1; d4 = d1; lgi = d1;
if any(gen)
    [d1(:,gen),d2(:,gen),d3(:,gen),d4(:,gen),lgi(:,gen)] = ...
        tt_generic(p(:,gen),q(:,gen),n,p2q(:,gen));
end
if any(~gen)
    [d1(:,~gen),d2(:,~gen),d3(:,~gen),d4(:,~gen),lgi(:,~gen)] = ...
        tt_conf(p(:,~gen),q(:,~gen),n,K,p2q(:,~gen));
end
end

% =========================================================================
function [d1,d2,d3,d4,lgi] = tt_generic(p,q,n,p2q)
%TT_GENERIC  The closed forms, written in w = q/r1 so that every power of
%   the roots is bounded in modulus.
h  = jsq(jm(p2q-4*q, p2q));    % = p^2-4q^2, without cancelling
r1 = (p+h)/2;                       % the root of larger modulus
w  = jd(q,r1);                      % |w| <= 1, and r2/r1 = w^2
A2n  = jpow(w,2*n);
A2n2 = jpow(w,2*n-2);
An2  = jpow(w,n-2);
den  = jc(-A2n, 1);
d3   = jd(jd(jc(-A2n2,1), r1), den);
d4   = ((-1)^n)*jd(jm(An2,h), jm(jm(r1,r1),den));
q0   = p2q;
d2   = jd(jc(jm(q,d3+d4), 1), q0);
d1   = jd(jc(2*jm(q,d2), n-1), q0);
lgi  = jlog0(h) - jlog0(den) - n*jlog0(r1);
end

% =========================================================================
function [d1,d2,d3,d4,lgi] = tt_conf(p,q,n,K,p2q)
%TT_CONF  The confluent neighbourhood, by expansion at the confluent point.
%
%   The formulas of TT_GENERIC are written in the roots, which coalesce as
%   x = p/(2q) approaches -1, and the closed forms lose their accuracy
%   there although the quantities themselves stay bounded.  Nothing is
%   actually singular: the primitives are rational in U_m(x) and
%   U_{m-1}(x), which are entire and, near x = -1, of size m.  So the
%   remedy is simply to evaluate the two Chebyshev values by their Taylor
%   series at the confluent point, whose coefficients are explicit,
%
%       U_m^{(k)}(-1)/k! = (-1)^{m+k} f_k,   f_0 = m+1,
%       f_{k+1}/f_k = (m-k)(m+k+2)/((2k+3)(k+1)).
%
%   The two primitives that carry a factor x+1 in the denominator are
%   handled by dividing the series rather than the values: the numerators
%   U_m+U_{m-1}+(-1)^{m+1} and m U_m + Q vanish at x = -1, so dropping
%   their leading coefficient and shifting the index by one gives Q and S
%   with no cancellation at all.
%
%   Twenty terms reach machine precision across the band.  The ratio of
%   successive terms in the shifted sum is bounded by tau/((j+1)(2j+3))
%   with tau = |x+1| n^2 < 2.5, which is the definition of the band, so
%   the sum converges faster than geometrically from the second term on
%   and the same truncation serves every derivative order.
m  = n-1;
JT = 20;
L  = K+JT+2;

% ---- Taylor coefficients at x = -1 -----------------------------------
eA = zeros(1,L+1);  eA(1) = (-1)^m*(m+1);           % U_m
for i = 0:L-1
    eA(i+2) = -eA(i+1)*(m-i)*(m+i+2)/((2*i+3)*(i+1));
end
eB = zeros(1,L+1);  eB(1) = (-1)^(m-1)*m;           % U_{m-1}
for i = 0:L-1
    eB(i+2) = -eB(i+1)*(m-1-i)*(m+i+1)/((2*i+3)*(i+1));
end
eQ = eA(2:end)+eB(2:end);                           % P = (x+1) Q
eR = m*eA(1:L)+eQ;                                  % R = m U_m + Q
eS = eR(2:end);                                     % R = (x+1) S

% ---- the jet of x, and of x - x0 --------------------------------------
% delta = x+1 comes from p2q directly, never from p+2q by subtraction
dl = jd(p2q,2*q);                                   % delta = x+1
u0 = dl(1,:);                                       % x0 + 1
u  = dl;  u(1,:) = 0;                               % x - x0 = delta - delta0

% ---- shift the expansions to x0, then compose with the jet ------------
A  = jhorner(shiftc(eA,u0,K,JT),u);
B  = jhorner(shiftc(eB,u0,K,JT),u);
Qj = jhorner(shiftc(eQ,u0,K,JT),u);
Sj = jhorner(shiftc(eS,u0,K,JT),u);

qA  = jm(q,A);
d3  = jd(B,qA);
d4  = jd(jc(0*qA,(-1)^(m+1)),qA);
d2  = jd(Qj,2*qA);
d1  = jd(Sj,2*qA);
lgi = -(m*jlog0(q)+jlog0(A));
end

% =========================================================================
function G = shiftc(e,u0,K,JT)
%SHIFTC  Move a Taylor expansion from x = -1 to the base point x0.
%   G(k+1,:) = F^{(k)}(x0)/k! = sum_j C(k+j,k) e_{k+j} (x0+1)^j, the
%   binomial and the power both carried by their own recursions so that
%   nothing larger than the answer is ever formed.
N  = numel(u0);  Le = numel(e);
G  = zeros(K+1,N);
for k = 0:K
    acc = zeros(1,N);  up = ones(1,N);  cb = 1;
    for j = 0:JT
        if k+j+1 > Le, break; end
        acc = acc + (cb*e(k+j+1))*up;
        up  = up.*u0;
        cb  = cb*(k+j+1)/(j+1);
    end
    G(k+1,:) = acc;
end
end

% =========================================================================
function J = jhorner(G,u)
%JHORNER  sum_k G(k+1,:) u^k, with u a jet whose constant coefficient is
%   zero, so the sum is finite and Horner is exact at the truncation.
K = size(G,1)-1;
J = zeros(size(G));  J(1,:) = G(K+1,:);
for k = K-1:-1:0
    J = jm(J,u);
    J(1,:) = J(1,:)+G(k+1,:);
end
end

% =========================================================================
function c = jc(a,v)
%JC  Add a constant to a series: its constant coefficient only.
c = a;
c(1,:) = c(1,:) + v;
end

function c = jm(a,b)
%JM  Product of two truncated power series (the Cauchy product).
K = size(a,1)-1;
if size(a,2) == 1 && size(b,2) > 1, a = repmat(a,1,size(b,2)); end
if size(b,2) == 1 && size(a,2) > 1, b = repmat(b,1,size(a,2)); end
c = zeros(size(a));
for k = 0:K
    acc = zeros(1,size(a,2));
    for j = 0:k
        acc = acc + a(j+1,:).*b(k-j+1,:);
    end
    c(k+1,:) = acc;
end
end

function c = jd(a,b)
%JD  Quotient of two truncated power series.
K = size(b,1)-1;
if size(a,2) == 1 && size(b,2) > 1, a = repmat(a,1,size(b,2)); end
c = zeros(size(b));
c(1,:) = a(1,:)./b(1,:);
for k = 1:K
    acc = a(k+1,:);
    for j = 1:k
        acc = acc - b(j+1,:).*c(k-j+1,:);
    end
    c(k+1,:) = acc./b(1,:);
end
end

function c = jsq(a)
%JSQ  Square root of a truncated power series.
K = size(a,1)-1;
c = zeros(size(a));
c(1,:) = sqrt(a(1,:));
for k = 1:K
    acc = a(k+1,:);
    for j = 1:k-1
        acc = acc - c(j+1,:).*c(k-j+1,:);
    end
    c(k+1,:) = acc./(2*c(1,:));
end
end

function L = jlog0(a)
%JLOG0  Logarithm of a series, with its constant coefficient set to zero.
%   Only the derivative coefficients are wanted and they carry no branch.
K = size(a,1)-1;
L = zeros(size(a));
for m = 1:K
    acc = a(m+1,:);
    for i = 1:m-1
        acc = acc - (i/m)*L(i+1,:).*a(m-i+1,:);
    end
    L(m+1,:) = acc./a(1,:);
end
end

function e = jexp0(a)
%JEXP0  Exponential of a series whose constant coefficient is zero.
K = size(a,1)-1;
e = zeros(size(a));
e(1,:) = 1;
for k = 1:K
    acc = zeros(1,size(a,2));
    for j = 1:k
        acc = acc + (j/k)*a(j+1,:).*e(k-j+1,:);
    end
    e(k+1,:) = acc;
end
end

function c = jpow(a,m)
%JPOW  a^m, without a branch decision.
%   The constant coefficient is the scalar power, which is right for a
%   negative real base at integer m; the higher coefficients come from
%   exp(m*(log a - log a_0)) and depend on derivatives of log a only.
c = jexp0(m*jlog0(a));
c = c .* a(1,:).^m;
end
