function [D,lp0,info] = qfmgf_dp(pmax,r0,s,t,par,ncirc)
%QFMGF_DP  Relative r-derivatives of the mgf at a (possibly shifted) base.
%
%   [D,lp0] = QFMGF_DP(pmax,r0,s,t,par) returns
%
%       D(m,:)  = [d^m Psi(r,s,t)/dr^m]_{r = r0} / Psi(r0,s,t),  m = 1..pmax,
%       lp0     = log Psi(r0,s,t),
%
%   for vectors of evaluation points (r0, s, t).  The caller reassembles
%   the derivative of Psi itself as exp(lp0).*D(m,:), which never over-
%   or underflows prematurely.
%
%   The first derivative is computed by a complex step,
%       d log Psi / dr = Im[log Psi(r0 + i*h_s)]/h_s,
%   which is exact to machine precision because Psi is analytic and real
%   on the real axis; there is no subtractive cancellation.  Higher
%   derivatives are Cauchy coefficients on a circle |r - r0| = h,
%
%       D(m,:) = m!/(n h^m) sum_j Psi_rel(r0 + h e^{i theta_j}) e^{-im theta_j},
%
%   evaluated by the FFT.  The radius is the stability control: too small
%   amplifies roundoff by m!/h^m, too large leaves the domain where the
%   truncation error (h/R)^{n-m} is negligible.  We set
%       h = 0.4 / max(|d log Psi/dr|, 0.4/rscale),
%   i.e. the radius over which log Psi moves by about 0.4, capped by the
%   natural scale of r; the complex-step derivative supplies the estimate
%   for free.  info.tail returns the magnitude of the last Cauchy
%   coefficients as an accuracy diagnostic.

if nargin < 6 || isempty(ncirc), ncirc = 24; end
if ~isfield(par,'deriv'), par.deriv = 'auto'; end

% ---- Taylor-mode route, where it is both faster and more accurate ------
% At pmax = 1 the complex step below is already exact and is the cheaper
% of the two.  From pmax = 2 the Cauchy circle starts paying the p!/h^p
% amplification of rounding -- a floor that refining the circle does not
% lower -- while QFMGF_DJ runs the same assembly in truncated power
% series and stays at machine precision.  It is also two to six times
% faster there, because it needs no circle.  QFMGF_DJ covers every node,
% so the circle survives only as an independent check: set par.deriv to
% 'circle' to take it.  The 'banded' engine is likewise a check, and
% must not be routed through the jets (which run the closed-form
% assembly): with engine = 'banded' the derivatives are taken on the
% circle over the banded evaluator, so that route shares nothing with
% the default.
banded = isfield(par,'engine') && strcmpi(par.engine,'banded');
if pmax >= 2 && ~banded && any(strcmpi(par.deriv,{'auto','jet'}))
    [D,lp0,info] = qfmgf_dj(pmax,r0,s,t,par);
    info.route = 'jet';  info.jetfrac = 1;
    return
end

r0 = r0(:).'; s = s(:).'; t = t(:).';
N  = numel(r0);
hs  = 1e-60*par.rscale;
lp1 = mgf(r0 + 1i*hs, s, t, par);
lp0 = real(lp1);
dlg = imag(lp1)/hs;                      % d log Psi / dr at r0
D   = zeros(pmax,N);
D(1,:) = dlg;
info = struct('h',[],'tail',[],'route','circle','jetfrac',0);
if pmax == 1, return; end

h  = 0.4./max(abs(dlg), 0.4/par.rscale);
th = 2i*pi*(0:ncirc-1)'/ncirc;
R  = r0 + h.*exp(th);                    % ncirc x N
LP = mgf(R, ones(ncirc,1)*s, ones(ncirc,1)*t, par);
F  = exp(LP - lp0);                      % relative Psi on the circle
C  = fft(F,[],1)/ncirc;
for m = 2:pmax
    D(m,:) = factorial(m)*C(m+1,:)./h.^m;
end
info.h    = h;
info.tail = max(abs(C(ncirc,:)),abs(C(ncirc-1,:)));
end

% -------------------------------------------------------------------------
function lp = mgf(r,s,t,par)
%MGF  Dispatch to the O(1) evaluator, or to the banded one on request.
if isfield(par,'engine') && strcmpi(par.engine,'banded')
    lp = qfmgf_logpsi(r,s,t,par);
else
    lp = qfmgf_logpsi_f(r,s,t,par,par.engine);
end
end
