function [gen,tau] = qfmgf_jetok(r,s,t,par)
%QFMGF_JETOK  Which branch of the primitives a node falls in.  Diagnostic.
%
%   [gen,tau] = QFMGF_JETOK(r,s,t,par) returns tau = |x+1| n^2 at the base
%   point, x = p/(2q) being the symbol ratio of the tridiagonal Toeplitz
%   core, together with the logical gen = tau >= 2.5.  Where gen is true
%   the Chebyshev values U_m and U_{m-1} are taken from the closed forms
%   in the roots; where it is false they are taken from their Taylor
%   expansion at the confluent point x = -1.
%
%   Both branches are QFMGF_DJ's, and both are O(1) in the sample size, so
%   nothing about the method turns on this test: it is here to report
%   coverage and to let the two branches be run against each other on the
%   same nodes, which is what par.ttsplit does.
%
%   The band is a small-sample phenomenon.  At the parameters of the paper
%   it is empty from T = 240 upwards, holds about a twentieth of the
%   t-ratio cone at T = 120, and about half the nodes below T = 60.
%
%   See also QFMGF_DJ, QFMGF_DP, TTPRIMS.

T = par.T; phi = par.phi; ruv = par.ruv; bt = par.bt;
n = T-1;
r = r(:).'; s = s(:).'; t = t(:).';
N = max([numel(r) numel(s) numel(t)]);
if isscalar(r), r = repmat(r,1,N); end
if isscalar(s), s = repmat(s,1,N); end
if isscalar(t), t = repmat(t,1,N); end

sc   = -1i*r;
tc   =  1i*t;
c0   =  2*s/T;
lam1 = 1/(1-ruv^2)-2i*tc;
k1   = (ruv*phi-bt)/(1-ruv^2)-1i*sc;
k4   = -ruv/(1-ruv^2);
qF   = (bt*ruv-phi)/(1-ruv^2)-k1.*k4./lam1;
om   = 1-phi;  wr = 1-ruv^2;  uu = -1i*sc;  Lam = 1-2i*tc*wr;
p2q  = (om^2+2*uu.*(ruv*om+bt)-wr*uu.^2 ...
        -2i*tc.*((om+bt*ruv)^2+bt^2*wr)+T*c0.*Lam)./Lam;
tau  = abs(p2q./(2*qF))*n^2;
gen  = tau >= 2.5;
end
