function lp = qfmgf_logpsi(r,s,t,par)
%QFMGF_LOGPSI  log Psi(r,s,t) for arrays of arguments.
%
%   lp = QFMGF_LOGPSI(r,s,t,par) returns log E[exp(r*U_A - s*U_B - t*U_C)]
%   elementwise, where par comes from QFMGF_SETUP.  s and t must be real
%   and nonnegative; r may be complex (it is, on the differentiation
%   circles used by QFMGF_DP).
%
%   The matrix W(r,s,t) = V^{-1} - 2rA + 2sB + 2tC is factored by a
%   banded LDL' elimination in the interleaved ordering (bandwidth 3),
%   vectorized ACROSS evaluation points, followed by a rank-two
%   determinant-lemma correction for the demeaning.  Everything is done
%   in logarithms, so Psi may underflow without harm.  For real r in the
%   domain of the mgf, W is symmetric positive definite: every pivot is
%   positive and there is no branch ambiguity of any kind.  For complex r
%   near the real domain, Re W is positive definite (W is accretive), so
%   the pivots stay in the open right half plane and all logarithms below
%   are principal ones.
%
%   Cost: O(T) per evaluation with a small constant; evaluations are
%   processed in vectorized chunks.

sz = size(r);
rv = r(:).'; sv = s(:).'; tv = t(:).';
if isscalar(sv), sv = sv*ones(size(rv)); end
if isscalar(tv), tv = tv*ones(size(rv)); end
N  = numel(rv);
lp = zeros(1,N);
n  = par.n; T = par.T; bt = par.bt;
np = n+3;                                   % padded length

for c0 = 1:par.chunk:N
    idx = c0:min(c0+par.chunk-1,N);
    nc  = numel(idx);
    rr = rv(idx); ss = sv(idx); tt = tv(idx);

    % ---- assemble the band diagonals (padded with zero rows) ----------
    d0 = zeros(np,nc); d1 = zeros(np,nc); d2 = zeros(np,nc); d3 = zeros(np,nc);
    d0(1:n,:) = par.Vi(:,1) - 2*rr.*par.Ab(:,1) + 2*ss.*par.Bb(:,1) + 2*tt.*par.Cb(:,1);
    d1(1:n,:) = par.Vi(:,2) - 2*rr.*par.Ab(:,2) + 2*ss.*par.Bb(:,2) + 2*tt.*par.Cb(:,2);
    d2(1:n,:) = par.Vi(:,3) - 2*rr.*par.Ab(:,3) + 2*ss.*par.Bb(:,3) + 2*tt.*par.Cb(:,3);
    d3(1:n,:) = par.Vi(:,4) - 2*rr.*par.Ab(:,4) + 2*ss.*par.Bb(:,4) + 2*tt.*par.Cb(:,4);

    % ---- banded LDL' elimination, vectorized across the chunk ---------
    L1 = zeros(np,nc); L2 = zeros(np,nc); L3 = zeros(np,nc);
    P  = ones(np,nc);
    la = zeros(1,nc);
    for i = 1:n
        p = d0(i,:); P(i,:) = p; la = la + log(p);
        m1 = d1(i,:)./p; L1(i,:) = m1;
        m2 = d2(i,:)./p; L2(i,:) = m2;
        m3 = d3(i,:)./p; L3(i,:) = m3;
        d0(i+1,:) = d0(i+1,:) - m1.*d1(i,:);
        d1(i+1,:) = d1(i+1,:) - m1.*d2(i,:);
        d2(i+1,:) = d2(i+1,:) - m1.*d3(i,:);
        d0(i+2,:) = d0(i+2,:) - m2.*d2(i,:);
        d1(i+2,:) = d1(i+2,:) - m2.*d3(i,:);
        d0(i+3,:) = d0(i+3,:) - m3.*d3(i,:);
    end

    % ---- solves W0 y = f and W0 y = g (f, g = u-, z-indicators) -------
    yf = zeros(np,nc); yf(par.iu,:) = 1;
    yg = zeros(np,nc); yg(par.iz,:) = 1;
    for i = 1:n
        yf(i+1,:) = yf(i+1,:) - L1(i,:).*yf(i,:);
        yf(i+2,:) = yf(i+2,:) - L2(i,:).*yf(i,:);
        yf(i+3,:) = yf(i+3,:) - L3(i,:).*yf(i,:);
        yg(i+1,:) = yg(i+1,:) - L1(i,:).*yg(i,:);
        yg(i+2,:) = yg(i+2,:) - L2(i,:).*yg(i,:);
        yg(i+3,:) = yg(i+3,:) - L3(i,:).*yg(i,:);
    end
    yf = yf./P; yg = yg./P;
    for i = n:-1:1
        yf(i,:) = yf(i,:) - L1(i,:).*yf(i+1,:) - L2(i,:).*yf(i+2,:) - L3(i,:).*yf(i+3,:);
        yg(i,:) = yg(i,:) - L1(i,:).*yg(i+1,:) - L2(i,:).*yg(i+2,:) - L3(i,:).*yg(i+3,:);
    end
    F11 = sum(yf(par.iu,:),1);
    F12 = sum(yg(par.iu,:),1);      % = f'W0^{-1}g (symmetric)
    F22 = sum(yg(par.iz,:),1);

    % ---- rank-two demeaning correction --------------------------------
    th11 = -2*tt/T;
    th12 = (rr - 2*tt*bt)/T;
    th22 = (2*rr*bt - 2*ss - 2*tt*bt^2)/T;
    M11 = 1 + th11.*F11 + th12.*F12;
    M12 =     th11.*F12 + th12.*F22;
    M21 =     th12.*F11 + th22.*F12;
    M22 = 1 + th12.*F12 + th22.*F22;
    la  = la + log(M11.*M22 - M12.*M21);

    lp(idx) = -0.5*(par.logdetV + la);
end
lp = reshape(lp,sz);
end
