function lp = qfmgf_logpsi_f(r,s,t,par,engine)
%QFMGF_LOGPSI_F  log Psi(r,s,t) in O(1) operations, independent of T.
%
%   lp = QFMGF_LOGPSI_F(r,s,t,par) returns
%
%       log Psi(r,s,t) = log E[exp(r*U_A - s*U_B - t*U_C)]
%                      = -1/2 log|V_y| - 1/2 log|W(r,s,t)|,
%       W(r,s,t)       = V_y^{-1} - 2rA + 2sB + 2tC,
%
%   with par from QFMGF_SETUP.  This is the drop-in O(1) replacement for
%   QFMGF_LOGPSI, which does the same job by a banded factorization at
%   O(T) cost per point.  Inputs may be arrays of a common size; the
%   output has that size.  Complex r is allowed, which is what the
%   complex-step and Cauchy-circle derivative rules of QFMGF_DP need.
%
%   The reduction is the one the paper develops for the characteristic
%   function.  Writing y = (r_1..r_T, z_0..z_{T-1})', the quadratic
%   forms are
%
%       U_A = z'Mr,   U_B = z'Mz,   U_C = r'Mr,
%
%   so in y coordinates A, B and C carry no dependence on the slope: the
%   return block of W is diagonal, eliminating it leaves a tridiagonal
%   Toeplitz core with corner corrections and a rank-one demeaning term,
%   and TTPRIMS supplies the bilinear forms of its inverse in closed
%   form.  Every step costs a fixed number of operations.
%
%   The mgf is the characteristic function at imaginary arguments.  With
%   (sc,tc) denoting the arguments of the characteristic function of
%   (U_A,U_C) and c0 the coefficient that U_B contributes to the
%   diagonal, the correspondence is
%
%       sc = -i r,     tc = i t,     c0 = 2s/T,
%
%   which is what this function substitutes into the assembly of
%   R1R2_GH.  On the real axis every intermediate quantity is real and
%   positive: W is symmetric positive definite for s,t >= 0 and r in the
%   domain of the mgf, so no branch question arises and the phase
%   returned is zero up to roundoff.  Off the axis the phases are
%   accumulated continuously, exactly as for the characteristic
%   function, and the accretivity argument of the paper applies.
%
%   engine (optional) is 'fast' (default, pure O(1)) or 'auto', which
%   adds the O(1) cancellation indicators of R1R2_GH and recomputes the
%   rare flagged points with the stable pivot recursion of
%   BORDERED_PHASE, at O(T) cost on those points only.
%
%   See also QFMGF_SETUP, QFMGF_LOGPSI, QFMGF_DP, TTPRIMS, R1R2_GH.

if nargin < 5 || isempty(engine), engine = 'fast'; end
T = par.T; phi = par.phi; ruv = par.ruv; bt = par.bt;
n = T-1;

sz = size(r);
sc = -1i*r(:).';                 % characteristic-function argument for U_A
tc =  1i*t(:).';                 % characteristic-function argument for U_C
c0 =  2*s(:).'/T;                % U_B contribution to the diagonal
if isscalar(sc), sc = sc*ones(1,max([numel(tc) numel(c0)])); end
if isscalar(tc), tc = tc*ones(size(sc)); end
if isscalar(c0), c0 = c0*ones(size(sc)); end

% ---- Schur elimination of the return block ------------------------------
lam1 = 1/(1-ruv^2)-2i*tc;
lam2 = 1-2i*tc;
sli  = n./lam1+1./lam2;
cS   = 2i*tc./(T+2i*tc.*sli);
k1   = (ruv*phi-bt)/(1-ruv^2)-1i*sc;
k2   = 1i*sc/T;
k3   = k1./lam1+k2.*sli;
k4   = -ruv/(1-ruv^2);
k5   = -(bt+1i*sc);
k6   = k4./lam1+k5./lam2+k2.*sli;
c11  = 1+(bt-ruv*phi)^2/(1-ruv^2)+n*c0 ...
     -(k1./lam1.*(k1+2*k2)+k2.^2.*sli-cS.*k3.^2);
c1n  = -c0-(k2./lam1.*(k1+k4)+k2.*k5./lam2+k2.^2.*sli-cS.*k3.*k6);
cnn  = 1/(1-ruv^2)+bt^2+n*c0 ...
     -k4./lam1.*(k4+2*k2)-k5./lam2.*(k5+2*k2)-k2.^2.*sli+cS.*k6.^2;
q0e  = (k1+k4)./lam1+k2.*sli;
a1   = -c0-k1.*k2./lam1-(k2-cS.*k3).*q0e;
b1   = -c0-k2.*(k1+k4)./lam1-(k2-cS.*q0e).*k6;
cc   = c0+2*(k1+k4).*k2./lam1+k2.^2.*sli-cS.*q0e.^2;
pF   = (1+phi^2+bt^2-2*bt*ruv*phi)/(1-ruv^2)+T*c0-(k1.^2+k4.^2)./lam1;
qF   = (bt*ruv-phi)/(1-ruv^2)-k1.*k4./lam1;
% pF+2qF in closed form: formed by subtraction it is a cancellation of
% order (1-phi)^2 against pF ~ 2, and every primitive of TTPRIMS
% inherits the loss amplified by T^2.  See TTPRIMS.
om   = 1-phi;  wr = 1-ruv^2;  uu = -1i*sc;  Lam = 1-2i*tc*wr;
p2q  = (om^2+2*uu.*(ruv*om+bt)-wr*uu.^2 ...
        -2i*tc*((om+bt*ruv)^2+bt^2*wr)+T*c0.*Lam)./Lam;

% ---- closed-form primitives of the tridiagonal Toeplitz core ------------
P  = ttprims(pF,qF,T-2,1,[],p2q);
d1 = P.d1; d2 = P.d2; d3 = P.d3; d4 = P.d4;

% ---- Sherman-Morrison for the demeaning term, then the 2x2 border -------
c1 = cc./(cc.*d1-1);
rr = 1-c1.*d1;
w1 = rr.*d1;
w2 = rr.*d2;
w3 = d3-c1.*d2.^2;
w4 = d4-c1.*d2.^2;
g1 = a1.^2.*w1+2*a1.*qF.*w2+qF.^2.*w3;
g2 = a1.*b1.*w1+(a1+b1).*qF.*w2+qF.^2.*w4;
g3 = b1.^2.*w1+2*b1.*qF.*w2+qF.^2.*w3;
cr = 1-cc.*d1;                       % rank-one factor of |Delta|/|D|
e1 = c11-g1;
e2 = c1n-g2;
e3 = cnn-g3;
e4 = e1.*e3-e2.^2;                   % border factor

% ---- log-modulus and continuous phase ----------------------------------
h1 = n*log(abs(lam1))+log(abs(lam2))+log(abs(1+2i*tc/T.*sli));
x1 = n*angle(lam1)+angle(lam2)+angle(1+2i*tc/T.*sli);
h2 = log(abs(cr));  x2 = angle(cr);
h3 = log(abs(e4));  x3 = angle(e4);
lh = 0.5*(P.logabs_invD-h1-h2-h3-n*log1p(-ruv^2));
lx = 0.5*(P.arg_invD-x1-x2-x3);

if strcmpi(engine,'auto')
    amp = max(max(abs(cc.*d1)./abs(cr), (abs(c11)+abs(g1))./abs(e1)), ...
              max((abs(cnn)+abs(g3))./abs(e3), ...
                  (abs(e1.*e3)+abs(e2).^2)./abs(e4)));
    idx = amp > 1e3 | ~isfinite(amp);
    if any(idx)
        [labsF,argF] = bordered_phase(pF(idx),qF(idx),cc(idx), ...
                        c11(idx),c1n(idx),cnn(idx),a1(idx),b1(idx),T);
        lh(idx) = 0.5*(-labsF-h1(idx)-n*log1p(-ruv^2));
        lx(idx) = 0.5*(-argF-x1(idx));
    end
end

lp = reshape(lh + 1i*lx + 0.5*log1p(-phi^2), sz);
end
