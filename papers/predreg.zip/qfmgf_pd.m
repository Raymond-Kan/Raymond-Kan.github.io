function [lp,ok] = qfmgf_pd(r,s,t,par)
%QFMGF_PD  log Psi(r,s,t) with a positive-definiteness certificate.
%
%   [lp,ok] = QFMGF_PD(r,s,t,par) returns the same log-mgf as
%   QFMGF_LOGPSI for real arguments, together with a logical flag ok
%   that is true exactly when the tilted matrix
%
%       W(r,s,t) = V^{-1} - 2rA + 2sB + 2tC
%
%   is positive definite, i.e. when (r,s,t) lies in the domain of the
%   moment generating function.  Outside that domain logPsi is
%   meaningless, and any bound built from it is void; the flag makes the
%   distinction checkable rather than assumed.
%
%   The test is exact: W is positive definite if and only if every pivot
%   of the banded LDL' factorization is positive and the 2x2 determinant
%   of the rank-two demeaning correction is positive.  Both quantities
%   are computed anyway in the course of evaluating logPsi, so the
%   certificate is free.
%
%   par must come from QFMGF_SETUP(...,'banded').
%
%   See also QFMGF_LOGPSI, QFMGF_SETUP, R2_TRUNC.

if ~isfield(par,'Vi')
    error('predreg:qfmgf_pd', ...
        'QFMGF_PD needs the banded setup: qfmgf_setup(...,''banded'').');
end
sz = size(r);
rv = r(:).'; sv = s(:).'; tv = t(:).';
if isscalar(rv), rv = rv*ones(1,max([numel(sv) numel(tv)])); end
if isscalar(sv), sv = sv*ones(size(rv)); end
if isscalar(tv), tv = tv*ones(size(rv)); end
N  = numel(rv);
lp = zeros(1,N); ok = true(1,N);
n  = par.n; T = par.T; bt = par.bt;
np = n+3;

for c0 = 1:par.chunk:N
    idx = c0:min(c0+par.chunk-1,N);
    nc  = numel(idx);
    rr = rv(idx); ss = sv(idx); tt = tv(idx);

    d0 = zeros(np,nc); d1 = zeros(np,nc); d2 = zeros(np,nc); d3 = zeros(np,nc);
    d0(1:n,:) = par.Vi(:,1) - 2*rr.*par.Ab(:,1) + 2*ss.*par.Bb(:,1) + 2*tt.*par.Cb(:,1);
    d1(1:n,:) = par.Vi(:,2) - 2*rr.*par.Ab(:,2) + 2*ss.*par.Bb(:,2) + 2*tt.*par.Cb(:,2);
    d2(1:n,:) = par.Vi(:,3) - 2*rr.*par.Ab(:,3) + 2*ss.*par.Bb(:,3) + 2*tt.*par.Cb(:,3);
    d3(1:n,:) = par.Vi(:,4) - 2*rr.*par.Ab(:,4) + 2*ss.*par.Bb(:,4) + 2*tt.*par.Cb(:,4);

    L1 = zeros(np,nc); L2 = zeros(np,nc); L3 = zeros(np,nc);
    P  = ones(np,nc);
    la = zeros(1,nc); good = true(1,nc);
    for i = 1:n
        p = d0(i,:); P(i,:) = p;
        good = good & (p > 0);
        la = la + log(max(p,realmin));
        m1 = d1(i,:)./p; L1(i,:) = m1;
        m2 = d2(i,:)./p; L2(i,:) = m2;
        m3 = d3(i,:)./p; L3(i,:) = m3;
        d0(i+1,:) = d0(i+1,:) - m1.*d1(i,:);
        d1(i+1,:) = d1(i+1,:) - m1.*d2(i,:);
        d2(i+1,:) = d2(i+1,:) - m1.*d3(i,:);
        d0(i+2,:) = d0(i+2,:) - m2.*d2(i,:);
        d1(i+2,:) = d1(i+2,:) - m2.*d3(i,:);
        d0(i+3,:) = d0(i+3,:) - m3.*d3(i,:);
    end

    yf = zeros(np,nc); yf(par.iu,:) = 1;
    yg = zeros(np,nc); yg(par.iz,:) = 1;
    for i = 1:n
        yf(i+1,:) = yf(i+1,:) - L1(i,:).*yf(i,:);
        yf(i+2,:) = yf(i+2,:) - L2(i,:).*yf(i,:);
        yf(i+3,:) = yf(i+3,:) - L3(i,:).*yf(i,:);
        yg(i+1,:) = yg(i+1,:) - L1(i,:).*yg(i,:);
        yg(i+2,:) = yg(i+2,:) - L2(i,:).*yg(i,:);
        yg(i+3,:) = yg(i+3,:) - L3(i,:).*yg(i,:);
    end
    yf = yf./P; yg = yg./P;
    for i = n:-1:1
        yf(i,:) = yf(i,:) - L1(i,:).*yf(i+1,:) - L2(i,:).*yf(i+2,:) - L3(i,:).*yf(i+3,:);
        yg(i,:) = yg(i,:) - L1(i,:).*yg(i+1,:) - L2(i,:).*yg(i+2,:) - L3(i,:).*yg(i+3,:);
    end
    F11 = sum(yf(par.iu,:),1);
    F12 = sum(yg(par.iu,:),1);
    F22 = sum(yg(par.iz,:),1);

    th11 = -2*tt/T;
    th12 = (rr - 2*tt*bt)/T;
    th22 = (2*rr*bt - 2*ss - 2*tt*bt^2)/T;
    M11 = 1 + th11.*F11 + th12.*F12;
    M12 =     th11.*F12 + th12.*F22;
    M21 =     th12.*F11 + th22.*F12;
    M22 = 1 + th12.*F12 + th22.*F22;
    dt2 = M11.*M22 - M12.*M21;
    good = good & (dt2 > 0);
    la  = la + log(max(dt2,realmin));

    lp(idx) = -0.5*(par.logdetV + la);
    ok(idx) = good;
end
lp = reshape(lp,sz); ok = reshape(ok,sz);
lp(~ok) = NaN;
end
