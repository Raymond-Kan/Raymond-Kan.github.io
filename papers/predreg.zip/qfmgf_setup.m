function par = qfmgf_setup(T,phi,ruv,bt,engine)
%QFMGF_SETUP  Structure of the moment generating function of (U_A,U_B,U_C).
%
%   par = QFMGF_SETUP(T,phi,ruv,bt) precomputes everything that is needed
%   to evaluate
%
%       Psi(r,s,t) = E[exp(r*U_A - s*U_B - t*U_C)],
%
%   where, in the standardized regression with slope bt = (sigma_v/sigma_u)
%   *beta and x = (u_1..u_T, z_0..z_{T-1})',
%
%       U_A = z'Mr = z'Mu + bt*z'Mz,   U_B = z'Mz,   U_C = r'Mr,
%
%   with r = u + bt*z and M = I_T - 1_T 1_T'/T.  We have
%
%       Psi(r,s,t) = |V|^{-1/2} |W(r,s,t)|^{-1/2},
%       W(r,s,t)   = V^{-1} - 2r*A + 2s*B + 2t*C,
%
%   where V is the covariance matrix of x and A, B, C represent the three
%   quadratic forms in x.  In the interleaved ordering
%   (u_1, z_0, u_2, z_1, ...), V^{-1} and the M-free parts of A, B, C are
%   BANDED with bandwidth 3, and the -1_T 1_T'/T part of M contributes an
%   exact rank-two correction spanned by the u- and z-indicator vectors.
%   Two evaluators are available.  QFMGF_LOGPSI_F uses the closed-form
%   reduction of the paper and costs O(1) per point, independent of T;
%   it is the default.  QFMGF_LOGPSI factors the banded matrix directly
%   and costs O(T) per point; it is retained as an independent check.
%   Set par.engine to 'banded' to select it.
%
%   With the default engine nothing of size T is built or stored, so the
%   setup is itself O(1); the band diagonals are assembled only when the
%   banded evaluator is requested.
%
%   For moments of b (which do not depend on beta), call with bt = 0.

if nargin < 4 || isempty(bt), bt = 0; end
if nargin < 5 || isempty(engine), engine = 'fast'; end
if ~isscalar(phi) || ~isreal(phi) || abs(phi) >= 1
    error('predreg:phi',['The predictor must be a stationary AR(1): ' ...
        '|phi| < 1 is required.']);
end
if abs(ruv) >= 1, error('predreg:ruv','|ruv| < 1 is required.'); end
if T < 5, error('predreg:T','T >= 5 is required.'); end

n  = 2*T;
c2 = 1/(1-ruv^2);

% ---- band diagonals (offsets 0..3), needed by the banded evaluator only
% Nothing of size T is built unless it is asked for: the interleaved
% index vectors below are the only arrays here that grow with the sample
% size, so they are constructed inside this branch rather than outside it.
Vi = []; Ab = []; Bb = []; Cb = []; iu = []; iz = [];
if strcmpi(engine,'banded')
    iu = (1:2:n)';             % u_t     -> row 2t-1
    iz = (2:2:n)';             % z_{t-1} -> row 2t
    Vi = zeros(n,4); Ab = zeros(n,4); Bb = zeros(n,4); Cb = zeros(n,4);
    % V^{-1}: u-block is diagonal (conditional precision of u given z);
    % cross block is -D^{-1}S with E[u_t|z] = ruv*(z_t - phi*z_{t-1}) for
    % t <= T-1 and 0 for t = T; z-block is H^{-1} + S'D^{-1}S.
    Vi(iu,1) = [c2*ones(T-1,1); 1];
    zd = [1; (1+phi^2)*ones(T-2,1); 1];
    zd = zd + ruv^2*c2*(phi^2*[ones(T-1,1);0] + [0;ones(T-1,1)]);
    Vi(iz,1)        = zd;
    Vi(iz(1:T-1),3) = -phi*c2;         % (z_{t-1}, z_t)
    Vi(iu(1:T-1),2) = ruv*phi*c2;      % (u_t, z_{t-1})
    Vi(iu(1:T-1),4) = -ruv*c2;         % (u_t, z_t)
    % band (M -> I) parts of A, B, C
    Ab(iu,2) = 0.5;  Ab(iz,1) = bt;
    Bb(iz,1) = 1;
    Cb(iu,1) = 1;    Cb(iu,2) = bt;    Cb(iz,1) = bt^2;
end

% ---- scales (E[U_A], E[U_B], E[U_C]) in closed form, O(1) -------------
% sG = sum_{d=1}^{T-1} (T-d) phi^{d-1} = 1'G1 for the upper shift-Toeplitz
% G, summed geometrically; sH = phi*sG.
m1 = T-1;
if phi == 0
    sG = m1;
else
    sG = m1*(1-phi^m1)/(1-phi) ...
       - phi*(1-m1*phi^(m1-1)+(m1-1)*phi^m1)/(1-phi)^2;
end
sH   = phi*sG;
trH  = T/(1-phi^2);
eHe  = (T + 2*sH)/(1-phi^2);
cB   = trH - eHe/T;                % E[z'Mz]
zMu  = -ruv*sG/T;                  % E[z'Mu]
cA   = zMu + bt*cB;                % E[U_A]
cC   = (T-1) + 2*bt*zMu + bt^2*cB; % E[U_C]

par = struct('T',T,'n',n,'phi',phi,'ruv',ruv,'bt',bt, ...
    'Vi',Vi,'Ab',Ab,'Bb',Bb,'Cb',Cb,'iu',iu,'iz',iz, ...
    'logdetV',(T-1)*log1p(-ruv^2)-log1p(-phi^2), ...
    'cA',cA,'cB',cB,'cC',cC, ...
    'rscale',1/sqrt(max(cB,1)*max(cC,1)),'chunk',512,'engine',engine);
end
