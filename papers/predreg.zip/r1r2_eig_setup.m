function [A,B1,B2,D] = r1r2_eig_setup(T,bt,phi,ruv)
%R1R2_EIG_SETUP  (2T-2)-dimensional matrices for the (R1,R2) problem.
%
%   [A,B1,B2,D] = R1R2_EIG_SETUP(T,bt,phi,ruv) builds symmetric
%   matrices such that, with x ~ N(0,I_{2T-2}),
%      R1 = x'Ax/x'B2x  and  R2 = x'B1x/x'B2x
%   have the joint distribution of (z'Mr/z'Mz, r'Mr/z'Mz) for the
%   predictive regression with normalized slope bt.  D is the diagonal
%   eigenvalue matrix of the projected predictor covariance used by the
%   benchmark integrands.  Used by the *_EIG benchmark programs.

if ~isscalar(phi) || ~isreal(phi) || abs(phi) >= 1
    error('predreg:phi',['The predictor must be a stationary AR(1): ' ...
        '|phi| < 1 is required.  The unit-root case has no stationary ' ...
        'distribution for z_0 and is a different problem.']);
end
P = null(ones(1,T));
W = toeplitz(phi.^(0:T-1))/(1-phi^2);
K   = toeplitz([0 phi.^(0:T-2)]);
G   = toeplitz(zeros(1,T),[0 phi.^(0:T-2)]);
Vz  = P'*W*P;  Vz = 0.5*(Vz+Vz');
Vy  = P'*(eye(T)+bt*ruv*K+bt^2*W)*P;  Vy = 0.5*(Vy+Vy');
Vyz = P'*(bt*W+ruv*G)*P;
Sy  = Vy-Vyz/Vz*Vyz';  Sy = 0.5*(Sy+Sy');
Vy1 = chol(Sy);
[Q,D] = eig(Vz);
A12 = Vyz*Q/sqrt(D);
A   = [zeros(T-1,2*T-2); sqrt(D)*Q'*Vy1' sqrt(D)*Q'*A12];
A   = 0.5*(A+A');
B12 = Vy1*A12;
B1  = [Vy1*Vy1' B12; B12' A12'*A12];
B1  = 0.5*(B1+B1');
B2  = [zeros(T-1,2*T-2); zeros(T-1) D];
end
