function f1 = r1r2_g_eig(rvec2,r,h,A,B1,B2,c)
%R1R2_G_EIG  Eigenvalue-approach cdf integrand for (R1,R2) (benchmark).
%
%   Evaluates Im(g(s,t)+g(s,-t))/s at polar points s=r*cos(h),
%   t=r*sin(h) for r2=rvec2, r1=c*sqrt(r2), by an O(T^3)
%   eigendecomposition per (r2,theta) node followed by an O(T)
%   integrand in the radial variable (paper, Section 2.3).  Ported
%   from tratc_cdf_slow/rsqc_cdf_slow.  Benchmark only.

rvec2 = rvec2(1);
h  = h(1);
R1 = A-c*sqrt(rvec2)*B2;
R2 = B1-rvec2*B2;
if abs(h-pi/2) < eps
    % s = 0: L'Hopital form of Im(g)/s
    [Q0,H0] = eig(R2);
    B2a = Q0'*B2*Q0;
    R1a = Q0'*R1*Q0;
    h0  = diag(H0);
    t1  = 2*h0*r;
    c1  = 1./(1+t1.*t1);
    ct1 = c1.*t1;
    g1  = prod(c1).^(0.25);
    h1  = 0.5*sum(atan(t1));
    c1r = zeros(size(r)); c1i = zeros(size(r));
    for j = 1:numel(r)
        C0 = diag(c1(:,j)+ct1(:,j)*1i);
        A1 = C0*B2a;
        A2 = C0*R1a;
        aa = trace(A1)*trace(A2)+2*trace(A1*A2);
        c1r(j) = real(aa);
        c1i(j) = imag(aa);
    end
    f1 = 2*r.*g1.*(c1r.*cos(h1)-c1i.*sin(h1));
else
    ch = cos(h); sh = sin(h);
    [Q1,H1] = eig(ch*R1+sh*R2);
    [Q2,H2] = eig(ch*R1-sh*R2);
    t1 = 2*diag(H1)*r;
    t2 = 2*diag(H2)*r;
    B1a = diag(Q1'*B2*Q1);
    B1b = diag(Q2'*B2*Q2);
    c1 = 1./(1+t1.*t1);
    c2 = 1./(1+t2.*t2);
    g1 = prod(c1).^(0.25);
    g2 = prod(c2).^(0.25);
    h1 = 0.5*sum(atan(t1));
    h2 = 0.5*sum(atan(t2));
    c1r = B1a'*c1;  c1i = B1a'*(c1.*t1);
    c2r = B1b'*c2;  c2i = B1b'*(c2.*t2);
    f1 = (g1.*(c1r.*sin(h1)+c1i.*cos(h1)) ...
         +g2.*(c2r.*sin(h2)+c2i.*cos(h2)))/ch;
end
f1(~isfinite(f1)) = 0;
end
