function y = r1r2_gh(R,theta,r1,r2,T,bt,phi,ruv,tsign,mode,engine)
%R1R2_GH  O(1) integrand for the joint distribution of (R1,R2).
%
%   y = R1R2_GH(R,theta,r1,r2,T,bt,phi,ruv,tsign,mode) evaluates, at
%   the polar quadrature points s = R*cos(theta), t = tsign*R*sin(theta),
%   either
%     mode='g':  Im(g(s,t))*R/s   with g = |D|^(1/2) tr(D B~)
%                (cdf integrand of Proposition 2), or
%     mode='h':  Re(h(s,t))*R     with h = |D|^(1/2)[(tr(D B~))^2
%                + 2 tr((D B~)^2)]  (density integrand of Proposition 1),
%   for the predictive regression with normalized slope bt, AR(1)
%   coefficient phi (|phi|<1) and innovation correlation ruv.  The
%   sqrt(1-phi^2) prefactor of |V_y|^(-1/2) is NOT included here (the
%   caller applies it).
%
%   Every point costs O(1) operations independent of T; moduli are
%   assembled in logs and phases tracked continuously (overflow- and
%   branch-cut-free for any T), and the confluent expansions of the
%   primitives are applied automatically near root coalescence (the
%   phi -> 1 region), which the earlier implementations left untreated.
%
%   The optional argument engine selects the phase computation for
%   |F|^{-1/2}: 'fast' (default) is the pure O(1) closed-form
%   assembly (provably continuous by the accretivity proposition of
%   the paper); 'auto' adds
%   O(1) cancellation indicators and recomputes rare flagged points
%   (the phi -> 1 mid-band) with the stable pivot recursion of
%   BORDERED_PHASE, at O(T) cost on those points only; 'pivot' is the
%   certified continuous branch everywhere (O(T) per point).
%
%   See also TRAT_PDF, TRAT_CDF, RSQ_PDF, RSQ_CDF, TTPRIMS, BORDERED_PHASE.

if nargin < 11, engine = 'fast'; end
if ~isscalar(phi) || ~isreal(phi) || abs(phi) >= 1
    error('predreg:phi',['The predictor must be a stationary AR(1): ' ...
        '|phi| < 1 is required.  The unit-root case has no stationary ' ...
        'distribution for z_0 and is a different problem.']);
end
theta = theta(1);
r2    = r2(1);
r1    = r1(1);
R     = R(:).';
s = R*cos(theta);
t = tsign*R*sin(theta);
n = T-1;                        % exponent convention (D is (T-2)x(T-2))
is_h = strcmpi(mode,'h');
order = 2+is_h;

% ---- Schur prelude (verified against note04 / paper Section 4.1) --------
lam1 = 1/(1-ruv^2)-2i*t;
lam2 = 1-2i*t;
sli  = n./lam1+1./lam2;                 % 1'Lam^{-1}1
cS   = 2i*t./(T+2i*t.*sli);
c0   = 2i*(s*r1+t*r2)/T;
k1   = (ruv*phi-bt)/(1-ruv^2)-1i*s;
k2   = 1i*s/T;
k3   = k1./lam1+k2.*sli;
k4   = -ruv/(1-ruv^2);
k5   = -(bt+1i*s);
k6   = k4./lam1+k5./lam2+k2.*sli;
c11  = 1+(bt-ruv*phi)^2/(1-ruv^2)+n*c0 ...
     -(k1./lam1.*(k1+2*k2)+k2.^2.*sli-cS.*k3.^2);
c1n  = -c0-(k2./lam1.*(k1+k4)+k2.*k5./lam2+k2.^2.*sli-cS.*k3.*k6);
cnn  = 1/(1-ruv^2)+bt^2+n*c0 ...
     -k4./lam1.*(k4+2*k2)-k5./lam2.*(k5+2*k2)-k2.^2.*sli+cS.*k6.^2;
q0e  = (k1+k4)./lam1+k2.*sli;
a1   = -c0-k1.*k2./lam1-(k2-cS.*k3).*q0e;
b1   = -c0-k2.*(k1+k4)./lam1-(k2-cS.*q0e).*k6;
cc   = c0+2*(k1+k4).*k2./lam1+k2.^2.*sli-cS.*q0e.^2;   % Delta = D-cc*11'
pF   = (1+phi^2+bt^2-2*bt*ruv*phi)/(1-ruv^2)+T*c0-(k1.^2+k4.^2)./lam1;
qF   = (bt*ruv-phi)/(1-ruv^2)-k1.*k4./lam1;
% pF+2qF in closed form; see TTPRIMS on why it is not formed by
% subtraction.
om   = 1-phi;  wr = 1-ruv^2;  uu = -1i*s;  Lam = 1-2i*t*wr;
p2q  = (om^2+2*uu.*(ruv*om+bt)-wr*uu.^2 ...
        -2i*t.*((om+bt*ruv)^2+bt^2*wr)+T*c0.*Lam)./Lam;

% ---- primitives of the tridiagonal Toeplitz core ------------------------
P  = ttprims(pF,qF,T-2,order,[],p2q);
d1 = P.d1; d2 = P.d2; d3 = P.d3; d4 = P.d4;
c4t = P.tr1; d1t = P.d1t; d2t = P.d2t; d3t = P.d3t; d4t = P.d4t;

% ---- Sherman-Morrison + border (conventions as in the paper) ------------
c1  = cc./(cc.*d1-1);                  % = -cc/(1-cc*d1)
r0  = 1-c1.*d1;                        % = 1/(1-cc*d1)
w1  = r0.*d1;
w2  = r0.*d2;
w3  = d3-c1.*d2.^2;
w4  = d4-c1.*d2.^2;
g1  = a1.^2.*w1+2*a1.*qF.*w2+qF.^2.*w3;
g2  = a1.*b1.*w1+(a1+b1).*qF.*w2+qF.^2.*w4;
g3  = b1.^2.*w1+2*b1.*qF.*w2+qF.^2.*w3;
c2  = 1-cc.*d1;                        % rank-one factor of |Delta|/|D|
e1  = c11-g1;
e2  = c1n-g2;
e3  = cnn-g3;
e4  = e1.*e3-e2.^2;                    % border factor

% Delta^{-2} forms
w0t = c1.*d2.*(c1.*d2.*d1t-2*d2t);
w1t = r0.^2.*d1t;
w2t = r0.*(d2t-c1.*d2.*d1t);
w3t = d3t+w0t;
w4t = d4t+w0t;
ww1 = a1.^2.*w1t+2*a1.*qF.*w2t+qF.^2.*w3t;
ww2 = a1.*b1.*w1t+(a1+b1).*qF.*w2t+qF.^2.*w4t;
ww3 = b1.^2.*w1t+2*b1.*qF.*w2t+qF.^2.*w3t;
zz1 = a1.*w1+qF.*w2;                   % 1'Delta^{-1}a
zz2 = b1.*w1+qF.*w2;                   % 1'Delta^{-1}b

% trace(F^{-1}) and 1'F^{-1}1
term1 = c4t+cc.*d1t./c2+(e3.*ww1+e1.*ww3-2*e2.*ww2)./e4+(e1+e3)./e4;
term2 = (e1+e3-2*e2+2*(e2-e3).*zz1+2*(e2-e1).*zz2)./e4 ...
      + w1+(e3.*zz1.^2+e1.*zz2.^2-2*e2.*zz1.*zz2)./e4;
trFM  = term1-term2/T;                 % trace(F^{-1}M)

% ---- modulus/phase assembly ---------------------------------------------
% |blk11| = lam1^{T-1} lam2 (1+2it/T*sli): logs and unwound phases
h1  = n*log(abs(lam1))+log(abs(lam2))+log(abs(1+2i*t/T.*sli));
x1  = n*angle(lam1)+angle(lam2)+angle(1+2i*t/T.*sli);
if strcmpi(engine,'pivot')
    % certified continuous phase of |F| via LU pivots (F is accretive:
    % Re F inherits positivity from Re of the 2T-dim matrix = V_y^{-1})
    [labsF,argF] = bordered_phase(pF,qF,cc,c11,c1n,cnn,a1,b1,T);
    base_h = 0.5*(-labsF-h1-n*log1p(-ruv^2));
    base_x = 0.5*(-argF-x1);
else
    h2  = log(abs(c2));   x2 = angle(c2);
    h3  = log(abs(e4));   x3 = angle(e4);
    base_h  = 0.5*(P.logabs_invD-h1-h2-h3-n*log1p(-ruv^2));
    base_x  = 0.5*(P.arg_invD-x1-x2-x3);
    if strcmpi(engine,'auto')
        % O(1) cancellation indicators; recompute flagged points with
        % the stable pivot recursion (rare => amortized O(1))
        amp = max(max(abs(cc.*d1)./abs(c2), ...
                      (abs(c11)+abs(g1))./abs(e1)), ...
                  max((abs(cnn)+abs(g3))./abs(e3), ...
                      (abs(e1.*e3)+abs(e2).^2)./abs(e4)));
        idx = amp > 1e3 | ~isfinite(amp);
        if any(idx)
            [labsF,argF] = bordered_phase(pF(idx),qF(idx),cc(idx), ...
                            c11(idx),c1n(idx),cnn(idx),a1(idx),b1(idx),T);
            base_h(idx) = 0.5*(-labsF-h1(idx)-n*log1p(-ruv^2));
            base_x(idx) = 0.5*(-argF-x1(idx));
        end
    end
end

if ~is_h
    y = exp(base_h+log(abs(trFM))).*sin(base_x+angle(trFM)).*R./s;
    y(~isfinite(y)) = 0;
    return
end

% ---- density integrand: also trace((F^{-1}M)^2) -------------------------
tr2 = P.tr2; d1s = P.d1s; d2s = P.d2s; d3s = P.d3s; d4s = P.d4s;
c5t = tr2-2*c1.*d1s+c1.^2.*d1t.^2;     % trace(Delta^{-2})
% Delta^{-3} forms
w0s = -2*c1.*d2.*d2s-c1.*(c1.*d2.*d1t-d2t).^2+c1.^2.*d2.^2.*d1s;
w1s = r0.^2.*(d1s-c1.*d1t.^2);
w2s = r0.*(d2s-c1.*d1s.*d2+c1.*d1t.*(c1.*d2.*d1t-d2t));
w3s = d3s+w0s;
w4s = d4s+w0s;
qq1 = a1.^2.*w1s+2*a1.*qF.*w2s+qF.^2.*w3s;
qq2 = a1.*b1.*w1s+(a1+b1).*qF.*w2s+qF.^2.*w4s;
qq3 = b1.^2.*w1s+2*b1.*qF.*w2s+qF.^2.*w3s;
% trace(F^{-2})
term3a = c5t+2*qq1./e1+2*e1./e4.*(qq3-2*e2./e1.*qq2+e2.^2./e1.^2.*qq1) ...
       + ww1.^2./e1.^2+2./e4.*(ww2-e2./e1.*ww1).^2 ...
       + e1.^2./e4.^2.*(ww3-2*e2./e1.*ww2+e2.^2./e1.^2.*ww1).^2;
term3  = (e3./e4).^2+2*(e2./e4).^2+(e1./e4).^2 ...
       + 2./e4.^2.*(e3.^2.*ww1+e2.^2.*ww3-2*e2.*e3.*ww2) ...
       + 2./e4.^2.*(e2.^2.*ww1+e1.^2.*ww3-2*e2.*e1.*ww2)+term3a;
% 1'F^{-2}1
hh1  = zz1;  hh2 = zz2;  hh3 = hh2-e2./e1.*hh1;
hh1a = a1.*w1t+qF.*w2t;
hh2a = b1.*w1t+qF.*w2t;
hh3a = hh2a-e2./e1.*hh1a;
hh4a = ww3-2*e2./e1.*ww2+e2.^2./e1.^2.*ww1;
term4a = (e3./e4).^2+2*(e2./e4).^2+(e1./e4).^2 ...
       + 1./e4.^2.*(e3.^2.*ww1+e2.^2.*ww3-2*e2.*e3.*ww2) ...
       + 1./e4.^2.*(e2.^2.*ww1+e1.^2.*ww3-2*e1.*e2.*ww2) ...
       + (e2.*hh2-e3.*hh1).^2./e4.^2+(e2.*hh1-e1.*hh2).^2./e4.^2 ...
       + w1t+hh1.^2./e1.^2.*ww1+e1.^2./e4.^2.*hh4a.*hh3.^2 ...
       + 2*hh1.*hh1a./e1+2*e1./e4.*hh3.*hh3a ...
       + 2./e4.*hh1.*hh3.*(ww2-e2./e1.*ww1);
term4b = e3./e4.^2.*(e2.*hh2-e3.*hh1)-e2./e4.^2.*(e2.*hh1-e1.*hh2) ...
       + 1./e4.*((e2.*hh2a-e3.*hh1a)+hh1./e1.*(e2.*ww2-e3.*ww1) ...
       + hh3.*e1./e4.*(e2.*ww3-e2.^2./e1.*ww2-e3.*ww2+e2.*e3./e1.*ww1));
term4c = 1./e4.^2.*(-e2.*e3-e2.*e1+(e2.^2+e1.*e3).*ww2 ...
       - e1.*e2.*ww3-e2.*e3.*ww1);
term4d = -e2./e4.^2.*(e2.*hh2-e3.*hh1)+e1./e4.^2.*(e2.*hh1-e1.*hh2) ...
       + 1./e4.*(e2.*hh1a-e1.*hh2a+hh1./e1.*(e2.*ww1-e1.*ww2) ...
       + e1.*hh3./e4.*(2*e2.*ww2-e1.*ww3-e2.^2./e1.*ww1));
term4  = term4a+2*term4b+2*term4c+2*term4d;

term = trFM.^2+2*(term3-2*term4/T+(term2/T).^2);
y = exp(base_h+log(abs(term))).*cos(base_x+angle(term)).*R;
y(~isfinite(y)) = 0;
end
