function f1 = r1r2_h_eig(rvec2,r,h,A,B1,B2,D,c)
%R1R2_H_EIG  Eigenvalue-approach density integrand for (R1,R2) (benchmark).
%
%   Evaluates Re(h(s,t)+h(s,-t))*r at polar points s=r*cos(h),
%   t=r*sin(h) for r2=rvec2, r1=c*sqrt(r2), by an O(T^3)
%   eigendecomposition per (r2,theta) node followed by an O(T^2)
%   integrand in the radial variable (paper, Section 2.3).  Ported
%   from rsqc_pdf_slow.  Benchmark only.

m = size(D,1);
rvec2 = rvec2(1);
h  = h(1);
R2 = B1-rvec2*B2;
R1 = A-c*sqrt(rvec2)*B2;
ch = cos(h); sh = sin(h);
f1 = zeros(size(r));
for sgn = [1 -1]
    [Q1,H1] = eig(ch*R1+sgn*sh*R2);
    t1  = 2*diag(H1)*r;
    Q1b = Q1(m+1:end,:);
    B1a = Q1b'*D*Q1b;
    b1d = diag(B1a);
    Ha  = 2*B1a.*B1a+b1d*b1d';
    c1  = 1./(1+t1.*t1);
    g1  = prod(c1).^(0.25);
    h1  = 0.5*sum(atan(t1));
    ct1 = c1.*t1;
    Ha1 = Ha*c1;
    Hat1= Ha*ct1;
    c1r = sum(Ha1.*c1)-sum(Hat1.*ct1);
    c1i = 2*sum(Hat1.*c1);
    f1  = f1+g1.*(c1r.*cos(h1)-c1i.*sin(h1)).*r;
end
f1(~isfinite(f1)) = 0;
end
