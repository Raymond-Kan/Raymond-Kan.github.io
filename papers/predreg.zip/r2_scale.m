function [m2,s2] = r2_scale(T,phi,bt,ruv)
%R2_SCALE  Centering and scaling for the outer R2 quadrature variable.
%
%   [m2,s2] = R2_SCALE(T,phi,bt,ruv) returns first-order (delta-method)
%   approximations to the mean and standard deviation of the
%   Cauchy-Schwarz bound (|bt|+sqrt(Q))^2 on R_2 = r'Mr/z'Mz, where
%   Q = u'Mu/z'Mz.  They are used only to center and scale the outer
%   quadrature variable, r2 = m2 + s2*y, a change of variables that
%   leaves the value of the integral unchanged.  No accuracy claim is
%   attached to them; the truncation point itself is certified
%   separately by R2_TRUNC.
%
%   See also R2_TRUNC, R2_UPPER.

p = min(phi,1-1e-8);                       % guard phi -> 1
lp = log(max(p,realmin));
if p > 0, omT = -expm1(T*lp); else, omT = 1-p^T; end
oneG1  = T/(1-p)+(p^T-1)/(1-p)^2;
oneH1T = 1/(1-p^2)+2*p*oneG1/(T*(1-p^2));
trMH   = T/(1-p^2)-oneH1T;
trGH   = p*(T*(1-p^2)+p^(2*T)-1)/(1-p^2)^3;
trH2   = T/(1-p^2)^2+2*p*trGH/(1-p^2);
oneGH1 = (T*(1-p^2)*(1+p+p^T)-omT*(1+3*p+3*p^2-p^(T+1)))/((1-p)^2*(1-p^2)^2);
oneH21T= oneH1T/(1-p^2)+2*p*oneGH1/(T*(1-p^2));
trMH2  = trH2-2*oneH21T+oneH1T^2;
trGGt  = (T*(1-p^2)-1+p^(2*T))/(1-p^2)^2;
oneGGt1= T/(1-p)^2-omT*(1+2*p-p^T)/((1-p)^2*(1-p^2));
sUV    = 2*ruv^2*(trGGt-2*oneGGt1/T+(oneG1/T)^2);

muU = T-1;        muV = trMH;
s2U = 2*(T-1);    s2V = 2*trMH2;
muQ = muU/muV;
s2Q = s2U/muV^2-2*muU*sUV/muV^3+muU^2*s2V/muV^4;
m2  = (abs(bt)+sqrt(muQ))^2;
s2  = (abs(bt)+sqrt(muQ))/sqrt(muQ)*sqrt(max(s2Q,0));
end
