function [xu,info] = r2_trunc(T,phi,ruv,bt,eps_tail)
%R2_TRUNC  Certified truncation point for the outer R2 integral.
%
%   xu = R2_TRUNC(T,phi,ruv,bt,eps_tail) returns a value xu such that
%
%       P[R_2 > xu] <= eps_tail,        R_2 = r'Mr/z'Mz,
%
%   the bound being a Chernoff bound evaluated with the exact moment
%   generating function of the paper:  for every theta > 0 in the domain
%   of the mgf,
%
%       P[U_C - x U_B > 0] <= E[exp(theta(U_C - x U_B))] = Psi(0,theta*x,-theta),
%
%   with U_B = z'Mz and U_C = r'Mr as in QFMGF_SETUP.  The right-hand
%   side is minimized over theta inside the domain (the exponent is
%   convex there), and x is then increased until the minimized bound
%   falls below eps_tail.  Nothing is approximated: Psi is the exact mgf,
%   the domain is certified pivot by pivot by QFMGF_PD, and the bound
%   holds for every T, phi, ruv and bt.
%
%   The default eps_tail is 1e-15.
%
%   [xu,info] = R2_TRUNC(...) also returns the attained log bound, the
%   minimizing theta, and the number of mgf evaluations used.
%
%   This replaces the delta-method "mean plus twenty standard deviations"
%   rule of R2_UPPER, which had no error guarantee.  R2_UPPER is retained
%   for the centering and scaling of the quadrature variable, where no
%   accuracy claim is attached to it.
%
%   See also QFMGF_PD, QFMGF_SETUP, R2_UPPER, TRAT_CDF, RSQ_CDF.

if nargin < 5 || isempty(eps_tail), eps_tail = 1e-15; end
par   = qfmgf_setup(T,phi,ruv,bt,'banded');
target = log(eps_tail);
nev   = 0;

% ---- bracket in x --------------------------------------------------------
[m2,s2] = r2_scale(T,phi,bt,ruv);          % first-order mean of the CS bound
x  = max(m2,1e-8);
[K,~,ne] = minK(x); nev = nev+ne;
while K > target
    x = 2*x;
    [K,~,ne] = minK(x); nev = nev+ne;
    if x > 1e12, error('predreg:r2trunc','No truncation point found.'); end
end
xhi = x; xlo = x/2;
[Klo,~,ne] = minK(xlo); nev = nev+ne;
if Klo <= target                            % walk the lower end down
    while Klo <= target && xlo > 1e-10
        xhi = xlo; xlo = xlo/2;
        [Klo,~,ne] = minK(xlo); nev = nev+ne;
    end
end

% ---- bisect --------------------------------------------------------------
for it = 1:60
    xm = 0.5*(xlo+xhi);
    [Km,~,ne] = minK(xm); nev = nev+ne;
    if Km <= target, xhi = xm; else, xlo = xm; end
    if (xhi-xlo) <= 1e-10*max(1,xhi), break, end
end
xu = xhi;
[Kf,thf,ne] = minK(xu); nev = nev+ne;
info = struct('logbound',Kf,'theta',thf,'nfev',nev,'eps',eps_tail, ...
              's2scale',s2,'m2',m2);

% -------------------------------------------------------------------------
    function [K,thstar,ne] = minK(x)
    % minimize log Psi(0,theta*x,-theta) over the domain in theta > 0.
    % The exponent is convex where finite; the domain is an interval
    % (0,thmax) certified by QFMGF_PD.
    thmax = domain_edge(x);
    if ~isfinite(thmax) || thmax <= 0, K = 0; thstar = 0; ne = 0; return, end
    a = 1e-12*thmax; b = (1-1e-9)*thmax;
    gr = (sqrt(5)-1)/2; ne = 0;
    c = b-gr*(b-a); d = a+gr*(b-a);
    fc = Keval(c,x); fd = Keval(d,x); ne = ne+2;
    for k = 1:80
        if fc < fd
            b = d; d = c; fd = fc; c = b-gr*(b-a); fc = Keval(c,x); ne = ne+1;
        else
            a = c; c = d; fc = fd; d = a+gr*(b-a); fd = Keval(d,x); ne = ne+1;
        end
        if (b-a) <= 1e-12*max(1,b), break, end
    end
    if fc < fd, thstar = c; K = fc; else, thstar = d; K = fd; end
    K = min(K,0);                            % a probability bound is <= 1
    end

    function v = Keval(th,x)
    [lp,okf] = qfmgf_pd(0,th*x,-th,par);
    if okf, v = lp; else, v = Inf; end
    end

    function th = domain_edge(x)
    % largest theta with W(0,theta*x,-theta) positive definite
    th = 1;
    [~,okf] = qfmgf_pd(0,th*x,-th,par);
    if okf
        while okf && th < 1e14
            th = th*2; [~,okf] = qfmgf_pd(0,th*x,-th,par);
        end
        lo = th/2; hi = th;
    else
        while ~okf && th > 1e-14
            th = th/2; [~,okf] = qfmgf_pd(0,th*x,-th,par);
        end
        if ~okf, th = 0; return, end
        lo = th; hi = th*2;
    end
    for k = 1:80
        mid = 0.5*(lo+hi);
        [~,okf] = qfmgf_pd(0,mid*x,-mid,par);
        if okf, lo = mid; else, hi = mid; end
        if (hi-lo) <= 1e-13*max(1,hi), break, end
    end
    th = lo;
    end
end
