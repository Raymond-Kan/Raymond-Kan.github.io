function [xu,m2,s2] = r2_upper(T,phi,bt,ruv,nsd)
%R2_UPPER  Truncation point and scale for the outer R2 integral.
%
%   [xu,m2,s2] = R2_UPPER(T,phi,bt,ruv) returns the truncation point xu
%   for the outer integral over r2 in the distributions of t(betahat)
%   and R^2, together with the centering m2 and scale s2 used for the
%   quadrature variable.
%
%   The truncation point is CERTIFIED: xu satisfies
%
%       P[R_2 > xu] <= 1e-15,      R_2 = r'Mr/z'Mz,
%
%   the bound being a Chernoff bound computed from the exact moment
%   generating function of the paper, minimized over the tilt inside a
%   domain that is verified pivot by pivot.  See R2_TRUNC.  Results are
%   cached, so the (millisecond) bisection is paid once per parameter
%   configuration.
%
%   m2 and s2 are first-order approximations to the mean and standard
%   deviation of the Cauchy-Schwarz bound (|bt|+sqrt(Q))^2 with
%   Q = u'Mu/z'Mz; they only center and scale the quadrature variable
%   and carry no accuracy claim.  See R2_SCALE.
%
%   xu = R2_UPPER(T,phi,bt,ruv,nsd) with nsd supplied reverts to the
%   uncertified rule of the earlier implementation, xu = (|bt| +
%   sqrt(muQ + nsd*sigmaQ))^2, and is retained only for comparison.
%
%   See also R2_TRUNC, R2_SCALE, QFMGF_PD.

[m2,s2] = r2_scale(T,phi,bt,ruv);

if nargin >= 5 && ~isempty(nsd)            % legacy delta-method rule
    muQ = (sqrt(m2)-abs(bt))^2;
    sQ  = s2*sqrt(muQ)/(abs(bt)+sqrt(muQ));
    xu  = (abs(bt)+sqrt(muQ+nsd*sQ))^2;
    return
end

persistent K V
if isempty(K), K = {}; V = []; end
key = [T phi bt ruv];
for i = 1:numel(K)
    if isequal(K{i},key), xu = V(i); return, end
end
xu = r2_trunc(T,phi,ruv,bt,1e-15);
K{end+1} = key; V(end+1) = xu;             %#ok<AGROW>
end
