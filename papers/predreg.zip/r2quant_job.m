function r2quant_job
%R2QUANT_JOB  Exact median and 95th percentile of R^2 under the null,
%   at the configuration quoted in Section 2.3 of the paper.
%   Writes r2quant.txt incrementally.

fid = fopen('r2quant.txt','w');
T = 120; phi = 0.99; ruv = -0.856; bt = 0;
ps = [0.5 0.95];
for j = 1:numel(ps)
    lo = 1e-8; hi = 0.9;
    for k = 1:24
        m = 0.5*(lo+hi);
        F = rsq_cdf(m,T,bt,phi,ruv,1e-7);
        if F < ps(j), lo = m; else, hi = m; end
        fprintf('  p=%.2f  iter %2d  x=%.6f  F=%.6f\n',ps(j),k,m,F);
    end
    q = 0.5*(lo+hi);
    fprintf(fid,'T=%d phi=%.4f ruv=%.3f : R2 quantile %.2f = %.6f\n', ...
            T,phi,ruv,ps(j),q);
    fprintf('T=%d phi=%.4f ruv=%.3f : R2 quantile %.2f = %.6f\n', ...
            T,phi,ruv,ps(j),q);
end
fclose(fid);
end
