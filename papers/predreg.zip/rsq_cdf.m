function F = rsq_cdf(rvec,T,bt,phi,ruv,tol,engine)
%RSQ_CDF  Exact cdf of the R^2 of a predictive regression.
%
%   F = RSQ_CDF(rvec,T,bt,phi,ruv) returns P[R^2 < rvec(i)] for the
%   predictive regression with normalized slope
%   bt = (sigma_v/sigma_u)*beta, AR(1) coefficient phi (|phi| < 1) and
%   innovation correlation ruv.  tol is the absolute tolerance of the
%   triple quadrature (default 1e-4).  The quadrature variables are
%   centered and scaled as in TRAT_CDF (r2 = m2+s2*y, R = v/s2, the
%   Jacobians cancel), which keeps the integration ranges O(1) for
%   all T.
%
%   The optional argument engine ('fast' default | 'auto' | 'pivot')
%   selects the phase computation in R1R2_GH; see R1R2_GH.
%
%   See also RSQ_PDF, RSQ_CDF_EIG, R1R2_GH.

if nargin < 6, tol = 1e-4; end
if nargin < 7, engine = 'fast'; end
if ~isscalar(phi) || ~isreal(phi) || abs(phi) >= 1
    error('predreg:phi',['The predictor must be a stationary AR(1): ' ...
        '|phi| < 1 is required.  The unit-root case has no stationary ' ...
        'distribution for z_0 and is a different problem.']);
end
F = zeros(size(rvec));
rhpisq = 1/(2*pi^2);
[xu,m2,s2] = r2_upper(T,phi,bt,ruv);
ylo = -m2/s2; yhi = (xu-m2)/s2;
pref = sqrt(1-phi^2);
for i = 1:numel(rvec)
    z = rvec(i);
    if z > 0 && z < 1
        F(i) = rhpisq*pref*( ...
          integral3(@(y,th,v) ...
            r1r2_gh(v/s2,th,-sqrt(z*(m2+s2*y(1))),m2+s2*y(1),T,bt,phi,ruv, 1,'g',engine) ...
           +r1r2_gh(v/s2,th,-sqrt(z*(m2+s2*y(1))),m2+s2*y(1),T,bt,phi,ruv,-1,'g',engine), ...
            ylo,yhi,0,pi/2,0,Inf,'AbsTol',tol) ...
         -integral3(@(y,th,v) ...
            r1r2_gh(v/s2,th, sqrt(z*(m2+s2*y(1))),m2+s2*y(1),T,bt,phi,ruv, 1,'g',engine) ...
           +r1r2_gh(v/s2,th, sqrt(z*(m2+s2*y(1))),m2+s2*y(1),T,bt,phi,ruv,-1,'g',engine), ...
            ylo,yhi,0,pi/2,0,Inf,'AbsTol',tol));
    elseif z >= 1
        F(i) = 1;
    end
end
F = max(0,min(1,F));
end
