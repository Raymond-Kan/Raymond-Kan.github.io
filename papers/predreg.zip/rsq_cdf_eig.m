function F = rsq_cdf_eig(rvec,T,bt,phi,ruv,tol)
%RSQ_CDF_EIG  Cdf of R^2 via the eigenvalue approach (benchmark).
%   Same inputs/outputs as RSQ_CDF.  O(T^3) per (r2,theta) node.
if nargin < 6, tol = 1e-4; end
F = zeros(size(rvec));
rhpisq = 1/(2*pi^2);
[A,B1,B2] = r1r2_eig_setup(T,bt,phi,ruv);
xu = r2_upper(T,phi,bt,ruv);
for i = 1:numel(rvec)
    z = rvec(i);
    if z > 0 && z < 1
        F(i) = rhpisq*( ...
            integral3(@(x,h,r) r1r2_g_eig(x,r,h,A,B1,B2,-sqrt(z)), ...
                      0,xu,0,pi/2,0,Inf,'AbsTol',tol) ...
           -integral3(@(x,h,r) r1r2_g_eig(x,r,h,A,B1,B2, sqrt(z)), ...
                      0,xu,0,pi/2,0,Inf,'AbsTol',tol));
    elseif z >= 1
        F(i) = 1;
    end
end
F = max(0,min(1,F));
end
