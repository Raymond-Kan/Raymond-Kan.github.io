function [f,A] = rsq_pdf(rvec,T,bt,phi,ruv,tol,engine)
%RSQ_PDF  Exact density of the R^2 of a predictive regression.
%
%   f = RSQ_PDF(rvec,T,bt,phi,ruv) returns the exact finite-sample
%   density of R^2 at the points in rvec, for the predictive
%   regression with normalized slope bt = (sigma_v/sigma_u)*beta,
%   AR(1) coefficient phi, and innovation correlation ruv.  tol is the
%   absolute tolerance of the triple quadrature (default 1e-4).
%
%   [f,A] = RSQ_PDF(...) also returns the coefficient of the
%   singularity of the density at the origin.  The density of R^2 is
%   unbounded at zero for every T, under the null and under the
%   alternative alike, and diverges at the rate
%
%       f(c) ~ A / sqrt(c)   as c -> 0+,   A = sqrt(T-2)*f_t(0),
%
%   with f_t the density of t(betahat): R^2 = t^2/(nu+t^2) with
%   nu = T-2 is an exact identity, so sqrt(c)*f(c) -> sqrt(nu)*f_t(0).
%   A is computed from TRAT_PDF at the origin and is valid for every
%   ruv and bt.  When ruv = 0 it also has the closed form
%
%       A = E[exp(-bt^2*Q/2)] / beta(1/2,(T-2)/2),   Q = z'Mz,
%         = |I + bt^2*H*M|^(-1/2) / beta(1/2,(T-2)/2),
%
%   which at bt = 0 is 1/beta(1/2,(T-2)/2), the value implied by the
%   Beta(1/2,(T-2)/2) null distribution.  Increasing the signal damps
%   the spike but never removes it.  RSQ_PDF returns Inf at c = 0.
%
%   Implements Proposition 1 with the O(1) integrand of Section 4.
%   Replaces rsqc_pdf; adds the confluent-expansion switch and is
%   overflow-free for any T.
%
%   The optional argument engine ('fast' default | 'auto' | 'pivot')
%   selects the phase computation in R1R2_GH; see R1R2_GH.
%
%   See also RSQ_CDF, RSQ_PDF_EIG, TRAT_PDF, R1R2_GH.

if nargin < 6, tol = 1e-4; end
if nargin < 7, engine = 'fast'; end   % strict O(1) default; 'auto' adds pivot fallback
if ~isscalar(phi) || ~isreal(phi) || abs(phi) >= 1
    error('predreg:phi',['The predictor must be a stationary AR(1): ' ...
        '|phi| < 1 is required.  The unit-root case has no stationary ' ...
        'distribution for z_0 and is a different problem.']);
end
f = zeros(size(rvec));
rhpisq = 1/(2*pi^2);
[xu,m2,s2] = r2_upper(T,phi,bt,ruv);
ylo = -m2/s2; yhi = (xu-m2)/s2;
pref = sqrt(1-phi^2);
for i = 1:numel(rvec)
    z = rvec(i);
    if z > 0 && z < 1
        f(i) = rhpisq*pref/(2*sqrt(z))*( ...
          integral3(@(y,th,v) ...
            (r1r2_gh(v/s2,th, sqrt(z*(m2+s2*y(1))),m2+s2*y(1),T,bt,phi,ruv, 1,'h',engine) ...
            +r1r2_gh(v/s2,th, sqrt(z*(m2+s2*y(1))),m2+s2*y(1),T,bt,phi,ruv,-1,'h',engine)).*sqrt(m2+s2*y(1)), ...
            ylo,yhi,0,pi/2,0,Inf,'AbsTol',tol) ...
         +integral3(@(y,th,v) ...
            (r1r2_gh(v/s2,th,-sqrt(z*(m2+s2*y(1))),m2+s2*y(1),T,bt,phi,ruv, 1,'h',engine) ...
            +r1r2_gh(v/s2,th,-sqrt(z*(m2+s2*y(1))),m2+s2*y(1),T,bt,phi,ruv,-1,'h',engine)).*sqrt(m2+s2*y(1)), ...
            ylo,yhi,0,pi/2,0,Inf,'AbsTol',tol));
    elseif z == 0
        f(i) = Inf;
    end
end
f = max(0,f);

if nargout > 1
    % Coefficient of the c^(-1/2) singularity at the origin: the density
    % of the t-ratio at zero, scaled by sqrt(nu).  One O(1) evaluation.
    A = sqrt(T-2)*trat_pdf(0,T,bt,phi,ruv,tol,engine);
end
end
