function f = rsq_pdf_eig(rvec,T,bt,phi,ruv,tol)
%RSQ_PDF_EIG  Density of R^2 via the eigenvalue approach (benchmark).
%   Same inputs/outputs as RSQ_PDF.  O(T^3) per (r2,theta) node.
if nargin < 6, tol = 1e-4; end
f = zeros(size(rvec));
rhpisq = 1/(2*pi^2);
[A,B1,B2,D] = r1r2_eig_setup(T,bt,phi,ruv);
xu = r2_upper(T,phi,bt,ruv);
for i = 1:numel(rvec)
    z = rvec(i);
    if z > 0 && z < 1
        f(i) = rhpisq/(2*sqrt(z))*( ...
            integral3(@(x,h,r) r1r2_h_eig(x,r,h,A,B1,B2,D, sqrt(z)).*sqrt(x(1)), ...
                      0,xu,0,pi/2,0,Inf,'AbsTol',tol) ...
           +integral3(@(x,h,r) r1r2_h_eig(x,r,h,A,B1,B2,D,-sqrt(z)).*sqrt(x(1)), ...
                      0,xu,0,pi/2,0,Inf,'AbsTol',tol));
    elseif z == 0
        f(i) = Inf;
    end
end
f = max(0,f);
end
