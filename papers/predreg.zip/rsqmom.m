function m = rsqmom(p,T,phi,ruv,bt,nq,engine)
%RSQMOM  Exact moments of the R^2 of the predictive regression.
%
%   m = RSQMOM(p,T,phi,ruv,bt) returns m(j) = E[(R^2)^j] for j = 1..p,
%   where bt = (sigma_v/sigma_u)*beta is the standardized slope (bt = 0
%   under the null).
%
%   The representation linearises both quadratic forms in the
%   denominator by scalar gamma integrals:
%
%     E[(R^2)^j] = E[U_A^{2j} U_B^{-j} U_C^{-j}]
%       = 1/Gamma(j)^2 int_0^inf int_0^inf s^{j-1} t^{j-1}
%             E[U_A^{2j} e^{-s U_B - t U_C}] ds dt,
%
%   and the inner expectation is the (2j)-th r-derivative of the mgf.
%   Since 0 <= R^2 <= 1, all moments exist.
%
%   nq (optional) is the number of Gauss-Legendre nodes per dimension
%   (default 48).  engine (optional) selects the mgf evaluator: 'fast'
%   (default, O(1) per point) or 'banded' (O(T) per point).

if nargin < 5 || isempty(bt), bt = 0; end
if nargin < 6 || isempty(nq), nq = 48; end
if nargin < 7 || isempty(engine), engine = 'fast'; end
par = qfmgf_setup(T,phi,ruv,bt,engine);

[q,w] = gauss01(nq);
sv  = (q./(1-q))/par.cB;  js = 1./(par.cB*(1-q).^2);
tv  = (q./(1-q))/par.cC;  jt = 1./(par.cC*(1-q).^2);
[S,Tt] = ndgrid(sv,tv);
[WS,WT] = ndgrid(w.*js, w.*jt);
S = S(:).'; Tt = Tt(:).'; WW = (WS(:).*WT(:)).';

[D,lp0] = qfmgf_dp(2*p, zeros(size(S)), S, Tt, par, max(24,4*(2*p)));

m = zeros(1,p);
for j = 1:p
    m(j) = real(sum(WW.*exp((j-1)*(log(S)+log(Tt))+lp0).*D(2*j,:)))/gamma(j)^2;
end
end

function [x,w] = gauss01(n)
j = 1:n-1; b = j./sqrt(4*j.^2-1);
[V,Dg] = eig(diag(b,1)+diag(b,-1));
[x,ix] = sort(diag(Dg).'); w = 2*V(1,ix).^2;
x = (x+1)/2; w = w/2;
end
