function test_certify(parts)
%TEST_CERTIFY  End-to-end numerical certification of the exact distributions.
%
%   Runs the checks a distribution function has to pass regardless of how
%   it was computed, at configurations chosen to be hard rather than
%   convenient: small samples, near-unit persistence, innovation
%   correlations near +/-1 and equal to zero, and negative persistence.
%
%   Part A  certified truncation of the outer integral: the bound
%           P[R_2 > xu] delivered by R2_TRUNC, against what the earlier
%           twenty-standard-deviation rule certified at the same
%           configuration.  Six configurations; seconds.
%   Part B  shape, mass and internal consistency of the distribution of
%           b at all six configurations: nonnegativity of the density,
%           monotonicity of the cdf, total mass, and agreement between
%           the cdf and the integrated density.  Seconds.
%   Part C  the same for t(betahat) and R^2 at two configurations, from
%           the cdf on a grid, plus agreement of the density with a
%           central difference of the cdf.  Tens of minutes.
%   Part D  sensitivity of a cdf value to a hundredfold tightening of the
%           quadrature tolerance and to a doubling of the truncation
%           point.  Tens of minutes.
%
%   A note on tolerances.  The triple quadratures of TRAT_PDF, TRAT_CDF,
%   RSQ_PDF and RSQ_CDF all default to 1e-4, and how far below that a
%   given call can be pushed depends on the routine, the argument and the
%   configuration: the cdfs will usually reach 1e-6, RSQ_PDF near the
%   origin -- where the density is unbounded -- often will not.  Below
%   its floor INTEGRAL3 exhausts its interval budget or hits its minimum
%   step size, warns, and returns a value that is not a value.  Every
%   call below therefore goes through ASKTOL, which starts at the
%   tolerance asked for and loosens it by factors of ten until the
%   quadrature is quiet, and each line reports the tolerance that
%   actually produced its number.
%
%   TEST_CERTIFY runs all four parts.  TEST_CERTIFY(parts) runs only the
%   parts named in the character vector parts, e.g. TEST_CERTIFY('AB')
%   for the two fast parts or TEST_CERTIFY('CD') for the two slow ones,
%   so that the slow half can be run separately or on another machine.
%
%   Output is written to test_certify_<parts>.out as it is produced, so
%   the run can be monitored and interrupted without losing what is done.

if nargin < 1 || isempty(parts), parts = 'ABCD'; end
parts = upper(parts);
fid = fopen(['test_certify_' parts '.out'],'w'); out = [1 fid];
    function pr(varargin)
        for o = out, fprintf(o,varargin{:}); end
        if fid > 0, fflushfile(fid); end
    end

Ts   = [ 60    120     120     120    240    480   ];
phis = [ 0.9   0.99    0.9805 -0.5    0.995  0.9805];
ruvs = [-0.95 -0.856   0.95   -0.856 -0.99   0     ];
bt   = 0;
nc   = numel(Ts);
hard = [2 3];                       % configurations used in Parts C and D

t00 = tic;
if any(parts == 'A')
pr('\n=== A.  certified truncation of the outer integral ===\n');
pr('%5s %8s %7s %12s %12s %14s\n', ...
   'T','phi','ruv','xu (cert)','xu (20 sd)','log bnd @20sd');
for k = 1:nc
    T=Ts(k); phi=phis(k); ruv=ruvs(k);
    xu = r2_upper(T,phi,bt,ruv);
    xo = r2_upper(T,phi,bt,ruv,20);
    par= qfmgf_setup(T,phi,ruv,bt,'banded');
    th = logspace(-6,4,800);
    [lp,ok] = qfmgf_pd(zeros(size(th)),th*xo,-th,par);
    lb = min([lp(ok) 0]);
    pr('%5d %8.4f %7.3f %12.5g %12.5g %14.2f\n',T,phi,ruv,xu,xo,lb);
end
pr('   (the certified rule targets log(1e-15) = -34.54)\n');
end

if any(parts == 'B')
pr('\n=== B.  distribution of b: shape, mass, consistency ===\n');
pr(['   The window is the exact 1e-10 and 1-1e-10 quantiles, located by\n' ...
    '   bisection on the cdf, so the whole support is covered and the\n' ...
    '   mass column tests the density and not the window.  Integration\n' ...
    '   of the density is by Simpson on 801 points; the last column is\n' ...
    '   the Richardson estimate of that rule''s own error, and is the\n' ...
    '   accuracy to which the mass column can be read.  The cdf is\n' ...
    '   computed with AbsTol 1e-10 and RelTol 1e-6, so decreases up to\n' ...
    '   about 1e-6 are quadrature noise rather than non-monotonicity.\n']);
pr('%5s %8s %7s %11s %13s %12s %12s\n', ...
   'T','phi','ruv','min f','mass','worst dF','Simpson err');
for k = 1:nc
    T=Ts(k); phi=phis(k); ruv=ruvs(k);
    xlo = bq(1e-10,T,bt,phi,ruv);
    xhi = bq(1-1e-10,T,bt,phi,ruv);
    x  = linspace(xlo,xhi,801);
    f  = bhat_pdf(x,T,bt,phi,1,ruv,1e-10);
    F  = bhat_cdf(x,T,bt,phi,1,ruv,1e-10);
    m1 = simp(x,f);                       % 801 points
    m2 = simp(x(1:2:end),f(1:2:end));     % 401 points
    pr('%5d %8.4f %7.3f %11.2e %13.9f %12.2e %12.2e\n', T,phi,ruv, ...
       min(f), m1, min(diff(F)), abs(m1-m2)/15);
end
end

if any(parts == 'C')
pr('\n=== C.  t(betahat) and R^2: cdf on a grid, density vs difference ===\n');
for k = hard
    T=Ts(k); phi=phis(k); ruv=ruvs(k);
    pr('\n  T = %d, phi = %.4f, ruv = %.3f\n',T,phi,ruv);

    xt = [-4 -2 -1 0 1 2 3 5];
    Ft = zeros(size(xt));
    for i = 1:numel(xt)
        tt = tic;
        [Ft(i),tl] = asktol(@(tol) trat_cdf(xt(i),T,bt,phi,ruv,tol),1e-6);
        pr('    t   F(%5.1f) = %.10f   (tol %.0e, %5.1fs)\n', ...
           xt(i),Ft(i),tl,toc(tt));
    end
    pr('    t   monotone %d   range [%.6f, %.6f]\n', ...
       all(diff(Ft) >= -1e-10), Ft(1), Ft(end));

    xr = [0.005 0.02 0.05 0.10 0.20 0.40];
    Fr = zeros(size(xr));
    for i = 1:numel(xr)
        tt = tic;
        [Fr(i),tl] = asktol(@(tol) rsq_cdf(xr(i),T,bt,phi,ruv,tol),1e-6);
        pr('    R2  F(%5.3f) = %.10f   (tol %.0e, %5.1fs)\n', ...
           xr(i),Fr(i),tl,toc(tt));
    end
    pr('    R2  monotone %d\n', all(diff(Fr) >= -1e-10));

    % A central difference of the cdf is limited from two sides: the
    % quadrature tolerance divided by the step, and the O(h^2) truncation
    % of the difference itself.  Neither can be pushed far.  The triple
    % quadrature has a floor below which INTEGRAL3 exhausts its interval
    % budget and returns an unreliable value with a warning, and the floor
    % is not the same for every routine or every argument: the default is
    % 1e-4 for all four, the cdfs will usually go to 1e-6, and RSQ_PDF
    % near the origin -- where the density is unbounded -- often will not.
    % Rather than guess, ASKTOL starts at the tolerance requested and
    % loosens it by factors of ten until the call completes without a
    % warning, and reports the tolerance that worked.
    %
    % The accuracy of the comparison itself is h^2 f''/6, so it depends
    % on the curvature of the density and not on the algorithm.  For the
    % t-ratio that is about 1e-3 at the steps used here.  For R^2 near
    % the origin, where the density carries a w^{-1/2} singularity and
    % falls by a factor of 400 between w = 0.05 and w = 0.15, it is about
    % 2e-2, and a 1 to 2 percent gap is the expected result rather than a
    % discrepancy: CHECK_CDSTEP verifies that halving h cuts the gap by
    % 4.007 and that Richardson extrapolation of the two differences
    % reproduces the density to 7e-6.  This is a check for gross
    % inconsistency between the density and the cdf, not a precision
    % measurement.
    h = 0.05;
    for x0 = [0 1.5]
        tt = tic;
        [fd,tf] = asktol(@(tol) trat_pdf(x0,T,bt,phi,ruv,tol),1e-6);
        [cp,tc] = asktol(@(tol) trat_cdf(x0+h,T,bt,phi,ruv,tol),1e-6);
        [cm,~ ] = asktol(@(tol) trat_cdf(x0-h,T,bt,phi,ruv,tol),tc);
        cd = (cp-cm)/(2*h);
        pr(['    t   f(%4.1f) = %.8f  vs central difference %.8f  ' ...
            '(rel %.2e, expect ~1e-3; tol pdf %.0e cdf %.0e; %5.1fs)\n'], ...
           x0,fd,cd,abs(fd-cd)/max(abs(fd),eps),tf,tc,toc(tt));
    end
    h = 0.005;
    for x0 = [0.05 0.15]
        tt = tic;
        [fd,tf] = asktol(@(tol) rsq_pdf(x0,T,bt,phi,ruv,tol),1e-5);
        [cp,tc] = asktol(@(tol) rsq_cdf(x0+h,T,bt,phi,ruv,tol),1e-6);
        [cm,~ ] = asktol(@(tol) rsq_cdf(x0-h,T,bt,phi,ruv,tol),tc);
        cd = (cp-cm)/(2*h);
        pr(['    R2  f(%5.3f) = %.8f  vs central difference %.8f  ' ...
            '(rel %.2e, expect ~2e-2; tol pdf %.0e cdf %.0e; %5.1fs)\n'], ...
           x0,fd,cd,abs(fd-cd)/max(abs(fd),eps),tf,tc,toc(tt));
    end
end
end

if any(parts == 'D')
pr('\n=== D.  quadrature and truncation sensitivity ===\n');
pr('   (the triple quadrature is not designed below about 1e-6; the\n');
pr('    comparison is therefore the default 1e-4 against 1e-6)\n');
pr('%5s %8s %7s %5s %8s %16s %16s\n', ...
   'T','phi','ruv','stat','x','|1e-4 - 1e-6|','|xu - 2 xu|');
for k = hard
    T=Ts(k); phi=phis(k); ruv=ruvs(k);
    xu = r2_upper(T,phi,bt,ruv);
    x0 = 2.0;
    a       = asktol(@(tol) trat_cdf(x0,T,bt,phi,ruv,tol),1e-4);
    [b,tb]  = asktol(@(tol) trat_cdf(x0,T,bt,phi,ruv,tol),1e-6);
    c       = asktol(@(tol) trat_cdf_xu(x0,T,bt,phi,ruv,tol,2*xu),tb);
    pr('%5d %8.4f %7.3f %5s %8.3g %16.3e %16.3e   (tol %.0e)\n', ...
       T,phi,ruv,'t',x0,abs(a-b),abs(b-c),tb);
    x0 = 0.05;
    a       = asktol(@(tol) rsq_cdf(x0,T,bt,phi,ruv,tol),1e-4);
    [b,tb]  = asktol(@(tol) rsq_cdf(x0,T,bt,phi,ruv,tol),1e-6);
    c       = asktol(@(tol) rsq_cdf_xu(x0,T,bt,phi,ruv,tol,2*xu),tb);
    pr('%5d %8.4f %7.3f %5s %8.3g %16.3e %16.3e   (tol %.0e)\n', ...
       T,phi,ruv,'R2',x0,abs(a-b),abs(b-c),tb);
end
end

pr('\ntotal %.1f minutes\n',toc(t00)/60);
fclose(fid);
end

% -------------------------------------------------------------------------
function q = bq(p,T,bt,phi,ruv)
%BQ  Exact p-quantile of b, by bisection on the exact cdf.
sd = sqrt((1-phi^2)/T);
lo = -60*sd; hi = 60*sd;
for k = 1:60
    m = 0.5*(lo+hi);
    if bhat_cdf(m,T,bt,phi,1,ruv,1e-12) < p, lo = m; else, hi = m; end
    if hi-lo < 1e-13*max(1,abs(hi)), break, end
end
q = 0.5*(lo+hi);
end

% -------------------------------------------------------------------------
function I = simp(x,y)
%SIMP  Composite Simpson rule on a uniform grid with an odd point count.
n = numel(x);
if mod(n,2) == 0, n = n-1; x = x(1:n); y = y(1:n); end
h = (x(end)-x(1))/(n-1);
I = h/3*(y(1)+y(end)+4*sum(y(2:2:end-1))+2*sum(y(3:2:end-2)));
end

% -------------------------------------------------------------------------
function [v,tol] = asktol(f,tol0)
%ASKTOL  Evaluate f(tol), loosening tol until the quadrature is quiet.
%
%   [v,tol] = ASKTOL(f,tol0) calls f(tol0) and, if MATLAB's adaptive
%   quadrature raises a warning (exhausted interval budget, minimum step
%   size reached, unsuccessful integration), retries at ten times the
%   tolerance, up to 1e-3.  Returns the value and the tolerance that
%   produced it, so the caller can report the accuracy it actually got
%   rather than the one it asked for.  A value produced under a warning
%   is not a value; this is how the suite avoids reporting one.
tol = tol0;
while true
    ws = warning('off','all'); lastwarn('');
    try
        v = f(tol);
    catch
        v = NaN;
    end
    warning(ws);
    [msg,~] = lastwarn;
    if isempty(msg) && isfinite(v), return, end
    if tol >= 1e-3, tol = NaN; return, end
    tol = tol*10;
end
end

% -------------------------------------------------------------------------
function fflushfile(fid)
%FFLUSHFILE  Force the buffered output of FID to disk.
try
    s = fopen(fid);
    if ~isempty(s), fseek(fid,0,'eof'); end
catch
end
end

% -------------------------------------------------------------------------
function F = trat_cdf_xu(x,T,bt,phi,ruv,tol,xu)
%TRAT_CDF_XU  TRAT_CDF with the truncation point supplied by the caller.
[m2,s2] = r2_scale(T,phi,bt,ruv);
ylo = -m2/s2; yhi = (xu-m2)/s2;
pref = sqrt(1-phi^2); rhpisq = 1/(2*pi^2);
F = zeros(size(x));
for i = 1:numel(x)
    c = x(i)/sqrt(T-2+x(i)^2);
    F(i) = 0.5 - rhpisq*pref*integral3(@(y,th,v) ...
        r1r2_gh(v/s2,th,c*sqrt(m2+s2*y(1)),m2+s2*y(1),T,bt,phi,ruv, 1,'g','fast') ...
      + r1r2_gh(v/s2,th,c*sqrt(m2+s2*y(1)),m2+s2*y(1),T,bt,phi,ruv,-1,'g','fast'), ...
        ylo,yhi,0,pi/2,0,Inf,'AbsTol',tol);
end
F = max(0,min(1,F));
end

% -------------------------------------------------------------------------
function F = rsq_cdf_xu(x,T,bt,phi,ruv,tol,xu)
%RSQ_CDF_XU  RSQ_CDF with the truncation point supplied by the caller.
[m2,s2] = r2_scale(T,phi,bt,ruv);
ylo = -m2/s2; yhi = (xu-m2)/s2;
pref = sqrt(1-phi^2); rhpisq = 1/(2*pi^2);
F = zeros(size(x));
for i = 1:numel(x)
    z = x(i);
    F(i) = rhpisq*pref*( ...
      integral3(@(y,th,v) ...
        r1r2_gh(v/s2,th,-sqrt(z*(m2+s2*y(1))),m2+s2*y(1),T,bt,phi,ruv, 1,'g','fast') ...
       +r1r2_gh(v/s2,th,-sqrt(z*(m2+s2*y(1))),m2+s2*y(1),T,bt,phi,ruv,-1,'g','fast'), ...
        ylo,yhi,0,pi/2,0,Inf,'AbsTol',tol) ...
     -integral3(@(y,th,v) ...
        r1r2_gh(v/s2,th, sqrt(z*(m2+s2*y(1))),m2+s2*y(1),T,bt,phi,ruv, 1,'g','fast') ...
       +r1r2_gh(v/s2,th, sqrt(z*(m2+s2*y(1))),m2+s2*y(1),T,bt,phi,ruv,-1,'g','fast'), ...
        ylo,yhi,0,pi/2,0,Inf,'AbsTol',tol));
end
F = max(0,min(1,F));
end
