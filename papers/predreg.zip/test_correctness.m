function test_correctness
%TEST_CORRECTNESS  Validation suite for the updated programs.
%
%   Checks, in order:
%   1. ttprims against direct matrix inversion (incl. confluent region)
%   2. bhat_int against a brute-force characteristic function (small T)
%   3. r1r2_gh against a brute-force integrand (small T)
%   4. new O(1) pdf/cdf vs eigenvalue benchmarks (moderate T)
%   5. stress: highly persistent predictor and large T (no overflow)

fprintf('--- 1. ttprims vs direct inversion ---\n');
rng(0);
for m = [5 9 20]
    p = 1.3-0.7i; q = -0.9-0.2i;
    Dm = diag(p*ones(m,1))+diag(q*ones(m-1,1),1)+diag(q*ones(m-1,1),-1);
    Di = inv(Dm); D2 = Di*Di; D3 = D2*Di;
    on = ones(m,1); e1 = eye(m,1); em = flipud(e1);
    P = ttprims(p,q,m,3);
    chk('d1', P.d1, on'*Di*on);   chk('d2', P.d2, e1'*Di*on);
    chk('d3', P.d3, e1'*Di*e1);   chk('d4', P.d4, e1'*Di*em);
    chk('tr1',P.tr1,trace(Di));
    chk('d1t',P.d1t,on'*D2*on);   chk('d2t',P.d2t,e1'*D2*on);
    chk('d3t',P.d3t,e1'*D2*e1);   chk('d4t',P.d4t,e1'*D2*em);
    chk('tr2',P.tr2,trace(D2));
    chk('d1s',P.d1s,on'*D3*on);   chk('d2s',P.d2s,e1'*D3*on);
    chk('d3s',P.d3s,e1'*D3*e1);   chk('d4s',P.d4s,e1'*D3*em);
    chk('log|1/D|',exp(P.logabs_invD+1i*P.arg_invD),1/det(Dm),1e-8);
end
% confluent region
m = 9; q = -1-1e-9i; p = -2*q*(1+1e-9);
Dm = diag(p*ones(m,1))+diag(q*ones(m-1,1),1)+diag(q*ones(m-1,1),-1);
Di = inv(Dm); D2 = Di*Di; D3 = D2*Di;
on = ones(m,1); e1 = eye(m,1); em = flipud(e1);
P = ttprims(p,q,m,3);
chk('confl d1', P.d1, on'*Di*on);
chk('confl d1t',P.d1t,on'*D2*on);
chk('confl d1s',P.d1s,on'*D3*on);
chk('confl d3s',P.d3s,e1'*D3*e1);
chk('confl tr2',P.tr2,trace(D2));

fprintf('--- 2. bhat_int vs brute force (T=9) ---\n');
T = 9; phi = 0.7; ruv = -0.5; r = 0.3;
[Af,Bf,V] = bhat_bruteforce_setup(T,phi,ruv);
for s = [0.15 0.8 3.7 11]
    tt = -r*s;
    Mfull = eye(2*T)-2i*s*Af-2i*tt*Bf;
    cf  = det(Mfull)^(-1/2);            % small T: direct principal root ok
    tr  = trace(Mfull\Bf);
    chk('cdf integrand', bhat_int(s,r,T,phi,ruv,'cdf'), imag(cf)/s, 1e-7);
    chk('pdf integrand', bhat_int(s,r,T,phi,ruv,'pdf'), real(cf*tr), 1e-7);
end

fprintf('--- 3. r1r2_gh vs brute force (T=9) ---\n');
bt = 0.2; r1v = 0.15; r2v = 1.1; th = 0.6; R = 0.9;
[A1f,A2f,Bf2] = r1r2_bruteforce_setup(T,bt,phi,ruv);
for tsign = [1 -1]
    s = R*cos(th); tv = tsign*R*sin(th);
    C = inv(eye(2*T)-2i*s*(A1f-r1v*Bf2)-2i*tv*(A2f-r2v*Bf2));
    cf = sqrt(det(C));
    gB = trace(C*Bf2);
    g  = imag(cf*gB)*R/s;
    h  = real(cf*(gB^2+2*trace((C*Bf2)^2)))*R;
    chk(sprintf('g (tsign=%d)',tsign), ...
        sqrt(1-phi^2)*r1r2_gh(R,th,r1v,r2v,T,bt,phi,ruv,tsign,'g'), g, 1e-7);
    chk(sprintf('h (tsign=%d)',tsign), ...
        sqrt(1-phi^2)*r1r2_gh(R,th,r1v,r2v,T,bt,phi,ruv,tsign,'h'), h, 1e-7);
end

fprintf('--- 4. new vs eigenvalue benchmarks (T=30) ---\n');
T = 30; b = 0.05; phi = 0.95; c0 = 15; ruv = -0.85;
x = b+c0*[-0.1 0 0.15];
chk('bhat_pdf', bhat_pdf(x,T,b,phi,c0,ruv), bhat_pdf_eig(x,T,b,phi,c0,ruv), 1e-5);
chk('bhat_cdf', bhat_cdf(x,T,b,phi,c0,ruv), bhat_cdf_eig(x,T,b,phi,c0,ruv), 1e-5);
bt = 0.1; ruv2 = -0.5; phi2 = 0.9;
tv = [-1.5 0.5]; zv = [0.05 0.2];
chk('trat_cdf', trat_cdf(tv,T,bt,phi2,ruv2), trat_cdf_eig(tv,T,bt,phi2,ruv2), 2e-3);
chk('trat_pdf', trat_pdf(tv,T,bt,phi2,ruv2), trat_pdf_eig(tv,T,bt,phi2,ruv2), 2e-3);
chk('rsq_cdf',  rsq_cdf(zv,T,bt,phi2,ruv2),  rsq_cdf_eig(zv,T,bt,phi2,ruv2),  2e-3);
chk('rsq_pdf',  rsq_pdf(zv,T,bt,phi2,ruv2),  rsq_pdf_eig(zv,T,bt,phi2,ruv2),  2e-3);

fprintf('--- 5. certified pivot phase (bordered_phase) ---\n');
% bordered_phase vs direct determinant, and engine agreement
T5 = 12; phi5 = 0.7; ruv5 = -0.5; r5 = 0.3;
for s5 = [0.2 1.1 6.0]
    yf = bhat_int(s5,r5,T5,phi5,ruv5,'cdf','fast');
    yp = bhat_int(s5,r5,T5,phi5,ruv5,'cdf','pivot');
    chk(sprintf('engines s=%.1f',s5), yf, yp, 1e-10);
end
% phi ~ 1: pivot engine must remain accurate where fast engine degrades
[Af5,Bf5] = bhat_bruteforce_setup(T5,0.99999,ruv5);
emax = 0;
for s5 = logspace(-6,1,25)
    lam5 = eig(eye(2*T5)-2i*s5*Af5-2i*(-0.1*s5)*Bf5);
    ref = imag(prod(lam5.^(-1/2)))/s5;
    yp  = bhat_int(s5,0.1,T5,0.99999,ruv5,'cdf','pivot');
    emax = max(emax, abs(yp-ref)/max(abs(ref),1e-3));
end
chk('pivot phi=0.99999', emax, 0, 1e-7);
fprintf('--- 6. stress tests ---\n');
% highly persistent + large T: must run without NaN/overflow
tic; F = bhat_cdf([0 0.4],1000,0,0.999,1,-0.9); t1 = toc;
fprintf('bhat_cdf T=1000 phi=0.999: F = [%.6f %.6f]  (%.2f s)  monotone: %d\n', ...
        F(1),F(2),t1,F(2)>F(1));
tic; f = bhat_pdf(0.1,5000,0,0.98,1,-0.5); t2 = toc;
fprintf('bhat_pdf T=5000: f = %.6g  (%.2f s)  finite: %d\n', f, t2, isfinite(f));
% pdf integrates to ~1 at moderate T
q = integral(@(u) bhat_pdf_vec(u,200,0,0.98,1,-0.85),-Inf,Inf,'AbsTol',1e-6);
fprintf('bhat_pdf integrates to %.8f (T=200, phi=0.98)\n', q);
fprintf('ALL TESTS DONE\n');
end

function chk(name,a,b,tol)
if nargin < 4, tol = 1e-9; end
err = max(abs(a(:)-b(:)))/max(1,max(abs(b(:))));
if err < tol, s = 'OK  '; else, s = 'FAIL'; end
fprintf('%s %-16s rel.err = %.2e\n', s, name, err);
end

function f = bhat_pdf_vec(u,T,b,phi,c0,ruv)
f = zeros(size(u));
for i = 1:numel(u), f(i) = bhat_pdf(u(i),T,b,phi,c0,ruv); end
end

function [Af,Bf,V] = bhat_bruteforce_setup(T,phi,ruv)
one = ones(T,1); M = eye(T)-one*one'/T;
H = toeplitz(phi.^(0:T-1))/(1-phi^2);
G = toeplitz(zeros(1,T),[0 phi.^(0:T-2)]);
V = [eye(T) ruv*G; ruv*G' H];
Z = zeros(T);
A = [Z M/2; M/2 Z];  B = [Z Z; Z M];
Vh = sqrtm(V);
Af = Vh*A*Vh; Bf = Vh*B*Vh;
end

function [A1f,A2f,Bf] = r1r2_bruteforce_setup(T,bt,phi,ruv)
one = ones(T,1); M = eye(T)-one*one'/T;
H = toeplitz(phi.^(0:T-1))/(1-phi^2);
G = toeplitz(zeros(1,T),[0 phi.^(0:T-2)]);
K = G+G';
V = [eye(T)+bt*ruv*K+bt^2*H bt*H+ruv*G; bt*H+ruv*G' H];
Z = zeros(T);
A1 = [Z M/2; M/2 Z];  A2 = [M Z; Z Z];  B = [Z Z; Z M];
Vh = sqrtm(V);
A1f = Vh*A1*Vh; A2f = Vh*A2*Vh; Bf = Vh*B*Vh;
end
