function test_largen
%TEST_LARGEN  The confluent branch at large n, against an exact reference.
%
%   Dense inversion stops being a usable reference well before the sample
%   sizes the paper cares about.  In the confluent region D is nearly
%   singular by construction --- its smallest eigenvalue is
%   2q(delta-delta_1) with delta_1 = 2 sin^2(pi/(2n)), so the condition
%   number grows like n^2 --- and a dense inverse therefore carries a
%   relative error of order eps*n^2 of its own: about 1e-11 already at
%   n = 300.  Beyond that the reference is worse than the quantity being
%   tested and the comparison measures the reference.
%
%   The spectral representations of the Appendix have no such limit.
%   Every primitive is exactly sum_j w_j lambda_j^{-l} with
%   lambda_j = p+2q cos(j pi/n) and weights known in closed form, so in
%   variable precision it is an exact reference at any n.  This script
%   uses it to carry the check out to n of several thousand.
LOG = 'largen_log.txt';
fid = fopen(LOG,'w'); out = [1 fid];
pr = @(varargin) prn(out,varargin{:});

fields = {'d1','d2','d3','d4','tr1','d1t','d2t','d3t','d4t', ...
          'tr2','d1s','d2s','d3s','d4s'};
dg = digits(34);
pr('=== Chebyshev branch vs a 34-digit spectral reference ===========\n');
pr('   (tau spread over the band, three q; worst relative error over\n');
pr('    all fourteen primitives, and over log|D|)\n\n');
pr('   %8s %10s %14s %14s\n','m','nodes','primitives','log|D|');
for m = [100 600 2400 9600]
    n = m+1;
    tv  = [1e-5 1e-3 0.05 0.4 1.2 2.4];
    th  = [0.4 2.6 4.9];
    [Tg,Th] = ndgrid(tv,th);
    dlt = (Tg(:).').*exp(1i*Th(:).')/n^2;
    qs  = [-0.95, -0.9-0.4i, 0.3+1i];
    worstP = 0; worstL = 0;
    jj  = (1:m).';
    for qv0 = qs
        qv = repmat(qv0,size(dlt));
        pv = 2*qv.*(dlt-1);
        F  = ttprims(pv,qv,m,3,inf);          % force the Chebyshev branch
        cs = cos(vpa(jj)*vpa(pi)/vpa(n));
        w3 = (2/vpa(n))*sin(vpa(jj)*vpa(pi)/vpa(n)).^2;
        w4 = w3.*(-1).^(jj-1);
        od = mod(jj,2)==1;
        w1 = vpa(zeros(m,1)); w2 = w1;
        w1(od) = (2/vpa(n))*cot(vpa(jj(od))*vpa(pi)/(2*vpa(n))).^2;
        w2(od) = (4/vpa(n))*cos(vpa(jj(od))*vpa(pi)/(2*vpa(n))).^2;
        W = [w1 w2 w3 w4 ones(m,1)];
        for k = 1:numel(dlt)
            lam = vpa(pv(k))+2*vpa(qv0)*cs;
            ref = vpa(zeros(1,14));
            il  = 1./lam;  acc = il;
            for l = 1:3
                S = (acc.'*W);                       % 1 x 5, order l
                if l == 1, ref(1:5)   = S;
                elseif l == 2, ref(6:10) = S([1 2 3 4 5]);
                else,          ref(11:14)= S(1:4);
                end
                acc = acc.*il;
            end
            got = vpa(zeros(1,14));
            for f = 1:14, got(f) = F.(fields{f})(k); end
            worstP = max(worstP, double(max(abs(got-ref)./abs(ref))));
            lref = -sum(log(abs(lam)));
            worstL = max(worstL, double(abs(F.logabs_invD(k)-lref)));
        end
    end
    pr('   %8d %10d %14.2e %14.2e\n',m,numel(dlt)*numel(qs),worstP,worstL);
end
digits(dg);
pr('\nDONE\n');
fclose(fid);
end

function prn(out,varargin)
for o = out, fprintf(o,varargin{:}); end
end
