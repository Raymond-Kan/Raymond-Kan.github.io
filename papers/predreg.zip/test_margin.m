function test_margin
%TEST_MARGIN  How far above its threshold the Chebyshev branch holds.
%
%   The two branches of TTPRIMS are switched at tau = |x+1|n^2 = 5/2.
%   This script forces every node down the confluent branch (thr = inf)
%   and measures it against a dense reference well above that threshold,
%   so that the margin the switch is carrying is a measurement rather
%   than an assertion.  It also reports the generic branch on the same
%   nodes, since the claim that the threshold is uncritical needs both
%   sides to be accurate where they overlap.
LOG = 'margin_log.txt';
fid = fopen(LOG,'w'); out = [1 fid];
pr = @(varargin) prn(out,varargin{:});

fields = {'d1','d2','d3','d4','tr1','d1t','d2t','d3t','d4t', ...
          'tr2','d1s','d2s','d3s','d4s'};
edges  = [2.5 5 10 20 40 80 160 320];
ths    = [0.3 1.2 2.2 3.4 4.4 5.6];
qs     = [-0.95, -0.9-0.4i, 0.3+1i];

for m = [30 100 300]
    n = m+1;
    pr('\n=== m = %d ==================================================\n',m);
    pr('   %12s %8s %14s %14s\n','tau band','nodes','Chebyshev','roots');
    for e = 1:numel(edges)-1
        tg = linspace(edges(e),edges(e+1),7);
        [Tg,Th] = ndgrid(tg,ths);
        dlt = (Tg(:).').*exp(1i*Th(:).')/n^2;
        eC = 0; eG = 0;
        for qv0 = qs
            qv = repmat(qv0,size(dlt));
            pv = 2*qv.*(dlt-1);
            Fc = ttprims(pv,qv,m,3,inf);     % force the Chebyshev branch
            Fg = ttprims(pv,qv,m,3,0);       % force the closed forms
            for j = 1:numel(dlt)
                D  = diag(pv(j)*ones(m,1))+diag(qv0*ones(m-1,1),1) ...
                                          +diag(qv0*ones(m-1,1),-1);
                M1 = inv(D); M2 = M1*M1; M3 = M2*M1;
                o = ones(m,1); e1 = eye(m,1); em = flipud(e1);
                ref = [o'*M1*o, e1'*M1*o, e1'*M1*e1, e1'*M1*em, trace(M1), ...
                       o'*M2*o, e1'*M2*o, e1'*M2*e1, e1'*M2*em, trace(M2), ...
                       o'*M3*o, e1'*M3*o, e1'*M3*e1, e1'*M3*em];
                gc = zeros(1,14); gg = zeros(1,14);
                for k = 1:14
                    gc(k) = Fc.(fields{k})(j);
                    gg(k) = Fg.(fields{k})(j);
                end
                eC = max(eC, max(abs(gc-ref)./abs(ref)));
                eG = max(eG, max(abs(gg-ref)./abs(ref)));
            end
        end
        pr('   %5g - %-5g %8d %14.2e %14.2e\n', ...
           edges(e),edges(e+1),numel(dlt)*numel(qs),eC,eG);
    end
end
pr('\nDONE\n');
fclose(fid);
end

function prn(out,varargin)
for o = out, fprintf(o,varargin{:}); end
end
