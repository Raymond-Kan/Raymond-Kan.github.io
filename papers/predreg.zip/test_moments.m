function test_moments
%TEST_MOMENTS  Validation of the exact-moment programs.
%   (1) the mgf evaluator against a dense computation at T = 6;
%   (2) exact closed forms in the ruv = 0, bt = 0 case (central t / beta);
%   (3) the Stambaugh bias approximation for E[b];
%   (4) simulation for a general configuration.
warning('off','all');
fid = fopen('moments_test_log.txt','w');
out = [1 fid];

%% (1) dense check of log Psi at T = 6
T = 6; phi = 0.7; ruv = -0.5; bt = 0.3;
par = qfmgf_setup(T,phi,ruv,bt);
pab = qfmgf_setup(T,phi,ruv,bt,'banded');
[V,A,B,C] = dense_model(T,phi,ruv,bt);
rng(1); maxerr = 0; maxerb = 0;
for k = 1:12
    r = 0.08*randn + 0.05i*randn; s = 0.5*rand; t = 0.5*rand;
    W  = inv(V) - 2*r*A + 2*s*B + 2*t*C;
    lpd = -0.5*(log(det(V)) + log(det(W)));
    maxerr = max(maxerr, abs(qfmgf_logpsi_f(r,s,t,par) - lpd));
    maxerb = max(maxerb, abs(qfmgf_logpsi(r,s,t,pab)    - lpd));
end
for o = out
    fprintf(o,['(1) dense check, T=6: max |logPsi - dense| = %.2e ' ...
               '(O(1)), %.2e (banded)\n\n'],maxerr,maxerb);
end

%% (2) exact closed forms at ruv = 0, bt = 0 (any phi)
T = 20; phi = 0.9; nu = T-2;
mt = tratmom(4,T,phi,0,0);
mr = rsqmom(2,T,phi,0,0);
mb1 = bmom(1,T,phi,0);
ex = [0, nu/(nu-2), 0, 3*nu^2/((nu-2)*(nu-4)), 1/(T-1), 3/((T-1)*(T+1)), 0];
got = [mt, mr, mb1];
names = {'E[t]','E[t^2]','E[t^3]','E[t^4]','E[R2]','E[R2^2]','E[b]'};
for o = out
    fprintf(o,'(2) ruv = 0 closed forms, T=20, phi=0.9\n');
    fprintf(o,'    %-8s %12s %12s %10s\n','moment','exact','computed','error');
    for i = 1:7
        fprintf(o,'    %-8s %12.8f %12.8f %10.2e\n', ...
            names{i},ex(i),got(i),abs(got(i)-ex(i)));
    end
    fprintf(o,'\n');
end

%% (3) Stambaugh bias approximation for E[b]
for o = out, fprintf(o,'(3) E[b] against -ruv(1+3phi)/T\n'); end
for cfg = [100 0.9 -0.856; 400 0.95 -0.856; 100 0.5 0.4]'
    T = cfg(1); phi = cfg(2); ruv = cfg(3);
    eb = bmom(1,T,phi,ruv);
    ap = -ruv*(1+3*phi)/T;
    for o = out
        fprintf(o,'    T=%4d phi=%.2f ruv=%+.3f  exact %+.6f  approx %+.6f\n', ...
            T,phi,ruv,eb,ap);
    end
end
for o = out, fprintf(o,'\n'); end

%% (4) simulation, general configuration
T = 30; phi = 0.95; ruv = -0.856; bt = 0.1; nrep = 2e6;
rng(20260808);
[bs,ts,rs] = simulate(T,phi,ruv,bt,nrep);
mb = bmom(2,T,phi,ruv);
mt = tratmom(2,T,phi,ruv,bt);
mr = rsqmom(1,T,phi,ruv,bt);
vals = {'E[b]',mb(1),mean(bs); 'E[b^2]',mb(2),mean(bs.^2); ...
        'E[t]',mt(1),mean(ts); 'E[t^2]',mt(2),mean(ts.^2); ...
        'E[R2]',mr(1),mean(rs)};
ses  = [std(bs) std(bs.^2) std(ts) std(ts.^2) std(rs)]/sqrt(nrep);
for o = out
    fprintf(o,'(4) simulation, T=30, phi=0.95, ruv=-0.856, bt=0.1, %d reps\n',nrep);
    fprintf(o,'    %-8s %12s %12s %10s\n','moment','formula','simulated','diff/se');
    for i = 1:5
        fprintf(o,'    %-8s %12.6f %12.6f %+9.2f\n', ...
            vals{i,1},vals{i,2},vals{i,3},(vals{i,2}-vals{i,3})/ses(i));
    end
end
fclose(fid);
end

% ----------------------------------------------------------------------
function [V,A,B,C] = dense_model(T,phi,ruv,bt)
id = (0:T-1)';
H  = phi.^abs(id-id')/(1-phi^2);
G  = zeros(T);
for i = 1:T
    for j = i+1:T, G(i,j) = phi^(j-i-1); end
end
V  = [eye(T) ruv*G; ruv*G' H];
M  = eye(T) - ones(T)/T;
Z  = zeros(T);
A  = [Z M/2; M/2 bt*M];
B  = [Z Z; Z M];
C  = [M bt*M; bt*M bt^2*M];
end

function [bs,ts,rs] = simulate(T,phi,ruv,bt,nrep)
bs = zeros(nrep,1); ts = bs; rs = bs;
bsz = 1e5; nu = T-2;
for c0 = 1:bsz:nrep
    idx = c0:min(c0+bsz-1,nrep); nb = numel(idx);
    v = randn(T,nb);
    u = ruv*v + sqrt(1-ruv^2)*randn(T,nb);
    z = zeros(T,nb); zprev = randn(1,nb)/sqrt(1-phi^2);
    for tt2 = 1:T
        z(tt2,:) = zprev;             % z_{t-1}
        zprev = phi*zprev + v(tt2,:);
    end
    r = bt*z + u;
    zm = z - mean(z,1); um = u - mean(u,1); rm = r - mean(r,1);
    UBv = sum(zm.^2,1);
    UAu = sum(zm.*um,1);              % for b
    UAr = sum(zm.*rm,1);              % for t and R^2
    UCv = sum(rm.^2,1);
    bs(idx) = (UAu./UBv)';
    ts(idx) = (sqrt(nu)*UAr./sqrt(UBv.*UCv - UAr.^2))';
    rs(idx) = (UAr.^2./(UBv.*UCv))';
end
end
