function test_o1
%TEST_O1  Check the O(1) mgf evaluator against the banded and dense routes.
warning('off','all');
fid = fopen('test_o1_log.txt','w'); out = [1 fid];

%% (1) dense determinant at small T, real and complex arguments
for cfg = [6 0.7 -0.5 0.3; 9 -0.4 0.75 0; 7 0.95 -0.856 0.12]'
    T = cfg(1); phi = cfg(2); ruv = cfg(3); bt = cfg(4);
    par = qfmgf_setup(T,phi,ruv,bt);
    pab = qfmgf_setup(T,phi,ruv,bt,'banded');
    [V,A,B,C] = dense_model(T,phi,ruv,bt);
    rng(7); eF = 0; eB = 0;
    for k = 1:20
        r = 0.05*randn + (k>10)*0.03i*randn;
        s = 0.6*rand; t = 0.6*rand;
        W  = inv(V) - 2*r*A + 2*s*B + 2*t*C;
        ld = -0.5*(log(det(V)) + log(det(W)));
        eF = max(eF, abs(qfmgf_logpsi_f(r,s,t,par) - ld));
        eB = max(eB, abs(qfmgf_logpsi(r,s,t,pab)   - ld));
    end
    for o = out
        fprintf(o,['(1) T=%2d phi=%+.2f ruv=%+.3f bt=%.2f: ' ...
                   'O(1) vs dense %.2e, banded vs dense %.2e\n'], ...
                T,phi,ruv,bt,eF,eB);
    end
end

%% (2) O(1) against the banded route at large T, on a realistic grid
for cfg = [120 0.95 -0.856 0.1; 960 0.99 -0.5 0; 20000 0.9805 -0.856 0.05]'
    T = cfg(1); phi = cfg(2); ruv = cfg(3); bt = cfg(4);
    par = qfmgf_setup(T,phi,ruv,bt);
    pab = qfmgf_setup(T,phi,ruv,bt,'banded');
    rng(11);
    s = par.cB*10.^(-2+3*rand(1,40));
    t = par.cC*10.^(-2+3*rand(1,40));
    r = par.rscale*(randn(1,40)+0.2i*randn(1,40));
    lf = qfmgf_logpsi_f(r,s,t,par);
    lb = qfmgf_logpsi(r,s,t,pab);
    rel = max(abs(lf-lb)./max(abs(lb),1));
    for o = out
        fprintf(o,'(2) T=%5d phi=%.4f: max rel |O(1) - banded| = %.2e\n', ...
                T,phi,rel);
    end
end

%% (3) timing: O(1) must be flat in T, banded linear
Ts = [120 960 7680];
for o = out, fprintf(o,'\n(3) 5000 evaluations, seconds\n'); end
for T = Ts
    par = qfmgf_setup(T,0.95,-0.856,0);
    pab = qfmgf_setup(T,0.95,-0.856,0,'banded');
    s = par.cB*ones(1,5000); t = par.cC*ones(1,5000);
    r = par.rscale*linspace(-1,1,5000);
    tic; qfmgf_logpsi_f(r,s,t,par); a = toc;
    tic; qfmgf_logpsi(r,s,t,pab);   b = toc;
    for o = out
        fprintf(o,'    T=%5d   O(1) %7.3f   banded %7.3f\n',T,a,b);
    end
end
fclose(fid);
end

% ----------------------------------------------------------------------
function [V,A,B,C] = dense_model(T,phi,ruv,bt)
id = (0:T-1)';
H  = phi.^abs(id-id')/(1-phi^2);
G  = zeros(T);
for i = 1:T
    for j = i+1:T, G(i,j) = phi^(j-i-1); end
end
V  = [eye(T) ruv*G; ruv*G' H];
M  = eye(T) - ones(T)/T;
Z  = zeros(T);
A  = [Z M/2; M/2 bt*M];
B  = [Z Z; Z M];
C  = [M bt*M; bt*M bt^2*M];
end
