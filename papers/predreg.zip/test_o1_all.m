function test_o1_all
%TEST_O1_ALL  Is every released routine really O(1) in the sample size?
%
%   The claim is that the cost of each integrand evaluation, and hence of
%   each density, distribution function and moment, does not grow with T.
%   This measures it rather than asserting it, over a range of T spanning
%   four orders of magnitude, and reports the ratio of the cost at the
%   largest sample size to that at the smallest.  A ratio near one is the
%   claim; anything growing like T or T^3 is not.
%
%   Two routines are deliberately not O(1) and are checked to be so: the
%   'pivot' phase engine, an O(T) option offered as a cross-check, and
%   the eigenvalue benchmarks, which are O(T^3).
LOG = 'o1_log.txt';
fid = fopen(LOG,'w'); out = [1 fid];
pr = @(varargin) prn(out,varargin{:});
phi = 0.9805; ruv = -0.856; bt = 0;
Ts  = [120 960 7680 61440 491520];

%% ---- integrands, microseconds per call --------------------------------
pr('=== integrand cost, microseconds per evaluation =================\n\n');
pr('   %10s %12s %12s %12s %12s\n','T','b cdf','b pdf','t/R2 g','t/R2 h');
c = zeros(numel(Ts),4);
for i = 1:numel(Ts)
    T = Ts(i);
    c(i,1) = tm(@() bhat_int(0.7,0.1,T,phi,ruv,'cdf'));
    c(i,2) = tm(@() bhat_int(0.7,0.1,T,phi,ruv,'pdf'));
    c(i,3) = tm(@() r1r2_gh(0.9,0.6,0.15,1.1,T,bt,phi,ruv, 1,'g'));
    c(i,4) = tm(@() r1r2_gh(0.9,0.6,0.15,1.1,T,bt,phi,ruv, 1,'h'));
    pr('   %10d %12.2f %12.2f %12.2f %12.2f\n',T,c(i,:));
end
pr('\n   ratio T=%d to T=%d: %.2f %.2f %.2f %.2f  (O(1) => about 1)\n', ...
   Ts(end),Ts(1),c(end,:)./c(1,:));

%% ---- the mgf and its derivatives --------------------------------------
pr('\n=== mgf and derivatives, microseconds per node ==================\n\n');
pr('   %10s %12s %12s %12s\n','T','log Psi','d/dr (p=2)','d/dr (p=6)');
d = zeros(numel(Ts),3);
for i = 1:numel(Ts)
    T = Ts(i);
    par = qfmgf_setup(T,phi,ruv,bt,'fast');
    s = 0.5/par.cB; t = 1/par.cC;
    d(i,1) = tm(@() qfmgf_logpsi_f(0,s,t,par));
    d(i,2) = tm(@() qfmgf_dp(2,0,s,t,par));
    d(i,3) = tm(@() qfmgf_dp(6,0,s,t,par));
    pr('   %10d %12.2f %12.2f %12.2f\n',T,d(i,:));
end
pr('\n   ratio: %.2f %.2f %.2f\n',d(end,:)./d(1,:));

%% ---- whole moments ----------------------------------------------------
pr('\n=== complete moment computations, seconds =======================\n\n');
pr('   %10s %12s %12s %12s\n','T','bmom(2)','rsqmom(2)','tratmom(2)');
e = zeros(numel(Ts),3);
for i = 1:numel(Ts)
    T = Ts(i);
    t0=tic; bmom(2,T,phi,ruv);        e(i,1)=toc(t0);
    t0=tic; rsqmom(2,T,phi,ruv,bt);   e(i,2)=toc(t0);
    t0=tic; tratmom(2,T,phi,ruv,bt);  e(i,3)=toc(t0);
    pr('   %10d %12.3f %12.3f %12.3f\n',T,e(i,:));
end
pr('\n   ratio: %.2f %.2f %.2f\n',e(end,:)./e(1,:));

%% ---- a complete cdf at the extremes -----------------------------------
pr('\n=== one complete cdf evaluation, seconds ========================\n\n');
pr('   %10s %12s\n','T','b cdf');
for T = [120 491520]
    t0=tic; F=bhat_cdf(0.15,T,0,phi,1,ruv); e1=toc(t0);
    pr('   %10d %12.3f   (F = %.10f)\n',T,e1,F);
end

%% ---- the two routines that are deliberately not O(1) ------------------
pr('\n=== the deliberate exceptions ===================================\n\n');
pr('   %10s %14s %14s\n','T','pivot engine','eig benchmark');
for T = [120 480 1920]
    a = tm(@() bhat_int(0.7,0.1,T,phi,ruv,'cdf','pivot'));
    t0=tic; bhat_cdf_eig(0.15,T,0,phi,1,ruv); b = toc(t0)*1e6;
    pr('   %10d %14.2f %14.2f\n',T,a,b);
end
pr('   (the first should grow like T, the second like T^3;\n');
pr('    neither is on the default path)\n');

pr('\nDONE\n');
fclose(fid);
end

% =========================================================================
function us = tm(f)
%TM  Microseconds per call, median of a short repeated run after a warm-up.
f(); f();
n = 20; v = zeros(1,n);
for k = 1:n, t0 = tic; f(); v(k) = toc(t0); end
us = median(v)*1e6;
end

function prn(out,varargin)
for o = out, fprintf(o,varargin{:}); end
end
