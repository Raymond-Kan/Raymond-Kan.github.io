function test_oddmom
%TEST_ODDMOM  The odd-moment route: QFMGF_DJS and TRATMOM_ODD.
%
%   Part 1 checks the s-derivative jets of QFMGF_DJS against a 40-digit
%   reference from the dense determinant (Cauchy circle in s, variable
%   precision), at points on the odd-moment path including its r > 0
%   half.  Part 2 checks TRATMOM_ODD against TRATMOM, whose cone route
%   is independently validated: the two representations must agree.
%   Part 3 is convergence in the node counts, and part 4 timing, which
%   substantiates the "about five times cheaper" claim of the paper.
LOG = 'oddmom_log.txt';
fid = fopen(LOG,'w'); out = [1 fid];
pr = @(varargin) prn(out,varargin{:});

%% ---- 1. s-jets against a 40-digit dense reference --------------------
pr('=== 1. QFMGF_DJS vs 40-digit dense s-derivatives ================\n');
digitsOld = digits(40);
for cfg = {{30,0.90,-0.856,0},{30,0.99,-0.500,0.10}}
    [T,phi,ruv,bt] = cfg{1}{:};
    par = qfmgf_setup(T,phi,ruv,bt,'fast');
    lamv = 0.8/par.cC; thv = [0.7 -1.3];       % both signs of r = 2*lam*th
    for th0 = thv
        r0 = 2*lamv*th0; s0 = lamv*th0^2; t0 = lamv;
        Dj = qfmgf_djs(3,r0,s0,t0,par);
        Dref = vpa_sderivs(3,r0,s0,t0,T,phi,ruv,bt,0.25*s0);
        pr('T=%d phi=%.2f bt=%.2f  th=%+.1f:',T,phi,bt,th0);
        for mm = 1:3
            pr('  m=%d %8.1e',mm,double(abs(Dj(mm)-Dref(mm))/abs(Dref(mm))));
        end
        pr('\n');
    end
end
digits(digitsOld);

%% ---- 2. TRATMOM_ODD against the cone route ---------------------------
pr('\n=== 2. TRATMOM_ODD vs TRATMOM ===================================\n');
pr('   %5s %6s %7s %7s %3s %14s %14s %10s\n', ...
   'T','phi','ruv','bt','p','odd route','cone route','rel diff');
for cfg = {{14,0.90,-0.5,0.10},{60,0.95,-0.856,0.0446}, ...
           {240,0.9805,-0.856,0.02},{960,0.95,0,0.0446}}
    [T,phi,ruv,bt] = cfg{1}{:};
    for p = [3 5]
        mo = tratmom_odd(p,T,phi,ruv,bt);
        mc = tratmom(p,T,phi,ruv,bt);  mc = mc(p);
        pr('   %5d %6.3f %7.3f %7.4f %3d %14.8f %14.8f %10.1e\n', ...
           T,phi,ruv,bt,p,mo,mc,abs(mo-mc)/max(abs(mc),1e-12));
    end
end

%% ---- 3. convergence in the node counts -------------------------------
pr('\n=== 3. node-count convergence (T=60 case, p=3) ==================\n');
ref = tratmom_odd(3,60,0.95,-0.856,0.0446,struct('nl',128,'nth',192));
for nl = [32 48 64 96]
    v = tratmom_odd(3,60,0.95,-0.856,0.0446,struct('nl',nl,'nth',round(1.5*nl)));
    pr('   nl=%3d nth=%3d   %14.10f   err vs fine %8.1e\n', ...
       nl,round(1.5*nl),v,abs(v-ref)/abs(ref));
end

%% ---- 4. timing --------------------------------------------------------
pr('\n=== 4. cost of one odd moment (T=240 case, p=3) =================\n');
tratmom_odd(3,240,0.9805,-0.856,0.02);          % warm-up
t0=tic; tratmom_odd(3,240,0.9805,-0.856,0.02);  to=toc(t0);
t0=tic; tratmom(3,240,0.9805,-0.856,0.02);      tc=toc(t0);
pr('   odd route %.3fs   cone route %.3fs   ratio %.1f\n',to,tc,tc/to);
pr('\nDONE\n');
fclose(fid);
end

% =========================================================================
function D = vpa_sderivs(pmax,r0,s0,t0,T,phi,ruv,bt,h0)
%   The circle radius must stay well inside the domain of analyticity:
%   Psi has a singularity at the s where |W| vanishes, which can sit
%   close below small base points, and a circle that passes near it
%   makes the half-power flip sign across the nodes.  A radius
%   proportional to s0 is safe; in variable precision the p!/h^p
%   amplification costs nothing.
[V,A,B,C] = dense_model(T,phi,ruv,bt);
Vi = inv(vpa(V));
h  = vpa(h0);
nc = 48;
lp = @(s) -log(det(Vi-2*vpa(r0)*vpa(A)+2*s*vpa(B)+2*vpa(t0)*vpa(C)))/2;
th = 2*sym(pi)*(0:nc-1)/nc;
l0 = lp(vpa(s0)); F = vpa(zeros(1,nc));
for j = 1:nc, F(j) = exp(lp(vpa(s0)+h*exp(1i*th(j)))-l0); end
D = vpa(zeros(1,pmax));
for m = 1:pmax
    acc = vpa(0);
    for j = 1:nc, acc = acc+F(j)*exp(-1i*m*th(j)); end
    D(m) = real(factorial(m)*acc/(nc*h^m));
end
end

function [V,A,B,C] = dense_model(T,phi,ruv,bt)
id = (0:T-1)';
H  = phi.^abs(id-id')/(1-phi^2);
G  = zeros(T);
for i = 1:T
    for j = i+1:T, G(i,j) = phi^(j-i-1); end
end
V  = [eye(T) ruv*G; ruv*G' H];
M  = eye(T)-ones(T)/T;  Z = zeros(T);
A  = [Z M/2; M/2 bt*M];
B  = [Z Z; Z M];
C  = [M bt*M; bt*M bt^2*M];
end

function prn(out,varargin)
for o = out, fprintf(o,varargin{:}); end
end
