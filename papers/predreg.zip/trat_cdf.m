function F = trat_cdf(rvec,T,bt,phi,ruv,tol,engine)
%TRAT_CDF  Exact cdf of the OLS t-ratio of a predictive regression.
%
%   F = TRAT_CDF(rvec,T,bt,phi,ruv) returns P[t(betahat) < rvec(i)] for
%   the predictive regression with normalized slope
%   bt = (sigma_v/sigma_u)*beta, AR(1) coefficient phi (|phi| < 1) and
%   innovation correlation ruv.  tol is the absolute tolerance of the
%   triple quadrature (default 1e-4).
%
%   The outer r2 variable is centered and scaled by the first-order
%   mean m2 and standard deviation s2 of the R2 bound (r2 = m2+s2*y),
%   and the radial variable is scaled conjugately (R = v/s2); the
%   Jacobians cancel.  This keeps the effective integration ranges
%   O(1) for all T.
%
%   The optional argument engine ('fast' default | 'auto' | 'pivot')
%   selects the phase computation in R1R2_GH; see R1R2_GH.
%
%   See also TRAT_PDF, TRAT_CDF_EIG, R1R2_GH.

if nargin < 6, tol = 1e-4; end
if nargin < 7, engine = 'fast'; end
if ~isscalar(phi) || ~isreal(phi) || abs(phi) >= 1
    error('predreg:phi',['The predictor must be a stationary AR(1): ' ...
        '|phi| < 1 is required.  The unit-root case has no stationary ' ...
        'distribution for z_0 and is a different problem.']);
end
F = zeros(size(rvec));
rhpisq = 1/(2*pi^2);
[xu,m2,s2] = r2_upper(T,phi,bt,ruv);
ylo = -m2/s2; yhi = (xu-m2)/s2;
pref = sqrt(1-phi^2);
for i = 1:numel(rvec)
    c = rvec(i)/sqrt(T-2+rvec(i)^2);
    F(i) = 1/2-rhpisq*pref*integral3(@(y,th,v) ...
           r1r2_gh(v/s2,th,c*sqrt(m2+s2*y(1)),m2+s2*y(1),T,bt,phi,ruv, 1,'g',engine) ...
          +r1r2_gh(v/s2,th,c*sqrt(m2+s2*y(1)),m2+s2*y(1),T,bt,phi,ruv,-1,'g',engine), ...
           ylo,yhi,0,pi/2,0,Inf,'AbsTol',tol);
end
F = max(0,min(1,F));
end
