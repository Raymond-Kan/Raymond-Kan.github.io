function f = trat_pdf(rvec,T,bt,phi,ruv,tol,engine)
%TRAT_PDF  Exact density of the OLS t-ratio of a predictive regression.
%
%   f = TRAT_PDF(rvec,T,bt,phi,ruv) returns the exact finite-sample
%   density of t(betahat) at the points in rvec, for the predictive
%   regression with normalized slope bt = (sigma_v/sigma_u)*beta,
%   AR(1) coefficient phi, and innovation correlation ruv.  tol is the
%   absolute tolerance of the triple quadrature (default 1e-4).
%
%   Implements Proposition 1 with the O(1) integrand of Section 4.
%   Replaces tratc_pdf; adds the confluent-expansion switch, and is overflow-free for any T.  The quadrature variables
%   are centered and scaled by the closed-form mean and standard
%   deviation of the R2 bound (see R2_UPPER), which keeps the
%   effective integration ranges O(1) for all T.
%
%   The optional argument engine ('fast' default | 'auto' | 'pivot')
%   selects the phase computation in R1R2_GH; see R1R2_GH.
%
%   See also TRAT_CDF, TRAT_PDF_EIG, R1R2_GH.

if nargin < 6, tol = 1e-4; end
if nargin < 7, engine = 'fast'; end   % strict O(1) default; 'auto' adds pivot fallback
if ~isscalar(phi) || ~isreal(phi) || abs(phi) >= 1
    error('predreg:phi',['The predictor must be a stationary AR(1): ' ...
        '|phi| < 1 is required.  The unit-root case has no stationary ' ...
        'distribution for z_0 and is a different problem.']);
end
f = zeros(size(rvec));
rhpisq = 1/(2*pi^2);
[xu,m2,s2] = r2_upper(T,phi,bt,ruv);
ylo = -m2/s2; yhi = (xu-m2)/s2;
pref = sqrt(1-phi^2);
for i = 1:numel(rvec)
    c = rvec(i)/sqrt(T-2+rvec(i)^2);
    f(i) = (T-2)/(T-2+rvec(i)^2)^(3/2)*rhpisq*pref*integral3(@(y,th,v) ...
           (r1r2_gh(v/s2,th,c*sqrt(m2+s2*y(1)),m2+s2*y(1),T,bt,phi,ruv, 1,'h',engine) ...
           +r1r2_gh(v/s2,th,c*sqrt(m2+s2*y(1)),m2+s2*y(1),T,bt,phi,ruv,-1,'h',engine)).*sqrt(m2+s2*y(1)), ...
           ylo,yhi,0,pi/2,0,Inf,'AbsTol',tol);
end
f = max(0,f);
end
