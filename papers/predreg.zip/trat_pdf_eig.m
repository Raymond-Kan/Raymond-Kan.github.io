function f = trat_pdf_eig(rvec,T,bt,phi,ruv,tol)
%TRAT_PDF_EIG  Density of the t-ratio via the eigenvalue approach (benchmark).
%   Same inputs/outputs as TRAT_PDF.  O(T^3) per (r2,theta) node.
if nargin < 6, tol = 1e-4; end
f = zeros(size(rvec));
rhpisq = 1/(2*pi^2);
[A,B1,B2,D] = r1r2_eig_setup(T,bt,phi,ruv);
xu = r2_upper(T,phi,bt,ruv);
for i = 1:numel(rvec)
    c = rvec(i)/sqrt(T-2+rvec(i)^2);
    f(i) = (T-2)/(T-2+rvec(i)^2)^(3/2)*rhpisq* ...
           integral3(@(x,h,r) r1r2_h_eig(x,r,h,A,B1,B2,D,c).*sqrt(x(1)), ...
           0,xu,0,pi/2,0,Inf,'AbsTol',tol);
end
f = max(0,f);
end
