function m = tratmom(p,T,phi,ruv,bt,opt)
%TRATMOM  Exact moments of the OLS t-ratio of the predictive regression.
%
%   m = TRATMOM(p,T,phi,ruv,bt) returns m(j) = E[t(betahat)^j] for
%   j = 1..p, where bt = (sigma_v/sigma_u)*beta (bt = 0 under the null).
%   E[t^j] exists if and only if j < T-2.
%
%   Collect the three quadratic forms in the 2x2 Gram matrix
%       G = [U_B U_A; U_A U_C],   |G| = U_B U_C - U_A^2,
%   so that t = sqrt(nu) U_A/|G|^{1/2} with nu = T-2.  The determinant in
%   the denominator is linearised by the matrix-variate gamma integral
%   over the cone of 2x2 positive definite matrices,
%
%     |G|^{-j/2} = 1/Gamma_2(j/2) int_{S>0} etr(-SG) |S|^{(j-3)/2} dS,
%
%   Gamma_2(a) = sqrt(pi)Gamma(a)Gamma(a-1/2), and etr(-SG) is again a
%   Gaussian tilt: tr(SG) = s11 U_B + 2 s12 U_A + s22 U_C.  In Cholesky
%   coordinates S = LL', (l1,l2,l3), the weight becomes the smooth
%   monomial 4 l1^{j-1} l3^{j-2} and, for j >= 2,
%
%     E[t^j] = nu^{j/2} 4/Gamma_2(j/2) *
%              int int int l1^{j-1} l3^{j-2}
%                  [d^j Psi/dr^j](r0, l1^2, l2^2+l3^2) dl1 dl2 dl3,
%
%   with r0 = -2 l1 l2.  For j = 1 the weight l3^{-1} concentrates the
%   mass on rank-one S and the integral collapses to the two-dimensional
%   boundary of the cone:
%
%     E[t] = sqrt(nu)/(2 pi) int_0^{2pi} int_0^inf
%            [dPsi/dr](-v sin 2psi, v cos^2 psi, v sin^2 psi) dv dpsi.
%
%   All evaluation points are in the interior of the mgf domain, where
%   the matrices are positive definite: there is no branch issue.
%
%   opt fields (all optional): npsi (48), nv (64) for the boundary
%   integral; n1 (26), n2 (34), n3 (26) for the cone integral; engine,
%   which selects the mgf evaluator, 'fast' (default, O(1) per point)
%   or 'banded' (O(T) per point, retained as a check).

if nargin < 5 || isempty(bt), bt = 0; end
if nargin < 6, opt = struct; end
if ~isfield(opt,'npsi'), opt.npsi = 48; end
if ~isfield(opt,'nv'),   opt.nv   = 64; end
if ~isfield(opt,'n1'),   opt.n1   = 26; end
if ~isfield(opt,'n2'),   opt.n2   = 34; end
if ~isfield(opt,'n3'),   opt.n3   = 26; end
if ~isfield(opt,'engine'), opt.engine = 'fast'; end
if p >= T-2
    error('predreg:mom','E[t^p] exists only for p < T-2.');
end
par = qfmgf_setup(T,phi,ruv,bt,opt.engine);
nu  = T-2;
m   = zeros(1,p);

% ---- p = 1: rank-one boundary of the cone (2-D) -----------------------
% integrand is pi-periodic in psi (S is unchanged by xi -> -xi), so a
% midpoint rule on [0,pi) is spectrally accurate in psi; the weight 2pi/n
% accounts for the two half-turns of the full circle
psi  = pi*((1:opt.npsi)-0.5)/opt.npsi;
wpsi = (2*pi/opt.npsi)*ones(1,opt.npsi);
[q,wv] = gauss01(opt.nv);
cpsi = cos(psi).^2*par.cB + sin(2*psi)*par.cA + sin(psi).^2*par.cC;
cpsi = max(cpsi, 0.05*(par.cB+par.cC));
[Q,PS]  = ndgrid(q,psi);
[WQ,WP] = ndgrid(wv,wpsi);
CP  = repmat(cpsi,opt.nv,1);
V   = (Q./(1-Q))./CP;
JAC = 1./(CP.*(1-Q).^2);
sv  = V.*cos(PS).^2;  tv = V.*sin(PS).^2;  r0 = -V.*sin(2*PS);
[D,lp0] = qfmgf_dp(1, r0(:).', sv(:).', tv(:).', par);
w2  = (WQ(:).*WP(:)).'.*JAC(:).';
m(1) = sqrt(nu)/(2*pi)*real(sum(w2.*exp(lp0).*D(1,:)));
if p == 1, return; end

% ---- p >= 2: Cholesky coordinates on the cone (3-D) -------------------
[q1,w1] = gauss01(opt.n1);
l1v = (q1./(1-q1))/sqrt(par.cB);  j1 = w1./(sqrt(par.cB)*(1-q1).^2);
[x2,w2g] = gaussm11(opt.n2);
l2v = (x2./(1-x2.^2))/sqrt(par.cC);
j2  = w2g.*(1+x2.^2)./((1-x2.^2).^2*sqrt(par.cC));
[q3,w3] = gauss01(opt.n3);
l3v = (q3./(1-q3))/sqrt(par.cC);  j3 = w3./(sqrt(par.cC)*(1-q3).^2);

[L1,L2,L3] = ndgrid(l1v,l2v,l3v);
[J1,J2,J3] = ndgrid(j1,j2,j3);
L1 = L1(:).'; L2 = L2(:).'; L3 = L3(:).';
WW = (J1(:).*J2(:).*J3(:)).';
sv = L1.^2;  tv = L2.^2 + L3.^2;  r0 = -2*L1.*L2;
[D,lp0] = qfmgf_dp(p, r0, sv, tv, par, max(24,4*p));
for j = 2:p
    g2 = sqrt(pi)*gamma(j/2)*gamma((j-1)/2);
    m(j) = nu^(j/2)*4/g2 * ...
        real(sum(WW.*L1.^(j-1).*L3.^(j-2).*exp(lp0).*D(j,:)));
end
end

function [x,w] = gauss01(n)
j = 1:n-1; b = j./sqrt(4*j.^2-1);
[V,Dg] = eig(diag(b,1)+diag(b,-1));
[x,ix] = sort(diag(Dg).'); w = 2*V(1,ix).^2;
x = (x+1)/2; w = w/2;
end

function [x,w] = gaussm11(n)
j = 1:n-1; b = j./sqrt(4*j.^2-1);
[V,Dg] = eig(diag(b,1)+diag(b,-1));
[x,ix] = sort(diag(Dg).'); w = 2*V(1,ix).^2;
end
