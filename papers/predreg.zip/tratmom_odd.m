function m = tratmom_odd(p,T,phi,ruv,bt,opt)
%TRATMOM_ODD  A single odd moment of the t-ratio, by the 2-D representation.
%
%   m = TRATMOM_ODD(p,T,phi,ruv,bt) returns E[t(betahat)^p] for a single
%   odd p, computed from the two-dimensional representation of the paper
%   (Section 5.5) rather than the three-dimensional cone integral that
%   TRATMOM uses.  For a single odd moment in isolation this route needs
%   about a quarter of the integrand evaluations; when several moments are
%   wanted, use TRATMOM, whose one sweep delivers every order at once.
%
%   The integrand is an s-derivative of the mgf, supplied by the
%   Taylor-mode evaluator QFMGF_DJS at O(1) cost per node.  Two features
%   of the quadrature matter.  The inner (theta) integrand is a Gaussian
%   ridge whose width grows like 1/sqrt(lambda), so the theta scale is
%   set per lambda node as sqrt(1/(2*lambda*cB) + cC/cB); a fixed scale
%   fails badly at small lambda.  And all the terms of the sum share one
%   set of nodes, so the jets are computed once.
%
%   opt.nl and opt.nth override the node counts (defaults 64 and 96).
%
%   See also TRATMOM, QFMGF_DJS.

if nargin < 6, opt = struct(); end
if ~isfield(opt,'nl'),  opt.nl  = 64; end
if ~isfield(opt,'nth'), opt.nth = 96; end
if mod(p,2) ~= 1
    error('predreg:oddp','p must be odd; use TRATMOM for even moments.');
end
if p >= T-2
    error('predreg:pmax','E[t^p] exists only for p < T-2.');
end
if p == 1
    mm = tratmom(1,T,phi,ruv,bt); m = mm(1); return
end

par = qfmgf_setup(T,phi,ruv,bt,'fast');
nu  = T-2;  K = (p+1)/2;

[ql,wl] = g01(opt.nl);
lam = (ql./(1-ql))/par.cC;  jl = wl./(par.cC*(1-ql).^2);
[xt,wt] = gm11(opt.nth);

% node grid: theta scale adapted to each lambda
LAM = zeros(1,opt.nl*opt.nth); TH = LAM; W = LAM;
for a = 1:opt.nl
    sq = sqrt(1/(2*lam(a)*par.cB)+par.cC/par.cB);
    th = sq*xt./(1-xt.^2);
    jt = wt.*sq.*(1+xt.^2)./((1-xt.^2).^2);
    ix = (a-1)*opt.nth+(1:opt.nth);
    LAM(ix) = lam(a);  TH(ix) = th;  W(ix) = jl(a)*jt;
end

rv = 2*LAM.*TH;  sv = LAM.*TH.^2;  tv = LAM;
[D,lp0] = qfmgf_djs(K,rv,sv,tv,par);

acc = 0;
for i = 0:(p-1)/2
    mi   = K-i;
    coef = factorial(p)/(factorial(i)*factorial(p-2*i)*4^i);
    acc  = acc + coef*sum(W.*LAM.^((p-1)/2-i).*TH.^(p-2*i) ...
                          .*exp(lp0).*D(mi,:));
end
m = real(((-1)^K)*nu^(p/2)/(sqrt(pi)*gamma(p/2))*acc);
end

% -------------------------------------------------------------------------
function [x,w] = g01(n)
j = 1:n-1; b = j./sqrt(4*j.^2-1);
[V,Dg] = eig(diag(b,1)+diag(b,-1));
[x,ix] = sort(diag(Dg).'); w = 2*V(1,ix).^2;
x = (x+1)/2; w = w/2;
end

function [x,w] = gm11(n)
j = 1:n-1; b = j./sqrt(4*j.^2-1);
[V,Dg] = eig(diag(b,1)+diag(b,-1));
[x,ix] = sort(diag(Dg).'); w = 2*V(1,ix).^2;
end
