function F = ttprims(p,q,m,order,thr,p2q)
%TTPRIMS  Stable primitives of a symmetric tridiagonal Toeplitz matrix.
%
%   F = TTPRIMS(p,q,m,order) computes, for the m x m complex symmetric
%   tridiagonal Toeplitz matrix D with diagonal p and off-diagonal q,
%   the bilinear forms of D^{-1} (order>=1), D^{-2} (order>=2), and
%   D^{-3} (order=3) in the vectors 1_m, e_1, e_m, together with a
%   continuous log-modulus/phase representation of 1/|D|.
%
%   Inputs p and q may be arrays of the same size (vectorized); m and
%   order are scalars.  The optional sixth argument supplies p+2q; see
%   the note on conditioning below.  Output F is a struct of arrays:
%
%     F.d1  = 1'D^{-1}1     F.d2  = e1'D^{-1}1    F.d3 = e1'D^{-1}e1
%     F.d4  = e1'D^{-1}em   F.tr1 = trace(D^{-1})               (order>=2)
%     F.d1t, F.d2t, F.d3t, F.d4t : same forms in D^{-2}         (order>=2)
%     F.tr2 = trace(D^{-2})                                     (order>=3)
%     F.d1s, F.d2s, F.d3s, F.d4s : same forms in D^{-3}         (order>=3)
%     F.logabs_invD = log(1/|D|)   (real)
%     F.arg_invD    = continuous phase of 1/|D|
%
%   Numerical design (see paper, Section 3).  Everything reduces to two
%   Chebyshev values.  With x = p/(2q) and U the Chebyshev polynomial
%   of the second kind,
%
%       |D| = q^m U_m(x),     d3 = U_{m-1}/(q U_m),
%       d4  = (-1)^{m+1}/(q U_m),
%       d2  = Q/(2q U_m),     d1 = S/(2q U_m),
%
%   where U_m + U_{m-1} + (-1)^{m+1} = (x+1)Q and m U_m + Q = (x+1)S,
%   both identities holding as polynomials, so nothing here is singular
%   anywhere: U_m is entire, of modulus of order m near the confluent
%   point x = -1, and the factors x+1 that Lemma 2 carries in its
%   denominators cancel identically against the numerators.  The
%   higher-order primitives are p-derivatives of the first-order ones
%   (D^{-2} = -dD^{-1}/dp, 2D^{-3} = d^2 D^{-1}/dp^2), hence rational
%   in the same two values and their x-derivatives.
%
%   Two regimes, split at tau = |x+1| n^2 = 2.5 with n = m+1, differing
%   only in how the Chebyshev values are evaluated:
%
%   1. tau >= 2.5 (generic): the closed forms in the characteristic
%      roots r+- = (p +- sqrt(p^2-4q^2))/2, evaluated after dividing
%      D by |r+|, which divides both roots by |r+| and so leaves
%      every power bounded by one in modulus
%      (overflow-free for any m), with the phase of 1/|D| assembled
%      continuously as arg(h) - arg(1-(r-/r+)^n) - n*arg(r+).
%
%   Conditioning of the argument.  Everything below is controlled by
%   delta = (p+2q)/(2q), and on the band p is close to -2q, so forming
%   p+2q by subtraction delivers it with absolute error eps whatever is
%   done afterwards: tau = n^2*delta is then known only to eps*n^2 and
%   every primitive inherits a relative error of about eps*n^2/5.  This
%   is a property of the argument, not of the evaluation -- all three
%   implementations agree to that accuracy -- and a caller that can form
%   p+2q in closed form removes it by passing it as the sixth argument.
%
%   2. tau < 2.5 (confluent): the Taylor expansions of U_m and U_{m-1}
%      at x = -1, whose coefficients are explicit,
%
%          U_m^{(k)}(-1)/k! = (-1)^{m+k} f_k,   f_0 = m+1,
%          f_{k+1}/f_k = (m-k)(m+k+2)/((2k+3)(k+1)),
%
%      carried in the variable tau = n^2(x+1) so that no coefficient
%      overflows at any m, with Q and S obtained by shifting the
%      coefficient index (no cancellation), and the x-derivatives read
%      off the same coefficient array.  Twenty terms reach machine
%      precision: the expanded functions are entire, and the ratio of
%      successive terms is at most |tau|/((2k+3)(k+1)), which is why a
%      short series covers the whole band although the primitives
%      themselves have poles (at the zeros of U_m, the nearest at
%      tau = 2n^2 sin^2(pi/(2n)) ~ 4.93) that would stall a direct
%      expansion of the primitives.  The phase of 1/|D| is
%      -(m arg(-q) + arg W) with W = U_m(x)/((-1)^m (m+1)); the product
%      of W over the zeros of U_m gives |arg W| < 1.1 < pi on the whole
%      band, so the principal argument is provably the continuous one.

if nargin < 4, order = 1; end
if nargin < 5 || isempty(thr), thr = 2.5; end   % exposed for testing
n  = m+1;
sz = size(p);
p = p(:).'; q = q(:).';
N = numel(p);
% p+2q is a difference of nearly equal quantities on the confluent band,
% so a caller able to form it without cancellation should pass it: the
% relative accuracy of every primitive is that of this one argument.
if nargin < 6 || isempty(p2q)
    p2q = p+2*q;
else
    p2q = p2q(:).';
    if isscalar(p2q) && N > 1, p2q = repmat(p2q,1,N); end
    p = p2q-2*q;      % so that every primitive returned is the exact
end                   % primitive of one and the same matrix

d1 = zeros(1,N); d2 = d1; d3 = d1; d4 = d1;
logabs_invD = zeros(1,N); arg_invD = zeros(1,N);
if order >= 2, tr1 = d1; d1t = d1; d2t = d1; d3t = d1; d4t = d1; end
if order >= 3, tr2 = d1; d1s = d1; d2s = d1; d3s = d1; d4s = d1; end

xd  = p2q./(2*q);
tau = abs(xd)*n^2;
iEx = tau >= thr;          % generic closed forms
iCh = ~iEx;                % Chebyshev expansion at the confluent point

% ======================= generic closed forms ============================
if any(iEx)
    pp = p(iEx); qq = q(iEx);
    h2 = (p2q(iEx)-4*qq).*p2q(iEx);      % = pp^2-4qq^2, without cancelling
    h  = sqrt(h2);
    r1 = (pp+h)/2;
    r2 = (pp-h)/2;
    sw = abs(r2) > abs(r1);                 % safeguard (never observed
    if any(sw)                              % to trigger along our paths)
        tmp = r1(sw); r1(sw) = r2(sw); r2(sw) = tmp;
        h(sw) = -h(sw);
    end
    sc  = abs(r1);
    ps  = pp./sc;  qs = qq./sc;  hs = h./sc;
    r1s = r1./sc;  r2s = r2./sc;
    q0  = p2q(iEx)./sc;
    r1n = r1s.^n;  r2n = r2s.^n;
    q1  = r1n-r2n;
    q2  = r1n+r2n;
    q3  = r1s.^(n-1)-r2s.^(n-1);
    D3  = q3./q1;
    D4  = (-qs).^(n-2).*hs./q1;
    D2v = (1+qs.*(D3+D4))./q0;
    D1v = ((n-1)+2*qs.*D2v)./q0;
    d1(iEx) = D1v./sc;  d2(iEx) = D2v./sc;
    d3(iEx) = D3./sc;   d4(iEx) = D4./sc;
    if order >= 2
        T1  = ((n-1)*q2./q1-2*qs.^2.*D3./hs)./hs;
        D3t = D3.*q2./(q1.*hs)-2*(n-1)*(qs.^2).^(n-1)./q1.^2;
        D4t = -(-qs).^(n-2).*(2*qs.^2.*q3./hs-(n-1)*q2)./q1.^2;
        D2t = (D2v+qs.*(D3t+D4t))./q0;
        D1t = (D1v+2*qs.*D2t)./q0;
        tr1(iEx) = T1./sc;
        d1t(iEx) = D1t./sc.^2; d2t(iEx) = D2t./sc.^2;
        d3t(iEx) = D3t./sc.^2; d4t(iEx) = D4t./sc.^2;
    end
    if order >= 3
        T2  = 4*n^2*(qs.^2).^n./(hs.^2.*q1.^2) ...
            + (n-1)*ps.*q2./(hs.^3.*q1) ...
            - 6*qs.^2./hs.^4 ...
            - 2*qs.^4.*(r1s.^(n-2)-r2s.^(n-2))./(hs.^4.*q1);
        D3s = ((r1s.^(2*n)-r2s.^(2*n)-n*(qs.^2).^(n-1).*(r1s.^2-r2s.^2))./hs ...
            + 2*n*(qs.^2).^(n-1).*(2*qs.^2.*q3-(n-1)*hs.*q2)./q1) ...
            ./(hs.^2.*q1.^2);
        D4s = -2*n*(-qs).^n./(hs.^2.*q1.^3).* ...
              (r1s.^(2*n-1)-r2s.^(2*n-1)-(2*n-1)*(qs.^2).^(n-1).*hs) ...
            - (-qs).^(n-2)./(2*hs.^2.*q1.^2).* ...
              (2*qs.^2.*ps.*q3./hs-(n-1)^2*hs.*q1-(n-1)*ps.*q2);
        D2s = (D2t+qs.*(D3s+D4s))./q0;
        D1s = (D1t+2*qs.*D2s)./q0;
        tr2(iEx) = T2./sc.^2;
        d1s(iEx) = D1s./sc.^3; d2s(iEx) = D2s./sc.^3;
        d3s(iEx) = D3s./sc.^3; d4s(iEx) = D4s./sc.^3;
    end
    zr = r2s./r1s;
    logabs_invD(iEx) = log(abs(hs))-log(abs(1-zr.^n))-(n-1)*log(sc);
    arg_invD(iEx)    = angle(hs)-angle(1-zr.^n)-n*angle(r1s);
end

% ============= Chebyshev expansion at the confluent point ================
if any(iCh)
    qq = q(iCh);
    nn = n^2;
    tv = xd(iCh)*nn;                  % tau (complex), |tv| < 2.5
    % Twenty terms reach machine precision, and for m <= 20 the series
    % terminates at k = m and is exact.  Two spare coefficients are
    % carried because the passage to Q and S below is an index shift:
    % without them S would be truncated one degree short of its own,
    % which is harmless once the terms are decaying but is a real error
    % at small m, where the polynomial genuinely ends where it ends.
    L  = min(m,20);
    LL = L+2;

    % coefficients of U_m and U_{m-1} at x = -1, scaled by n^(-2k) so
    % that the series is in tv and no coefficient overflows at any m
    gA = zeros(1,LL+1);  gA(1) = (-1)^m*(m+1);
    for i = 0:LL-1
        gA(i+2) = -gA(i+1)*((m-i)*(m+i+2)/nn)/((2*i+3)*(i+1));
    end
    gB = zeros(1,LL+1);  gB(1) = (-1)^(m-1)*m;
    for i = 0:LL-1
        gB(i+2) = -gB(i+1)*((m-1-i)*(m+i+1)/nn)/((2*i+3)*(i+1));
    end
    % U_m + U_{m-1} + (-1)^{m+1} = (x+1) Q  and  m U_m + Q = (x+1) S:
    % the constant coefficients cancel exactly, so Q and S are index
    % shifts (the factor nn converts d/d(delta) series to d/d(tv) ones)
    gQ = nn*(gA(2:end)+gB(2:end));
    gR = m*gA(1:LL)+gQ;
    gS = nn*gR(2:end);

    % values and first two tv-derivatives, by Horner
    [A0,A1,A2] = hn3(gA,tv);
    [B0,B1,B2] = hn3(gB,tv);
    [Q0,Q1,Q2] = hn3(gQ,tv);
    [S0,S1,S2] = hn3(gS,tv);

    sg  = (-1)^(m+1);
    qA  = qq.*A0;
    d3(iCh) = B0./qA;
    d4(iCh) = sg./qA;
    d2(iCh) = Q0./(2*qA);
    d1(iCh) = S0./(2*qA);
    if order >= 2
        % v'D^{-2}v = -d(v'D^{-1}v)/dp = -(1/2q) d/dx = -(nn/2q) d/d(tv)
        A0sq = A0.^2;  q2 = qq.^2;
        tr1(iCh) = nn*A1./(2*qA);
        d3t(iCh) = nn*(B0.*A1-B1.*A0)./(2*q2.*A0sq);
        d4t(iCh) = sg*nn*A1./(2*q2.*A0sq);
        d2t(iCh) = nn*(Q0.*A1-Q1.*A0)./(4*q2.*A0sq);
        d1t(iCh) = nn*(S0.*A1-S1.*A0)./(4*q2.*A0sq);
    end
    if order >= 3
        % v'D^{-3}v = (1/2) d^2(v'D^{-1}v)/dp^2 = (nn^2/(8q^2)) d^2/d(tv)^2
        q3 = qq.^3;  A0cu = A0.^3;  n4 = nn^2;
        tr2(iCh) = n4*(A1.^2-A2.*A0)./(4*q2.*A0sq);
        d3s(iCh) = n4*(B2.*A0sq-2*B1.*A1.*A0+2*B0.*A1.^2-B0.*A2.*A0)./(8*q3.*A0cu);
        d4s(iCh) = sg*n4*(2*A1.^2-A2.*A0)./(8*q3.*A0cu);
        d2s(iCh) = n4*(Q2.*A0sq-2*Q1.*A1.*A0+2*Q0.*A1.^2-Q0.*A2.*A0)./(16*q3.*A0cu);
        d1s(iCh) = n4*(S2.*A0sq-2*S1.*A1.*A0+2*S0.*A1.^2-S0.*A2.*A0)./(16*q3.*A0cu);
    end
    % 1/|D|: |D| = q^m U_m = (-q)^m n W, W = A0/((-1)^m n), and
    % |arg W| < 1.1 on the band, so the principal argument is continuous
    W = A0*((-1)^m/n);
    logabs_invD(iCh) = -(m*log(abs(qq))+log(n)+log(abs(W)));
    arg_invD(iCh)    = -(m*angle(-qq)+angle(W));
end

F.d1 = reshape(d1,sz); F.d2 = reshape(d2,sz);
F.d3 = reshape(d3,sz); F.d4 = reshape(d4,sz);
if order >= 2
    F.tr1 = reshape(tr1,sz);
    F.d1t = reshape(d1t,sz); F.d2t = reshape(d2t,sz);
    F.d3t = reshape(d3t,sz); F.d4t = reshape(d4t,sz);
end
if order >= 3
    F.tr2 = reshape(tr2,sz);
    F.d1s = reshape(d1s,sz); F.d2s = reshape(d2s,sz);
    F.d3s = reshape(d3s,sz); F.d4s = reshape(d4s,sz);
end
F.logabs_invD = reshape(logabs_invD,sz);
F.arg_invD    = reshape(arg_invD,sz);
end

% =========================================================================
function [f0,f1,f2] = hn3(g,z)
%HN3  Value and first two derivatives of sum_k g(k+1) z^k, by Horner.
f0 = zeros(size(z)); f1 = f0; f2 = f0;
for k = numel(g):-1:1
    f2 = f2.*z + f1;
    f1 = f1.*z + f0;
    f0 = f0.*z + g(k);
end
f2 = 2*f2;
end
