%
%  This function computes the number of terms in the univariate*multivariate moment expansion
%
function y = ncount(nu)
nuz = nu==0;
nu(nuz) = [];
m = length(nu);
if m==0
   y = int64(1);
   return
end
if m==1
   y = int64(2*(nu-1));
   return
end
if m==2
   y = int64(min(nu)+2*sum(nu)-3);
   return
end
%
%  Regular case
%
nu = sort(nu,2,'descend');
s2 = nu(2:m);
ss2 = sum(s2);
y = int64(prod(1+s2));
if nu(1)<ss2
%
%   F(i,j) is a matrix of the number of elements of nu's such 
%   that 0<=|nu|<=i and nu<=s2(1:j)
%
   M = ss2-nu(1);
   F = ones(M,m-1);
   if s2(1)<M
      F(2:s2(1),1) = 2:s2(1);
      F(s2(1)+1:M,1) = s2(1)+1;
   else
      F(2:M,1) = 2:M;
   end
   for j=2:m-1
       for i=1:min(s2(j),M-1)
           F(i+1,j) = F(i+1,j-1)+F(i,j);
       end
       for i=s2(j)+1:M-1
           F(i+1,j) = F(i+1,j-1)+F(i,j)-F(i-s2(j),j-1);
       end
   end
   y = y-F(end);
end
y = y+ncount_rec(s2)+2*(nu(1)-1);
