%
%  This function computes the number of terms in the univariate moment expansion
%  for the noncentral multivariate normal case.
%
function y = ncount2(nu)
persistent M cind 
m1 = 0;
nuz = nu==0;
nu(nuz) = [];
m = length(nu);
if m<=1
   y = int64(1);
   return
end
if m==2    
   y = int64(min(nu)+1);
   return
end
nu = sort(nu,2,'descend');
s2 = nu(2:end);
ss2 = sum(s2);
if ss2<nu(1)
   nu(1) = ss2;    % When ss2<s1, then f(s1,s2) = f(ss2,s2)
end
s1 = nu(1);
if nu(1)==1
   h0 = 1;
   h1 = 1;
   for i=2:m
       y = h1+(i-1)*h0;
       h0 = h1;
       h1 = y;
   end
   y = int64(y);
   return
end
if m==3  
%   y = (3+3*nu(2)-nu(3))*(2+3*nu(3)+nu(3)^2)/6;
%   d = nu(2)+nu(3)-nu(1);
%   if d>0
%      if rem(d,2)==0
%         y = y-(2*d+5)*(d+2)*d/24;
%      else
%         y = y-(2*d+1)*(d+3)*(d+1)/24;
%      end
%   end
   d = max(0,nu(2)+nu(3)-nu(1));
   y = (3+3*nu(2)-nu(3))*(2+3*nu(3)+nu(3)^2)/6-ceil(d*(d+2)*(2*d+5)/24);
   y = int64(y);
   return
end
if nu(m)==1
   x1 = nu(1:m-1);
   y = ncount2(x1);
   E = eye(m-1);
   for i=1:m-1
       y = y+ncount2(x1-E(i,:));
   end
   y = int64(y);
   return
end
%
%  Some special cases
%
if s1==ss2
   y = ncount2([ss2-1 s2])+1;
   return
end
if s1==ss2-1
   y = ncount2([ss2-2 s2])+m-1;
   return
end
%
%   Regular case: going through kappa for kappa<=s2
%
s2a = s2;
s2a(1) = min(s2a(1),ss2-s2a(1));   % reduce the storage space if s2(1)>s2(2)+...+s2(m-1)
pnu = prod(s2a+1);
if pnu>length(M)    % create M and cind as persistent variables, so M does not need to be computed from scratch
   cind = cumprod([1 s2a(1:m-2)+1]);
   M = NaN(pnu,1);
   M(1) = 1;
   m1 = m;
end
sx = ss2;   % sx = |s2|-|kappa|, which is updated
y = 0;
if sx<=s1
   y = 1;
end
x = zeros(1,m-1);  % this is kappa
for i=2:prod(s2+1)
    for j=1:m-1
        if x(j)<s2(j)
           x(j) = x(j)+1;
           x1 = sort(x(x~=0),2,'descend');
           x1(1) = min(x1(1),sum(x1(2:end)));
           xind = sum(x1.*cind(1:length(x1)))+1;
           sx = sx-1;
           if isnan(M(xind))    % Updating is required
              if length(x1)==2
                 M(xind) = x1(2)+1;
              elseif length(x1)==3
                 M(xind) = (3+3*x1(2)-x1(3))*(2+3*x1(3)+x1(3)^2)/6;
                 d = x1(2)+x1(3)-x1(1);
                 if d>0
                    M(xind) = M(xind)-ceil((2*d+5)*(d+2)*d/24);
                 end
              else
                 M(xind) = ncount2(x1);
              end
           end
           if sx<=s1   % Only sum up those with |s2|>=|kappa|>=|s2|-s1
              y = y+M(xind);
           end
           break
        else
           x(j) = 0;
           sx = sx+s2(j);
        end
    end
end
y = int64(y);
if m1==m
   clear M cind
end
