%
%  This function computes the number of terms in the
%  general decomposition formula
%
function y = ncount_d(nu,m)
   n = length(nu);
   sc = nu(1:m);
   sd = nu(m+1:n);
   m1 = m*(n-m);
   x = zeros(1,m1);
   mx = zeros(m1,2);  % mx tells us the two index of the l_{ij} subscripts
   for i=1:m
       ind = (i-1)*(n-m)+1:i*(n-m);
       mx(ind,1) = i;
       mx(ind,2) = 1:n-m;   % the second subscript is reduced by m
   end
   y = int64(1)+ncount_rec(sc)+ncount_rec(sd);
   cond = true;
   sx = 0;
   while cond
      for j=1:m1
          i1 = mx(j,1);
          i2 = mx(j,2);
%  When l_{i1,i2} is increased by 1, sc(i1) and sd(i2) are reduced by 1,       
          if sc(i1)>0&&sd(i2)>0
             x(j) = x(j)+1;
             sx = sx+1;
             sc(i1) = sc(i1)-1;
             sd(i2) = sd(i2)-1;
             y = y+1;
             break
          elseif x(j)>0
             sc(i1) = sc(i1)+x(j);
             sd(i2) = sd(i2)+x(j);
             sx = sx-x(j);
             x(j) = 0;
          end   
      end
      cond = sx>0;
  end
