%
%  This function computes the number of terms in Kan (2008) formula
%
function y = ncount_kan(nu)
s = floor(sum(nu)/2)+1;
y = int64(floor(prod(nu+1)/2)*s);
