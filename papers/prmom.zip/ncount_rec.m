%
%  This function computes the number of terms in Willink (2005) recursive formula
%
function y = ncount_rec(nu)
y = int64(2*sum(nu-1));
for i=2:length(nu)
    l = prod(nchoosek(nu,i),2);
    y = y+(i+1)*sum(l);
end
