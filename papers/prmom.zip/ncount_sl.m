%
%  This function computes the number of terms in Song and Lee (2015) expansion
%
function y = ncount_sl(nu)
persistent M cind 
m1 = 0;
nuz = nu==0;
nu(nuz) = [];
m = length(nu);
if m==0
   y = int64(1);
   return
end
if m==1
   y = floor(nu/2)+1;
   return
end
nu = sort(nu,2,'descend');
if m==2    
   y = (4+3*nu(1)-nu(2))*(nu(2)+1)*(nu(2)+3)/24;
   if rem(nu(2),2)==0
      if rem(nu(1),2)==0
         y = y+(nu(1)+nu(2)+4)/8;
      else
         y = y+(nu(1)-nu(2))/8;
      end
   end
   y = int64(y);
   return
end
s2 = nu(2:end);
ss2 = sum(s2);
s1 = nu(1);
if nu(1)==1
   h0 = 1;
   h1 = 1;
   for i=2:m
       y = h1+(i-1)*h0;
       h0 = h1;
       h1 = y;
   end
   y = int64(y);
   return
end
%
%   Regular case: going through kappa for kappa<=s2
%
pnu = prod(s2+1);
if pnu>length(M)    % create M and cind as persistent variables, so M does not need to be computed from scratch
   cind = cumprod([1 s2(1:m-2)+1]);
   M = NaN(pnu,1);
   M(1) = 1;
   m1 = m;
end
sx = ss2;   % sx = |s2|-|kappa|, which is updated
y = 0;
if ss2<=s1
   y = floor((s1-sx)/2)+1;
end
x = zeros(1,m-1);  % this is kappa
for i=2:prod(s2+1)
    for j=1:m-1
        if x(j)<s2(j)
           x(j) = x(j)+1;
           x1 = sort(x(x~=0),2,'descend');
           xind = sum(x1.*cind(1:length(x1)))+1;
           sx = sx-1;
           if isnan(M(xind))    % Updating is required
              if length(x1)==1
                 M(xind) = floor(x1/2)+1;
              elseif length(x1)==2
                 y1 = (4+3*x1(1)-x1(2))*(x1(2)+1)*(x1(2)+3)/24;
                 if rem(x1(2),2)==0
                    if rem(x1(1),2)==0
                       y1 = y1+(x1(1)+x1(2)+4)/8;
                    else
                       y1 = y1+(x1(1)-x1(2))/8;
                    end
                 end
                 M(xind) = y1;
              else
                 M(xind) = ncount_sl(x1);
              end
           end
           if sx<=s1   % Only sum up those with s2>=|kappa|>=|s2|-s1
              y = y+M(xind)*(floor((s1-sx)/2)+1);
           end
           break
        else
           x(j) = 0;
           sx = sx+s2(j);
        end
    end
end
y = int64(y);
if m1==m
   clear M cind
end
