%
%  This function computes the number of terms in the univariate moment expansion
%
function y = ncount_u(nu)
m = length(nu);
y = ncount2(nu)+2*(sum(nu)-m);
