%
%  This function computes the number of terms in the univariate*multivariate 
%  moment expansion for the central multivariate normal case
%
function y = ncountc(nu)
nuz = nu==0;
if any(nuz)
   nu(nuz) = [];
end
n = length(nu);
s = sum(nu);
if s==0
   y = int64(1);
   return
end
if rem(s,2)==1
   y = int64(0);
   return
end
if n==1
   y = int64(1);
   return
end
%
%  Regular case
%
s1 = nu(1);
s2 = nu(2:end);
ss2 = sum(s2);
pnu = prod(s2+1);
y = ncountc_rec(s1)+ncountc_rec(s2);
sx = ss2;          % sx = |s_2|-|kappa|, which is updated, note that sx is not |kappa|
if sx<=s1
   y = y+1;
end
x = zeros(1,n-1);  % this is kappa, power of X_2 to X_n
sodd = rem(ss2,2);
j1 = 1;
for i=2:pnu
    for j=1:n-1
% j tells us the position of the first nonzero element of x
% j1 tells us the position of the last nonzero element of x
        if x(j)<s2(j)
           x(j) = x(j)+1;
           sx = sx-1;
% Only need to deal with the case that |\kappa| is even
           if rem(sx,2)==sodd
              if sx<=s1
                 y = y+1;
              end
           end
           break
        else
           x(j) = 0;
           sx = sx+s2(j);
        end
    end
end
