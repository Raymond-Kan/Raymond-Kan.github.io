%
%  This function computes the number of terms in the
%  general decomposition formula for the central
%  multivariate normal case
%
function y = ncountc_d(nu,m)
n = length(nu);
sa = nu(1:m);
sb = nu(m+1:n);
m1 = m*(n-m);
x = zeros(1,m1);
mx = zeros(m1,2);  % mx tells us the two index of the l_{ij} subscripts
for i=1:m
    ind = (i-1)*(n-m)+1:i*(n-m);
    mx(ind,1) = i;
    mx(ind,2) = 1:n-m;   % the second subscript is reduced by m
end
y = ncountc_rec(sa)+ncountc_rec(sb)+1;
cond = true;
sx = 0;
ssa = sum(sa);
while cond
   for j=1:m1
       i1 = mx(j,1);
       i2 = mx(j,2);
%  When l_{i1,i2} is increased by 1, sa(i1) and sb(i2) will be reduced by 1,       
       if sa(i1)>0&&sb(i2)>0
          x(j) = x(j)+1;
          sx = sx+1;
          sa(i1) = sa(i1)-1;
          sb(i2) = sb(i2)-1;
          ssa = ssa-1;
          if rem(ssa,2)==0
             y = y+1;
          end
          break
       elseif x(j)>0
          sa(i1) = sa(i1)+x(j);
          sb(i2) = sb(i2)+x(j);
          ssa = ssa+x(j);
          sx = sx-x(j);
          x(j) = 0;
       end   
   end
   cond = sx>0;
end
