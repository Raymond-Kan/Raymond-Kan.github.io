%
%  This function computes the number of terms in Kan (2008) formula
%  for the central normal case.
%
function y = ncountc_kan(nu)
y = int64(floor(prod(nu+1)/2));
