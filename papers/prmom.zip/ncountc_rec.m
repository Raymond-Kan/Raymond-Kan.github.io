%
%  This function computes the number of terms in Willink (2005) recursive formula
%  for the central multivariate normal case
%
function y = ncountc_rec(nu)
nuz = nu==0;
if any(nuz)
   nu(nuz) = [];
end
m = length(nu);
s = sum(nu);
if s==0
   y = int64(1);
   return
end
if rem(s,2)==1
   y = int64(0);
   return
end
[nu,inu] = sort(nu,2,'descend');
pnu = prod(nu+1);
y = int64(1);
x = zeros(1,m);
sx = 0;
for i=2:pnu
    for j=1:m
        if x(j)<nu(j)
           x(j) = x(j)+1;
           sx = sx+1;
           if rem(sx,2)==0
              y = y+sum(x~=0);
           end   
           break
        else
           x(j) = 0;
           sx = sx-nu(j);
        end
    end
end

