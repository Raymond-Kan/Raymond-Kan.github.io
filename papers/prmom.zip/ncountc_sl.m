%
%  This function computes the number of terms in Song and Lee (2015) 
%  expansion for the central normal case.
%
function y = ncountc_sl(nu)
persistent M cind
m1 = 0;
s = sum(nu);
if rem(s,2)==1
   y = int64(0);
   return
end
nuz = nu==0;
nu(nuz) = [];
m = length(nu);
if m<=1
   y = int64(1);
   return
end
if m==2
   y = int64(floor(min(nu)/2)+1);
   return
end
nu = sort(nu,2,'descend');
if nu(1)==1
   y = int64(prod([1:2:s]));
   return
end
s1 = nu(1);
s2 = nu(2:end);
ss2 = sum(s2);
if ss2<nu(1)
   s1 = ss2;    % When ss2<nu1, then f(nu1,s2) = f(ss2,s2)
end
if m==3
   s2 = nu(2);
   s3 = nu(3);
   y = (3*(s3+1)*(s3+3)*(2*s2-s3+1)+(s1-s2+1)*(s1^2+s2^2+s2*(7+3*s3)-  ...
       s1*(7+2*s2+3*s3)+3*(5+s3*(5+s3))))/48;
   if rem(s3,2)==0
      if rem(s2,2)==0
         y = y+(4+s2+s3)/8;
      else
         y = y+(s2-s3)/8;
      end
   end
   y = int64(y);
   return
end
%
%   Regular case: going through kappa for kappa<=s2
%
s2a = s2;
s2a(1) = min(s2a(1),ss2-s2a(1));   % reduce the storage space if s2(1)>s2(2)+...+s2(m-1)
pnu = prod(s2a+1);
if pnu>length(M)    % create M and cind as persistent variables, so M does not need to be computed from scratch
   cind = cumprod([1 s2a(1:m-2)+1]);
   M = zeros(pnu,1);
   M(1) = 1;
   m1 = m;
end
sx = ss2;   % sx = |s2|-|kappa|, which is updated
y = 0;
if sx<=s1
   y = 1;
end
x = zeros(1,m-1);  % this is kappa
for i=2:prod(s2+1)
    for j=1:m-1
        if x(j)<s2(j)
           x(j) = x(j)+1;
           sx = sx-1;
           if rem(ss2-sx,2)==0    % |kappa| is even
              x1 = sort(x(x~=0),2,'descend');
              x1(1) = min(x1(1),sum(x1(2:end)));
              xind = sum(x1.*cind(1:length(x1)))+1;
              if M(xind)==0    % Updating is required
                 if length(x1)==2
                    M(xind) = floor(x1(2)/2)+1;
                 elseif length(x1)==3   
                    nu1 = x1(1);
                    nu2 = x1(2);
                    nu3 = x1(3);
                    M(xind) = (3*(nu3+1)*(nu3+3)*(2*nu2-nu3+1)+(nu1-nu2+1)*(nu1^2+nu2^2+nu2*(7+3*nu3)-  ...
                              nu1*(7+2*nu2+3*nu3)+3*(5+nu3*(5+nu3))))/48;
                    if rem(nu3,2)==0
                       if rem(nu2,2)==0
                          M(xind) = M(xind)+(4+nu2+nu3)/8;
                       else
                          M(xind) = M(xind)+(nu2-nu3)/8;
                       end
                    end
                 else
                    M(xind) = ncountc_sl(x1);
                 end
              end
              if sx<=s1   % Only sum up those with |s2|>=|kappa|>=|s2|-s1
                 y = y+M(xind);
              end
           end
           break
        else
           x(j) = 0;
           sx = sx+s2(j);
        end
    end
end
y = int64(y);
if m1==m
   clear M cind
end
