%
%  This function computes the number of terms in the univariate moment expansion
%  for the central multivariate normal case
%
function y = ncountc_u(nu)
nuz = nu==0;
if any(nuz)
   nu(nuz) = [];
end
m = length(nu);
s = sum(nu);
if s==0
   y = int64(1);
   return
end
if rem(s,2)==1
   y = int64(0);
   return
end
if m==1
   y = int64(1);
   return
end
%
%  Regular case
%
[nu,inu] = sort(nu,2,'descend');
b = nu;                   % vector of beta_{s,i}, when b=0, beta_{s,i}=s_i
n = m*(m-1)/2;
mx = zeros(n,2);          % mx tells us the two subscripts of b_{ij} 
c = 0;
for i=1:m-1
    for j=i+1:m
        c = c+1;
        mx(c,:) = [j i];
    end
end
%  x is b_{i,j} for the nonzero \sigma_{ij}
x = zeros(1,n);
y = int64(sum(nu+1)+1);
cond = true;
sx = 0;
while cond
   for j=1:n
       i1 = mx(j,1);
       i2 = mx(j,2);
%  When b_{i1,i2} is increased by one, beta_{s,i1} and beta_{s,i2} will
%  be reduced by one.       
       if b(i1)*b(i2)>=1
          x(j) = x(j)+1;
          sx = sx+1;
          b(i1) = b(i1)-1;
          b(i2) = b(i2)-1;
          if all(rem(b,2)==0)
             y = y+1;
          end
          break
       elseif x(j)>0
          b(i1) = b(i1)+x(j);
          b(i2) = b(i2)+x(j);
          sx = sx-x(j);
          x(j) = 0;
       end
   end
   cond = sx>0;
end
