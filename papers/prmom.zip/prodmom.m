%
% prodmom.m		Date: 4/29/2015
% This Matlab program computes the product moment of X_1^{nu_1}X_2^{nu_2}...X_n^{nu_n},
% where X_i are elements from X ~ N(mu,V).  
% V only needs to be positive semidefinite.
% mu: mean of X
% V: variance-covariance matrix of X
% nu: power of X_i
% Usage: prodmom(mu,V,[nu_1 nu_2 ... nu_n])
% Example: To get E[X_1*X_2^3*X_3^2], use prodmom(mu,V,[1 3 2])
% Note: This program is based on an expansion of univariate moments of X_1
%       and multivariate moments of (X_2,...,X_n).
%
function y = prodmom(mu,V,nu)
n = size(V,1);
if nargin<3
   nu = ones(1,n);
end
s = sum(nu);
if s==0
   y = 1;
   return
end
nuz = nu==0;
if any(nuz)
   nu(nuz) = [];
   mu = mu(~nuz);
   V = V(~nuz,~nuz);
   n = length(nu);
end
%
%  Use univariate normal results
%
if n==1
   y0 = 1;
   y1 = mu;
   for i=1:s-1
       y = mu*y1+i*V*y0;
       y0 = y1;
       y1 = y;
   end
   return
end
%
%  Use bivariate normal results when there are only two distinct indices
%
if n==2
   z1 = ones(nu(1)+1,1);
   z1(2) = mu(1);
   for i=3:nu(1)+1
       z1(i) = (mu(1)*z1(i-1)+V(1,1)*z1(i-2))/(i-1);
   end
   z2 = ones(nu(2)+1,1);
   z2(2) = mu(2);
   for i=3:nu(2)+1
       z2(i) = (mu(2)*z2(i-1)+V(2,2)*z2(i-2))/(i-1);
   end
   ss = min(nu);
   y = prod(factorial(nu))*sum(cumprod([1; V(1,2)./[1:ss]']).*z1(end:-1:end-ss).*z2(end:-1:end-ss));
   return  
end
%
%  Regular case
%
[nu,inu] = sort(nu,2,'descend');
mu = mu(inu);
V = V(inu,inu);          
s1 = nu(1);
s2 = nu(2:end);
ss2 = sum(s2);
%
%   Compute scaled moments of X_1
%
maxm1 = s1+1;
m1 = ones(maxm1,1);
m1(2) = mu(1);
for i=3:maxm1
    m1(i) = (mu(1)*m1(i-1)+V(1,1)*m1(i-2))/(i-1);
end
%
%   Compute scaled product moments of X_2 to X_n
%
pnu = prod(s2+1);
M = zeros(pnu,1);
M(1) = 1;
cind = cumprod([1 s2(1:n-2)+1]);
v = V(1,2:n);
zv = find(v==0);
nzv = find(v~=0);
V1 = V(2:n,2:n);
mu1 = mu(2:n);
y = 0;
fs2 = factorial(s2);
%  c = v.^(s2-x)*(s2-x)_x
c = prod(v(nzv).^s2(nzv));
szv = sum(s2(zv));
sx = ss2;          % sx = |s_2|-|kappa|, which is updated, note that sx is not |kappa|
if sx<=s1&&szv==0
   y = c*m1(s1-sx+1);
end
x = zeros(1,n-1);  % this is kappa, power of X_2 to X_n
j1 = 1;
for i=2:pnu
    for j=1:n-1
% j tells us the position of the first nonzero element of x
% j1 tells us the position of the last nonzero element of x
        if x(j)<s2(j)
           i1 = i-cind(j);
           j1 = max(j,j1);
           if v(j)~=0
              c = c*(s2(j)-x(j))/v(j);   
           else
              szv = szv-1;
           end
           x(j) = x(j)+1;
           sx = sx-1;
           M(i) = mu1(j)*M(i1);
           if x(j)>1
              M(i) = M(i)+V1(j,j)*M(i1-cind(j));
           end
           for k=j+1:j1
               if x(k)>0
                  M(i) = M(i)+V1(j,k)*M(i1-cind(k));
               end
           end
           M(i) = M(i)/x(j);
           if sx<=s1&&szv==0
              y = y+c*M(i)*m1(s1-sx+1);
           end
           break
        else
           x(j) = 0;
           sx = sx+s2(j);
           if v(j)~=0
              c = c*v(j)^s2(j)/fs2(j);
           else
              szv = szv+s2(j);
           end
        end
    end
end
y = y*factorial(s1)*prod(fs2(zv));
