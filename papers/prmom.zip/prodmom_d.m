%
% prodmom_d.m		Date: 6/29/2023
% This Matlab program computes the product moment of X_1^{nu_1}X_2^{nu_2}...X_n^{nu_n},
% where X_i are elements from X ~ N(mu,V).  
% V only needs to be positive semidefinite.
% mu: mean of X
% V: variance-covariance matrix of X
% m: decomposition of X into two subsets with the first one with m elements
%    and the second one with n-m elements, 1<=m<=n-1
% nu: power of X_i
% Usage: prodmom_d(mu,V,m,[nu_1 nu_2 ... nu_n])
% Example: To get E[X_1*X_2^3*X_3^2], use prodmom_d(mu,V,m,[1 3 2]), where 
%          m can be 1 or 2 in this case.
% Note: This program is based on an expansion of multivariate moments of 
%       (X_1,...,X_m) and (X_{m-1},...,X_{n-m}).
%
function y = prodmom_d(mu,V,m,nu)
n = size(V,1);
if nargin<4
   nu = ones(1,n);
end
s = sum(nu);
if s==0
   y = 1;
   return
end
nuz = nu==0;
if any(nuz)
   nu(nuz) = [];
   mu = mu(~nuz);
   V = V(~nuz,~nuz);
   n = length(nu);
end
%
%  Use univariate normal results
%
if n==1
   y0 = 1;
   y1 = mu;
   for i=1:s-1
       y = mu*y1+i*V*y0;
       y0 = y1;
       y1 = y;
   end
   return
end
%
%  Use bivariate normal results when there are only two distinct indices
%
if n==2
   z1 = ones(nu(1)+1,1);
   z1(2) = mu(1);
   for i=3:nu(1)+1
       z1(i) = (mu(1)*z1(i-1)+V(1,1)*z1(i-2))/(i-1);
   end
   z2 = ones(nu(2)+1,1);
   z2(2) = mu(2);
   for i=3:nu(2)+1
       z2(i) = (mu(2)*z2(i-1)+V(2,2)*z2(i-2))/(i-1);
   end
   ss = min(nu);
   y = prod(factorial(nu))*sum(cumprod([1; V(1,2)./[1:ss]']).*z1(end:-1:end-ss).*z2(end:-1:end-ss));
   return  
end
%
%  Regular case
%
sa = nu(1:m);
sb = nu(m+1:end);
%
%   Compute scaled product moments of (X_1,...,X_m)
%
mu1 = mu(1:m);
V1 = V(1:m,1:m);
cind1 = cumprod([1 sa(1:m-1)+1]);
pnu1 = prod(sa+1);
M1 = zeros(pnu1,1);
M1(1) = 1;
x = zeros(1,m);
j1 = 1;
for i=2:pnu1
    for j=1:m
% j tells us the position of the first nonzero element of x
% j1 tells us the position of the last nonzero element of x
        if x(j)<sa(j)
           i1 = i-cind1(j);
           j1 = max(j,j1);
           x(j) = x(j)+1;
           M1(i) = mu1(j)*M1(i1);
           if x(j)>1
              M1(i) = M1(i)+V1(j,j)*M1(i1-cind1(j));
           end
           for k=j+1:j1
               if x(k)>0
                  M1(i) = M1(i)+V1(j,k)*M1(i1-cind1(k));
               end
           end
           M1(i) = M1(i)/x(j);
           break
        else
           x(j) = 0;
        end
    end
end
%
%   Compute scaled product moments of (X_{m+1},...,X_n)
%
mu2 = mu(m+1:end);
V2 = V(m+1:end,m+1:end);
cind2 = cumprod([1 sb(1:n-m-1)+1]);
pnu2 = prod(sb+1);
M2 = zeros(pnu2,1);
M2(1) = 1;
x = zeros(1,n-m);
j1 = 1;
for i=2:pnu2
    for j=1:n-m
% j tells us the position of the first nonzero element of x
% j1 tells us the position of the last nonzero element of x
        if x(j)<sb(j)
           i1 = i-cind2(j);
           j1 = max(j,j1);
           x(j) = x(j)+1;
           M2(i) = mu2(j)*M2(i1);
           if x(j)>1
              M2(i) = M2(i)+V2(j,j)*M2(i1-cind2(j));
           end
           for k=j+1:j1
               if x(k)>0
                  M2(i) = M2(i)+V2(j,k)*M2(i1-cind2(k));
               end
           end
           M2(i) = M2(i)/x(j);
           break
        else
           x(j) = 0;
        end
    end
end
%
%   Loop through (l_1,...,l_m) to create the scaled
%   moment of (X_1,...,X_n)
%
V21 = V(m+1:end,1:m);
v = V21(:);
% vector of (l_{1,m+1},l_{1,m+2},...,l_{1,n},l_{2,m+1},...,l_{m,n})
nzv = find(v~=0);
v = v(nzv);
m1 = length(nzv);
x = zeros(1,m1);
mx = zeros(m1,2);  % mx tells us the two subscripts of l_{ij} 
c = 0;
for i=1:m
    for j=1:n-m
        if V21(j,i)~=0
           c = c+1;
           mx(c,:) = [i j];
        end
    end
end
fs = cumprod(1:max(nu));
% c1 is prod_{i=1}^m prod_{j=m+1}^n \sigma_{ij}^{l_{ij}}/l_{ij}!
c1 = 1;
y = M1(end)*M2(end);
cond = true;
sx = 0;
ind1 = pnu1;
ind2 = pnu2;
while cond
   for j=1:m1
       i1 = mx(j,1);
       i2 = mx(j,2);
%  When l_{i1,i2} is increased by 1, sa(i1) and sb(i2) will be reduced by 1,       
       if sa(i1)>0&&sb(i2)>0
          x(j) = x(j)+1;
          sx = sx+1;
          sa(i1) = sa(i1)-1;
          sb(i2) = sb(i2)-1;
          c1 = c1*v(j)/x(j);
          ind1 = ind1-cind1(i1);
          ind2 = ind2-cind2(i2);
          y = y+c1*M1(ind1)*M2(ind2);
          break
       elseif x(j)>0
          c1 = c1*fs(x(j))/v(j)^x(j);
          sa(i1) = sa(i1)+x(j);
          sb(i2) = sb(i2)+x(j);
          ind1 = ind1+x(j)*cind1(i1);
          ind2 = ind2+x(j)*cind2(i2);
          sx = sx-x(j);
          x(j) = 0;
       end   
   end
   cond = sx>0;
end
y = sign(y)*exp(log(abs(y))+sum(gammaln(nu+1)));
