%
% prodmom_kan.m		Date: 4/29/2006
% This Matlab program computes the product moment of X_1^{nu_1}X_2^{nu_2}...X_m^{nu_m},
% where X_i are elements from X ~ N(mu,V).  
% V only needs to be positive semidefinite.
% mu: mean of X
% V: variance-covariance matrix of X
% nu: power of X_i 
% Usage: prodmom_kan(mu,V,[nu1 nu2 ... num])
% Example: To get E[X_1*X_2^3*X_3^2], use prodmom_kan(mu,V,[1 3 2])
% Note: It uses an explict formula based on Kan (2008).
%
function y = prodmom_kan(mu,V,nu)
m = size(V,1);
if nargin<3
   nu = ones(size(ii));
end
s = sum(nu);
if s==0
   y = 1;
   return
end
nuz = nu==0;
if any(nuz)
   nu(nuz) = [];
   mu = mu(~nuz);
   V = V(~nuz,~nuz);
   m = length(nu);
end
%
%  Use univariate normal results
%
if m==1
   y0 = 0;
   y1 = 1;
   for i=0:s-1
       y = mu*y1+i*V*y0;
       y0 = y1;
       y1 = y;
   end
   return
end
%
%  Regular case
%
[nu,inu] = sort(nu,2,'descend');
mu = mu(inu);
V = V(inu,inu);          % Extract only the relevant part of V
x = zeros(1,m);
d = ones(1,m);
kk = cumprod(nu+1,"reverse");
nu2 = nu/2;
p = 2;
q = nu2*V*nu2';   % h'*Sigma*h
q1 = nu2*mu;      % h'*mu
y = 0;
for i=1:fix(kk(1)/2)
%   Compute E[Y^s]/s! for Y~N(q1,q)
    z2 = 1;
    z3 = q1;
    for j=2:s
        z1 = z2;
        z2 = z3;
        z3 = (q*z1+q1*z2)/j;
    end
    y = y+p*z3;
    j1 = m;
    while rem(i,kk(j1))==0
       j1 = j1-1;
    end
    x(j1) = x(j1)+d(j1);
    if d(j1)==1
       p = -round(p*(nu(j1)+1-x(j1))/x(j1));
       q = q-2*(nu2-x)*V(:,j1)-V(j1,j1);
       q1 = q1-mu(j1);
    else
       p = -round(p*(x(j1)+1)/(nu(j1)-x(j1)));
       q = q+2*(nu2-x)*V(:,j1)-V(j1,j1);
       q1 = q1+mu(j1);
    end
    if x(j1)==0||x(j1)==nu(j1);
       d(j1) = -d(j1);
    end
end
