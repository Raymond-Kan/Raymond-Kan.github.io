%
% prodmom_rec.m		Date: 4/20/2024
% This Matlab program computes the product moment of X_1^{nu_1}X_2^{nu_2}...X_m^{nu_m},
% where X_i are elements from X ~ N(0_n,V).  
% V only needs to be positive semidefinite.
% V: variance-covariance matrix of X
% s: power of X_i
% Reference: Willink (2005) Normal Moments and Hermite Polynomials,
%            Statistics and Probability Letters 73, 271-275.
% Usage: prodmom_rec(V,[nu1 nu2 ... num])
% Example: To get E[X_1*X_2^3*X_3^2], use prodmom_rec(mu,V,[1 3 2])
% Note: This program uses a recursive algorithm by Willink (2005)
%
function y = prodmom_rec(mu,V,nu)
m = length(mu);
if nargin<3
   nu = ones(1,m);
end
s = sum(nu);
if s==0
   y = 1;
   return
end
% Extract only the relevant part of mu and V
nuz = nu==0;
if any(nuz)
   nu(nuz) = [];
   mu = mu(~nuz);
   V = V(~nuz,~nuz);
   m = length(nu);
end
[nu,inu] = sort(nu);
mu = mu(inu);     
V = V(inu,inu);
nu(1) = nu(1)-1;
nu1 = nu+1;
pnu = prod(nu1);
M = zeros(pnu,1);
M(1) = 1;
x = zeros(1,m);
cind = cumprod([1 nu1(1:m-1)]);
j1 = 1;
for i=2:pnu
    for j=1:m
% j tells us the position of the first nonzero element of x
% j1 tells us the position of the last nonzero element of x
        if x(j)<nu(j)
           i1 = i-cind(j);
           j1 = max(j,j1);
           x(j) = x(j)+1;
           M(i) = mu(j)*M(i1);
           if x(j)>1
              M(i) = M(i)+(x(j)-1)*V(j,j)*M(i1-cind(j));
           end
           for k=j+1:j1
               M(i) = M(i)+x(k)*V(j,k)*M(i1-cind(k));
           end
           break
        else
           x(j) = 0;
        end
    end
end
y = mu(1)*M(end);
for j=1:m
    y = y+nu(j)*V(1,j)*M(pnu-cind(j));
end
