%
% prodmom_sl.m		Date: 4/29/2015
% This Matlab program computes the product moment of X_1^{nu_1}X_2^{nu_2}...X_m^{nu_m},
% where X_i are elements from X ~ N(mu,V).  
% V only needs to be positive semidefinite.
% mu: mean of X
% V: variance-covariance matrix of X
% nu: power of X_i 
% Usage: prodmom_sl(mu,V,[nu1 nu2 ..., num])
% Example: To get E[X_1*X_2^3*X_3^2], use prodmom_sl(mu,V,[1 3 2])
% Note: This program is based on an expansion of Song and Lee (2015).
%
function y = prodmom_sl(mu,V,nu);
m = size(V,1);
if nargin<3
   nu = ones(size(ii));
end
s = sum(nu);
if s==0
   y = 1;
   return
end
nuz = nu==0;
if any(nuz)
   nu(nuz) = [];
   mu = mu(~nuz);
   V = V(~nuz,~nuz);
   m = length(nu);
end
%
%  Use univariate normal results
%
if m==1
   y0 = 1;
   y1 = mu;
   for i=1:s-1
       y = mu*y1+i*V*y0;
       y0 = y1;
       y1 = y;
   end
   return
end
%
%  Regular case
%
[nu,inu] = sort(nu,2,'descend');
mu = mu(inu);
V = V(inu,inu);           % Extract only the relevant part of V
v = V(logical(tril(ones(m))))';
b = nu;                   % vector of L_{s,i}, when l=0, L_{s,i}=s_i
nzv = find(v~=0);
v = v(nzv);               % get rid of zero \sigma_{ij}
n = length(nzv);
mx = zeros(n,2);          % mx tells us the two index of the l_{ij} subscripts
c = 0;
for i=1:m
    for j=i:m
        if V(j,i)~=0
           c = c+1;
           mx(c,:) = [j i];
        end
    end
end
x = zeros(1,n);   % vector of l = (l_{1,1}, ..., l_{m,1},l_{2,2},...,l_{m,2},...,l_{m,m})
fs = cumprod(1:nu(1));
zmu = find(mu==0);
nzmu = find(mu~=0);
sbz = sum(nu(zmu));        % sum of L_{s,i} for the zero mu_i cases
%  get rid of zero mu_i
nu = nu(nzmu);
mu1 = mu(nzmu)';
% c1 is prod_{i=1}^m prod_{j=i}^m \sigma_{ij}^{l_{ij}}/l_{ij}!
c1 = 1;
% c2 is (prod_{i=1}^m nu_i!*\mu_i^L_{s,i}/L_{s,i}!)/2^{\sum_{i=1}^m l_{ii}} 
c2 = prod(mu1.^nu);
if sbz>0
   y = 0;
else
   y = c2;
end
cond = true;
sx = 0;
while cond
   for j=1:n
       i1 = mx(j,1);
       i2 = mx(j,2);
%  When l_{i1,i2} is increased by one, only L_{s,i1} and L_{s,i2} will
%  be reduced by one.
       sbzd = (mu(i1)==0)+(mu(i2)==0);   % reduction of sbz
       if (i1~=i2&&b(i1)*b(i2)>=1)||(i1==i2&&b(i1)>=2)
          x(j) = x(j)+1;
          sx = sx+1;
          if i1==i2
             c2 = 0.5*c2*b(i1)*(b(i1)-1);
          else
             c2 = c2*b(i1)*b(i2);
          end
          if mu(i1)~=0
             c2 = c2/mu(i1);
          end
          if mu(i2)~=0
             c2 = c2/mu(i2);
          end
          b(i1) = b(i1)-1;
          b(i2) = b(i2)-1;
          c1 = c1*v(j)/x(j);
          sbz = sbz-sbzd;
          if sbz==0
             y = y+c1*c2;
          end
          break
       elseif x(j)>0
          c1 = c1*fs(x(j))/v(j)^x(j);
          b(i1) = b(i1)+x(j);
          b(i2) = b(i2)+x(j);
          if i1==i2
             c2 = c2*2^x(j)*fs(max(1,b(i1)-2*x(j)))/fs(b(i1));
          else
             c2 = c2*fs(max(1,b(i1)-x(j)))/fs(b(i1)) ...
                  *fs(max(1,b(i2)-x(j)))/fs(b(i2));
          end
          if mu(i1)~=0
             c2 = c2*mu(i1)^x(j);
          end
          if mu(i2)~=0
             c2 = c2*mu(i2)^x(j);
          end
          sx = sx-x(j);
          sbz = sbz+x(j)*sbzd;
          x(j) = 0;
       end
   end
   cond = sx>0;  % continue until sx=0
end
