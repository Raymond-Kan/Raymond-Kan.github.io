%
% prodmom_u.m		Date: 4/29/2015
% This Matlab program computes the product moment of X_{i_1}^{nu_1}X_{i_2}^{nu_2}...X_{i_m}^{nu_m},
% where X_i are elements from X ~ N(mu,V).  
% V only needs to be positive semidefinite.
% mu: mean of X
% V: variance-covariance matrix of X
% nu: power of X_i 
% Usage: prodmom_u(mu,V,[nu1 nu2 ... num])
% Example: To get E[X_1*X_2^3*X_3^2], use prodmomnc_u(mu,V,[1 3 2])
% Note: This program is based on an expansion of univariate moments of X_i.
%
function y = prodmom_u(mu,V,nu)
m = length(mu);
if nargin<3
   nu = ones(1,m);
end
s = sum(nu);
if s==0
   y = 1;
   return
end
nuz = nu==0;
if any(nuz)
   nu(nuz) = [];
   mu = mu(~nuz);
   V = V(~nuz,~nuz);
   m = length(nu);
end
%
%  Use univariate normal results
%
if m==1
   y0 = 1;
   y1 = mu;
   for i=1:s-1
       y = mu*y1+i*V*y0;
       y0 = y1;
       y1 = y;
   end
   return
end
%
%  Use bivariate normal results when there are only two distinct indices
%
if m==2
   z1 = ones(nu(1)+1,1);
   z1(2) = mu(1);
   for i=3:nu(1)+1
       z1(i) = (mu(1)*z1(i-1)+V(1,1)*z1(i-2))/(i-1);
   end
   z2 = ones(nu(2)+1,1);
   z2(2) = mu(2);
   for i=3:nu(2)+1
       z2(i) = (mu(2)*z2(i-1)+V(2,2)*z2(i-2))/(i-1);
   end
   ss = min(nu);
   y = prod(factorial(nu))*sum(cumprod([1; V(1,2)./[1:ss]']).*z1(end:-1:end-ss).*z2(end:-1:end-ss));
   return  
end
%
%  Regular case
%
[nu,inu] = sort(nu,2,'descend');
mu = mu(inu);
V = V(inu,inu);          % Extract only the relevant part of V
v = V(logical(tril(ones(m))-eye(m)));
%
%  Compute scaled univariate moments of X_1 to X_m
%
nu1 = nu+1;   
m1 = ones(m,nu1(1));
m1(:,2) = mu;
for i=1:m
    for j=3:nu1(i)
        m1(i,j) = (mu(i)*m1(i,j-1)+V(i,i)*m1(i,j-2))/(j-1);
    end
end
b = nu;                   % vector of beta_{s,i}, when b=0, beta_{s,i}=s_i
nzv = find(v~=0);
v = v(nzv);               % get rid of zero \sigma_{ij}
n = length(nzv);
mx = zeros(n,2);          % mx tells us the two subscripts of b_{ij} 
c = 0;
for i=1:m-1
    for j=i+1:m
        if V(j,i)~=0
           c = c+1;
           mx(c,:) = [j i];
        end
    end
end
fs = cumprod(1:nu(1));
%  x is b_{i,j} for the nonzero \sigma_{ij}
x = zeros(1,n);
c1 = 1;           % c1 = \prod_{i=1}^{m-1}\prod_j=i+1}^m \sigma_{ij}^{b_{ij}}/b_{ij}!
y = m1(1,b(1)+1);
for k=2:m
    y = y*m1(k,b(k)+1);
end
cond = true;
sx = 0;
while cond
   for j=1:n
       i1 = mx(j,1);
       i2 = mx(j,2);
%  When b_{i1,i2} is increased by one, beta_{s,i1} and beta_{s,i2} will
%  be reduced by one.       
       if b(i1)*b(i2)>=1
          x(j) = x(j)+1;
          sx = sx+1;
          c1 = c1*v(j)/x(j);
          b(i1) = b(i1)-1;
          b(i2) = b(i2)-1;
          c2 = m1(1,b(1)+1);
          for k=2:m
              c2 = c2*m1(k,b(k)+1);
          end
          y = y+c1*c2;
          break
       elseif x(j)>0
          c1 = c1*fs(x(j))/v(j)^x(j);
          b(i1) = b(i1)+x(j);
          b(i2) = b(i2)+x(j);
          sx = sx-x(j);
          x(j) = 0;
       end
   end
   cond = sx>0;
end
y = sign(y)*exp(log(abs(y))+sum(gammaln(nu+1)));
