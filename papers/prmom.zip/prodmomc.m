%
% prodmomc.m		Date: 4/29/2015
% This Matlab program computes the product moment of X_1^{nu_1}X_2^{nu_2}...X_n^{nu_n},
% where X_{i_j} are elements from X ~ N(0_n,V).  
% V only needs to be positive semidefinite.
% V: variance-covariance matrix of X
% nu: power of X_i's 
% of the equation.
% Usage: prodmomc(V,[nu_1 nu_2 ... nu_n])
% Example: To get E[X_1*X_2^3*X_3^2], use prodmomc(V,[1 3 2])
%
function y = prodmomc(V,nu)
n = size(V,1);
if nargin<2
   nu = ones(1,n);
end
s = sum(nu);
if s==0
   y = 1;
   return
end
if rem(s,2)==1
   y = 0;
   return
end
nuz = nu==0;
if any(nuz)
   nu(nuz) = [];
   V = V(~nuz,~nuz);
   m = length(nu);
end
%
%  Use univariate normal results
%
if n==1
   y = V^(s/2)*prod([1:2:s-1]);
   return
end
%
%  Use bivariate normal results when there are only two distinct indices
%
if n==2
   rho = V(1,2)/sqrt(V(1,1)*V(2,2));
   rho2 = rho^2;
   r = fix(nu(1)/2);
   s = fix(nu(2)/2);
   y = 1;
   c = 1;
   odd = 2*rem(nu(1),2);
   for j=1:min(r,s)
       c = 2*c*(r+1-j)*(s+1-j)*rho2/(j*(2*j+odd-1));
       y = y+c;
   end
   if odd
      y = y*rho;
   end
   y = V(1,1)^(nu(1)/2)*V(2,2)^(nu(2)/2)*prod([1:2:nu(1)])*prod([1:2:nu(2)])*y;
   return  
end
%
%  Regular case
%
[nu,inu] = sort(nu,2,'descend');
V = V(inu,inu);          
s1 = nu(1);
s2 = nu(2:end);
ss2 = sum(s2);
%
%   Compute scaled moments of X_1
%
maxm1 = s1+1;
m1 = zeros(maxm1,1);
m1(1) = 1;
m1(3:2:maxm1) = cumprod(V(1,1)./[2:2:s1]);
%
%   Compute scaled product moments of X_2 to X_n
%
cind = cumprod([1 s2(1:n-2)+1]);
pnu = prod(s2+1);
M = zeros(pnu,1);
M(1) = 1;
v = V(1,2:n);
zv = find(v==0);
nzv = find(v~=0);
V1 = V(2:n,2:n);
fs2 = factorial(s2);
%  c = v.^(s2-x)*(s2-x)_x
c = prod(v(nzv).^s2(nzv));
szv = sum(s2(zv));
sx = ss2;          % sx = |s_2|-|kappa|, which is updated, note that sx is not |kappa|
if sx<=s1&&szv==0
   y = c*m1(s1-sx+1);
else
   y = 0;
end
x = zeros(1,n-1);  % this is kappa, power of X_2 to X_n
sodd = rem(ss2,2);
j1 = 1;
for i=2:pnu
    for j=1:n-1
% j tells us the position of the first nonzero element of x
% j1 tells us the position of the last nonzero element of x
        if x(j)<s2(j)
           if v(j)~=0
              c = c*(s2(j)-x(j))/v(j);   
           else
              szv = szv-1;
           end
           j1 = max(j,j1);
           x(j) = x(j)+1;
           sx = sx-1;
% Only need to deal with the case that |\kappa| is even
           if rem(sx,2)==sodd
              i1 = i-cind(j);
              if x(j)>1
                 M(i) = M(i)+V1(j,j)*M(i1-cind(j));
              end
              for k=j+1:j1
                  if x(k)>0
                     M(i) = M(i)+V1(j,k)*M(i1-cind(k));
                  end
              end
              M(i) = M(i)/x(j);
              if sx<=s1&&szv==0
                 y = y+c*M(i)*m1(s1-sx+1);
              end
           end
           break
        else
           x(j) = 0;
           sx = sx+s2(j);
           if v(j)~=0
              c = c*v(j)^s2(j)/fs2(j);
           else
              szv = szv+s2(j);
           end
        end
    end
end
y = y*factorial(s1)*prod(fs2(zv));
