%
% prodmomc_d.m		Date: 6/29/2023
% This Matlab program computes the product moment of X_1^{nu_1}X_2^{nu_2}...X_n^{nu_n},
% where X_i are elements from X ~ N(0_n,V).  
% V only needs to be positive semidefinite.
% V: variance-covariance matrix of X
% m: decomposition of X into two subsets with the first one with m elements
%    and the second one with n-m elements, 1<=m<=n-1
% nu: power of X_i
% Usage: prodmomc_d(V,m,[nu1 nu2 ... nun])
% Example: To get E[X_1*X_2^3*X_3^2], use prodmomc_d(V,m,[1 3 2]), where 
%          m can be 1 or 2 in this case.
% Note: This program is based on an expansion of multivariate moments of 
%       (X_1,...,X_m) and (X_{m-1},...,X_{n-m}).
%
function y = prodmomc_d(V,m,nu)
n = size(V,1);
if nargin<3
   nu = ones(1,n);
end
s = sum(nu);
if rem(s,2)==1
   y = 0;
   return
end
if s==0
   y = 1;
   return
end
nuz = nu==0;
if any(nuz)
   nu(nuz) = [];
   mu = mu(~nuz);
   V = V(~nuz,~nuz);
   n = length(nu);
end
%
%  Use univariate normal results
%
if n==1
   y = V^(s/2)*prod([1:2:s-1]);
   return
end
%
%  Use bivariate normal results when there are only two distinct indices
%
if n==2
   rho = V(1,2)/sqrt(V(1,1)*V(2,2));
   rho2 = rho^2;
   r = fix(nu(1)/2);
   s = fix(nu(2)/2);
   y = 1;
   c = 1;
   odd = 2*rem(nu(1),2);
   for j=1:min(r,s)
       c = 2*c*(r+1-j)*(s+1-j)*rho2/(j*(2*j+odd-1));
       y = y+c;
   end
   if odd
      y = y*rho;
   end
   y = V(1,1)^(nu(1)/2)*V(2,2)^(nu(2)/2)*prod([1:2:nu(1)])*prod([1:2:nu(2)])*y;
   return  
end
%
%  Regular case
%
sa = nu(1:m);
sb = nu(m+1:end);
%
%   Compute scaled product moments of (X_1,...,X_m)
%
V1 = V(1:m,1:m);
cind1 = cumprod([1 sa(1:m-1)+1]);
pnu1 = prod(sa+1);
M1 = zeros(pnu1,1);
M1(1) = 1;
x = zeros(1,m);
sx = 0;
j1 = 1;
for i=2:pnu1
    for j=1:m
% j tells us the position of the first nonzero element of x
% j1 tells us the position of the last nonzero element of x
        if x(j)<sa(j)
           j1 = max(j,j1);
           x(j) = x(j)+1;
           sx = sx+1;
           if rem(sx,2)==0
              i1 = i-cind1(j);
              if x(j)>1
                 M1(i) = M1(i)+V1(j,j)*M1(i1-cind1(j));
              end
              for k=j+1:j1
                  if x(k)>0
                     M1(i) = M1(i)+V1(j,k)*M1(i1-cind1(k));
                  end
              end
              M1(i) = M1(i)/x(j);
           end
           break
        else
           x(j) = 0;
           sx = sx-nu(j);
        end
    end
end
%
%   Compute scaled product moments of (X_{m+1},...,X_n)
%
V2 = V(m+1:end,m+1:end);
cind2 = cumprod([1 sb(1:n-m-1)+1]);
pnu2 = prod(sb+1);
M2 = zeros(pnu2,1);
M2(1) = 1;
x = zeros(1,n-m);
sx = 0;
j1 = 1;
for i=2:pnu2
    for j=1:n-m
% j tells us the position of the first nonzero element of x
% j1 tells us the position of the last nonzero element of x
        if x(j)<sb(j)
           j1 = max(j,j1);
           x(j) = x(j)+1;
           sx = sx+1;
           if rem(sx,2)==0
              i1 = i-cind2(j);
              if x(j)>1
                 M2(i) = M2(i)+V2(j,j)*M2(i1-cind2(j));
              end
              for k=j+1:j1
                  if x(k)>0
                     M2(i) = M2(i)+V2(j,k)*M2(i1-cind2(k));
                  end
              end
              M2(i) = M2(i)/x(j);
           end
           break
        else
           x(j) = 0;
           sx = sx-nu(m+j);
        end
    end
end
%
%   Loop through (l_1,...,l_m) to create the scaled
%   moment of (X_1,...,X_n)
%
V21 = V(m+1:end,1:m);
v = V21(:);
% vector of (l_{1,m+1},l_{1,m+2},...,l_{1,n},l_{2,m+1},...,l_{m,n})
nzv = find(v~=0);
v = v(nzv);
m1 = length(nzv);
x = zeros(1,m1);
mx = zeros(m1,2);  % mx tells us the two index of the l_{ij} subscripts
c = 0;
for i=1:m
    for j=1:n-m
        if V21(j,i)~=0
           c = c+1;
           mx(c,:) = [i j];
        end
    end
end
fs = cumprod(1:max(nu));
% c1 is prod_{i=1}^m prod_{j=m+1}^n \sigma_{ij}^{l_{ij}}/l_{ij}!
c1 = 1;
y = M1(end)*M2(end);
cond = true;
sx = 0;
ssa = sum(sa);
ind1 = pnu1;
ind2 = pnu2;
while cond
   for j=1:m1
       i1 = mx(j,1);
       i2 = mx(j,2);
%  When l_{i1,i2} is increased by 1, sa(i1) and sb(i2) will be reduced by 1,       
       if sa(i1)>0&&sb(i2)>0
          x(j) = x(j)+1;
          sx = sx+1;
          sa(i1) = sa(i1)-1;
          sb(i2) = sb(i2)-1;
          ssa = ssa-1;
          c1 = c1*v(j)/x(j);
          ind1 = ind1-cind1(i1);
          ind2 = ind2-cind2(i2);
          if rem(ssa,2)==0
             y = y+c1*M1(ind1)*M2(ind2);
          end
          break
       elseif x(j)>0
          c1 = c1*fs(x(j))/v(j)^x(j);
          sa(i1) = sa(i1)+x(j);
          sb(i2) = sb(i2)+x(j);
          ssa = ssa+x(j);
          ind1 = ind1+x(j)*cind1(i1);
          ind2 = ind2+x(j)*cind2(i2);
          sx = sx-x(j);
          x(j) = 0;
       end   
   end
   cond = sx>0;
end
y = sign(y)*exp(log(abs(y))+sum(gammaln(nu+1)));
