%
% prodmomc_kan.m   Date: 4/29/2006
% This Matlab program computes the product moment of X_1^{nu_1}X_{2}^{nu_2}...X_{m}^{nu_m},
% where X_i are elements from X ~ N(0_m,V).  
% V only needs to be positive semidefinite.
% V: variance-covariance matrix of X
% nu: power of X_i 
% Usage: prodmomc_kan(V,[nu1 nu2 ... num])
% Example: To get E[X_2X_4^3X_7^2], use prodmomc_kan(V,[1 3 2])
% Note: It uses an explict formula based on Kan (2008).
%
function y = prodmomc_kan(V,nu)
m = size(V,1);
if nargin<2
   nu = ones(1,m);
end
s = sum(nu);
if s==0
   y = 1;
   return
end
if rem(s,2)==1
   y = 0;
   return
end
nuz = nu==0;
if any(nuz)
   nu(nuz) = [];
   V = V(~nuz,~nuz);
   m = length(nu);
end
s2 = s/2;
%
%  Use univariate normal results
%
if m==1
   y = V^s2*prod([1:2:s-1]);
   return
end
%
%  Regular case
%
[nu,inu] = sort(nu,2,'descend');
V = V(inu,inu);          % Extract only the relevant part of V
x = zeros(1,m);
d = ones(1,m);
kk = cumprod(nu+1,"reverse");
V = V/2;
nu2 = nu/2;
p = 2;
q = nu2*V*nu2';
y = 0;
for i=1:fix(kk(1)/2)
    y = y+p*q^s2;
    j1 = m;
    while rem(i,kk(j1))==0
       j1 = j1-1;
    end
    x(j1) = x(j1)+d(j1);
    if d(j1)==1
       p = -round(p*(nu(j1)+1-x(j1))/x(j1));
       q = q-2*(nu2-x)*V(:,j1)-V(j1,j1);
    else
       p = -round(p*(x(j1)+1)/(nu(j1)-x(j1)));
       q = q+2*(nu2-x)*V(:,j1)-V(j1,j1);
    end
    if x(j1)==0||x(j1)==nu(j1)
       d(j1) = -d(j1);
    end
end
y = y/prod([1:s2]);
