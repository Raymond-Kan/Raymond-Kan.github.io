%
% prodmomc_rec.m		Date: 4/20/2024
% This Matlab program computes the product moment of X_{1}^{nu_1}X_{2}^{nu_2}...X_{m}^{nu_m},
% where X_{i} are elements from X ~ N(0_m,V).  
% V only needs to be positive semidefinite.
% V: variance-covariance matrix of X
% s: power of X_i
% Method: A recursive method, which is numerically more stable as it does not
%         involve summing up terms with alternate signs.
% Reference: Triantafyllopoulos (2003) On the Central Moments of the 
%            Multidimensional Gaussian Distribution, Mathematical Scientist
%            Kotz, Balakrishnan, and Johnson (2000), Continuous Multivariate
%            Distributions, Vol. 1, p.261
%            Note that there is a typo in Eq.(46.25), there should be an extra 
%            rho in front of the equation.
%            Willink (2005) Normal Moments and Hermite Polynomials,
%            Statistics and Probability Letters 73, 271-275.
% Usage: prodmomc_rec(V,[nu1 nu2 ... num])
% Example: To get E[X_1*X_2^3*X_3^2], use prodmomc_rec(V,[1 3 2])
% Note: This program uses a recursive algorithm by Willink (2005).
%
function y = prodmomc_rec(V,nu)
m = size(V,1);
if nargin<2
   nu = ones(1,m);
end
s = sum(nu);
if s==0
   y = 1;
   return
end
if rem(s,2)==1
   y = 0;
   return
end
% Extract only the relevant part of V
nuz = nu==0;
if any(nuz)
   nu(nuz) = [];
   V = V(~nuz,~nuz);
   m = length(nu);
end
[nu,inu] = sort(nu);
V = V(inu,inu);          
nu(1) = nu(1)-1;
nu1 = nu+1;
pnu = prod(nu1);
M = zeros(pnu,1);
M(1) = 1;
x = zeros(1,m);
sx = 0;
cind = cumprod([1 nu1(1:m-1)]);
j1 = 1;
for i=2:pnu
    for j=1:m
% j tells us the position of the first nonzero element of x
% j1 tells us the position of the last nonzero element of x
        if x(j)<nu(j)
           j1 = max(j,j1);
           x(j) = x(j)+1;
           sx = sx+1;
           if rem(sx,2)==0
              i1 = i-cind(j);
              if x(j)>1
                 M(i) = (x(j)-1)*V(j,j)*M(i1-cind(j));
              end
              for k=j+1:j1
                  M(i) = M(i)+x(k)*V(j,k)*M(i1-cind(k));
              end
           end   
           break
        else
           x(j) = 0;
           sx = sx-nu(j);
        end
    end
end
y = 0;
for j=1:m
    y = y+nu(j)*V(1,j)*M(pnu-cind(j));
end
