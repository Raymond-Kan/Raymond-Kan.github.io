%
% prodmomc_sl.m		Date: 4/29/2015
% This Matlab program computes the product moment of X_1^{nu_1}X_2^{nu_2}...X_m^{nu_m},
% where X_i are elements from X ~ N(0_m,V).  
% V only needs to be positive semidefinite.
% V: variance-covariance matrix of X
% nu: power of X_i
% Usage: prodmomc_sl(V,[nu1 nu2 ... num])
% Example: To get E[X_1*X_2^3*X_3^2], use prodmomc_sl(V,[1 3 2])
% Note: This program is based on an expansion of Song and Lee (2015).
%
function y = prodmomc_sl(V,nu);
m = size(V,1);
if nargin<2
   nu = ones(size(ii));
end
s = sum(nu);
if s==0
   y = 1;
   return
end
if rem(s,2)==1
   y = 0;
   return
end
nuz = nu==0;
if any(nuz)
   nu(nuz) = [];
   V = V(~nuz,~nuz);
   m = length(nu);
end
%
%  Use univariate normal results
%
if m==1
   y = V^(s/2)*prod([1:2:s-1]);
   return
end
%
%  Regular case
%
v = V(logical(tril(ones(m))-eye(m)));
b = nu;                   % vector of 2*l_{i,i}, need all b_i to be even
nzv = find(v~=0);
v = v(nzv)';              % get rid of zero \sigma_{ij}
n = length(nzv);
mx = zeros(n,2);          % mx tells us the two index of the l_{ij} subscripts
c = 0;
for i=1:m-1
    for j=i+1:m
        if V(j,i)~=0
           c = c+1;
           mx(c,:) = [j i];
        end
    end
end
vd = sqrt(diag(V)');   % standard deviation of the n random variables
x = zeros(1,n);        % vector of l = (l_{1,2}, ..., l_{1,m},l_{2,3},...,l_{2,m},...,l_{m,m})
fs = cumprod(1:max(nu));
% c1 is prod_{i=1}^{m} prod_{j=i}^m \sigma_{ij}^{l_{ij}}/l_{ij}!/2^sum{i=1}^m l_{ii}
c1 = prod(vd.^b)/2^sum(b/2);
if any(rem(b,2)~=0)
   y = 0;
else 
   y = c1/prod(factorial(b/2));
end
cond = true;
sx = 0;
while cond
   for j=1:n
       i1 = mx(j,1);
       i2 = mx(j,2);
%  When l_{i1,i2} is increased by one, only b_{i1} and b_{i2} will
%  be reduced by one.
       if b(i1)*b(i2)>=1
          x(j) = x(j)+1;
          sx = sx+1;
          b(i1) = b(i1)-1;
          b(i2) = b(i2)-1;
          c1 = c1*v(j)/x(j)*2/(vd(i1)*vd(i2));
          if all(rem(b,2)==0)
             y = y+c1/prod(factorial(b/2));
          end
          break
       elseif x(j)>0
          c1 = c1*fs(x(j))*(vd(i1)*vd(i2)/2/v(j))^x(j);
          b(i1) = b(i1)+x(j);
          b(i2) = b(i2)+x(j);
          sx = sx-x(j);
          x(j) = 0;
       end
   end
   cond = sx>0;  % continue until sx=0
end
y = sign(y)*exp(log(abs(y))+sum(gammaln(nu+1)));
