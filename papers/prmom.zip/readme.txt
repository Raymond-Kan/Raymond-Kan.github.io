These are programs for my Communications in Statistics - Simulation 
and Computation paper "A Fast Algorithm for Computing Product Moments 
of Multivariate Normal Random Variables."  If you have questions, 
comments, or bug reports, please send them to 
Raymond.Kan@rotman.utoronto.ca

Raymond Kan
Rotman School of Management
University of Toronto

Version 1.0: 4/15/2024, initial release.
Version 1.1: 5/30/2024, update prodmom_rec.m and prodmomc_rec.m to
             reduce the number of calculations

ncountc*.m: programs to count the number of terms for the
            central multivariate normal case
   * = _rec: Willink (2005)
   * = _kan: Kan (2008)
   * = _sl: Song and Lee (2015)
   * = {}: decomposition formula with m=1
   * = _u: formula based on product of univariate moments
   * = _d: decomposition formula with general m
ncount*.m: programs to count the number of terms for the
           noncentral multivariate normal case
   * = _rec: Willink (2005)
   * = _kan: Kan (2008)
   * = _sl: Song and Lee (2015)
   * = {}: decomposition formula with m=1
   * = _u: formula based on product of univariate moments
   * = _d: decomposition formula with general m
prodmomc*.m: programs to compute \mu_s' for the central 
            multivariate normal case, with different methods
   * = _rec: Willink (2005)
   * = _kan: Kan (2008)
   * = _sl: Song and Lee (2015)
   * = {}: decomposition formula with m=1
   * = _u: formula based on product of univariate moments
   * = _d: decomposition formula with general m
prodmom*.m: programs to compute \mu_s' for the noncentral 
              multivariate normal case, with different methods
   * = _rec: Willink (2005)
   * = _kan: Kan (2008)
   * = _sl: Song and Lee (2015)
   * = {}: decomposition formula with m=1
   * = _u: formula based on product of univariate moments
   * = _d: decomposition formula with general m
