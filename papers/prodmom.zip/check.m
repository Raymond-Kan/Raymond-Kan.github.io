%
% check.m: Checks the programs against each other on randomly generated
% problems.  All the numbers that are printed are maximum relative
% differences, and they should be close to machine precision (1e-16).
%
rng(1)
method = {'auto','orth','shift','plain'};
%
% Central case: prodmom.m and prodmomq.m versus prodmom_rec.m
%
e = zeros(2,4);
for trial=1:300
    m = randi(6);
    n = m+randi(3);
    x = randn(n+2,n);
    d = exp(2*randn(n,1));
    V = (x'*x).*(d*d');
    ii = randi(n,1,m);             % some of the indices can be repeated
    nu = randi(5,1,m)-1;
    nu(1) = nu(1)+rem(sum(nu),2);
    y0 = prodmom_rec(V,ii,nu);
    for j=1:4
        e(1,j) = max(e(1,j),abs(prodmom(V,ii,nu,method{j})/y0-1));
        e(2,j) = max(e(2,j),abs(prodmomq(V,ii,nu,method{j})/y0-1));
    end
end
fprintf('Central case, relative to prodmom_rec.m\n')
fprintf('             %9s %9s %9s %9s\n',method{:})
fprintf('prodmom      %9.1e %9.1e %9.1e %9.1e\n',e(1,:))
fprintf('prodmomq     %9.1e %9.1e %9.1e %9.1e\n',e(2,:))
%
% Noncentral case: prodmomnc.m and prodmomncq.m versus prodmomnc_rec.m
%
e = zeros(2,4);
for trial=1:300
    m = randi(6);
    n = m+randi(3);
    x = randn(n+2,n);
    d = exp(randn(n,1));
    V = (x'*x).*(d*d');
    mu = abs(randn(n,1)).*d*sqrt(n);    % positive means, so that the moment is not close to zero
    ii = randi(n,1,m);
    nu = randi(5,1,m)-1;
    y0 = prodmomnc_rec(mu,V,ii,nu);
    for j=1:4
        e(1,j) = max(e(1,j),abs(prodmomnc(mu,V,ii,nu,method{j})/y0-1));
        e(2,j) = max(e(2,j),abs(prodmomncq(mu,V,ii,nu,method{j})/y0-1));
    end
end
fprintf('\nNoncentral case, relative to prodmomnc_rec.m\n')
fprintf('             %9s %9s %9s %9s\n',method{:})
fprintf('prodmomnc    %9.1e %9.1e %9.1e %9.1e\n',e(1,:))
fprintf('prodmomncq   %9.1e %9.1e %9.1e %9.1e\n',e(2,:))
%
% Isserlis formula
%
e = 0;
for trial=1:20
    n = 8;
    x = randn(n+2,n);
    V = x'*x;
    nu = [2 1 1 2 1 1 1 1];
    e = max(e,abs(prodmom(V,1:n,nu)/prodmom_haf(V,1:n,nu)-1));
end
fprintf('\nprodmom.m relative to prodmom_haf.m: %9.1e\n',e)
%
% Special cases: a variable with zero variance, and a rescaling of the
% variables by 1e30
%
n = 6;
x = randn(n+2,n);
V = x'*x;
mu = randn(n,1);
nu = [2 3 1 2 2 2];
V0 = V;
V0(2,:) = 0;
V0(:,2) = 0;
fprintf('\nZero variance: prodmom = %g (should be 0), prodmomnc relative to mu_2^3*E[...]: %9.1e\n', ...
        prodmom(V0,1:n,nu),abs(prodmomnc(mu,V0,1:n,nu)/(mu(2)^3*prodmomnc(mu,V0,[1 3 4 5 6],nu([1 3 4 5 6])))-1))
d = [1e30 1 1e-30 1 1e30 1]';
fprintf('Rescaling: prodmom %9.1e, prodmomq %9.1e, prodmomnc %9.1e, prodmomncq %9.1e\n', ...
        abs(prodmom(V.*(d*d'),1:n,nu)/(prodmom(V,1:n,nu)*prod(d'.^nu))-1), ...
        abs(prodmomq(V.*(d*d'),1:n,nu)/(prodmomq(V,1:n,nu)*prod(d'.^nu))-1), ...
        abs(prodmomnc(mu.*d,V.*(d*d'),1:n,nu)/(prodmomnc(mu,V,1:n,nu)*prod(d'.^nu))-1), ...
        abs(prodmomncq(mu.*d,V.*(d*d'),1:n,nu)/(prodmomncq(mu,V,1:n,nu)*prod(d'.^nu))-1))
%
% Quadratic forms: if A_i = a_i*b_i', then z'A_iz = (a_i'z)*(b_i'z), so
% the moment of a product of quadratic forms is a product moment of the
% normal vector [a_1'z ... a_p'z b_1'z ... b_p'z].  V1 is positive
% definite and V2 is singular.  These moments can be close to zero, so
% some of the problems are ill-conditioned and we compare the actual
% relative error of qmom.m and qmomnc.m with relerr, the error estimate
% that they return.
%
e = zeros(2,2);
r = zeros(2,2);
for trial=1:200
    p = randi(4);
    n = 3+randi(5);
    x = randn(n+2,n);
    V1 = x'*x/(n+2);
    x = randn(n-2,n);
    V2 = x'*x/(n-2);
    mu = randn(n,1);
    a = randn(n,p);
    b = randn(n,p);
    A = zeros(n,n,p);
    for i=1:p
        A(:,:,i) = a(:,i)*b(:,i)';       % not symmetric
    end
    si = randi(3,1,p);
    c = [a b];
    for j=1:2
        if j==1
           V = V1;
        else
           V = V2;
        end
        [y,relerr] = qmom(V,A,si);
        d = abs(y/prodmomq(c'*V*c,1:2*p,[si si])-1);
        e(1,j) = max(e(1,j),d);
        r(1,j) = max(r(1,j),d/relerr);
        [y,relerr] = qmomnc(mu,V,A,si);
        d = abs(y/prodmomncq(c'*mu,c'*V*c,1:2*p,[si si])-1);
        e(2,j) = max(e(2,j),d);
        r(2,j) = max(r(2,j),d/relerr);
    end
end
fprintf('\nQuadratic forms, relative to prodmomq.m and prodmomncq.m\n')
fprintf('             %12s %12s %12s %12s\n','V p.d.','V singular','V p.d.','V singular')
fprintf('             %12s %12s %12s %12s\n','max error','max error','error/relerr','error/relerr')
fprintf('qmom         %12.1e %12.1e %12.2f %12.2f\n',e(1,:),r(1,:))
fprintf('qmomnc       %12.1e %12.1e %12.2f %12.2f\n',e(2,:),r(2,:))
