%
% fig_kappa.m: Produces Figure 1 of prodmom_note.tex (fig_kappa.pdf).
% The numbers are log10 of the condition numbers of the three versions of
% the identity, where the condition number is the sum of the absolute
% values of the terms divided by the absolute value of their sum.
% Panel (a): E[z_1...z_n] for the covariance matrix of test1.m.
% Panel (b): E[(z_1z_2z_3z_4)^(s/4)] for the covariance matrix
%            rng(1); x = randn(22,20); V = x'*x/22;
% Columns: q^(s/2), (q-c)^(s/2), and pi_{s/2}(q-c).
%
na = 2:2:20;
Ka = [ 2.0829  0.0000  0.0000
       3.0849  0.8890  0.7409
       4.9879  1.8225  1.4962
       4.9956  1.1432  0.9100
       6.5622  1.8617  1.5096
       7.9112  2.3363  1.9391
      10.4651  4.5437  4.2110
       9.8671  3.3902  2.8727
       9.8637  3.1872  2.6234
      11.1311  3.8300  3.1843];
sb = 4:4:48;
Kb = [ 1.1461  0.0264  0.0928
       1.3927  0.3520  0.2432
       2.1879  1.1050  0.3925
       2.7624  1.7117  0.6415
       3.4551  2.4315  0.8234
       4.1056  3.1035  1.0533
       4.7856  3.8010  1.2519
       5.4607  4.4907  1.5073
       6.1455  5.1877  1.7317
       6.8323  5.8848  1.9866
       7.5238  6.5850  2.2021
       8.2179  7.2866  2.4885];
set(groot,'defaultTextInterpreter','latex','defaultLegendInterpreter','latex', ...
    'defaultAxesTickLabelInterpreter','latex')
fig = figure('Units','inches','Position',[1 1 6.5 2.9],'Color','w');
tl = tiledlayout(fig,1,2,'TileSpacing','compact','Padding','compact');
for j=1:2
    ax = nexttile(tl);
    if j==1
       x = na;
       K = Ka;
    else
       x = sb;
       K = Kb;
    end
    plot(ax,x,K(:,1),'-ok',x,K(:,2),'--sk',x,K(:,3),'-.^k','LineWidth',0.8,'MarkerSize',4.5)
    grid(ax,'on')
    ax.FontSize = 9;
    ylim(ax,[0 12])
    ylabel(ax,'$\log_{10}\kappa$')
    if j==1
       xlim(ax,[2 20])
       xlabel(ax,'$n$')
       title(ax,'(a) $s_1=\cdots=s_n=1$','FontSize',9)
       legend(ax,{'$q^{s/2}$','$(q-c)^{s/2}$','$\pi_{s/2}(q-c)$'},'Location','northwest','FontSize',8)
    else
       xlim(ax,[4 48])
       xticks(ax,4:8:48)
       xlabel(ax,'$s$')
       title(ax,'(b) $n=4$, $s_1=\cdots=s_4=s/4$','FontSize',9)
    end
end
exportgraphics(fig,'fig_kappa.pdf','ContentType','vector')
set(groot,'defaultTextInterpreter','remove','defaultLegendInterpreter','remove', ...
    'defaultAxesTickLabelInterpreter','remove')
