arch = computer('arch');
lapacklib = fullfile(matlabroot,'extern','lib',arch,'microsoft','libmwlapack.lib');
blaslib = fullfile(matlabroot,'extern','lib',arch,'microsoft','libmwblas.lib');
mex -v pmomd.f
mex -v pmomq.f
mex -v pmomncd.f
mex -v pmomncq.f
if strcmp(arch,'win32') 
   mex ('-v','qmomquad.f',lapacklib,blaslib)
   mex ('-v','qmomncquad.f',lapacklib,blaslib)
end
if strcmp(arch,'win64')
   mex('-v','-largeArrayDims','qmomquad.f',lapacklib,blaslib)
   mex('-v','-largeArrayDims','qmomncquad.f',lapacklib,blaslib)
end 
