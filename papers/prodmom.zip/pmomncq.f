#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*), prhs(*)
      integer nlhs, nrhs
      mwpointer mxgetpr,mxcreatedoublescalar
      mwsize mxgetm,n
      mwpointer x1,x2,x3,y
      x1 = mxgetpr(prhs(1))
      x2 = mxgetpr(prhs(2))
      x3 = mxgetpr(prhs(3))
      n = mxgetm(prhs(2))
      plhs(1) = mxcreatedoublescalar(0)
      y = mxgetpr(plhs(1))
      call pmom(%val(y),%val(x1),%val(x2),%val(x3),n)      
      return
      end


      SUBROUTINE PMOM(YD,MUD,VD,NUD,N)
      INTEGER N,S,NU(:),X(:),D(:)
      INTEGER*8 P,KK(:)
      REAL*8 YD,MUD(N),NUD(N),VD(N,N)
      REAL*16 Y,Q,Q1,V(:,:),NU2(:),MU(:),Z1,Z2,Z3
      ALLOCATABLE :: X,D,KK,NU,NU2,V,MU

      ALLOCATE(NU(N))
      ALLOCATE(NU2(N))
      ALLOCATE(X(N))
      ALLOCATE(D(N))
      ALLOCATE(KK(N))      
      ALLOCATE(MU(N))
      ALLOCATE(V(N,N))
      
      X = 0
      D = 1
      V = VD
      MU = MUD
      NU = NINT(NUD)
      S = SUM(NU)
      NU2 = 0.5q0*NUD
      P = 2
      Q = DOT_PRODUCT(NU2,MATMUL(V,NU2))
      Q1 = DOT_PRODUCT(NU2,MU)
      Y = 0q0
      KK(N) = NU(N)+1
      DO 100 I=N-1,1,-1
  100 KK(I) = KK(I+1)*(NU(I)+1)      
      DO 101 I=1,KK(1)/2
      Z2 = 1q0
      Z3 = Q1
      DO 103 J=2,S
      Z1 = Z2
      Z2 = Z3
  103 Z3 = (Q*Z1+Q1*Z2)/QFLOAT(J)
      Y = Y+QFLOAT(P)*Z3
      DO 102 J1=N,1,-1
      IF (MOD(I,KK(J1)).NE.0) GOTO 200
  102 CONTINUE
  200 X(J1) = X(J1)+D(J1)
      IF (D(J1).EQ.1) THEN   
         P = -P*(NU(J1)+1-X(J1))/X(J1)
         Q = Q-2q0*DOT_PRODUCT(V(:,J1),NU2-X)-V(J1,J1)
         Q1 = Q1-MU(J1)
      ELSE
         P = -P*(X(J1)+1)/(NU(J1)-X(J1))
         Q = Q+2q0*DOT_PRODUCT(V(:,J1),NU2-X)-V(J1,J1)
         Q1 = Q1+MU(J1)
      END IF
      IF ((X(J1).EQ.0).OR.(X(J1).EQ.NU(J1))) D(J1)=-D(J1)
  101 CONTINUE
      YD = Y
      RETURN
      END
