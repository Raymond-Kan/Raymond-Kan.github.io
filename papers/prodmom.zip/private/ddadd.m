%
% ddadd.m		Date: 11/24/2026
% Sum of two double-double numbers: (zh,zl) = (ah,al)+(bh,bl).
% Works elementwise on arrays.
%
function [zh,zl] = ddadd(ah,al,bh,bl)
[s,e] = twosum(ah,bh);
[t,f] = twosum(al,bl);
e = e+t;
t = s+e;
e = e-(t-s);
e = e+f;
zh = t+e;
zl = e-(zh-t);
