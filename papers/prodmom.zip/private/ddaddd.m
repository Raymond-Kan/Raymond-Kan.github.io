%
% ddaddd.m		Date: 11/24/2026
% Sum of a double-double number and a double: (zh,zl) = (ah,al)+b.
% Works elementwise on arrays.
%
function [zh,zl] = ddaddd(ah,al,b)
[s,e] = twosum(ah,b);
e = e+al;
zh = s+e;
zl = e-(zh-s);
