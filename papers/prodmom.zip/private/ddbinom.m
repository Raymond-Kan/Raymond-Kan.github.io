%
% ddbinom.m		Date: 11/24/2026
% Binomial coefficients with alternate signs as double-double numbers:
% (bh(i+1),bl(i+1)) = (-1)^i*binom(n,i), i=0,...,n.  bl is zero unless the
% binomial coefficient is larger than 2^53.
%
function [bh,bl] = ddbinom(n)
bh = ones(1,n+1);
bl = zeros(1,n+1);
for i=1:n
    [th,tl] = ddmuld(bh(i),bl(i),n-i+1);
    bh(i+1) = th/i;
    [ph,pl] = twoprod(bh(i+1),i);
    bl(i+1) = (((th-ph)-pl)+tl)/i;
end
bh = (-1).^(0:n).*bh;
bl = (-1).^(0:n).*bl;
