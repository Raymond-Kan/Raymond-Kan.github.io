%
% ddmul.m		Date: 11/24/2026
% Product of two double-double numbers: (zh,zl) = (ah,al)*(bh,bl).
% Works elementwise on arrays.
%
function [zh,zl] = ddmul(ah,al,bh,bl)
[p,e] = twoprod(ah,bh);
e = e+(ah.*bl+al.*bh);
zh = p+e;
zl = e-(zh-p);
