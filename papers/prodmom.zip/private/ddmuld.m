%
% ddmuld.m		Date: 11/24/2026
% Product of a double-double number and a double: (zh,zl) = (ah,al)*b.
% Works elementwise on arrays.
%
function [zh,zl] = ddmuld(ah,al,b)
[p,e] = twoprod(ah,b);
e = e+al.*b;
zh = p+e;
zl = e-(zh-p);
