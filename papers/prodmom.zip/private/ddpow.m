%
% ddpow.m		Date: 11/24/2026
% Integer power of a double-double number: (yh,yl) = (xh,xl)^n for an
% integer n>=0, by repeated squaring.  Works elementwise on arrays.
%
function [yh,yl] = ddpow(xh,xl,n)
if n==0
   yh = ones(size(xh));
   yl = zeros(size(xh));
   return
end
first = true;
while true
   if rem(n,2)==1
      if first
         yh = xh;
         yl = xl;
         first = false;
      else
         [yh,yl] = ddmul(yh,yl,xh,xl);
      end
   end
   n = fix(n/2);
   if n==0
      break
   end
   [xh,xl] = ddmul(xh,xl,xh,xl);
end
