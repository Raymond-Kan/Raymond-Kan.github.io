%
% ddsum.m		Date: 11/24/2026
% Sum of the elements of a column vector of double-double numbers,
% using pairwise summation: (sh,sl) = sum((xh,xl)).
%
function [sh,sl] = ddsum(xh,xl)
n = length(xh);
while n>1
   if rem(n,2)==1
      xh(n+1,1) = 0;
      xl(n+1,1) = 0;
      n = n+1;
   end
   n = n/2;
   [xh,xl] = ddadd(xh(1:n),xl(1:n),xh(n+1:2*n),xl(n+1:2*n));
end
sh = xh;
sl = xl;
