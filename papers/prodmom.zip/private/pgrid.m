%
% pgrid.m		Date: 11/24/2026
% For nu = [nu_1 ... nu_m], this program generates the N = prod(nu+1) points
% h = (nu_1/2-x_1,...,nu_m/2-x_m), 0<=x_j<=nu_j, that are used by the
% moments of sum identity, together with their weights
% w = prod_j (-1)^(x_j)*binom(nu_j,x_j).
% H: N by m matrix, each row is a point h (x_m changes fastest)
% w: N by 1 vector of weights
% wl: when there are three output arguments, the weights are computed as
%     double-double numbers (w,wl).  This is needed when the weights are
%     larger than 2^53 and are not exactly representable as doubles.
%
function [H,w,wl] = pgrid(nu)
m = length(nu);
N = prod(nu+1);
H = zeros(N,m);
w = ones(N,1);
wl = zeros(N,1);
r = N;
for j=1:m
    r = r/(nu(j)+1);
    idx = rem(floor((0:N-1)'/r),nu(j)+1)+1;
    v = nu(j)/2-(0:nu(j))';
    H(:,j) = v(idx);
    if nargout>2
       [bh,bl] = ddbinom(nu(j));
       [w,wl] = ddmul(w,wl,bh(idx)',bl(idx)');
    else
       b = (round(cumprod([1 (nu(j):-1:1)./(1:nu(j))])).*(-1).^(0:nu(j)))';
       w = w.*b(idx);
    end
end
