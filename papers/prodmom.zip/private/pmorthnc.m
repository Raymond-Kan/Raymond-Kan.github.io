%
% pmorthnc.m		Date: 11/24/2026
% For vectors t and x, this program computes
%
%    F = sum_{j=0}^{floor(s/2)} rho_{s-2j}(t)*pi_j(x)/((s-2j)!j!),
%
% where rho_i and pi_j are the monic polynomials that are defined by the
% recurrence relations
%
%    pi_j(x) = (x-al(j))*pi_{j-1}(x)-be(j)*pi_{j-2}(x),
%    rho_i(t) = t*rho_{i-1}(t)-bm(i)*rho_{i-2}(t),
%
% see pmpilot.m.
% G: sum of the absolute values of the terms of F
% Fx: partial derivative of F with respect to x
% Ft: partial derivative of F with respect to t
%
function [F,G,Fx,Ft] = pmorthnc(t,x,s,al,be,bm)
k = floor(s/2);
N = length(t);
der = nargout>2;
%
%  R(:,j+1) = rho_{s-2j}(t)/(s-2j)!, D(:,j+1) is its derivative
%
R = zeros(N,k+1);
r0 = zeros(N,1);
r1 = ones(N,1);
if der
   D = zeros(N,k+1);
   d0 = r0;
   d1 = r0;
end
if rem(s,2)==0
   R(:,k+1) = r1;
end
for i=1:s
    u = 1/i;
    v = bm(i)/(i*max(i-1,1));
    if der
       d2 = u*(r1+t.*d1)-v*d0;
       d0 = d1;
       d1 = d2;
    end
    r2 = u*(t.*r1)-v*r0;
    r0 = r1;
    r1 = r2;
    if rem(s-i,2)==0
       R(:,(s-i)/2+1) = r1;
       if der
          D(:,(s-i)/2+1) = d1;
       end
    end
end
%
%  p1 = pi_j(x)/j!, d1 is its derivative
%
p0 = zeros(N,1);
p1 = ones(N,1);
F = R(:,1);
G = abs(F);
if der
   d0 = p0;
   d1 = p0;
   Fx = p0;
   Ft = D(:,1);
end
for j=1:k
    u = 1/j;
    v = be(j)/(j*max(j-1,1));
    if der
       d2 = u*(p1+(x-al(j)).*d1)-v*d0;
       d0 = d1;
       d1 = d2;
    end
    p2 = u*((x-al(j)).*p1)-v*p0;
    p0 = p1;
    p1 = p2;
    z = R(:,j+1).*p1;
    F = F+z;
    G = G+abs(z);
    if der
       Fx = Fx+R(:,j+1).*d1;
       Ft = Ft+D(:,j+1).*p1;
    end
end
