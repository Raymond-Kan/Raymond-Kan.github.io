%
% pmpownc.m		Date: 11/24/2026
% For vectors t and x, this program computes
%
%    F = sum_{j=0}^{floor(s/2)} t^(s-2j)*x^j/((s-2j)!j!),
%
% which is E[Y^s]/s! for Y ~ N(t,2x) when x>=0.  It uses the recurrence
% relation z_j = (t*z_{j-1}+2x*z_{j-2})/j.
% G: an estimate of the size of the terms that are summed up to obtain F
% Fx: partial derivative of F with respect to x
% Ft: partial derivative of F with respect to t
%
function [F,G,Fx,Ft] = pmpownc(t,x,s)
z0 = zeros(size(t));
z1 = z0;
F = ones(size(t));
x = 2*x;
for j=1:s
    z0 = z1;
    z1 = F;
    F = (t.*z1+x.*z0)/j;
end
G = abs(F);
Fx = z0;
Ft = z1;
