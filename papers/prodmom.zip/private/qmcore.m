%
% qmcore.m		Date: 11/24/2026
% This program does the computations for qmom.m (mu is empty) and
% qmomnc.m.  It computes the cross moment of q_1^{s_1}...q_p^{s_p}, where
% q_i = z'A_iz and z ~ N(mu,V), together with an estimate of the relative
% error that is due to roundoff errors (when est is true).
%
% Method: With s = s_1+...+s_p, Proposition 4 of the paper gives
%
%            E[q_1^s_1...q_p^s_p] = sum_h w(h) E[(z'B(h)z)^s]/s!,
%
%         where B(h) = h_1*A_1+...+h_p*A_p, and the sum is over
%         h = (s_1/2-x_1,...,s_p/2-x_p), 0<=x_j<=s_j, and
%         w(h) = prod_j (-1)^(x_j)*binom(s_j,x_j).  With V = R'R and
%         C = 2*R*B(h)*R', y_j = E[(z'B(h)z)^j]/j! is obtained from
%
%            y_j = (1/(2j)) sum_{i=1}^j a_i*y_{j-i},
%            a_i = tr(C^i)+i*mu'B(h)R'C^(i-2)R*B(h)mu*4,  i>=2,
%            a_1 = tr(C)+2*mu'B(h)mu.
%
%         The points h are processed in blocks.  For each block, the
%         eigenvalues of the matrices C are obtained by a single call to
%         pageeig (when it is available), which is a lot faster than
%         calling eig for each h.
%
function [y,relerr] = qmcore(mu,V,A,si,est)
nc = ~isempty(mu);
n = size(V,1);
p = size(A,3);
if isempty(si)
   si = ones(1,p);
end
si = si(:)';
A = (A+permute(A,[2 1 3]))/2;      % z'Az only depends on (A+A')/2
A = A(:,:,si>0);
si = si(si>0);
p = length(si);
s = sum(si);
relerr = 0;
if s==0
   y = 1;
   return
end
%
%  Find R such that V = R'R.  When V is singular, R has fewer rows than
%  columns.
%
V = (V+V')/2;
[R,flag] = chol(V);
if flag>0
   [Q,D] = eig(V);
   D = diag(D);
   if min(D)<-n*eps*max(abs(D))
      error('qmom:notpsd','V is not positive semidefinite.')
   end
   keep = D>n*eps*max(D);
   R = sqrt(D(keep)).*Q(:,keep)';
end
r = size(R,1);
At = zeros(r,r,p);
g = zeros(r,p);
m1 = zeros(1,p);
for i=1:p
    T = R*A(:,:,i)*R';
    At(:,:,i) = (T+T')/2;
    if nc
       g(:,i) = 2*(R*(A(:,:,i)*mu(:)));
       m1(i) = 2*(mu(:)'*A(:,:,i)*mu(:));
    end
end
if r==0                 % z is a constant
   y = prod((m1/2).^si);
   return
end
if p==1                 % a single quadratic form, no need to use the identity
   [f,fa] = dmom(2*At,g,m1,s,nc,est);
   y = f*prod(1:s);
   if est
      relerr = 10*eps*s*fa/abs(f);
   end
   return
end
[si,inu] = sort(si,2,'descend');   % this reduces the number of blocks
At = At(:,:,inu);
g = g(:,inu);
m1 = m1(inu);
%
%  The last mi quadratic forms make up the inner block, which is
%  vectorized.  The first mo quadratic forms are dealt with by a loop.
%
nb = max(1,min(2^12,floor(2^22/r^2)));
mi = find(cumprod(si(p:-1:1)+1)<=nb,1,'last');
if isempty(mi)
   mi = 1;
end
mo = p-mi;
io = 1:mo;
in = mo+1:p;
[H,w] = pgrid(si(in));
N = length(w);
AI = reshape(At(:,:,in),r*r,mi);
AO = reshape(At(:,:,io),r*r,mo);
sio = si(io);
bn = cell(1,mo);
for j=1:mo
    bn{j} = round(cumprod([1 (sio(j):-1:1)./(1:sio(j))])).*(-1).^(0:sio(j));
end
%
%  By symmetry, we only need to go through half of the points
%
NO = prod(sio+1);
nhalf = floor(NO/2);
x = zeros(1,mo);
h = sio/2;
y = 0;
yc = 0;
r1 = 0;
for i=1:nhalf+rem(NO,2)
    wo = 2;
    if i>nhalf
       wo = 1;
    end
    for j=1:mo
        wo = wo*bn{j}(x(j)+1);
    end
    C = reshape(2*(AO*h'+AI*H'),r,r,N);
    if nc
       [f,fa] = dmom(C,g(:,io)*h'+g(:,in)*H',m1(io)*h'+m1(in)*H',s,nc,est);
    else
       [f,fa] = dmom(C,[],[],s,nc,est);
    end
%
%   Add wo*sum(w.*f) to y, the rounding error of the addition goes to yc
%
    z = wo*(f*w);
    u = y+z;
    v = u-y;
    yc = yc+((y-(u-v))+(z-v));
    y = u;
    if est
       r1 = hypot(r1,wo*norm(fa.*w'));
    end
    j = mo;
    while j>0&&x(j)==sio(j)
       x(j) = 0;
       h(j) = sio(j)/2;
       j = j-1;
    end
    if j>0
       x(j) = x(j)+1;
       h(j) = h(j)-1;
    end
end
y = y+yc;
if est
   relerr = 10*eps*s*r1/abs(y);
   if r1==0
      relerr = 0;
   end
end
end

function [f,fa] = dmom(C,eta,m1,s,nc,est)
%
% f = E[(z'Bz)^s]/s! for each page of C (a 1 by N vector).  fa is the same
% quantity when all the terms in a_i are replaced by their absolute values,
% it measures the size of the terms that are summed up to obtain f.
%
[r,~,N] = size(C);
if exist('pageeig','builtin')||exist('pageeig','file')
   d = reshape(pageeig(C),r,N);
else
   d = zeros(r,N);
   for i=1:N
       d(:,i) = eig(C(:,:,i));
   end
end
a = zeros(s,N);
aa = a;
dj = ones(r,N);
for j=1:s
    dj = dj.*d;
    a(j,:) = sum(dj,1);
    if est
       aa(j,:) = sum(abs(dj),1);
    end
end
if nc
   a(1,:) = a(1,:)+m1;
   aa(1,:) = aa(1,:)+abs(m1);
   v = eta;
   for j=2:s
       a(j,:) = a(j,:)+j*sum(eta.*v,1);
       if est
          aa(j,:) = aa(j,:)+j*sum(abs(eta.*v),1);
       end
       if j<s
          v = reshape(pagemtimes(C,reshape(v,r,1,N)),r,N);
       end
   end
end
f = ones(s+1,N);
for j=1:s
    f(j+1,:) = sum(a(j:-1:1,:).*f(1:j,:),1)/(2*j);
end
f = f(s+1,:);
fa = [];
if est
   fa = ones(s+1,N);
   for j=1:s
       fa(j+1,:) = sum(aa(j:-1:1,:).*fa(1:j,:),1)/(2*j);
   end
   fa = fa(s+1,:);
end
end
