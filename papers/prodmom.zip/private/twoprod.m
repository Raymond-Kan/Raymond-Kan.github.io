%
% twoprod.m		Date: 11/24/2026
% Error-free transformation of a product (Dekker and Veltkamp):
% a*b = p+e exactly, with p = fl(a*b).  Works elementwise on arrays.
%
function [p,e] = twoprod(a,b)
p = a.*b;
t = 134217729*a;
ah = t-(t-a);
al = a-ah;
t = 134217729*b;
bh = t-(t-b);
bl = b-bh;
e = ((ah.*bh-p)+ah.*bl+al.*bh)+al.*bl;
