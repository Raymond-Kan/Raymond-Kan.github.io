%
% twosum.m		Date: 11/24/2026
% Error-free transformation of a sum (Knuth): a+b = s+e exactly, with
% s = fl(a+b).  Works elementwise on arrays.
%
function [s,e] = twosum(a,b)
s = a+b;
v = s-a;
e = (a-(s-v))+(b-v);
