%
% prodmom.m		Date: 11/24/2026
% This Matlab program computes the product moment of X_{i_1}^{nu_1}X_{i_2}^{nu_2}...X_{i_m}^{nu_m},
% where X_{i_j} are elements from X ~ N(0_n,V).
% V only needs to be positive semidefinite.
% V: variance-covariance matrix of X
% ii: vector of i_j
% nu: power of X_{i_j} (the default is a vector of ones)
% method: 'auto'  (default) the program chooses between 'orth' and 'shift'
%         'orth'  use an orthogonal polynomial of h'Vh (most accurate)
%         'shift' use a power of h'Vh-c (fastest)
%         'plain' use a power of h'Vh, i.e., the identity as it is given
%                 in the paper (least accurate, for comparison only)
% y: the product moment
% relerr: an estimate of the relative error of y that is due to roundoff
%         errors.  If relerr is not small enough, use prodmomq.m.
% Reference: Kan (2008) From Moments of Sum to Moments of Product,
%            Journal of Multivariate Analysis 99, 542-554.
% Usage: prodmom(V,[i1 i2 ... ir],[nu1 nu2 ... nur])
% Example: To get E[X_2X_4^3X_7^2], use prodmom(V,[2 4 7],[1 3 2])
% Method: With s = nu_1+...+nu_m, k = s/2, and q(h) = h'Vh/2, Proposition 1
%         of the paper gives
%
%            E[X_1^nu_1...X_m^nu_m] = (1/k!) sum_h w(h) q(h)^k,       (1)
%
%         where the sum is over h = (nu_1/2-x_1,...,nu_m/2-x_m),
%         0<=x_j<=nu_j, and w(h) = prod_j (-1)^(x_j)*binom(nu_j,x_j).
%         The terms of (1) have alternate signs and there can be a lot of
%         cancellation.  However, sum_h w(h) g(h) = 0 for every polynomial
%         g of degree less than s, so (1) continues to hold when q(h)^k
%         is replaced by p(q(h)) for ANY monic polynomial p of degree k.
%         This program uses either p(q) = (q-c)^k with
%         c = sum_j nu_j*V_jj/8 (the average of q(h) under the weights
%         |w(h)|), or the monic orthogonal polynomial of degree k with
%         respect to the weights |w(h)| (see private/pmpilot.m).  Both
%         choices make the terms much smaller than the ones in (1), so
%         far fewer digits are lost in the summation.
%
function [y,relerr] = prodmom(V,ii,nu,method)
if nargin<3||isempty(nu)
   nu = ones(size(ii));
end
if nargin<4
   method = 'auto';
end
%
%  Combine the indices that are repeated and drop the ones with a zero power
%
[ii,~,ic] = unique(ii(:)');
nu = accumarray(ic(:),nu(:))';
ii = ii(nu>0);
nu = nu(nu>0);
s = sum(nu);
relerr = 0;
if s==0
   y = 1;
   return
end
if rem(s,2)==1
   y = 0;
   return
end
V = V(ii,ii);            % Extract only the relevant part of V
V = (V+V')/2;
dv = diag(V)';
if any(dv<0)
   error('prodmom:negvar','V has a negative diagonal element.')
end
if any(dv==0)            % a variable with zero variance is identically zero
   y = 0;
   return
end
m = length(ii);
k = s/2;
%
%  Use univariate normal results
%
if m==1
   y = V^k*prod(1:2:s-1);
   return
end
%
%  Scale the variables by powers of 2 (which does not introduce any
%  rounding errors) so that their variances are between 0.5 and 2.
%
[~,e] = log2(dv);
e = floor(e/2);
sc = pow2(-e);
V = V.*(sc'*sc);
e = sum(e.*nu);
[nu,inu] = sort(nu,2,'descend');
V = V(inu,inu);
%
%  Choose the polynomial
%
c = (nu*diag(V))/8;
orth = false;
switch lower(method)
   case 'plain'
      c = 0;
   case 'shift'
   case {'orth','auto'}
      [al,be,gain] = pmpilot(V,nu,c);
      orth = strcmpi(method,'orth')||gain>10||(gain>2&&prod(nu+1)<=2^16);
   otherwise
      error('prodmom:method','Unknown method.')
end
%
%  The last mi variables form the inner block, which is vectorized.
%  The first mo variables are dealt with by a loop.
%
mi = find(cumprod(nu(m:-1:1)+1)<=2^13,1,'last');
if isempty(mi)
   mi = 1;
end
mo = m-mi;
io = 1:mo;
in = mo+1:m;
[H,w] = pgrid(nu(in));
cI = sum((H*V(in,in)).*H,2)/2-c;
VOO = V(io,io)/2;
VIO = V(in,io);
nuo = nu(io);
bn = cell(1,mo);
for j=1:mo
    bn{j} = round(cumprod([1 (nuo(j):-1:1)./(1:nuo(j))])).*(-1).^(0:nuo(j));
end
est = nargout>1;
if est
   hmax = max(abs(H),[],1);
   cmax = max(abs(cI))+c;
   r0 = 0;
   r1 = 0;
end
%
%  By symmetry, we only need to go through half of the points
%
NO = prod(nuo+1);
nhalf = floor(NO/2);
x = zeros(1,mo);
h = nuo/2;
y = 0;
yc = 0;
for i=1:nhalf+rem(NO,2)
    wo = 2;
    if i>nhalf
       wo = 1;
    end
    for j=1:mo
        wo = wo*bn{j}(x(j)+1);
    end
    a = h*VOO*h';
    b = VIO*h';
    q = cI+(a+H*b);
    if orth
       t0 = ones(size(q));
       t = q-al(1);
       for j=2:k
           t1 = (q-al(j)).*t-be(j)*t0;
           t0 = t;
           t = t1;
       end
    else
       tm = ipow(q,k-1);
       t = tm.*q;
    end
    wt = w.*t;
%
%   Add wo*sum(wt) to y, the rounding error of the addition goes to yc
%
    z = wo*sum(wt);
    u = y+z;
    v = u-y;
    yc = yc+((y-(u-v))+(z-v));
    y = u;
    if est
       if orth        % derivative of the polynomial
          t0 = zeros(size(q));
          tm = ones(size(q));
          d0 = t0;
          d1 = t0;
          for j=1:k
              d2 = tm+(q-al(j)).*d1-be(j)*d0;
              t1 = (q-al(j)).*tm-be(j)*t0;
              t0 = tm;
              tm = t1;
              d0 = d1;
              d1 = d2;
          end
          tm = d1/k;
       end
       r0 = hypot(r0,wo*(abs(a)+hmax*abs(b)+cmax)*norm(w.*tm));
       r1 = hypot(r1,wo*norm(wt));
    end
    j = mo;
    while j>0&&x(j)==nuo(j)
       x(j) = 0;
       h(j) = nuo(j)/2;
       j = j-1;
    end
    if j>0
       x(j) = x(j)+1;
       h(j) = h(j)-1;
    end
end
y = y+yc;
if est
   relerr = 10*eps*k*hypot(r0,r1)/abs(y);
   if r0+r1==0
      relerr = 0;
   end
end
y = pow2(y/prod(1:k),e);
end

function y = ipow(x,n)
%
% x.^n for an integer n>=0 by repeated squaring
%
if n==0
   y = ones(size(x));
   return
end
first = true;
while true
   if rem(n,2)==1
      if first
         y = x;
         first = false;
      else
         y = y.*x;
      end
   end
   n = fix(n/2);
   if n==0
      break
   end
   x = x.*x;
end
end
