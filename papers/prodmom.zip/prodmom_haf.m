%
% prodmom_haf.m		Date: 11/24/2026
% This Matlab program computes the product moment of X_{i_1}^{nu_1}X_{i_2}^{nu_2}...X_{i_m}^{nu_m},
% where X_{i_j} are elements from X ~ N(0_n,V).  
% V only needs to be positive semidefinite.
% V: variance-covariance matrix of X
% ii: vector of i_j
% nu: power of X_{i_j} 
% Reference: Triantafyllopoulos (2003) On the Central Moments of the Multidimensional
%            Gaussian Distribution, Mathematical Scientist
%            Kotz, Balakrishnan, and Johnson (2000), Continuous Multivariate
%            Distributions, Vol. 1, p.261
% Note that there is a typo in Eq.(46.25), there should be an extra rho in front 
% of the equation.
% Usage: prodmom_haf(V,[i1 i2 ... ir],[nu1 nu2 ... nur])
% Example: To get E[X_2X_4^3X_7^2], use prodmom_haf(V,[2 4 7],[1 3 2])
% Note: This program uses the Wick's (Isserlis) formula.  It sums up
%       (s-1)!! terms, where s = sum(nu), so it is only practical for
%       small s.
%
function y = prodmom_haf(V,ii,nu)
if nargin<3
   nu = ones(size(ii));
end
s = sum(nu);
if s==0
   y = 1;
   return
end
if rem(s,2)==1
   y = 0;
   return
end
nuz = nu==0;
nu(nuz) = [];
ii(nuz) = [];
V = V(ii,ii);          % Extract only the relevant part of V
m = length(ii);
s2 = s/2;
if any(diag(V)==0)     % a variable with zero variance is identically zero
   y = 0;
   return
end
%
%  Use univariate normal results
%
if m==1
   y = V^s2*prod([1:2:s-1]);
   return
end
%
%  Use bivariate normal results when there are only two distinct indices
%
if m==2
   rho = V(1,2)/sqrt(V(1,1)*V(2,2));
   y = V(1,1)^(nu(1)/2)*V(2,2)^(nu(2)/2)*bivmom(nu,rho);
   return  
end
%
%  Regular case
%
V = V(repelem(1:m,nu),repelem(1:m,nu));    % repeat the i-th variable nu(i) times
y = scov(1:s);

function y = scov(ii)
    if length(ii)==2
       y = V(ii(1),ii(2));
    else
       y = 0;
       for i=2:length(ii)
           y = y+V(ii(1),ii(i))*scov([ii(2:i-1) ii(i+1:end)]);
       end
    end
end

end