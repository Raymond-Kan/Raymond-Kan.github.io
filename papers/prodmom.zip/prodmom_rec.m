%
% prodmom_rec.m		Date: 4/20/2015
% This Matlab program computes the product moment of X_{i_1}^{s_1}X_{i_2}^{s_2}...X_{i_k}^{s_k},
% where X_{i_j} are elements from X ~ N(0_n,V).  
% V only needs to be positive semidefinite.
% V: variance-covariance matrix of X
% ii: vector of i_j
% s: power of X_{i_j} 
% Method: A recursive method, which is numerically more stable as it does not
%         involve summing up terms with alternate signs.
% Reference: Triantafyllopoulos (2003) On the Central Moments of the 
%            Multidimensional Gaussian Distribution, Mathematical Scientist
%            Kotz, Balakrishnan, and Johnson (2000), Continuous Multivariate
%            Distributions, Vol. 1, p.261
%            Note that there is a typo in Eq.(46.25), there should be an extra 
%            rho in front of the equation.
%            Willink (2005) Normal Moments and Hermite Polynomials,
%            Statistics and Probability Letters 73, 271-275.
% Usage: prodmom_rec(V,[i1 i2 ... ir],[nu1 nu2 ... nur])
% Example: To get E[X_2X_4^3X_7^2], use prodmom_rec(V,[2 4 7],[1 3 2])
% Note: This program uses a recursive algorithm by Willink (2005).
%
function y = prodmom_rec(V,ii,nu);
if nargin<3
   nu = ones(size(ii));
end
s = sum(nu);
if s==0
   y = 1;
   return
end
if rem(s,2)==1
   y = 0;
   return
end
nuz = nu==0;
nu(nuz) = [];
ii(nuz) = [];
m = length(ii);
V = V(ii,ii);
[nu,inu] = sort(nu,2,'descend');
V = V(inu,inu);          % Extract only the relevant part of V
nu1 = nu+1;
pnu = prod(nu1);
M = zeros(pnu,1);
M(1) = 1;
x = zeros(1,m);
sx = 0;
cind = cumprod([1 nu1(1:m-1)]);
j1 = 1;
for i=2:pnu
    for j=1:m
% j tells us the position of the first nonzero element of x
% j1 tells us the position of the last nonzero element of x
        if x(j)<nu(j)
           j1 = max(j,j1);
           x(j) = x(j)+1;
           sx = sx+1;
           if rem(sx,2)==0
              if x(j)>1
                 M(i) = (x(j)-1)*V(j,j)*M(i-2*cind(j));
              end
              for k=j+1:j1
                  M(i) = M(i)+x(k)*V(j,k)*M(i-cind(j)-cind(k));
              end
           end   
           break
        else
           x(j) = 0;
           sx = sx-nu(j);
        end
    end
end
y = M(end);
