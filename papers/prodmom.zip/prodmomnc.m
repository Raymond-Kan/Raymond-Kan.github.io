%
% prodmomnc.m		Date: 11/24/2026
% This Matlab program computes the product moment of X_{i_1}^{nu_1}X_{i_2}^{nu_2}...X_{i_m}^{nu_m},
% where X_{i_j} are elements from X ~ N(mu,V).
% V only needs to be positive semidefinite.
% mu: mean of X
% V: variance-covariance matrix of X
% ii: vector of i_j
% nu: power of X_{i_j} (the default is a vector of ones)
% method: 'auto'  (default) the program chooses between 'orth' and 'shift'
%         'orth'  use orthogonal polynomials of h'mu and h'Vh (most accurate)
%         'shift' use powers of h'mu and h'Vh-c (fastest)
%         'plain' use powers of h'mu and h'Vh, i.e., the identity as it is
%                 given in the paper (least accurate, for comparison only)
% y: the product moment
% relerr: an estimate of the relative error of y that is due to roundoff
%         errors.  If relerr is not small enough, use prodmomncq.m.
% Reference: Kan (2008) From Moments of Sum to Moments of Product,
%            Journal of Multivariate Analysis 99, 542-554.
% Usage: prodmomnc(mu,V,[i1 i2 ... ir],[nu1 nu2 ... nur])
% Example: To get E[X_2X_4^3X_7^2], use prodmomnc(mu,V,[2 4 7],[1 3 2])
% Method: With s = nu_1+...+nu_m, t(h) = h'mu and q(h) = h'Vh/2,
%         Proposition 2 of the paper gives
%
%            E[X_1^nu_1...X_m^nu_m] = sum_h w(h) F(t(h),q(h)),         (1)
%            F(t,q) = sum_{j=0}^{floor(s/2)} t^(s-2j)*q^j/((s-2j)!j!),
%
%         where the sum is over h = (nu_1/2-x_1,...,nu_m/2-x_m),
%         0<=x_j<=nu_j, w(h) = prod_j (-1)^(x_j)*binom(nu_j,x_j), and
%         F(t,q) = E[Y^s]/s! for Y ~ N(t,2q).  The terms of (1) have
%         alternate signs and there can be a lot of cancellation.
%         However, sum_h w(h) g(h) = 0 for every polynomial g of degree
%         less than s, so (1) continues to hold when t^i is replaced by
%         ANY monic polynomial of degree i in t, and q^j is replaced by
%         ANY monic polynomial of degree j in q.  This program replaces
%         q^j by (q-c)^j with c = sum_j nu_j*V_jj/8 (the average of q(h)
%         under the weights |w(h)|), or it replaces t^i and q^j by the
%         monic orthogonal polynomials with respect to the weights |w(h)|
%         (see private/pmpilot.m).  Both choices make the terms much
%         smaller than the ones in (1), so far fewer digits are lost in
%         the summation.
%
function [y,relerr] = prodmomnc(mu,V,ii,nu,method)
if nargin<4||isempty(nu)
   nu = ones(size(ii));
end
if nargin<5
   method = 'auto';
end
%
%  Combine the indices that are repeated and drop the ones with a zero power
%
[ii,~,ic] = unique(ii(:)');
nu = accumarray(ic(:),nu(:))';
ii = ii(nu>0);
nu = nu(nu>0);
mu = mu(ii);
mu = mu(:);
V = V(ii,ii);            % Extract only the relevant part of mu and V
V = (V+V')/2;
dv = diag(V)';
if any(dv<0)
   error('prodmomnc:negvar','V has a negative diagonal element.')
end
%
%  A variable with zero variance is a constant
%
y0 = prod(mu(dv==0)'.^nu(dv==0));
mu = mu(dv>0);
V = V(dv>0,dv>0);
nu = nu(dv>0);
dv = dv(dv>0);
m = length(nu);
s = sum(nu);
relerr = 0;
if s==0||y0==0
   y = y0;
   return
end
%
%  Use univariate normal results
%
if m==1
   z0 = 0;
   z1 = 1;
   for i=0:s-1
       y = mu*z1+i*V*z0;
       z0 = z1;
       z1 = y;
   end
   y = y0*y;
   return
end
%
%  Scale the variables by powers of 2 (which does not introduce any
%  rounding errors) so that their variances are between 0.5 and 2.
%
[~,e] = log2(dv);
e = floor(e/2);
sc = pow2(-e);
V = V.*(sc'*sc);
mu = mu.*sc';
e = sum(e.*nu);
[nu,inu] = sort(nu,2,'descend');
mu = mu(inu);
V = V(inu,inu);
%
%  Choose the polynomials
%
c = (nu*diag(V))/8;
orth = false;
switch lower(method)
   case 'plain'
      c = 0;
   case 'shift'
   case {'orth','auto'}
      [al,be,gain,bm] = pmpilot(V,nu,c,mu);
      orth = strcmpi(method,'orth')||gain>10||(gain>2&&prod(nu+1)<=2^16);
   otherwise
      error('prodmomnc:method','Unknown method.')
end
%
%  The last mi variables form the inner block, which is vectorized.
%  The first mo variables are dealt with by a loop.
%
mi = find(cumprod(nu(m:-1:1)+1)<=2^13,1,'last');
if isempty(mi)
   mi = 1;
end
mo = m-mi;
io = 1:mo;
in = mo+1:m;
[H,w] = pgrid(nu(in));
cI = sum((H*V(in,in)).*H,2)/2-c;
tI = H*mu(in);
VOO = V(io,io)/2;
VIO = V(in,io);
muo = mu(io);
nuo = nu(io);
bn = cell(1,mo);
for j=1:mo
    bn{j} = round(cumprod([1 (nuo(j):-1:1)./(1:nuo(j))])).*(-1).^(0:nuo(j));
end
est = nargout>1;
if est
   hmax = max(abs(H),[],1);
   cmax = max(abs(cI))+c;
   tmax = max(abs(tI));
   r0 = 0;
   r1 = 0;
end
%
%  By symmetry, we only need to go through half of the points
%
NO = prod(nuo+1);
nhalf = floor(NO/2);
x = zeros(1,mo);
h = nuo/2;
y = 0;
yc = 0;
for i=1:nhalf+rem(NO,2)
    wo = 2;
    if i>nhalf
       wo = 1;
    end
    for j=1:mo
        wo = wo*bn{j}(x(j)+1);
    end
    a = h*VOO*h';
    b = VIO*h';
    q = cI+(a+H*b);
    t = tI+h*muo;
    if est
       if orth
          [F,G,Fq,Ft] = pmorthnc(t,q,s,al,be,bm);
       else
          [F,G,Fq,Ft] = pmpownc(t,q,s);
       end
       Fq = (abs(a)+hmax*abs(b)+cmax)*Fq;
       Ft = (abs(h*muo)+tmax)*Ft;
       r0 = hypot(r0,wo*norm([w.*Fq; w.*Ft]));
       r1 = hypot(r1,wo*norm(w.*G));
    elseif orth
       F = pmorthnc(t,q,s,al,be,bm);
    else
       F = pmpownc(t,q,s);
    end
%
%   Add wo*sum(w.*F) to y, the rounding error of the addition goes to yc
%
    z = wo*(w'*F);
    u = y+z;
    v = u-y;
    yc = yc+((y-(u-v))+(z-v));
    y = u;
    j = mo;
    while j>0&&x(j)==nuo(j)
       x(j) = 0;
       h(j) = nuo(j)/2;
       j = j-1;
    end
    if j>0
       x(j) = x(j)+1;
       h(j) = h(j)-1;
    end
end
y = y+yc;
if est
   relerr = 10*eps*hypot(r0,s*r1)/abs(y);
   if r0+r1==0
      relerr = 0;
   end
end
y = y0*pow2(y,e);
