%
% prodmomncq.m		Date: 6/4/2023
% This Matlab program computes the product moment of X_{i_1}^{nu_1}X_{i_2}^{nu_2}...X_{i_m}^{nu_m},
% where X_{i_j} are elements from X ~ N(mu,V).  It calls an external Fortran program
% to do the computations in quadruple precision.
% V only needs to be positive semidefinite.
% mu: mean of X
% V: variance-covariance matrix of X
% ii: vector of i_j
% nu: power of X_{i_j} 
% Usage: prodmomncq(mu,V,[i1 i2 ... ir],[nu1 nu2 ... nur])
% Example: To get E[X_2X_4^3X_7^2], use prodmomncq(mu,V,[2 4 7],[1 3 2])
%
function y = prodmomncq(mu,V,ii,nu);
if nargin<4
   nu = ones(size(ii));
end
s = sum(nu);
if s==0
   y = 1;
   return
end
nuz = nu==0;
nu(nuz) = [];
ii(nuz) = [];
m = length(ii);
mu = mu(ii);
V = V(ii,ii);
%
%  Use univariate normal results
%
if m==1
   y0 = 0;
   y1 = 1;
   for i=0:s-1
       y = mu*y1+i*V*y0;
       y0 = y1;
       y1 = y;
   end
   return
end
%
%  Use bivariate normal results when there are only two distinct indices
%
if m==2
   z1 = ones(nu(1)+1,1);
   z1(2) = mu(1);
   for i=3:nu(1)+1
       z1(i) = (mu(1)*z1(i-1)+V(1,1)*z1(i-2))/(i-1);
   end
   z2 = ones(nu(2)+1,1);
   z2(2) = mu(2);
   for i=3:nu(2)+1
       z2(i) = (mu(2)*z2(i-1)+V(2,2)*z2(i-2))/(i-1);
   end
   ss = min(nu);
   y = prod(factorial(nu))*sum(cumprod([1; V(1,2)./[1:ss]']).*z1(end:-1:end-ss).*z2(end:-1:end-ss));
   return  
end
%
%  Regular case
%
[nu,inu] = sort(nu,2,'descend');
mu = mu(inu);
V = V(inu,inu);          % Extract only the relevant part of V
y = pmomncq(mu,V,nu);

