%
% prodmomncq.m		Date: 11/24/2026
% This Matlab program computes the product moment of X_{i_1}^{nu_1}X_{i_2}^{nu_2}...X_{i_m}^{nu_m},
% where X_{i_j} are elements from X ~ N(mu,V).  It is the same as
% prodmomnc.m but all the computations are done in double-double arithmetic
% (about 32 significant digits, which is comparable to quadruple
% precision), so it is slower but it can afford to lose 16 more digits to
% cancellation.  The double-double arithmetic is written in Matlab (see the
% folder private), no external Fortran program is needed.
% V only needs to be positive semidefinite.
% mu: mean of X
% V: variance-covariance matrix of X
% ii: vector of i_j
% nu: power of X_{i_j} (the default is a vector of ones), sum(nu)<=170
% method: 'auto'  (default) the program chooses between 'orth' and 'shift'
%         'orth'  use orthogonal polynomials of h'mu and h'Vh (most accurate)
%         'shift' use powers of h'mu and h'Vh-c (fastest)
%         'plain' use powers of h'mu and h'Vh, i.e., the identity as it is
%                 given in the paper (least accurate, for comparison only)
% y: the product moment (rounded to double precision)
% relerr: an estimate of the relative error of y that is due to roundoff
%         errors (before y is rounded to double precision)
% Reference: Kan (2008) From Moments of Sum to Moments of Product,
%            Journal of Multivariate Analysis 99, 542-554.
% Usage: prodmomncq(mu,V,[i1 i2 ... ir],[nu1 nu2 ... nur])
% Example: To get E[X_2X_4^3X_7^2], use prodmomncq(mu,V,[2 4 7],[1 3 2])
% Method: See prodmomnc.m.  In this program, (ah,al) stands for the
%         double-double number ah+al.
%
function [y,relerr] = prodmomncq(mu,V,ii,nu,method)
if nargin<4||isempty(nu)
   nu = ones(size(ii));
end
if nargin<5
   method = 'auto';
end
%
%  Combine the indices that are repeated and drop the ones with a zero power
%
[ii,~,ic] = unique(ii(:)');
nu = accumarray(ic(:),nu(:))';
ii = ii(nu>0);
nu = nu(nu>0);
mu = mu(ii);
mu = mu(:);
V = V(ii,ii);            % Extract only the relevant part of mu and V
V = (V+V')/2;
dv = diag(V)';
if any(dv<0)
   error('prodmomncq:negvar','V has a negative diagonal element.')
end
%
%  A variable with zero variance is a constant
%
y0 = prod(mu(dv==0)'.^nu(dv==0));
mu = mu(dv>0);
V = V(dv>0,dv>0);
nu = nu(dv>0);
dv = dv(dv>0);
m = length(nu);
s = sum(nu);
relerr = 0;
if s==0||y0==0
   y = y0;
   return
end
if s>170
   error('prodmomncq:toolarge','The sum of the powers cannot exceed 170.')
end
k = floor(s/2);
%
%  Scale the variables by powers of 2 (which does not introduce any
%  rounding errors) so that their variances are between 0.5 and 2.
%
[~,e] = log2(dv);
e = floor(e/2);
sc = pow2(-e);
V = V.*(sc'*sc);
mu = mu.*sc';
e = sum(e.*nu);
[nu,inu] = sort(nu,2,'descend');
mu = mu(inu);
V = V(inu,inu);
%
%  Choose the polynomials
%
c = (nu*diag(V))/8;
orth = false;
switch lower(method)
   case 'plain'
      c = 0;
   case 'shift'
   case {'orth','auto'}
      [al,be,gain,bm] = pmpilot(V,nu,c,mu);
      orth = strcmpi(method,'orth')||gain>1e4||(gain>2&&prod(nu+1)<=2^16);
   otherwise
      error('prodmomncq:method','Unknown method.')
end
if orth
%
%  (Ch(j+1),Cl(j+1)) = s!/((s-2j)!j!)
%
   Ch = ones(1,k+1);
   Cl = zeros(1,k+1);
   for j=1:k
       [th,tl] = ddmuld(Ch(j),Cl(j),(s-2*j+2)*(s-2*j+1));
       Ch(j+1) = th/j;
       [ph,pl] = twoprod(Ch(j+1),j);
       Cl(j+1) = (((th-ph)-pl)+tl)/j;
   end
end
%
%  The last mi variables form the inner block, which is vectorized.
%  The first mo variables are dealt with by a loop.
%
mi = find(cumprod(nu(m:-1:1)+1)<=2^13,1,'last');
if isempty(mi)
   mi = 1;
end
mo = m-mi;
io = 1:mo;
in = mo+1:m;
nui = nu(in);
nuo = nu(io);
[H,w,wl] = pgrid(nui);
N = length(w);
%
%  The weights of the outer loop.  When they can be larger than 2^53, they
%  are computed as double-double numbers.
%
bnh = cell(1,mo);
bnl = cell(1,mo);
bigp = 2;
for j=1:mo
    [bnh{j},bnl{j}] = ddbinom(nuo(j));
    bigp = bigp*max(abs(bnh{j}));
end
bigp = bigp>=2^53;
bigw = any(wl~=0);
pl = 0;
%
%  (cIh,cIl) = h_I'*V_II*h_I/2-c and (tIh,tIl) = h_I'*mu_I for all the
%  points of the inner block
%
cIh = -c*ones(N,1);
cIl = zeros(N,1);
tIh = zeros(N,1);
tIl = tIh;
for i=1:mi
    [th,tl] = twoprod(H(:,i),mu(in(i)));
    [tIh,tIl] = ddadd(tIh,tIl,th,tl);
    for j=i:mi
        f = 1;
        if i==j
           f = 0.5;
        end
        [th,tl] = twoprod(f*H(:,i).*H(:,j),V(in(i),in(j)));
        [cIh,cIl] = ddadd(cIh,cIl,th,tl);
    end
end
hv = cell(1,mi);
for j=1:mi
    hv{j} = nui(j)/2-(0:nui(j))';
end
%
%  (gh,gl) = V_OO*h_O, (bh,bl) = V_IO*h_O, (ah,al0) = h_O'*V_OO*h_O/2,
%  (toh,tol) = h_O'*mu_O for the first point of the outer loop
%
VOO = V(io,io);
VIO = V(in,io);
muo = mu(io);
h = nuo/2;
gh = zeros(mo,1);
gl = gh;
bh = zeros(mi,1);
bl = bh;
for j=1:mo
    [th,tl] = twoprod(VOO(:,j),h(j));
    [gh,gl] = ddadd(gh,gl,th,tl);
    [th,tl] = twoprod(VIO(:,j),h(j));
    [bh,bl] = ddadd(bh,bl,th,tl);
end
[th,tl] = ddmuld(gh,gl,h'/2);
[ah,al0] = ddsum([th; 0],[tl; 0]);
[th,tl] = twoprod(muo,h');
[toh,tol] = ddsum([th; 0],[tl; 0]);
est = nargout>1;
if est
   aw = abs(w);
   hmax = nui/2;
   cmax = max(abs(cIh))+c;
   tmax = max(abs(tIh));
   r0 = 0;
   r1 = 0;
end
%
%  By symmetry, we only need to go through half of the points.  The points
%  of the outer loop are visited in the order of a Gray code, so that only
%  one element of h_O changes (by one) in each step.
%
x = zeros(1,mo);
d = ones(1,mo);
kk = [cumprod(nuo+1,'reverse') 1];
nhalf = fix(kk(1)/2);
p = 2;
yh = 0;
yl = 0;
for i=1:nhalf+rem(kk(1),2)
    if i>nhalf
       p = p/2;
    end
    if bigp
       p = 1+(i<=nhalf);
       pl = 0;
       for j=1:mo
           [p,pl] = ddmul(p,pl,bnh{j}(x(j)+1),bnl{j}(x(j)+1));
       end
    end
%
%   (qh,ql) = a+H_I*b+cI and (th,tl) = h'mu for all the points of the
%   inner block
%
    qh = ah;
    ql = al0;
    for j=1:mi
        [uh,ul] = ddmuld(bh(j),bl(j),hv{j});
        [qh,ql] = ddadd(qh,ql,uh,ul);
        qh = reshape(qh,1,[]);
        ql = reshape(ql,1,[]);
    end
    [qh,ql] = ddadd(qh',ql',cIh,cIl);
    [th,tl] = ddadd(tIh,tIl,toh,tol);
    if orth
%
%      (Rh,Rl)(:,j+1) = rho_{s-2j}(t)
%
       Rh = zeros(N,k+1);
       Rl = Rh;
       r0h = zeros(N,1);
       r0l = r0h;
       r1h = ones(N,1);
       r1l = r0h;
       if rem(s,2)==0
          Rh(:,k+1) = r1h;
       end
       for j=1:s
           [uh,ul] = ddmul(th,tl,r1h,r1l);
           if bm(j)~=0
              [r0h,r0l] = ddmuld(r0h,r0l,-bm(j));
              [uh,ul] = ddadd(uh,ul,r0h,r0l);
           end
           r0h = r1h;
           r0l = r1l;
           r1h = uh;
           r1l = ul;
           if rem(s-j,2)==0
              Rh(:,(s-j)/2+1) = r1h;
              Rl(:,(s-j)/2+1) = r1l;
           end
       end
%
%      (zh,zl) = sum_j C_j*rho_{s-2j}(t)*pi_j(q)
%
       zh = Rh(:,1);
       zl = Rl(:,1);
       r0h = zeros(N,1);
       r0l = r0h;
       r1h = ones(N,1);
       r1l = r0h;
       for j=1:k
           [uh,ul] = ddaddd(qh,ql,-al(j));
           [uh,ul] = ddmul(uh,ul,r1h,r1l);
           if be(j)~=0
              [r0h,r0l] = ddmuld(r0h,r0l,-be(j));
              [uh,ul] = ddadd(uh,ul,r0h,r0l);
           end
           r0h = r1h;
           r0l = r1l;
           r1h = uh;
           r1l = ul;
           [uh,ul] = ddmul(Rh(:,j+1),Rl(:,j+1),r1h,r1l);
           [uh,ul] = ddmul(uh,ul,Ch(j+1),Cl(j+1));
           [zh,zl] = ddadd(zh,zl,uh,ul);
       end
    else
%
%      (zh,zl) = M_s, where M_j = E[Y^j] for Y ~ N(t,2q), by using
%      M_j = (t^2+(2j-3)*2q)*M_{j-2}-(j-2)*(j-3)*(2q)^2*M_{j-4}
%
       j0 = rem(s,2);
       [uh,ul] = ddmul(th,tl,th,tl);
       [vh,vl] = ddmul(qh,ql,qh,ql);
       vh = 4*vh;
       vl = 4*vl;
       [r1h,r1l] = ddmuld(qh,ql,2*(2*j0+1));
       [uh,ul] = ddadd(uh,ul,r1h,r1l);
       r0h = zeros(N,1);
       r0l = r0h;
       if j0==0
          zh = ones(N,1);
          zl = r0h;
       else
          zh = th;
          zl = tl;
       end
       for j=j0+2:2:s
           [r1h,r1l] = ddmul(uh,ul,zh,zl);
           if j>3
              [r0h,r0l] = ddmuld(r0h,r0l,-(j-2)*(j-3));
              [r0h,r0l] = ddmul(r0h,r0l,vh,vl);
              [r1h,r1l] = ddadd(r1h,r1l,r0h,r0l);
           end
           r0h = zh;
           r0l = zl;
           zh = r1h;
           zl = r1l;
           [uh,ul] = ddadd(uh,ul,8*qh,8*ql);
       end
    end
    if est
       if orth
          [~,G,Fq,Ft] = pmorthnc(th,qh,s,al,be,bm);
       else
          [~,G,Fq,Ft] = pmpownc(th,qh,s);
       end
       Fq = (abs(ah)+hmax*abs(bh)+cmax)*Fq;
       Ft = (abs(toh)+tmax)*Ft;
       r0 = hypot(r0,p*norm([aw.*Fq; aw.*Ft]));
       r1 = hypot(r1,p*norm(aw.*G));
    end
    if bigw
       [zh,zl] = ddmul(zh,zl,w,wl);
    else
       [zh,zl] = ddmuld(zh,zl,w);
    end
    [zh,zl] = ddsum(zh,zl);
    [zh,zl] = ddmul(zh,zl,p,pl);
    [yh,yl] = ddadd(yh,yl,zh,zl);
    if i>nhalf||mo==0
       break
    end
    j1 = mo;
    while rem(i,kk(j1))==0
       j1 = j1-1;
    end
    x(j1) = x(j1)+d(j1);
    if ~bigp
       if d(j1)==1
          p = -round(p*(nuo(j1)+1-x(j1))/x(j1));
       else
          p = -round(p*(x(j1)+1)/(nuo(j1)-x(j1)));
       end
    end
%
%   Update a, g, b, and h_O'*mu_O for the change of h_O(j1) to
%   h_O(j1)-d(j1)
%
    [ah,al0] = ddadd(ah,al0,-d(j1)*gh(j1),-d(j1)*gl(j1));
    [ah,al0] = ddaddd(ah,al0,VOO(j1,j1)/2);
    [gh,gl] = ddaddd(gh,gl,-d(j1)*VOO(:,j1));
    [bh,bl] = ddaddd(bh,bl,-d(j1)*VIO(:,j1));
    [toh,tol] = ddaddd(toh,tol,-d(j1)*muo(j1));
    if x(j1)==0||x(j1)==nuo(j1)
       d(j1) = -d(j1);
    end
end
yh = yh/prod(1:s);
yl = yl/prod(1:s);
if est
   relerr = 10*2^(-105)*hypot(r0,s*r1)/abs(yh);
   if r0+r1==0
      relerr = 0;
   end
end
y = y0*pow2(yh+yl,e);
