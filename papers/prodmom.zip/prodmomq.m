%
% prodmomq.m		Date: 11/24/2026
% This Matlab program computes the product moment of X_{i_1}^{nu_1}X_{i_2}^{nu_2}...X_{i_m}^{nu_m},
% where X_{i_j} are elements from X ~ N(0_n,V).  It is the same as prodmom.m
% but all the computations are done in double-double arithmetic (about 32
% significant digits, which is comparable to quadruple precision), so it is
% slower but it can afford to lose 16 more digits to cancellation.  The
% double-double arithmetic is written in Matlab (see the folder private),
% no external Fortran program is needed.
% V only needs to be positive semidefinite.
% V: variance-covariance matrix of X
% ii: vector of i_j
% nu: power of X_{i_j} (the default is a vector of ones)
% method: 'auto'  (default) the program chooses between 'orth' and 'shift'
%         'orth'  use an orthogonal polynomial of h'Vh (most accurate)
%         'shift' use a power of h'Vh-c (fastest)
%         'plain' use a power of h'Vh, i.e., the identity as it is given
%                 in the paper (least accurate, for comparison only)
% y: the product moment (rounded to double precision)
% relerr: an estimate of the relative error of y that is due to roundoff
%         errors (before y is rounded to double precision)
% Reference: Kan (2008) From Moments of Sum to Moments of Product,
%            Journal of Multivariate Analysis 99, 542-554.
% Usage: prodmomq(V,[i1 i2 ... ir],[nu1 nu2 ... nur])
% Example: To get E[X_2X_4^3X_7^2], use prodmomq(V,[2 4 7],[1 3 2])
% Method: See prodmom.m.  In this program, (ah,al) stands for the
%         double-double number ah+al.
%
function [y,relerr] = prodmomq(V,ii,nu,method)
if nargin<3||isempty(nu)
   nu = ones(size(ii));
end
if nargin<4
   method = 'auto';
end
%
%  Combine the indices that are repeated and drop the ones with a zero power
%
[ii,~,ic] = unique(ii(:)');
nu = accumarray(ic(:),nu(:))';
ii = ii(nu>0);
nu = nu(nu>0);
s = sum(nu);
relerr = 0;
if s==0
   y = 1;
   return
end
if rem(s,2)==1
   y = 0;
   return
end
V = V(ii,ii);            % Extract only the relevant part of V
V = (V+V')/2;
dv = diag(V)';
if any(dv<0)
   error('prodmomq:negvar','V has a negative diagonal element.')
end
if any(dv==0)            % a variable with zero variance is identically zero
   y = 0;
   return
end
m = length(ii);
k = s/2;
%
%  Scale the variables by powers of 2 (which does not introduce any
%  rounding errors) so that their variances are between 0.5 and 2.
%
[~,e] = log2(dv);
e = floor(e/2);
sc = pow2(-e);
V = V.*(sc'*sc);
e = sum(e.*nu);
[nu,inu] = sort(nu,2,'descend');
V = V(inu,inu);
%
%  Choose the polynomial
%
c = (nu*diag(V))/8;
orth = false;
switch lower(method)
   case 'plain'
      c = 0;
   case 'shift'
   case {'orth','auto'}
      [al,be,gain] = pmpilot(V,nu,c);
      orth = strcmpi(method,'orth')||gain>1e4||(gain>2&&prod(nu+1)<=2^16);
   otherwise
      error('prodmomq:method','Unknown method.')
end
%
%  The last mi variables form the inner block, which is vectorized.
%  The first mo variables are dealt with by a loop.
%
mi = max(find(cumprod(nu(m:-1:1)+1)<=2^13,1,'last'),1);
if isempty(mi)
   mi = 1;
end
mo = m-mi;
io = 1:mo;
in = mo+1:m;
nui = nu(in);
nuo = nu(io);
[H,w,wl] = pgrid(nui);
N = length(w);
%
%  The weights of the outer loop.  When they can be larger than 2^53, they
%  are computed as double-double numbers.
%
bnh = cell(1,mo);
bnl = cell(1,mo);
bigp = 2;
for j=1:mo
    [bnh{j},bnl{j}] = ddbinom(nuo(j));
    bigp = bigp*max(abs(bnh{j}));
end
bigp = bigp>=2^53;
bigw = any(wl~=0);
pl = 0;
%
%  (cIh,cIl) = h_I'*V_II*h_I/2-c for all the points of the inner block
%
cIh = -c*ones(N,1);
cIl = zeros(N,1);
for i=1:mi
    for j=i:mi
        f = 1;
        if i==j
           f = 0.5;
        end
        [th,tl] = twoprod(f*H(:,i).*H(:,j),V(in(i),in(j)));
        [cIh,cIl] = ddadd(cIh,cIl,th,tl);
    end
end
hv = cell(1,mi);
for j=1:mi
    hv{j} = nui(j)/2-(0:nui(j))';
end
%
%  (gh,gl) = V_OO*h_O, (bh,bl) = V_IO*h_O, (ah,al) = h_O'*V_OO*h_O/2
%  for the first point of the outer loop
%
VOO = V(io,io);
VIO = V(in,io);
h = nuo/2;
gh = zeros(mo,1);
gl = gh;
bh = zeros(mi,1);
bl = bh;
for j=1:mo
    [th,tl] = twoprod(VOO(:,j),h(j));
    [gh,gl] = ddadd(gh,gl,th,tl);
    [th,tl] = twoprod(VIO(:,j),h(j));
    [bh,bl] = ddadd(bh,bl,th,tl);
end
[th,tl] = ddmuld(gh,gl,h'/2);
[ah,al0] = ddsum([th; 0],[tl; 0]);
est = nargout>1;
if est
   aw = abs(w);
   hmax = nui/2;
   cmax = max(abs(cIh))+c;
   r0 = 0;
   r1 = 0;
end
%
%  By symmetry, we only need to go through half of the points.  The points
%  of the outer loop are visited in the order of a Gray code, so that only
%  one element of h_O changes (by one) in each step.
%
x = zeros(1,mo);
d = ones(1,mo);
kk = [cumprod(nuo+1,'reverse') 1];
nhalf = fix(kk(1)/2);
p = 2;
yh = 0;
yl = 0;
for i=1:nhalf+rem(kk(1),2)
    if i>nhalf
       p = p/2;
    end
    if bigp
       p = 1+(i<=nhalf);
       pl = 0;
       for j=1:mo
           [p,pl] = ddmul(p,pl,bnh{j}(x(j)+1),bnl{j}(x(j)+1));
       end
    end
%
%   (qh,ql) = a+H_I*b+cI for all the points of the inner block
%
    qh = ah;
    ql = al0;
    for j=1:mi
        [th,tl] = ddmuld(bh(j),bl(j),hv{j});
        [qh,ql] = ddadd(qh,ql,th,tl);
        qh = reshape(qh,1,[]);
        ql = reshape(ql,1,[]);
    end
    [qh,ql] = ddadd(qh',ql',cIh,cIl);
    if orth
       th = ones(N,1);
       tl = zeros(N,1);
       [zh,zl] = ddaddd(qh,ql,-al(1));
       for j=2:k
           [uh,ul] = ddaddd(qh,ql,-al(j));
           [uh,ul] = ddmul(uh,ul,zh,zl);
           [th,tl] = ddmuld(th,tl,-be(j));
           [uh,ul] = ddadd(uh,ul,th,tl);
           th = zh;
           tl = zl;
           zh = uh;
           zl = ul;
       end
    else
       [th,tl] = ddpow(qh,ql,k-1);
       [zh,zl] = ddmul(th,tl,qh,ql);
    end
    if est
       if orth        % derivative of the polynomial (in double precision)
          t0 = zeros(N,1);
          th = ones(N,1);
          d0 = t0;
          d1 = t0;
          for j=1:k
              d2 = th+(qh-al(j)).*d1-be(j)*d0;
              t1 = (qh-al(j)).*th-be(j)*t0;
              t0 = th;
              th = t1;
              d0 = d1;
              d1 = d2;
          end
          th = d1/k;
       end
       r0 = hypot(r0,p*(abs(ah)+hmax*abs(bh)+cmax)*norm(aw.*th));
       r1 = hypot(r1,p*norm(aw.*zh));
    end
    if bigw
       [zh,zl] = ddmul(zh,zl,w,wl);
    else
       [zh,zl] = ddmuld(zh,zl,w);
    end
    [zh,zl] = ddsum(zh,zl);
    [zh,zl] = ddmul(zh,zl,p,pl);
    [yh,yl] = ddadd(yh,yl,zh,zl);
    if i>nhalf||mo==0
       break
    end
    j1 = mo;
    while rem(i,kk(j1))==0
       j1 = j1-1;
    end
    x(j1) = x(j1)+d(j1);
    if ~bigp
       if d(j1)==1
          p = -round(p*(nuo(j1)+1-x(j1))/x(j1));
       else
          p = -round(p*(x(j1)+1)/(nuo(j1)-x(j1)));
       end
    end
%
%   Update a, g, and b for the change of h_O(j1) to h_O(j1)-d(j1)
%
    [ah,al0] = ddadd(ah,al0,-d(j1)*gh(j1),-d(j1)*gl(j1));
    [ah,al0] = ddaddd(ah,al0,VOO(j1,j1)/2);
    [gh,gl] = ddaddd(gh,gl,-d(j1)*VOO(:,j1));
    [bh,bl] = ddaddd(bh,bl,-d(j1)*VIO(:,j1));
    if x(j1)==0||x(j1)==nuo(j1)
       d(j1) = -d(j1);
    end
end
if est
   relerr = 10*2^(-105)*k*hypot(r0,r1)/abs(yh);
   if r0+r1==0
      relerr = 0;
   end
end
y = pow2((yh+yl)/prod(1:k),e);
