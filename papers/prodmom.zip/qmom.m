%
% qmom.m		Date: 11/24/2026
% This Matlab program computes the cross moment of q_1^{s_1}...q_p^{s_p},
% where q_i = z'A_iz and z ~ N(0,V).
% V only needs to be positive semidefinite.
% V: n by n variance-covariance matrix of z
% A: n by n by p array, A(:,:,i) is A_i (it does not need to be symmetric)
% s: vector of s_i (the default is a vector of ones)
% y: the cross moment
% relerr: an estimate of the relative error of y that is due to roundoff
%         errors
% Reference: Kan (2008) From Moments of Sum to Moments of Product,
%            Journal of Multivariate Analysis 99, 542-554.
% Usage: qmom(V,A,s)
% Method: See private/qmcore.m.
%
function [y,relerr] = qmom(V,A,si)
if nargin<3
   si = [];
end
[y,relerr] = qmcore([],V,A,si,nargout>1);
