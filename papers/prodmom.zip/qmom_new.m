%
% qmom_new.m		Date: 1/11/2004
% This Matlab program computes the cross moment of q_i^{s_1}..q_i^{s_p},
% where q_i = z'A_iz and z \sim N(0,V).  It uses a new recursive algorithm
% to compute E[(z'Bz)^s] due to Brown (1986).
% Usage: qmom_new(V,A,s)
%
function y = qmom_new(V,A,si);
p = size(A,3);
if nargin==2
   si = ones(1,p);
end
s = sum(si);
if s==0
   y = 1;
   return
end
if p==1&&s==1
   y = trace(A*V);
   return
end
n = size(V,1);
L = chol(V);
for i=1:p
    A(:,:,i) = L*A(:,:,i)*L';
end
a = zeros(n,1);
if p==1
   d = 2*eig(A); 
   y = 1;
   for j=1:s
       a = d.*(y+a);
       y = sum(a)/(2*j);
   end
   y = factorial(s)*y;
   return
end
%
%   Convert moment of product to moments of sum
%
% Sorting of si is to reduce the number of updates,
% it is really not necessary.
[si,inu] = sort(si,2,'descend');  
ls = length(si);
p = 2;
x = zeros(1,ls);
d = ones(1,ls);
kk = cumprod(si+1,"reverse");
B = 0.5*si(1)*A(:,:,inu(1));
for i=2:ls
    B = B+0.5*si(i)*A(:,:,inu(i));
end
y = 0;
for i=1:fix(kk(1)/2)
%
%   This part computes E[(z'Bz)^s]/s!, where B=x_1*A_1+...x_p*A_p
%   where z ~ N(0_n,V).  
%
    d0 = eig((B+B'));   % make it symmetric to avoid numerical errors
    y1 = 1;
    a = zeros(n,1);
    for j=1:s
        a = d0.*(y1+a);
        y1 = sum(a)/(2*j);
    end
    y = y+p*y1;
    j1 = ls;
    while rem(i,kk(j1))==0
       j1 = j1-1;
    end
    x(j1) = x(j1)+d(j1);
    if d(j1)==1
       p = -round(p*(si(j1)+1-x(j1))/x(j1));    
       B = B-A(:,:,inu(j1));
    else
       p = -round(p*(x(j1)+1)/(si(j1)-x(j1)));
       B = B+A(:,:,inu(j1));
    end
    if x(j1)==0||x(j1)==si(j1)
       d(j1) = -d(j1);
    end
end
