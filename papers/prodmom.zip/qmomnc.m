%
% qmomnc.m		Date: 11/24/2026
% This Matlab program computes the cross moment of q_1^{s_1}...q_p^{s_p},
% where q_i = z'A_iz and z ~ N(mu,V).
% V only needs to be positive semidefinite.
% mu: n by 1 mean of z
% V: n by n variance-covariance matrix of z
% A: n by n by p array, A(:,:,i) is A_i (it does not need to be symmetric)
% s: vector of s_i (the default is a vector of ones)
% y: the cross moment
% relerr: an estimate of the relative error of y that is due to roundoff
%         errors
% Reference: Kan (2008) From Moments of Sum to Moments of Product,
%            Journal of Multivariate Analysis 99, 542-554.
% Usage: qmomnc(mu,V,A,s)
% Method: See private/qmcore.m.
%
function [y,relerr] = qmomnc(mu,V,A,si)
if nargin<4
   si = [];
end
[y,relerr] = qmcore(mu,V,A,si,nargout>1);
