%
% qmomnc_new.m		Date: 1/11/2004
% This Matlab program computes the cross moment of q_i^{s_1}..q_i^{s_p},
% where q_i = z'A_iz and z ~ N(mu,V).  It uses a new recursive algorithm
% to compute E[(z'Bz)^s] due to Brown (1986).
% Usage: qmomnc_new(mu,V,A,s)
%
function y = qmomnc_new(mu,V,A,si);
p = size(A,3);
if nargin==3
   si = ones(1,p);
end
s = sum(si);
if s==0
   y = 1;
   return
end
if p==1&&s==1
   y =  trace(A*(V+mu*mu'));
   return
end
n = size(V,1);
L = chol(V);
for i=1:p
    A(:,:,i) = L*A(:,:,i)*L';
end
mu = inv(L')*mu;
if p==1
   [Q,D] = eig(2*A);
   d = diag(D);
   delta = (Q'*mu).^2;
   q = zeros(n,1);
   h = q;
   y = 1;
   for j=1:s
       q = d.*(y+q);
       h = delta.*q+d.*h;
       y = sum(q+h)/(2*j);
   end
   y = factorial(si)*y;
   return
end
%
%   Convert moment of product to moments of sum
%
% Sorting of si is to reduce the number of updates,
% it is really not necessary.
%
[si,inu] = sort(si,2,'descend');  
ls = length(si);
p = 2;
x = zeros(1,ls);
d = ones(1,ls);
kk = cumprod(si+1,"reverse");
B = 0.5*si(1)*A(:,:,inu(1));
for i=2:ls
    B = B+0.5*si(i)*A(:,:,inu(i));
end
y = 0;
for i=1:fix(kk(1)/2)
%
%   This part computes E[(z'Bz)^s]/s!, where B=x_1*A_1+...x_p*A_p
%   where z ~ N(mu,V).  
%
    [Q,D] = eig(B+B');
    d0 = diag(D);
    delta = (Q'*mu).^2;
    q = zeros(n,1);
    h = q;
    y1 = 1;
    for j=1:s
        q = d0.*(y1+q);
        h = delta.*q+d0.*h;
        y1 = sum(q+h)/(2*j);
    end
    y = y+p*y1;
    j1 = ls;
    while rem(i,kk(j1))==0
       j1 = j1-1;
    end
    x(j1) = x(j1)+d(j1);
    if d(j1)==1
       p = -round(p*(si(j1)+1-x(j1))/x(j1));    
       B = B-A(:,:,inu(j1));
    else
       p = -round(p*(x(j1)+1)/(si(j1)-x(j1)));
       B = B+A(:,:,inu(j1));
    end
    if x(j1)==0||x(j1)==si(j1)
       d(j1) = -d(j1);
    end
end
