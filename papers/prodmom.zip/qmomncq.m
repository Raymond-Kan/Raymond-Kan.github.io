%
% qmomncq.m		Date: 1/11/2004
% This Matlab program computes the cross moment of q_i^{s_1}..q_i^{s_p},
% where q_i = z'A_iz and z \sim N(mu,V).  It calls an external Fortran
% program which makes use of quadruple precision for intermediate
% computations.
% Usage: qmomncq(mu,V,A,s)
%
function y = qmomncq(mu,V,A,si);
p = size(A,3);
if nargin==3
   si = ones(1,p);
end
L = chol(V);
for i=1:p
    A(:,:,i) = L*A(:,:,i)*L';
end
mu = inv(L')*mu;
% Sorting of si is to reduce the number of updates,
% it is not really necessary to do it.
[si inu] = sort(si,2,'descend');  
A = A(:,:,inu);
y = qmomncquad(mu,A,si);
