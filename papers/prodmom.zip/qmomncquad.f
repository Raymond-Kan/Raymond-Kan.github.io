#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*),prhs(*)
      integer nlhs,nrhs
      mwpointer mxgetpr,mxcreatedoublescalar
      mwsize mxgetnumberofdimensions,mxgetdimensions,m
      mwpointer x1,x2,x3,y
      mwsize dims(3)
      x1 = mxgetpr(prhs(1))  ! x1 is mu
      x2 = mxgetpr(prhs(2))  ! x2 is A
      x3 = mxgetpr(prhs(3))  ! x3 is s_i
C
C     dims(1) is n, dims(3) is p
C
      m = mxGetNumberOfDimensions(prhs(2))
      call mxCopyPtrToInteger8(mxGetDimensions(prhs(2)),dims,3)
      if (m.eq.2) dims(3) = 1
      plhs(1) = mxcreatedoublescalar(0)
      y = mxgetpr(plhs(1))
      call qmomnc(%val(y),%val(x1),%val(x2),%val(x3),dims(1),dims(3))
      return
      end


      SUBROUTINE QMOMNC(YD,MU,A,SIR,N,P)
      MWSIGNEDINDEX N
      INTEGER M,P
      INTEGER SI(:),X(:),D(:)
      INTEGER*8 P1,KK(:)
      REAL*8 YD,MU(N),A(N,N,P),SIR(P),B(:,:)
      ALLOCATABLE :: B,SI,X,D,KK
      REAL*16 Y,Y1
      ALLOCATE(B(N,N))
      ALLOCATE(SI(P))
C
C     Setting up variables
C
      SI = NINT(SIR)
      M = SUM(SI)
C
C     Quick return if m=0 or p=1
C
      IF (M.EQ.0) THEN
         YD = 1d0
         RETURN
      END IF
      Y = 0q0
      IF (P.EQ.1) THEN
         IF (M.EQ.1) THEN
            DO 134 I=1,N
  134       Y = Y+A(I,I,1)
            Y = Y+DOT_PRODUCT(MU,MATMUL(A(:,:,1),MU))
         ELSE
            B = 2d0*A(:,:,1)
            CALL TRS(Y,M,B,MU,N)
            DO 135 I=M,1,-1
  135       Y = Y*QFLOAT(I)
         END IF
         YD = Y             
         RETURN
      END IF
      ALLOCATE(X(P))
      ALLOCATE(D(P))
      ALLOCATE(KK(P))
      X = 0
      D = 1
      KK(P) = SI(P)+1
      DO 100 I=P-1,1,-1
  100 KK(I) = KK(I+1)*(SI(I)+1)
      P1 = 2
C
C     Create inital B
C
      B = SI(1)*A(:,:,1)
      DO 152 K=2,P
  152 B = B+SI(K)*A(:,:,K)
      DO 153 I=1,KK(1)/2
      CALL TRS(Y1,M,B,MU,N)
      Y = Y+QFLOAT(P1)*Y1
      DO 102 J1=P,1,-1
      IF (MOD(I,KK(J1)).NE.0) GOTO 200
  102 CONTINUE
  200 X(J1) = X(J1)+D(J1)
      IF (D(J1).EQ.1) THEN    
         P1 = -P1*(SI(J1)+1-X(J1))/X(J1)
         B = B-2*A(:,:,J1)
      ELSE
         P1 = -P1*(X(J1)+1)/(SI(J1)-X(J1))
         B = B+2*A(:,:,J1)
      END IF
      IF ((X(J1).EQ.0).OR.(X(J1).EQ.SI(J1))) D(J1)=-D(J1)
  153 CONTINUE
      YD = Y
      RETURN 
      END


      SUBROUTINE TRS(YQ,M,AA,MUD,N)
      MWSIGNEDINDEX N,LWORK,INFO
      INTEGER M
      REAL*8 AA(N,N),A(:),B(:,:),WORK(:),MUD(N),ETA(:)
      REAL*16 YQ,Y(:),T(:),AQ(:),DQ(:)
      ALLOCATABLE :: A,WORK,B,AQ,DQ,Y,T,ETA

      LWORK = 3*N
      ALLOCATE(A(N))
      ALLOCATE(WORK(LWORK))
      ALLOCATE(B(N,N))
      ALLOCATE(AQ(N))
      ALLOCATE(DQ(N))
      ALLOCATE(ETA(N))
      ALLOCATE(Y(M+1))
      ALLOCATE(T(M))
      B = AA
C
C     Call LAPACK dsyev to produce the eigenvalues
C
      CALL DSYEV('N','U',N,B,N,A,WORK,LWORK,INFO)
      AQ = A
      ETA = MUD
      Y(1) = 1q0
      DQ = 1q0
C
C     Start the recursion
C
      DO 132 I=1,M
      DQ = DQ*AQ
      ETA = MATMUL(AA,ETA)
      T(I) = SUM(DQ)+QFLOAT(I)*DOT_PRODUCT(ETA,MUD)
  132 Y(I+1) = DOT_PRODUCT(T(I:1:-1),Y(1:I))/QFLOAT(2*I)
      YQ = Y(M+1)
      RETURN
      END
