These are programs for my JMVA paper "From Moments of Sum to Moments of Product."
If you have questions, comments, or bug reports, please send them to 
Raymond.Kan@rotman.utoronto.ca

Raymond Kan
Rotman School of Management
University of Toronto

Version 2.0 is written entirely in Matlab.  The Fortran programs (and the mex
files) of the earlier versions are no longer needed.  The programs need Matlab
R2020b or later (R2023a or later is recommended, because qmom.m and qmomnc.m
are much faster when the function pageeig is available).

Note 1: The folder "private" must be kept under the folder of the main
programs.  It contains the helper functions that are shared by the main
programs (double-double arithmetic, generation of the points for the identity,
and the choice of the polynomials).

Note 2: The identity of the paper expresses a moment of product as an
alternating sum of moments of sum, say

   E[X_1^nu_1...X_m^nu_m] = (1/k!) sum_h w(h) q(h)^k,  q(h) = h'Vh/2, k = sum(nu)/2

for X ~ N(0,V).  The summation can lose many significant digits due to
cancellation, which is why the earlier versions used quadruple precision.
Version 2.0 deals with this problem in two ways.

(a) Better conditioned versions of the identity.  Since
    sum_h w(h) g(h) = 0 for every polynomial g of degree less than sum(nu),
    the identity continues to hold when q(h)^k is replaced by p(q(h)), where p
    is ANY monic polynomial of degree k.  The programs can use
       'plain': p(q) = q^k, i.e., the identity as it is given in the paper,
       'shift': p(q) = (q-c)^k, where c = sum_j nu_j*V_jj/8 is the average of
                q(h) under the weights |w(h)|,
       'orth':  the monic polynomial of degree k that is orthogonal to all
                polynomials of lower degree under the weights |w(h)|.  It
                minimizes sum_h |w(h)| p(q(h))^2.
    For the noncentral case, the powers of h'mu are also replaced by
    orthogonal polynomials.  'shift' costs the same as 'plain' but it
    typically loses a few digits less than 'plain'.  'orth' takes a few times
    longer but it loses very few digits (in my tests, it gives 12 or more
    correct digits in double precision for problems where 'plain' gives 5).
    By default ('auto'), the programs choose between 'orth' and 'shift'.

(b) Double-double arithmetic.  prodmomq.m and prodmomncq.m represent each
    number as the unevaluated sum of two doubles, which gives about 32
    significant digits (quadruple precision gives 34).  It is written in
    vectorized Matlab, and in my tests it is 3 to 6 times faster than the
    quadruple precision Fortran programs of the earlier versions.
    prodmomncq.m requires sum(nu)<=170.

In addition, the main programs return an estimate of the relative error of the
answer that is due to roundoff errors as a second output, e.g.,
[y,relerr] = prodmom(V,ii,nu).  The estimate is meant to be conservative (it is
typically 10 to 1000 times the actual error).  If relerr of prodmom.m is not
small enough, use prodmomq.m.

Note 3: The folder "doc" contains a note that explains how the formulas that
are used by the programs differ from the ones in the paper and why they are
numerically more stable (prodmom_note.pdf), and a user's manual
(prodmom_manual.pdf), together with their LaTeX sources.

Version 1.0: 2/15/2008, initial release.
Version 1.1: 4/30/2009, get rid of the function in qmom.m, qmom_new.m,
             qmomnc.m, and qmomnc_new.m.
Version 1.2: 11/14/2009, change the Fortran programs to work with
             both 32 bit and 64 bit Windows.  In addition, the mex1.m
             now links the BLAS and LAPACK from Matalb, reducing the
             need for external libraries.
Version 1.3: 6/20/2010, revise qmom_new.m and qmomnc_new.m based on a
             recursive algorithm of Brown (1986).
Version 1.4: 4/19/2015, fix a bug in prodmomd.m and prodmomq.m,
             revise prodmom.m and significantly improve prodmom_rec.m
             add prodmomnc.m and prodmomnc_rec.m.
Version 1.5: 6/6/2023, most of the program are rewritten by using the
             generalized Gray code for the loops of the index.  Add
             prodmomncd.m and prodmomncq.m.  mexw32 files are now removed 
             from the distribution because I no longer have a 32 bit Windows.
Version 1.6: 6/18/2023, prodmomnc.m, pmomncd.f, and pmomncq.f are updated
             by using a recursive algorithm for computing s-th moment of a
             normal random variable.
Version 2.0: 11/24/2026, all the programs are now in Matlab, the Fortran
             programs are removed.
             1. prodmom.m and prodmomnc.m are vectorized, and they use the
                better conditioned versions of the identity that are described
                in Note 2.  They are faster and far more accurate than the
                double precision Fortran programs prodmomd.m and prodmomncd.m,
                which are removed.
             2. prodmomq.m and prodmomncq.m now use double-double arithmetic
                instead of calling quadruple precision Fortran programs.
             3. The programs return an estimate of the relative error.
             4. Indices that are repeated are now combined, e.g.,
                prodmom(V,[1 1 2]) is computed as prodmom(V,[1 2],[2 1]).
             5. Fix a bug when a variable has zero variance (prodmom.m
                returned NaN when there were two variables).
             6. qmom.m and qmomnc.m are vectorized (they call pageeig once for
                a block of matrices instead of calling eig for each matrix),
                which makes them 3 to 4 times faster.  V can now be singular.
             7. Fix a bug in qmomnc.m, qmomq.m and qmomncq.m, which gave
                incorrect results when the matrices A_i are not symmetric.
             8. qmomq.m and qmomncq.m are removed.  They computed the
                eigenvalues in double precision and only did the subsequent
                computations in quadruple precision.  Since the errors of the
                eigenvalues are magnified by the cancellation in the same way
                as the other roundoff errors, they were not more accurate than
                qmom.m and qmomnc.m.
             9. qmom_new.m and qmomnc_new.m are removed, because the new
                qmom.m and qmomnc.m are faster.

prodmom.m: Moment of products of normal random variables z, with z distributed
           as N(0,V).  It makes use of the new identity.
prodmomq.m: Same as prodmom.m but the computations are done in double-double
            arithmetic.
prodmom_haf.m: Moment of products of normal random variables z, with z 
               distributed as N(0,V).  It uses Isserlis formula.
prodmom_rec.m: Moment of products of normal random variables z, with z 
               distributed as N(0,V).  It uses a recursive formula.  It is
               fast and numerically stable, but it needs to store prod(nu+1)
               numbers.
bivmom.m: Computes the product moment of x_1^{p_1}x_2^{p_2} when x_1 and x_2
          have standard bivariate normal distribution with correlation rho.

prodmomnc.m: Moment of products of normal random variables z, with z distributed
             as N(mu,V).  It makes use of the new identity.
prodmomncq.m: Same as prodmomnc.m but the computations are done in
              double-double arithmetic.
prodmomnc_rec.m: Moment of products of normal random variables z, with z 
                 distributed as N(mu,V).  It uses a recursive formula.

qmom.m: Moment of products of quadratic forms of N(0,V), using the new
        identity
qmomnc.m: Moment of products of quadratic forms of N(mu,V), using the new
          identity

check.m: Checks the programs against each other on random problems
test1.m: Compares the speed and accuracy of various versions of prodmom.m 
test1a.m: Compares the speed and accuracy of various versions of prodmomnc.m 
test2.m: Compares the speed and accuracy of prodmom.m and prodmomq.m for a
         large problem (it takes about two minutes)
test2a.m: Compares the speed and accuracy of prodmomnc.m and prodmomncq.m for a
          large problem (it takes about seven minutes)
test3.m: Speed of qmom.m
test4.m: Speed of qmomnc.m

doc/prodmom_note.tex, prodmom_note.pdf: Note on the methods of Version 2.0
doc/prodmom_manual.tex, prodmom_manual.pdf: User's manual
doc/fig_kappa.m, fig_kappa.pdf: Figure 1 of the note and the program that
                                produces it

private/pgrid.m: Generates the points h and the weights w(h) of the identity
private/pmpilot.m: Computes the orthogonal polynomials
private/pmpownc.m, private/pmorthnc.m: Evaluate the summand of the identity
                   for the noncentral case
private/qmcore.m: Does the computations for qmom.m and qmomnc.m
private/twosum.m, twoprod.m, ddadd.m, ddaddd.m, ddmul.m, ddmuld.m, ddpow.m,
        ddsum.m, ddbinom.m: Double-double arithmetic
