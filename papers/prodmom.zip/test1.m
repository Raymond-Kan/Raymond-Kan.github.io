rng('default')
s = 20;
x = randn(10*s,s);
V = (x'*x)./(10*s);
delete test1.out
diary test1.out
format long
fprintf('\nRepeated s_i, New Identity (Quadruple Precision)\n') 
fprintf('s_i = 4\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmomq(V,[1:5],4*ones(1,5));
toc
y
fprintf('\nRepeated s_i, New Identity\n') 
fprintf('s_i = 4\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmom(V,[1:5],4*ones(1,5));
toc
y
fprintf('\nRepeated s_i, Recursive Algorithm\n') 
fprintf('s_i = 4\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmom_rec(V,[1:5],4*ones(1,5));
toc
y
fprintf('Non-Repeated s_i, New Identity (Quadruple Precision)\n') 
fprintf('s_i = 1\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmomq(V,[1:s]);
toc
y
fprintf('\nNon-Repeated s_i, New Identity\n') 
fprintf('s_i = 1\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmom(V,[1:s]);
toc
y
fprintf('\nRepeated s_i, Recursive Algorithm\n') 
fprintf('s_i = 4\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmom_rec(V,[1:s]);
toc
y
fprintf('\nNon-Repeated s_i, Isserlis Formula\n') 
fprintf('s_i = 1\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmom_haf(V,[1:s]);
toc
y
diary off
