%
% test1.m: Compares the speed and the accuracy of various versions of
% prodmom.m
%
rng('default')
s = 20;
x = randn(10*s,s);
V = (x'*x)./(10*s);
if isfile('test1.out')
   delete test1.out
end
diary test1.out
format long
name = {'New Identity (Orthogonal Polynomial)','New Identity (Shifted Power)', ...
        'New Identity (As in the Paper)','New Identity (Double-Double)', ...
        'Recursive Algorithm'};
for j=1:2
    if j==1
       ii = 1:5;
       nu = 4*ones(1,5);
       fprintf('\nRepeated s_i: s_i = 4, s = %d\n',s)
    else
       ii = 1:s;
       nu = ones(1,s);
       fprintf('\nNon-Repeated s_i: s_i = 1, s = %d\n',s)
    end
    for i=1:5
        relerr = 0;
        tic
        switch i
           case 1
              [y,relerr] = prodmom(V,ii,nu,'orth');
           case 2
              [y,relerr] = prodmom(V,ii,nu,'shift');
           case 3
              [y,relerr] = prodmom(V,ii,nu,'plain');
           case 4
              [y,relerr] = prodmomq(V,ii,nu);
           case 5
              y = prodmom_rec(V,ii,nu);
        end
        t = toc;
        fprintf('%-38s y = %22.15e, relerr = %7.1e, time = %8.4f seconds\n',name{i},y,relerr,t)
    end
end
%
% Isserlis formula has (s-1)!! terms, so we use a smaller s
%
s = 12;
fprintf('\nNon-Repeated s_i: s_i = 1, s = %d\n',s)
tic
y = prodmom(V,1:s);
t = toc;
fprintf('%-38s y = %22.15e, time = %8.4f seconds\n','New Identity',y,t)
tic
y = prodmom_haf(V,1:s);
t = toc;
fprintf('%-38s y = %22.15e, time = %8.4f seconds\n','Isserlis Formula',y,t)
diary off
