%
% test1a.m: Compares the speed and the accuracy of various versions of
% prodmomnc.m
%
rng('default')
s = 20;
mu = randn(s,1);
x = randn(10*s,s);
V = (x'*x)./(10*s);
if isfile('test1a.out')
   delete test1a.out
end
diary test1a.out
format long
name = {'New Identity (Orthogonal Polynomial)','New Identity (Shifted Power)', ...
        'New Identity (As in the Paper)','New Identity (Double-Double)', ...
        'Recursive Algorithm'};
for j=1:2
    if j==1
       ii = 1:5;
       nu = 4*ones(1,5);
       fprintf('\nRepeated s_i: s_i = 4, s = %d\n',s)
    else
       ii = 1:s;
       nu = ones(1,s);
       fprintf('\nNon-Repeated s_i: s_i = 1, s = %d\n',s)
    end
    for i=1:5
        relerr = 0;
        tic
        switch i
           case 1
              [y,relerr] = prodmomnc(mu,V,ii,nu,'orth');
           case 2
              [y,relerr] = prodmomnc(mu,V,ii,nu,'shift');
           case 3
              [y,relerr] = prodmomnc(mu,V,ii,nu,'plain');
           case 4
              [y,relerr] = prodmomncq(mu,V,ii,nu);
           case 5
              y = prodmomnc_rec(mu,V,ii,nu);
        end
        t = toc;
        fprintf('%-38s y = %22.15e, relerr = %7.1e, time = %8.4f seconds\n',name{i},y,relerr,t)
    end
end
diary off
