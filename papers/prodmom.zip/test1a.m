rng('default')
s = 20;
mu = randn(s,1);
x = randn(10*s,s);
V = (x'*x)./(10*s);
delete test1a.out
diary test1a.out
format long
fprintf('\nRepeated s_i, New Identity (Quadruple Precision)\n') 
fprintf('s_i = 4\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmomncq(mu,V,[1:5],4*ones(1,5));
toc
y
fprintf('\nRepeated s_i, New Identity\n') 
fprintf('s_i = 4\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmomnc(mu,V,[1:5],4*ones(1,5));
toc
y
fprintf('\nRepeated s_i, Recursive Algorithm\n') 
fprintf('s_i = 4\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmomnc_rec(mu,V,[1:5],4*ones(1,5));
toc
y
fprintf('Non-Repeated s_i, New Identity (Quadruple Precision)\n') 
fprintf('s_i = 1\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmomncq(mu,V,[1:s]);
toc
y
fprintf('\nNon-Repeated s_i, New Identity\n') 
fprintf('s_i = 1\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmomnc(mu,V,[1:s]);
toc
y
fprintf('\nRepeated s_i, Recursive Algorithm\n') 
fprintf('s_i = 4\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmomnc_rec(mu,V,[1:s]);
toc
y
diary off
