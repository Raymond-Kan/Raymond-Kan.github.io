%
% test2.m: Compares the speed and the accuracy of prodmom.m and prodmomq.m
% for a large problem (2^29 terms for the non-repeated case)
%
rng('default')
s = 30;
x = randn(10*s,s);
V = (x'*x)./(10*s);
if isfile('test2.out')
   delete test2.out
end
diary test2.out
format long
name = {'Double Precision (Orthogonal Polynomial)','Double Precision (Shifted Power)', ...
        'Double Precision (As in the Paper)','Double-Double'};
for j=1:2
    if j==1
       ii = 1:5;
       nu = 6*ones(1,5);
       fprintf('\nRepeated s_i: s_i = 6, s = %d\n',s)
    else
       ii = 1:s;
       nu = ones(1,s);
       fprintf('\nNon-Repeated s_i: s_i = 1, s = %d\n',s)
    end
    for i=1:4
        tic
        switch i
           case 1
              [y,relerr] = prodmom(V,ii,nu,'orth');
           case 2
              [y,relerr] = prodmom(V,ii,nu,'shift');
           case 3
              [y,relerr] = prodmom(V,ii,nu,'plain');
           case 4
              [y,relerr] = prodmomq(V,ii,nu);
        end
        t = toc;
        fprintf('%-42s y = %22.15e, relerr = %7.1e, time = %8.3f seconds\n',name{i},y,relerr,t)
    end
end
diary off
