rng('default')
s = 30;
x = randn(10*s,s);
V = (x'*x)./(10*s);
delete test2.out
diary test2.out
format long
fprintf('\nRepeated s_i, Double Precision\n') 
fprintf('s_i = 6\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmomd(V,[1:5],6*ones(1,5));
toc
y
fprintf('\nRepeated s_i, Quadruple Precision\n') 
fprintf('s_i = 6\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmomq(V,[1:5],6*ones(1,5));
toc
y
fprintf('Non-Repeated s_i, Double Precision\n') 
fprintf('s_i = 1\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmomd(V,[1:s]);
toc
y
fprintf('\nNon-Repeated s_i, Quadruple Precision\n') 
fprintf('s_i = 1\n')
fprintf('s = %3.0f\n',s)
tic
y = prodmomq(V,[1:s]);
toc
y
diary off
