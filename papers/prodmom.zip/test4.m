rng('default')
s = 20;
p = 5;
n = 60;
A = zeros(n,n,p);
for i=1:p
    x = randn(20*n,n);
    A(:,:,i) = (x'*x)./(20*n);
end
x = randn(20*n,n);
V = (x'*x)./(20*n);
mu = randn(n,1);
delete test4.out
diary test4.out
format long
fprintf('\nRepeated s_i, New Identity\n') 
fprintf('s_i = 4\n')
fprintf('s = %3.0f\n',s)
tic
y = qmomnc(mu,V,A,[4 4 4 4 4]);
toc
y
fprintf('\nRepeated s_i, New Identity (Brown)\n') 
fprintf('s_i = 4\n')
fprintf('s = %3.0f\n',s)
tic
y = qmomnc_new(mu,V,A,[4 4 4 4 4]);
toc
y
fprintf('\nRepeated s_i, New Identity (Qaudruple Precision)\n') 
fprintf('s_i = 4\n')
fprintf('s = %3.0f\n',s)
tic
y = qmomncq(mu,V,A,[4 4 4 4 4]);
toc
y
p = 20;
A = zeros(n,n,p);
for i=1:p
    x = randn(20*n,n);
    A(:,:,i) = (x'*x)./(20*n);
end
fprintf('\nNon-Repeated s_i, New Identity\n') 
fprintf('s_i = 1\n')
fprintf('s = %3.0f\n',s)
tic
y = qmomnc(mu,V,A);
toc
y
fprintf('\nNon-Repeated s_i, New Identity (Brown)\n') 
fprintf('s_i = 1\n')
fprintf('s = %3.0f\n',s)
tic
y = qmomnc_new(mu,V,A);
toc
y
fprintf('\nNon-Repeated s_i, New Identity (Qaudruple Precision)\n') 
fprintf('s_i = 1\n')
fprintf('s = %3.0f\n',s)
tic
y = qmomncq(mu,V,A);
toc
y
diary off
