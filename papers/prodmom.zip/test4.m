%
% test4.m: Speed of qmomnc.m
%
rng('default')
s = 20;
p = 5;
n = 60;
A = zeros(n,n,p);
for i=1:p
    x = randn(20*n,n);
    A(:,:,i) = (x'*x)./(20*n);
end
x = randn(20*n,n);
V = (x'*x)./(20*n);
mu = randn(n,1);
if isfile('test4.out')
   delete test4.out
end
diary test4.out
format long
fprintf('\nRepeated s_i: s_i = 4, s = %d\n',s)
tic
[y,relerr] = qmomnc(mu,V,A,[4 4 4 4 4]);
t = toc;
fprintf('y = %22.15e, relerr = %7.1e, time = %8.3f seconds\n',y,relerr,t)
p = 20;
A = zeros(n,n,p);
for i=1:p
    x = randn(20*n,n);
    A(:,:,i) = (x'*x)./(20*n);
end
fprintf('\nNon-Repeated s_i: s_i = 1, s = %d\n',s)
tic
[y,relerr] = qmomnc(mu,V,A);
t = toc;
fprintf('y = %22.15e, relerr = %7.1e, time = %8.3f seconds\n',y,relerr,t)
diary off
