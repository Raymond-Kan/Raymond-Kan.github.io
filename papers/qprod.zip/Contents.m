% qprod Toolbox -- Expectations of products of quadratic forms in normal random variables
% Version 1.4   4-Oct-2026
%
% Companion to: R. Kan and J. Pan, An explicit expression for the expectation
% of a product of quadratic forms in multivariate normal random variables.
%
% Numerical evaluation (fast; all call qprod_core)
%   qproda        - E[Q_1*...*Q_k], Q_i = z'A_i z, z ~ N(mu,S)
%   qprodac       - same, z ~ N(0,S)
%   qprods        - E[Q_1^s_1*...*Q_k^s_k], z ~ N(mu,S)
%   qprodsc       - same, z ~ N(0,S)
%   qproda_comp   - E[Q_1*...*Q_k], Q_i = z^H A_i z, z ~ CN(mu,S)
%   qprodac_comp  - same, z ~ CN(0,S)
%   qprods_comp   - E[Q_1^s_1*...*Q_k^s_k], z ~ CN(mu,S)
%   qprodsc_comp  - same, z ~ CN(0,S)
%   qprodw        - E[prod tr(W A_i)^s_i], W ~ W_m(n,S,L) real Wishart
%   qprodw_comp   - same, W ~ CW_m(n,S,L) complex Wishart
%   qprod_core    - the evaluation engine (cumulant recursion)
%   qprod_check   - input validation shared by the functions above
%
% The explicit expression of the paper, evaluated term by term
%   qprod_enum    - Propositions 2-4 and Corollaries 1-3, literally
%   qproda_slow   - Proposition 1 (admissible permutations), z ~ N(mu,S)
%   qprodac_slow  - Proposition 1, z ~ N(0,S)
%
% Independent checks (used by test_all)
%   qprod_wick    - Isserlis-Wick expansion of the Gaussian expectation
%   qprod_mgf     - symbolic differentiation of the moment generating function
%   qprods_sim    - Monte Carlo simulation
%   qproda_lm, qproda_lm_comp       - Letac and Massam (2008)
%   qprodac_glm, qprodac_glm_comp   - Graczyk, Letac and Massam (2003, 2005)
%   qproda_kan, qprodac_kan         - Kan (2008), moments of sums
%
% Symbolic expansion (one string per distinct term)
%   qprodastr, qprodastrc, qprodastr_comp, qprodastrc_comp   - all s_i = 1
%   qprodsstr, qprodsstrc, qprodsstr_comp, qprodsstrc_comp   - general s
%   qprodstr_core - the generating engine
%   qmom, qmom_rec, qmomc, qmomc_rec - E[(z'Az)^k] by integer partitions
%
% Counting the distinct terms
%   qcount, qcountc, qcountc_rec     - all s_i = 1 (Tables 2 and 4)
%   qcounts, qcountsc                - general s (Table 7)
%
% Combinatorial helpers
%   msetpart      - partitions of a multiset (Knuth, Algorithm M)
%   setpart       - set partitions of {1,...,n}
%   ip_desc       - integer partitions
%   bell          - Bell numbers
%   necklace, bracelet, ntheta       - counts of necklaces, bracelets, canonical theta-words
%   fixbrace, fixbracef              - enumeration of bracelets
%   taulist, thetalist               - canonical words of a block with coefficients
%   nthperm, nmp, istheta, tostr     - permutations and utilities
%
% Examples and tests
%   example1 ... example6            - demonstration scripts (output in *.out)
%   test_all                         - run all checks
%
% See readme.txt and manual.pdf for details.
