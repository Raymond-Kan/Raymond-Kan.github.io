
%  bell.m    Date: 7/29/2023
%  This program computes the bell number, B_k, which
%  is the number of possible set partitions of (1,...,k).
%
function y = bell(k)
   if k==0
      y = 1;
   else
      A = zeros(k);
      A(1,1) = 1;
      for i=2:k
          A(i,1) = A(i-1,i-1);
          for j=2:k
              A(i,j) = A(i,j-1)+A(i-1,j-1);
          end
      end
      y = A(k,k);
   end
