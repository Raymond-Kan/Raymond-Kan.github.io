function y = bracelet(v)
%BRACELET  Number of bracelets with fixed content.
%
%   y = BRACELET(v) returns the number of bracelets (equivalence classes
%   of words under rotation and reversal) of length n = sum(v) containing
%   v_i beads of color i, i = 1,...,p (Lemma 8 of the paper):
%
%      n_tau(v) = N_neck(v)/2 + ((n-j)/2)! / (2 prod floor(v_i/2)!)
%
%   if the number j of odd v_i is at most 2, and n_tau(v) = N_neck(v)/2
%   otherwise.  This is the number of distinct tau-terms with index
%   content v.
%
%   See also NECKLACE, NTHETA, FIXBRACE, TAULIST.

   v = v(:).';
   v = v(v > 0);
   n = sum(v);
   if n <= 2
      y = 1;
      return
   end
   y = 0.5*necklace(v);
   if sum(rem(v,2) == 1) <= 2
      v2 = fix(v/2);
      y = y + exp(gammaln(sum(v2)+1) - sum(gammaln(v2+1)))/2;
   end
   y = round(y);
end
