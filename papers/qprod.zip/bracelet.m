%
%    bracelet.m
%    This program finds out the number of bracelets with r colors and length
%    of k, with k_i beads in color i, i=1,...,r.
%
function y = bracelet(k)
   r = length(k);
   y = 0.5*necklace(k);
   if sum(rem(k,2)==1)<=2
      k2 = fix(k/2);
      y = y+exp(gammaln(sum(k2)+1)-sum(gammaln(k2+1)))/2;
   end
   y = round(y);
   