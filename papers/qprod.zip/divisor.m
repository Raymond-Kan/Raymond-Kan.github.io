% sigma by David Terr, Raytheon Inc., 5-19-04
% Given a nonnegative integers k and n, return the list of the 
% the divisors of n. 
% Note: This program requires first downloading factor2.

function s = divisor(n)
   if n<=0
      s = [];
      return
   end
   if n==1
      s = 1;
      return
   end
   fax = factor2(n);
   m = prod(fax(:,2)+1);   % Number of divisors
   s = ones(1,m);
   lf = length(fax(:,1));
   y = zeros(1,lf);
   s(1) = 1;
   s(end) = n;
   for i=2:m-1
       s(i) = s(i-1);
       for j=1:lf
           if y(j)<fax(j,2)
              y(j) = y(j)+1;
              s(i) = s(i)*fax(j,1);
              break
           else
              y(j) = 0;
              s(i) = s(i)/fax(j,1)^fax(j,2);
           end
       end
   end
   s = sort(round(s));
