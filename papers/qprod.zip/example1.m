k = 9;
m = 5;
A = zeros(m,m,k);
for i=1:k
    x = randn(20,m);
    A(:,:,i) = (x'*x)/20;
end
mu = randn(m,1);
%
%  Create a positive semi-definite S
%
x = randn(m-1,m);
S = (x'*x)/m;
delete example1.out
diary example1.out
format long
%
%  case with mu=0_m
%
tic
y1 = qprodac(A,S);
toc
y1
tic
y2 = qprodac_slow(A,S);
toc
y2
tic
y3 = qprodac_glm(A,S);
toc
y3
%
%  case with mu~=0_m
%
tic
y4 = qproda(A,S,mu); 
toc
y4
tic
y5 = qproda_slow(A,S,mu); 
toc
y5
tic
y6 = qproda_lm(A,S,mu); 
toc
y6
diary off

