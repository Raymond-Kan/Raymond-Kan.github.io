%
%  example1.m: numerical evaluation of E[Q_1*...*Q_k] for z ~ N(mu,S)
%  and z ~ N(0,S) by the fast evaluator (qproda, qprodac) and by the
%  alternative algorithms kept for verification:
%     qprod_enum    the explicit expression of the paper, term by term
%     qproda_slow   the admissible-permutation expansion (Proposition 1)
%     qproda_lm     Letac and Massam (2008)
%     qprodac_glm   Graczyk, Letac and Massam (2005)
%     qproda_kan    Kan (2008)
%
if exist('rng','file') == 2 || exist('rng','builtin') == 5, rng(1); else randn('seed',1); end
k = 8;
m = 5;
A = zeros(m,m,k);
for i=1:k
    x = randn(20,m);
    A(:,:,i) = (x'*x)/20;
end
mu = randn(m,1);
%
%  Create a positive semidefinite (singular) S
%
x = randn(m-1,m);
S = (x'*x)/m;
if exist('example1.out','file'), delete example1.out, end
diary example1.out
format long
fprintf('k = %d, m = %d\n\n',k,m);
%
%  case with mu = 0_m
%
fprintf('--- z ~ N(0,S) ---\n');
tic; y = qprodac(A,S);          fprintf('qprodac      %22.15e  %8.3f s\n',y,toc);
tic; y = qprod_enum(A,S,[]);    fprintf('qprod_enum   %22.15e  %8.3f s\n',y,toc);
tic; y = qprodac_slow(A,S);     fprintf('qprodac_slow %22.15e  %8.3f s\n',y,toc);
tic; y = qprodac_glm(A,S);      fprintf('qprodac_glm  %22.15e  %8.3f s\n',y,toc);
tic; y = qprodac_kan(A,S);      fprintf('qprodac_kan  %22.15e  %8.3f s\n',y,toc);
%
%  case with mu ~= 0_m
%
fprintf('\n--- z ~ N(mu,S) ---\n');
tic; y = qproda(A,S,mu);        fprintf('qproda       %22.15e  %8.3f s\n',y,toc);
tic; y = qprod_enum(A,S,mu);    fprintf('qprod_enum   %22.15e  %8.3f s\n',y,toc);
tic; y = qproda_slow(A,S,mu);   fprintf('qproda_slow  %22.15e  %8.3f s\n',y,toc);
tic; y = qproda_lm(A,S,mu);     fprintf('qproda_lm    %22.15e  %8.3f s\n',y,toc);
tic; y = qproda_kan(A,S,mu);    fprintf('qproda_kan   %22.15e  %8.3f s\n',y,toc);
%
%  larger k with the fast evaluator only
%
fprintf('\n--- qproda for larger k ---\n');
for k = 10:2:14
    A = zeros(m,m,k);
    for i=1:k
        x = randn(20,m);
        A(:,:,i) = (x'*x)/20;
    end
    tic; y = qproda(A,S,mu);     fprintf('k = %2d  qproda %22.15e  %8.3f s\n',k,y,toc);
end
diary off
