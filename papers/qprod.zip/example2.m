k = 9;
m = 5;
A = zeros(m,m,k);
for i=1:k
    x = randn(20,m)+1i*randn(20,m);
    A(:,:,i) = (x'*x)/20;
end
mu = randn(m,1)+1i*randn(m,1);
x = randn(20,m)+1i*randn(20,m);
S = (x'*x)/m;
delete example2.out
diary example2.out
format long
%
%  case with mu=0_m
%
tic
y1 = qprodac_comp(A,S);
toc
y1
tic
y2 = qprodac_glm_comp(A,S);
toc
y2
%
%  case with mu~=0_m
%
tic
y3 = qproda_comp(A,S,mu); 
toc
y3
tic
y4 = qproda_lm_comp(A,S,mu); 
toc
y4
diary off

