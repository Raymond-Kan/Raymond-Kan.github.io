%
%  example2.m: E[Q_1*...*Q_k] for Hermitian quadratic forms in complex
%  normal vectors, z ~ CN(mu,S) and z ~ CN(0,S), by the fast evaluator
%  (qproda_comp, qprodac_comp) and by the alternative algorithms
%  qprod_enum, qproda_lm_comp (Letac and Massam, 2008) and
%  qprodac_glm_comp (Graczyk, Letac and Massam, 2003).
%
if exist('rng','file') == 2 || exist('rng','builtin') == 5, rng(2); else randn('seed',2); end
k = 7;
m = 5;
A = zeros(m,m,k);
for i=1:k
    x = randn(20,m)+1i*randn(20,m);
    A(:,:,i) = (x'*x)/20;
end
mu = randn(m,1)+1i*randn(m,1);
x = randn(20,m)+1i*randn(20,m);
S = (x'*x)/20;
if exist('example2.out','file'), delete example2.out, end
diary example2.out
format long
fprintf('k = %d, m = %d\n\n',k,m);
fprintf('--- z ~ CN(0,S) ---\n');
tic; y = qprodac_comp(A,S);          fprintf('qprodac_comp      %22.15e  %8.3f s\n',y,toc);
tic; y = qprod_enum(A,S,[],[],true); fprintf('qprod_enum        %22.15e  %8.3f s\n',y,toc);
tic; y = qprodac_glm_comp(A,S);      fprintf('qprodac_glm_comp  %22.15e  %8.3f s\n',y,toc);
fprintf('\n--- z ~ CN(mu,S) ---\n');
tic; y = qproda_comp(A,S,mu);        fprintf('qproda_comp       %22.15e  %8.3f s\n',y,toc);
tic; y = qprod_enum(A,S,mu,[],true); fprintf('qprod_enum        %22.15e  %8.3f s\n',y,toc);
tic; y = qproda_lm_comp(A,S,mu);     fprintf('qproda_lm_comp    %22.15e  %8.3f s\n',y,toc);
diary off
