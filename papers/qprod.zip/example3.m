%
%  example3.m: products with repeated quadratic forms,
%  E[Q_1^{s_1}*...*Q_k^{s_k}] for z ~ N(mu,S) and z ~ N(0,S).
%  The same value is obtained from qprods/qprodsc with the powers in s,
%  from qproda/qprodac with repeated slices of A, from the explicit
%  expression (qprod_enum) and from the method of Kan (2008).
%
if exist('rng','file') == 2 || exist('rng','builtin') == 5, rng(3); else randn('seed',3); end
s = [2 4 2 2];
k = length(s);
m = 5;
A = zeros(m,m,k);
for i=1:k
    x = randn(20,m);
    A(:,:,i) = (x'*x)/20;
end
mu = randn(m,1);
x = randn(m-1,m);
S = (x'*x)/m;
%
%  A long list of A matrices for qproda/qprodac
%
At = zeros(m,m,sum(s));
count = 0;
for i=1:k
    for j=count+1:count+s(i)
        At(:,:,j) = A(:,:,i);
    end
    count = count+s(i);
end
if exist('example3.out','file'), delete example3.out, end
diary example3.out
format long
fprintf('s = [%s], m = %d\n\n',num2str(s),m);
fprintf('--- z ~ N(0,S) ---\n');
tic; y = qprodsc(A,S,s);        fprintf('qprodsc        %22.15e  %8.3f s\n',y,toc);
tic; y = qprodac(At,S);         fprintf('qprodac(At)    %22.15e  %8.3f s\n',y,toc);
tic; y = qprod_enum(A,S,[],s);  fprintf('qprod_enum     %22.15e  %8.3f s\n',y,toc);
tic; y = qprodac_kan(A,S,s);    fprintf('qprodac_kan    %22.15e  %8.3f s\n',y,toc);
fprintf('\n--- z ~ N(mu,S) ---\n');
tic; y = qprods(A,S,mu,s);      fprintf('qprods         %22.15e  %8.3f s\n',y,toc);
tic; y = qproda(At,S,mu);       fprintf('qproda(At)     %22.15e  %8.3f s\n',y,toc);
tic; y = qprod_enum(A,S,mu,s);  fprintf('qprod_enum     %22.15e  %8.3f s\n',y,toc);
tic; y = qproda_kan(A,S,mu,s);  fprintf('qproda_kan     %22.15e  %8.3f s\n',y,toc);
fprintf('\nnumber of distinct terms: %d (mu ~= 0), %d (mu = 0); with the %d matrices treated as distinct: %d and %d\n', ...
        qcounts(s), qcountsc(s), sum(s), qcount(sum(s)), qcountc(sum(s)));
diary off
