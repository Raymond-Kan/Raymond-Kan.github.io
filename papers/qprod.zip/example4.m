%
%  example4.m: products with repeated Hermitian quadratic forms in complex
%  normal vectors, E[Q_1^{s_1}*...*Q_k^{s_k}] for z ~ CN(mu,S) and
%  z ~ CN(0,S).
%
if exist('rng','file') == 2 || exist('rng','builtin') == 5, rng(4); else randn('seed',4); end
s = [2 4 2 2];
k = length(s);
m = 5;
A = zeros(m,m,k);
for i=1:k
    x = randn(20,m)+1i*randn(20,m);
    A(:,:,i) = (x'*x)/20;
end
mu = randn(m,1)+1i*randn(m,1);
x = randn(20,m)+1i*randn(20,m);
S = (x'*x)/20;
At = zeros(m,m,sum(s));
count = 0;
for i=1:k
    for j=count+1:count+s(i)
        At(:,:,j) = A(:,:,i);
    end
    count = count+s(i);
end
if exist('example4.out','file'), delete example4.out, end
diary example4.out
format long
fprintf('s = [%s], m = %d\n\n',num2str(s),m);
fprintf('--- z ~ CN(0,S) ---\n');
tic; y = qprodsc_comp(A,S,s);        fprintf('qprodsc_comp      %22.15e  %8.3f s\n',y,toc);
tic; y = qprodac_comp(At,S);         fprintf('qprodac_comp(At)  %22.15e  %8.3f s\n',y,toc);
tic; y = qprod_enum(A,S,[],s,true);  fprintf('qprod_enum        %22.15e  %8.3f s\n',y,toc);
fprintf('\n--- z ~ CN(mu,S) ---\n');
tic; y = qprods_comp(A,S,mu,s);      fprintf('qprods_comp       %22.15e  %8.3f s\n',y,toc);
tic; y = qproda_comp(At,S,mu);       fprintf('qproda_comp(At)   %22.15e  %8.3f s\n',y,toc);
tic; y = qprod_enum(A,S,mu,s,true);  fprintf('qprod_enum        %22.15e  %8.3f s\n',y,toc);
diary off
