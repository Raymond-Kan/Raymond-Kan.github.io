s = [2 4 2 2];
k = length(s);
m = 5;
A = zeros(m,m,k);
for i=1:k
    x = randn(20,m)+1i*randn(20,m);
    A(:,:,i) = (x'*x)/20;
end
mu = randn(m,1)+1i*randn(m,1);
x = randn(20,m)+1i*randn(20,m);
S = (x'*x)/m;
%
%  Create a long list of A matrix for
%  us to use qproda_comp.m and qprodac_comp.m
%
At = zeros(m,m,sum(s));
count = 0;
for i=1:k
    for j=count+1:count+s(i)
        At(:,:,j) = A(:,:,i);
    end
    count = count+s(i);
end
delete example4.out
diary example4.out
format long
%
%  case with mu=0_m
%
tic
y1 = qprodsc_comp(A,S,s);
toc
y1
tic
y2 = qprodac_comp(At,S);
toc
y2
%
%  case with mu~=0_m
%
tic
y3 = qprods_comp(A,S,mu,s);
toc
y3
tic
y4 = qproda_comp(At,S,mu);
toc
y4
diary off

