%
%  This program shows how to obtain the correct expression
%  of E[tr(W*A1)*tr(W*A2)*tr(W*A3)] for real Wishart
%  and E[tr(W*A1)*tr(W*A2)^2] for complex Wishart
%
delete example5.out
diary example5.out
fprintf(' E[tr(W*A1)*tr(W*A2)*tr(W*A3)] for real Wishart\n')
fprintf(' Note that a stands for tau and h stands for theta\n')
y = qprodastr(3);
disp(y)
fprintf('\n E[tr(W*A1)*tr(W*A2)^2] for complex Wishart\n')
fprintf(' Note that a stands for tau and h stands for theta\n')
y = qprodsstr_comp([1 2]);
disp(y)
diary off

