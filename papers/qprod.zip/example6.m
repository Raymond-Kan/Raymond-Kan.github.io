%
%  example6.m: Wishart product moments and the independent checks.
%  (i)   E[prod_i tr(W*A_i)^{s_i}] for W ~ W_m(n,S,L) and W ~ CW_m(n,S,L)
%        by qprodw/qprodw_comp, compared with the explicit expression
%        (qprod_enum) and, for integer n, with a sum of independent
%        normal vectors evaluated by qprods.
%  (ii)  the Isserlis-Wick evaluator qprod_wick, the Monte Carlo
%        estimate qprods_sim and, when a symbolic toolbox is available,
%        the moment generating function check qprod_mgf.
%
if exist('rng','file') == 2 || exist('rng','builtin') == 5, rng(6); else randn('seed',6); end
m = 4;
k = 3;
s = [2 1 1];
n = 3;
A = zeros(m,m,k);
for i=1:k
    x = randn(10,m);
    A(:,:,i) = (x'*x)/10;
end
x = randn(m-1,m);
S = (x'*x)/m;                  % singular covariance matrix
Mu = randn(m,n);               % mu_1,...,mu_n
L = Mu*Mu';                    % noncentrality matrix
if exist('example6.out','file'), delete example6.out, end
diary example6.out
format long
fprintf('--- real Wishart, W ~ W_%d(%d,S,L), s = [%s] ---\n',m,n,num2str(s));
y1 = qprodw(A,S,n,L,s);
y2 = qprod_enum(A,S,L,s,false,n);
%  W = sum_t z_t z_t', so E[prod_i tr(W A_i)^{s_i}] = E[prod_i (sum_t q_it)^{s_i}]
%  with independent z_t ~ N(mu_t,S): expand the powers of the sums
y3 = 0;
for b1 = 0:s(1), for b2 = 0:s(2), for b3 = 0:s(3)
    c1 = nchoosek(s(1),b1)*nchoosek(s(2),b2)*nchoosek(s(3),b3);
    for c2a = 0:b1, for c2b = 0:b2, for c2c = 0:b3
        c2 = nchoosek(b1,c2a)*nchoosek(b2,c2b)*nchoosek(b3,c2c);
        y3 = y3 + c1*c2*qprods(A,S,Mu(:,1),s-[b1 b2 b3])*qprods(A,S,Mu(:,2),[b1 b2 b3]-[c2a c2b c2c])*qprods(A,S,Mu(:,3),[c2a c2b c2c]);
    end, end, end
end, end, end
fprintf('qprodw                         %22.15e\n',y1);
fprintf('qprod_enum                     %22.15e\n',y2);
fprintf('sum of %d independent vectors   %22.15e\n',n,y3);
fprintf('\n--- central real Wishart with non-integer degrees of freedom, n = 2.5 ---\n');
fprintf('qprodw      %22.15e\n',qprodw(A,S,2.5,[],s));
fprintf('qprod_enum  %22.15e\n',qprod_enum(A,S,[],s,false,2.5));
fprintf('\n--- complex Wishart, W ~ CW_%d(%d,S,L), s = [%s] ---\n',m,2,num2str(s));
Ac = zeros(m,m,k);
for i=1:k
    x = randn(10,m)+1i*randn(10,m);
    Ac(:,:,i) = (x'*x)/10;
end
x = randn(10,m)+1i*randn(10,m);
Sc = (x'*x)/10;
Muc = randn(m,2)+1i*randn(m,2);
Lc = Muc*Muc';
fprintf('qprodw_comp %22.15e\n',qprodw_comp(Ac,Sc,2,Lc,s));
fprintf('qprod_enum  %22.15e\n',qprod_enum(Ac,Sc,Lc,s,true,2));
fprintf('\n--- independent checks of E[Q_1^2 Q_2 Q_3], z ~ N(mu,S) ---\n');
mu = Mu(:,1);
yq = qprods(A,S,mu,s);
fprintf('qprods       %22.15e\n',yq);
fprintf('qprod_wick   %22.15e   (Isserlis-Wick)\n',qprod_wick(A,S,mu,s));
[ysim,se] = qprods_sim(A,S,mu,s,200000);
fprintf('qprods_sim   %22.15e   (Monte Carlo, s.e. %.3e, z = %.2f)\n',ysim,se,(ysim-yq)/se);
%
%  symbolic differentiation of the moment generating function, on a small
%  integer-valued problem so that the symbolic computation is exact and fast
%
m = 2; k = 2; s = [2 1];
B = zeros(m,m,k);
for i=1:k
    x = round(2*randn(m,m));
    B(:,:,i) = x+x';
end
x = round(2*randn(m,m)); Sb = x'*x; mub = round(2*randn(m,1));
fprintf('\n--- E[Q_1^2 Q_2] for integer-valued A_i, S, mu (m = 2) ---\n');
fprintf('qprods       %22.15e\n',qprods(B,Sb,mub,s));
fprintf('qprod_wick   %22.15e   (Isserlis-Wick)\n',qprod_wick(B,Sb,mub,s));
try
    fprintf('qprod_mgf    %22.15e   (symbolic differentiation of the MGF)\n',qprod_mgf(B,Sb,mub,s));
catch
    fprintf('qprod_mgf    skipped (no symbolic toolbox)\n');
end
diary off
