%
% Given an integer n, the function returns the prime factorization of n as a
% kx2 matrix, with the k distinct prime factors in the left column and
% exponents in the right column. 
%
function fac = factor2( n )
   if n==0||n==1
      fac = [n 0];
      return
   end
   fac0 = factor(n);
   len = length(fac0);
   fac1 = zeros(len,2);
   p = fac0(1);
   fac1(1,:) = [p 1];
   m = 1;
   k = 1;
   while k<len
      k = k+1;
      if fac0(k)==p
         fac1(m,2) = fac1(m,2)+1;
      else
         p = fac0(k);
         m = m+1;
         fac1(m,:) = [p 1];
      end
   end
   fac = fac1(1:m,:);
   
