function [y,cc] = fixbrace(ii)
%
%   This program enumerates bracelets with fixed
%   content
%   Input:
%   ii: frequency of 1 to k, where k is the length of ii
%   Output
%   y: possible number of braces that could create 
%      from the fixed content of i=1,...,k, with 
%      frequencies of ii(1) to ii(k).
%   cc: coefficients which tells us the number of 
%       bracelets that each row of y maps to if the
%       contents are all distinct.
%
k = length(ii);
n = sum(ii);
if k==1
   y = ones(1,n);
   cc = 1/(2*ii);
   return
end
bk = bracelet(ii);
y = zeros(bk,n);
head = k;
a = [1 k*ones(1,n-1)];
ii(1) = ii(1)-1;
if ii(1)>0
   avail_next = -1:k-1;
   avail_prev = 1:k+1;
else
   avail_next = [-1 0 0 2:k-1];
   avail_prev = [2 2:k+1];
end
cc = ones(bk,1);
count = 0;
gen(2,1,1,1,1,0)

function gen(t,p,r,u,v,RS)
%
%   RS tells us whether the bracelet maps to
%   one or two necklaces. 
%   RS=0: 1 necklace, RS=1: 2 necklaces
%
if t>(n+r+3)/2
   if a(t-1)>a(n-t+2+r)
      RS = 1;
   elseif a(t-1)<a(n-t+2+r)
      RS = -1;
   end
end
if t>n
   if RS>=0&&mod(n,p)==0
      count = count+1;
      d = round(n/p);
      cc(count) = cc(count)/d;
      if RS==0
         cc(count) = cc(count)/2;  % 1 necklace
      end
      y(count,:) = a;
   end
elseif ii(1)~=n-t+1
   j = head;
   while j>=a(t-p)
      a(t) = j;
      if j==a(t-p)
         if a(t)==1
            v = v+1;
            if u==t-1
               u = t;
            end
         else
            v = 0;
         end
         if u==v    % testing starts when we find u=v
            rev = 0;
            j1 = u+1;
            while rev==0&&j1<(t+1)/2
               rev = sign(a(j1)-a(t-j1+1));
               j1 = j1+1;            
            end
            if rev<=0  
               removej
               if rev<0
                  gen(t+1,p,r,u,v,RS)
               else
                  gen(t+1,p,t,u,v,0)
               end
               addj
            end
%
%   if rev=-1, discontinue this tree as the current string 
%   will always be dominated by its reversal.
%
         else
            removej
            gen(t+1,p,r,u,v,RS)
            addj
         end
      else
         removej
         gen(t+1,t,r,u,0,RS)
         addj
      end
      j = avail_next(j+1);
   end
end

function addj
   if ii(j)==0
      prev = avail_prev(j+1);
      next = avail_next(j+1);
      avail_next(prev+1) = j;
      avail_prev(next+1) = j; 
      if avail_prev(j+1)==k+1
         head = j;
      end
   end
   ii(j) = ii(j)+1;
end

function removej
   ii(j) = ii(j)-1;
   if ii(j)==0
      if j==head
         head = avail_next(j+1);
      end
      prev = avail_prev(j+1);
      next = avail_next(j+1);
      avail_next(prev+1) = next;
      avail_prev(next+1) = prev; 
   end
end

end
end