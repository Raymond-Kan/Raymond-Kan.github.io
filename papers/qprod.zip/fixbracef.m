%
%   fixbracef.m    Date: 7/31/2023
%   This program enumerates bracelets with fixed
%   contents of (1,2,...,k).  It stores the
%   factoradic of the bracelets.
%
function y = fixbracef(k)
if k<=3
   y = 1;
   return
end
if k==4
   y = [1 2 3]';
   return
end
if k==5
   y = [1:9 11 13 15]';
   return
end
k1 = k-1;
fack = cumprod(1:k1);
nb = fack(k1)/2;
y = zeros(nb,1);
%
%   There are altogther k-2 blocks.  First
%   block has (k-2)(k-3)! elements.  Second block
%   has (k-3)(k-3)! elements, all the way to
%   the last block which has (k-3)! elements.
%
nk2 = fack(k-2);
nk3 = fack(k-3);
ka = [k-2:-1:1]*nk3;   % number of bracelets in each block
kas = cumsum(ka);
%   The first block has no mirror image and 
%   they are all good.
ns = sum(fack(1:k-2));
y(1:ns) = 1:ns;
%   For the second and last blocks, we have
%   explicit expression and there is no need
%   to check.
y2 = false(nk2,1);
b = [2; 2];
for i=3:k-3  
    b1 = b;
    b1(1) = b1(1)+fack(i-1);
    b = repmat(b1,i,1);
end
bb = cumsum([1; b(2:end)]);
count = ns;
count1 = 1;
cc1 = kas(k-3);
cc2 = (k-3)*nk2;
for i=1:2*nk2-ns
    if i==bb(count1)
       y(cc1+count1) = cc2+i;
       count1 = count1+1;
    else
       count = count+1;
       y(count) = ns+i;
    end
end
count = kas(2);            % counter to tell us how many bracelets have been found
count1 = 2*nk2;
cc = kas(k-3)+1;
cc1 = (k-3)*nk2+1;
a = uint8([2 k1:-1:3 1]);  % last entry of the second block
%  From block 3 onward, we need to check the permutations
for ii=1:(k-5)*nk2/2
    i = k1-1;
    while a(i)>=a(i+1)
       i = i-1;
    end
    j = i+1;
    k2 = k1;
    while j<k2     
       t = a(j);
       a(j) = a(k2);
       a(k2) = t;
       j = j+1;
       k2 = k2-1;
    end   
    j = i+1;
    while a(j)<a(i)
       j = j+1;
    end
    t = a(i);
    a(i) = a(j);
    a(j) = t;
    if a(1)<a(k1)
       count = count+1;
       y(count) = count1+ii;
    else
       cc = cc-1;
       y(cc) = cc1-ii;
    end
end
