%
%    This Matlab function computes the gcd of a vector
%    of integers
%
function y=gcdv(k);
   r = length(k);
   if r==1
      y = k;
      return
   end
   if any(r==1)
      y = 1;
      return
   end
   k = sort(k);
   y = k(1);
   if y==k(end)
      return
   end
   for i=2:r
       y = gcd(y,k(i));
       if y==1
          break
       end
   end
