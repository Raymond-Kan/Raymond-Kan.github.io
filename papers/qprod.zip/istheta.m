%
%   This Matlab function takes a vector of n
%   elements and decides if it is smaller than
%   or equal to its reverse.
%   Input
%   A: a vector of n elements 
%   Output
%   theta: a logical variable, which is equal
%          to true when A is smaller or equal to
%          its reverse
%
function theta = istheta(A)
   n = length(A);
   for i=1:floor(n/2)
       A1 = A(i);
       A2 = A(n+1-i);
       if A1~=A2
          theta = A1<A2;
          return
       end          
   end
   theta = true;
   