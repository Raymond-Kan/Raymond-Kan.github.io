function P = msetpart(s)
%MSETPART  All partitions of a multiset into nonempty blocks.
%
%   P = MSETPART(s), where s = (s_1,...,s_k) is a vector of nonnegative
%   integers, returns the partitions of the multiset that contains s_i
%   copies of the integer i, i = 1,...,k, into unordered nonempty blocks
%   (the set B_s of the paper).  P is an N x 1 cell array; P{j} is an
%   r x k matrix whose i-th row gives the multiplicities of 1,...,k in
%   the i-th block of the j-th partition.  Blocks are listed in
%   lexicographically decreasing order (Knuth's canonical order), so equal
%   blocks are adjacent.
%
%   For s = ones(1,k) the result is the set of set partitions of
%   {1,...,k}, with each block given as a 0/1 indicator row; the count is
%   the Bell number B_k.
%
%   The enumeration is Algorithm M of D. E. Knuth, The Art of Computer
%   Programming, Vol. 4A, Section 7.2.1.5 (pp. 429-430).
%
%   Example:  msetpart([2 1]) returns the four partitions of {1,1,2}:
%     [2 1], [2 0;0 1], [1 1;1 0], [1 0;1 0;0 1].
%
%   See also SETPART, QCOUNTS, QPROD_ENUM.

   s = s(:).';
   if any(s < 0) || any(s ~= round(s))
      error('qprod:badInput','msetpart: s must contain nonnegative integers.');
   end
   k = numel(s);
   ss = sum(s);
   if ss == 0
      P = {zeros(0,k)};
      return
   end
   % Knuth's arrays c (component), u (available), v (used); the stack
   % f(1:l+1) delimits the l blocks of the current partition.
   m1 = ss*(ss+1)/2 + 1;
   c = zeros(1,m1); u = zeros(1,m1); v = zeros(1,m1);
   f = zeros(1,ss+1);
   c(1:k) = 1:k; u(1:k) = s; v(1:k) = s;
   a = 1; l = 1; b = k+1;
   f(1) = a; f(2) = b;
   % Upper bound on the number of partitions: Bell number of ss.
   P = cell(bell(ss),1);
   count = 1;
   P{1} = emit();
   while true
      % M5: decrease v
      j = b-1;
      while v(j) == 0
         j = j-1;
      end
      if j == a && v(j) == 1
         % M6: backtrack
         if l == 1
            break
         end
         l = l-1;
         b = a;
         a = f(l);
         continue
      end
      v(j) = v(j)-1;
      v(j+1:b-1) = u(j+1:b-1);
      % M2-M4: visit a partition, pushing new blocks while possible
      kk = b;
      while true
         flag = false;
         for jj = a:b-1
             u(kk) = u(jj)-v(jj);
             if u(kk) == 0
                flag = true;
             else
                if flag
                   v(kk) = u(kk);
                else
                   v(kk) = min(v(jj),u(kk));
                   flag = u(kk) < v(jj);
                end
                c(kk) = c(jj);
                kk = kk+1;
             end
         end
         if kk > b
            a = b; b = kk; l = l+1; f(l+1) = b;
         else
            break
         end
      end
      count = count+1;
      P{count} = emit();
   end
   P = P(1:count);

   function M = emit()
      M = zeros(l,k);
      for i = 1:l
          ind = f(i):f(i+1)-1;
          M(i,c(ind)) = v(ind);
      end
      M = M(any(M,2),:);
   end
end
