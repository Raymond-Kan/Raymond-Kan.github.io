function y = necklace(v)
%NECKLACE  Number of necklaces with fixed content.
%
%   y = NECKLACE(v) returns the number of necklaces (equivalence classes
%   of words under rotation) of length n = sum(v) containing v_i beads of
%   color i, i = 1,...,p, by Polya's enumeration theorem:
%
%      N_neck(v) = (1/n) sum_{j | gcd(v)} phi(j) (n/j)! / prod (v_i/j)!,
%
%   where phi is Euler's totient function (eq. (numneck) of the paper).
%
%   See also BRACELET, NTHETA.

   v = v(:).';
   v = v(v > 0);
   n = sum(v);
   if n <= 1
      y = 1;
      return
   end
   g = v(1);
   for i = 2:numel(v)
       g = gcd(g,v(i));
   end
   y = 0;
   for j = find(rem(g,1:g) == 0)        % positive divisors of g
       y = y + totient(j)*exp(gammaln(n/j+1) - sum(gammaln(v/j+1)));
   end
   y = round(y/n);
end

function t = totient(j)
   if j == 1
      t = 1;
   else
      f = unique(factor(j));
      t = round(j*prod(1-1./f));
   end
end
