%
%    necklace.m
%    This program finds out the number of necklaces with r colors and length
%    of k, with k_i beads in color i, i=1,...,r.
%
function y = necklace(k)
   r = length(k);
   sk = sum(k);
   y = 0;
   for j=divisor(gcdv(k))
       y = y+totient(j)*exp(gammaln(sk/j+1)-sum(gammaln(k./j+1)));
   end
   y = round(y/sk);
   
    