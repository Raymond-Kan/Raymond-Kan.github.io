function next_perm = nmp(current_perm)
    % Find the next permutation of a multiset
    n = length(current_perm);
    i = n - 1;

    % Step 1: Find the rightmost element smaller than its successor
    while i > 0 && current_perm(i) >= current_perm(i + 1)
        i = i - 1;
    end

    if i == 0
        % If no such element exists, the current permutation is the last one
        next_perm = [];
        return;
    end

    % Step 2: Find the smallest element to the right of i that is larger than current_perm(i)
    j = n;
    while current_perm(j) <= current_perm(i)
        j = j - 1;
    end

    % Step 3: Swap elements at i and j
    current_perm([i, j]) = current_perm([j, i]);

    % Step 4: Reverse the sequence to the right of i
    current_perm(i + 1:end) = current_perm(end:-1:i + 1);

    next_perm = current_perm;
end
