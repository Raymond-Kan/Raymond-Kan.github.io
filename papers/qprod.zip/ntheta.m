function y = ntheta(v)
%NTHETA  Number of canonical theta-words with a given content.
%
%   y = NTHETA(v) returns the number of distinct theta-terms whose index
%   word contains v_i copies of the integer i, i = 1,...,p, i.e. the number
%   of arrangements of the multiset that do not exceed their reversal
%   lexicographically (Lemma 7 of the paper):
%
%      n_theta(v) = ( N + P ) / 2,
%
%   where N = (sum v)!/prod(v_i!) is the number of distinct arrangements
%   and P is the number of palindromic arrangements (P = 0 if two or more
%   of the v_i are odd, and P = floor(n/2)!/prod floor(v_i/2)! otherwise).
%
%   See also BRACELET, THETALIST, QCOUNTS.

   v = v(:).';
   v = v(v > 0);
   n = sum(v);
   if n <= 1
      y = 1;
      return
   end
   y = exp(gammaln(n+1) - sum(gammaln(v+1)))/2;
   if sum(rem(v,2) == 1) <= 1
      v2 = fix(v/2);
      y = y + exp(gammaln(sum(v2)+1) - sum(gammaln(v2+1)))/2;
   end
   y = round(y);
end
