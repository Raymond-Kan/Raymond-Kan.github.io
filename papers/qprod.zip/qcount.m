%QCOUNT  Number of distinct terms in the expansion of E[Q_1*...*Q_k], z ~ N(mu,S).
%
%   y = QCOUNT(k) returns M(k), the number of distinct terms in the
%   explicit expression of E[prod_{i=1}^k z'*A_i*z] for z ~ N(mu,S)
%   (eq. (18) and Table 2 of the paper), as a uint64.  M(k) exceeds
%   2^64 for k > 19, and an error is raised in that case.
%
%   See also QCOUNTC, QCOUNTS, QPRODASTR.
%
function y = qcount(k)
   if k > 19
      error('qprod:overflow','qcount: M(k) exceeds 2^64 for k > 19.');
   end
   p = ip_desc(k);
   np = size(p,1);
   fack = cumprod(uint64(1:k));
% total number of unique \tau's and \theta's with different lengths   
   nt = 2*ones(1,k,'uint64');    
   for i=3:k
       nt(i) = (i+1)*fack(i-1)/2;
   end
   y = uint64(0);
   for i=1:np
       p1 = p(i,:);
       p1(p1==0) = [];
       c = fack(k)/prod(fack(p1));
       for j=1:p1(1)
           f = sum(p1==j);
           if f>0
              c = c*nt(j)^f/fack(f);
           end
       end
       y = y+c;
   end
     
       
           
      