%
%   This Matlab function computes the number of unique
%   terms in the expression of E[Q_1*Q_2*...*Q_k], where
%   Q_i=z'*Ai*z and z~N(\mu,\Sigma).
%
function y = qcount(k)
   p = ip_desc(k);
   np = size(p,1);
   fack = cumprod(uint64(1:k));
% total number of unique \tau's and \theta's with different lengths   
   nt = 2*ones(1,k,'uint64');    
   for i=3:k
       nt(i) = (i+1)*fack(i-1)/2;
   end
   y = uint64(0);
   for i=1:np
       p1 = p(i,:);
       p1(p1==0) = [];
       c = fack(k)/prod(fack(p1));
       for j=1:p1(1)
           f = sum(p1==j);
           if f>0
              c = c*nt(j)^f/fack(f);
           end
       end
       y = y+c;
   end
     
       
           
      