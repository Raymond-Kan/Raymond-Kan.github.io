%
%   This Matlab function computes the number of unique terms
%   in the expression of E[Q_1*Q_2*...*Q_k], where
%   Q_i=z'*Ai*z and z~N(0,\Sigma).  The number of unique
%   terms is based on the expression in Don (1979).
%
function y = qcountc(k)
   if k==1
      y = uint64(1);
      return
   end
   p = ip_desc(k);
   y = 0;
   fack = cumprod([1 1:k]);
   for i=1:size(p,1)
       p1 = p(i,:);
       p1(p1==0) = [];
       f = zeros(1,k);
       for j=1:length(p1)
           f(p1(j)) = f(p1(j))+1;
       end
       c = 2^(f(1)+f(2))/prod(fack(f+1).*[2*(1:k)].^f);
       y = y+c;
   end
   y = uint64(fack(end)*y);
       
       
           
      