%QCOUNTC  Number of distinct terms in the expansion of E[Q_1*...*Q_k], z ~ N(0,S).
%
%   y = QCOUNTC(k) returns N(k), the number of distinct terms in the
%   explicit expression of E[prod_{i=1}^k z'*A_i*z] for z ~ N(0,S)
%   (eq. (21) and Table 4 of the paper; entry A002135 of the OEIS), as a
%   uint64.  N(k) exceeds 2^64 for k > 21, and an error is raised in that
%   case.
%
%   See also QCOUNTC_REC, QCOUNT, QCOUNTSC, QPRODASTRC.
%
function y = qcountc(k)
   if k > 21
      error('qprod:overflow','qcountc: N(k) exceeds 2^64 for k > 21.');
   end
   if k==1
      y = uint64(1);
      return
   end
   p = ip_desc(k);
   y = 0;
   fack = cumprod([1 1:k]);
   for i=1:size(p,1)
       p1 = p(i,:);
       p1(p1==0) = [];
       f = zeros(1,k);
       for j=1:length(p1)
           f(p1(j)) = f(p1(j))+1;
       end
       c = 2^(f(1)+f(2))/prod(fack(f+1).*[2*(1:k)].^f);
       y = y+c;
   end
   y = uint64(fack(end)*y);
       
       
           
      