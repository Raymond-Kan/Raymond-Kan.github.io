%
%   This Matlab function computes the number of unique terms
%   in the expression of E[Q_1*Q_2*...*Q_k], where
%   Q_i=z'*Ai*z and z~N(0,\Sigma).  This is based on
%   a recursive relation.
%
function y = qcountc_rec(k)
   if k<=2
      y = uint64(k);
   else
      a = ones(k+1,1,'uint64');
      a(3) = 2;
      for i=3:k
          a(i+1) = i*a(i)-(i-1)*(i-2)/2*a(i-2);
      end
      y = a(end);
   end

       
       
           
      