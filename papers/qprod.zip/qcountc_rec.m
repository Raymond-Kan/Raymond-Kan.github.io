%QCOUNTC_REC  Number of distinct terms in the expansion of E[Q_1*...*Q_k], z ~ N(0,S), by recurrence.
%
%   y = QCOUNTC_REC(k) returns N(k) (see QCOUNTC) from the recurrence
%   N(k+1) = (k+1) N(k) - C(k,2) N(k-2), N(0) = N(1) = 1, N(2) = 2
%   (Section 4 of the paper).  An error is raised for k > 21.
%
%   See also QCOUNTC.
%
function y = qcountc_rec(k)
   if k > 21
      error('qprod:overflow','qcountc_rec: N(k) exceeds 2^64 for k > 21.');
   end
   if k<=2
      y = uint64(k);
   else
      a = ones(k+1,1,'uint64');
      a(3) = 2;
      for i=3:k
          a(i+1) = i*a(i)-(i-1)*(i-2)/2*a(i-2);
      end
      y = a(end);
   end

       
       
           
      