function y = qcounts(s,central)
%QCOUNTS  Number of distinct terms in the expansion of E[prod_i (z'*A_i*z)^{s_i}].
%
%   y = QCOUNTS(s) returns M(s), the number of distinct theta-tau
%   monomials in the explicit expression of E[prod_{i=1}^k (z'*A_i*z)^{s_i}]
%   for z ~ N(mu,S) (Proposition 4 of the paper; see also Table 7).
%   y = QCOUNTS(s,true) returns the count for the central case z ~ N(0,S),
%   i.e. the number of distinct tau-monomials (the same as QCOUNTSC(s)).
%   The count is returned as a uint64 and is exact as long as it is
%   below 2^64; an error is raised otherwise.
%
%   Method.  By Lemma 7 and Lemma 8 the number of distinct theta- and
%   tau-words with content b is n_theta(b) + n_tau(b) (n_tau(b) alone in
%   the central case), and a block that occurs h times in a multiset
%   partition contributes the number of multisets of size h drawn from
%   these words.  The multiset partitions come from MSETPART.
%
%   See also QCOUNTSC, QCOUNT, QCOUNTC, MSETPART, NTHETA, BRACELET.

   if nargin < 2
      central = false;
   end
   s = s(:).';
   if any(s < 0) || any(s ~= round(s))
      error('qprod:badInput','qcounts: s must contain nonnegative integers.');
   end
   s = s(s > 0);
   if isempty(s)
      y = uint64(1);
      return
   end
   k = numel(s);
   dims = s+1;
   stride = cumprod([1 dims(1:end-1)]);
   nw = zeros(prod(dims),1);                 % cache: number of words per content
   P = msetpart(s);
   y = uint64(0);
   for t = 1:numel(P)
       B = P{t};
       l = size(B,1);
       c = uint64(1);
       i = 1;
       while i <= l
          h = 1;
          while i+h <= l && isequal(B(i+h,:),B(i,:))
             h = h+1;
          end
          idx = 1 + B(i,:)*stride';
          if nw(idx) == 0
             if central
                nw(idx) = bracelet(B(i,:));
             else
                nw(idx) = ntheta(B(i,:)) + bracelet(B(i,:));
             end
          end
          c = mulcheck(c,multiset(nw(idx),h));
          i = i+h;
       end
       y = addcheck(y,c);
   end
end

function v = multiset(nn,h)
%  number of multisets of size h from nn objects = nchoosek(nn+h-1,h)
   v = round(exp(gammaln(nn+h)-gammaln(h+1)-gammaln(nn)));
   if v > 2^53
      error('qprod:overflow','qcounts: the count exceeds the exactly representable range.');
   end
   v = uint64(v);
end

function c = mulcheck(a,b)
   c = a*b;
   if b ~= 0 && c/b ~= a
      error('qprod:overflow','qcounts: the count exceeds 2^64.');
   end
end

function c = addcheck(a,b)
   c = a+b;
   if c < a
      error('qprod:overflow','qcounts: the count exceeds 2^64.');
   end
end
