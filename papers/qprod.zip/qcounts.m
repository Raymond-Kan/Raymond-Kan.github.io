%
%   This Matlab function computes the number of unique terms
%   in the expression of E[Q_1^{s1}*Q_2^{s2}*...*Q_k^{sk}], where
%   Q_i=z'*Ai*z and z~N(\mu,\Sigma).
%
function y = qcounts(s)
   s = sort(s);
   m = length(s);
   ss = sum(s);
   m1 = s*[m:-1:1]';
   c = zeros(1,m1);
   u = zeros(1,m1);
   v = zeros(1,m1);
   f = zeros(1,ss+1);
%
%  Initial multi-set partition
%
   c(1:m) = 1:m;
   u(1:m) = s;
   v(1:m) = s;
   a = 1;
   l = 1;
   b = m+1;
   f(1) = a;
   f(2) = b;
   y = uint64(nterm(s));
   while l<ss
      j = b-1;
      while v(j)==0
         j = j-1;
      end
      if j==a&&v(j)==1
         l = l-1;
         b = a;
         a = f(l);
      else
         v(j) = v(j)-1;
         ind = j+1:b-1;
         v(ind) = u(ind);
         k = b;
         while b<=m1
%  flag indicates whether v has changed
            flag = false;
            for j=a:b-1
                u(k) = u(j)-v(j);
                if u(k)==0
                   flag = true;
                else
                   if flag
                      v(k) = u(k);
                   else
                      v(k) = min(v(j),u(k));
                      flag = u(k)<v(j);
                   end
                   c(k) = c(j);
                   k = k+1;
                end
            end
            if k>b
               a = b;
               b = k;
               l = l+1;
               f(l+1) = b;
            else
               break
            end
         end
         c1 = uint64(1);   
         i = 1;
         ind = f(i):f(i+1)-1;
         cc = c(ind);
         vv = v(ind);
         ind1 = find(vv>0);
         cc0 = cc(ind1);
         vv0 = vv(ind1);
         l0 = length(cc0);
         h = 1;      % h tells us the number of repeated blocks
         while i<l
            i = i+1;
            ind = f(i):f(i+1)-1;
            cc = c(ind);
            vv = v(ind);
            ind1 = find(vv>0);
            cc1 = cc(ind1);
            vv1 = vv(ind1);
            l1 = length(cc1);
            if l0==l1&&all(cc0==cc1)&&all(vv0==vv1)
               h = h+1;
            else
               bvv = nterm(vv0);
               if h==1
                  c1 = c1*bvv;
               else
                  c1 = c1*nchoosek(bvv+h-1,h);
               end
               h = 1;
            end  
            cc0 = cc1;
            vv0 = vv1;
            l0 = l1;      
         end            
         bvv = nterm(vv0);
         if h==1
            c1 = c1*bvv;
         else
            c1 = c1*nchoosek(bvv+h-1,h);
         end
         y = y+c1;
      end
   end

%
%  This function computes the possible number of
%  tau's and theta's that one can create from vv.
%
function y1 = nterm(vv)
   if length(vv)==1
      y1 = 2;
   else
      y1 = exp(gammaln(sum(vv)+1)-sum(gammaln(vv+1)))/2;
      if sum(rem(vv,2)==1)<=1
         k2 = fix(vv/2);
         y1 = y1+exp(gammaln(sum(k2)+1)-sum(gammaln(k2+1)))/2;
      end
      y1 = round(y1)+bracelet(vv);
   end
