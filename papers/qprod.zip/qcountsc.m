function y = qcountsc(s)
%QCOUNTSC  Number of distinct terms in the expansion of E[prod_i (z'*A_i*z)^{s_i}], central case.
%
%   y = QCOUNTSC(s) returns the number of distinct tau-monomials in the
%   explicit expression of E[prod_{i=1}^k (z'*A_i*z)^{s_i}] for z ~ N(0,S)
%   (see Table 7 of the paper).  It is the same as QCOUNTS(s,true).
%
%   See also QCOUNTS, QCOUNTC.

   y = qcounts(s,true);
end
