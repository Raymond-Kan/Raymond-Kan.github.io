%
%  This Matlab function expresses E[(z'*A*z)^k],
%  where z ~ N(mu,S), in terms of \tau_i=tr((A*S)^i) 
%  and \theta_i=\mu'*(A*S)^{i-1}*A*\mu.
%
function [c,y] = qmom(k)
   p = ip_desc(k);
   np = size(p,1);
   fack = cumprod(1:k);
   cc = ones(1,np);
   f = zeros(np,k);
   f(np,1) = k;
   for i=1:np-1
       pp = p(i,:);
       pp(pp==0) = [];
       c1 = fack(k)*2^k;
       for j=1:k
           fj = sum(pp==j);
           f(i,j) = fj;
           if fj>0
              c1 = c1/(2*j)^fj/fack(fj);
           end
       end
       cc(i) = cc(i)*c1;
   end 
   c = cell(1,np);
%
%  For each partition, we have (1+f_1)*...*(1+f_k) elements
%
   for i=1:np
       ff = f(i,:);
%   Note that we go in opposite direction so that
%   the output agrees with the format of the integer
%   partition, i.e., \kappa_1 \geq .... \geq \kappa_r
       ind = fliplr(find(ff>0));
       ff1 = ff(ind);
       nf = length(ff1);
       pf = prod(ff1+1);
       c{i} = cc(i)*ones(1,pf);
       x = zeros(1,nf);
       count = 1;
       while count<pf
          count = count+1;
          c{i}(count) = c{i}(count-1);
%   We change the subscripts with smaller \kappa's first
          for kk=nf:-1:1
              if x(kk)<ff1(kk)
                 x(kk) = x(kk)+1;
                 c{i}(count) = c{i}(count)*(ff1(kk)-x(kk)+1)/x(kk)*ind(kk);
                 break
              else
                 x(kk) = 0;
                 c{i}(count) = c{i}(count)/ind(kk)^ff1(kk);
              end
          end
       end
   end    
   if nargout>1
      y = strings(np,1);
      for i=1:np
          c1 = c{i};
          ff = f(i,:);
          ind = fliplr(find(ff>0));
          ff1 = ff(ind);
          nf = length(ff1);
          pf = prod(ff1+1);
          x = [zeros(1,nf-1) -1];
          count = 0;
          while count<pf
             count = count+1;
             for kk=nf:-1:1
                 if x(kk)<ff1(kk)
                    x(kk) = x(kk)+1;
                    break
                 else
                    x(kk) = 0;
                 end
             end
             for kk=1:nf
                 p1k = ind(kk);
                 p1ks = num2str(p1k);
                 if x(kk)<ff1(kk)
                    if kk==1
                       tt1 = append('a_',p1ks);
                    else
                       tt1 = append(tt1,'*a_',p1ks);
                    end
                    if x(kk)<ff1(kk)-1
                       tt1 = append(tt1,'^',num2str(ff1(kk)-x(kk)));
                    end
                    if x(kk)>0
                       tt1 = append(tt1,'*h_',p1ks);
                       if x(kk)>1
                          tt1 = append(tt1,'^',num2str(x(kk)));
                       end
                    end
                 else
                    if kk==1
                       tt1 = append('h_',p1ks);
                    else
                       tt1 = append(tt1,'*h_',p1ks);
                    end
                    if x(kk)>1
                       tt1 = append(tt1,'^',num2str(x(kk)));
                    end
                 end
              end
              if c1(count)>1
                 tt1 = append(num2str(c1(count)),'*',tt1);
              end
              if count==1
                 tt = tt1;
              else
                 tt = append(tt,'+',tt1);
              end
          end
          y(i) = tt;
      end
   end              
