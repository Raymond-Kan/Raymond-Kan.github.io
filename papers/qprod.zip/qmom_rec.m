%
%  This Matlab function expresses E[(z'*A*z)^k], where
%  z ~ N(mu,S), in terms of \tau_i=tr((A*S)^i) and \theta_i=\mu'*(A*S)^{i-1}*A*\mu.
%  Note: This makes use of a recursive algorithm.
%
function [c,y] = qmom_rec(k)
   c = cell(k,1);
   p = cell(k,1);
   f = cell(k,1);
%
%  F(i,j) is the number of integer partitions of i with j parts or less,
%  it is also the number of integer partitions of i whose first part
%  is j or less.
%
   F = ones(k);
   for j=2:k
       F(:,j) = F(:,j-1);
       F(j,j) = F(j,j)+1;
       for i=j+1:k
           F(i,j) = F(i,j)+F(i-j,j);
       end
   end
%
%   Within c{i}{j}, there are prod_{i=1}^j(1+f_{k_i}) elements,
%   they correspond to coefficients associated with 
%   \tau_{k_i} or \theta_{k_i}, with the last index changes
%   most frequently.
%
   c{1}{1} = [1 1];
   p{1} = 1;
   f{1} = 2;
%   
%   q is used to store the cumulants, 1st column is
%   the coefficients for \tau_i, 2nd column is the
%   coefficients for \theta_i.
%
   q = zeros(k,2);
   q(1,:) = [1 1];
   for i=2:k
       q(i,1) = 2*q(i-1,1)*(i-1);
       q(i,2) = i*q(i,1);
       p{i} = ip_desc(i);
       np = size(p{i},1);
       f{i} = zeros(np,i);
       for j=1:np
           p1 = p{i}(j,:);
           p1(p1==0) = [];
           p2 = unique(p1);
           nf = 1;
           for i1=1:length(p2)
               f1 = sum(p1==p2(i1))+1;
               f{i}(j,p2(i1)) = f1;
               nf = nf*f1;
           end
           c{i}{j} = zeros(1,nf);
       end
       c{i}{1} = q(i,:);      % This is for the partition (i)
%   Use recurrence relation
       cc = 1;
       for j=1:i-1
           q1 = q(i-j,:);
           cc = cc*(i-j)/j;
           for ii=1:length(c{j})
               c1 = c{j}{ii};
%   This is the ii-th partition of integer j 
               p2 = p{j}(ii,:);
               f2 = f{j}(ii,:);
               p1 = sort([p2 i-j],2,'descend');
%   This determines which partition of j that it belongs
%   after we multiply the entries of the cumulants
               j1 = part_ind(p1);
               f1 = f{i}(j1,:);
               f1u = fliplr(f1(f1~=0));
               f2u = fliplr(f2(f2~=0));
               lf1 = length(f1u);
               lf2 = length(f2u);
               ij = sum(unique(p2)>i-j)+1;
               x = [ones(1,lf2-1) 0];
               qq = flipud([1 cumprod(f1u(lf1:-1:2))]');
               for jj=1:length(c1)
                   for kk=lf2:-1:1
                       if x(kk)<f2u(kk)
                          x(kk) = x(kk)+1;
                          break
                       else
                          x(kk) = 1;
                       end
                   end
%
%   Using x to figure out the particular configuration
%   of \tau and \theta
%
                   if lf1==lf2
                      j2a = (x-1)*qq+1;
                      y = x;
                   else
                      y = [x(1:ij-1) 1 x(ij:end)];
                      j2a = (y-1)*qq+1;
                   end                
                   y(ij) = y(ij)+1;
                   j2b = (y-1)*qq+1;
                   c{i}{j1}(j2a) = c{i}{j1}(j2a)+cc*c1(jj)*q1(1);
                   c{i}{j1}(j2b) = c{i}{j1}(j2b)+cc*c1(jj)*q1(2);
               end     
           end
       end    
   end    
   c = c{k};
   if nargout>1
      p = p{k};
      f = f{k};
      nc = length(c);
      y = strings(nc,1);
      for i=1:nc
          c1 = c{i};
          f1 = f(i,:);
          p1 = p(i,:);
          p1u = sort(unique(p1(p1~=0)),2,'descend');
          f1u = fliplr(f1(f1~=0));
          lf1 = length(f1u);          
          x = [ones(1,lf1-1) 0];
          for jj=1:length(c1)
              for kk=lf1:-1:1
                  if x(kk)<f1u(kk)
                     x(kk) = x(kk)+1;
                     break
                  else
                     x(kk) = 1;
                  end
              end
              for kk=1:lf1
                  p1k = p1u(kk);
                  p1ks = num2str(p1k);
                  if x(kk)<f1u(kk)
                     if kk==1
                        tt1 = append('a_',p1ks);
                     else
                        tt1 = append(tt1,'*a_',p1ks);
                     end
                     if x(kk)<f1u(kk)-1
                        tt1 = append(tt1,'^',num2str(f1u(kk)-x(kk)));
                     end
                     if x(kk)>1
                        tt1 = append(tt1,'*h_',p1ks);
                        if x(kk)>2
                           tt1 = append(tt1,'^',num2str(x(kk)-1));
                        end
                     end
                  else
                     if kk==1
                        tt1 = append('h_',p1ks);
                     else
                        tt1 = append(tt1,'*h_',p1ks);
                     end
                     if x(kk)>2
                        tt1 = append(tt1,'^',num2str(x(kk)-1));
                     end
                  end
              end
              if c1(jj)>1
                 tt1 = append(num2str(c1(jj)),'*',tt1);
              end
              if jj==1
                 tt = tt1;
              else
                 tt = append(tt,'+',tt1);
              end
          end    
          y(i) = tt;
      end
   end              

function y1 = part_ind(lam)
%
%  This function takes an integer partition lam of k and returns the location of 
%  lam within the list of integer partitions with |kappa|=k, where kappa is 
%  arranged in reverse lexicographical order.
%
   n1 = sum(lam);
   y1 = F(n1,n1);
   for i2=1:length(lam)
       if lam(i2)>1
          k2 = lam(i2);
          y1 = y1-F(n1,k2-1);
          n1 = n1-k2;
       else
          break
       end
   end
end

end   