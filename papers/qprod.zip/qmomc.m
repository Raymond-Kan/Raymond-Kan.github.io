%QMOMC  Explicit expression of E[(z'*A*z)^k] for z ~ N(0,S), by integer partitions.
%
%   c = QMOMC(k) returns the coefficient of tau_kappa = prod_j tr((A*S)^{kappa_j})
%   in the explicit expression of E[(z'*A*z)^k] for z ~ N(0,S), for every
%   integer partition kappa of k in the order produced by IP_DESC
%   (eq. (10) of the paper with mu = 0: the coefficient is
%   k! 2^k / prod_i f_i! (2i)^{f_i}).
%
%   See also QMOM, QMOMC_REC.
%
function c = qmomc(k)
   p = ip_desc(k);
   np = size(p,1);
   kfac = cumprod(1:k);
   c = ones(1,np);
   for i=1:np-1
       pp = p(i,:);
       pp(pp==0) = [];
       c1 = kfac(k)*2^k;
       for j=1:p(i,1)
           fj = sum(pp==j);
           if fj>0
              c1 = c1/(2*j)^fj/kfac(fj);
           end
       end
       c(i) = c(i)*c1;
   end 
