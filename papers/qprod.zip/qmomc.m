%
%  This Matlab function expresses E[(z'*A*z)^k], where
%  z ~ N(0_m,S) in terms of \tau_\kappa=tr((A*S)^\kappa_1)*...*tr((A*S)^\kappa_r),
%  and \kappa = (\kappa_1,...,\kappa_r) is an integer partition of k.
%  The output is a set of coefficients associated with \tau_\kappa,
%  where \kappa \vdash k is arranged in reverse lexicographical order.
%
function c = qmomc(k)
   p = ip_desc(k);
   np = size(p,1);
   kfac = cumprod(1:k);
   c = ones(1,np);
   for i=1:np-1
       pp = p(i,:);
       pp(pp==0) = [];
       c1 = kfac(k)*2^k;
       for j=1:p(i,1)
           fj = sum(pp==j);
           if fj>0
              c1 = c1/(2*j)^fj/kfac(fj);
           end
       end
       c(i) = c(i)*c1;
   end 
