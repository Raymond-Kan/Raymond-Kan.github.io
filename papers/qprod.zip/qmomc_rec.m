%
%  This Matlab function expresses E[(z'*A*z)^k], where
%  z ~ N(0_m,S) in terms of \tau_\kappa=tr((A*S)^\kappa_1)*...*tr((A*S)^\kappa_r),
%  and \kappa = (\kappa_1,...,\kappa_r) is an integer partition of k.
%  This makes use of a recursive algorithm.
%  The output is a set of coefficients associated with \tau_\kappa,
%  where \kappa \vdash k is arranged in reverse lexicographical order.
%
function c = qmomc_rec(k)
%
%  F(i,j) is the number of integer partitions of i with j parts or less,
%  it is also the number of integer partitions of i whose first part
%  is j or less.
%
   F = ones(k);
   for j=2:k
       F(:,j) = F(:,j-1);
       F(j,j) = F(j,j)+1;
       for i=j+1:k
           F(i,j) = F(i,j)+F(i-j,j);
       end
   end
%
%   c is used to store the coefficeints that are 
%   associated with \tau_\kappa, with \kappa arranged in
%   reverse lexicographical order.
%
   p = cell(k-1,1);
   for i=1:k-1
       p{i} = ip_desc(i);
   end   
   c = zeros(k,F(end));
   c(1,1) = 1;
   q = 1;
   for i=2:k
       q = 2*(i-1)*q;
       c1 = q;
       c(i,1) = c1;
       for j=1:i-1
           c1 = c1/(2*j);
           for ii=1:size(p{j},1)
               pp = sort([i-j p{j}(ii,:)],2,'descend');
               pind = part_ind(pp);
               c(i,pind) = c(i,pind)+c1*c(j,ii);
           end
       end
   end     
   c = c(k,:);
   
function y1 = part_ind(lam)
%
%  This function takes an integer partition lam of k and returns the location of 
%  lam within the list of integer partitions with |kappa|=k, where kappa is 
%  arranged in reverse lexicographical order.
%
   n1 = sum(lam);
   y1 = F(n1,n1);
   for i2=1:length(lam)
       if lam(i2)>1
          k2 = lam(i2);
          y1 = y1-F(n1,k2-1);
          n1 = n1-k2;
       else
          break
       end
   end
end

end   