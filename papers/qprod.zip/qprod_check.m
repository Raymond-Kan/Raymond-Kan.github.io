function [A,S,L,s,n] = qprod_check(fname,A,S,mu,s,n,cplx)
%QPROD_CHECK  Validate and normalize the inputs of the qprod functions.
%
%   [A,S,L,s,n] = QPROD_CHECK(fname,A,S,mu,s,n,cplx) checks that
%     - A is an m x m x k array of symmetric (cplx = false) or Hermitian
%       (cplx = true) matrices,
%     - S is an m x m symmetric/Hermitian matrix,
%     - mu is either empty (central case), an m x 1 vector (the mean of
%       z, in which case L = mu*mu' is returned) or an m x m
%       symmetric/Hermitian matrix (a Wishart noncentrality matrix, which
%       is returned as L); L = [] is returned when mu is empty or zero,
%     - s is a vector of k nonnegative integers (s = [] means ones(1,k)),
%     - n is a nonnegative scalar (degrees of freedom; n = [] means 1).
%   fname is the name of the calling function, used in error messages.
%   Symmetry is tested up to a relative tolerance of 1e-8.
%
%   See also QPRODA, QPRODS, QPRODW.

   if cplx
      word = 'Hermitian';
   else
      word = 'symmetric';
   end
   if ndims(A) > 3 || size(A,1) ~= size(A,2)
      error('qprod:badInput','%s: A must be an m x m x k array.',fname);
   end
   [m,~,k] = size(A);
   if ~isequal(size(S),[m m])
      error('qprod:badInput','%s: S must be an m x m matrix.',fname);
   end
   if ~issym(S)
      error('qprod:badInput','%s: S must be %s.',fname,word);
   end
   for i = 1:k
       if ~issym(A(:,:,i))
          error('qprod:badInput','%s: A(:,:,%d) must be %s.',fname,i,word);
       end
   end
   if isempty(mu)
      L = [];
   elseif isvector(mu) && numel(mu) == m
      mu = mu(:);
      if any(mu ~= 0)
         L = mu*mu';
      else
         L = [];
      end
   elseif isequal(size(mu),[m m])
      if ~issym(mu)
         error('qprod:badInput','%s: the noncentrality matrix must be %s.',fname,word);
      end
      if any(mu(:) ~= 0)
         L = mu;
      else
         L = [];
      end
   else
      error('qprod:badInput','%s: mu must be an m x 1 vector (or an m x m noncentrality matrix).',fname);
   end
   if isempty(s)
      s = ones(1,k);
   end
   if numel(s) ~= k
      error('qprod:badInput','%s: length of s must equal size(A,3).',fname);
   end
   if any(s < 0) || any(s ~= round(s)) || ~isreal(s)
      error('qprod:badInput','%s: s must contain nonnegative integers.',fname);
   end
   s = double(s(:).');
   if isempty(n)
      n = 1;
   end
   if ~isscalar(n) || ~isreal(n) || n < 0
      error('qprod:badInput','%s: n must be a nonnegative scalar.',fname);
   end

   function ok = issym(M)
      ok = norm(M-M','fro') <= 1e-8*(1+norm(M,'fro'));
   end
end
