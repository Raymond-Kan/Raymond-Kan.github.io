function y = qprod_core(A,S,L,s,n,cplx)
%QPROD_CORE  Fast evaluation of product moments of quadratic forms.
%
%   y = QPROD_CORE(A,S,L,s,n,cplx) computes
%
%      E[ prod_{i=1}^k tr(W*A_i)^{s_i} ],
%
%   where W ~ W_m(n,S,L) (real Wishart, cplx = false) or
%   W ~ CW_m(n,S,L) (complex Wishart, cplx = true), with degrees of
%   freedom n, covariance matrix S (positive semidefinite, possibly
%   singular) and noncentrality matrix L = sum_t mu_t*mu_t' (L = [] for
%   the central case).  With n = 1 and L = mu*mu' this is
%   E[prod_i (z'*A_i*z)^{s_i}] for z ~ N(mu,S) (or z ~ CN(mu,S)), which is
%   how QPRODA, QPRODS and their variants call it.  Inputs are not
%   validated here; see QPROD_CHECK.
%
%   Method.  Rather than enumerating the explicit expression term by term
%   (see QPROD_ENUM for that), the function evaluates the same quantity
%   through the cumulant generating function.  For every sub-multiset b
%   of the multiset {1^{s_1},...,k^{s_k}}, let
%
%      Q_b = sum over all distinct arrangements (i_1,...,i_r) of b of
%            A_{i_1}*S*A_{i_2}*S* ... *A_{i_r}*S,        r = |b|.
%
%   Grouping the arrangements by their last element gives the recursion
%   Q_b = sum_{i: b_i>0} Q_{b-e_i}*A_i*S, so all Q_b are obtained with
%   O(k prod(s_i+1)) products of m x m matrices and no enumeration of
%   words.  The joint cumulants of tr(W*A_1),...,tr(W*A_k) are
%
%      kappa_b = (prod_i b_i!) 2^{r-1} [ n tr(Q_b)/r + sum_{i: b_i>0} tr(Q_{b-e_i} A_i L) ]
%
%   in the real case (the factor 2^{r-1} is absent in the complex case),
%   and the moments follow from the multivariate moment-cumulant
%   recursion
%
%      m_s = sum_{0 < b <= s, b_j >= 1} prod_i C(s_i - d_ij, b_i - d_ij) kappa_b m_{s-b},
%
%   where j is any index with s_j >= 1.  The total cost is
%   O(k m^3 prod(s_i+1) + prod(s_i+1)(s_i+2)/2), which for k distinct
%   matrices is O(k m^3 2^k + 3^k) instead of the factorial cost of the
%   explicit expression; k = 15 distinct matrices take a few seconds.
%
%   See also QPRODA, QPRODS, QPRODW, QPROD_ENUM, QPROD_CHECK.

   s = s(:).';
   keep = s > 0;
   s = s(keep);
   A = A(:,:,keep);
   k = numel(s);
   if k == 0
      y = 1;
      return
   end
   m = size(A,1);
   noncentral = ~isempty(L);
   dims = s+1;
   N = prod(dims);
   stride = cumprod([1 dims(1:end-1)]);
%
%  b(idx,:) is the multiplicity vector of the sub-multiset with linear
%  index idx = 1 + b*stride', and r(idx) = |b|.
%
   b = zeros(N,k);
   for i = 1:k
       b(:,i) = mod(floor((0:N-1)'/stride(i)),dims(i));
   end
   r = sum(b,2);
   fb = round(exp(sum(gammaln(b+1),2)));     % prod_i b_i!
   AS = cell(1,k);
   ALt = cell(1,k);
   for i = 1:k
       AS{i} = A(:,:,i)*S;
       if noncentral
          ALt{i} = (A(:,:,i)*L).';          % so that trace(P*A_i*L) = sum(sum(P.*ALt{i}))
       end
   end
%
%  Symmetric sums Q_b and cumulants kappa_b, level by level in r = |b|.
%  Only the previous level of Q is needed, so earlier levels are released.
%
   if cplx
      cf = ones(1,sum(s));
   else
      cf = 2.^((1:sum(s))-1);
   end
   [~,order] = sort(r);
   Q = cell(N,1);
   Q{1} = eye(m);
   kappa = zeros(N,1);
   rprev = 0;
   lastlevel = [];
   thislevel = [];
   for t = 2:N
       idx = order(t);
       ri = r(idx);
       if ri ~= rprev
          % level ri starts: level ri-2 is no longer needed
          for u = lastlevel
              Q{u} = [];
          end
          lastlevel = thislevel;
          thislevel = [];
          rprev = ri;
       end
       thislevel(end+1) = idx; %#ok<AGROW>
       Qb = zeros(m);
       H = 0;
       for i = 1:k
           if b(idx,i) > 0
              P = Q{idx-stride(i)};
              Qb = Qb + P*AS{i};
              if noncentral
                 H = H + sum(sum(P.*ALt{i}));
              end
           end
       end
       Q{idx} = Qb;
       kappa(idx) = fb(idx)*cf(ri)*(n*trace(Qb)/ri + H);
   end
   if cplx
      kappa = real(kappa);
   end
%
%  Moment-cumulant recursion over the sub-multisets of s.
%
   smax = max(s);
   C = zeros(smax+1);                         % C(a+1,c+1) = nchoosek(a,c)
   for a = 0:smax
       for c = 0:a
           C(a+1,c+1) = round(exp(gammaln(a+1)-gammaln(c+1)-gammaln(a-c+1)));
       end
   end
   mom = zeros(N,1);
   mom(1) = 1;
   for idx = 2:N
       sv = b(idx,:);
       j = find(sv,1);
       % linear indices of all b <= sv with b_j >= 1
       offs = stride(j)*(1:sv(j))';
       for i = 1:k
           if i ~= j && sv(i) > 0
              offs = reshape(offs + stride(i)*(0:sv(i)),[],1);
           end
       end
       rows = 1 + offs;
       bb = b(rows,:);
       svd = sv; svd(j) = svd(j)-1;
       bb(:,j) = bb(:,j)-1;
       coef = ones(numel(rows),1);
       for i = 1:k
           if svd(i) > 0
              coef = coef.*C(svd(i)+1,bb(:,i)+1).';
           end
       end
       mom(idx) = sum(coef.*kappa(rows).*mom(idx-rows+1));
   end
   y = mom(N);
   if cplx
      y = real(y);
   end
end
