function y = qprod_enum(A,S,mu,s,cplx,n)
%QPROD_ENUM  Term-by-term evaluation of the explicit expression of the paper.
%
%   y = QPROD_ENUM(A,S,mu,s) returns E[prod_{i=1}^k (z'*A_i*z)^{s_i}] for
%   z ~ N(mu,S) by evaluating the explicit expression of Proposition 4 of
%   the paper (which reduces to Proposition 2 when all s_i = 1 and to
%   Corollary 1 when mu = 0) literally, one canonical term at a time.
%   y = QPROD_ENUM(A,S,mu,s,true) does the same for z ~ CN(mu,S) and
%   Hermitian A_i (Proposition 3), and
%   y = QPROD_ENUM(A,S,L,s,cplx,n) with an m x m noncentrality matrix L
%   and degrees of freedom n gives the Wishart product moments
%   E[prod_i tr(W*A_i)^{s_i}] of Corollaries 2 and 3.  mu = [] or
%   L = [] selects the central case; s = [] means ones(1,k).
%
%   This function is the reference implementation of the formulas: it is
%   slow (its cost grows like the number of terms, see QCOUNTS), and its
%   only purpose is to check the fast evaluator QPROD_CORE, which the
%   user-level functions QPRODA, QPRODS, QPRODW, ... call.  It follows the
%   paper step by step:
%
%     * the multiset partitions pi of {1^{s_1},...,k^{s_k}} come from
%       MSETPART (the set B_s of the paper);
%     * the coefficient of pi is 2^{|s|-f_1-f_2} c_s(pi) in the real case
%       and 2^{l(pi)-f_1-f_2} c_s(pi) in the complex case, with
%       c_s(pi) = prod_j s_j! / (prod_{i,j} b_{ij}! prod h!) (eq. (cs));
%     * the block sum lambda_b of a block with content b (eq. (48)) is
%       formed from all canonical theta- and tau-words with that content,
%       found by brute force among the distinct arrangements of the
%       multiset (a word is a canonical theta-word when it does not
%       exceed its reversal, and a canonical tau-word when it is the
%       smallest of its rotations and reflections), with the
%       multiplicities c_j and d_j of Lemma 9;
%     * theta_nu = tr(A_nu1 S A_nu2 S ... S A_nup L) and
%       tau_nu = n tr(A_nu1 S ... A_nup S), with real parts taken in the
%       complex case.
%   Block sums are cached, so each content b is processed once.
%
%   See also QPROD_CORE, QPRODA, QPRODS, QPRODW, MSETPART, QCOUNTS.

   if nargin < 4, s = []; end
   if nargin < 5 || isempty(cplx), cplx = false; end
   if nargin < 6, n = []; end
   [A,S,L,s,n] = qprod_check('qprod_enum',A,S,mu,s,n,cplx);
   keep = s > 0;
   s = s(keep);
   A = A(:,:,keep);
   k = numel(s);
   if k == 0
      y = 1;
      return
   end
   m = size(A,1);
   noncentral = ~isempty(L);
   AS = cell(1,k);
   for i = 1:k
       AS{i} = A(:,:,i)*S;
   end
   ss = sum(s);
   fac = cumprod([1 1:ss]);                  % fac(j+1) = j!
   dims = s+1;
   stride = cumprod([1 dims(1:end-1)]);
   lambda = nan(prod(dims),1);               % cache of block sums by content
   P = msetpart(s);
   y = 0;
   for t = 1:numel(P)
       B = P{t};                             % blocks (rows) of this partition
       l = size(B,1);
       bsize = sum(B,2);
       f12 = sum(bsize <= 2);
       if cplx
          coef = 2^(l-f12);
       else
          coef = 2^(ss-f12);
       end
       % c_s(pi) = prod_j s_j! / ( prod_{ij} b_ij! * prod over distinct
       % blocks of (multiplicity h)! )
       coef = coef*prod(fac(s+1))/prod(prod(fac(B+1)));
       i = 1;
       while i <= l
          h = 1;
          while i+h <= l && isequal(B(i+h,:),B(i,:))
             h = h+1;
          end
          coef = coef/fac(h+1);
          i = i+h;
       end
       val = coef;
       for i = 1:l
           idx = 1 + B(i,:)*stride';
           if isnan(lambda(idx))
              lambda(idx) = blocksum(B(i,:));
           end
           val = val*lambda(idx);
       end
       y = y + val;
   end

   function lam = blocksum(b)
   %  lambda_b of eq. (48): 2^{1(l(b)=2)} sum_j c_j theta_{p_j} + sum_j d_j tau_{q_j}
      ell = sum(b);
      fb = prod(fac(b+1));                   % prod_l b_l!
      w = zeros(1,ell);                      % first arrangement (sorted)
      pos = 0;
      for i = 1:k
          w(pos+1:pos+b(i)) = i;
          pos = pos+b(i);
      end
      th = 0;
      ta = 0;
      while ~isempty(w)
         % canonical theta-word: w <= reverse(w) lexicographically
         wr = fliplr(w);
         if noncentral && ~lexgt(w,wr)
            c = fb;
            if ell > 1 && isequal(w,wr)
               c = c/2;
            end
            th = th + c*theta(w);
         end
         % canonical tau-word: w is the smallest of its 2*ell rotations
         % and reflections
         [iscan,rho,onenk] = taucanon(w);
         if iscan
            if onenk && ell > 2
               d = rho/(2*ell)*fb;
            else
               d = rho/ell*fb;
            end
            ta = ta + d*tau(w);
         end
         w = nmp(w);
      end
      lam = 2^(ell == 2)*th + ta;
   end

   function v = theta(w)
      P0 = A(:,:,w(1));
      for j = 2:numel(w)
          P0 = P0*S*A(:,:,w(j));
      end
      v = trace(P0*L);
      if cplx, v = real(v); end
   end

   function v = tau(w)
      P0 = AS{w(1)};
      for j = 2:numel(w)
          P0 = P0*AS{w(j)};
      end
      v = n*trace(P0);
      if cplx, v = real(v); end
   end
end

function g = lexgt(a,b)
%  true if a > b lexicographically
   d = find(a ~= b,1);
   g = ~isempty(d) && a(d) > b(d);
end

function [iscan,rho,onenk] = taucanon(w)
%  iscan: w is the lexicographically smallest among its rotations and the
%  rotations of its reversal; rho: primitive period of w; onenk: the
%  bracelet maps to one necklace (its reversal is one of its rotations).
   ell = numel(w);
   iscan = true;
   rho = ell;
   onenk = false;
   wr = fliplr(w);
   for r = 0:ell-1
       u = [w(r+1:end) w(1:r)];
       if lexgt(w,u)
          iscan = false;
          return
       end
       if r > 0 && isequal(u,w) && r < rho
          rho = r;
       end
       u = [wr(r+1:end) wr(1:r)];
       if lexgt(w,u)
          iscan = false;
          return
       end
       if isequal(u,w)
          onenk = true;
       end
   end
end
