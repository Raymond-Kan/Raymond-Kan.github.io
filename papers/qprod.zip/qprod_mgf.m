function y = qprod_mgf(A,S,mu,s,cplx,n)
%QPROD_MGF  Product moments by symbolic differentiation of the moment generating function.
%
%   y = QPROD_MGF(A,S,mu,s) computes E[prod_{i=1}^k (z'*A_i*z)^{s_i}] for
%   z ~ N(mu,S) as the mixed derivative
%
%      d^{|s|} / (dt_1^{s_1} ... dt_k^{s_k})  E[exp(sum_i t_i z'*A_i*z)]  at t = 0,
%
%   using the closed form of the joint moment generating function,
%
%      E[exp(z'*M(t)*z)] = |I - 2 S M(t)|^{-1/2} exp( tr( M(t) (I - 2 S M(t))^{-1} mu mu' ) ),
%
%   M(t) = sum_i t_i A_i, which is valid for singular S.  The derivative is
%   taken symbolically, so the function needs the Symbolic Math Toolbox in
%   Matlab or the symbolic package in GNU Octave (it calls PKG LOAD
%   SYMBOLIC itself), and an error is raised when neither is available.
%   y = QPROD_MGF(A,S,mu,s,true) uses the complex normal moment
%   generating function |I - S M(t)|^{-1} exp(tr(M(t)(I - S M(t))^{-1} mu mu'))
%   for z ~ CN(mu,S).  y = QPROD_MGF(A,S,L,s,cplx,n), with an m x m
%   noncentrality matrix L and degrees of freedom n, gives the Wishart
%   product moments E[prod_i tr(W*A_i)^{s_i}] for W ~ W_m(n,S,L) (exponent
%   -n/2) or W ~ CW_m(n,S,L) (exponent -n).  mu = [] or L = [] gives the
%   central case; s = [] means ones(1,k).
%
%   The inputs are converted to symbolic numbers with SYM, so the result
%   is exact (up to the final conversion to double) when A, S, mu and n
%   have rational entries.  The cost grows quickly with m, k and |s|; the
%   function is meant for small examples and is used by TEST_ALL as an
%   independent check of QPROD_CORE and QPROD_ENUM.
%
%   See also QPROD_WICK, QPRODS_SIM, QPROD_CORE, QPROD_ENUM, TEST_ALL.

   if nargin < 4, s = []; end
   if nargin < 5 || isempty(cplx), cplx = false; end
   if nargin < 6, n = []; end
   [A,S,L,s,n] = qprod_check('qprod_mgf',A,S,mu,s,n,cplx);
   if exist('OCTAVE_VERSION','builtin') ~= 0
      try
         pkg load symbolic
      catch
         error('qprod:noSymbolic','qprod_mgf: the Octave symbolic package is required.');
      end
   elseif exist('sym','file') ~= 2
      error('qprod:noSymbolic','qprod_mgf: the Symbolic Math Toolbox is required.');
   end
   m = size(A,1);
   k = numel(s);
   t = sym('t',[1 k]);
   ws = warning('off','all');                 % Octave's sym() warns on non-integer input
   M = sym(zeros(m));
   for i = 1:k
       M = M + t(i)*sym(A(:,:,i));
   end
   Ss = sym(S);
   ns = sym(n);
   if ~isempty(L)
      Ls = sym(L);
   end
   warning(ws);
   if cplx
      G = sym(eye(m)) - Ss*M;
      f = det(G)^(-ns);
   else
      G = sym(eye(m)) - 2*Ss*M;
      f = det(G)^(-ns/2);
   end
   if ~isempty(L)
      f = f*exp(trace(M*(G\sym(eye(m)))*Ls));
   end
   for i = 1:k
       for j = 1:s(i)
           f = diff(f,t(i));
       end
   end
   y = double(subs(f,t,zeros(1,k)));
   if cplx
      y = real(y);
   end
end
