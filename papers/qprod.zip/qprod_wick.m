function y = qprod_wick(A,S,mu,s,cplx)
%QPROD_WICK  Isserlis-Wick evaluation of E[prod_i (z'*A_i*z)^{s_i}].
%
%   y = QPROD_WICK(A,S,mu,s) computes E[prod_{i=1}^k (z'*A_i*z)^{s_i}] for
%   z ~ N(mu,S) directly from the Isserlis-Wick theorem, without using any
%   of the combinatorial results of the paper.  y = QPROD_WICK(A,S,mu,s,true)
%   does the same for z ~ CN(mu,S) (proper complex normal, Hermitian A_i).
%   mu = [] gives the central case and s = [] means ones(1,k).
%
%   Method.  Write z = mu + x with x ~ N(0,S).  Each factor expands as
%      z'*A*z = mu'*A*mu + (2*A*mu)'*x + x'*A*x
%   (in the complex case: mu'*A*mu + (mu'*A)*x + x'*(A*mu) + x'*A*x), and
%   the product of |s| factors is expanded into a sum of products of
%   constants, linear forms and quadratic forms in x.  The expectation of
%   each such product is a Gaussian moment, which Wick's theorem writes as
%   a sum over all perfect matchings of the "slots" (one slot per linear
%   form, two per quadratic form) of products of covariances.  Following
%   the matched slots through the quadratic forms turns each matching into
%   a product of traces of chains  tr(A S A S ...)  and of quadratic forms
%   in mu, which is what the code evaluates.  In the complex case Wick's
%   theorem pairs each x with a conjugated x', so the matchings are the
%   bijections between the "x slots" and the "x' slots".
%
%   The cost grows like 3^|s| (2|s|-1)!! and the function is meant for
%   |s| <= 5 (|s| <= 6 in the central case); it exists only to provide an
%   independent check of QPROD_CORE and QPROD_ENUM in TEST_ALL.
%
%   See also QPROD_MGF, QPRODS_SIM, QPROD_CORE, QPROD_ENUM, TEST_ALL.

   if nargin < 4, s = []; end
   if nargin < 5 || isempty(cplx), cplx = false; end
   [A,S,~,s] = qprod_check('qprod_wick',A,S,mu,s,1,cplx);
   m = size(A,1);
   if isempty(mu)
      mu = zeros(m,1);
   end
   mu = mu(:);
   noncentral = any(mu ~= 0);
%
%  list of factors (matrices) with repetition
%
   F = cell(1,sum(s));
   nf = 0;
   for i = 1:numel(s)
       for j = 1:s(i)
           nf = nf+1;
           F{nf} = A(:,:,i);
       end
   end
   if nf == 0
      y = 1;
      return
   end
   if ~cplx
      % each factor: const c, linear vector l (l'*x), quadratic matrix
      cst = zeros(1,nf); lin = cell(1,nf);
      for j = 1:nf
          cst(j) = mu'*F{j}*mu;
          lin{j} = 2*F{j}*mu;
      end
      if noncentral
         ntype = 3;
      else
         ntype = 1;
      end
      y = 0;
      typ = zeros(1,nf);                      % 0 const, 1 linear, 2 quadratic
      for choice = 0:ntype^nf-1
          c = choice;
          for j = 1:nf
              typ(j) = mod(c,ntype); c = floor(c/ntype);
          end
          if ntype == 1
             typ(:) = 2;
          end
          val = prod(cst(typ == 0));
          if val == 0, continue, end
          val = val*wick_real(find(typ == 1),find(typ == 2));
          y = y + val;
      end
   else
      cst = zeros(1,nf); rowv = cell(1,nf); colv = cell(1,nf);
      for j = 1:nf
          cst(j) = real(mu'*F{j}*mu);
          rowv{j} = mu'*F{j};                 % (mu'*A) x : an "x slot"
          colv{j} = F{j}*mu;                  % x' (A*mu) : an "x' slot"
      end
      if noncentral
         ntype = 4;
      else
         ntype = 1;
      end
      y = 0;
      typ = zeros(1,nf);                      % 0 const, 1 row-linear, 2 col-linear, 3 quadratic
      for choice = 0:ntype^nf-1
          c = choice;
          for j = 1:nf
              typ(j) = mod(c,ntype); c = floor(c/ntype);
          end
          if ntype == 1
             typ(:) = 3;
          end
          val = prod(cst(typ == 0));
          if val == 0, continue, end
          val = val*wick_complex(find(typ == 1),find(typ == 2),find(typ == 3));
          y = y + val;
      end
      y = real(y);
   end

   function v = wick_real(L,Qd)
   %  E[ prod_{j in L} l_j'x  prod_{j in Qd} x'A_j x ],  x ~ N(0,S)
      % slots: linear j -> one slot; quadratic j -> two slots
      nL = numel(L); nQ = numel(Qd);
      ns = nL + 2*nQ;
      if mod(ns,2) == 1
         v = 0;
         return
      end
      vert = [L Qd Qd];                        % vertex of each slot
      isq = [false(1,nL) true(1,2*nQ)];
      other = [zeros(1,nL) nL+nQ+(1:nQ) nL+(1:nQ)];  % the other slot of a quadratic vertex
      partner = zeros(1,ns);
      v = 0;
      match(1);

      function match(first)
         while first <= ns && partner(first) > 0
            first = first+1;
         end
         if first > ns
            v = v + evalmatch();
            return
         end
         for second = first+1:ns
             if partner(second) == 0
                partner(first) = second; partner(second) = first;
                match(first+1);
                partner(first) = 0; partner(second) = 0;
             end
         end
      end

      function val = evalmatch()
         val = 1;
         done = false(1,ns);
         % paths: start at linear slots
         for u0 = find(~isq)
             if done(u0), continue, end
             row = lin{vert(u0)}.';
             done(u0) = true;
             u = u0;
             while true
                w = partner(u);
                done(w) = true;
                if ~isq(w)
                   val = val*(row*S*lin{vert(w)});
                   break
                end
                row = row*S*F{vert(w)};
                u = other(w);
                done(u) = true;
             end
         end
         % cycles: remaining quadratic slots
         for u0 = find(isq)
             if done(u0), continue, end
             P = F{vert(u0)};
             done(u0) = true;
             u = other(u0);
             done(u) = true;
             while true
                w = partner(u);
                done(w) = true;
                if w == u0
                   val = val*trace(P*S);
                   break
                end
                P = P*S*F{vert(w)};
                u = other(w);
                done(u) = true;
             end
         end
      end
   end

   function v = wick_complex(R,C,Qd)
   %  E[ prod_{j in R} (mu'A_j) x  prod_{j in C} x'(A_j mu)  prod_{j in Qd} x'A_j x ],
   %  x ~ CN(0,S): pair every x slot with an x' slot, E[x x'] = S.
      outv = [R Qd];                           % vertices with an x slot
      inv_ = [C Qd];                           % vertices with an x' slot
      no = numel(outv);
      if no ~= numel(inv_)
         v = 0;
         return
      end
      isqo = [false(1,numel(R)) true(1,numel(Qd))];
      isqi = [false(1,numel(C)) true(1,numel(Qd))];
      v = 0;
      perm = zeros(1,no);
      used = false(1,no);
      place(1);

      function place(j)
         if j > no
            v = v + evalperm();
            return
         end
         for q = 1:no
             if ~used(q)
                used(q) = true; perm(j) = q;
                place(j+1);
                used(q) = false;
             end
         end
      end

      function val = evalperm()
         val = 1;
         done = false(1,no);                   % out-slots consumed
         % paths start at row-linear vertices
         for j0 = find(~isqo)
             row = rowv{outv(j0)};
             j = j0;
             while true
                done(j) = true;
                q = perm(j);                   % in-slot index
                w = inv_(q);
                if ~isqi(q)
                   val = val*(row*S*colv{w});
                   break
                end
                row = row*S*F{w};
                j = find(outv == w & isqo,1);  % continue from w's x slot
             end
         end
         % cycles among the remaining quadratic vertices
         for j0 = find(isqo)
             if done(j0), continue, end
             w0 = outv(j0);
             P = F{w0};
             j = j0;
             while true
                done(j) = true;
                q = perm(j);
                w = inv_(q);
                if w == w0
                   val = val*trace(P*S);
                   break
                end
                P = P*S*F{w};
                j = find(outv == w & isqo,1);
             end
         end
      end
   end
end
