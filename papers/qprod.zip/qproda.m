%
%  qproda.m     Date: 7/29/2023
%  This Matlab function computes the expectation 
%  of a product of k quadratic forms in normal 
%  random variables with mean mu and a covariance
%  matrix S.  
%  Input
%  A: symmetric matrix of m x m x k
%  S: covariance matrix of z
%  mu: mean of z
%  Output
%  y: E[Q_1*Q_2*...*Q_k],
%  where Q_i=z'*A_i*z and z~N(mu,S).
%
function y = qproda(A,S,mu)
   k = size(A,3);
   if k==1
      y = trace(A*S)+mu'*A*mu;
      return
   end
   if k==2
      A1 = A(:,:,1);
      A2 = A(:,:,2);
      A1S = A1*S;
      A2S = A2*S; 
      Q1 = trace(A1S)+mu'*A1*mu;
      Q2 = trace(A2S)+mu'*A2*mu;
      y = 2*trace(A1S*A2S)+4*mu'*A1S*A2*mu+Q1*Q2;
      return
   end
   A1 = zeros(size(A,[2 3]));
   for i=1:k
       A1(:,i) = A(:,:,i)*mu;
       A(:,:,i) = A(:,:,i)*S;
   end
   fack = cumprod([1:k]);
   nb = ones(1,k,'uint64');    % number of bracelets with different lengths
   nh = ones(1,k,'uint64');    % number of possible permutations with first element greater than the last element
   for i=3:k
       nh(i) = fack(i)/2;
       nb(i) = nh(i-1);
   end
   y = 0;
%
%  Create bracelet index for i=1:k
%   
   brace = cell(1,k+1);
   for i=1:k+1
       brace{i} = fixbracef(i);
   end
%   
%  The algorithm for creating the next partition of
%  an n-set is based on 
%  Combinatorial Algorithms for Computers and Calculators,
%  2nd edition, Nijenhuis and Wilf, Chapter 11
%  nc is the number of classes
%  p(1:nc) is the number of elements in class 1 to nc
%  q(1:k) tells us the class that each element belongs to
%
%  first entry
%
   p = [k zeros(1,k-1)];
   q = ones(1,k);
   nc = 1;
   nb1 = nb(k);
   nh1 = nh(k);
   c = 2^k;
   v = uint8(1:k);
   for count=1:nb1
       ii = nthperm(v,brace{k}(count));
       A0 = A(:,:,ii(1));
       for j=2:k
           A0 = A0*A(:,:,ii(j));
       end
       y = y+c*trace(A0);
   end
   for count=1:nh1
       ii = nthperm(v,brace{k+1}(count));
       A0 = A1(:,ii(k));
       for j=k-1:-1:1
           A0 = A(:,:,ii(j))*A0;
       end
       y = y+c*mu'*A0;
   end
   while nc<k
      m = k;
      while p(q(m))==1
         q(m) = 1;
         m = m-1;
      end
      l = q(m);
      nc = nc+m-k;
      p(1) = p(1)+k-m;
      if l==nc
         nc = nc+1;
         p(nc) = 0;
      end
      q(m) = l+1;
      p(l) = p(l)-1;
      p(l+1) = p(l+1)+1;
      kappa = p(1:nc);
      y1 = 2^(k-sum(kappa==1|kappa==2));
      for i=1:nc
          pp = find(q==i);
          r = length(pp);
          if r==1
             y2 = trace(A(:,:,pp))+mu'*A1(:,pp);
          elseif r==2
             A0 = A(:,:,pp(1));
             y2 = trace(A0*A(:,:,pp(2)))+2*mu'*A0*A1(:,pp(2));
          else
             y2 = 0;
             for j=1:nb(r)
                 pp1 = nthperm(pp,brace{r}(j));
                 A0 = A(:,:,pp1(1));
                 for j1=2:r
                     A0 = A0*A(:,:,pp1(j1));
                 end
                 y2 = y2+trace(A0);
             end
             for j=1:nh(r)
                 pp1 = nthperm(pp,brace{r+1}(j));
                 A0 = A1(:,pp1(r));
                 for j1=r-1:-1:1
                     A0 = A(:,:,pp1(j1))*A0;
                 end
                 y2 = y2+mu'*A0;
             end
          end
          y1 = y1*y2;
      end
      y = y+y1;
   end
   