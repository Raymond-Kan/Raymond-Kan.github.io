function y = qproda(A,S,mu)
%QPRODA  Expectation of a product of quadratic forms in normal variables.
%
%   y = QPRODA(A,S,mu) returns E[Q_1*Q_2*...*Q_k], where Q_i = z'*A_i*z
%   and z ~ N(mu,S).
%   Input
%     A : m x m x k array of symmetric matrices, A(:,:,i) = A_i
%     S : m x m covariance matrix (positive semidefinite, may be singular)
%     mu: m x 1 mean vector
%
%   The value is computed by QPROD_CORE (cumulant recursion, cost
%   O(k m^3 2^k + 3^k)).  QPROD_ENUM evaluates the explicit expression
%   (Proposition 2 of the paper) term by term and QPRODASTR generates it
%   symbolically; QPRODA_SLOW, QPRODA_LM and QPRODA_KAN are independent
%   algorithms kept for cross-checking.
%
%   See also QPRODAC, QPRODS, QPRODA_COMP, QPRODW, QPROD_ENUM, QPRODASTR.

   [A,S,L] = qprod_check('qproda',A,S,mu,[],1,false);
   y = qprod_core(A,S,L,ones(1,size(A,3)),1,false);
end
