function y = qproda_comp(A,S,mu)
%QPRODA_COMP  Expectation of a product of Hermitian quadratic forms in complex normal variables.
%
%   y = QPRODA_COMP(A,S,mu) returns E[Q_1*Q_2*...*Q_k], where
%   Q_i = z'*A_i*z (z' the conjugate transpose) and z ~ CN(mu,S) follows
%   a proper multivariate complex normal distribution.
%   Input
%     A : m x m x k array of Hermitian matrices, A(:,:,i) = A_i
%     S : m x m Hermitian covariance matrix (positive semidefinite)
%     mu: m x 1 complex mean vector
%
%   The value is computed by QPROD_CORE (cumulant recursion).  QPROD_ENUM
%   evaluates the explicit expression (Proposition 3 of the paper) term by
%   term and QPRODASTR_COMP generates it symbolically; QPRODA_LM_COMP is
%   an independent algorithm kept for cross-checking.
%
%   See also QPRODA, QPRODAC_COMP, QPRODS_COMP, QPRODW_COMP, QPROD_ENUM.

   [A,S,L] = qprod_check('qproda_comp',A,S,mu,[],1,true);
   y = qprod_core(A,S,L,ones(1,size(A,3)),1,true);
end
