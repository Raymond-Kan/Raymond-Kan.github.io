%QPRODA_KAN  E[prod_i (z'*A_i*z)^{s_i}] by the moments-of-sums method of Kan (2008).
%
%   y = QPRODA_KAN(A,S,mu,s) computes E[prod_{i=1}^k (z'*A_i*z)^{s_i}] for
%   z ~ N(mu,S) by an algorithm that is independent of the combinatorial
%   results of the paper: the product moment is written as a linear
%   combination of moments of single quadratic forms
%   E[(z'*B*z)^{|s|}], B = sum_i x_i A_i (R. Kan, From moments of sum to
%   moments of product, J. Multivariate Anal. 99 (2008) 542-554), and each
%   of these is obtained from a recursive algorithm due to Brown (1986)
%   applied to the eigen-decomposition of S^{1/2} B S^{1/2}.  s = [] (or
%   omitted)
%   means ones(1,k).  Used by TEST_ALL as a cross-check of QPROD_CORE.
%
%   See also QPRODAC_KAN, QPRODS, QPROD_CORE, TEST_ALL.
%
function y = qproda_kan(A,V,mu,si)
p = size(A,3);
if nargin==3
   si = ones(1,p);
end
s = sum(si);
if s==0
   y = 1;
   return
end
if p==1&&s==1
   y = trace(A*(V+mu*mu'));
   return
end
r = rank(V);
[Q,D] = eig(V);
dd = diag(D);
[~,ii] = sort(dd,1,'descend');
ii = ii(1:r);
dd = dd(ii);
Q = Q(:,ii);
B1 = Q*diag(sqrt(dd));   % B1*B1' = V
if p==1
   A1 = B1'*A*B1;
   A1 = A1+A1';
   m = rank(A1);
   [P,D] = eig(A1);
   d = diag(D);
   [~,ii] = sort(abs(d),1,'descend');
   ii = ii(1:m);
   d = d(ii);
   P = P(:,ii);
   delta = (2*P'*B1'*A*mu./d).^2;
   alpha = 2*mu'*A*mu-sum(delta.*d);
   q = zeros(m,1);
   h = q;
   y = 1;
   for j=1:s
       q = d.*(y+q);
       h = delta.*q+d.*h;
       y = (sum(q+h)+alpha*y)/(2*j);
   end
   y = factorial(s)*y;
   return
end
%
%   Convert moment of product to moments of sum
%
% Sorting of si is to reduce the number of updates,
% it is really not necessary.
[si,inu] = sort(si,2,'descend');  
ls = length(si);
p = 2;
x = zeros(1,ls);
d = ones(1,ls);
kk = fliplr(cumprod(fliplr(si+1)));
B = 0.5*si(1)*A(:,:,inu(1));
for i=2:ls
    B = B+0.5*si(i)*A(:,:,inu(i));
end
y = 0;
for i=1:fix(kk(1)/2)
%
%   This part computes E[(z'*B*z)^s]/s!, where B=x_1*A_1+...+x_p*A_p
%   where z ~ N(mu,V).  
%
    B2 = B1'*B*B1;
    m = rank(B2);
    [P,D] = eig(B2+B2');
    d0 = diag(D);
    [~,ii] = sort(abs(d0),1,'descend');
    ii = ii(1:m);
    d0 = d0(ii);
    P = P(:,ii);
    delta = (2*P'*B1'*B*mu./d0).^2;
    alpha = 2*mu'*B*mu-sum(delta.*d0);
    q = zeros(m,1);
    h = q;
    y1 = 1;
    for j=1:s
        q = d0.*(y1+q);
        h = delta.*q+d0.*h;
        y1 = (sum(q+h)+alpha*y1)/(2*j);
    end
    y = y+p*y1;
    j1 = ls;
    while rem(i,kk(j1))==0
       j1 = j1-1;
    end
    x(j1) = x(j1)+d(j1);
    if d(j1)==1
       p = -round(p*(si(j1)+1-x(j1))/x(j1));    
       B = B-A(:,:,inu(j1));
    else
       p = -round(p*(x(j1)+1)/(si(j1)-x(j1)));
       B = B+A(:,:,inu(j1));
    end
    if x(j1)==0||x(j1)==si(j1)
       d(j1) = -d(j1);
    end
end
