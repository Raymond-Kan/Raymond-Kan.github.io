%
%  qproda_lm_comp.m     Date: 7/29/2023
%  This Matlab function computes the expectation of
%  a product of k Hermitian quadratic forms in 
%  complex normal random variables with mu and covariance 
%  matrix S.  
%  Input
%  A: Hermitian matrix of m x m x k
%  S: covariance matrix of z
%  mu: mean of z
%  Output
%  y: E[Q_1*Q_2*...*Q_k],
%  where Q_i=z'*A_i*z and z~CN(\mu,S).
%  Note: This expression is obtained based on Letac and 
%        and Massam (2008 JMVA)
%
function y = qproda_lm_comp(A,S,mu)
   k = size(A,3);
   if k==1
      y = real(trace(A*S)+mu'*A*mu);
      return
   end
   if k==2
      A1 = A(:,:,1);
      A2 = A(:,:,2);
      A1S = A1*S;
      A2S = A2*S; 
      Q1 = trace(A1S)+mu'*A1*mu;
      Q2 = trace(A2S)+mu'*A2*mu;
      y = real(trace(A1S*A2S)+mu'*A1S*A2*mu+mu'*A2S*A1*mu+Q1*Q2);
      return
   end
   a = zeros(1,k);
   h = zeros(1,k);
   A1 = zeros(size(A,[2 3]));
   for i=1:k
       A1(:,i) = A(:,:,i)*mu;
       A(:,:,i) = A(:,:,i)*S;
       a(i) = real(trace(A(:,:,i)));
       h(i) = real(mu'*A1(:,i));
   end
   kfac = cumprod(1:k);
   vind = uint8(1:k);
   H = setpart(k);
   y = ffun(vind)+gfun(vind);
   for i=1:k-1
       H = setpart(i);
       v1 = uint8([1:i]);
       y = y+ffun(v1)*gfun(vind(i+1:k));
       for j=2:nchoosek(k,i)
           for i1=i:-1:1
               if v1(i1)<k-i+i1
                  break
               end
           end
           v1(i1) = v1(i1)+1;
           for j1=i1+1:i
               v1(j1) = v1(j1-1)+1;
           end
           v2 = setdiff(vind,v1);
           y = y+ffun(v1)*gfun(v2);
       end
   end 

function y1 = ffun(nu)
   if length(nu)==1
      y1 = h(nu);
      return
   end
   y1 = 0;
   for ii=1:size(H,1)
       pi = H(ii,:);
       y1a = 1;
       nc = max(pi);
       for jj=1:nc
           pij = nu(find(pi==jj));
           lpij = length(pij);
           lam = 0;
           for k1=1:kfac(lpij) 
               kappa = nthperm(pij,k1);
               A0 = A1(:,kappa(lpij));
               for k2=lpij-1:-1:1
                   A0 = A(:,:,kappa(k2))*A0;
               end
               lam = lam+mu'*A0;
           end          
           y1a = y1a*lam;
       end
       y1 = y1+y1a;
   end
   y1 = real(y1);
end
   
function y1 = gfun(nu)
   if length(nu)==1
      y1 = a(nu);
      return
   end
   knu = length(nu);
   y1 = 0;
   v = uint8(1:knu);
   for ii=1:kfac(knu)
       p = nthperm(v,ii);
       y1a = 1;
       for jj=1:knu
           if p(jj)>0
              f = p(jj);
              p(jj) = 0;
              B = A(:,:,nu(jj));
              while f~=jj
                 r = f;
                 B = B*A(:,:,nu(r));
                 f = p(f);
                 p(r) = 0;
              end
              y1a = y1a*trace(B);
           end
       end
       y1 = y1+y1a;
   end
   y1 = real(y1);
end   

end