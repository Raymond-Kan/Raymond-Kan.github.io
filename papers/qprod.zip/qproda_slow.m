%
%  qproda_slow.m     Date: 2/1/2024
%  This Matlab function computes the expectation 
%  of a product of k quadratic forms in normal 
%  random variables.  The expression is in the 
%  form of linear combination of various product 
%  of traces.  This is based on a slow algorithm.
%  Input
%  A: symmetric matrix of m x m x k
%  S: covarianced matrix of z
%  mu: mean of z
%  Output
%  y: E[Q_1*Q_2*...*Q_k],
%  where Q_i=z'*A_i*z and z~N(mu,S).
%
function y = qproda_slow(A,S,mu)
   k = size(A,3);
   if k==1
      y = trace(A*S)+mu'*A*mu;
      return
   end
   if k==2
      A1 = A(:,:,1);
      A2 = A(:,:,2);
      A1S = A1*S;
      A2S = A2*S; 
      Q1 = trace(A1S)+mu'*A1*mu;
      Q2 = trace(A2S)+mu'*A2*mu;
      y = 2*trace(A1S*A2S)+4*mu'*A1S*A2*mu+Q1*Q2;
      return
   end
   AS = zeros(size(A));
   AS1 = AS;
   for i=1:k
       AS(:,:,i) = A(:,:,i)*S;
       AS1(:,:,i) = A(:,:,i)*mu*mu';
   end
   p = ip_desc(k);
   np = size(p,1);
   ps = perms(uint8(k:-1:1));
   fack = size(ps,1);
   y = 0;
   for i=1:np
       kappa = p(i,:);
       r = sum(kappa>0);
       kappa = kappa(1:r);
       i2 = cumsum(kappa);
       i1 = [1 i2(1:r-1)+1];
       kappas = fliplr(unique(kappa));  % unique elements of kappa
       s = length(kappas);
       f = zeros(1,s);
       for ii=1:s
           f(ii) = sum(kappa==kappas(ii));
       end
       nu = [-1 zeros(1,s-1)];          % \nu tells us the number of theta's
       for j=1:prod(1+f)
           for ii=1:s
               if nu(ii)<f(ii)
                  nu(ii) = nu(ii)+1;
                  break
               else
                  nu(ii) = 0;
               end
           end
           c = 2^(k-sum(kappa==1|kappa==2));
           if any(kappas==2)
              nu2 = nu(find(kappas==2));
              c = c*2^nu2;
           end
% ind tells us out of the r terms in kappa, which one is \theta and
% which one is \tau, where 0 stands for \theta and 1 stands for \tau
           ind = zeros(1,r);           
           nus = 0;
           for ii=1:s
               ind(nus+nu(ii)+1:nus+f(ii)) = 1;
               nus = nus+f(ii);
           end
           for jj=1:fack
               ps1 = ps(jj,:);
%  Check is ps1 is in S_{\kappa,\nu}
               ST = true;
               ii = 0;
               while ST&&ii<r
                  ii = ii+1;
                  ps2 = ps1(i1(ii):i2(ii));
                  if kappa(ii)>1
                     if ind(ii)
                        ST = ps2(1)==min(ps2);
                     else
                        ST = ps2(1)<ps2(end);
                     end
                  end
                  if ST&&ind(ii)&&kappa(ii)>2
                     ST = ps2(2)<ps2(end);
                  end
                  if ST&&ii<r&&ind(ii)==ind(ii+1)&&kappa(ii)==kappa(ii+1)
                     ST = ps2(1)<ps1(i2(ii)+1);
                  end
               end
               if ST
                  y1 = 1;
                  for ii=1:r
                      ps2 = ps1(i1(ii):i2(ii));
                      if ind(ii)
                         A0 = AS(:,:,ps2(end));
                      else
                         A0 = AS1(:,:,ps2(end));
                      end
                      for jj=kappa(ii)-1:-1:1
                          A0 = AS(:,:,ps2(jj))*A0;
                      end
                      y1 = y1*trace(A0);
                  end
                  y = y+c*y1;
               end
           end
       end
   end
