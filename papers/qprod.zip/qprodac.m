function y = qprodac(A,S)
%QPRODAC  Expectation of a product of quadratic forms in central normal variables.
%
%   y = QPRODAC(A,S) returns E[Q_1*Q_2*...*Q_k], where Q_i = z'*A_i*z
%   and z ~ N(0,S).
%   Input
%     A : m x m x k array of symmetric matrices, A(:,:,i) = A_i
%     S : m x m covariance matrix (positive semidefinite, may be singular)
%
%   The value is computed by QPROD_CORE (cumulant recursion).  QPROD_ENUM
%   evaluates the explicit expression (Corollary 1 of the paper) term by
%   term and QPRODASTRC generates it symbolically; QPRODAC_SLOW,
%   QPRODAC_GLM and QPRODAC_KAN are independent algorithms kept for
%   cross-checking.
%
%   See also QPRODA, QPRODSC, QPRODAC_COMP, QPRODW, QPROD_ENUM, QPRODASTRC.

   [A,S] = qprod_check('qprodac',A,S,[],[],1,false);
   y = qprod_core(A,S,[],ones(1,size(A,3)),1,false);
end
