%
%  qprodac_comp.m     Date: 7/29/2023
%  This Matlab function computes the expectation of
%  a product of k Hermitian quadratic forms in central 
%  complex normal random variables with a covariance matrix S.  
%  Input
%  A: Hermitian matrix of m x m x k
%  S: covariance matrix of z
%  Output
%  y: E[Q_1*Q_2*...*Q_k],
%  where Q_i=z'*A_i*z and z~CN(0_m,S).
%  Note: The expression for E[Q_1*Q_2*...*Q_k] is obtained 
%        using the real case, but we need to take the real
%        values of all the terms when k>=3.
%
function y = qprodac_comp(A,S)
%
%  Input validation
%
   [m0,m1,k0] = size(A);
   if m0~=m1
      error('qprodac_comp: A must be an m x m x k array.');
   end
   if ~isequal(size(S),[m0 m0])
      error('qprodac_comp: S must be an m x m matrix.');
   end
   if norm(S-S','fro') > 1e-8*(1+norm(S,'fro'))
      error('qprodac_comp: S must be Hermitian.');
   end
   for i0=1:k0
       if norm(A(:,:,i0)-A(:,:,i0)','fro') > 1e-8*(1+norm(A(:,:,i0),'fro'))
          error('qprodac_comp: A(:,:,%d) must be Hermitian.',i0);
       end
   end

   k = size(A,3);
   for i=1:k
       A(:,:,i) = A(:,:,i)*S;
   end
   if k==1
      y = trace(A);
      return
   end
   if k==2
      A1 = A(:,:,1);
      A2 = A(:,:,2);
      y = trace(A1*A2)+trace(A1)*trace(A2);
      return
   end
   fack = cumprod([1 1:k-1]);
   y = 0;
   nb = ones(1,k,'uint64');    % number of bracelets with different lengths
   for i=3:k
       nb(i) = fack(i)/2;
   end
%
%  Create bracelet index for i=1:k
%   
   brace = cell(1,k);
   for i=1:k
       brace{i} = fixbracef(i);
   end
%
%  The algorithm for creating the next partition of
%  an n-set is based on 
%  Combinatorial Algorithms for Computers and Calculators,
%  2nd edition, Nijenhuis and Wilf, Chapter 11
%  nc is the number of classes
%  p(1:nc) is the number of elements in class 1 to nc
%  q(1:k) tells us the class that each element belongs to
%
%  first entry
%
   p = [k zeros(1,k-1)];
   q = ones(1,k);
   nc = 1;
   v = uint8(1:k);
   if k<=3
      A0 = A(:,:,1);
      for j=2:k
          A0 = A0*A(:,:,j);
      end
      y = trace(A0);
   else   
      for count=1:nb(k)
          ii = nthperm(v,brace{k}(count));
          A0 = A(:,:,ii(1));
          for j=2:k
              A0 = A0*A(:,:,ii(j));
          end
          y = y+trace(A0);
      end       
   end
   y = 2*real(y);
   while nc<k
      m = k;
      l = q(m);
      while p(l)==1
         q(m) = 1;
         m = m-1;
         l = q(m);
      end
      nc = nc+m-k;
      p(1) = p(1)+k-m;
      if l==nc
         nc = nc+1;
         p(nc) = 0;
      end
      q(m) = l+1;
      p(l) = p(l)-1;
      p(l+1) = p(l+1)+1;
      kappa = p(1:nc);
      y1 = 2^(nc-sum(kappa==1|kappa==2));
      for i=1:nc
          pp = find(q==i);
          r = length(pp);
          if r<=3
             A0 = A(:,:,pp(1));
             for j=2:r
                 A0 = A0*A(:,:,pp(j));
             end
             y2 = trace(A0);
          else
             y2 = 0;
             for j=1:nb(r)
                 pp1 = nthperm(pp,brace{r}(j));
                 A0 = A(:,:,pp1(1));
                 for j1=2:r
                     A0 = A0*A(:,:,pp1(j1));
                 end
                 y2 = y2+trace(A0);
             end
          end
          y1 = y1*real(y2);
      end
      y = y+y1;
   end
