function y = qprodac_comp(A,S)
%QPRODAC_COMP  Expectation of a product of Hermitian quadratic forms in central complex normal variables.
%
%   y = QPRODAC_COMP(A,S) returns E[Q_1*Q_2*...*Q_k], where Q_i = z'*A_i*z
%   (z' the conjugate transpose) and z ~ CN(0,S).
%   Input
%     A : m x m x k array of Hermitian matrices, A(:,:,i) = A_i
%     S : m x m Hermitian covariance matrix (positive semidefinite)
%
%   The value is computed by QPROD_CORE (cumulant recursion).  QPROD_ENUM
%   evaluates the explicit expression (Proposition 3 of the paper with mu = 0) term by
%   term and QPRODASTRC_COMP generates it symbolically; QPRODAC_GLM_COMP
%   is an independent algorithm kept for cross-checking.
%
%   See also QPRODAC, QPRODA_COMP, QPRODSC_COMP, QPRODW_COMP, QPROD_ENUM.

   [A,S] = qprod_check('qprodac_comp',A,S,[],[],1,true);
   y = qprod_core(A,S,[],ones(1,size(A,3)),1,true);
end
