%
%  qprodac_glm.m     Date: 8/3/2025
%  This Matlab function computes the expectation of
%  a product of k quadratic forms in central normal 
%  random variables with a covariance matrix S.  It
%  is based on the algorithm from Graczyk, Letac,
%  and Massam (2005, JTP) by setting p=1. 
%  Input
%  A: symmetric matrix of m x m x k
%  S: covariance matrix of z
%  Output
%  y: E[Q_1*Q_2*...*Q_k],
%  where Q_i=z'*A_i*z and z~N(0_m,S).
%
function y = qprodac_glm(A,S)
   k = size(A,3);
   for i=1:k
       A(:,:,i) = A(:,:,i)*S;
   end
   if k==1
      y = trace(A);
      return
   end
   y = 0;
   v = uint8(1:k);
   for i=1:factorial(k)
       p = nthperm(v,i);
       y1 = 1;
       nc = 0;
       for j=1:k
           if p(j)>0
              f = p(j);
              p(j) = 0;
              B = A(:,:,j);
              while f~=j
                 r = f;
                 B = B*A(:,:,r);
                 f = p(f);
                 p(r) = 0;
              end
              nc = nc+1;
              y1 = y1*trace(B);
           end
       end
       y = y+2^(k-nc)*y1;
   end
