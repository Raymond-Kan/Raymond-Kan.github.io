%
%  qprodac_glm_comp.m     Date: 7/29/2023
%  This Matlab function computes the expectation of
%  a product of k Hermitian quadratic forms in central 
%  complex normal random variables with a covariance matrix S.  
%  Input
%  A: Hermitian matrix of m x m x k
%  S: covariance matrix of z
%  Output
%  y: E[Q_1*Q_2*...*Q_k],
%  where Q_i=z'*A_i*z and z~CN(0_m,S).
%  Note: This expression is obtained based on Graczyk, Letac,
%        and Massam (2003 AS), Eq.2.4.
%
function y = qprodac_glm_comp(A,S)
   k = size(A,3);
   for i=1:k
       A(:,:,i) = A(:,:,i)*S;
   end
   if k==1
      y = trace(A);
      return
   end
   y = 0;
   v = uint8(1:k);
   for i=1:factorial(k)
       p = nthperm(v,i);
       y1 = 1;
       for j=1:k
           if p(j)>0
              f = p(j);
              p(j) = 0;
              B = A(:,:,j);
              while f~=j
                 r = f;
                 B = B*A(:,:,r);
                 f = p(f);
                 p(r) = 0;
              end
              y1 = y1*trace(B);
           end
       end
       y = y+y1;
   end
   y = real(y);
   