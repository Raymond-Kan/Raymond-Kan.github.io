%QPRODAC_KAN  E[prod_i (z'*A_i*z)^{s_i}] for z ~ N(0,S) by the method of Kan (2008).
%
%   y = QPRODAC_KAN(A,S,s) computes E[prod_{i=1}^k (z'*A_i*z)^{s_i}] for
%   z ~ N(0,S) by the moments-of-sums method of R. Kan, From moments of
%   sum to moments of product, J. Multivariate Anal. 99 (2008) 542-554;
%   see QPRODA_KAN.  s = [] (or omitted) means ones(1,k).
%
%   See also QPRODA_KAN, QPRODSC, QPROD_CORE, TEST_ALL.
%
function y = qprodac_kan(A,V,si)
p = size(A,3);
if nargin==2
   si = ones(1,p);
end
s = sum(si);
if s==0
   y = 1;
   return
end
if p==1&&s==1
   y = trace(A*V);
   return
end
r = rank(V);
[Q,D] = eig(V);
dd = diag(D);
[~,ii] = sort(dd,1,'descend');
ii = ii(1:r);
dd = dd(ii);
Q = Q(:,ii);
B1 = Q*diag(sqrt(dd));   % B1*B1' = V
if p==1
   A1 = B1'*A*B1;
   d = eig(A1+A1');
   a = zeros(r,1);
   y = 1;
   for j=1:s
       a = d.*(y+a);
       y = sum(a)/(2*j);
   end
   y = factorial(s)*y;
   return
end
%
%   Convert moment of product to moments of sum
%
A1 = zeros(r,r,p);
for i=1:p
    A1(:,:,i) = B1'*A(:,:,i)*B1;
end
A = A1;
% Sorting of si is to reduce the number of updates,
% it is really not necessary.
[si,inu] = sort(si,2,'descend');  
ls = length(si);
p = 2;
x = zeros(1,ls);
d = ones(1,ls);
kk = fliplr(cumprod(fliplr(si+1)));
B = 0.5*si(1)*A(:,:,inu(1));
for i=2:ls
    B = B+0.5*si(i)*A(:,:,inu(i));
end
y = 0;
for i=1:fix(kk(1)/2)
%
%   This part computes E[(z'*B*z)^s]/s!, where B=x_1*A_1+...x_p*A_p
%   where z ~ N(0_n,V).  
%
    d0 = eig((B+B'));   % make it symmetric to avoid numerical errors
    y1 = 1;
    a = zeros(r,1);
    for j=1:s
        a = d0.*(y1+a);
        y1 = sum(a)/(2*j);
    end
    y = y+p*y1;
    j1 = ls;
    while rem(i,kk(j1))==0
       j1 = j1-1;
    end
    x(j1) = x(j1)+d(j1);
    if d(j1)==1
       p = -round(p*(si(j1)+1-x(j1))/x(j1));    
       B = B-A(:,:,inu(j1));
    else
       p = -round(p*(x(j1)+1)/(si(j1)-x(j1)));
       B = B+A(:,:,inu(j1));
    end
    if x(j1)==0||x(j1)==si(j1)
       d(j1) = -d(j1);
    end
end
