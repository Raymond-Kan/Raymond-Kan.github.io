%
%  qprodac_slow.m     Date: 2/1/2024
%  This Matlab function computes the expectation of
%  a product of k quadratic forms in central normal 
%  random variables.  The expression is in the 
%  form of linear combination of various product 
%  of traces, and it is based on the expression from
%  Don (1979).
%  Input
%  A: symmetric matrix of m x m x k
%  S: covariance matrix of z
%  Output
%  y: E[Q_1*Q_2*...*Q_k],
%  where Q_i=z'*A_i*z and z~N(0_m,S).
%
function y = qprodac(A,S)
   k = size(A,3);
   for i=1:k
       A(:,:,i) = A(:,:,i)*S;
   end
   if k==1
      y = trace(A);
      return
   end
   if k==2
      A1 = A(:,:,1);
      A2 = A(:,:,2);
      y = 2*trace(A1*A2)+trace(A1)*trace(A2);
      return
   end
   p = ip_desc(k);
   np = size(p,1);
   ps = perms(uint8(k:-1:1));
   fack = size(ps,1);
   y = 0;
   for i=1:np
       kappa = p(i,:);
       r = sum(kappa>0);
       kappa = kappa(1:r);
       i2 = cumsum(kappa);
       i1 = [1 i2(1:r-1)+1];
       c = 2^(k-sum(kappa==1|kappa==2));
       for j=1:fack
           ps1 = ps(j,:);
%  Check is ps1 is in S_{\kappa}
           ST = true;
           ii = 0;
           while ST&&ii<r
               ii = ii+1;
               ps2 = ps1(i1(ii):i2(ii));
               ST = ps2(1)==min(ps2);
               if ST&&kappa(ii)>2
                  ST = ps2(2)<ps2(end);
               end
               if ST&&ii<r&&kappa(ii)==kappa(ii+1)
                  ST = ps2(1)<ps1(i2(ii)+1);
               end
           end
           if ST
              y1 = 1;   
              for ii=1:r
                  ps2 = ps1(i1(ii):i2(ii));
                  A0 = A(:,:,ps2(1));
                  for jj=2:kappa(ii)
                      A0 = A0*A(:,:,ps2(jj));
                  end
                  y1 = y1*trace(A0);
              end               
              y = y+c*y1;
           end
       end
   end
