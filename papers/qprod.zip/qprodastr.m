%
%  This Matlab function creates an expression for
%  the expectation of a product of k quadratic forms 
%  in normal random variables.  The expression is in the 
%  form of linear combination of various product 
%  of theta and tau terms.
%  Input
%  k: number of quadratic forms in normal random 
%     random variables.
%  Output
%  ys: E[Q_1*Q_2*...*Q_k],
%  where Q_i=z'*A_i*z and z~N(mu,S).
%  Note that the output are in terms of a_nu's and h_nu's
%  where a_{nu} stands for tr(prod_{i \in nu}A_i*S)
%  and h_{nu} stands for mu'*(prod_{i \in nu(1:m-1)}A_i*S)*A_{nu(m)}*mu.
%
function ys = qprodastr(k)
   if k==1
      ys = string(['a_1';'h_1']);
      return
   end
   if k==2
      ys = string(['2*a_1_2';'4*h_1_2';'a_1*a_2';'h_1*a_2';'a_1*h_2';'h_1*h_2']);
      return
   end
   p = ip_desc(k);
   np = size(p,1);
   fack = cumprod([1:k]);
   nb = ones(1,k);    % number of bracelets with different lengths
   nh = ones(1,k);    % number of possible permutations with first element greater than the last element
   for i=3:k
       nh(i) = fack(i)/2;
       nb(i) = nh(i-1);
   end
   nt = nb+nh;
   nk = 0;    % number of unique terms
   for i=1:np
       p1 = p(i,:);
       p1(p1==0) = [];
       c = fack(k)/prod(fack(p1));
       for j=1:k
           f = sum(p1==j);   % frequency of j in the partition
           if f>0
              c = c/fack(f)*nb(j)^f;
           end
       end
       nk = nk+c;
   end
   nk = round(nk);
   ys = strings(nk,1);
%
%  Create bracelet index for i=1:k
%   
   brace = cell(1,k+1);
   for i=1:k+1
       brace{i} = fixbracef(i);
   end
%   
%  The algorithm for creating the next partition of
%  an n-set is based on 
%  Combinatorial Algorithms for Computers and Calculators,
%  2nd edition, Nijenhuis and Wilf, Chapter 11
%  nc is the number of classes
%  p(1:nc) is the number of elements in class 1 to nc
%  q(1:k) tells us the class that each element belongs to
%
%  first entry
%
   p = [k zeros(1,k-1)];
   q = ones(1,k);
   nc = 1;
   nb1 = nb(k);
   nt1 = nt(k);
   c = 2^k;
   v = uint8(1:k);
   for count=1:nb1
       bc = nthperm(v,brace{k}(count));
       ys(count) = [num2str(c) '*a' sprintf('_%0.f',bc)];
   end
   for count=nb1+1:nt1
       bc = nthperm(v,brace{k+1}(count-nb1));
       ys(count) = [num2str(c) '*h' sprintf('_%0.f',bc)];
   end
   pp = zeros(1,k);
   k1 = ones(1,k);
   k2 = zeros(1,k);
   while nc<k
      m = k;
      while p(q(m))==1
         q(m) = 1;
         m = m-1;
      end
      l = q(m);
      nc = nc+m-k;
      p(1) = p(1)+k-m;
      if l==nc
         nc = nc+1;
         p(nc) = 0;
      end
      q(m) = l+1;
      p(l) = p(l)-1;
      p(l+1) = p(l+1)+1;
      kappa = p(1:nc);
      c = 2^(k-sum(kappa==1|kappa==2));
      for i=1:nc
          ind = find(q==i);
          k2(i) = k1(i)+length(ind)-1;
          pp(k1(i):k2(i)) = ind;
          if i<nc
             k1(i+1) = k2(i)+1;
          end
      end
%  Generate all the permutations that one can
%  obtain from pp
      nb1 = nb(kappa);   
      nt1 = nt(kappa);   
      cc = prod(nt1);
      x = [0 ones(1,nc-1)];
      pp1 = pp;
      for ii=1:cc
          for i=1:nc
              kk = k1(i):k2(i);
              r = length(kk);
              if x(i)<nt1(i)
                 x(i) = x(i)+1;
                 pp0 = pp(kk);
                 if x(i)<=nb1(i)
                    pp1(kk) = nthperm(pp0,brace{r}(x(i)));
                 else
                    pp1(kk) = nthperm(pp0,brace{r+1}(x(i)-nb1(i)));
                 end
                 break
              else
                 x(i) = 1;
                 pp1(kk) = pp(kk);
              end
          end
          hind = x>nb1;
          ind = find(kappa==2);
          nu2 = sum(hind(ind));
          c0 = c*2^nu2;
          if c0>1
             y1 = num2str(c0);
          else
             y1 = '';
          end
          for i=1:nc
              kk = k1(i):k2(i);
              if hind(i)
                 y2 = ['h' sprintf('_%0.f',pp1(kk))];
              else 
                 y2 = ['a' sprintf('_%0.f',pp1(kk))];
              end
              if isempty(y1)
                 y1 = y2;
              else
                 y1 = append(y1,'*',y2);
              end
          end
          count = count+1;
          ys(count) = y1;
      end
   end
%   ys = join(ys,'+');   
