function ys = qprodastr_comp(k)
%QPRODASTR_COMP  Explicit expression of E[Q_1*...*Q_k] for z ~ CN(mu,S), as strings.
%
%   ys = qprodastr_comp(k) returns the terms of the explicit expression of
%   E[Q_1*Q_2*...*Q_k], Q_i = z'*A_i*z, z ~ CN(mu,S) (Proposition 3 of the paper),
%   one term per element.  The output is a string array in Matlab and a
%   cell array of character vectors in GNU Octave.  See QPRODSTR_CORE for
%   the notation (a_nu = tau_nu, h_nu = theta_nu) and the ordering of the
%   terms.
%
%   See also QPRODSTR_CORE, QPRODASTR, QPRODASTRC_COMP, QPRODSSTR_COMP, QPRODA_COMP.

   ys = tostr(qprodstr_core(ones(1,k),false,true));
end
