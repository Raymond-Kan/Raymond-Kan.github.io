function ys = qprodastrc(k)
%QPRODASTRC  Explicit expression of E[Q_1*...*Q_k] for z ~ N(0,S), as strings.
%
%   ys = qprodastrc(k) returns the terms of the explicit expression of
%   E[Q_1*Q_2*...*Q_k], Q_i = z'*A_i*z, z ~ N(0,S) (Corollary 1 of the paper),
%   one term per element.  The output is a string array in Matlab and a
%   cell array of character vectors in GNU Octave.  See QPRODSTR_CORE for
%   the notation (a_nu = tau_nu, h_nu = theta_nu) and the ordering of the
%   terms.
%
%   See also QPRODSTR_CORE, QPRODASTR, QPRODASTRC_COMP, QPRODSSTRC, QPRODAC.

   ys = tostr(qprodstr_core(ones(1,k),true,false));
end
