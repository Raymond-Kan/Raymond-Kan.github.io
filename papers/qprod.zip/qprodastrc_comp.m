%
%  qprodstrc_comp.m     Date: 7/19/2025
%  This Matlab function creates an expression for
%  the expectation of a product of k Hermitian forms 
%  in complex normal random variables.  The expression is in the 
%  form of linear combination of various product 
%  of traces.
%  Input
%  k: number of quadratic forms in central complex normal random 
%     random variables.
%  Output
%  ys: E[Q_1*Q_2*...*Q_k],
%  where Q_i=z^H*A_i*z and z~CN(0_m,S).
%  Note that the output are in terms of a_nu',
%  where a_{nu} stands for Re(tr(prod_{i \in nu}A_i*S)).
%
function ys = qprodastrc_comp(k)
   if k==1
      ys = {'a_1'};
      if exist('OCTAVE_VERSION','builtin')==0
         ys = string(ys);   % string array in Matlab; cell array of char in Octave
      end
      return
   end
   if k==2
      ys = cell(2,1);
      ys{1} = 'a_1_2';
      ys{2} = 'a_1*a_2';
      if exist('OCTAVE_VERSION','builtin')==0
         ys = string(ys);   % string array in Matlab; cell array of char in Octave
      end
      return
   end
   p = ip_desc(k);
   np = size(p,1);
   nk = 0;    % number of unique terms
   fack = cumprod([1 1:k]);
   for i=1:np
       p1 = p(i,:);
       p1(p1==0) = [];
       f = zeros(1,k);
       for j=1:length(p1)
           f(p1(j)) = f(p1(j))+1;
       end
       c = 2^(f(1)+f(2))/prod(fack(f+1).*[2*(1:k)].^f);
       nk = nk+c;
   end
   nk = round(fack(end)*nk);
   ys = cell(nk,1);
   nb = ones(1,k,'uint64');    % number of bracelets with different lengths
   for i=3:k
       nb(i) = fack(i)/2;
   end
%
%  Create bracelet index for i=1:k
%   
   brace = cell(1,k);
   for i=1:k
       brace{i} = fixbracef(i);
   end
%   
%  The algorithm for creating the next partition of
%  an n-set is based on 
%  Combinatorial Algorithms for Computers and Calculators,
%  2nd edition, Nijenhuis and Wilf, Chapter 11
%  nc is the number of classes
%  p(1:nc) is the number of elements in class 1 to nc
%  q(1:k) tells us the class that each element belongs to
%
%  first entry
%
   p = [k zeros(1,k-1)];
   q = ones(1,k);
   nc = 1;
   nb1 = nb(k);
   c = 2;
   v = uint8(1:k);
   if k<=3
      count = 1;
      ys{count} = [num2str(c) '*a' sprintf('_%0.f',1:k)];
   else   
      for count=1:nb1
          bc = nthperm(v,brace{k}(count));
          ys{count} = [num2str(c) '*a' sprintf('_%0.f',bc)];
      end       
   end
   pp = zeros(1,k);
   k1 = ones(1,k);
   k2 = zeros(1,k);
   while nc<k
      m = k;
      while p(q(m))==1
         q(m) = 1;
         m = m-1;
      end
      l = q(m);
      nc = nc+m-k;
      p(1) = p(1)+k-m;
      if l==nc
         nc = nc+1;
         p(nc) = 0;
      end
      q(m) = l+1;
      p(l) = p(l)-1;
      p(l+1) = p(l+1)+1;
      kappa = p(1:nc);
      c = 2^(nc-sum(kappa==1|kappa==2));
      for i=1:nc
          ind = find(q==i);
          k2(i) = k1(i)+length(ind)-1;
          pp(k1(i):k2(i)) = ind;
          if i<nc
             k1(i+1) = k2(i)+1;
          end
      end
%  Generate all the permutations that one can
%  obtain from pp
      nb1 = nb(kappa);   
      cc = prod(nb1);
      x = [0 ones(1,nc-1)];
      pp1 = pp;
      for ii=1:cc
          for i=1:nc
              kk = k1(i):k2(i);
              r = length(kk);
              if x(i)<nb1(i)
                 x(i) = x(i)+1;
                 pp0 = pp(kk);
                 pp1(kk) = nthperm(pp0,brace{r}(x(i)));
                 break
              elseif nb1(i)>1
                 x(i) = 1;
                 pp1(kk) = pp(kk);
              end
          end
          count = count+1;
          if c>1
             y1 = num2str(c);
          else
             y1 = '';
          end
          for j=1:nc
              y2 = ['a' sprintf('_%0.f',pp1(k1(j):k2(j)))];
              if isempty(y1)
                 y1 = y2;
              else
                 y1 = [y1,'*',y2];
              end
          end
          ys{count} = y1;
      end
   end
%   ys = join(ys,'+');   
   if exist('OCTAVE_VERSION','builtin')==0
      ys = string(ys);   % string array in Matlab; cell array of char in Octave
   end
