function ys = qprodastrc_comp(k)
%QPRODASTRC_COMP  Explicit expression of E[Q_1*...*Q_k] for z ~ CN(0,S), as strings.
%
%   ys = qprodastrc_comp(k) returns the terms of the explicit expression of
%   E[Q_1*Q_2*...*Q_k], Q_i = z'*A_i*z, z ~ CN(0,S) (Proposition 3 of the paper with mu = 0),
%   one term per element.  The output is a string array in Matlab and a
%   cell array of character vectors in GNU Octave.  See QPRODSTR_CORE for
%   the notation (a_nu = tau_nu, h_nu = theta_nu) and the ordering of the
%   terms.
%
%   See also QPRODSTR_CORE, QPRODASTRC, QPRODASTR_COMP, QPRODSSTRC_COMP, QPRODAC_COMP.

   ys = tostr(qprodstr_core(ones(1,k),true,true));
end
