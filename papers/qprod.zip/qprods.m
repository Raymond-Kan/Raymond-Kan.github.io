%
%  qprods.m     Date: 8/5/2025
%  This Matlab function computes the expectation 
%  of a product of k quadratic forms in normal 
%  random variables with mean mu and a covariance
%  matrix S, raised to different powers  
%  Input
%  A: symmetric matrix of m x m x k
%  S: covariance matrix of z
%  mu: mean of z
%  s: power of A_i, i=1,...,k
%  Output
%  y: E[Q_1^{s1}*Q_2^{s2}*...*Q_k^{sk}],
%  where Q_i=z'*A_i*z and z~N(mu,S).
%
function y = qprods(A,S,mu,s)
%
%  Input validation
%
   [m0,m1,k0] = size(A);
   if m0~=m1
      error('qprods: A must be an m x m x k array.');
   end
   if ~isequal(size(S),[m0 m0])
      error('qprods: S must be an m x m matrix.');
   end
   if norm(S-S','fro') > 1e-8*(1+norm(S,'fro'))
      error('qprods: S must be symmetric.');
   end
   for i0=1:k0
       if norm(A(:,:,i0)-A(:,:,i0)','fro') > 1e-8*(1+norm(A(:,:,i0),'fro'))
          error('qprods: A(:,:,%d) must be symmetric.',i0);
       end
   end
   if numel(mu)~=m0
      error('qprods: mu must be an m x 1 vector.');
   end
   mu = mu(:);
   if numel(s)~=k0
      error('qprods: length of s must equal size(A,3).');
   end
   if any(s<0) || any(s~=round(s))
      error('qprods: s must contain nonnegative integers.');
   end
   s = s(:).';

   if any(s==0)
      sz = find(s==0);
      A(:,:,sz) = [];
      s(sz) = [];
   end
   ss = sum(s);
   if ss==1
      y = trace(A*S)+mu'*A*mu;
      return
   end
   k = length(s);
   [s,ii] = sort(s);
   A = A(:,:,ii);
   A1 = zeros(size(A,[2 3]));
   for i=1:k
       A1(:,i) = A(:,:,i)*mu;
       A(:,:,i) = A(:,:,i)*S;
   end
   fac = cumprod(1:s(k));
   cv = 2^ss*prod(fac(s));
   m1 = s*[k:-1:1]';
   c = zeros(1,m1);
   u = zeros(1,m1);
   v = zeros(1,m1);
   f = zeros(1,ss+1);
%
%  Initial multi-set partition
%
   c(1:k) = 1:k;
   u(1:k) = s;
   v(1:k) = s;
   a = 1;
   l = 1;
   b = k+1;
   f(1) = a;
   f(2) = b;
   y = cv*(tausum(c(1:k),v(1:k))+thetasum(c(1:k),v(1:k)));
   while l<ss
      j = b-1;
      while v(j)==0
         j = j-1;
      end
      if j==a&&v(j)==1
         l = l-1;
         b = a;
         a = f(l);
      else
         v(j) = v(j)-1;
         ind = j+1:b-1;
         v(ind) = u(ind);
         k = b;
         while b<=m1
%  flag indicates whether v has changed
            flag = false;
            for j=a:b-1
                u(k) = u(j)-v(j);
                if u(k)==0
                   flag = true;
                else
                   if flag
                      v(k) = u(k);
                   else
                      v(k) = min(v(j),u(k));
                      flag = u(k)<v(j);
                   end
                   c(k) = c(j);
                   k = k+1;
               end
            end
            if k>b
               a = b;
               b = k;
               l = l+1;
               f(l+1) = b;
            else
               break
            end
         end
         c1 = cv;   
         i = 0;
         while i<=l
            i = i+1;
            if i<=l
               ind = f(i):f(i+1)-1;
               cc = c(ind);
               vv = v(ind);
               ind1 = find(vv>0);
               cc1 = cc(ind1);
               vv1 = vv(ind1);
               l1 = length(cc1);
            end
            if i==1
               cc0 = cc1;
               vv0 = vv1;
               l0 = l1;
               h = 1;   % multiplicity of the block
            elseif i<=l&&l0==l1&&all(cc0==cc1)&&all(vv0==vv1)
               h = h+1;
            else
               c1 = c1*(tausum(cc0,vv0)+thetasum(cc0,vv0))^h/fac(h);
               h = 1;
               cc0 = cc1;
               vv0 = vv1;
               l0 = l1;
            end
         end            
         y = y+c1;
      end
   end

function yy = tausum(c0,v0)
%
%  This Matlab function computes a linear combination of all 
%  unique \tau with the indices indicated by c0, and  
%  multiplicities by v0.
%  
   lv0 = length(v0);
   sv0 = sum(v0);
% when there are two matrices or less, there is only
% one possible trace   
   if lv0==1
      yy = trace(A(:,:,c0)^v0)/(2*v0);
   elseif sv0==2
      yy = 0.5*trace(A(:,:,c0(1))*A(:,:,c0(2)));
   elseif sv0==3
      if lv0==2
         yy = 0.5*trace(A(:,:,c0(1))^v0(1)*A(:,:,c0(2))^v0(2));
      else
         yy = trace(A(:,:,c0(1))*A(:,:,c0(2))*A(:,:,c0(3)));
      end
   elseif all(v0==1)
      ff = fixbracef(lv0);
      yy = 0;
      for i1=1:length(ff)
          ff1 = nthperm(c0,ff(i1));
          AA = A(:,:,ff1(1));
          for j1=2:lv0
              AA = AA*A(:,:,ff1(j1));
          end
          yy = yy+trace(AA);
      end
   else
      [ff,c2] = fixbrace(v0);
      yy = 0;
      for i1=1:size(ff,1)
          ff1 = c0(ff(i1,:));
          AA = A(:,:,ff1(1));
          for j1=2:sv0
              AA = AA*A(:,:,ff1(j1));
          end
          yy = yy+c2(i1)*trace(AA);
      end
   end
end    

function yy = thetasum(c0,v0)
%
%  This Matlab function computes a linear combination of all 
%  unique \theta with the indices indicated by c0, and  
%  multiplicities by v0.
%  
   lv0 = length(v0);
   sv0 = sum(v0);
% when there are two matrices or less, there is only
% one possible theta   
   if lv0==1
      yy = 0.5*mu'*A(:,:,c0)^(v0-1)*A1(:,c0);
   elseif sv0==2
      yy = mu'*A(:,:,c0(1))*A1(:,c0(end));
   elseif all(v0==1)
      ff = fixbracef(lv0+1);
      yy = 0;
      for i1=1:length(ff)
          ff1 = nthperm(c0,ff(i1));
          AA = A1(:,ff1(lv0));
          for j1=lv0-1:-1:1
              AA = A(:,:,ff1(j1))*AA;
          end
          yy = yy+mu'*AA;
      end
   else
      nh = exp(gammaln(sum(v0)+1)-sum(gammaln(v0+1)))/2;
      if sum(rem(v0,2)==1)<=1
         k2 = fix(v0/2);
         nh = nh+exp(gammaln(sum(k2)+1)-sum(gammaln(k2+1)))/2;
      end
      nh = round(nh);
      count = 0;
      p = zeros(1,sv0);
      for k1=1:lv0
          p(count+1:count+v0(k1)) = c0(k1);
          count = count+v0(k1);
      end
      if v0(lv0)==1
         AA = A1(:,c0(lv0));
      else
         AA = A(:,:,c0(lv0))^(v0(lv0)-1)*A1(:,c0(lv0));
      end
      for j1=lv0-1:-1:1
          AA = A(:,:,c0(j1))^v0(j1)*AA;
      end
      yy = mu'*AA;
      if all(p==fliplr(p))
         yy = yy/2;
      end   
      count = 1;
      while count<nh
         p = nmp(p);
         while ~istheta(p)
            p = nmp(p);
         end
         count = count+1;
         AA = A1(:,p(sv0));
         for j1=sv0-1:-1:1
             AA = A(:,:,p(j1))*AA;
         end
         if all(p==fliplr(p))
            yy = yy+mu'*AA/2;
         else
            yy = yy+mu'*AA;
         end
      end
   end
end    

end
