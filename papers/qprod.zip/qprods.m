function y = qprods(A,S,mu,s)
%QPRODS  Expectation of a product of powers of quadratic forms in normal variables.
%
%   y = QPRODS(A,S,mu,s) returns E[Q_1^{s_1}*Q_2^{s_2}*...*Q_k^{s_k}],
%   where Q_i = z'*A_i*z and z ~ N(mu,S).
%   Input
%     A : m x m x k array of symmetric matrices, A(:,:,i) = A_i
%     S : m x m covariance matrix (positive semidefinite, may be singular)
%     mu: m x 1 mean vector
%     s : vector of k nonnegative integer powers
%
%   The value is computed by QPROD_CORE (cumulant recursion, cost
%   O(k m^3 prod(s_i+1))).  QPROD_ENUM evaluates the explicit expression
%   (Proposition 4 of the paper) term by term and QPRODSSTR generates it
%   symbolically.
%
%   See also QPRODSC, QPRODA, QPRODS_COMP, QPRODW, QPROD_ENUM, QPRODSSTR.

   [A,S,L,s] = qprod_check('qprods',A,S,mu,s,1,false);
   y = qprod_core(A,S,L,s,1,false);
end
