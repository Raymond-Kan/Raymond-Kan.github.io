function y = qprods_comp(A,S,mu,s)
%QPRODS_COMP  Expectation of a product of powers of Hermitian quadratic forms in complex normal variables.
%
%   y = QPRODS_COMP(A,S,mu,s) returns E[Q_1^{s_1}*...*Q_k^{s_k}], where
%   Q_i = z'*A_i*z (z' the conjugate transpose) and z ~ CN(mu,S).
%   Input
%     A : m x m x k array of Hermitian matrices, A(:,:,i) = A_i
%     S : m x m Hermitian covariance matrix (positive semidefinite)
%     mu: m x 1 complex mean vector
%     s : vector of k nonnegative integer powers
%
%   The value is computed by QPROD_CORE (cumulant recursion).  QPROD_ENUM
%   evaluates the explicit expression term by term and QPRODSSTR_COMP
%   generates it symbolically.
%
%   See also QPRODS, QPRODSC_COMP, QPRODA_COMP, QPRODW_COMP, QPROD_ENUM.

   [A,S,L,s] = qprod_check('qprods_comp',A,S,mu,s,1,true);
   y = qprod_core(A,S,L,s,1,true);
end
