function y = qprods_sim(A,S,mu,s,nobs)
   if nargin<5
      nobs = 100000;
   end
   Sh = sqrtm(S);
   m = size(A,1);
   k = size(A,3);
   r = rank(S);
   if r==m
      Sh = sqrtm(S);
   else
      [Q,D] = eig(S);
      [~,ii] = sort(-diag(D));
      ii = ii(1:r);
      Sh = Q(:,ii)*sqrt(D(ii,ii));
   end
   Q = zeros(nobs,1);
   for ii=1:nobs
       z = mu+Sh*randn(r,1);
       y1 = 1;
       for j=1:k
           Qj = z'*A(:,:,j)*z;
           y1 = y1*Qj^s(j);
       end
       Q(ii) = y1;
   end
   y = mean(Q);
