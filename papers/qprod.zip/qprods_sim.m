function [y,se] = qprods_sim(A,S,mu,s,nobs,cplx)
%QPRODS_SIM  Monte Carlo estimate of E[prod_i (z'*A_i*z)^{s_i}].
%
%   [y,se] = QPRODS_SIM(A,S,mu,s,nobs) draws nobs (default 100000)
%   independent z ~ N(mu,S) and returns the sample mean y of
%   prod_i (z'*A_i*z)^{s_i} together with its standard error se.
%   mu = [] gives the central case and s = [] means ones(1,k).
%   [y,se] = QPRODS_SIM(A,S,mu,s,nobs,true) draws z ~ CN(mu,S) instead
%   (proper complex normal; A_i Hermitian).
%
%   The simulation is a crude but completely independent check of the
%   exact routines and is used as such by TEST_ALL.  A singular S is
%   handled by drawing from its eigenvectors with positive eigenvalues.
%
%   See also QPRODS, QPRODS_COMP, QPROD_WICK, QPROD_MGF, TEST_ALL.

   if nargin < 4, s = []; end
   if nargin < 5 || isempty(nobs), nobs = 100000; end
   if nargin < 6 || isempty(cplx), cplx = false; end
   [A,S,~,s] = qprod_check('qprods_sim',A,S,mu,s,1,cplx);
   m = size(A,1);
   k = size(A,3);
   if isempty(mu)
      mu = zeros(m,1);
   end
   mu = mu(:);
   [V,D] = eig((S+S')/2);
   d = real(diag(D));
   pos = d > 1e-12*max(d);
   Sh = V(:,pos)*diag(sqrt(d(pos)));          % Sh*Sh' = S
   r = size(Sh,2);
   if cplx
      X = (randn(r,nobs)+1i*randn(r,nobs))/sqrt(2);
   else
      X = randn(r,nobs);
   end
   Z = Sh*X + mu(:,ones(1,nobs));             % m x nobs
   Q = ones(1,nobs);
   for i = 1:k
       if s(i) > 0
          qi = real(sum(conj(Z).*(A(:,:,i)*Z),1));
          Q = Q.*qi.^s(i);
       end
   end
   y = mean(Q);
   se = std(Q)/sqrt(nobs);
end
