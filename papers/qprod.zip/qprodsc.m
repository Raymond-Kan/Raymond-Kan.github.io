function y = qprodsc(A,S,s)
%QPRODSC  Expectation of a product of powers of quadratic forms in central normal variables.
%
%   y = QPRODSC(A,S,s) returns E[Q_1^{s_1}*Q_2^{s_2}*...*Q_k^{s_k}],
%   where Q_i = z'*A_i*z and z ~ N(0,S).
%   Input
%     A : m x m x k array of symmetric matrices, A(:,:,i) = A_i
%     S : m x m covariance matrix (positive semidefinite, may be singular)
%     s : vector of k nonnegative integer powers
%
%   The value is computed by QPROD_CORE (cumulant recursion).  QPROD_ENUM
%   evaluates the explicit expression term by term and QPRODSSTRC
%   generates it symbolically.
%
%   See also QPRODS, QPRODAC, QPRODSC_COMP, QPRODW, QPROD_ENUM, QPRODSSTRC.

   [A,S,~,s] = qprod_check('qprodsc',A,S,[],s,1,false);
   y = qprod_core(A,S,[],s,1,false);
end
