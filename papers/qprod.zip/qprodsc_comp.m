%
%  qprodsc_comp.m     Date: 8/14/2025
%  This Matlab function computes the expectation 
%  of a product of k Hermitian quadratic forms in  
%  complex normal random variables with zero mean 
%  and a covariance matrix S, raised to different powers  
%  Input
%  A: symmetric matrix of m x m x k
%  S: covariance matrix of z
%  s: power of Q_i, i=1,...,k
%  Output
%  y: E[Q_1^{s1}*Q_2^{s2}*...*Q_k^{sk}],
%  where Q_i=z'*A_i*z and z~CN(0,S).
%
function y = qprodsc_comp(A,S,s)
   if any(s==0)
      sz = find(s==0);
      A(:,:,sz) = [];
      s(sz) = [];
   end
   ss = sum(s);
   if ss==1
      y = real(trace(A*S));
      return
   end
   k = length(s);
   [s,ii] = sort(s);
   A = A(:,:,ii);
   for i=1:k
       A(:,:,i) = A(:,:,i)*S;
   end
   fac = cumprod(1:s(k));
   cv = prod(fac(s));
   m1 = s*[k:-1:1]';
   c = zeros(1,m1);
   u = zeros(1,m1);
   v = zeros(1,m1);
   f = zeros(1,ss+1);
%
%  Initial multi-set partition
%
   c(1:k) = 1:k;
   u(1:k) = s;
   v(1:k) = s;
   a = 1;
   l = 1;
   b = k+1;
   f(1) = a;
   f(2) = b;
   y = 2*cv*tausum(c(1:k),v(1:k));
   while l<ss
      j = b-1;
      while v(j)==0
         j = j-1;
      end
      if j==a&&v(j)==1
         l = l-1;
         b = a;
         a = f(l);
      else
         v(j) = v(j)-1;
         ind = j+1:b-1;
         v(ind) = u(ind);
         k = b;
         while b<=m1
%  flag indicates whether v has changed
            flag = false;
            for j=a:b-1
                u(k) = u(j)-v(j);
                if u(k)==0
                   flag = true;
                else
                   if flag
                      v(k) = u(k);
                   else
                      v(k) = min(v(j),u(k));
                      flag = u(k)<v(j);
                   end
                   c(k) = c(j);
                   k = k+1;
               end
            end
            if k>b
               a = b;
               b = k;
               l = l+1;
               f(l+1) = b;
            else
               break
            end
         end
         c1 = cv;   
         i = 0;
         while i<=l
            i = i+1;
            if i<=l
               ind = f(i):f(i+1)-1;
               cc = c(ind);
               vv = v(ind);
               ind1 = find(vv>0);
               cc1 = cc(ind1);
               vv1 = vv(ind1);
               l1 = length(cc1);
            end
            if i==1
               cc0 = cc1;
               vv0 = vv1;
               l0 = l1;
               h = 1;   % multiplicity of the block
            elseif i<=l&&l0==l1&&all(cc0==cc1)&&all(vv0==vv1)
               h = h+1;
            else
               c1 = c1*tausum(cc0,vv0)^h/fac(h);
               h = 1;
               cc0 = cc1;
               vv0 = vv1;
               l0 = l1;
            end
         end            
         y = y+2^l*c1;
      end
   end

function yy = tausum(c0,v0)
%
%  This Matlab function computes a linear combination of all 
%  unique \tau with the indices indicated by c0, and  
%  multiplicities by v0.
%  
   lv0 = length(v0);
   sv0 = sum(v0);
% when there are two matrices or less, there is only
% one possible trace   
   if lv0==1
      yy = real(trace(A(:,:,c0)^v0))/(2*v0);
   elseif sv0==2
      yy = 0.5*real(trace(A(:,:,c0(1))*A(:,:,c0(2))));
   elseif sv0==3
      if lv0==2
         yy = 0.5*real(trace(A(:,:,c0(1))^v0(1)*A(:,:,c0(2))^v0(2)));
      else
         yy = real(trace(A(:,:,c0(1))*A(:,:,c0(2))*A(:,:,c0(3))));
      end
   elseif all(v0==1)
      ff = fixbracef(lv0);
      yy = 0;
      for i1=1:length(ff)
          ff1 = nthperm(c0,ff(i1));
          AA = A(:,:,ff1(1));
          for j1=2:lv0
              AA = AA*A(:,:,ff1(j1));
          end
          yy = yy+real(trace(AA));
      end
   else
      [ff,c2] = fixbrace(v0);
      yy = 0;
      for i1=1:size(ff,1)
          ff1 = c0(ff(i1,:));
          AA = A(:,:,ff1(1));
          for j1=2:sv0
              AA = AA*A(:,:,ff1(j1));
          end
          yy = yy+c2(i1)*real(trace(AA));
      end
   end
end    

end
