function y = qprodsc_comp(A,S,s)
%QPRODSC_COMP  Expectation of a product of powers of Hermitian quadratic forms in central complex normal variables.
%
%   y = QPRODSC_COMP(A,S,s) returns E[Q_1^{s_1}*...*Q_k^{s_k}], where
%   Q_i = z'*A_i*z (z' the conjugate transpose) and z ~ CN(0,S).
%   Input
%     A : m x m x k array of Hermitian matrices, A(:,:,i) = A_i
%     S : m x m Hermitian covariance matrix (positive semidefinite)
%     s : vector of k nonnegative integer powers
%
%   The value is computed by QPROD_CORE (cumulant recursion).  QPROD_ENUM
%   evaluates the explicit expression term by term and QPRODSSTRC_COMP
%   generates it symbolically.
%
%   See also QPRODSC, QPRODS_COMP, QPRODAC_COMP, QPRODW_COMP, QPROD_ENUM.

   [A,S,~,s] = qprod_check('qprodsc_comp',A,S,[],s,1,true);
   y = qprod_core(A,S,[],s,1,true);
end
