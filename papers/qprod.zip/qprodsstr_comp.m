%
%  qprodsstr_comp.m     Date: 8/15/2025
%  This Matlab function creates an expression
%  for E[Q_1^{s1}*...*Q_k^{sk}], where z~CN(mu,S),
%  Q_i = z'*A_i*z, and A_i is a Hermitian matrix.
%  The expression is in the form of linear 
%  combination of various product of theta and 
%  tau terms.
%  Input
%  s: power of Q_i, i=1,...,k
%  Output
%  y: E[Q_1^{s1}*Q_2^{s2}*...*Q_k^{sk}],
%  where Q_i=z'*A_i*z and z~CN(mu,S).
%  Note that the output are in terms of a_nu's and h_nu's
%  where a_{nu} stands for tr(prod_{i \in nu}A_i*S)
%  and h_{nu} stands for mu'*(prod_{i \in nu(1:m-1)}A_i*S)*A_{nu(m)}*mu.
%
function ys = qprodsstr_comp(s)
   ss = sum(s);
   if ss==1
      ys = {'a_1';'h_1'};
      if exist('OCTAVE_VERSION','builtin')==0
         ys = string(ys);   % string array in Matlab; cell array of char in Octave
      end
      return
   end
   k = length(s);
   if ss==2
      if k==1
         ys = cell(5,1);
         ys{1} = 'a_1_1';
         ys{2} = '2*h_1_1';
         ys{3} = 'a_1*a_1';
         ys{4} = '2*h_1*a_1';
         ys{5} = 'h_1*h_1';
      else
         ys = cell(6,1);
         ys{1} = 'a_1_2';
         ys{2} = '2*h_1_2';
         ys{3} = 'a_1*a_2';
         ys{4} = 'h_1*a_2';
         ys{5} = 'a_1*h_2';
         ys{6} = 'h_1*h_2';
      end
      if exist('OCTAVE_VERSION','builtin')==0
         ys = string(ys);   % string array in Matlab; cell array of char in Octave
      end
      return
   end
   fac = cumprod(1:max(s));
   cv = prod(fac(s));
   m1 = fix(ss*(ss+1)/2+1);
   c = zeros(1,m1);
   u = zeros(1,m1);
   v = zeros(1,m1);
   f = zeros(1,ss+1);
%
%  Initial multi-set partition
%
   c(1:k) = 1:k;
   u(1:k) = s;
   v(1:k) = s;
   a = 1;
   l = 1;
   b = k+1;
   f(1) = a;
   f(2) = b;
   count = 0;
   nk = qcounts(s);
   ys = cell(nk,1); 
   vv = zeros(1,ss);
   ii = 0;
   for i=1:k
       vv(ii+1:ii+v(i)) = i;
       ii = ii+v(i);
   end
   [yy,cc] = taulist(vv);
   cc = round(2*cv*cc);
   for ii=1:length(cc)
       count = count+1;
       ys{count} = [num2str(cc(ii)) '*a' sprintf('_%0.f',yy(ii,:))];
   end
   [yy,cc] = thetalist(vv);
   cc = round(2*cv*cc);
   for ii=1:length(cc)
       count = count+1;
       ys{count} = [num2str(cc(ii)) '*h' sprintf('_%0.f',yy(ii,:))];
   end
   while l<ss
      j = b-1;
      while v(j)==0
         j = j-1;
      end
      if j==a&&v(j)==1
         l = l-1;
         b = a;
         a = f(l);
      else
         v(j) = v(j)-1;
         ind = j+1:b-1;
         v(ind) = u(ind);
         k = b;
         while b<=m1
%  flag indicates whether v has changed
            flag = false;
            for j=a:b-1
                u(k) = u(j)-v(j);
                if u(k)==0
                   flag = true;
                else
                   if flag
                      v(k) = u(k);
                   else
                      v(k) = min(v(j),u(k));
                      flag = u(k)<v(j);
                   end
                   c(k) = c(j);
                   k = k+1;
               end
            end
            if k>b
               a = b;
               b = k;
               l = l+1;
               f(l+1) = b;
            else
               break
            end
         end
         c1 = cv;   
         i = 0;
         bcount = 0;
         bs = cell(1,ss);    % string representation of possible theta and tau for each block 
         bc = cell(1,ss);    % coefficient of possible theta and tau for each block
         while i<=l
            i = i+1;
            if i<=l            
               ind = f(i):f(i+1)-1;
               cc = c(ind);
               vv = v(ind);
               ind1 = find(vv>0);
               cc1 = cc(ind1);
               vv1 = vv(ind1);
               l1 = length(cc1);
            end   
            if i==1
               cc0 = cc1;
               vv0 = vv1;
               l0 = l1;
               h = 1;            
            elseif i<=l&&l0==l1&&all(cc0==cc1)&&all(vv0==vv1)
               h = h+1;
            else
               c1 = c1/fac(h);
               bcount = bcount+1;  % number of unique blocks
               vva = zeros(1,sum(vv0));
               jj = 0;
               for ii=1:length(vv0)
                   vva(jj+1:jj+vv0(ii)) = cc0(ii);
                   jj = jj+vv0(ii);
               end
               [ffa,ca] = taulist(vva);
               [ffh,ch] = thetalist(vva);
               ff = [ffa; ffh];
               cc = [ca; ch];
               na = length(ca);
               nh = length(ch);
               nn = na+nh;
               if h==1
                  bs{bcount} = cell(nn,1);
                  bc{bcount} = cc;
                  for ii=1:na
                      bs{bcount}{ii} = ['a' sprintf('_%0.f',ff(ii,:))];
                  end
                  for ii=na+1:nn
                      bs{bcount}{ii} = ['h' sprintf('_%0.f',ff(ii,:))];
                  end
               else
                  nn1 = nchoosek(nn+h-1,h);
                  bs{bcount} = cell(nn1,1);
                  bc{bcount} = zeros(nn1,1);
                  pp = [ones(1,h-1) 0];
                  for ii=1:nn1
                      pp = next_combs(pp);
                      pp2 = unique(pp);
                      c0 = fac(h);
                      for jj=1:length(pp2)
                          c0 = c0/fac(sum(pp==pp2(jj)));
                      end
                      bc{bcount}(ii) = c0*prod(cc(pp));
                      if pp(1)<=na
                         bs{bcount}{ii} = ['a' sprintf('_%0.f',ff(pp(1),:))];
                      else
                         bs{bcount}{ii} = ['h' sprintf('_%0.f',ff(pp(1),:))];
                      end
                      for jj=2:h
                          if pp(jj)<=na
                             bs{bcount}{ii} = [bs{bcount}{ii},'*a',  sprintf('_%0.f',ff(pp(jj),:))];
                          else
                             bs{bcount}{ii} = [bs{bcount}{ii},'*h',  sprintf('_%0.f',ff(pp(jj),:))];
                          end
                      end
                  end
               end
               h = 1;
               cc0 = cc1;
               vv0 = vv1;
               l0 = l1;
            end
         end            
%
%  Create the product of tau and theta terms
%
         xmax = zeros(1,bcount);
         for ii=1:bcount
             xmax(ii) = length(bc{ii});
         end
         x = [0 ones(1,bcount-1)];
         for ii=1:prod(xmax)
             count = count+1;
             for jj=1:bcount
                 if x(jj)==xmax(jj)
                    x(jj) = 1;
                 else
                    x(jj) = x(jj)+1;
                    break
                 end
             end
             c0 = c1*bc{1}(x(1));
             ys1 = bs{1}{x(1)};
             for jj=2:bcount
                 c0 = c0*bc{jj}(x(jj));
                 ys1 = [ys1,'*',bs{jj}{x(jj)}];
             end
             c0 = round(2^l*c0);
             if c0>1
                ys1 = [num2str(c0),'*',ys1];
             end
             ys{count} = ys1;     
         end
      end
   end

   if exist('OCTAVE_VERSION','builtin')==0
      ys = string(ys);   % string array in Matlab; cell array of char in Octave
   end

function p = next_combs(p)
   if p(end)==nn
      cnt = h-1;  
      while p(cnt)==nn
         cnt = cnt-1;  
      end
      p(cnt:h) = p(cnt)+1;  
   else
      p(h) = p(h)+1;   
   end
end

end