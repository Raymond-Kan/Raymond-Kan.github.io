function ys = qprodsstrc_comp(s)
%QPRODSSTRC_COMP  Explicit expression of E[Q_1^{s_1}*...*Q_k^{s_k}] for z ~ CN(0,S), as strings.
%
%   ys = qprodsstrc_comp(s) returns the terms of the explicit expression of
%   E[Q_1^{s_1}*...*Q_k^{s_k}], Q_i = z'*A_i*z, z ~ CN(0,S),
%   one term per element.  The output is a string array in Matlab and a
%   cell array of character vectors in GNU Octave.  See QPRODSTR_CORE for
%   the notation (a_nu = tau_nu, h_nu = theta_nu) and the ordering of the
%   terms.
%
%   See also QPRODSTR_CORE, QPRODSSTRC, QPRODSSTR_COMP, QPRODASTRC_COMP, QPRODSC_COMP.

   ys = tostr(qprodstr_core(s,true,true));
end
