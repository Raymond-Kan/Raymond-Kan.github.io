function ys = qprodstr_core(s,central,cplx)
%QPRODSTR_CORE  Generate the explicit expression of a product moment as strings.
%
%   ys = QPRODSTR_CORE(s,central,cplx) returns the terms of the explicit
%   expression of
%      E[prod_{i=1}^k (z'*A_i*z)^{s_i}]
%   (Proposition 4 of the paper; Proposition 2 when all s_i = 1) as a cell
%   array of character vectors, one term per cell.  central = true gives
%   the expression for z ~ N(0,S) (tau-terms only); cplx = true gives the
%   expression for z ~ CN(mu,S) and Hermitian A_i, in which every theta-
%   and tau-term stands for its real part and the powers of two are
%   reduced accordingly (Proposition 3).
%
%   A term is written as  c*w1*w2*...*wl, where c is the integer
%   coefficient (omitted when it is 1) and each factor w is either
%     a_i1_i2_..._ip   for tau_nu   = tr(A_i1*S*A_i2*S*...*A_ip*S), or
%     h_i1_i2_..._ip   for theta_nu = mu'*A_i1*S*A_i2*S*...*S*A_ip*mu
%   (for a Wishart matrix W ~ W_m(n,S,L): tau_nu = n*tr(...) and
%   theta_nu = tr(A_i1*S*...*S*A_ip*L), Corollaries 2 and 3).  The factors
%   of a term are the blocks of a multiset partition of {1^{s_1},...,k^{s_k}};
%   within a block the canonical index words of Section 8 of the paper
%   are used, so that no two terms of the output are equal.
%
%   The user-level wrappers QPRODASTR, QPRODASTRC, QPRODASTR_COMP,
%   QPRODASTRC_COMP (all s_i = 1) and QPRODSSTR, QPRODSSTRC,
%   QPRODSSTR_COMP, QPRODSSTRC_COMP call this function and convert the
%   result to a string array in Matlab (TOSTR).  The coefficients come
%   from TAULIST and THETALIST (bracelets and canonical theta-words of a
%   block with their multiplicities) and the multiset partitions from
%   MSETPART.
%
%   See also QPRODASTR, QPRODSSTR, QPROD_ENUM, QCOUNTS, TAULIST, THETALIST.

   s = s(:).';
   if any(s < 0) || any(s ~= round(s))
      error('qprod:badInput','qprodstr_core: s must contain nonnegative integers.');
   end
   k0 = numel(s);
   keep = find(s > 0);
   s = s(keep);
   k = numel(s);
   if k == 0
      ys = {'1'};
      return
   end
   ss = sum(s);
   fac = cumprod([1 1:ss]);                  % fac(j+1) = j!
%
%  Overall coefficient: 2^{|s|} prod s_i! (real) or prod s_i! (complex,
%  the factor 2^{l(pi)} is applied per partition); the block coefficients
%  of TAULIST/THETALIST carry the factors 2^{-1} of blocks of length <= 2.
%
   if cplx
      cv = prod(fac(s+1));
   else
      cv = 2^ss*prod(fac(s+1));
   end
   nk = double(qcounts(s,central));
   ys = cell(nk,1);
   count = 0;
   dims = s+1;
   stride = cumprod([1 dims(1:end-1)]);
   bs = cell(prod(dims),1);                  % cache of block strings by content
   bc = cell(prod(dims),1);                  % cache of block coefficients
   P = msetpart(s);
   for t = 1:numel(P)
       B = P{t};
       l = size(B,1);
       if cplx
          c1 = cv*2^l;
       else
          c1 = cv;
       end
       % group equal (adjacent) blocks; for each distinct block form the
       % list of its possible factors (h-fold products when repeated)
       fs = {};
       fc = {};
       i = 1;
       while i <= l
          h = 1;
          while i+h <= l && isequal(B(i+h,:),B(i,:))
             h = h+1;
          end
          c1 = c1/fac(h+1);
          idx = 1 + B(i,:)*stride';
          if isempty(bs{idx})
             [bs{idx},bc{idx}] = blockterms(B(i,:));
          end
          [fs{end+1},fc{end+1}] = powerterms(bs{idx},bc{idx},h); %#ok<AGROW>
          i = i+h;
       end
       % all products of one factor per distinct block; the first block
       % varies fastest
       nb = numel(fs);
       xmax = cellfun(@numel,fc);
       x = [0 ones(1,nb-1)];
       for ii = 1:prod(xmax)
           for jj = 1:nb
               if x(jj) == xmax(jj)
                  x(jj) = 1;
               else
                  x(jj) = x(jj)+1;
                  break
               end
           end
           c0 = c1;
           str = '';
           for jj = 1:nb
               c0 = c0*fc{jj}(x(jj));
               if jj == 1
                  str = fs{jj}{x(jj)};
               else
                  str = [str '*' fs{jj}{x(jj)}]; %#ok<AGROW>
               end
           end
           c0 = round(c0);
           if c0 ~= 1
              str = [num2str(c0) '*' str]; %#ok<AGROW>
           end
           count = count+1;
           ys{count} = str;
       end
   end
   ys = ys(1:count);

   function [bstr,bcoef] = blockterms(b)
   %  canonical tau- and theta-words of the block with content b, as
   %  strings, with their coefficients
      vv = zeros(1,sum(b));
      pos = 0;
      for i1 = 1:k
          vv(pos+1:pos+b(i1)) = keep(i1);    % original matrix labels
          pos = pos+b(i1);
      end
      [wa,ca] = taulist(vv);
      if central
         wh = zeros(0,numel(vv)); ch = zeros(0,1);
      else
         [wh,ch] = thetalist(vv);
      end
      na = numel(ca);
      nh = numel(ch);
      bstr = cell(na+nh,1);
      for i1 = 1:na
          bstr{i1} = ['a' sprintf('_%d',wa(i1,:))];
      end
      for i1 = 1:nh
          bstr{na+i1} = ['h' sprintf('_%d',wh(i1,:))];
      end
      bcoef = [ca(:); ch(:)];
   end
end

function [fs,fc] = powerterms(bstr,bcoef,h)
%  the distinct h-fold products of the factors in bstr (multisets of
%  size h), with coefficient h!/prod(multiplicities!) * prod(bcoef)
   nn = numel(bstr);
   if h == 1
      fs = bstr;
      fc = bcoef;
      return
   end
   nn1 = round(exp(gammaln(nn+h)-gammaln(h+1)-gammaln(nn)));
   fs = cell(nn1,1);
   fc = zeros(nn1,1);
   fach = prod(1:h);
   pp = [ones(1,h-1) 0];
   for ii = 1:nn1
       % next multiset (nondecreasing h-tuple) in lexicographic order
       if pp(end) == nn
          cnt = h-1;
          while pp(cnt) == nn
             cnt = cnt-1;
          end
          pp(cnt:h) = pp(cnt)+1;
       else
          pp(h) = pp(h)+1;
       end
       c0 = fach;
       for u = unique(pp)
           c0 = c0/prod(1:sum(pp == u));
       end
       fc(ii) = c0*prod(bcoef(pp));
       str = bstr{pp(1)};
       for jj = 2:h
           str = [str '*' bstr{pp(jj)}]; %#ok<AGROW>
       end
       fs{ii} = str;
   end
end
