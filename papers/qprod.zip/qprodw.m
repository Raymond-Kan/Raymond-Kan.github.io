function y = qprodw(A,S,n,L,s)
%QPRODW  Product moments of a (noncentral) real Wishart matrix.
%
%   y = QPRODW(A,S,n,L,s) returns E[prod_{i=1}^k tr(W*A_i)^{s_i}], where
%   W ~ W_m(n,S,L) is a real Wishart matrix with n degrees of freedom,
%   covariance matrix S and noncentrality matrix L: W = sum_{t=1}^n z_t*z_t'
%   with independent z_t ~ N(mu_t,S) and L = sum_t mu_t*mu_t'.  (The
%   conventional noncentrality parameter is inv(S)*L; L is used so that
%   singular S is allowed.)
%   Input
%     A : m x m x k array of symmetric matrices, A(:,:,i) = A_i
%     S : m x m covariance matrix (positive semidefinite, may be singular)
%     n : degrees of freedom (any nonnegative real number)
%     L : m x m noncentrality matrix; L = [] or zeros(m) for the central
%         Wishart distribution
%     s : vector of k nonnegative integer powers; s = [] means ones(1,k)
%
%   Since tr(W*A) = z'*A*z when n = 1 and L = mu*mu', QPRODW(A,S,1,mu*mu',s)
%   equals QPRODS(A,S,mu,s).  The value is computed by QPROD_CORE
%   (cumulant recursion); QPROD_ENUM evaluates the explicit expression of
%   Corollary 2 of the paper term by term.
%
%   See also QPRODW_COMP, QPRODA, QPRODS, QPROD_ENUM.

   if nargin < 5
      s = [];
   end
   [A,S,L,s,n] = qprod_check('qprodw',A,S,L,s,n,false);
   y = qprod_core(A,S,L,s,n,false);
end
