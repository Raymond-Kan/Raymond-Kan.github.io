function y = qprodw_comp(A,S,n,L,s)
%QPRODW_COMP  Product moments of a (noncentral) complex Wishart matrix.
%
%   y = QPRODW_COMP(A,S,n,L,s) returns E[prod_{i=1}^k tr(W*A_i)^{s_i}],
%   where W ~ CW_m(n,S,L) is a complex Wishart matrix with n degrees of
%   freedom, Hermitian covariance matrix S and noncentrality matrix L:
%   W = sum_{t=1}^n z_t*z_t' (z' the conjugate transpose) with independent
%   proper complex normal z_t ~ CN(mu_t,S) and L = sum_t mu_t*mu_t'.
%   Input
%     A : m x m x k array of Hermitian matrices, A(:,:,i) = A_i
%     S : m x m Hermitian covariance matrix (positive semidefinite)
%     n : degrees of freedom (any nonnegative real number)
%     L : m x m Hermitian noncentrality matrix; L = [] or zeros(m) for the
%         central complex Wishart distribution
%     s : vector of k nonnegative integer powers; s = [] means ones(1,k)
%
%   QPRODW_COMP(A,S,1,mu*mu',s) equals QPRODS_COMP(A,S,mu,s).  The value is
%   computed by QPROD_CORE (cumulant recursion); QPROD_ENUM evaluates the
%   explicit expression of Corollary 3 of the paper term by term.
%
%   See also QPRODW, QPRODA_COMP, QPRODS_COMP, QPROD_ENUM.

   if nargin < 5
      s = [];
   end
   [A,S,L,s,n] = qprod_check('qprodw_comp',A,S,L,s,n,true);
   y = qprod_core(A,S,L,s,n,true);
end
