These are programs for the paper "An explicit expression for the
expectation of a product of quadratic forms in multivariate normal random
variables" by Raymond Kan and Jiening Pan.  If you have questions,
comments, or bug reports, please send them to
Raymond.Kan@rotman.utoronto.ca

Raymond Kan
Rotman School of Management
University of Toronto

Version 1.0: 8/15/2025, initial release
Version 1.1: 9/2/2025, qprods.m, qprodsc.m, qprods_comp.m, and qprodsc_comp.m
             were updated to reduce the number of computations for the
             coefficients
Version 1.2: 9/8/2025, added example5.m
Version 1.3: 7/24/2026, maintenance and portability release
             - corrected the function name declared inside qprodac_slow.m
             - fixed a typo in thetalist.m that prevented the file from
               being parsed by GNU Octave, and a missing semicolon in
               qprodsstrc.m
             - the expression-generating functions now also run under
               GNU Octave (string array in Matlab, cell array of
               character vectors in Octave)
             - added input validation, test_all.m and the user manual
Version 1.4: 10/4/2026
             - New evaluation engine (qprod_core.m).  The numerical
               routines qproda, qprodac, qprods, qprodsc and their _comp
               versions keep their names and arguments but now evaluate
               the product moment through the cumulant generating
               function: the sums over all orderings of a block of
               matrices satisfy a subset recursion, and the moments follow
               from the multivariate moment-cumulant recursion.  The cost
               is O(k m^3 2^k + 3^k) for k distinct matrices instead of
               factorial; k = 8 takes 0.05 seconds instead of 5, and
               k = 14 is feasible.
             - New functions qprodw.m and qprodw_comp.m for the product
               moments E[prod_i tr(W*A_i)^{s_i}] of real and complex
               (noncentral) Wishart matrices with arbitrary degrees of
               freedom n and noncentrality matrix L (Corollaries 2 and 3
               of the paper).
             - The explicit expression of the paper is still available,
               evaluated term by term, in the new reference implementation
               qprod_enum.m, which follows Proposition 4 and Lemma 9
               literally; it replaces the eight enumerative evaluators of
               version 1.3 and serves to check qprod_core.
             - New independent checks: qprod_wick.m (Isserlis-Wick
               expansion), qprod_mgf.m (symbolic differentiation of the
               moment generating function; requires the Symbolic Math
               Toolbox or the Octave symbolic package), a rewritten
               qprods_sim.m (Monte Carlo, with standard error) and the
               moments-of-sums routines qproda_kan.m and qprodac_kan.m
               (Kan, 2008), which are now documented.  test_all.m runs
               all of them (about 230 checks).
             - The eight expression-generating functions share one engine
               (qprodstr_core.m); the ten copies of Knuth's multiset
               partition algorithm are replaced by msetpart.m, and the
               count of canonical theta-words by ntheta.m.  The set of
               terms generated is unchanged; for qprodastr* with k >= 4
               the order of the terms differs from version 1.3.
             - qcounts.m and qcountsc.m are rewritten on top of
               msetpart.m; the counting functions now report an error
               instead of wrapping around when a count exceeds 2^64.
             - Removed divisor.m, factor2.m, totient.m and gcdv.m (their
               work is done by the built-in functions factor and gcd).
             - Added Contents.m ("help qprod" lists the functions),
               example6.m (Wishart moments and the independent checks),
               seeds in the example scripts, and error identifiers
               (qprod:badInput, qprod:overflow, qprod:noSymbolic).

Requirements: Matlab R2019a or later, or GNU Octave 7 or later.
              qprod_mgf.m additionally needs the Symbolic Math Toolbox
              (Matlab) or the symbolic package (Octave); test_all.m skips
              the corresponding checks when neither is available.
              nthperm.mexw64 is an optional compiled helper for 64-bit
              Windows Matlab (source in nthperm.cpp, compile with
              "mex nthperm.cpp"); the plain nthperm.m is used otherwise.

License note: nthperm.m/nthperm.cpp/nthperm.mexw64 are by Peter H. Li
              (Matlab Central File Exchange, FreeBSD license) and are
              redistributed under that license.  All other files are by
              the authors.

Notation: Q_i = z'*A_i*z (z' is the conjugate transpose in the complex
case); S is the covariance matrix of z and mu its mean.  For a Wishart
matrix, W ~ W_m(n,S,L) means W = sum_{t=1}^n z_t*z_t' with independent
z_t ~ N(mu_t,S) and L = sum_t mu_t*mu_t' (L = [] for the central case).
In the generated expressions, a_nu stands for tau_nu = tr(A_nu1*S*...*A_nup*S)
and h_nu for theta_nu = mu'*A_nu1*S*...*S*A_nup*mu (for a Wishart matrix:
tau_nu = n*tr(...) and theta_nu = tr(A_nu1*S*...*S*A_nup*L)); for the
complex case every a_nu and h_nu stands for the real part.

Main programs (numerical evaluation):
qproda.m:       E[Q_1*...*Q_k], z~N(mu,S)
qprodac.m:      E[Q_1*...*Q_k], z~N(0,S)
qprods.m:       E[Q_1^{s_1}*...*Q_k^{s_k}], z~N(mu,S)
qprodsc.m:      E[Q_1^{s_1}*...*Q_k^{s_k}], z~N(0,S)
qproda_comp.m:  E[Q_1*...*Q_k], z~CN(mu,S), A_i Hermitian
qprodac_comp.m: E[Q_1*...*Q_k], z~CN(0,S)
qprods_comp.m:  E[Q_1^{s_1}*...*Q_k^{s_k}], z~CN(mu,S)
qprodsc_comp.m: E[Q_1^{s_1}*...*Q_k^{s_k}], z~CN(0,S)
qprodw.m:       E[prod_i tr(W*A_i)^{s_i}], W~W_m(n,S,L) (real Wishart)
qprodw_comp.m:  E[prod_i tr(W*A_i)^{s_i}], W~CW_m(n,S,L) (complex Wishart)
qprod_core.m:   the evaluation engine called by all of the above
qprod_check.m:  input validation shared by all of the above

The explicit expression of the paper, evaluated term by term (slow; for
verification):
qprod_enum.m:   Propositions 2-4 and Corollaries 1-3, with Lemma 9
                multiplicities; real/complex, central/noncentral, Wishart
qproda_slow.m:  Proposition 1 (admissible permutations), z~N(mu,S)
qprodac_slow.m: Proposition 1, z~N(0,S)

Independent checks of the formulas (used by test_all.m):
qprod_wick.m:   Isserlis-Wick expansion of the Gaussian expectation
qprod_mgf.m:    symbolic differentiation of the moment generating function
qprods_sim.m:   Monte Carlo estimate with standard error
qproda_lm.m, qproda_lm_comp.m:     Letac and Massam (2008, JMVA)
qprodac_glm.m, qprodac_glm_comp.m: Graczyk, Letac and Massam (2005, JTP;
                                   2003, AS)
qproda_kan.m, qprodac_kan.m:       Kan (2008, JMVA), moments of sums

Expression-generating programs (one string per distinct term):
qprodastr.m, qprodastrc.m, qprodastr_comp.m, qprodastrc_comp.m:
                E[Q_1*...*Q_k] for z~N(mu,S), N(0,S), CN(mu,S), CN(0,S)
qprodsstr.m, qprodsstrc.m, qprodsstr_comp.m, qprodsstrc_comp.m:
                E[Q_1^{s_1}*...*Q_k^{s_k}] for the same four cases
qprodstr_core.m: the engine called by the eight functions above
qmom.m, qmom_rec.m:   coefficients (and strings) of E[(z'*A*z)^k], z~N(mu,S)
qmomc.m, qmomc_rec.m: coefficients of E[(z'*A*z)^k], z~N(0,S)

Counting programs:
qcount.m:       number of distinct terms in E[Q_1*...*Q_k], z~N(mu,S)
qcountc.m:      number of distinct terms in E[Q_1*...*Q_k], z~N(0,S)
qcountc_rec.m:  same as qcountc.m, by the recurrence of Section 4
qcounts.m:      number of distinct terms in E[Q_1^{s_1}*...*Q_k^{s_k}], z~N(mu,S)
qcountsc.m:     number of distinct terms in E[Q_1^{s_1}*...*Q_k^{s_k}], z~N(0,S)

Examples:
example1.m: E[Q_1*...*Q_k] for z~N(mu,S) and z~N(0,S) by all available
            algorithms, with timings, and qproda for k up to 14
example2.m: the complex case, z~CN(mu,S) and z~CN(0,S)
example3.m: repeated quadratic forms, qprods/qprodsc vs qproda/qprodac
            with repeated slices, qprod_enum and qproda_kan
example4.m: repeated quadratic forms, complex case
example5.m: the expressions for E[tr(W*A1)*tr(W*A2)*tr(W*A3)] (real
            Wishart) and E[tr(W*A1)*tr(W*A2)^2] (complex Wishart), the
            latter correcting Example 3 of Di Nardo (2014)
example6.m: Wishart product moments with qprodw/qprodw_comp, and the
            independent checks qprod_wick, qprods_sim and qprod_mgf
test_all.m: runs all checks; test_all(true) skips the slow ones
The output of each example is in the corresponding .out file.

Auxiliary programs:
msetpart.m:  partitions of a multiset (Knuth, Algorithm M)
setpart.m:   set partitions of {1,...,n} (Nijenhuis and Wilf)
ip_desc.m:   integer partitions in reverse lexicographic order
bell.m:      Bell numbers
necklace.m:  number of necklaces with fixed content
bracelet.m:  number of bracelets with fixed content (Lemma 8)
ntheta.m:    number of canonical theta-words with fixed content (Lemma 7)
fixbrace.m:  enumeration of bracelets with fixed content (Karim et al., 2013)
fixbracef.m: enumeration of bracelets of (1,...,k), as factoradic indices
taulist.m:   canonical tau-words of a block with their coefficients
thetalist.m: canonical theta-words of a block with their coefficients
nthperm.m:   n-th lexicographic permutation (Peter H. Li)
nmp.m:       next multiset permutation
istheta.m:   tests whether a word is a canonical theta-word
tostr.m:     cell array of char -> string array (Matlab) / unchanged (Octave)
Contents.m:  list of the functions ("help qprod" when the folder is named qprod)
