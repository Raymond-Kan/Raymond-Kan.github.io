%   
%  This function creaetes the set partitions of
%  {1,...,n}
%  Reference: 
%  Combinatorial Algorithms for Computers and Calculators,
%  2nd edition, Nijenhuis and Wilf, Chapter 11
%  nc is the number of classes
%  p(1:nc) is the number of elements in class 1 to nc
%  q(1:n) tells us the class that each element belongs to
%
function y = setpart(n)
   bn = bell(n);
   y = zeros(bn,n);
   p = [n zeros(1,n-1)];
   q = ones(1,n);
   count = 1;
   y(count,:) = q;
   nc = 1;
   while nc<n
      m = n;
      while p(q(m))==1
         q(m) = 1;
         m = m-1;
      end
      l = q(m);
      nc = nc+m-n;
      p(1) = p(1)+n-m;
      if l==nc
         nc = nc+1;
         p(nc) = 0;
      end
      q(m) = l+1;
      p(l) = p(l)-1;
      p(l+1) = p(l+1)+1;
      count = count+1;
      y(count,:) = q;
   end
