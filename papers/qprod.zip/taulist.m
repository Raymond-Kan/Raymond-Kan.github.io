%
%   This Matlab function creates the list of 
%   permutations of a vector of integers vv
%   that lead to unique tau.  The coefficient
%   associated with the unique tau is also given.
%
function [y,c] = taulist(vv)
   vv = sort(vv);
   k = length(vv);
   vu = unique(vv);
   r = length(vu);
   if r==1
      y = vv;
      c = 1/(2*k);
      return
   end
   if k==2    % vv(1)~=vv(2)
      y = vv;
      c = 0.5;
      return
   end
   if k==3
      y = vv;
      if r==2
         c = 0.5;
      else
         c = 1;
      end
      return
   end
   if r==k
      f = fixbracef(k);
      nh = size(f,1);
      y = zeros(nh,k);
      c = ones(nh,1);
      for i=1:nh
          y(i,:) = nthperm(vv,f(i));
      end
      return
   end
   v = zeros(1,r);
   for i=1:r
       v(i) = sum(vv==vu(i));
   end
   [y,c] = fixbrace(v);
   y = vu(y);
 