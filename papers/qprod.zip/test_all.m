% Comprehensive test of the fixed qprod package (run under Octave or Matlab)
function test_all
   randn('seed',123); rand('seed',123);
   npass = 0; nfail = 0;

   function check(name, ok)
      if ok, npass = npass+1; fprintf('PASS %s\n', name);
      else   nfail = nfail+1; fprintf('FAIL %s\n', name);
      end
   end

   % ---------- random test problems ----------
   m = 4;
   kmax = 5;
   A = zeros(m,m,kmax);
   for i=1:kmax
       x = randn(15,m); A(:,:,i) = (x'*x)/15;
   end
   mu = randn(m,1);
   x = randn(m-1,m); S = (x'*x)/m;      % singular psd
   Ac = zeros(m,m,kmax)+0i;
   for i=1:kmax
       x = randn(15,m)+1i*randn(15,m); Ac(:,:,i) = (x'*x)/15;
   end
   muc = randn(m,1)+1i*randn(m,1);
   x = randn(15,m)+1i*randn(15,m); Sc = (x'*x)/15;

   % ---------- string-term evaluator ----------
   function v = evalterms(ys, AA, SS, mm, cplx)
      % ys: string array (Matlab) or cellstr (Octave); evaluate sum of terms
      if ~iscell(ys), ys = cellstr(ys); end
      v = 0;
      for t=1:numel(ys)
          tok = strsplit(ys{t}, '*');
          val = 1;
          for jj=1:numel(tok)
              tk = tok{jj};
              if ~isempty(regexp(tk, '^\d+$', 'once'))
                 val = val*str2double(tk);
              else
                 % optional exponent
                 pw = 1;
                 caret = strfind(tk, '^');
                 if ~isempty(caret)
                    pw = str2double(tk(caret+1:end));
                    tk = tk(1:caret-1);
                 end
                 typ = tk(1);
                 idx = sscanf(strrep(tk(3:end), '_', ' '), '%d')';
                 if typ=='a'
                    P = eye(size(SS,1));
                    for q=idx, P = P*AA(:,:,q)*SS; end
                    x0 = trace(P);
                 else
                    P = AA(:,:,idx(1));
                    for q=idx(2:end), P = P*SS*AA(:,:,q); end
                    x0 = mm'*P*mm;
                 end
                 if cplx, x0 = real(x0); end
                 val = val*x0^pw;
              end
          end
          v = v+val;
      end
   end

   function v = evaltilde(ys, A1, SS, mm)
      % for qmom output: a_i = tr((A*S)^i), h_i = mu'(A*S)^{i-1}A mu
      if ~iscell(ys), ys = cellstr(ys); end
      v = 0;
      AS = A1*SS;
      for t=1:numel(ys)
          tok = strsplit(ys{t}, '+');   % qmom joins terms with +
          for u=1:numel(tok)
              ftok = strsplit(tok{u}, '*');
              val = 1;
              for jj=1:numel(ftok)
                  tk = ftok{jj};
                  if ~isempty(regexp(tk, '^\d+$', 'once'))
                     val = val*str2double(tk);
                  else
                     pw = 1;
                     caret = strfind(tk, '^');
                     if ~isempty(caret)
                        pw = str2double(tk(caret+1:end));
                        tk = tk(1:caret-1);
                     end
                     ii2 = str2double(tk(3:end));
                     if tk(1)=='a', x0 = trace(AS^ii2);
                     else           x0 = mm'*AS^(ii2-1)*A1*mm;
                     end
                     val = val*x0^pw;
                  end
              end
              v = v+val;
          end
      end
   end

   reltol = @(a,b) abs(a-b) <= 1e-9*max(1,abs(b));

   % ---------- 1. string functions vs numeric evaluators (real) ----------
   for k=1:kmax
       Ak = A(:,:,1:k);
       v1 = evalterms(qprodastr(k),  Ak, S, mu, false);
       v2 = qproda(Ak, S, mu);
       check(sprintf('qprodastr(%d) == qproda', k), reltol(v1,v2));
       v1 = evalterms(qprodastrc(k), Ak, S, mu, false);
       v2 = qprodac(Ak, S);
       check(sprintf('qprodastrc(%d) == qprodac', k), reltol(v1,v2));
   end

   % ---------- 2. string functions vs numeric evaluators (complex) ----------
   for k=1:4
       Ak = Ac(:,:,1:k);
       v1 = evalterms(qprodastr_comp(k),  Ak, Sc, muc, true);
       v2 = qproda_comp(Ak, Sc, muc);
       check(sprintf('qprodastr_comp(%d) == qproda_comp', k), reltol(v1,v2));
       v1 = evalterms(qprodastrc_comp(k), Ak, Sc, muc, true);
       v2 = qprodac_comp(Ak, Sc);
       check(sprintf('qprodastrc_comp(%d) == qprodac_comp', k), reltol(v1,v2));
   end

   % ---------- 3. repeated-power string functions ----------
   slist = {[3], [1 3], [2 2], [2 1 2], [1 1 1]};
   for c=1:numel(slist)
       s = slist{c}; ks = length(s);
       Ak = A(:,:,1:ks);
       v1 = evalterms(qprodsstr(s),  Ak, S, mu, false);
       v2 = qprods(Ak, S, mu, s);
       check(sprintf('qprodsstr([%s]) == qprods', num2str(s)), reltol(v1,v2));
       v1 = evalterms(qprodsstrc(s), Ak, S, mu, false);
       v2 = qprodsc(Ak, S, s);
       check(sprintf('qprodsstrc([%s]) == qprodsc', num2str(s)), reltol(v1,v2));
       Akc = Ac(:,:,1:ks);
       v1 = evalterms(qprodsstr_comp(s),  Akc, Sc, muc, true);
       v2 = qprods_comp(Akc, Sc, muc, s);
       check(sprintf('qprodsstr_comp([%s]) == qprods_comp', num2str(s)), reltol(v1,v2));
       v1 = evalterms(qprodsstrc_comp(s), Akc, Sc, muc, true);
       v2 = qprodsc_comp(Akc, Sc, s);
       check(sprintf('qprodsstrc_comp([%s]) == qprodsc_comp', num2str(s)), reltol(v1,v2));
   end

   % ---------- 4. qmom string output ----------
   A1 = A(:,:,1);
   for k=1:6
       [~,ystr] = qmom(k);
       v1 = evaltilde(ystr, A1, S, mu);
       v2 = qprods(A1, S, mu, k);
       check(sprintf('qmom(%d) strings == qprods', k), reltol(v1,v2));
       [~,ystr] = qmom_rec(k);
       v1 = evaltilde(ystr, A1, S, mu);
       check(sprintf('qmom_rec(%d) strings == qprods', k), reltol(v1,v2));
   end

   % ---------- 5. numeric cross-checks (fixed function names) ----------
   k = 5; Ak = A(:,:,1:k);
   v = [qprodac(Ak,S) qprodac_slow(Ak,S) qprodac_glm(Ak,S)];
   check('qprodac == qprodac_slow == qprodac_glm', ...
         all(abs(v-v(1)) <= 1e-9*abs(v(1))));
   v = [qproda(Ak,S,mu) qproda_slow(Ak,S,mu) qproda_lm(Ak,S,mu)];
   check('qproda == qproda_slow == qproda_lm', ...
         all(abs(v-v(1)) <= 1e-9*abs(v(1))));

   % ---------- 6. edge cases ----------
   check('qproda k=1', reltol(qproda(A(:,:,1),S,mu), trace(A(:,:,1)*S)+mu'*A(:,:,1)*mu));
   check('qprods scalar s', reltol(qprods(A(:,:,1),S,mu,4), ...
         qproda(repmat(A(:,:,1),[1 1 4]),S,mu)));
   check('qprods with zero in s', reltol(qprods(A(:,:,1:3),S,mu,[2 0 1]), ...
         qprods(A(:,:,[1 3]),S,mu,[2 1])));
   check('qproda row mu accepted', reltol(qproda(A(:,:,1:2),S,mu'), ...
         qproda(A(:,:,1:2),S,mu)));
   % counting functions
   check('qcount(7)',   qcount(7)==49824);
   check('qcountc(10)', qcountc(10)==1436714);
   check('qcounts([2 2])', qcounts([2 2])==54);
   check('qcountsc([5 5])', qcountsc([5 5])==554);
   % validation errors
   ok = false;
   try, qproda(A(:,:,1:2), S(1:3,1:3), mu); catch, ok = true; end
   check('qproda rejects wrong-size S', ok);
   ok = false;
   B = A(:,:,1); B(1,2) = B(1,2)+1;   % asymmetric
   try, qproda(B, S, mu); catch, ok = true; end
   check('qproda rejects asymmetric A', ok);
   ok = false;
   try, qprods(A(:,:,1:2), S, mu, [1 -1]); catch, ok = true; end
   check('qprods rejects negative s', ok);

   fprintf('\n===== %d passed, %d failed =====\n', npass, nfail);
end
