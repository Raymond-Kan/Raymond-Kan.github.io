%THETALIST  Canonical theta-words of a block and their coefficients.
%
%   [y,c] = THETALIST(vv) returns, for the index word content given by
%   the (sorted) label vector vv, the canonical theta-words (one per row
%   of y: the arrangements of vv that do not exceed their reversal
%   lexicographically, Section 8 of the paper) and their coefficients c.
%   The coefficient is the multiplicity c_j of Lemma 9 divided by
%   prod_l b_l! (the factor cancelled in Remark 4), with the convention
%   that a block of length 1 carries an extra factor 1/2 (and a block of
%   length 2 the factor 2 of eq. (48)), so that 2^{|s|} times the block
%   sums reproduces the coefficient 2^{|s|-f_1-f_2} of the paper.  These
%   are the conventions used by QPRODSTR_CORE.
%
%   See also TAULIST, NTHETA, NMP, ISTHETA, QPRODSTR_CORE.
%
function [y,c] = thetalist(vv)
   vv = sort(vv);
   k = length(vv);
   vu = unique(vv);
   r = length(vu);
   if r==1
      y = vv;
      c = 0.5;
      return
   end
   if k==2  % This is for the case that vv(1)~=vv(2)
      y = vv;
      c = 1;
      return
   end
   if r==k
      f = fixbracef(k+1);
      nh = size(f,1);
      y = zeros(nh,k);
      c = ones(nh,1);
      for i=1:nh
          y(i,:) = nthperm(vv,f(i));
      end
      return
   end
   v = zeros(1,r);
   for i=1:r
       v(i) = sum(vv==vu(i));
   end
   nh = ntheta(v);
   y = zeros(nh,k);
   c = ones(nh,1);
   p = vv;
   count = 1;
   y(count,:) = p;
   if all(p==fliplr(p))
      c(count) = c(count)/2;
   end
   while count<nh
      p = nmp(p);
      while ~istheta(p)
         p = nmp(p);
      end
      count = count+1;
      y(count,:) = p;
      if all(p==fliplr(p))  % palidromic permutation?
         c(count) = c(count)/2;
      end
   end
 
