%
%   This Matlab function creates the list of 
%   permutations of a vector of integers vv
%   that lead to unique theta.  The coefficient
%   associated with the unique theta is also given.
%
function [y,c] = thetalist(vv)
   vv = sort(vv);
   k = length(vv);
   vu = unique(vv);
   r = length(vu);
   if r==1
      y = vv;
      c = 0.5;
      return
   end
   if k==2  % This is for the case that vv(1)~=vv(2)
      y = vv;
      c = 1;
      return
   end
   if r==k
      f = fixbracef(k+1);
      nh = size(f,1);
      y = zeros(nh,k);
      c = ones(nh,1);
      for i=1:nh
          y(i,:) = nthperm(vv,f(i));
      end
      return
   end
   v = zeros(1,r);
   for i=1:r
       v(i) = sum(vv==vu(i));
   end
   nh = exp(gammaln(sum(v)+1)-sum(gammaln(v+1)))/2;
   if sum(rem(v,2)==1)<=1
      k2 = fix(v/2);
      nh = nh++exp(gammaln(sum(k2)+1)-sum(gammaln(k2+1)))/2;
   end
   nh = round(nh);
   y = zeros(nh,k);
   c = ones(nh,1);
   p = vv;
   count = 1;
   y(count,:) = p;
   if all(p==fliplr(p))
      c(count) = c(count)/2;
   end
   while count<nh
      p = nmp(p);
      while ~istheta(p)
         p = nmp(p);
      end
      count = count+1;
      y(count,:) = p;
      if all(p==fliplr(p))  % palidromic permutation?
         c(count) = c(count)/2;
      end
   end
 