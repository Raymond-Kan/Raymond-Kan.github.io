function ys = tostr(ys)
%TOSTR  Convert a cell array of character vectors to the native string type.
%
%   ys = TOSTR(ys) returns a string array in Matlab and leaves the input,
%   a cell array of character vectors, unchanged in GNU Octave, which has
%   no string class.  All expression-generating functions of the package
%   pass their output through this function.

   if exist('OCTAVE_VERSION','builtin') == 0
      ys = string(ys);
   end
end
