%
% qratintnc.m  Date: 5/20/2010, last revised 7/22/2026 (Version 1.3, see readme.txt)
% This Matlab program computes E[(x'Ax)^p/(x'Bx)^q], where p is a
% nonnegative real number, q is a nonnegative real number, and
% z ~ N(mu,I_n).  It makes use of an integration approach.
% Input:
% A: matrix of the quadratic form in the numerator
% B: matrix of the quadratic form in the denominator
% mu: mean of the normal random vector
% p: power of the quadratic form in the numerator
% q: power of the quadratic form in the denominator
% E: absolute error (default is 1e-10)
% Output:
% y: E[(z'Az)^p/(z'Bz)^q]
%
function y = qratintnc(A,B,mu,p,q,E);
if nargin<6
   E = 1e-10;
end
if nargin<5
   q = p;
end
n = size(A,1);
if n==1
   r = p-q;
   if r>-0.5
      lam = mu^2;
%
%     The following expression can be used when symbolic toolbox is available
%     y = (2*A)^p/(2*B)^q*gamma(0.5+r)/sqrt(pi)*exp(-lam/2)*hypergeom(r+0.5,0.5,lam/2);
%
      if rem(r,1)==0
         c = (2*A)^p/(2*B)^q*gamma(0.5+r)/sqrt(pi);
         y = c;
         for i=1:r
             c = c*lam*(r+1-i)/i/(2*i-1);
             y = y+c;
         end
      else  % evaluate 1F1(r+1/2;1/2;lam/2) by its positive-term series;
            % this works for all r>-1/2, including negative non-integer r,
            % and removes the Statistics Toolbox dependency
         c = 1;
         f = 1;
         k = 0;
         while c>1e-16*f
             c = c*(r+0.5+k)/((0.5+k)*(k+1))*(lam/2);
             f = f+c;
             k = k+1;
         end
         y = (2*A)^p/(2*B)^q*gamma(0.5+r)/sqrt(pi)*exp(-lam/2)*f;
      end
   else
      y = NaN;
   end
   return
end
pr = ceil(p)-p;
if q==0
   if p==0
      y = 1;
   else
      [P,D] = eig(A);
      a = 2*diag(D);
      delta = (P'*mu).^2;
      ra = rank(A);
      if ra<n
         [~,i1] = sort(abs(a));
         a(i1(1:n-ra)) = 0;
      end
      if pr==0
         q0 = zeros(n,1);
         h0 = zeros(n,1);
         d = 1;
         for i=1:p
             q0 = a.*(d+q0);
             h0 = delta.*q0+a.*h0;
             d = sum(q0+h0)/(2*i);
         end
         y = gamma(p+1)*d;
      elseif any(a<0)
         y = NaN;
         fprintf('A matrix must be positive semi-definite when p is not an integer!\n')
      else
         p = ceil(p);
         y = integral(@(t) mom(t).*t.^(pr-1),0,Inf,'AbsTol',E,'RelTol',1e-9)*gamma(p+1)/gamma(pr);
      end
   end
   return
end
[P,D] = eig(B);
d = diag(D);
rb = rank(B);
if rb<n
   [~,i1] = sort(abs(d));
   d(i1(1:n-rb)) = 0;
end
sn = 1;
if all(d<=0)
   if rem(q,1)==0
      d = abs(d);
      sn = 1-2*rem(q,2);   % sn=-1 if q is odd, and +1 if q is even
   else
      y = NaN;
      fprintf('B matrix must be positive semi-definite when q is not an integer!\n')
      return
   end
end
[d,ii] = sort(d,1,'descend');
if d(1)*d(end)<0
   y = NaN;
   fprintf('B matrix must be semi-definite!\n')
   return
end
maxb = d(1);
if maxb==0   % B is a zero matrix, moment does not exist for q>0
   y = NaN;
   return
end
sn = sn/maxb^q;
d = d/maxb;
da = eig(A);
ra = rank(A);
if ra<n
   [~,i1] = sort(abs(da));
   da(i1(1:n-ra)) = 0;
end
if pr>0&&any(da<0)
   y = NaN;
   fprintf('A matrix must be positive semi-definite when p is not an integer!\n')
   return
elseif all(da<=0)
   A = -A;
   da = abs(da);
   sn = sn*(1-2*rem(p,2));
end
maxa = max(da);
if maxa==0&&p>0   % A is a zero matrix, so (x'Ax)^p = 0
   y = 0;
   return
elseif maxa>0
   sn = sn*maxa^p;
   A = A./maxa;
end
P = P(:,ii);
A = P'*A*P;
A = A+A';      % Symmetrize and double: the routines below work with 2A
               % (this supplies the factor of 2 in terms like 1+lam*s)
mu = P'*mu;
m = rank(B);
d(m+1:end) = 0;
%
%  Check for existence of moments
%
if m/2+p<=q
   y = NaN;
   return
end
if m<n   % Stronger condition for existence of moments when B is psd.
   A22 = A(m+1:end,m+1:end);
   A12 = A(1:m,m+1:end);
   if any(abs(A22(:))>eps)
      if m/2<=q
         y = NaN;
         return
      end
   elseif any(abs(A12(:))>eps)
      if (m+p)/2<=q
         y = NaN;
         return
      end
   else
%
%  reduce the size of the problem if A_{12}=0_{mx(n-m)} and A_{22}=0_{(n-m)x(n-m)}
%
      A = A(1:m,1:m);
      d = d(1:m);
      mu = mu(1:m);
      n = m;
   end
end

if pr==0
   y = sn*integral(@(t) momr1(t).*t.^(q-1),0,Inf,'AbsTol',E,'RelTol',1e-9)* exp(-0.5*(mu'*mu))*gamma(p+1)/gamma(q);
else
   p = ceil(p);
   y = sn*integral2(@(t,s) t.^(q-1).*momr(s,t).*s.^(pr-1),0,Inf,0,Inf,'AbsTol',E,'RelTol',1e-9)*exp(-0.5*(mu'*mu))*gamma(p+1)/gamma(pr)/gamma(q);
end

function y2 = mom(t)
%
%  This program computes |C|^{-1/2}exp(-0.5*mu'mu+0.5*mu'*inv(C)*mu)E[(z'\hat{A}z)^p]/p!, 
%  where z ~ N(C^{-1/2}mu,I_n), \hat{A}=C^{-1/2}AC^{-1/2}, and C = I_n+2t*A.
%
   M = length(t);
   y2 = ones(1,M);
   d0 = 1+a*t;
   d1 = a*ones(1,M)./d0;
   delta1 = delta*ones(1,M)./d0; 
   q0 = zeros(n,M);
   h0 = zeros(n,M);
   for j=1:p
       q0 = d1.*(ones(n,1)*y2+q0);
       h0 = delta1.*q0+d1.*h0;
       y2 = sum(q0+h0)/(2*j);
   end
   y2 = y2.*exp(-0.5*t.*sum(a*ones(1,M).*delta1))./sqrt(prod(d0));
end

function y2 = momr1(t)
%
%  This program computes |I_n+2tB|^{-1/2}exp(-mu'*mu/2+mu'*(I_n+2tB)^{-1}mu)E[(w'Rw)^p]/p!, 
%  where w ~ N(Delta*mu,I_n), and R = Delta*A*Delta.
%
   M = length(t);
   y2 = ones(1,M);
   for i=1:M
       dr = 1./sqrt(1+2*t(i)*d);
       muR = mu.*dr;
       A1 = A.*(dr*dr');
       G = zeros(n);
       g = zeros(n,1);
       for j=1:p
           G = y2(i)*A1+A1*G;
           g = G*muR+A1*g;
           y2(i) = (trace(G)+muR'*g)/(2*j);
       end
       y2(i) = y2(i)*prod(dr)*exp(muR'*muR/2);
   end
end

function y2 = momr(s,t)
%
%  This program computes |C|^(1/2)exp(0.5*mu'*C*mu)E[(w'Rw)^p]/p!, 
%  where w ~ N(C^(1/2)*mu,I_n).
%
   t = t(1);
   M = length(s);
   y2 = ones(1,M);
   dr = 1./sqrt(1+2*t*d);  
   [Q,D] = eig(A.*(dr*dr'));
   delta0 = (Q'*(mu.*dr)).^2;
   lam = diag(D);
   lam1 = 1+lam*s;
   d0 = lam*ones(1,M)./lam1;
   delta = delta0*ones(1,M)./lam1;
   q0 = zeros(n,M);
   h0 = zeros(n,M);
   for j=1:p
       q0 = d0.*(ones(n,1)*y2+q0);
       h0 = delta.*q0+d0.*h0;
       y2 = sum(q0+h0)/(2*j);
   end
   y2 = y2.*exp(sum(delta)/2)./sqrt(prod(lam1)).*prod(dr);
end

end
