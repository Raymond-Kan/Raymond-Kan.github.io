%
% qratser.m  Date: 5/20/2010, last revised 7/22/2026 (Version 1.3, see readme.txt)
% This Matlab program computes E[(x'Ax)^p/(x'Bx)^q], where p is a
% nonnegative real number, q is a nonnegative real number, and
% z ~ N(0_n,I_n).  It makes use of an infinite series approach.
% Input:
% A: matrix of the quadratic form in the numerator
% B: matrix of the quadratic form in the denominator
% p: power of the quadratic form in the numerator
% q: power of the quadratic form in the denominator
% E: relative error (default is 1e-10)
% Output:
% y: E[(z'Az)^p/(z'Bz)^q]
% j: Number of iterations
%
function [y,j] = qratser(A,B,p,q,E);
j = 0;
if nargin<5
   E = 1e-10;
end
if nargin<4
   q = p;
end
n = size(A,1);
if n==1
   if p+0.5>q
      y = (2*A)^p/(2*B)^q*gamma(0.5+p-q)/sqrt(pi);
   else
      y = NaN;
   end
   return
end
pr = ceil(p)-p;
M = 1000;  % Maximum number of terms
if q==0
   if p==0
      y = 1;
   else
      a = 2*eig(A);
      ra = rank(A);
      if ra<n
         [~,i1] = sort(abs(a));
         a(i1(1:n-ra)) = 0;
      end
      if pr==0
         q0 = zeros(n,1);
         d = 1;
         for i=1:p
             q0 = a.*(d+q0);
             d = sum(q0)/(2*i);
         end
         y = gamma(p+1)*d;
      elseif any(a<0)
         y = NaN;
         fprintf('A matrix must be positive semi-definite when p is not an integer!\n')
      else
         maxea = max(a);
         a = 1-a/maxea;
         a(a==0) = [];
         n2 = n/2;
         c = maxea^p*gamma(n2+p)/gamma(n2);
         q0 = 0;
         q1 = c;
         y = q1;
         d = 1;
         q2 = zeros(size(a));
         tt = zeros(M,1);
         sabs = abs(q1);
         while (abs(q1)>q0||abs(q1/y)>E)&&j<M
            q0 = abs(q1);
            c = c*(-p+j)/(n2+j);
            j = j+1;
            q2 = a.*(d+q2);
            d = sum(q2)/(2*j);
            q1 = c*d;
            y = y+q1;
            sabs = sabs+abs(q1);
            tt(j) = q1;
         end
         %
         %  When mu = 0_n, the series has no severe cancellation problem except
         %  when A is indefinite (integer p) and the moment is close to zero, in
         %  which case the relative accuracy is limited (the integration method
         %  would do no better, so we only warn).
         %
         if eps*sabs > max(100*E,1e-11)*max(abs(y),realmin)
            fprintf(' Warning: cancellation limits the relative accuracy of the series to ~ %.1e\n',eps*sabs/max(abs(y),realmin))
         end
         if j==M
            [y,added] = addtail(y,tt,j);
            if added
               fprintf(' Maximum number of terms reached; an estimated tail was added\n')
            else
               fprintf(' Maximum number of terms reached\n')
            end
         end
      end
   end
   return
end
[P,D] = eig(B);
d = diag(D);
rb = rank(B);
if rb<n
   [~,i1] = sort(abs(d));
   d(i1(1:n-rb)) = 0;
end
sn = 1;
if all(d<=0)
   if rem(q,1)==0
      d = abs(d);
      sn = 1-2*rem(q,2);   % sn=-1 if q is odd, and +1 if q is even
   else
      y = NaN;
      fprintf('B matrix must be positive semi-definite when q is not an integer!\n')
      return
   end
end
[d,ii] = sort(d,1,'descend');
if d(1)*d(end)<0
   y = NaN;
   fprintf('B matrix must be semi-definite!\n')
   return
end
maxb = d(1);
if maxb==0   % B is a zero matrix, moment does not exist for q>0
   y = NaN;
   return
end
sn = sn/maxb^q;
d = d/maxb;
da = eig(A);
ra = rank(A);
if ra<n
   [~,i1] = sort(abs(da));
   da(i1(1:n-ra)) = 0;
end
if pr>0&&any(da<0)
   y = NaN;
   fprintf('A matrix must be positive semi-definite when p is not an integer!\n')
   return
elseif all(da<=0)
   A = -A;
   da = abs(da);
   sn = sn*(1-2*rem(p,2));
end
maxa = max(da);
if maxa==0&&p>0   % A is a zero matrix, so (x'Ax)^p = 0
   y = 0;
   return
elseif maxa>0
   sn = sn*maxa^p;
   A = A./maxa;
end
P = P(:,ii);
A = P'*A*P;
m = rank(B);
d(m+1:end) = 0;
%
%  Check for existence of moments
%
if m/2+p<=q
   y = NaN;
   return
end
if m<n   % Stronger condition for existence of moments when B is psd.
   A22 = A(m+1:end,m+1:end);
   A12 = A(1:m,m+1:end);
   if any(abs(A22(:))>eps)
      if m/2<=q
         y = NaN;
         return
      end
   elseif any(abs(A12(:))>eps)
      if (m+p)/2<=q
         y = NaN;
         return
      end
   else
%
%  reduce the size of the problem if A_{12}=0_{mx(n-m)} and A_{22}=0_{(n-m)x(n-m)}
%
      A = A(1:m,1:m);
      d = d(1:m);
      n = m;
   end
end
n2 = n/2;
eb = 1-d;
Bh = diag(eb);
D = eb*ones(1,n);
if pr==0
   G = zeros(n,n,p+1);
   d = ones(p+1,1);
   n2p = n2+p;
   c = 2^(p-q)*sn*exp(gammaln(p+1)+gammaln(n2p-q)-gammaln(n2p));
   for i=1:p
       G1 = A*d(i)+A*G(:,:,i);
       d(i+1) = trace(G1)/(2*i);
       G(:,:,i+1) = G1;
   end
   q1 = c*d(end);
   y = q1;
   q0 = 0;
   tt = zeros(M,1);
   sabs = abs(q1);
   while (abs(q1)>q0||abs(q1/y)>E)&&j<M
      q0 = abs(q1);
      c = c*(q+j)/(n2p+j);
      j = j+1;
      G1 = d(1)*Bh+D.*G(:,:,1);
      d(1) = trace(G1)/(2*j);
      G(:,:,1) = G1;
      for i=1:p
          G1 = A*d(i)+Bh*d(i+1)+A*G1+D.*G(:,:,i+1);
          d(i+1) = trace(G1)/(2*(i+j));
          G(:,:,i+1) = G1;
      end
      q1 = c*d(end);
      y = y+q1;
      sabs = sabs+abs(q1);
      tt(j) = q1;
   end
else
   Ah = eye(n)-A;
   q1 = 1;
   y = 1;
   q0 = 0;
% 
%  For a given j=0,1,...,
%  c1(i) = (-p)_{i-1}*(q)_{j-i+1}/(n/2)_j, i=1,...,j+1
%  The rescaling of c1 will cost additional computation 
%  time, but it will reduce the overflow problem.
%
   c1 = ones(M+1,1);
   d = ones(M+1,1);
   G = zeros(n);
   tt = zeros(M,1);
   sabs = 1;
   while (abs(q1)>q0||abs(q1/y)>E)&&j<M
      q0 = abs(q1);
      j = j+1;
      c1(j+1) = c1(j)*(-p+j-1)/(n2+j-1);
      c1(1:j) = c1(1:j).*(q+j-1-(0:j-1)')/(n2+j-1);   % (avoid [q+j-1:-1:q], which can come up short in floating point)
      G = [eb*ones(1,n*j).*G zeros(n)]+[zeros(n) Ah*G];
      G(:,1:n) = G(:,1:n)+d(1)*Bh;
      for i=2:j
          G(:,(i-1)*n+1:i*n) = G(:,(i-1)*n+1:i*n)+d(i)*Bh+d(i-1)*Ah;
      end
      G(:,j*n+1:(j+1)*n) = G(:,j*n+1:(j+1)*n)+d(j)*Ah;
      for i=1:j+1
          d(i) = trace(G(:,(i-1)*n+1:i*n))/(2*j);
      end
      q1 = sum(c1(1:j+1).*d(1:j+1));
      y = y+q1;
      sabs = sabs+abs(q1);
      tt(j) = q1;
   end
end
%
%  If the maximum number of terms was reached (this happens when B is
%  rank deficient, in which case the terms decay only polynomially),
%  add an estimated tail to the partial sum.
%
if j==M
   [y,added] = addtail(y,tt,j);
   if added
      fprintf(' Maximum number of terms reached; an estimated tail was added\n')
   else
      fprintf(' Maximum number of terms reached\n')
   end
end
%
%  When mu = 0_n, the series has no severe cancellation problem except
%  when A is indefinite (integer p) and the moment is close to zero, in
%  which case the relative accuracy is limited (the integration method
%  would do no better, so we only warn).
%
if eps*sabs > max(100*E,1e-11)*max(abs(y),realmin)
   fprintf(' Warning: cancellation limits the relative accuracy of the series to ~ %.1e\n',eps*sabs/max(abs(y),realmin))
end
if pr>0
   y = y*2^(p-q)*sn*exp(gammaln(n2+p-q)-gammaln(n2));
end

function [y1,added] = addtail(y1,tt,j)
%
%  When the series is truncated at the maximum number of terms and the
%  terms decay like c*j^(-s) (this happens when B is rank deficient),
%  estimate the remaining tail, sum_{i>j} tt(i) ~ tt(j)*j/(s-1), from
%  the empirical decay exponent s and add it to the partial sum y1.
%
added = false;
d0 = 20;
if j>3*d0&&tt(j)~=0&&all(sign(tt(j-2*d0:j))==sign(tt(j)))
   s = -log(abs(tt(j)/tt(j-d0)))/log(j/(j-d0));
   if isfinite(s)&&s>1.02
      y1 = y1+tt(j)*j/(s-1);
      added = true;
   end
end
