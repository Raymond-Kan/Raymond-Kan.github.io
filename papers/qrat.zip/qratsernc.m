%
% qratsernc.m  Date: 1/28/2012, last revised 7/22/2026 (Version 1.3, see readme.txt)
% This Matlab program computes E[(x'Ax)^p/(x'Bx)^q], where p is a
% nonnegative real number, q is a nonnegative real number, and
% z ~ N(mu,I_n).  It makes use of an infinite series approach.
% Input:
% A: matrix of the quadratic form in the numerator
% B: matrix of the quadratic form in the denominator
% mu: mean of the normal random vector
% p: power of the quadratic form in the numerator
% q: power of the quadratic form in the denominator
% E: relative error (default is 1e-10)
% Output:
% y: E[(z'Az)^p/(z'Bz)^q]
% j: Number of iterations
%
function [y,j] = qratsernc(A,B,mu,p,q,E);
j = 0;
if nargin<6
   E = 1e-10;
end
if nargin<5
   q = p;
end
A0 = A; B0 = B; mu0 = mu;   % keep the inputs for the fallback to qratintnc.m
n = size(A,1);
if n==1
   r = p-q;
   if r>-0.5
      lam = mu^2;
%
%     The following expression can be used when symbolic toolbox is available
%     y = (2*A)^p/(2*B)^q*gamma(0.5+r)/sqrt(pi)*exp(-lam/2)*hypergeom(r+0.5,0.5,lam/2);
%
      if rem(r,1)==0
         c = (2*A)^p/(2*B)^q*gamma(0.5+r)/sqrt(pi);
         y = c;
         for i=1:r
             c = c*lam*(r+1-i)/i/(2*i-1);
             y = y+c;
         end
      else  % evaluate 1F1(r+1/2;1/2;lam/2) by its positive-term series;
            % this works for all r>-1/2, including negative non-integer r,
            % and removes the Statistics Toolbox dependency
         c = 1;
         f = 1;
         k = 0;
         while c>1e-16*f
             c = c*(r+0.5+k)/((0.5+k)*(k+1))*(lam/2);
             f = f+c;
             k = k+1;
         end
         y = (2*A)^p/(2*B)^q*gamma(0.5+r)/sqrt(pi)*exp(-lam/2)*f;
      end
   else
      y = NaN;
   end
   return
end
pr = ceil(p)-p;
M = 1000;  % Maximum number of terms
if q==0
   if p==0
      y = 1;
   else
      [P,D] = eig(A);
      a = 2*diag(D);
      delta = (P'*mu).^2;
      ra = rank(A);
      if ra<n
         [~,i1] = sort(abs(a));
         a(i1(1:n-ra)) = 0;
      end
      if pr==0
         q0 = zeros(n,1);
         h0 = zeros(n,1);
         d = 1;
         for i=1:p
             q0 = a.*(d+q0);
             h0 = delta.*q0+a.*h0;
             d = sum(q0+h0)/(2*i);
         end
         y = gamma(p+1)*d;
      elseif any(a<0)
         y = NaN;
         fprintf('A matrix must be positive semi-definite when p is not an integer!\n')
      else
         maxea = max(a);
         a = 1-a/maxea;
         n2 = n/2;
         c = maxea^p*gamma(n2+p)/gamma(n2);
         q0 = 0;
         q1 = c;
         y = q1;
         d = 1;
         q2 = zeros(n,1);
         h0 = zeros(n,1);
         delta = delta.*(a-1);
         tt = zeros(M,1);
         sabs = abs(q1);
         while (abs(q1)>q0||abs(q1/y)>E)&&j<M
            q0 = abs(q1);
            c = c*(-p+j)/(n2+j);
            j = j+1;
            temp = d+q2;
            q2 = a.*temp;
            h0 = delta.*temp+a.*h0;
            d = sum(q2+h0)/(2*j);
            q1 = c*d;
            y = y+q1;
            sabs = sabs+abs(q1);
            tt(j) = q1;
         end
         %
         %  The h coefficients in the series alternate in sign and can be as
         %  large as exp(mu'mu/2), so for large mu'mu the sum suffers severe
         %  cancellation.  Estimate the cancellation error and switch to the
         %  integration method when the series cannot deliver the accuracy.
         %
         if eps*sabs > max(100*E,1e-11)*max(abs(y),realmin)
            fprintf(' Warning: severe cancellation in the series (relative error ~ %.1e);\n',eps*sabs/max(abs(y),realmin))
            fprintf('          switching to the integration method (qratintnc.m)\n')
            y = qratintnc(A0,B0,mu0,p,q,E);
            return
         end
         if j==M
            [y,added] = addtail(y,tt,j);
            if added
               fprintf(' Maximum number of terms reached; an estimated tail was added\n')
            else
               fprintf(' Maximum number of terms reached\n')
            end
         end
      end
   end
   return
end
[P,D] = eig(B);
d = diag(D);
rb = rank(B);
if rb<n
   [~,i1] = sort(abs(d));
   d(i1(1:n-rb)) = 0;
end
sn = 1;
if all(d<=0)
   if rem(q,1)==0
      d = abs(d);
      sn = 1-2*rem(q,2);   % sn=-1 if q is odd, and +1 if q is even
   else
      y = NaN;
      fprintf('B matrix must be positive semi-definite when q is not an integer!\n')
      return
   end
end
[d,ii] = sort(d,1,'descend');
if d(1)*d(end)<0
   y = NaN;
   fprintf('B matrix must be semi-definite!\n')
   return
end
maxb = d(1);
if maxb==0   % B is a zero matrix, moment does not exist for q>0
   y = NaN;
   return
end
sn = sn/maxb^q;
d = d/maxb;
da = eig(A);
ra = rank(A);
if ra<n
   [~,i1] = sort(abs(da));
   da(i1(1:n-ra)) = 0;
end
if pr>0&&any(da<0)
   y = NaN;
   fprintf('A matrix must be positive semi-definite when p is not an integer!\n')
   return
elseif all(da<=0)
   A = -A;
   da = abs(da);
   sn = sn*(1-2*rem(p,2));
end
maxa = max(da);
if maxa==0&&p>0   % A is a zero matrix, so (x'Ax)^p = 0
   y = 0;
   return
elseif maxa>0
   sn = sn*maxa^p;
   A = A./maxa;
end
P = P(:,ii);
A = P'*A*P;
mu = P'*mu;
m = rank(B);
d(m+1:end) = 0;
%
%  Check for existence of moments
%
if m/2+p<=q
   y = NaN;
   return
end
if m<n   % Stronger condition for existence of moments when B is psd.
   A22 = A(m+1:end,m+1:end);
   A12 = A(1:m,m+1:end);
   if any(abs(A22(:))>eps)
      if m/2<=q
         y = NaN;
         return
      end
   elseif any(abs(A12(:))>eps)
      if (m+p)/2<=q
         y = NaN;
         return
      end
   else
%
%  reduce the size of the problem if A_{12}=0_{mx(n-m)} and A_{22}=0_{(n-m)x(n-m)}
%
      A = A(1:m,1:m);
      d = d(1:m);
      mu = mu(1:m);
      n = m;
   end
end
n2 = n/2;
eb = 1-d;
Bh = diag(eb);
D = eb*ones(1,n);
if pr==0
   G = zeros(n,n,p+1);
   g = zeros(n,p+1);
   d = ones(p+1,1);
   n2p = n2+p;
   c = 2^(p-q)*sn*exp(gammaln(p+1)+gammaln(n2p-q)-gammaln(n2p));
   for i=1:p
       G1 = A*d(i)+A*G(:,:,i);
       g(:,i+1) = G1*mu+A*g(:,i);
       d(i+1) = (trace(G1)+mu'*g(:,i+1))/(2*i);
       G(:,:,i+1) = G1;
   end
   q1 = c*d(end);
   y = q1;
   q0 = 0;
   tt = zeros(M,1);
   sabs = abs(q1);
   while (abs(q1)>q0||abs(q1/y)>E)&&j<M
      q0 = abs(q1);
      c = c*(q+j)/(n2p+j);
      j = j+1;
      G1 = d(1)*Bh+D.*G(:,:,1);
      g(:,1) = (G1-G(:,:,1))*mu-d(1)*mu+eb.*g(:,1);
      d(1) = (trace(G1)+mu'*g(:,1))/(2*j);
      G(:,:,1) = G1;
      for i=1:p
          G1 = A*d(i)+Bh*d(i+1)+A*G1+D.*G(:,:,i+1);
          g(:,i+1) = (G1-G(:,:,i+1))*mu-d(i+1)*mu+A*g(:,i)+eb.*g(:,i+1);
          d(i+1) = (trace(G1)+mu'*g(:,i+1))/(2*(i+j));
          G(:,:,i+1) = G1;
      end
      q1 = c*d(end);
      y = y+q1;
      sabs = sabs+abs(q1);
      tt(j) = q1;
   end
else
   Ah = eye(n)-A;
   q1 = 1;
   y = 1;
   q0 = 0;
% 
%  For a given j=0,1,...,
%  c1(i) = (-p)_{i-1}*(q)_{j-i+1}/(n/2)_j, i=1,...,j+1
%  The rescaling of c1 will cost additional computation 
%  time, but it will reduce the overflow problem.
%
   c1 = ones(M+1,1);
   d = ones(M+1,1);
   G = zeros(n);
   g = zeros(n,1);
   tt = zeros(M,1);
   sabs = 1;
   while (abs(q1)>q0||abs(q1/y)>E)&&j<M
      q0 = abs(q1);
      j = j+1;
      c1(j+1) = c1(j)*(-p+j-1)/(n2+j-1);
      c1(1:j) = c1(1:j).*(q+j-1-(0:j-1)')/(n2+j-1);   % (avoid [q+j-1:-1:q], which can come up short in floating point)
      temp = d(j)*eye(n)+G(:,(j-1)*n+1:j*n);
      G(:,j*n+1:(j+1)*n) = Ah*temp;
      g(:,j+1) = (G(:,j*n+1:(j+1)*n)-temp)*mu+Ah*g(:,j);
      for i=j:-1:2
          temp1 = d(i-1)*eye(n)+G(:,(i-2)*n+1:(i-1)*n);
          G(:,(i-1)*n+1:i*n) = Ah*temp1+D.*temp;
          g(:,i) = (G(:,(i-1)*n+1:i*n)-temp-temp1)*mu+Ah*g(:,i-1)+eb.*g(:,i);
          temp = temp1;
      end
      G(:,1:n) = D.*temp;
      g(:,1) = (G(:,1:n)-temp)*mu+eb.*g(:,1);
      for i=1:j+1
          d(i) = (trace(G(:,(i-1)*n+1:i*n))+mu'*g(:,i))/(2*j);
      end
      q1 = sum(c1(1:j+1).*d(1:j+1));
      y = y+q1;
      sabs = sabs+abs(q1);
      tt(j) = q1;
   end
end
%
%  If the maximum number of terms was reached (this happens when B is
%  rank deficient, in which case the terms decay only polynomially),
%  add an estimated tail to the partial sum.
%
if j==M
   [y,added] = addtail(y,tt,j);
   if added
      fprintf(' Maximum number of terms reached; an estimated tail was added\n')
   else
      fprintf(' Maximum number of terms reached\n')
   end
end
%
%  The h coefficients in the series alternate in sign and can be as
%  large as exp(mu'mu/2), so for large mu'mu the sum suffers severe
%  cancellation.  Estimate the cancellation error and switch to the
%  integration method when the series cannot deliver the accuracy.
%
if eps*sabs > max(100*E,1e-11)*max(abs(y),realmin)
   fprintf(' Warning: severe cancellation in the series (relative error ~ %.1e);\n',eps*sabs/max(abs(y),realmin))
   fprintf('          switching to the integration method (qratintnc.m)\n')
   y = qratintnc(A0,B0,mu0,p,q,E);
   return
end
if pr>0
   y = y*2^(p-q)*sn*exp(gammaln(n2+p-q)-gammaln(n2));
end

function [y1,added] = addtail(y1,tt,j)
%
%  When the series is truncated at the maximum number of terms and the
%  terms decay like c*j^(-s) (this happens when B is rank deficient),
%  estimate the remaining tail, sum_{i>j} tt(i) ~ tt(j)*j/(s-1), from
%  the empirical decay exponent s and add it to the partial sum y1.
%
added = false;
d0 = 20;
if j>3*d0&&tt(j)~=0&&all(sign(tt(j-2*d0:j))==sign(tt(j)))
   s = -log(abs(tt(j)/tt(j-d0)))/log(j/(j-d0));
   if isfinite(s)&&s>1.02
      y1 = y1+tt(j)*j/(s-1);
      added = true;
   end
end
