%
%   test1.m
%   This Matlab program tests qratint.m and qratintnc.m
%
n = 240;
pmax = 5;
qmax = 5;
pm = 2*pmax+1;
qm = 2*qmax+1;
m1 = zeros(pm,qm);
m2 = zeros(pm,qm);
x = randn(4*n,n);
A = (x'*x)/(4*n);
x = randn(4*n,n);
B = (x'*x)/(4*n);
mu = randn(n,1);
t = cputime;
for i=1:pm
    p = (i-1)/2;
    for j=1:qm
        q = (j-1)/2;
        m1(i,j) = qratint(A,B,p,q);
        m2(i,j) = qratintnc(A,B,mu,p,q);
    end
end
t = cputime-t;
delete test1.out
diary test1.out
fprintf(' Integration Approach\n')
fprintf(' CPU Time = %10.3fs\n',t)
fprintf(' Central Normal:\n')
fprintf(' n = %4.0f\n',n)
fprintf('       ')
for j=1:qm
    fprintf('      q=%3.1f     ',(j-1)/2)
end
fprintf('\n')
for i=1:pm
    fprintf(' p=%3.1f',(i-1)/2)
    for j=1:qm
        fprintf('%16.6e',m1(i,j))
    end
    fprintf('\n')
end
fprintf('\n Noncentral Normal:\n')
fprintf(' n = %4.0f\n',n)
fprintf('       ')
for j=1:qm
    fprintf('      q=%3.1f     ',(j-1)/2)
end
fprintf('\n')
for i=1:pm
    fprintf(' p=%3.1f',(i-1)/2)
    for j=1:qm
        fprintf('%16.6e',m2(i,j))
    end
    fprintf('\n')
end
n1 = zeros(pm,qm);
n2 = zeros(pm,qm);
t = cputime;
for i=1:pm
    p = (i-1)/2;
    for j=1:qm
        q = (j-1)/2;
        [m1(i,j), n1(i,j)] = qratser(A,B,p,q);
        [m2(i,j), n2(i,j)] = qratsernc(A,B,mu,p,q);
    end
end
t = cputime-t;
fprintf('\n\n Infinite Series Approach\n')
fprintf(' CPU Time = %10.3fs\n',t)
fprintf(' Central Normal:\n')
fprintf(' n = %4.0f\n',n)
fprintf('       ')
for j=1:qm
    fprintf('      q=%3.1f     ',(j-1)/2)
end
fprintf('\n')
for i=1:pm
    fprintf(' p=%3.1f',(i-1)/2)
    for j=1:qm
        fprintf('%16.6e',m1(i,j))
    end
    fprintf('\n')
end
fprintf('\n Number of Iterations:\n')
fprintf('       ')
for j=1:qm
    fprintf('   q=%3.1f',(j-1)/2)
end
fprintf('\n')
for i=1:pm
    fprintf(' p=%3.1f',(i-1)/2)
    for j=1:qm
        fprintf('%8.0f',n1(i,j))
    end
    fprintf('\n')
end
fprintf('\n Noncentral Normal:\n')
fprintf(' n = %4.0f\n',n)
fprintf('       ')
for j=1:qm
    fprintf('      q=%3.1f     ',(j-1)/2)
end
fprintf('\n')
for i=1:pm
    fprintf(' p=%3.1f',(i-1)/2)
    for j=1:qm
        fprintf('%16.6e',m2(i,j))
    end
    fprintf('\n')
end
fprintf('\n Number of Iterations:\n')
fprintf('       ')
for j=1:qm
    fprintf('   q=%3.1f',(j-1)/2)
end
fprintf('\n')
for i=1:pm
    fprintf(' p=%3.1f',(i-1)/2)
    for j=1:qm
        fprintf('%8.0f',n2(i,j))
    end
    fprintf('\n')
end
diary off