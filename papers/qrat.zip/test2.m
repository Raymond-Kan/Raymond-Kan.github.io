%
%   test2.m
%   This Matlab program tests the relative speed of
%   qratintnc.m vs. qratsernc.m
%
n = [60:60:600];
ln = length(n);
delete test2.out
diary test2.out
for ii=1:2
    if ii==1
       p = 2;
       q = 3.5;
    end
    if ii==2
       p = 2.5;
       q = 3.5;
    end
    fprintf(' p = %4.1f,  q = %4.1f\n',p,q)
    fprintf(' Central normal:\n')
    fprintf('                    Integration                           Series\n')
    fprintf('    n         Moment         CPU Time      Moment      No. of Terms     CPU Time\n')
    for i=1:ln
        n1 = n(i);
        x = randn(4*n1,n1);
        A = (x'*x)/(4*n1);
        x = randn(4*n1,n1);
        B = (x'*x)/(4*n1);
        t = cputime;
        m1 = qratint(A,B,p,q);
        t1 = cputime-t;
        t = cputime;
        [m2,M] = qratser(A,B,p,q);
        t2 = cputime-t;
        fprintf('%6.0f  %16.6e %10.2fs %16.6e    %6.0f     %10.2fs\n',n1,m1,t1,m2,M,t2)
    end
    fprintf('\n Noncentral normal:\n')
    fprintf('                    Integration                           Series\n')
    fprintf('    n         Moment         CPU Time      Moment      No. of Terms     CPU Time\n')
    for i=1:ln
        n1 = n(i);
        x = randn(4*n1,n1);
        A = (x'*x)/(4*n1);
        x = randn(4*n1,n1);
        B = (x'*x)/(4*n1);
        mu = randn(n1,1);
        t = cputime;
        m1 = qratintnc(A,B,mu,p,q);
        t1 = cputime-t;
        t = cputime;
        [m2,M] = qratsernc(A,B,mu,p,q);
        t2 = cputime-t;
        fprintf('%6.0f  %16.6e %10.2fs %16.6e    %6.0f     %10.2fs\n',n1,m1,t1,m2,M,t2)
    end
    fprintf('\n\n')
end
diary off
