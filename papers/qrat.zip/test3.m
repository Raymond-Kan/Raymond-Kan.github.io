%
%   test3.m
%   Regression tests for the fixes introduced in Version 1.3.
%   Reference values were computed by high-precision quadrature and
%   Monte Carlo, independently of these programs.
%
A = [2.0,0.4,0.2;0.4,1.5,0.3;0.2,0.3,1.0];
B = [1.2,0.3,0.1;0.3,0.8,0.2;0.1,0.2,0.6];
mu = [0.5;-0.3;0.8];

delete test3.out
diary test3.out
fprintf('1. Non-binary q=1.8 (used to crash qratser/qratsernc):\n')
fprintf('   qratser(A,B,2.5,1.8)     = %.8e (ref 7.25176443e+00)\n',qratser(A,B,2.5,1.8))
fprintf('   qratsernc(A,B,mu,2.5,1.8)= %.8e (ref 8.69846899e+00)\n',qratsernc(A,B,mu,2.5,1.8))
fprintf('   qratint(A,B,2.5,1.8)     = %.8e (ref 7.25176443e+00)\n',qratint(A,B,2.5,1.8))
fprintf('   qratintnc(A,B,mu,2.5,1.8)= %.8e (ref 8.69846899e+00)\n',qratintnc(A,B,mu,2.5,1.8))

fprintf('\n2. Rank-deficient B (series used to be off by several percent):\n')
V = [1,0.2,0.1;0.2,1,0.3;0.1,0.3,1];
[V,~] = qr(V);
Bp = V*diag([1.5,0.7,0])*V';
fprintf('   qratser(A,Bp,2,0.7)      = %.8e (ref 1.65223404e+01)\n',qratser(A,Bp,2,0.7))
fprintf('   qratsernc(A,Bp,mu,2,0.7) = %.8e (ref 2.59892589e+01)\n',qratsernc(A,Bp,mu,2,0.7))

fprintf('\n3. n=1 with non-integer r=p-q<0 (used to fail):\n')
fprintf('   qratintnc(1.3,0.8,0.7,0.2,0.5) = %.10e (ref 2.1504088138e+00)\n',qratintnc(1.3,0.8,0.7,0.2,0.5))
fprintf('   qratsernc(1.3,0.8,0.7,0.2,0.5) = %.10e (ref 2.1504088138e+00)\n',qratsernc(1.3,0.8,0.7,0.2,0.5))
fprintf('   qratintnc(1.3,0.8,0.7,1.2,0.5) = %.10e (ref 1.7207476258e+00)\n',qratintnc(1.3,0.8,0.7,1.2,0.5))

fprintf('\n4. Zero A matrix:\n')
fprintf('   qratint(zeros(3),B,1,1)  = %.1f (ref 0)\n',qratint(zeros(3),B,1,1))
fprintf('   qratser(zeros(3),B,1,1)  = %.1f (ref 0)\n',qratser(zeros(3),B,1,1))

fprintf('\n5. Large noncentrality (series used to suffer catastrophic cancellation,\n')
fprintf('   now falls back to the integration method):\n')
mu7 = 7*ones(2,1); A2 = [2.0,0.4;0.4,1.5]; B2 = [1.2,0.3;0.3,0.8];
fprintf('   qratsernc(eye(2),eye(2),mu7,0.5,0) = %.10e (ref 9.9501334482e+00)\n',qratsernc(eye(2),eye(2),mu7,0.5,0))
fprintf('   qratsernc(A2,B2,mu7,2,1.5)         = %.10e (ref 3.1020001349e+01)\n',qratsernc(A2,B2,mu7,2,1.5))
fprintf('   qratsernc(A2,B2,mu7,1.3,0.7)       = %.10e (ref 3.5451429630e+01)\n',qratsernc(A2,B2,mu7,1.3,0.7))

fprintf('\n6. Unchanged paths (should match Version 1.2):\n')
fprintf('   qratint(A,B,2,1.5)       = %.10e (ref 4.4718948977e+00)\n',qratint(A,B,2,1.5))
fprintf('   qratintnc(A,B,mu,2,1.5)  = %.10e (ref 5.1122443558e+00)\n',qratintnc(A,B,mu,2,1.5))
fprintf('   qratser(A,B,1.3,0.7)     = %.10e (ref 3.3402294851e+00)\n',qratser(A,B,1.3,0.7))
fprintf('   qratsernc(A,B,mu,1.3,0.7)= %.10e (ref 3.8821753246e+00)\n',qratsernc(A,B,mu,1.3,0.7))
fprintf('   qratser(A,-B,2,1)        = %.10e (ref -7.8173155263e+00)\n',qratser(A,-B,2,1))
fprintf('   qratsernc(A,B,mu,2.5,0)  = %.10e (ref 1.9663178348e+02)\n',qratsernc(A,B,mu,2.5,0))

diary off
