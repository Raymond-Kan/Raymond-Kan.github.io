%
%  This program computes the list of bootstrap ratios from a
%  set of observations as well as their corresponding 
%  probabilities
%  Input: 
%  X: an nx2 matrix with different columns of data for the 
%     numerator and denominator of the ratio
%  Output
%  r: an mxk matrix with the possible bootstrap ratios, where m is 
%     the number of bootstrp ratios
%  p: probability for each bootstrp ratio to occur
%
function [r,p] = bootrat(X)
[n,k] = size(X);
q = nchoosek([1:2*n-1],n-1);
m = length(q);
k = diff([zeros(m,1) q 2*n*ones(m,1)],1,2)-1;
S = k*X;
r = S(:,1)./S(:,2);
c = factorial(n)/n^n;
p1 = c./prod(factorial(k),2);
%
%  Clean up repeated values
%
[r,~,IC] = unique(r);
p = zeros(size(r));
for i=1:m
    p(IC(i)) = p(IC(i))+p1(i);
end
