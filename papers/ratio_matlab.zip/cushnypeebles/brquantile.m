function [q] = brquantile(alpha,u,v)
%[q] = brquantile(alpha,u,v)
%
%Computes the 100*alpha percent quantile of
%mean(u)/mean(v), where the pais (u_i,v_i) are sampled
%(jointly, with replacement) from the vectors (u,v), with equal
%probabilities.
%
%Reference: Broda, S.A., and Kan, R. (2015), "On Distributions
%of Ratios".

if ~isscalar(alpha), error('alpha must be scalar.');end
[tsls,p] = bootrat([u v]);
xCDF = [-Inf; tsls; Inf];
yCDF = [0; cumsum(p); 1];
i= find(yCDF>=alpha,1);
q=xCDF(i);
