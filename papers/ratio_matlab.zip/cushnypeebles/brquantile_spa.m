function [q] = brquantile_spa(alpha,u,v,order)
%[q] = brquantile_spa(alpha,u,v,order=1)
%
%Computes the 100*alpha percent quantile of
%mean(u)/mean(v), where the pais (u_i,v_i) are sampled
%(jointly, with replacement) from the vectors (u,v), with equal
%probabilities, based on the saddlepoint approximation with the
%given order (default is 1).

%Reference: Broda, S.A., and Kan, R. (2015), "On Distributions
%of Ratios".
if nargin<4, order=1;end
if ~isscalar(alpha), error('alpha must be scalar.');end
m1=mean(u);
m2=mean(v);
Sig=cov([u v]);
clam=[1; -m1/m2];
if m2==0
    rstart=0;
else
    rstart=norminv(alpha,m1/m2,sqrt((clam'*Sig*clam)/m2^2/numel(u)));
end
[def,delta,lb1,ub1,lb2,ub2] = defpair(u,v);
z = ones(size(u));
if ~def
    [thetaY,t0] = cumu1(z,v,order);
    zu = z*u';
    zv = z*v';
    st = fsolve(@cgfgrad,[0 0],optimset('disp','off','Jacobian','on','TolX',1e-10,'TolFun',1e-12))';
    theta = Kder(st(1),st(2),z,u,v,2*order+2);
end
q=fzero(@(r)brspacdf(r,u,v,order)-alpha,rstart);
    function F=brspacdf(rvec,u,v,order)
        
        F = zeros(size(rvec));
        
        if def
            % Positive or negative denominator, Y<0: delta=0, Y>0: delta=1
            if isnan(lb2)
                for i=1:numel(rvec)
                    if rvec(i)>=ub1
                        F(i) = 1;
                    elseif rvec(i)>lb1
                        [thetaW,s0] = cumu1(z,u-rvec(i)*v,order);
                        F(i) = spar_cdf(rvec(i),[],thetaW,[],[],s0,delta,order);
                    end
                end
            else
                %
                %  If there are holes in the support of R, then X and Y form a
                %  definite pair.
                %
                [thetaY,t0] = cumu1(z,v,order);
                for i=1:numel(rvec)
                    r = rvec(i);
                    if r<ub1||r>lb2
                        [thetaW,s0] = cumu1(z,u-rvec(i)*v,order);
                        F(i) = spar_cdf(rvec(i),[],thetaW,thetaY,[ub1 lb2 delta],s0,t0,order);
                    else
                        F(i) = spar_cdf(rvec(i),[],[],thetaY,[ub1 lb2 delta],[],t0,order);  % P[Y<0]
                    end
                end
            end
            return
        end
        
        for i=1:numel(rvec)
            [thetaW,s0] = cumu1(z,u-rvec(i)*v,order);
            F(i) = spar_cdf(rvec(i),theta,thetaW,thetaY,st,s0,t0,order);
        end
    end
    function [grad,J]=cgfgrad(t)
        % Gradient and Jacobian of the joint cumulant generating function of X1 and X2
        Q = exp(z*(t(1)*u+t(2)*v)');
        sQ = sum(Q,2);
        Q1 = Q.*zu;
        Q2 = Q.*zv;
        q1 = sum(Q1,2)./sQ;
        q2 = sum(Q2,2)./sQ;
        grad = [sum(q1) sum(q2)];
        K11 = sum(sum(Q1.*zu,2)./sQ)-q1'*q1;
        K12 = sum(sum(Q1.*zv,2)./sQ)-q1'*q2;
        K22 = sum(sum(Q2.*zv,2)./sQ)-q2'*q2;
        J = [K11 K12; K12 K22];
    end



    function [K,t] = cumu1(z,v,order)
        %
        %   This function computes the saddlepoint and cumulants for
        %   z'*v,
        %
        n = length(z);
        m = 2*order+2;
        zv = z*v';
        options = optimset('Display','off','TolX',1e-12);
        t = fzero(@saddlept,0,options);
        Q = exp(t*zv);
        sQ = sum(Q,2);
        F = zeros(n,m);
        F(:,1) = sQ;
        c = 1;
        for i=2:m
            c = c*(i-1);
            Q = Q.*zv;
            F(:,i) = sum(Q,2)./sQ/c;
        end
        R = F;
        for i=3:m
            for j=2:i-1
                R(:,i) = R(:,i)-(j-1)/(i-1)*R(:,j).*F(:,i-j+1);
            end
        end
        K = zeros(m,1);
        K(1) = sum(log(R(:,1)/n));
        K(3:m) = sum(R(:,3:m));
        
        function y = saddlept(t)
            Q = exp(t*zv);
            y = sum(sum(Q.*zv,2)./sum(Q,2));
        end
    end

    function K = Kder(s,t,z,u,v,m)
        n = length(z);
        zu = z*u';
        zv = z*v';
        Q = exp(s*zu+t*zv);
        sQ = sum(Q,2);
        F = zeros(n,m*(m+1)/2);
        F(:,1) = sQ;
        count = 1;
        fac = cumprod([1 1:m-1]);
        for i=2:m
            for j=1:i
                k1 = i-j;
                k2 = j-1;
                count = count+1;
                F(:,count) = sum(Q.*(zu.^k1.*zv.^k2),2)./sQ/fac(k1+1)/fac(j);
            end
        end
        R = F;
        ind = @(i,j)(i-1)*i/2+j;
        for i=3:m
            ind1 = ind(i,1);
            ind2 = ind(i,i);
            for j=2:i-1
                R(:,ind1) = R(:,ind1)-(j-1)/(i-1)*R(:,ind(j,1)).*F(:,ind(i-j+1,1));
                R(:,ind2) = R(:,ind2)-(j-1)/(i-1)*R(:,ind(j,j)).*F(:,ind(i-j+1,i-j+1));
            end
            for j=2:i-1
                ind1 = ind(i,j);
                for i1=0:i-j
                    for i2=double(i1==0):j-2
                        R(:,ind1) = R(:,ind1)-(1-i2/(j-1))*R(:,ind(i-i1-i2,j-i2)).*F(:,ind(i1+i2+1,i2+1));
                    end
                end
            end
        end
        K = zeros(m);
        K(1,1) = sum(log(R(:,1)/n));
        for i=2:m
            K(i,1:i) = sum(R(:,i*(i-1)/2+[1:i]));
        end
    end
end