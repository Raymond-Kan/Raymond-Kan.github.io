function f=brspapdf(rvec,u,v,order)
%
%  This program computes the saddlepoint approximation of
%  the bootstrapped pdf of the ratio of x/y, where
%  x = sum(u)
%  y = sum(v)
%  order: order of saddlepoint approximation
%
z = ones(size(u));
f = zeros(size(rvec));
[def,delta,lb1,ub1,lb2,ub2] = defpair(u,v);
index = (rvec>lb1&rvec<ub1)|(rvec>lb2&rvec<ub2);
if def
   for i=1:numel(rvec)
       r = rvec(i);
       if (r>lb1&r<ub1)|(r>lb2&r<ub2)
          [s0,thetaW] = cumu1(z,u-rvec(i)*v,order);
          J = Jder(rvec(i),s0,z,u,v,order);
          f(i) = spar_pdf(r,[],thetaW,J,[],s0,order);
       end
   end
else
   zu = z*u';
   zv = z*v';
   st = fsolve(@cgfgrad,[0 0],optimset('disp','off','Jacobian','on','TolX',1e-10,'TolFun',1e-12))';
   theta = Kder(st(1),st(2),z,u,v,2*order+2);
   for i=1:numel(rvec)
       r = rvec(i);
       if (r>lb1&r<ub1)|(r>lb2&r<ub2)
          [s0,thetaW] = cumu1(z,u-rvec(i)*v,order);
          J = Jder(rvec(i),s0,z,u,v,order);
          f(i) = spar_pdf(r,theta,thetaW,J,st,s0,order);
       end
   end
end

function [grad,J]=cgfgrad(t)
% Gradient and Jacobian of the joint cumulant generating function of X1 and X2
   Q = exp(z*(t(1)*u+t(2)*v)');
   sQ = sum(Q,2);
   Q1 = Q.*zu;
   Q2 = Q.*zv;
   q1 = sum(Q1,2)./sQ;
   q2 = sum(Q2,2)./sQ;
   grad = [sum(q1) sum(q2)];
   K11 = sum(sum(Q1.*zu,2)./sQ)-q1'*q1;
   K12 = sum(sum(Q1.*zv,2)./sQ)-q1'*q2;
   K22 = sum(sum(Q2.*zv,2)./sQ)-q2'*q2;
   J = [K11 K12; K12 K22];
end

end

function [t,K] = cumu1(z,v,order)
%
%   This function computes the saddlepoint and cumulants for
%   z'*v, 
%
n = length(z);
m = 2*order+1;
zv = z*v';
options = optimset('Display','off','TolX',1e-12);
t = fzero(@saddlept,0,options);
Q = exp(t*zv);
sQ = sum(Q,2);
F = zeros(n,m);
F(:,1) = sQ;
c = 1;
for i=2:m
    c = c*(i-1);
    Q = Q.*zv;
    F(:,i) = sum(Q,2)./sQ/c;
end
R = F;
for i=3:m
    for j=2:i-1
        R(:,i) = R(:,i)-(j-1)/(i-1)*R(:,j).*F(:,i-j+1);
    end
end
K = zeros(m,1);
K(1) = sum(log(R(:,1)/n));
K(3:m) = sum(R(:,3:m));

function y = saddlept(t)
   Q = exp(t*zv);
   y = sum(sum(Q.*zv,2)./sum(Q,2));
end
end

function J = Jder(r,s,z,u,v,order)
   m = 2*order;
   KJ = Kder(s,-r*s,z,u,v,m);   
   J = zeros(m-1,1);
   for i=1:m-1
       J(i) = polyval([i:-1:1].*KJ(i+1,i+1:-1:2),-r);
   end
end

function K = Kder(s,t,z,u,v,m)
n = length(z);
zu = z*u';
zv = z*v';
Q = exp(s*zu+t*zv);
sQ = sum(Q,2);
F = zeros(n,m*(m+1)/2);
F(:,1) = sQ;
count = 1;
fac = cumprod([1 1:m-1]);
for i=2:m
    for j=1:i
        k1 = i-j;
        k2 = j-1;
        count = count+1;
        F(:,count) = sum(Q.*(zu.^k1.*zv.^k2),2)./sQ/fac(k1+1)/fac(j);
    end
end
R = F;
ind = @(i,j)(i-1)*i/2+j;
for i=3:m
    ind1 = ind(i,1);
    ind2 = ind(i,i);
    for j=2:i-1
        R(:,ind1) = R(:,ind1)-(j-1)/(i-1)*R(:,ind(j,1)).*F(:,ind(i-j+1,1));
        R(:,ind2) = R(:,ind2)-(j-1)/(i-1)*R(:,ind(j,j)).*F(:,ind(i-j+1,i-j+1));
    end
    for j=2:i-1
        ind1 = ind(i,j);
        for i1=0:i-j
            for i2=double(i1==0):j-2
                R(:,ind1) = R(:,ind1)-(1-i2/(j-1))*R(:,ind(i-i1-i2,j-i2)).*F(:,ind(i1+i2+1,i2+1));
            end
        end
    end
end
K = zeros(m);
K(1,1) = sum(log(R(:,1)/n));
for i=2:m
    K(i,1:i) = sum(R(:,i*(i-1)/2+[1:i]));
end
end
