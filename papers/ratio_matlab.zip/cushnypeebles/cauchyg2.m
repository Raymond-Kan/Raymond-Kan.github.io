function [pdf,cdf]=cauchyg2(r,m1,m2,ss1,ss2,rho)
%[pdf,cdf]=cauchyg2(rvec,m1,m2,ss1,ss2,rho)
%pdf and cdf of x1/x2, where x_i~N(m_i,ss_i), with correlation rho.
%ratiospa.m is the corresponding SPA
a=sqrt(r.^2./ss1-2*rho*r./sqrt(ss1*ss2)+1/ss2);
b=m1*r/ss1-rho*(m1+m2*r)/sqrt(ss1*ss2)+m2/ss2;
c=m1^2./ss1-2*rho*m1*m2./sqrt(ss1*ss2)+m2^2/ss2;
d=exp((b.^2-c*a.^2)./(2*(1-rho^2).*a.^2));
term=b/sqrt(1-rho^2)./a;
pdf=b.*d/sqrt(2*pi*ss1*ss2)./a.^3.*(normcdf(term)-normcdf(-term))+sqrt(1-rho^2)./sqrt(pi^2*ss1*ss2)./a.^2.*exp(-c./2./(1-rho^2));
if nargout>1
    Pwy=zeros(size(r));
    Py=normcdf(0,m2,sqrt(ss2));
    cv=rho*sqrt(ss1*ss2);
    mw=m1-r*m2;
    sw=sqrt(ss1-2*r*cv+r.^2*ss2);
    Pw=normcdf(0,m1-r*m2,sw);
    for loop=1:length(r)
        rwy=(cv-r(loop)*ss2)/(sw(loop)*sqrt(ss2));
        x1=-mw(loop)./sw(loop);
        y1=-m2/sqrt(ss2);
        Pwy(loop)=mvncdf([x1,y1],[0, 0],[1 rwy; rwy 1]);
    end
    cdf=Pw+Py-2*Pwy;
end