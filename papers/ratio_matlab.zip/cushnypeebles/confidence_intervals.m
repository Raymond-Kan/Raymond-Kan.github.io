function confidence_intervals()
%computes basic bootstrap and bootstrap percentile equal tails
%confidence intervals for the Cusnhy-Peobles data
v = [1.9 0.8 1.1  0.1 -0.1  4.4 5.5 1.6 4.6 3.4]';
u= [0.7  -1.6 -0.2 -1.2  -.1  3.4  3.7  0.8  0.0  2.0]';

ubar = mean(u);
vbar = mean(v);
r=ubar/vbar;
alpha=0.05;

lq=brquantile(alpha/2,u,v);
uq=brquantile(1-alpha/2,u,v);

lq_spa=brquantile_spa(alpha/2,u,v,1);
uq_spa=brquantile_spa(1-alpha/2,u,v,1);

basic_CI=2*r-[uq lq]
basic_CI_spa=2*r-[uq_spa lq_spa]
percentile_CI=[lq uq]
percentile_CI_spa=[lq_spa uq_spa]