function [def,delta,lb1,ub1,lb2,ub2] = defpair(u,v)
%
%  This function checks if sum(u) and sum(v) form a definite pair,
%  where u and v are the data that determine the distribution of (u,v).
%  When they form a definite pair, the function delta = 0/1 such that
%  P[sum(u)-r*sum(v)<0]=delta for lb<=r<=ub, so delta=0 means it is
%  a positive random variable, and delta=1 means it is a negative 
%  random variable.
%
def = false;
delta = NaN;
lb1 = -Inf;
ub1 = Inf;
lb2 = NaN;
ub2 = NaN;
%
%   First check the denominator  
%
n = length(u);
F1 = @(r) -n*min(u-r*v); % negative of the minimum value
F2 = @(r) n*max(u-r*v);  % maximum value
minv = min(v);
maxv = max(v);
m = minv*n;  % minimum value of denominator
M = maxv*n;  % maximum value of denominator
if m>=0||M<=0
   def = true;
   delta = double(m>=0);
   F1a = fzero(F1,0);
   F2a = fzero(F2,0);
   if F1a<F2a
      lb1 = F1a;
      ub1 = F2a;
   else
      lb1 = F2a;
      ub1 = F1a;
   end   
   return
end
%
%  Find out if any r will make sum(u)-r*sum(v) to be a 
%  positive or negative random variable
%
[r1,F1s] = fminsearch(F1,0);
if F1s<=0
   def = true;
   delta = 0;
   ub2 = Inf;
   if F1s<0
      r1a = r1+1;
      F1a = F1(r1a);
      if F1a<0
         r1a = r1+F1s/(F1s-F1a);
      end
      lb2 = fzero(F1,[r1 r1a]);
      r1a = r1-1;
      F1a = F1(r1a);
      if F1a<0
         r1a = r1-F1s/(F1s-F1a);
      end
      ub1 = fzero(F1,[r1a r1]);
   end          
   return
end
[r2,F2s] = fminsearch(F2,0);
if F2s<=0
   def = true;
   delta = 1;
   ub2 = Inf;
   if F2s<0
      r2a = r2+1;
      F2a = F2(r2a);
      if F2a<0
         r2a = r2+F2s/(F2s-F2a);
%  Trap some rounding errors at the end
         if F2(r2a)<0
            r2a = r2a+0.1;
         end
      end
      lb2 = fzero(F2,[r2 r2a]);
      r2a = r2-1;
      F2a = F2(r2a);
      if F2a<0
         r2a = r2-F2s/(F2s-F2a);
%  Trap some rounding errors at the end
         if F2(r2a)<0
            r2a = r2a-0.1;
         end
      end
      ub1 = fzero(F2,[r2a r2]);
   end          
   return
end
