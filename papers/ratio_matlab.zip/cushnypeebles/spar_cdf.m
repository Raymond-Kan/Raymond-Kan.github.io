function F=spar_cdf(r,theta,thetaW,thetaY,st,s0,t0,order)
%
%  This program computes the SPA of the cdf of R=X/Y
%  Input:
%  r: value of the ratio R=X/Y
%  theta: K_{X,Y}_{1^i,2^j}(\hat{s},\hat{t})/(i!j!), first row is for zero derivative
%  theta_W: K_W^{(i)}(\tilde{s}_0)/i!   first element is for K_W, second element is K_W',
%           third element is K_W''/2!
%  theta_Y: K_Y^{(i)}(\tilde{t}_0)/i!   first element is for K_Y, second element is K_Y',
%           third element is K_Y''/2!
%  st = [\hat{s},\hat{t}]: saddlepoint for K_{X,Y}
%  s0: saddlepoint for K_W
%  t0: saddlepoint for K_Y
%  order: order of saddlepoint approximation
%  Note: The size of theta is (2*order+2)x(2*order+2), the size of thetaW and thetaY
%        is (2*order+2)x1.
%  Output:
%  F = saddlepoint approximation of F_R(r)
%  Note: (1) If theta is an empty matrix, it implies X and Y form a definite pair
%            and the SPA is performed based on a simpler formula.  There are two cases:
%            (i) if Y>0 or Y<0, then thetaY is an empty matrix and t0 stores delta,
%                where delta=0 if Y<0 and delta=1 if Y>0
%            (ii) if W=X-\beta*Y>0 or <0 for lb<=\beta<=ub, then st store [lb ub delta]
%        (2) When X and Y are \bar{X} and \bar{Y} of n independent copies of
%            X and Y.  Use n*theta, n*thetaW, and n*thetaY as input.
%
m = 2*order-1;
h = cumprod(-[1:2:3*m-1]');
H = @(s)(s>=0);
if isempty(theta)
   %
   %  X and Y form a definite pair
   %
   if isempty(thetaY)
      delta = t0;
      if delta==1
         F = H(s0)-spau(s0,thetaW);    % If Y>0, then P[R<r]=P[W<0]
      else
         F = H(-s0)+spau(s0,thetaW);   % If Y<0, then P[R<r]=P[W>0]
      end
   else
      lb = st(1);
      ub = st(2);
      delta = st(3);
      p2 = H(t0)-spau(t0,thetaY);      % P[Y<0]
      if r>=lb&&r<=ub
         if delta==0
            F = p2;                    % If X-beta*Y>0 for lb<=beta<=ub, P[R<r]=P[Y<0] for lb<=r<=ub
         else
            F = 1-p2;                  % If X-beta*Y<0 for lb<=beta<=ub, P[R<r]=P[Y>0] for lb<=r<=ub
         end
      else
         p1 = H(s0)-spau(s0,thetaW);   % P[W<0]
         if r<lb
            F = abs(p1-p2);
         else
            F = min(p1+p2,2-p1-p2);
         end
      end
   end
   return
end
%
%   convert theta for (X,Y) to theta for (W,Y)
%
st = [st(1); st(2)+r*st(1)];   % K_{W,Y}(s,t) = K_{X,Y}(s,t-r*s)
c = ones(1,2*order+2);
for k=1:2*order+1
    for j=max(3,k+1):2*order+2
        theta(j,k) = polyval(fliplr(theta(j,k:j).*c(1:j-k+1)),-r);
    end
    c = cumsum(c(1:end-1));
end
p1 = spau(s0,thetaW);
p2 = spau(t0,thetaY);
p3 = spab(st,theta);
F = (H(s0)-p1)*(1-2*H(st(2)))+(H(t0)-p2)*(1-2*H(st(1)))+2*(H(st(1))*H(st(2))-p3);
F = max(min(F,1),0);

    function p = spau(s,K)
        sK2 = sqrt(2*K(3));
        th = K(4:end)'./sK2.^[3:m+2];
        I = zeros(3*m+1,1);
        u = abs(s)*sK2;
        pdfu = normpdf(u);
        I(1) = 0.5*erfc(u/sqrt(2));
        I(2) = pdfu-u*I(1);
        for i=2:3*m
            if rem(i,2)==0
               I(i+1) = -u*I(i);
            else
               I(i+1) = h(fix(i/2))*pdfu-u*I(i);
            end
        end
        if s<0
           I(1:2:end) = -I(1:2:end);
        end
        d = th;
        p = I(1)+d*I(4:m+3);
        for i=2:m
            for k=m:-1:i
                d(k) = th(1:k-i+1)*d(k-1:-1:i-1)'/i;
            end
            p = p+d(i:m)*I(3*i+1:m+2*i+1);
        end
        pp = exp(0.5*u^2+K(1));
        if isfinite(pp)
           p = pp*p;
        else
           p = sign(p)*exp(0.5*u^2+K(1)+log(abs(p)));
        end
    end

    function p = spab(st,K)
        ds = 2*(st>=0)-1;
        S11 = 2*theta(3,1);
        S12 = theta(3,2);
        S22 = 2*theta(3,3);
        if sum(ds)==0   % one element of ds is 1, the other is -1
           S12 = -S12;
        end
        S = [S11 S12; S12 S22];
        tau = abs(st);
        t = S*tau;
        th = K(4:end,:);
        %
        %   Je(i,j) is jfunc([i-2 j-2]')
        %
        Si = inv(S);
        s1 = sqrt(S11);
        s2 = sqrt(S22);
        rho = S12/(s1*s2);
        ss1 = sqrt(S11-S12^2/S22);
        ss2 = sqrt(S22-S12^2/S11);
        Je = zeros(3*m+1);
%        Je(1,1) = bnorm(-t(1)/s1,-t(2)/s2,rho);
        Je(1,1) = mvncdf([-t(1)/s1 -t(2)/s2],[0 0],[1 rho; rho 1]);
        mu1 = t(1)-S12/S22*t(2);
        Je(1,2) = normpdf(t(2)/s2)*erfc(mu1/ss1/sqrt(2))/(2*s2);
        mu2 = t(2)-S12/S11*t(1);
        Je(2,1) = normpdf(t(1)/s1)*erfc(mu2/ss2/sqrt(2))/(2*s1);
        Je(2,2) = exp(-t'*Si*t/2)/(2*pi*sqrt(det(S)));
        Je(1,3) = (t(2)*Je(1,2)-S12*Je(2,2))/S22;
        Je(3,1) = (t(1)*Je(2,1)-S12*Je(2,2))/S11;
        for j=3:3*m
            Je(2,j) = tau(2)*Je(2,j-1)-(j-3)*Si(2,2)*Je(2,j-2);
            Je(j,2) = tau(1)*Je(j-1,2)-(j-3)*Si(1,1)*Je(j-2,2);
            Je(1,j+1) = (t(2)*Je(1,j)-(j-2)*Je(1,j-1)-S12*Je(2,j))/S22;
            Je(j+1,1) = (t(1)*Je(j,1)-(j-2)*Je(j-1,1)-S12*Je(j,2))/S11;
        end
        for j=3:3*m-1
            k=3:3*m+2-j;
            Je(j,k) = tau(1)*Je(j-1,k)-(j-3)*Si(1,1)*Je(j-2,k)-Si(1,2)*(k-2).*Je(j-1,k-1);
        end
        %
        %   Ie is the ifunc, first row is for |nu|=3, last row
        %   is for |nu|=3*m
        %
        p = Je(1,1)*ds(1)*ds(2);   % I(0)
        ind1 = zeros(3*m+1);
        ind2 = zeros(3*m+1);
        ind1(1,1) = 1;
        ind2(1,1) = 1;
        for j=2:3*m+1
            ind1(1:j,j) = [ind1(1:j-1,j-1); 0]-[0; ind1(1:j-1,j-1)*tau(1)];
            ind2(1:j,j) = [ind2(1:j-1,j-1); 0]-[0; ind2(1:j-1,j-1)*tau(2)];
        end
        Ie = zeros(3*m-2,3*m+1);
        for j=1:3*m-2
            for k=1:j+3
                j1 = j+4-k;
                Ie(j,k) = ind1(1:j1,j1)'*Je(j1:-1:1,k:-1:1)*ind2(1:k,k)*ds(1)^j1*ds(2)^k;
            end
        end
        %
        % a contains a_{r,nu}, where |nu| starts from 3*r to m+2*r
        %
        for r1=1:m
            if r1==1
               a = th;
            else
               %
               % In order to update a(r,nu) from a(r-1,nu), we multiply the matrix a_{r-1,nu}
               % by every element of theta.
               %
               a2 = zeros(m-r1+1,m+2*r1+1);
               for j=1:m-r1+1
                   for k=1:j+3
                       l = min(m+2*r1-k+2,m+2*r1-j-1);
                       a2(j:m-r1+1,k:k+l-1) = a2(j:m-r1+1,k:k+l-1)+th(j,k)*a(1:m-r1-j+2,1:l);
                   end
               end
               a = a2/r1;
            end
            for j=r1:m
                ind = j+2*r1;
                p = p+a(ind-3*r1+1,1:ind+1)*Ie(ind-2,1:ind+1)';
            end
        end
        pp = exp(K(1,1)+0.5*tau'*S*tau);
        if isfinite(pp)
           p = pp*p;
        else
           p = sign(p)*exp(K(1,1)+0.5*tau'*S*tau+log(abs(p)));
        end
    end
end