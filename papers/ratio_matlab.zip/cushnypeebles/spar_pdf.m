function f=spar_pdf(r,theta,thetaW,J,st,s0,order)
%
%  This program computes the SPA of the pdf of R=X/Y
%  Input:
%  r: value of the ratio R=X/Y
%  theta: K_{X,Y}_{1^i,2^j}(\hat{s},\hat{t})/(i!j!), first row is for zero derivative 
%  theta_W: K_W^{(i)}(\tilde{s}_0)/i!   first element is for K_W, second element is K_W', 
%           third element is K_W''/2!
%  st = [\hat{s},\hat{t}]: saddlepoint for K_{X,Y}
%  s0: saddlepoint for K_W
%  w0: sign(s0)*sqrt(-2*K_W(s0))
%  J: J^(i)(0)/i!, where J^(i)(t) = d^k K_2(s,t-r*s)/ds^i evaluated at s=\tilde{s}, first 
%     element is for J(0), second element is for J'(0), 3rd element is for J''(0)/2!   
%  order: order of saddlepoint approximation
%  Note: The size of theta is (2*order+2)x(2*order+2), the size of thetwW is 
%        (2*order+1)x1, the size of J is (2*order-1)x1.
%  Output:
%  f = saddlepoint approximation of f_R(r)
%  Note: (1) If theta is an empty matrix, it implies X and Y form a definite pair
%            and the SPA is performed based on the Geary's formula.
%        (2) When X and Y are \bar{X} and \bar{Y} of n independent copies of
%            X and Y.  Use n*theta, n*thetaW, and n*J as input.
% 
if nargin<7
   order = 1;
end
w0 = sign(s0)*sqrt(-2*thetaW(1));
sK2 = sqrt(2*thetaW(3));
thetaW = thetaW(4:end)./sK2.^[3:2*order]';
J = J./sK2.^[1:2*order-1]';
aa = acoeff(thetaW);
g0 = zeros(order,1);
for j=1:order
    g0(j) = aa(j,1:2*j-1)*J(2*j-1:-1:1);
end
if isempty(theta)
   f = normpdf(w0)*abs(sum(g0));
else
   if order==1
      cutoff = 1e-3;
   elseif order==2
      cutoff = 5e-3;
   else
      cutoff = 5e-2;
   end
   cgfst = theta(1,1);
   tr = st(2)+r*st(1);
   cgfs = -0.5*w0^2;
   w = sign(tr)*sqrt(2*(cgfs-cgfst));
   if ~isreal(w)
      w = 0;
   end
   f = normpdf(w0)*erf(-w/sqrt(2))*sum(g0);
   fac = factorial([0:2*order+1]);
   KK = theta(2:end,:);
   for i=1:2*order+1
       KK(i,1:i+1) = KK(i,1:i+1).*fac(1:i+1).*fliplr(fac(1:i+1));
   end
   detKppr = sqrt(KK(2,1)*KK(2,3)-KK(2,2)^2);
   ht = zeros(2*order,1);
   Jt = zeros(2*order-1,1);
   c = [1 -r]';
   for j=2:2*order
       Jt(j-1) = KK(j,2:j+1)*c;
       c = [c; 0]-[0; r*c];
       ht(j) = KK(j,1:j+1)*c;
   end
   h2t = ht(2);
   sh2t = sqrt(h2t);
   thetat = zeros(2*order-2,1);
   c = 2*h2t;
   for j=3:2*order
       c = c*j*sh2t;
       thetat(j-2) = ht(j)/c;
   end
   if abs(w)>cutoff
      pp = -g0(1)/w;
      for k=2:order
          c = 1/w;
          for j=1:k-1
              pp = pp-c*g0(k-j+1);
              c = c*(1-2*j)/w^2;
          end
          pp = pp-c*g0(1);
      end
   else
      pp = detKppr/h2t;
   end
%
%  gt(k) is g_{k-1}(\hat{t}_r)
%  Not needed for the moment.
%  We need all the derivatives of g_j^{(k)}(\hat{t}_r)
%  as well as all the derivatives of h(t) with h'(t) = J(t).
%  Note that g_0(t) = h'(t)/h2(t)^(1/2), so the derivatives
%  of g_0 are closely related to the derivatives of h'(t).
%
   aat = acoeff(thetat);
   gt = zeros(order,1);
   for j=2:order
       c = 1/sh2t;
       for k=1:2*j-2
           c = c/(k*sh2t);
           gt(j) = gt(j)+c*Jt(k)*aat(j,2*j-k-1);
       end
   end
   f = f+exp(cgfst)*pp/pi;
   if order>1&&abs(w)>cutoff
      pp = 1/detKppr/tr^2;
   end
   if order>2||(order==2&&abs(w)<=cutoff)
      c = KK(2,1)-KK(2,2)*r;
% h_2'(t) and h_2''(t)
      p1t = Jt(2)*h2t-Jt(1)*ht(3);
      c1 = KK(2,1)-KK(2,3)*r^2;
      p2t = Jt(1)^2*KK(4,1)-2*Jt(1)*c1*KK(4,2)+ ...
            (c1^2+2*r*c*Jt(1))*KK(4,3)-2*r*c*c1*KK(4,4)+(r*c)^2*KK(4,5);
      p1pt = KK(3,2)^2-KK(3,1)*KK(3,3)+(KK(3,1)*KK(3,4)-KK(3,2)*KK(3,3))*r+ ...
             (KK(3,3)^2-KK(3,2)*KK(3,4))*r^2+p2t/h2t;
      h2pt = p1t/h2t;
      h2ppt = (p1pt-h2pt^2)/h2t;
% h''(\hat{t}_r) and h'''(\hat{t}_r)
      shpp = detKppr/sh2t;  
      hppp = (-KK(3,1)*Jt(1)^3+3*KK(3,2)*Jt(1)^2*c-3*KK(3,3)*Jt(1)*c^2+KK(3,4)*c^3)/h2t^3; 
% h^(4)(\hat{t}_r)
      term1 = (KK(4,1)*Jt(1)^4-4*KK(4,2)*Jt(1)^3*c+6*KK(4,3)*Jt(1)^2*c^2-4*KK(4,4)*Jt(1)*c^3+KK(4,5)*c^4)/h2t^4;
      term2 = -3*(Jt(1)^2*(KK(3,2)^2-KK(3,1)*KK(3,3))+c*Jt(1)*(KK(3,1)*KK(3,4)-KK(3,2)*KK(3,3))+ ...
              c*c*(KK(3,3)^2-KK(3,2)*KK(3,4)))/h2t^3;
      hpppp = term1+term2-3*h2pt*hppp/h2t;
      theta3 = hppp/shpp^3/6;
      theta4 = hpppp/shpp^4/24;
      if order==2  % singularity case
         pp = theta3*h2pt/(2*sh2t^3)+(5*h2pt^2-2*p1pt)/(8*h2t^2*detKppr) ...
              +(3*thetat(2)-15*thetat(1)^2/2+3/2*theta3^2-theta4)*detKppr/h2t;
      else
         if order>3
            fprintf(' Can only handle up to 3rd order SPA for this case!\n')
            order = 3;
         end
         if abs(w)<cutoff
% Need to make some additional adjustment
            pp = theta3*h2pt/(2*sh2t^3)+(5*h2pt^2-2*p1pt)/(8*h2t^2*detKppr) ...
                 +(3*thetat(2)-15*thetat(1)^2/2+3/2*theta3^2-theta4)*detKppr/h2t;
         else
            u = tr*shpp;
            pp2 = -3*theta3*h2pt/(2*h2t^(3/2))-(5*h2pt^2-2*p1pt)/(8*h2t^2*detKppr) ...
                  +(3*thetat(2)-15*thetat(1)^2/2+3*theta4-15*theta3^2/2)*detKppr/h2t;
            pp3 = -h2pt/sh2t^3-6*theta3*shpp/sh2t;
            pp4 = -3*shpp/sh2t;
            pp = pp+pp2/u^2+pp3/u^3+pp4/u^4;
         end
      end
   end
   if order>1
      f = f+exp(cgfst)*pp/pi;
   end
end

function aa = acoeff(theta)
   m = length(theta);
   if m<=0
      aa = 1;
      return
   end
   h = cumprod(-[1:2:3*m-1]);
   dd = zeros(m);
   dd(1,:) = theta;
   aa = zeros(m/2+1,m+1);
   aa(1:m/2+1,1) = [1 h(1:m/2)]';
   for j=2:m
       for k=j:m
           dd(j,k) = (dd(j-1,k-1:-1:j-1)*theta(1:k-j+1))/j;
       end
       if rem(j,2)==0
          for k=1:j
              aa(j/2+1,k+1) = h(j/2+1:j/2+k)*dd(1:k,k);
          end
       end
   end
