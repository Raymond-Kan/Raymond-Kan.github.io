function [f,info] = spar_pdf(r,theta,thetaW,J,st,s0,order)
%
%  Saddlepoint approximation (SPA) of arbitrary order to the pdf of R = X/Y
%  (Broda & Kan, 2015, Biometrika, and its Supplementary Material, Section 4).
%
%  Input (same conventions as the original spar_pdf.m):
%  r:      value of the ratio R = X/Y
%  theta:  (D+1)x(D+1) matrix with theta(p+1,k+1) = K_{1^{p-k} 2^k}(\hat{s},\hat{t})/((p-k)! k!),
%          i.e., row p+1 holds the p-th order derivatives of K(s,t) at the outer saddlepoint,
%          column k+1 corresponds to k derivatives with respect to t.  The first row is K itself.
%          D must be at least 2*order (2*order+1 for the limit r=r_0 to be computable);
%          extra derivatives (D = 2*order+4 .. 2*order+8 recommended) are used to evaluate the
%          removable singularity at r_0 = -\hat{t}/\hat{s} accurately (see below).
%  thetaW: K_W^{(i)}(\tilde{s}_0)/i!, i=0,1,...  (W = X-rY; at least 2*order+1 elements)
%  J:      J^{(i)}(0)/i!, i=0,1,..., where J(t) = K_2(\tilde{s}(t),t-r\tilde{s}(t)) (at least 2*order-1 elements)
%  st:     [\hat{s},\hat{t}], outer saddlepoint, K_1(\hat{s},\hat{t}) = K_2(\hat{s},\hat{t}) = 0
%  s0:     inner saddlepoint for t=0, K_1(s0,-r*s0) - r K_2(s0,-r*s0) = 0
%  order:  order m of the SPA (error O(n^{-m}) when applied to means of n copies)
%
%  Output:
%  f:      m-th order SPA of f_R(r)
%  info:   structure with the pieces: g0(j+1) = g_j(0), A(J+1) = A_J, w0, w, tr = \hat{t}_r,
%          branch (1 = direct, 2 = regularized) for each A_J.
%
%  Notes:
%  (1) If theta is empty, X and Y form a definite pair and f = phi(w0)|sum_j g_j(0)| (Daniels' formula).
%  (2) For means of n copies use n*theta, n*thetaW and n*J as inputs.
%  (3) The approximation is
%         f = phi(w0) {1-2 Phi(w)} sum_{j<m} g_j(0) + 2 phi(w0) phi(w) sum_{J<m} A_J,
%      with A_J = sum_{q=0}^{J} (-1)^q (2q-1)!! [Psi_{J-q}]_{2q}, where [.]_l is the l-th Taylor
%      coefficient about w = \hat{w} of Psi_j(w) = g_j(t(w)) t'(w)/t(w) - g_j(0)/w and the map t <-> w is
%      defined by h(t) - h(0) = w^2/2 - \hat{w} w  (h(t) = K(\tilde{s}(t), t - r\tilde{s}(t))).
%      Psi_j is analytic at w = 0, so A_J is continuous through r_0.  For |w| below a cutoff the
%      Taylor coefficients are computed by a regularized (top-down) division which is exact at r_0 and
%      has truncation error O(w^(D-2*order)) nearby; otherwise by direct series division.
%
if nargin<7
   order = 1;
end
m = order;
Jmax = m-1;
%
%  g_j(0), j=0..m-1, from thetaW and J (inner Laplace expansion at t=0)
%
hk = thetaW(1:2*m+1); hk = hk(:)';          % K_W^{(k)}(s0)/k!, k=0..2m
Jk = J(1:2*m-1);      Jk = Jk(:)';          % J^{(k)}(0)/k!,   k=0..2m-2
g0 = laplace_coeffs(hk,Jk,Jmax,0);          % row vector, g0(j+1) = g_j(0)
w0 = sign(s0)*sqrt(-2*thetaW(1));
if isempty(theta)
   f = normpdf(w0)*abs(sum(g0));
   info = struct('g0',g0,'w0',w0);
   return
end
D = size(theta,1)-1;
if D<2*m
   error('theta must contain derivatives up to order 2*order (preferably 2*order+4 or more).');
end
Lextra = D-2*m;
%
%  convert the program layout theta(p+1,k+1) to TH(i+1,j+1) = K_{1^i 2^j}/(i!j!)
%
TH = zeros(D+1);
for p=0:D
    for k=0:p
        TH(p-k+1,k+1) = theta(p+1,k+1);
    end
end
tr = st(2)+r*st(1);                         % \hat{t}_r
cgfst = theta(1,1);                         % h(\hat{t}_r) = K(\hat{s},\hat{t})
cgfs = -0.5*w0^2;                           % h(0) = K_W(s0)
w = sign(tr)*sqrt(max(2*(cgfs-cgfst),0));   % \hat{w}
%
%  Taylor series (in delta = t - \hat{t}_r) of h(t) and g_j(t) at the outer saddlepoint
%
Ld = 2*Jmax+Lextra;
[h,g] = inner_series(TH,r,Jmax,Ld);
%
%  outer coefficients A_J: direct evaluation and regularized (top-down) evaluation.
%  The direct evaluation suffers from cancellation when t_hat_r is small; its rounding
%  sensitivity est_dir is estimated by perturbing its small inputs (w, t_hat_r, g_j(0)) by an
%  amplified machine epsilon.  The regularized evaluation is used whenever the two evaluations
%  disagree by less than est_dir (i.e. whenever the direct one cannot be trusted at that level).
%
L = 2*Jmax+Lextra;
if abs(w)>0
   Adir = outer_coeffs(h,g,g0,tr,w,Jmax,L,false);
else
   Adir = NaN(1,Jmax+1);
end
dl = 1e-12;                                  % perturbation (machine epsilon x 1e4)
dw = dl*abs(cgfst)/abs(w);                   % modelled rounding in w (x 1e4)
dt = dl*abs(st(2));                          % modelled rounding in t_hat_r (x 1e4)
if abs(w)>0 && dw<1e-2*abs(w) && dt<1e-2*abs(tr)
   gsc = max(abs(g(:,1:2*Jmax+1)),[],2)';
   Ap = outer_coeffs(h,g,g0+dl*gsc,tr+dt,w+dw,Jmax,L,false);
   est_dir = abs(Ap-Adir)*(2.2e-16/dl)*10;
else
   est_dir = Inf(1,Jmax+1);
end
if Lextra>=1
   Areg = outer_coeffs(h,g,g0,tr,w,Jmax,L,true);
else
   Areg = NaN(1,Jmax+1);
end
A = zeros(1,Jmax+1);
branch = zeros(1,Jmax+1);
for JJ=0:Jmax
    if Lextra<1
       A(JJ+1) = Adir(JJ+1); branch(JJ+1) = 1;
       if ~isfinite(est_dir(JJ+1)) || est_dir(JJ+1)>1e-6*abs(Adir(JJ+1))
          warning('spar_pdf:nearR0','t_hat_r is small and theta has no extra derivatives; A_%d may be inaccurate.',JJ);
       end
    elseif ~isfinite(Adir(JJ+1)) || est_dir(JJ+1)>=abs(Adir(JJ+1)-Areg(JJ+1))
       A(JJ+1) = Areg(JJ+1); branch(JJ+1) = 2;
    else
       A(JJ+1) = Adir(JJ+1); branch(JJ+1) = 1;
    end
end
f = normpdf(w0)*((1-2*normcdf(w))*sum(g0)+2*normpdf(w)*sum(A));
info = struct('g0',g0,'A',A,'w0',w0,'w',w,'tr',tr,'branch',branch,'Lextra',Lextra,'est_dir',est_dir);
end

% =====================================================================================
function [h,g] = inner_series(TH,r,Jmax,Ld)
%  Taylor coefficients in delta = t - t* of h(t) = K(s(t),t-r s(t)) and of g_j(t), j=0..Jmax,
%  at a point (s*,t*) on the inner saddlepoint curve K_1 - r K_2 = 0.
%  TH(i+1,j+1) = K_{1^i 2^j}(s*,t*)/(i! j!).
D = size(TH,1)-1;
% rotate: Kt(p+1,k+1) = coefficient of sig^p del^k in K(s*+sig, t*+del-r*sig)
Kt = zeros(D+1);
for i=0:D
    for j=0:D-i
        if TH(i+1,j+1)~=0
           for k=0:j
               Kt(i+j-k+1,k+1) = Kt(i+j-k+1,k+1)+TH(i+1,j+1)*nchoosek(j,k)*(-r)^(j-k);
           end
        end
    end
end
Lh = min(Ld+2,D);
K1 = bdx(Kt,1);
K2 = bdx(Kt,2);
% saddle curve sigma(delta): d/dsig Kt = 0, Newton iteration on truncated series
sig = zeros(1,Lh+1);
for it=1:Lh+2
    F = bcompose(K1,sig,Lh); F(1) = 0;
    Fp = bcompose(K2,sig,Lh);
    corr = sdiv(F,Fp,Lh);
    sig = sig-corr;
    if all(corr==0), break, end
end
h = bcompose(Kt,sig,Lh);
kmax = 2*Jmax+2;
ht = cell(1,kmax+1); Jt = cell(1,kmax+1);
Kd = bdy(Kt,1);
for k=0:kmax
    ht{k+1} = bcompose(bdx(Kt,k),sig,Ld);
    Jt{k+1} = bcompose(bdx(Kd,k),sig,Ld);
end
g = laplace_coeffs_series(ht,Jt,Jmax,Ld);
end

% -------------------------------------------------------------------------------------
function g = laplace_coeffs(hk,Jk,Jmax,Ld)
%  scalar version: hk(k+1) = h_k/k!, Jk(k+1) = J_k/k!
kmax = 2*Jmax+2;
ht = cell(1,kmax+1); Jt = cell(1,kmax+1);
for k=0:kmax
    if k+1<=length(hk), ht{k+1} = hk(k+1)*factorial(k); else, ht{k+1} = 0; end
    if k+1<=length(Jk), Jt{k+1} = Jk(k+1)*factorial(k); else, Jt{k+1} = 0; end
end
g = laplace_coeffs_series(ht,Jt,Jmax,Ld);
g = g(:,1)';
end

function g = laplace_coeffs_series(ht,Jt,Jmax,Ld)
%  Laplace expansion coefficients g_j (series in delta, order Ld) of
%  sqrt(n)/(2 pi i) int exp(n[H(s)-H(s*)]) G(s) ds ~ (2 pi)^{-1/2} sum_j g_j n^{-j},
%  H(s*+a) - H(s*) = sum_{k>=2} ht_k a^k/k!,  G(s*+a) = sum_k Jt_k a^k/k!   (ht_k, Jt_k series in delta).
%  g_j = sum_{r=0}^{2j} (-1)^{j+r} (2j+2r-1)!! E_{r,2j+2r} ht_2^{-(j+r+1/2)},  E_{r,l} = [G P^r/r!]_l,
%  P(a) = sum_{k>=3} ht_k a^k/k!.
amax = 6*Jmax;
G = zeros(amax+1,Ld+1); P = zeros(amax+1,Ld+1);
kmax = length(ht)-1;
for k=0:min(amax,kmax)
    G(k+1,:) = pad(Jt{k+1},Ld)/factorial(k);
    if k>=3
       P(k+1,:) = pad(ht{k+1},Ld)/factorial(k);
    end
end
h2 = pad(ht{3},Ld);
Pr = zeros(amax+1,Ld+1); Pr(1,1) = 1;
E = cell(1,2*Jmax+1);
E{1} = bmul(G,Pr,amax,Ld);
for rr=1:2*Jmax
    Pr = bmul(Pr,P,amax,Ld)/rr;
    E{rr+1} = bmul(G,Pr,amax,Ld);
end
g = zeros(Jmax+1,Ld+1);
for j=0:Jmax
    for rr=0:2*j
        l = 2*j+2*rr;
        c = (-1)^(j+rr)*dfact2(j+rr);
        g(j+1,:) = g(j+1,:)+c*smul(E{rr+1}(l+1,:),spow(h2,-(j+rr+0.5),Ld),Ld);
    end
end
end

% -------------------------------------------------------------------------------------
function A = outer_coeffs(h,g,g0,tr,w,Jmax,L,regularized)
%  A_J = sum_q (-1)^q (2q-1)!! [Psi_{J-q}]_{2q}(w_hat), using
%  Psi_j(w(t)) = [Delta_j(t) - g_j(0) (log(w(t)/t))'] / w'(t),  Delta_j(t) = (g_j(t)-g_j(0))/t,
%  w(t) = w_hat + V(delta), V(delta) = delta*sqrt(Q(delta)), Q = 2(h(t)-h(t_hat_r))/delta^2,
%  re-expanded in v = w - w_hat through delta = tau(v), the inverse series of V.
h = pad(h,L+3);
q = 2*h(3:L+3);                              % Q(delta), order L
V = [0 spow(q,0.5,L)];                       % V(delta), order L+1
tau = srevert(V,L+1);                        % delta = tau(v)
wV = V; wV(1) = w;                           % w(t) as series in delta
if regularized
   omega = topdown_div(wV,tr);               % w/t  (exact divisibility by delta+tr assumed)
else
   omega = smul(wV,sinv([tr 1],L+1),L+1);
end
Lam = sdiv(sderiv(omega),omega,L);           % (log(w/t))'
inv_dw = sinv(sderiv(V),L);                  % 1/w'(t)
A = zeros(1,Jmax+1);
psi = zeros(Jmax+1,L+1);
for j=0:Jmax
    gj = pad(g(j+1,:),L); gj(1) = gj(1)-g0(j+1);
    if regularized
       Delta = topdown_div(gj,tr);
    else
       Delta = smul(gj,sinv([tr 1],L),L);
    end
    Psi_t = smul(Delta-g0(j+1)*Lam,inv_dw,L);
    psi(j+1,:) = scompose(Psi_t,tau,L);
end
for JJ=0:Jmax
    for qq=0:JJ
        A(JJ+1) = A(JJ+1)+(-1)^qq*dfact2(qq)*psi(JJ-qq+1,2*qq+1);
    end
end
end

function M = topdown_div(N,c)
%  Divide polynomial N(x) by (x + c) assuming exact divisibility, from the top coefficient down
%  (no division by c; stable for small c; exact for c = 0).  Returns quotient padded to length(N).
L = length(N)-1;
M = zeros(1,L+1);
M(L) = N(L+1);
for l=L-1:-1:1
    M(l) = N(l+1)-c*M(l+1);
end
end

% ============================ truncated power series tools ============================
function a = pad(a,L)
a = a(:)';
if length(a)>=L+1
   a = a(1:L+1);
else
   a = [a zeros(1,L+1-length(a))];
end
end

function c = smul(a,b,L)
c = conv(a,b);
c = pad(c,L);
end

function b = sinv(a,L)
a = pad(a,L);
b = zeros(1,L+1);
b(1) = 1/a(1);
for k=1:L
    b(k+1) = -(a(2:k+1)*b(k:-1:1).')/a(1);
end
end

function c = sdiv(a,b,L)
c = smul(pad(a,L),sinv(b,L),L);
end

function c = spow(a,alpha,L)
%  a^alpha, a(1) > 0
a = pad(a,L);
c = zeros(1,L+1);
c(1) = a(1)^alpha;
for k=1:L
    s = 0;
    for j=1:k
        s = s+(alpha*j-(k-j))*a(j+1)*c(k-j+1);
    end
    c(k+1) = s/(k*a(1));
end
end

function d = sderiv(a)
L = length(a)-1;
if L<1, d = 0; return, end
d = (1:L).*a(2:end);
end

function c = scompose(f,g,L)
%  f(g(x)), g(1) = 0
f = pad(f,L); g = pad(g,L);
c = zeros(1,L+1);
for k=L+1:-1:1
    c = smul(c,g,L);
    c(1) = c(1)+f(k);
end
end

function tau = srevert(V,L)
%  inverse series: V(tau(v)) = v, V(1)=0, V(2)~=0
V = pad(V,L);
tau = zeros(1,L+1); tau(2) = 1/V(2);
dV = sderiv(V);
for it=1:L+2
    Vt = scompose(V,tau,L); Vt(2) = Vt(2)-1;
    dVt = scompose(pad(dV,L),tau,L);
    corr = sdiv(Vt,dVt,L);
    tau = tau-corr;
    if all(corr==0), break, end
end
end

function C = bmul(A,B,P,Lq)
%  product of bivariate series (rows: x-degree, columns: y-degree), truncated
C = conv2(A,B);
C = C(1:min(end,P+1),1:min(end,Lq+1));
if size(C,1)<P+1 || size(C,2)<Lq+1
   C(P+1,Lq+1) = 0;                         % pad with zeros
end
end

function c = bcompose(A,g,Lq)
%  A(g(y),y), g univariate series in y with g(1)=0 -> univariate series in y of order Lq
P = size(A,1)-1;
c = zeros(1,Lq+1);
gp = zeros(1,Lq+1); gp(1) = 1;
g = pad(g,Lq);
for p=0:P
    c = c+smul(gp,pad(A(p+1,:),Lq),Lq);
    gp = smul(gp,g,Lq);
end
end

function B = bdx(A,k)
P = size(A,1)-1;
if P-k<0, B = zeros(1,size(A,2)); return, end
B = zeros(P-k+1,size(A,2));
for p=k:P
    B(p-k+1,:) = A(p+1,:)*(factorial(p)/factorial(p-k));
end
end

function B = bdy(A,k)
Lq = size(A,2)-1;
if Lq-k<0, B = zeros(size(A,1),1); return, end
B = zeros(size(A,1),Lq-k+1);
for q=k:Lq
    B(:,q-k+1) = A(:,q+1)*(factorial(q)/factorial(q-k));
end
end

function d = dfact2(k)
%  (2k-1)!!
d = prod(1:2:2*k-1);
end
