clear
vhat = [1.9 0.8 1.1  0.1 -0.1  4.4 5.5 1.6 4.6 3.4]';
uhat = [0.7  -1.6 -0.2 -1.2 -.1 3.4 3.7  0.8  0.0  2.0]';
n = length(uhat);
rvec = [-0.6:0.2:.6];
[def,delta,lb1,ub1,lb2,ub2] = defpair(uhat,vhat);
[~,cdf0] = cauchyg2(rvec,sum(uhat),sum(vhat),var(uhat)*n,var(vhat)*n,corr(uhat,vhat));
cdf1 = brspacdf(rvec,uhat,vhat,1);
[tsls,p] = bootrat([uhat vhat]);
xCDF = [-Inf; tsls; Inf];
yCDF = [0; cumsum(p); 1];
cdf=linterp(xCDF,yCDF,rvec);
[cdf' cdf0' cdf1' (cdf0'-cdf')./min(cdf',1-cdf') (cdf1'-cdf')./min(cdf',1-cdf')]
 