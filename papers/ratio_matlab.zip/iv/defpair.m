function [def,delta,lb1,ub1,lb2,ub2] = defpair(z,u,v,pi0,wild)
%
%  This function checks if z'u and pi0*z'z+z'v form a definite pair
%  When they form a definite pair, the function delta = 0/1 such that
%  P[z'u-r*(pi0*z'z+z'v)<0]=delta for lb<=r<=ub, so delta=0 means it is
%  a positive random variable, and delta=1 means it is a negative 
%  random variable.
%
def = false;
delta = NaN;
lb1 = -Inf;
ub1 = Inf;
lb2 = NaN;
ub2 = NaN;
zzp = pi0*z'*z;
%
%   First check the denominator  
%
if wild
   absz = abs(z);
   F1 = @(r) absz'*abs(u-r*v)+r*zzp;  % negative of the minimum value
   F2 = @(r) absz'*abs(u-r*v)-r*zzp;  % maximum value
   m0 = absz'*abs(v);
   m = zzp-m0;  % minimum value of denominator
   M = zzp+m0;  % maximum value of denominator
else
   z1 = sum(z(z<0));
   z2 = sum(z(z>0));
   F1 = @(r) -z1*max(u-r*v)-z2*min(u-r*v)+r*zzp; % negative of the minimum value
   F2 = @(r) z1*min(u-r*v)+z2*max(u-r*v)-r*zzp;  % maximum value
   minv = min(v);
   maxv = max(v);
   m = zzp+maxv*z1+minv*z2;  % minimum value of denominator
   M = zzp+minv*z1+maxv*z2;  % maximum value of denominator
end
if m>=0||M<=0
   def = true;
   delta = double(m>=0);
   F1a = fzero(F1,0);
   F2a = fzero(F2,0);
   if F1a<F2a
      lb1 = F1a;
      ub1 = F2a;
   else
      lb1 = F2a;
      ub1 = F1a;
   end   
   return
end
%
%  Find out if any r will make z'u-r(pi0*z'z+z'v) to be a 
%  positive or negative random variable
%
[r1,F1s] = fminsearch(F1,0);
if F1s<=0
   def = true;
   delta = 0;
   ub2 = Inf;
   if F1s<0
      r1a = r1+1;
      F1a = F1(r1a);
      if F1a<0
         r1a = r1+2*F1s/(F1s-F1a);
      end
      lb2 = fzero(F1,[r1 r1a]);
      r1a = r1-1;
      F1a = F1(r1a);
      if F1a<0
         r1a = r1-2*F1s/(F1s-F1a);
      end
      ub1 = fzero(F1,[r1a r1]);
   end          
   return
end
[r2,F2s] = fminsearch(F2,0);
if F2s<=0
   def = true;
   delta = 1;
   ub2 = Inf;
   if F2s<0
      r2a = r2+1;
      F2a = F2(r2a);
      if F2a<0
         r2a = r2+2*F2s/(F2s-F2a);
      end
      lb2 = fzero(F2,[r2 r2a]);
      r2a = r2-1;
      F2a = F2(r2a);
      if F2a<0
         r2a = r2-2*F2s/(F2s-F2a);
      end
      ub1 = fzero(F2,[r2a r2]);
   end          
   return
end
