function figure2
close all
hetero=1;% set to 1 for heteroskedastik DGP
beta0=0;%H0
ovid=0;% degree of overidentification
B=399;%number of bootstrap samples
numsim=100000;%number of simulations for monte carlo
filename='figure2.eps'
set(0,'DefaulttextInterpreter','latex')
ha = tight_subplot(2,2,[.1 0.07],[0.15 0.1],[0.15 0.1]);
if exist(['data_for_' filename '.mat']),
    load(['data_for_' filename '.mat']);
    printonly=1;
else
    printonly=0;
end
% Scenarios to simulate for top left panel
% T   rho   pi  beta
scenarios=[
    25     .9   2    0;
    50     .9   2    0;
    100    .9   2    0;
    150    .9   2    0;
    200    .9   2    0;
    250    .9   2    0;
    300    .9   2    0;
    350    .9   2    0;
    400    .9   2    0;
    ]
% n is sample size, rho is endogeneity, pi is instrument strength,
% beta is true beta (for DGP),
labelafter=1;%which column of scenarios to use as xlabel in plot. use 5 to use row number
axes(ha(1));
dolegend=1
if printonly
    sizes=sizes_topleft;
    simulate
else
    rng(0)
    simulate;
    sizes_topleft=sizes;
end

% Scenarios to simulate for top right panel
% T   rho   pi  beta
scenarios=[
    25     .1   2    0;
    50     .1   2    0;
    100    .1   2    0;
    150    .1   2    0;
    200    .1   2    0;
    250    .1   2    0;
    300    .1   2    0;
    350    .1   2    0;
    400    .1   2    0;
    ]
labelafter=1;
axes(ha(2));
dolegend=0
if printonly
    sizes=sizes_topright
    simulate
else
    rng(0)
    simulate;
    sizes_topright=sizes;
end

% Scenarios to simulate for bottom left panel
% T   rho   pi  beta
scenarios=[
    25     .9   8    0;
    50     .9   8    0;
    100    .9   8    0;
    150    .9   8    0;
    200    .9   8    0;
    250    .9   8    0;
    300    .9   8    0;
    350    .9   8    0;
    400    .9   8    0;
    ]
labelafter=1;
axes(ha(3));
dolegend=0
if printonly
    sizes=sizes_bottomleft
    simulate
else
    rng(0)
    simulate;
    sizes_bottomleft=sizes;
end

% Scenarios to simulate for bottom right panel
% T   rho   pi  beta
scenarios=[
    25     .1   8    0;
    50     .1   8    0;
    100    .1   8    0;
    150    .1   8    0;
    200    .1   8    0;
    250    .1   8    0;
    300    .1   8    0;
    350    .1   8    0;
    400    .1   8    0;
    ]
labelafter=1;
axes(ha(4));
dolegend=0
if printonly
    sizes=sizes_bottomright
    simulate
else
    rng(0)
    simulate;
    sizes_bottomright=sizes;
end
set(gcf,'PaperUnits','inches')
set(gcf,'PaperPosition',[0 0 8.5 8.5]);
set(gcf,'color','none','inverthardcopy','off')
save(['data_for_' filename '.mat'], 'sizes_topleft', 'sizes_topright', 'sizes_bottomleft', 'sizes_bottomright')
print(gcf, '-depsc2', filename )
eps = fileread(filename);
fd = fopen(filename, 'wt');
fwrite(fd, eps);
fclose(fd);
system(['epstopdf ' filename]);



    function simulate
        if printonly==0
            numscen=size(scenarios,1);
            scenarios=[scenarios [1:numscen]'];
            nmax=max(scenarios(:,1));
            pvals=zeros(numsim,numscen,2+(ovid==0));%can only do SPA in just identified case
            DDmax=binornd(1,.5,B,nmax)*2-1;%let's keep those fixed
            h = waitbar(0,'Simulating...');
            for sim=1:numsim
                waitbar(sim/numsim);
                %do this outside the loop over a; using common random numbers makes the
                %plot smoother
                w1max = randn(nmax,1);
                u1max = randn(nmax,1);%structural error
                u2max = randn(nmax,1);% reduced form error
                
                for sloop=1:numscen
                    n=scenarios(sloop,1);
                    rho=scenarios(sloop,2);
                    pi=scenarios(sloop,3);
                    beta=scenarios(sloop,4);
                    DD=DDmax(:,1:n);
                    w1=w1max(1:n);
                    u1=u1max(1:n);
                    u2=u2max(1:n);
                    Z = ones(n,1);
                    Pz=Z*inv(Z'*Z)*Z';
                    Mz = eye(n)-Pz;
                    w1=w1/norm(w1);
                    k = size(Z,2);
                    l=k+1+ovid;
                    
                    if hetero
                        u=sqrt(n)*abs(w1).*u1;
                    else
                        u=u1;
                    end
                    
                    v=rho*u+sqrt(1-rho^2)*u2;
                    W=[w1 Z randn(n,l-2)];
                    Pw=W*inv(W'*W)*W';
                    Mw=eye(n)-Pw;
                    Pwz=(Pw-Pz);
                    
                    y2 = w1*pi+v;
                    y1 = y2*beta+u;
                    betahat=y1'*Pwz*y2/(y2'*Pwz*y2);
                    u1hat0 = Mz*(y1-y2*beta0)*sqrt(n/(n-k));
                    u1hat = Mz*(y1-y2*betahat);
                    XX = [W u1hat0];
                    pihatDM = XX\y2;pihatDM=pihatDM(1:end-1);
                    u2hat0 = (y2-W*pihatDM)*sqrt(n/(n-l));
                    %s1=norm(u1hat)/sqrt(n);
                    %t=(betahat-beta0)*norm(Pwz*y2)/s1%note the typo in D&M. this gives the same as eviews (except that Eviews uses a d.f. correction)
                    sh=sqrt(u1hat.^2'*(Pwz*y2).^2)/norm(Pwz*y2)^2;
                    th=(betahat-beta0)/sh;%this uses White standard errors (w/o d.o.f correction).
                    %tB=zeros(B,1);
                    thB=zeros(B,1);
                    betahatB=zeros(B,1);
                    for boot=1:B
                        D=DD(boot,:)';
                        u1B=u1hat0.*(D);
                        u2B=u2hat0.*(D);
                        y2B=w1*pihatDM(1)+u2B;
                        y1B=beta0*y2B+u1B;
                        betahatB(boot)=y1B'*Pwz*y2B/(y2B'*Pwz*y2B);
                        u1hatB = Mz*(y1B-y2B*betahatB(boot));
                        %s1B=norm(u1hatB)/sqrt(n);
                        %tB(boot)=(betahatB(boot)-beta0)*norm(Pwz*y2B)/s1B;
                        shB=sqrt(u1hatB.^2'*(Pwz*y2B).^2)/norm(Pwz*y2B)^2;
                        thB(boot)=(betahatB(boot)-beta0)/shB;%this uses White standard errors (w/o d.o.f correction).
                    end
                    pvals(sim,sloop,1)=2*min(mean(thB<th),mean(thB>th));
                    pvals(sim,sloop,2)=2*min(mean(betahatB<betahat),mean(betahatB>betahat));
                    if ovid==0,%can only do this in the just identified case
                        cdf1 = ivspacdf(betahat,beta0,pihatDM(1),Mz*w1,u1hat0,u2hat0,1,1);
                        pvals(sim,sloop,3)=2*min(cdf1,1-cdf1);
                    end
                end
            end
            
            sizes=mean(pvals<.05,1);
            close(h);
        end
        avec=scenarios(:,labelafter);
        
        plot(avec,sizes(1,:,2),'b');
        hold on
        if ovid==0
            plot(avec,sizes(1,:,3),'r--');
        end
        plot(avec,sizes(1,:,1),'m:','Linewidth',1.75)
        hold off
        labels=cell(4,1);
        labels{1}='$T$';
        labels{2}='$\rho$';
        labels{3}='$\pi$';
        labels{4}='$\beta$';
        labels{5}='Scenario No.';
        thetitle=[];
        
        if labelafter~=5
            for i=2:3
                if i~=labelafter,
                    thetitle=[thetitle labels{i} '=' num2str(scenarios(1,i)) ', '];
                end;
            end
        end
        thetitle=thetitle(1:end-2);
        if dolegend
            h=legend('D{\&}M WRE','SPA','D{\&}M WRE $t$','Location','NorthWest');
            set(h,'Interpreter','latex','FontSize',7);
        end
        xlabel(labels{labelafter},'FontSize',12),ylabel('pr(reject)','FontSize',12);
        title(thetitle,'FontSize',12);
        hold on
        plot(avec,avec*0+.05,'k:');
        hold off
        axis([min(avec) max(avec) 0 0.1]);
        set(gca,'box','off','TickDir','out','FontSize',10,'XTick',[avec],'Ytick',[0:.01:0.1]);
        set(gca,'color','none');
    end
end
