function F=ivspacdf(rvec,beta0,pi0,z,u,v,wild,order)
%
%  This program computes the saddlepoint approximation of
%  the cdf of the IV estimator of the model
%  y = x*beta0+u
%  x = z*pi0+v
%  order: order of saddlepoint approximation
%  Use wild=true to use the wild bootstrap instead of iid%
%
rvec = rvec-beta0;
zzp = pi0*z'*z;
F = zeros(size(rvec));
[def,delta,lb1,ub1,lb2,ub2] = defpair(z,u,v,pi0,wild);
%[def] = defpair(z,u,v,pi0,wild)
if def
% Positive or negative denominator, Y<0: delta=0, Y>0: delta=1
   if isnan(lb2)
      for i=1:numel(rvec)
          if rvec(i)>=ub1
             F(i) = 1;
          elseif rvec(i)>lb1
             if wild 
                [thetaW,s0] = cumu1w(z,u-rvec(i)*v,-rvec(i)*zzp,order);
             else
                [thetaW,s0] = cumu1(z,u-rvec(i)*v,-rvec(i)*zzp,order);
             end
             F(i) = spar_cdf(rvec(i),[],thetaW,[],[],s0,delta,order);
          end
      end
   else
%
%  If there are holes in the support of R, then X and Y form a 
%  definite pair.
%
      if wild 
         [thetaY,t0] = cumu1w(z,v,zzp,order);
      else
         [thetaY,t0] = cumu1(z,v,zzp,order);
      end
      for i=1:numel(rvec)
          r = rvec(i);
          if r<ub1||r>lb2
             if wild 
                [thetaW,s0] = cumu1w(z,u-rvec(i)*v,-rvec(i)*zzp,order);
             else
                [thetaW,s0] = cumu1(z,u-rvec(i)*v,-rvec(i)*zzp,order);
             end
             F(i) = spar_cdf(rvec(i),[],thetaW,thetaY,[ub1 lb2 delta],s0,t0,order);
          else
             F(i) = spar_cdf(rvec(i),[],[],thetaY,[ub1 lb2 delta],[],t0,order);  % P[Y<0]
          end
      end
   end       
   return
end 
if wild
   [thetaY,t0] = cumu1w(z,v,zzp,order);
   lnh = -0.69314718055994531;  % ln(1/2)
   zu = z.*u;
   zv = z.*v; 
   zu2 = zu.*zu;
   zv2 = zv.*zv;
   zuv = zu.*zv;
   zzp1 = zzp-sum(zv);
   szu = sum(zu);
   st = fsolve(@cgfgradw,[0 0],optimset('disp','off','Jacobian','on','TolX',1e-10,'TolFun',1e-12))';
   theta = Kderw(st(1),st(2),z,u,v,zzp,2*order+2);
else
   [thetaY,t0] = cumu1(z,v,zzp,order);
   zu = z*u';
   zv = z*v';
   zu2 = zu.*zu;
   zv2 = zv.*zv;
   zuv = zu.*zv;
   st = fsolve(@cgfgrad,[0 0],optimset('disp','off','Jacobian','on','TolX',1e-10,'TolFun',1e-12))';
   theta = Kder(st(1),st(2),z,u,v,zzp,2*order+2);
end
for i=1:numel(rvec)
    if wild
       [thetaW,s0] = cumu1w(z,u-rvec(i)*v,-rvec(i)*zzp,order);
    else
       [thetaW,s0] = cumu1(z,u-rvec(i)*v,-rvec(i)*zzp,order);
    end
    F(i) = spar_cdf(rvec(i),theta,thetaW,thetaY,st,s0,t0,order);
end

function [grad,J]=cgfgrad(t)
% Gradient and Jacobian of the joint cumulant generating function of X1 and X2
   Q = exp(z*(t(1)*u+t(2)*v)');
   sQ = sum(Q,2);
   Q1 = Q.*zu;
   Q2 = Q.*zv;
   q1 = sum(Q1,2)./sQ;
   q2 = sum(Q2,2)./sQ;
   grad = [sum(q1) sum(q2)+zzp];
   K11 = sum(sum(Q1.*zu,2)./sQ)-q1'*q1;
   K12 = sum(sum(Q1.*zv,2)./sQ)-q1'*q2;
   K22 = sum(sum(Q2.*zv,2)./sQ)-q2'*q2;
   J = [K11 K12; K12 K22];
end

function [grad,J]=cgfgradw(t)
% Gradient and Jacobian of the joint cumulant generating function of X1 and X2
   w = 1./(1+exp(-2*(t(1)*zu+t(2)*zv)));
   grad = [-szu+2*zu'*w zzp1+2*zv'*w];
   w1 = w.*w;
   K11 = 4*zu2'*(w-w1);
   K12 = 4*zuv'*(w-w1);
   K22 = 4*zv2'*(w-w1);
   J = [K11 K12; K12 K22];
end

end

function [K,t] = cumu1(z,v,zzp,order)
%
%   This function computes the saddlepoint and cumulants for
%   z'*v+zzp, 
%
n = length(z);
m = 2*order+2;
zv = z*v';
options = optimset('Display','off','TolX',1e-12);
t = fzero(@saddlept,0,options);
Q = exp(t*zv);
sQ = sum(Q,2);
F = zeros(n,m);
F(:,1) = sQ;
c = 1;
for i=2:m
    c = c*(i-1);
    Q = Q.*zv;
    F(:,i) = sum(Q,2)./sQ/c;
end
R = F;
for i=3:m
    for j=2:i-1
        R(:,i) = R(:,i)-(j-1)/(i-1)*R(:,j).*F(:,i-j+1);
    end
end
K = zeros(m,1);
K(1) = t*zzp+sum(log(R(:,1)/n));
K(3:m) = sum(R(:,3:m));

function y = saddlept(t)
   Q = exp(t*zv);
   y = sum(sum(Q.*zv,2)./sum(Q,2))+zzp;
end
end

function K = Kder(s,t,z,u,v,zzp,m)
n = length(z);
zu = z*u';
zv = z*v';
Q = exp(s*zu+t*zv);
sQ = sum(Q,2);
F = zeros(n,m*(m+1)/2);
F(:,1) = sQ;
count = 1;
fac = cumprod([1 1:m-1]);
for i=2:m
    for j=1:i
        k1 = i-j;
        k2 = j-1;
        count = count+1;
        F(:,count) = sum(Q.*(zu.^k1.*zv.^k2),2)./sQ/fac(k1+1)/fac(j);
    end
end
R = F;
ind = @(i,j)(i-1)*i/2+j;
for i=3:m
    ind1 = ind(i,1);
    ind2 = ind(i,i);
    for j=2:i-1
        R(:,ind1) = R(:,ind1)-(j-1)/(i-1)*R(:,ind(j,1)).*F(:,ind(i-j+1,1));
        R(:,ind2) = R(:,ind2)-(j-1)/(i-1)*R(:,ind(j,j)).*F(:,ind(i-j+1,i-j+1));
    end
    for j=2:i-1
        ind1 = ind(i,j);
        for i1=0:i-j
            for i2=double(i1==0):j-2
                R(:,ind1) = R(:,ind1)-(1-i2/(j-1))*R(:,ind(i-i1-i2,j-i2)).*F(:,ind(i1+i2+1,i2+1));
            end
        end
    end
end
K = zeros(m);
K(1,1) = t*zzp+sum(log(R(:,1)/n));
for i=2:m
    K(i,1:i) = sum(R(:,i*(i-1)/2+[1:i]));
end
K(2,2) = K(2,2)+zzp;
end

function [K,t] = cumu1w(z,v,zzp,order)
%
%   This function computes the saddlepoint and cumulants for
%   z'*v+zzp, 
%
n = length(z);
m = 2*order+2;
lnh = -0.69314718055994531;  % ln(1/2)
zv = z.*v;
zzp1 = zzp-sum(zv);
options = optimset('Display','off','TolX',1e-12);
t = fzero(@saddlept,0,options);
w = 1./(1+exp(-2*t*zv));
K = zeros(m,1);
K(1) = n*lnh+t*zzp+sum(t*zv)-sum(log(w));
K(2) = zzp-sum(zv)+2*zv'*w;
c0 = 2;
c1 = 1;
ZZ = zv;
w1 = w;
for i=3:m
    ZZ = ZZ.*zv;
    w1 = [w1 w1(:,end).*w];
    c0 = 2*c0/(i-1);
    c1 = c1.*[1:i-2]';
    c1 = [c1; 0]-[0; c1];
    K(i) = c0*ZZ'*(w1*c1);
end

function y = saddlept(t)
   y = zzp1+2*sum(zv./(1+exp(-2*t*zv)));
end
end


function K = Kderw(s,t,z,u,v,zzp,m)
   lnh = -0.69314718055994531;  % ln(1/2)
   zu = z.*u;
   zv = z.*v;
   zzp1 = zzp-sum(zv);
   szu = sum(zu);
   n = length(z);
   w = 1./(1+exp(-2*(s*zu+t*zv)));
   K = zeros(m);
   K(1,1) = n*lnh+t*(zzp+sum(zv))+s*szu-sum(log(w));
   K(2,1) = -szu+2*zu'*w;
   K(2,2) = zzp1+2*zv'*w;
   ZZ = [zu zv];
   w1 = w;
   c0 = 2;
   c1 = 1;
   fac = factorial([0:m]);
   for i=3:m
       ZZ = [ZZ.*(zu*ones(1,i-1)) ZZ(:,end).*zv];
       w1 = [w1 w1(:,end).*w];
       c0 = 2*c0;
       c1 = c1.*[1:i-2]';
       c1 = [c1; 0]-[0; c1];
       w2 = w1*c1;
       for j=1:i
           K(i,j) = c0*ZZ(:,j)'*w2/fac(i-j+1)/fac(j);
       end
   end
end
