Reference: Broda and Kan (2015), On Distributions of Ratios.

Files contained in this zip archive:

Directory cushnypeebles
    bootrat.m                   Computes abscissas and exact cumulative probabilities of the bootstrap distribution of a ratio.
    brquantile.m                Computes the corresponding exact bootstrap quantiles.
    brquantile_spa.m            Computes the saddlepoint approximation to the bootstrap quantiles.
    brspacdf.m                  Computes the bootstrap cdf.
    brspapdf.m                  Computes the bootstrap pdf.
    confidence_intervals.m      Compute the confidence intervals in Section 5.2.
    defpair.m                   Checks if numerator and denominator form a definite pair in the Fieller-Creasy bootstrap example.
    table2.m                    Creates Table 2 in the paper.

Directory iv
    data_for_figure2.eps.mat    Simulation results for Figure S1 in the Supplementary Material.
    defpair.m                   Checks if numerator and denominator form a definite pair in the IV bootstrap example.
    figure2.m                   Creates figure2.eps and figure2.pdf, which correspond to Figure S1 in the paper. Uses data_for_figure2.eps.mat if available. Otherwise, it runs the Monte Carlo experiment.
    figure2.eps
    figure2.pdf
    ivspacdf.m                  Computes the bootstrap cdf of the IV estimator.
    ivspapdf.m                  Computes the bootstrap pdf of the IV estimator.
    tight_subplot.m             Creates tighter subplots then Matlab's subplot. Written by Pekka Kumpulainen 20.6.2010 Tampere University of Technology / Automation Science and Engineering.

Directory tratio
    bivtrat.m                   Computes the exact pdf and cdf of a ratio of elliptical Student's t random variables.
    bivtratquantile.m           Computes the corresponding quantiles.
    bivtratspa.m                Same as bivtrat, but uses saddlepoint approximation.
    bivtratquantilespa.m        Same as bivtratquantile, but uses saddlepoint approximation.
    bssm_gci1.m                 Computes the generalized confidence interval for ratios of regression coefficients in the example of Bebu et. al. (2009).
    bssm_gci2.m                 Same, but for the example from Cox (1985).
    dgamma.f                    Fortran 77 code for the gamma function. From the specfun package by W. J. Cody and L. Stoltz. Called by f21a.f90.
    dlgama.f90                  Fortran 90 code for the log gamma function. From the specfun package by W. J. Cody and L. Stoltz. Called by f21a.f90.
    f21a.f90                    Fortran 90 code to evaluate the 2F1 function in the specific case needed in the paper.
    f21a.m                      Matlab code that does the same thing. Will be used if no .mex file is present.
    f21a.mexw64                 Mex file compiled from f21a.f90.
    f21r.m                      Evaluates a ratio of certain 2F1 functions. Called by tratspa.m when using f21a would result in over/underflow.
    figure1.m                   Creates figure1.eps and figure1.pdf. This is Figure 1 in the paper.
    figure1.eps
    figure1.pdf
    hyper2f1.m                  Sums the hypergeometric series. Called by f21a.m.
    lee_lin_gci1                Computes the generalized confidence interval for the example from Finney (1978).
    mexinterface_c.f90          Used by f21a.f90.
    trat.m                      Computes the exact pdf and cdf of a ratio of independent Student's t variates.
    tratquantile.m              Computes the corresponding quantiles.
    tratquantile_spa.m          Same, but using saddlepoint approximation.
    tratspa.m                   Same as trat.m, but using saddlepoint approximation.

Common files
    cauchyg2.m                  Computes the density and distribution function of a ratio of normals.
    spar_cdf.m                  Evaluates the saddlepoint approximation for the cdf of a ratio, given the tilted cumulants and saddlepoints. See, e.g., tratspa.m for an example of how to use it.
    spar_pdf.m                  Same, but for pdf.
