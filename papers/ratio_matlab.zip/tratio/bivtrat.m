function [f,F]=bivtrat(rvec,n,m1,m2,s1,s2,rho)
%
%  This program computes the exact pdf and cdf of 
%  (m1+s1*Z1/U)/(m2+s2*Z2/U), where (Z1,Z2) have 
%  a standard bivariate normal distribution with 
%  correlation rho, U~sqrt(chi^2_n/n), and U is independent 
%  of (Z_1,Z_2)
%  Let X1=m1+s1*Z1/U, X2=m2+s2*Z2/U.  When rho=0, the joint density
%  of (X1,X2) is given by
%  f(x1,x2) = 1/(2*pi*s1*s2)*[1+((x1-m1)/s1)^2/n+((x2-m2)/s2)^2/n]^(-n/2-1)
%
adj = s1*rho/s2;
rvec = rvec-adj;
m1 = m1-adj*m2;
s1 = s1*sqrt(1-rho^2);
q = -s2*(m1/s1^2*rvec+m2/s2^2)./sqrt(1+(s2/s1)^2*rvec.^2);
q1 = sqrt((m1/s1)^2+(m2/s2)^2+n-q.^2); 
k1 = (1+((m1/s1)^2+(m2/s2)^2)/n)^(-n/2);
k2 = 0.5*n^(n/2+1)*beta(1/2,(n+1)/2);
f = s2/s1/pi./(1+(s2/s1)^2*rvec.^2).*(k1+k2*q./q1.^(n+1).*(2*tcdf(sqrt(n+1)*q./q1,n+1)-1));
if nargout>1
   F = zeros(size(rvec));
   z2 = m2/abs(s2);
   for i=1:numel(rvec)
       r = rvec(i);
       rho1 = r/sqrt((s1/s2)^2+r^2);
       z1 = (r*m2-m1)/sqrt(s1^2+r^2*s2^2);
       C = [1 rho1; rho1 1];
       F(i) = 2*mvtcdf([z1 z2],C,n)-tcdf(z1,n);
   end
   F = F+tcdf(-z2,n);
end
