function q = bivtratquantile(alpha,n,m1,m2,s1,s2,rho)
%q = bivtratquantile(alpha,n,m1,m2,s1,s2,rho)
%
%Computes the 100*alpha percent quantile of
%(m1+s1*T_1)/(m2+s2*T_2), T_1 and T_2 have a standard bivariate t 
%distribution with n degrees of freedom and correlation of rho.
%
%Reference: Broda, S.A., and Kan, R. (2015), "On Distributions
%of Ratios".
if ~isscalar(alpha) 
   error('alpha must be scalar.');
end
options = optimset('disp','none');
if m2==0
   rstart = 0;
else
   rstart = norminv(alpha,m1/m2,sqrt((s1^2+(m1*s2/m2)^2)/m2^2));
end
q = fzero(@(r)cdf(r)-alpha,rstart,options);
    
    function F=cdf(r)
       [~,F] = bivtrat(r,n,m1,m2,s1,s2,rho);
    end
end
