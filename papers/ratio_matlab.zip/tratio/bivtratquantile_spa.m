function q = bivtratquantile_spa(alpha,n,m1,m2,s1,s2,rho,order)
%q = bivtratquantile_spa(alpha,n,m1,m2,s1,s2,rho,order)
%
%Computes the 1st, 2nd or 3rd order saddlepoint approximation to 
%100*alpha quantile of 
%(m1+s1*T_1)/(m2+s2*T_2), T_1 and T_2 have a standard bivariate t distribution
%with n degrees of freedom and correlation of rho.
%
%Reference: Broda, S.A., and Kan, R. (2015), "On Distributions
%of Ratios".
%
if ~isscalar(alpha)
   error('alpha must be scalar.');
end
adj = s1*rho/s2;
m1 = m1-adj*m2;
s1 = s1*sqrt(1-rho^2);
ss = min(abs([s1 s2]))/2;
m1 = m1/ss;
m2 = m2/ss;
s1 = s1/ss; 
s2 = s2/ss;
options = optimset('disp','none');
st = [-m1/s1^2 -m2/s2^2];
c = ((m1/s1)^2+(m2/s2)^2)/n;
if order==1
   theta = zeros(4);
   theta(1,1) = -n/2*log1p(c); 
   theta(3,1:3) = [0.5*s1^2/(1+c) 0 0.5*s2^2/(1+c)];
elseif order==2
   theta = zeros(6);
   theta(1,1) = -n/2*log1p(c); 
   theta(3,1:3) = [0.5*s1^2/(1+c) 0 0.5*s2^2/(1+c)];
   theta(5,1:5) = [0.25*s1^4/n/(1+c)^2 0 0.5*s1^2*s2^2/n/(1+c)^2 0 0.25*s2^4/n/(1+c)^2];
else
   theta = zeros(8);
   theta(1,1) = -n/2*log1p(c); 
   theta(3,1:3) = [0.5*s1^2/(1+c) 0 0.5*s2^2/(1+c)];
   theta(5,1:5) = [0.25*s1^4/n/(1+c)^2 0 0.5*s1^2*s2^2/n/(1+c)^2 0 0.25*s2^4/n/(1+c)^2];
   theta(7,1:7) = [s1^6/6 0 0.5*s1^4*s2^2 0 0.5*s1^2*s2^4 0 s2^6/6]/(n^2*(1+c)^3);
end
t0 = st(2);  
c = -m2*t0/n;
if order==1
   thetaY = [-0.5*n*log1p(c); 0; 0.5*s2^2/(1+c); 0];
elseif order==2
   thetaY = [-0.5*n*log1p(c); 0; 0.5*s2^2/(1+c); 0; 0.25*s2^4/n/(1+c)^2; 0];
else
   thetaY = [-0.5*n*log1p(c); 0; 0.5*s2^2/(1+c); 0; 0.25*s2^4/n/(1+c)^2; 0; s2^6/(6*n^2)/(1+c)^3; 0];
end

if m2==0
   rstart = 0;
else
   rstart = norminv(alpha,m1/m2,sqrt((s1^2+(m1*s2/m2)^2)/m2^2));
end
q = fzero(@(r)cdf(r)-alpha,rstart,options)+adj; 

function y = cdf(r)
   c1 = m2*s1^2+m1*r*s2^2;
   c2 = s1^2+(r*s2)^2;
   s0 = (m2*r-m1)/c2;
   c = (m2*r-m1)*s0/n;
   if order==1
      thetaW = [-0.5*n*log1p(c); 0; 0.5*c2/(1+c); 0];
   elseif order==2
      thetaW = [-0.5*n*log1p(c); 0; 0.5*c2/(1+c); 0; 0.25*c2^2/n/(1+c)^2; 0];
   else
      thetaW = [-0.5*n*log1p(c); 0; 0.5*c2/(1+c); 0; 0.25*c2^2/n/(1+c)^2; 0; c2^3/(6*n^2)/(1+c)^3; 0];
   end
   y = spar_cdf(r,theta,thetaW,thetaY,st,s0,t0,order);
end

end