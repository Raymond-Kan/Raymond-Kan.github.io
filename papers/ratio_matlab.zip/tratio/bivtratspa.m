function [pdf,cdf] = bivtratspa(rvec,n,m1,m2,s1,s2,rho,order)
%[pdf,cdf] = bivtratspa(rvec,n,m1,m2,s1,s2,rho,order)
%
%Computes the 1st, 2nd, or 3rd order saddlepoint approximation to 
%the pdf and cdf of (m1+s1*T_1)/(m2+s2*T_2), T_1 = Z_1/sqrt(X/n), 
%T_2 = Z_2/sqrt(X/n), with (Z_1,Z_2) have a standard bivaraite normal 
%distribution with correlation rho, and X ~ chi^2_n, independent of each other. 
%
%Reference: Broda, S.A., and Kan, R. (2015), "On Distributions
%of Ratios".
%
adj = s1*rho/s2;
rvec = rvec-adj;
m1 = m1-adj*m2;
s1 = s1*sqrt(1-rho^2);
ss = min(abs([s1 s2]));
m1 = m1/ss;
m2 = m2/ss;
s1 = s1/ss; 
s2 = s2/ss;
pdf = zeros(size(rvec));
st = [-m1/s1^2 -m2/s2^2];
c = ((m1/s1)^2+(m2/s2)^2)/n;
if order==1
   theta = zeros(4);
   theta(1,1) = -n/2*log1p(c); 
   theta(3,1:3) = [0.5*s1^2/(1+c) 0 0.5*s2^2/(1+c)];
elseif order==2
   theta = zeros(6);
   theta(1,1) = -n/2*log1p(c); 
   theta(3,1:3) = [0.5*s1^2/(1+c) 0 0.5*s2^2/(1+c)];
   theta(5,1:5) = [0.25*s1^4/n/(1+c)^2 0 0.5*s1^2*s2^2/n/(1+c)^2 0 0.25*s2^4/n/(1+c)^2];
else
   theta = zeros(8);
   theta(1,1) = -n/2*log1p(c); 
   theta(3,1:3) = [0.5*s1^2/(1+c) 0 0.5*s2^2/(1+c)];
   theta(5,1:5) = [0.25*s1^4/n/(1+c)^2 0 0.5*s1^2*s2^2/n/(1+c)^2 0 0.25*s2^4/n/(1+c)^2];
   theta(7,1:7) = [s1^6/6 0 0.5*s1^4*s2^2 0 0.5*s1^2*s2^4 0 s2^6/6]/(n^2*(1+c)^3);
end
if nargout>1
   cdf = zeros(size(rvec)); 
   c = (m2/s2)^2/n;
   if order==1
      thetaY = [-0.5*n*log1p(c); 0; 0.5*s2^2/(1+c); 0];
   elseif order==2
      thetaY = [-0.5*n*log1p(c); 0; 0.5*s2^2/(1+c); 0; 0.25*s2^4/n/(1+c)^2; 0];
   else
      thetaY = [-0.5*n*log1p(c); 0; 0.5*s2^2/(1+c); 0; 0.25*s2^4/n/(1+c)^2; 0; s2^6/(6*n^2)/(1+c)^3; 0];
   end   
end

r = rvec(1);
for loop=1:length(rvec)
    r = rvec(loop);
    c1 = m2*s1^2+m1*r*s2^2;
    c2 = s1^2+(r*s2)^2;
    s0 = (m2*r-m1)/c2;
    c = (m2*r-m1)*s0/n;
    if order==1
       thetaW = [-0.5*n*log1p(c); 0; 0.5*c2/(1+c); 0];
       J = c1/c2/(1+c);
       pdf(loop) = spar_pdf(r,theta,thetaW(1:3),J,st,s0,order);
    elseif order==2
       thetaW = [-0.5*n*log1p(c); 0; 0.5*c2/(1+c); 0; 0.25*c2^2/n/(1+c)^2; 0];
       J = [c1/c2/(1+c); -r*s2^2/(1+c); c1/n/(1+c)^2];
       pdf(loop) = spar_pdf(r,theta,thetaW(1:5),J,st,s0,order);
    else
       thetaW = [-0.5*n*log1p(c); 0; 0.5*c2/(1+c); 0; 0.25*c2^2/n/(1+c)^2; 0; c2^3/(6*n^2)/(1+c)^3; 0];
       J = [c1/c2/(1+c); -r*s2^2/(1+c); c1/n/(1+c)^2; -r*s2^2*c2/n/(1+c)^2; c1*c2/(n^2*(1+c)^3)];
       pdf(loop) = spar_pdf(r,theta,thetaW(1:7),J,st,s0,order);
    end    
    if nargout>1
       cdf(loop) = spar_cdf(r,theta,thetaW,thetaY,st,s0,st(2),order);
    end
end
