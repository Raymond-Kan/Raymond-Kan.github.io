function bssm_gci1()
%Example from Section 2.3 of Bebu, Seiller-Moiseiwitsch and Mathew (2009)
alpha=.05;
y=[73,69,71,91,80,110, 77,93,116,78,87,86,101,104, 118,85,105,76,101, 79,87,71,78,92,92, 101,86,105,111,102,107,102,112]';
X=zeros(33,3);
X(:,1)=1;
X(1:6,2)=log(.2);
X(7:14,2)=log(.3);
X(15:19,2)=log(.4);
X(20:25,2)=log(1);
X(26:33,2)=log(2.5);
X(20:33,3)=1;
[n,p]=size(X);

bhat=X\y;
r=exp(bhat(3)/bhat(2));
shat=norm(y-X*bhat)/sqrt(n-p);
S=shat^2*inv(X'*X);
V=diag(diag(S));
C=V^-.5*S*V^-.5;
a=bhat(3);
c=bhat(2);
b=-sqrt(V(3,3));
d=-sqrt(V(2,2));
rho=C(2,3);
pr_y_neg=tcdf(-c/abs(d),n-p);
cl = exp(bivtratquantile(alpha/2,n-p,a,c,b,d,rho))
cu = exp(bivtratquantile(1-alpha/2,n-p,a,c,b,d,rho))
 
cl_spa = exp(bivtratquantilespa(alpha/2,n-p,a,c,b,d,rho,1))
cu_spa = exp(bivtratquantilespa(1-alpha/2,n-p,a,c,b,d,rho,1))
 
 