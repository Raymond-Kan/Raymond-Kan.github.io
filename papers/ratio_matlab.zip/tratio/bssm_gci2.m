function bssm_gci2()
%Example from Section 2.3 of Cox (1985, Table 1)

alpha=.05;
y=[5.9  3.8 6.5  18.3  18.2  16.1  7.6 7.6 0.4  1.1  3.2  6.5  4.1  4.7  ]';
X=zeros(14,2);
X(1:7,1)=1;
X(8:14,2)=1;
[n,p]=size(X);

bhat=X\y;
r=bhat(1)/bhat(2);
shat=norm(y-X*bhat)/sqrt(n-p);
S=shat^2*inv(X'*X);
V=diag(diag(S));
C=V^-.5*S*V^-.5;
a=bhat(1);
c=bhat(2);
b=-sqrt(V(1,1));
d=-sqrt(V(2,2));
rho=C(1,2);
pr_y_neg=tcdf(-c/abs(d),n-p);

cl = bivtratquantile(alpha/2,n-p,a,c,b,d,rho)
cu = bivtratquantile(1-alpha/2,n-p,a,c,b,d,rho)
 
cl_spa = bivtratquantilespa(alpha/2,n-p,a,c,b,d,rho,1)
cu_spa = bivtratquantilespa(1-alpha/2,n-p,a,c,b,d,rho,1)
 
 