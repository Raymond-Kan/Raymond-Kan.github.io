!CS REAL FUNCTION ALGAMA(X)
 REAL*8 FUNCTION DLGAMA (X)
 !---------------------------------------------------------------------- 
 !
 ! This routine calculates the LOG(GAMMA) function for a positive real
 ! argument X. Computation is based on an algorithm outlined in
 ! references 1 and 2. The program uses rational functions that
 ! theoretically approximate LOG(GAMMA) to at least 18 significant
 ! decimal digits. The approximation for X > 12 is from reference
 ! 3, while approximations for X < 12.0 are similar to those in
 ! reference 1, but are unpublished. The accuracy achieved depends
 ! on the arithmetic system, the compiler, the intrinsic functions,
 ! and proper selection of the machine-dependent constants.
 !
 !
 !*********************************************************************
 !*********************************************************************
 !
 ! Explanation of machine-dependent constants
 !
 ! beta - radix for the floating-point representation
 ! maxexp - the smallest positive power of beta that overflows
 ! XBIG - largest argument for which LN(GAMMA(X)) is representable
 ! in the machine, i.e., the solution to the equation
 ! LN(GAMMA(XBIG)) = beta**maxexp
 ! XINF - largest machine representable floating-point number;
 ! approximately beta**maxexp.
 ! EPS - The smallest positive floating-point number such that
 ! 1.0+EPS .GT. 1.0
 ! FRTBIG - Rough estimate of the fourth root of XBIG
 !
 !
 ! Approximate values for some important machines are:
 !
 ! beta maxexp XBIG
 !
 ! CRAY-1 (S.P.) 2 8191 9.62E+2461
 ! Cyber 180/855
 ! under NOS (S.P.) 2 1070 1.72E+319
 ! IEEE (IBM/XT,
 ! SUN, etc.) (S.P.) 2 128 4.08E+36
 ! IEEE (IBM/XT,
 ! SUN, etc.) (D.P.) 2 1024 2.55D+305
 ! IBM 3033 (D.P.) 16 63 4.29D+73
 ! VAX D-Format (D.P.) 2 127 2.05D+36
 ! VAX G-Format (D.P.) 2 1023 1.28D+305
 !
 !
 ! XINF EPS FRTBIG
 !
 ! CRAY-1 (S.P.) 5.45E+2465 7.11E-15 3.13E+615
 ! Cyber 180/855
 ! under NOS (S.P.) 1.26E+322 3.55E-15 6.44E+79
 ! IEEE (IBM/XT,
 ! SUN, etc.) (S.P.) 3.40E+38 1.19E-7 1.42E+9
 ! IEEE (IBM/XT,
 ! SUN, etc.) (D.P.) 1.79D+308 2.22D-16 2.25D+76
 ! IBM 3033 (D.P.) 7.23D+75 2.22D-16 2.56D+18
 ! VAX D-Format (D.P.) 1.70D+38 1.39D-17 1.20D+9
 ! VAX G-Format (D.P.) 8.98D+307 1.11D-16 1.89D+76
 !
 !**************************************************************
 !**************************************************************
 !
 ! Error returns
 !
 ! The program returns the value XINF for X .LE. 0.0 or when
 ! overflow would occur. The computation is believed to
 ! be free of underflow and overflow.
 !
 !
 ! Intrinsic functions required are:
 !
 ! LOG
 !
 !
 ! References:
 !
 ! 1) W. J. Cody and K. E. Hillstrom, 'Chebyshev Approximations for
 ! the Natural Logarithm of the Gamma Function,' Math. Comp. 21,
 ! 1967, pp. 198-203.
 !
 ! 2) K. E. Hillstrom, ANL/AMD Program ANLC366S, DGAMMA/DLGAMA, May,
 ! 1969.
 !
 ! 3) Hart, Et. Al., Computer Approximations, Wiley and sons, New
 ! York, 1968.
 !
 !
 ! Authors: W. J. Cody and L. Stoltz
 ! Argonne National Laboratory
 !
 ! Latest modification: June 16, 1988
 !
 !---------------------------------------------------------------------- 
 INTEGER I
 !CS REAL
 REAL*8 :: C, CORR, D1, D2, D4, EPS, FRTBIG, FOUR, HALF, ONE, &
 PNT68, P1, P2, P4, Q1, Q2, Q4, RES, SQRTPI, THRHAL, TWELVE, TWO, &
 X, XBIG, XDEN, XINF, XM1, XM2, XM4, XNUM, Y, YSQ, ZERO
 DIMENSION C (7), P1 (8), P2 (8), P4 (8), Q1 (8), Q2 (8), Q4 (8)
 !---------------------------------------------------------------------- 
 ! Mathematical constants
 !---------------------------------------------------------------------- 
 !S DATA ONE,HALF,TWELVE,ZERO/1.0E0,0.5E0,12.0E0,0.0E0/,
 !S 1 FOUR,THRHAL,TWO,PNT68/4.0E0,1.5E0,2.0E0,0.6796875E0/,
 !S 2 SQRTPI/0.9189385332046727417803297E0/
    DATA ONE,HALF,TWELVE,ZERO/1.0D0,0.5D0,12.0D0,0.0D0/, &
    FOUR,THRHAL,TWO,PNT68/4.0D0,1.5D0,2.0D0,0.6796875D0/, &
    SQRTPI/0.9189385332046727417803297D0/
 !---------------------------------------------------------------------- 
 ! Machine dependent parameters
 !---------------------------------------------------------------------- 
 !S DATA XBIG,XINF,EPS,FRTBIG/4.08E36,3.401E38,1.19E-7,1.42E9/
    DATA XBIG,XINF,EPS,FRTBIG/2.55D305,1.79D308,2.22D-16,2.25D76/
 !---------------------------------------------------------------------- 
 ! Numerator and denominator coefficients for rational minimax
 ! approximation over (0.5,1.5).
 !---------------------------------------------------------------------- 
 !S DATA D1/-5.772156649015328605195174E-1/
 !S DATA P1/4.945235359296727046734888E0,2.018112620856775083915565E2,
 !S 1 2.290838373831346393026739E3,1.131967205903380828685045E4,
 !S 2 2.855724635671635335736389E4,3.848496228443793359990269E4,
 !S 3 2.637748787624195437963534E4,7.225813979700288197698961E3/
 !S DATA Q1/6.748212550303777196073036E1,1.113332393857199323513008E3,
 !S 1 7.738757056935398733233834E3,2.763987074403340708898585E4,
 !S 2 5.499310206226157329794414E4,6.161122180066002127833352E4,
 !S 3 3.635127591501940507276287E4,8.785536302431013170870835E3/
    DATA D1/-5.772156649015328605195174D-1/
    DATA P1/4.945235359296727046734888D0,2.018112620856775083915565D2, &
    2.290838373831346393026739D3,1.131967205903380828685045D4, &
    2.855724635671635335736389D4,3.848496228443793359990269D4, &
    2.637748787624195437963534D4,7.225813979700288197698961D3/
    DATA Q1/6.748212550303777196073036D1,1.113332393857199323513008D3, &
    7.738757056935398733233834D3,2.763987074403340708898585D4, &
    5.499310206226157329794414D4,6.161122180066002127833352D4, &
    3.635127591501940507276287D4,8.785536302431013170870835D3/
 !---------------------------------------------------------------------- 
 ! Numerator and denominator coefficients for rational minimax
 ! Approximation over (1.5,4.0).
 !---------------------------------------------------------------------- 
 !S DATA D2/4.227843350984671393993777E-1/
 !S DATA P2/4.974607845568932035012064E0,5.424138599891070494101986E2,
 !S 1 1.550693864978364947665077E4,1.847932904445632425417223E5,
 !S 2 1.088204769468828767498470E6,3.338152967987029735917223E6,
 !S 3 5.106661678927352456275255E6,3.074109054850539556250927E6/
 !S DATA Q2/1.830328399370592604055942E2,7.765049321445005871323047E3,
 !S 1 1.331903827966074194402448E5,1.136705821321969608938755E6,
 !S 2 5.267964117437946917577538E6,1.346701454311101692290052E7,
 !S 3 1.782736530353274213975932E7,9.533095591844353613395747E6/
    DATA D2/4.227843350984671393993777D-1/
    DATA P2/4.974607845568932035012064D0,5.424138599891070494101986D2, &
    1.550693864978364947665077D4,1.847932904445632425417223D5, &
    1.088204769468828767498470D6,3.338152967987029735917223D6, &
    5.106661678927352456275255D6,3.074109054850539556250927D6/
    DATA Q2/1.830328399370592604055942D2,7.765049321445005871323047D3, &
    1.331903827966074194402448D5,1.136705821321969608938755D6, &
    5.267964117437946917577538D6,1.346701454311101692290052D7, &
    1.782736530353274213975932D7,9.533095591844353613395747D6/
 !---------------------------------------------------------------------- 
 ! Numerator and denominator coefficients for rational minimax
 ! Approximation over (4.0,12.0).
 !---------------------------------------------------------------------- 
 !S DATA D4/1.791759469228055000094023E0/
 !S DATA P4/1.474502166059939948905062E4,2.426813369486704502836312E6,
 !S 1 1.214755574045093227939592E8,2.663432449630976949898078E9,
 !S 2 2.940378956634553899906876E10,1.702665737765398868392998E11,
 !S 3 4.926125793377430887588120E11,5.606251856223951465078242E11/
 !S DATA Q4/2.690530175870899333379843E3,6.393885654300092398984238E5,
 !S 2 4.135599930241388052042842E7,1.120872109616147941376570E9,
 !S 3 1.488613728678813811542398E10,1.016803586272438228077304E11,
 !S 4 3.417476345507377132798597E11,4.463158187419713286462081E11/
    DATA D4/1.791759469228055000094023D0/
    DATA P4/1.474502166059939948905062D4,2.426813369486704502836312D6, &
    1.214755574045093227939592D8,2.663432449630976949898078D9, &
    2.940378956634553899906876D10,1.702665737765398868392998D11, &
    4.926125793377430887588120D11,5.606251856223951465078242D11/
    DATA Q4/2.690530175870899333379843D3,6.393885654300092398984238D5, &
    4.135599930241388052042842D7,1.120872109616147941376570D9, &
    1.488613728678813811542398D10,1.016803586272438228077304D11, &
    3.417476345507377132798597D11,4.463158187419713286462081D11/
 !---------------------------------------------------------------------- 
 ! Coefficients for minimax approximation over (12, INF).
 !---------------------------------------------------------------------- 
 !S DATA C/-1.910444077728E-03,8.4171387781295E-04,
 !S 1 -5.952379913043012E-04,7.93650793500350248E-04,
 !S 2 -2.777777777777681622553E-03,8.333333333333333331554247E-02,
 !S 3 5.7083835261E-03/
    DATA C/-1.910444077728D-03,8.4171387781295D-04, &
    -5.952379913043012D-04,7.93650793500350248D-04, &
    -2.777777777777681622553D-03,8.333333333333333331554247D-02, &
    5.7083835261D-03/
 !---------------------------------------------------------------------- 
 Y = X
 IF ( (Y.GT.ZERO) .AND. (Y.LE.XBIG) ) THEN
 IF (Y.LE.EPS) THEN
 RES = - LOG (Y)
 ELSEIF (Y.LE.THRHAL) THEN
 !---------------------------------------------------------------------- 
 ! EPS .LT. X .LE. 1.5
 !---------------------------------------------------------------------- 
 IF (Y.LT.PNT68) THEN
 CORR = - LOG (Y)
 XM1 = Y
 ELSE
 CORR = ZERO
 XM1 = (Y - HALF) - HALF
 ENDIF
 IF ( (Y.LE.HALF) .OR. (Y.GE.PNT68) ) THEN
 XDEN = ONE
 XNUM = ZERO
 DO 140 I = 1, 8
 XNUM = XNUM * XM1 + P1 (I)
 XDEN = XDEN * XM1 + Q1 (I)
 140 END DO
 RES = CORR + (XM1 * (D1 + XM1 * (XNUM / XDEN) ) )
 ELSE
 XM2 = (Y - HALF) - HALF
 XDEN = ONE
 XNUM = ZERO
 DO 220 I = 1, 8
 XNUM = XNUM * XM2 + P2 (I)
 XDEN = XDEN * XM2 + Q2 (I)
 220 END DO
 RES = CORR + XM2 * (D2 + XM2 * (XNUM / XDEN) )
 ENDIF
 ELSEIF (Y.LE.FOUR) THEN
 !---------------------------------------------------------------------- 
 ! 1.5 .LT. X .LE. 4.0
 !---------------------------------------------------------------------- 
 XM2 = Y - TWO
 XDEN = ONE
 XNUM = ZERO
 DO 240 I = 1, 8
 XNUM = XNUM * XM2 + P2 (I)
 XDEN = XDEN * XM2 + Q2 (I)
 240 END DO
 RES = XM2 * (D2 + XM2 * (XNUM / XDEN) )
 ELSEIF (Y.LE.TWELVE) THEN
 !---------------------------------------------------------------------- 
 ! 4.0 .LT. X .LE. 12.0
 !---------------------------------------------------------------------- 
 XM4 = Y - FOUR
 XDEN = - ONE
 XNUM = ZERO
 DO 340 I = 1, 8
 XNUM = XNUM * XM4 + P4 (I)
 XDEN = XDEN * XM4 + Q4 (I)
 340 END DO
 RES = D4 + XM4 * (XNUM / XDEN)
 ELSE
 !---------------------------------------------------------------------- 
 ! Evaluate for argument .GE. 12.0,
 !---------------------------------------------------------------------- 
 RES = ZERO
 IF (Y.LE.FRTBIG) THEN
 RES = C (7)
 YSQ = Y * Y
 DO 450 I = 1, 6
 RES = RES / YSQ + C (I)
 450 END DO
 ENDIF
 RES = RES / Y
 CORR = LOG (Y)
 RES = RES + SQRTPI - HALF * CORR
 RES = RES + Y * (CORR - ONE)
 ENDIF
 ELSE
 !---------------------------------------------------------------------- 
 ! Return for bad arguments
 !---------------------------------------------------------------------- 
 RES = XINF
 ENDIF
 !---------------------------------------------------------------------- 
 ! Final adjustments and return
 !---------------------------------------------------------------------- 
 !CS ALGAMA = RES
 !CD
 DLGAMA = RES
 ! ---------- Last line of DLGAMA ----------
 END

