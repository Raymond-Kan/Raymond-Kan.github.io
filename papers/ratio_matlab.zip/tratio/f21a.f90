!----------------------------------------------------------------------------
!computes 2F1(v1,v2;v1+v2+1/2,(1+z)/2), v1, v2 nonnegative integers, z real vector
!when comiling with Intel Fortran, use /assume:realloc_lhs.
!----------------------------------------------------------------------------

subroutine mexFunction(nlhs, plhs, nrhs, prhs)
use mexinterface
implicit none
integer*4 ::  nlhs, nrhs
integer(kind=mwSize) :: n, m
integer(kind=mwPointer), parameter :: null=0
integer(kind=mwPointer) ::  plhs(nlhs), prhs(nrhs)
real*8 :: v1, v2
logical :: allreal
if (nrhs.lt.3) call mexerrmsgtxt('requires 3 input arguments'//char(0))
n = mxgetn(prhs(1))
m = mxgetm(prhs(1))
if (max(m,n).ne.1) call mexerrmsgtxt('v1 must be scalar'//char(0))
n = mxgetn(prhs(2))
m = mxgetm(prhs(2))
if (max(m,n).ne.1) call mexerrmsgtxt('v2 must be scalar'//char(0))
if (mxiscomplex(prhs(1))) call mexerrmsgtxt('v1 and v2 must be nonnegative integers.'//char(0))
if (mxiscomplex(prhs(2))) call mexerrmsgtxt('v1 and v2 must be nonnegative integers.'//char(0))
if (mxiscomplex(prhs(3))) call mexerrmsgtxt('z must be real.'//char(0))
m = mxgetm(prhs(3))
n = mxgetn(prhs(3))
if (min(m,n).ne.1) call mexerrmsgtxt('z must be a vector.'//char(0))
plhs(1) = mxCreateDoubleMatrix(m, n, 1)
n = max(m,n)
call mxcopyptrtoreal8(mxgetpr(prhs(1)),v1,1_8)
call mxcopyptrtoreal8(mxgetpr(prhs(2)),v2,1_8)
call f21a(v1,v2,%val(mxgetpr(prhs(3))), &
    %val(mxgetpr(plhs(1))),%val(mxgetpi(plhs(1))),n,allreal)
if (allreal) call mxsetpi(plhs(1),NULL)
end subroutine

!----------------------------------------------------------------------------
!computational subroutine
!----------------------------------------------------------------------------
subroutine f21a(v1,v2,z,y,im,nn,allreal)
use mexinterface
use, intrinsic :: ieee_arithmetic
implicit none
integer, parameter :: maxiter=10000
real*8, parameter :: tol=1.0d-16
integer :: k, n, m, v
integer(kind=mwSize) :: nn, ii, ix(nn)
integer(kind=mwSize),allocatable :: ind(:)
real*8 :: d, v1, v2, temp, y(nn),  z(nn),  z1(nn), z2(nn), w(nn), y0(nn), y1(nn), &
          y2(nn), c(nn), y0i(nn), y1i(nn), y2i(nn), g(nn), w0, z0, psi, w1(nn), im(nn)
real*8, parameter :: pi=3.141592653589793238462643d0
logical :: logind(nn), allreal
interface
    elemental function hyper2f1(a,b,c,w1,ln) result(y)
        implicit none
        real*8, intent(in) :: a, b, c, w1
        logical, intent(in) :: ln
        real*8 :: y
    end function hyper2f1
    elemental real*8 function dlgama(x)
        real*8, intent(in) :: x
    end function dlgama
    elemental function log1p(x)
        implicit none
        real*8, intent(in) :: x
        real*8 :: log1p
    end function log1p
end interface
allreal=.true.
if ((v1-int(v1) .ne. 0) .or. (v2-int(v2) .ne. 0)  .or. (v2.lt.0) .or. (v1 .lt. 0)) then
   call mexerrmsgtxt('v1 and v2 must be nonnegative integers.'//char(0))
   return
endif
if ((v1.eq.0) .or. (v2.eq.0)) then
   y = 1.0d0
   return
endif
if (v1.lt.v2) then
   temp = v1
   v1 = v2
   v2 = temp
endif
ix = (/ (ii,ii=1,nn) /)
z1 = 0.5d0*(1.0d0+z)
d = (v1+v2-1.0d0)*0.5d0
if (mod(v1+v2,2d0).eq.1) then
   m = (v1-v2-1.0d0)*0.5d0
   logind = (z.le.-1)
   if (any(logind)) then
      ind = pack(ix,logind)
      w(ind) = z1(ind)
      c(ind) = (2.0d0/(1-z(ind)))**d
      y1(ind) = c(ind)
      do k=1,m
         c(ind) = (-m+k-1.0d0)*(m+k)/dble(k)/dble(d+k)*c(ind)*w(ind)
         y1(ind) = y1(ind)+c(ind)
      enddo
      y(ind) = y1(ind)
   endif
   logind = (z.gt.-1.and.z.lt.1)
   if (any(logind)) then
      ind = pack(ix,logind)
      w(ind) = (z(ind)+1)/(z(ind)-1)
      c(ind) = (2/(1-z(ind)))**v2
      y1(ind) = c(ind)
      do k=1,m
         c(ind) = (-m+k-1.0d0)*(v2+k-1.0d0)/dble(k)/dble(d+k)*c(ind)*w(ind)
         y1(ind) = y1(ind)+c(ind)
      enddo
      y(ind) = y1(ind)
   endif
   logind = (z.gt.1)
   if (any(logind)) then
      ind = pack(ix,logind)
      w(ind) = z1(ind)
      if (m.eq.0) then
          y1(ind) = 1.0d0
      else
         y0(ind) = 1.0d0
         y1(ind) = 1.0d0-(m+1.0d0)/(v2+m+1.0d0)*w(ind)
         do k=2,m
             y2(ind) = (((2*k+m+v2-1.0d0)-(m+k)*w(ind))*y1(ind)+(k-1.0d0)*(w(ind)-1.0d0)*y0(ind))/dble(v2+m+k)
             y0(ind) = y1(ind)
             y1(ind) = y2(ind)
         enddo
      endif
      y(ind) = y1(ind)/(1-w(ind))**(v2+m)
   endif
   logind = (z.eq.1)
   if (any(logind)) then
      ind = pack(ix,logind)
      y(ind) = ieee_value(1.0d0,ieee_positive_inf)
   endif
else
   n = (v1-v2)*0.5d0
   v = v2
   w0 = exp(psi(1.0d0)+psi(dble(2*n+1))-psi(dble(v1))-psi(dble(n+0.5)))
   z0 = min(20.0d0,max(3.0d0,(2.0d0-w0)/w0))
   logind = (z.gt.0.and.z.lt.1)
   if (any(logind)) then
      ind = pack(ix,logind)
      w(ind) = (1-z(ind))*(1+z(ind))
      y(ind) = (0.5d0*pi+asin(z(ind)))/sqrt(w(ind));
      do k=1,n
         y(ind) = (k+0.5d0)/k*(z(ind)+y(ind))/w(ind)
      enddo
      y1(ind) = 1d0
      do k=2,v
         y2(ind) = (2*n+2*k-1d0)*(2*n+2*k-3d0)/(2*n+k-1d0)/(k-1)*(z(ind)*y(ind)+y1(ind))/w
         y1(ind) = y(ind)
         y(ind) = y2(ind)
      enddo
   endif
   logind = (z.ge.-1.and.z.lt.0)
   if (any(logind)) then
      ind = pack(ix,logind)
      y(ind) = hyper2f1(v1,dble(v),v+n+0.5d0,z1(ind),.false.)
   end if
   logind = (z.lt.-1.and.z.gt.-z0)
   if (any(logind)) then
      ind = pack(ix,logind)
      w(ind) = (z(ind)+1.0d0)/(z(ind)-1.0d0)
      y(ind) = exp(hyper2f1(v1,n+0.5d0,v+n+0.5d0,w(ind),.true.)+v1*log1p(-w(ind)))
   endif
   logind = (z.le.-z0)
   if (any(logind)) then
      ind = pack(ix,logind)
      w(ind) = 2.0d0/(1.0d0-z(ind))
      if (n.eq.0) then
         y1(ind) = 0.0d0
      else
         c(ind) = exp(dlgama(dble(v+n+0.5d0))+dlgama(dble(2*n))-dlgama(dble(v1))-dlgama(dble(n+0.5d0))+v*log(w(ind)))
         y1(ind) = c(ind)
         do k=1,2*n-1
             c(ind) = (n+0.5d0-k)*(v+k-1.0d0)/dble(k)/dble(2*n-k)*c(ind)*w(ind)
             y1(ind) = y1(ind)+c(ind)
         enddo
      endif
      g(ind) = -log(w(ind))+psi(1.0d0)+psi(2*n+1.0d0)-psi(dble(v1))-psi(n+0.5d0)
      c(ind) = (-1.0d0)**n/pi*exp(dlgama(v+n+0.5d0)-dlgama(dble(v))-dlgama(2*n+1.0d0)+dlgama(n+0.5d0)+v1*log(w(ind)))
      y1i(ind) = c(ind)*g(ind)
      do k=1,maxiter
          g(ind) = g(ind)+1.0d0/dble(k)+1.0d0/dble(2*n+k)-1.0d0/(v1+k-1.0d0)-1.0d0/(n+k-0.5d0)
          c(ind) = (v1+k-1.0d0)*(n-0.5d0+k)/dble(k)/dble(k+2*n)*c(ind)*w(ind)
          y2(ind) = c(ind)*g(ind)
          y1i(ind) = y1i(ind)+y2(ind)
          if (all(abs(y2(ind)/y1i(ind)).lt.tol)) then
             exit
          endif
      enddo
      y(ind) = y1(ind)+y1i(ind)
   endif
   logind = (z.gt.1.and.z.lt.z0)
   if (any(logind)) then
      ind = pack(ix,logind)
      w(ind) = (z(ind)-1.0d0)/(z(ind)+1.0d0)
      y(ind) = (-1)**v*exp(hyper2f1(v1,n+0.5d0,v+n+0.5d0,w(ind),.true.)+v1*log1p(-w(ind)))
      !imaginary part
      allreal = .false.
      y1(ind) = (-1)**(n+v)*(1-w(ind))**v1*w(ind)**(-d)*exp(dlgama(v+n+0.5d0)+dlgama(v+n-0.5d0)-dlgama(v1)-dlgama(dble(v)))
      im(ind) = y1(ind)
      do k=1,v-1
         y1(ind) = (-v+k)*(n+k-0.5d0)/(-v-n+0.5d0+k)/dble(k)*w(ind)*y1(ind)
         im(ind) = im(ind)+y1(ind);
      enddo
   endif
   logind = (z.ge.z0)
   if (any(logind)) then
      ind = pack(ix,logind)
      w(ind) = 2/(1.0d0+z(ind))
      if (n.eq.0) then
         y1(ind) = 0.0d0
      else
         c(ind) = (-1)**v*exp(dlgama(v+n+0.5d0)+dlgama(2.0d0*n)-dlgama(v1)-dlgama(n+0.5d0)+v*log(w(ind)))
         y1(ind) = c(ind)
         do k=1,2*n-1
            c(ind) = (n+0.5-k)*(v+k-1)/dble(k)/dble(2*n-k)*c(ind)*w(ind)
            y1(ind) = y1(ind)+c(ind)
         enddo
      endif
      g(ind) = -log(w(ind))+psi(1.0d0)+psi(2*n+1.0d0)-psi(v1)-psi(n+0.5d0)
      c(ind) = (-1)**(v+n)/pi*exp(dlgama(v+n+0.5d0)-dlgama(dble(v))-dlgama(2*n+1.0d0)+dlgama(n+0.5d0)+v1*log(w(ind)))
      y1i(ind) = c(ind)*g(ind)
      do k=1,maxiter
         g(ind) = g(ind)+1.0d0/dble(k)+1.0d0/(2.0d0*n+k)-1.0d0/(v1+k-1.0d0)-1.0d0/(n+k-0.5d0)
         c(ind) = (v1+k-1)*(n-0.5+k)/dble(k)/dble(k+2*n)*c(ind)*w(ind)
         y2(ind) = c(ind)*g(ind)
         y1i(ind) = y1i(ind)+y2(ind)
         if (all(abs(y2(ind)/y1i(ind)) .lt. tol)) then
            exit
         endif
      enddo
      y(ind) = y1(ind)+y1i(ind)
      !imaginary part
      allreal = .false.
      y1(ind) = (-1)**(n+v)*exp(dlgama(v+n+0.5d0)+dlgama(n+0.5d0)-dlgama(dble(v))-dlgama(2.0d0*n+1) &
                +v1*log(w(ind))-(n+0.5d0)*log(1.0d0-w(ind)))
      im(ind) = y1(ind)
      w(ind) = w(ind)/(w(ind)-1)
      do k=1,v-1
         y1(ind) = (-v+k)*(n+k-0.5d0)/(2.0d0*n+k)/dble(k)*w(ind)*y1(ind)
         im(ind) = im(ind)+y1(ind)
      enddo
   endif
   logind = (z.eq.1)
   if (any(logind)) then
      ind = pack(ix,logind)
      y(ind) = (-1.0d0)**v
   endif
endif
logind = (z.eq.0)
if (any(logind)) then
   ind = pack(ix,logind)
   y(ind) = sqrt(pi)*exp(dlgama((v1+v2+1)*0.5d0)-dlgama((v1+1.0d0)*0.5d0)-dlgama((v2+1.0d0)*0.5d0))
endif
end subroutine

!----------------------------------------------------------------------
!sums the hypergeometric series
!----------------------------------------------------------------------
elemental function hyper2f1(a,b,c,w1,ln) result(y)
implicit none
real*8, intent(in) :: a, b, c, w1
real*8 :: y
real*8 :: a1, d1, z, c1, c2, term
logical, intent(in) :: ln
integer :: kmax, count1, count2, k
real*8, parameter :: lnsr2pi = 0.9189385332046727417803297364056d0, tol = 1.0d-16, &
                     realmin = 4.450147717014403d-308
integer, parameter :: maxcount=50000
interface
    pure function stirlerr(n) result(z)
        implicit none
        integer, intent(in) :: n
        real*8 :: z
    end function stirlerr
    pure function bd0(x,np) result(z)
        implicit none
        integer, intent (in) :: x
        real*8, intent(in) :: np
        real*8 :: z
    end function bd0
    elemental function log1p(x)
        implicit none
        real*8, intent(in) :: x
        real*8 :: log1p
    end function log1p
    elemental real*8 function dgamma(x)
        real*8, intent(in) :: x
    end function dgamma
    elemental real*8 function dlgama(x)
        real*8, intent(in) :: x
    end function dlgama
end interface

if (w1 .gt. c/(a*b)) then
   a1 = 1.0d0-c+(a+b-2.0d0)*w1
   d1 = sqrt(a1**2+4*(a-1)*(b-1)*w1*(1.0d0-w1))
   kMax = floor((a1+d1)/(2*(1.0d0-w1)))
else
   kMax = 0;
endif

if (kMax.lt.10 .and. max(a, b, c).lt.10) then
   z = log(dgamma(dble(a+kMax))/dgamma(dble(a))*dgamma(dble(b+kMax))/dgamma(dble(b))* &
       dgamma(dble(c))/dgamma(dble(c+kMax)))
else
   z = dlgama(dble(a+kMax))-dlgama(dble(a))+dlgama(dble(b+kMax))-dlgama(dble(b))+ &
       dlgama(dble(c))-dlgama(dble(c+kMax))
endif

if (kMax.gt.w1*realmin) then
    z = z-lnsr2pi-0.5d0*log(dble(kMax))-stirlerr(kMax)-bd0(kMax,w1)+w1
endif
count1 = 0
count2 = 0
c1 = 0
term = 1
k = kMax
do while (k.gt.0.and.term.gt.c1*tol .and. count1.lt.maxcount )
   count1 = count1+1
   k = k-1
   term = term*(k+1)*(k+c)/(k+a)/(k+b)/w1
   c1 = c1+term
enddo
term = w1*(kMax+a)*(kMax+b)/(kMax+c)/(kMax+1.0d0)
c2 = term
k = kMax+1;
do while (term.gt.c2*tol .and. count2.lt.maxcount)
   count2 = count2+1
   term = term*w1*(k+a)*(k+b)/(k+c)/(k+1.0d0)
   c2 = c2+term
   k = k+1
enddo
if (ln) then
   y = z+log1p(c1+c2)
else
   y = exp(z)*(1.0d0+c1+c2)
endif
end function

!-----------------------------------------------------------------------------------------------------------------------------------
!  LOG1P
!
!  Compute log(1+x).
!-----------------------------------------------------------------------------------------------------------------------------------
elemental function log1p(x) result(y)
implicit none
real*8, intent(in) :: x
real*8 :: y,z
z = 1.0d0+x
if (abs(x).gt.0.375d0) then
   y = log(z)
else
   y = log(z)-((z-1.0d0)-x)/x                                                  ! cancels errors with IEEE arithmetic
endif
return
end function log1p


!----------------------------------------------------------------------
!computes the error of Stirling's approximation of ln(n!),which suggests
!ln(n!) \approx (n+0.5)*ln(n)-n+ln(sqrt(2*pi))
!----------------------------------------------------------------------
pure function stirlerr(n) result(z)
implicit none
integer, intent(in) :: n
integer :: nn
real*8 :: z, S0, S1, S2, S3, S4
real*8, parameter :: lnsr2pi = 0.9189385332046727417803297364056d0
real*8, parameter, dimension(31) ::sferr_halves = (/ &
0.0d0, &
0.1534264097200273452913848d0, &
0.0810614667953272582196702d0, &
0.0548141210519176538961390d0, &
0.0413406959554092940938221d0, &
0.03316287351993628748511048d0, &
0.02767792568499833914878929d0, &
0.02374616365629749597132920d0, &
0.02079067210376509311152277d0, &
0.01848845053267318523077934d0, &
0.01664469118982119216319487d0, &
0.01513497322191737887351255d0, &
0.01387612882307074799874573d0, &
0.01281046524292022692424986d0, &
0.01189670994589177009505572d0, &
0.01110455975820691732662991d0, &
0.010411265261972096497478567d0, &
0.009799416126158803298389475d0, &
0.009255462182712732917728637d0, &
0.008768700134139385462952823d0, &
0.008330563433362871256469318d0, &
0.007934114564314020547248100d0, &
0.007573675487951840794972024d0, &
0.007244554301320383179543912d0, &
0.006942840107209529865664152d0, &
0.006665247032707682442354394d0, &
0.006408994188004207068439631d0, &
0.006171712263039457647532867d0, &
0.005951370112758847735624416d0, &
0.005746216513010115682023589d0, &
0.005554733551962801371038690d0 /)
interface
    pure real*8 function dlgama(x)
        real*8, intent(in) :: x
    end function dlgama
end interface
if (n.le.15) then
   nn = n+n
   if (mod(nn,1) .eq. 0) then
      z = sferr_halves(nn+1)
   else
      z = dlgama(dble(n+1))-(n+0.5)*log(dble(n))+dble(n)-lnsr2pi
   endif
   return
endif
S0 = 0.083333333333333333333d0
S1 = 0.00277777777777777777778d0
S2 = 0.00079365079365079365079365d0
S3 = 0.000595238095238095238095238d0
S4 = 0.0008417508417508417508417508d0
nn = n*n
if (n .gt. 500) then
   z = ((S0-S1/nn)/n)
   return
endif
if (n .gt. 80) then
   z = ((S0-(S1-S2/nn)/nn)/n)
   return
endif
if (n .gt. 35 ) then
   z = ((S0-(S1-(S2-S3/nn)/nn)/nn)/n)
   return
endif
z = ((S0-(S1-(S2-(S3-S4/nn)/nn)/nn)/nn)/n)
end function stirlerr

!----------------------------------------------------------------------
!evaluates the "deviance part" bd0(x,np) = x*log(x/np)+np-x for x, np>0
!----------------------------------------------------------------------

pure function bd0(x,np) result(z)
implicit none
real*8, intent(in) :: np
integer, intent(in) :: x
real*8 :: z, v, s, ej
integer :: j
!if isinf(x)||isinf(np)||np==0
!   z = NaN;
!   return
!end
if (abs(x-np) .lt. 0.1d0*(x+np)) then
   v = (x-np)/(x+np)
   s = (x-np)*v
   ej = 2*x*v;
   v = v*v;
   j = 3
   do while (j>0)
      ej = ej*v
      z = s+ej/j
      if (z .eq. s) then
         return
      endif
      s = z
      j = j+2
   enddo
endif
z = x*log(x/np)+np-x
end function bd0

!----------------------------------------------------------------------

FUNCTION PSI(XX) RESULT(fn_val)

! Code converted using TO_F90 by Alan Miller
! Date: 2003-01-14  Time: 15:25:01

!----------------------------------------------------------------------

! This function program evaluates the logarithmic derivative of the
!   gamma function,

!      psi(x) = d/dx (gamma(x)) / gamma(x) = d/dx (ln gamma(x))

!   for real x, where either

!          -xmax1 < x < -xmin (x not a negative integer), or
!            xmin < x.

!   The calling sequence for this function is

!                  Y = PSI(X)

!   The main computation uses rational Chebyshev approximations
!   published in Math. Comp. 27, 123-127 (1973) by Cody, Strecok and
!   Thacher.  This transportable program is patterned after the
!   machine-dependent FUNPACK program PSI(X), but cannot match that
!   version for efficiency or accuracy.  This version uses rational
!   approximations that are theoretically accurate to 20 significant
!   decimal digits.  The accuracy achieved depends on the arithmetic
!   system, the compiler, the intrinsic functions, and proper selection
!   of the machine-dependent constants.

!*******************************************************************

! The following machine-dependent constants must be declared in
!   DATA statements.  IEEE values are provided as a default.

!   XINF   = largest positive machine number
!   XMAX1  = beta ** (p-1), where beta is the radix for the floating-point
!            system, and p is the number of base-beta digits in the
!            floating-point significand.  This is an upper bound on
!            non-integral floating-point numbers, and the negative of the
!            lower bound on acceptable negative arguments for PSI.
!            If rounding is necessary, round this value down.
!   XMIN1  = the smallest in magnitude acceptable argument.  We
!            recommend XMIN1 = MAX(1/XINF,xmin) rounded up, where
!            xmin is the smallest positive floating-point number.
!   XSMALL = absolute argument below which  PI*COTAN(PI*X)  may be
!            represented by 1/X.  We recommend XSMALL < sqrt(3 eps)/pi,
!            where eps is the smallest positive number such that
!            1 + eps > 1.
!   XLARGE = argument beyond which PSI(X) may be represented by
!            LOG(X).  The solution to the equation
!               x*ln(x) = beta ** p
!            is a safe value.

!     Approximate values for some important machines are

!                        beta  p     eps     xmin       XINF

!  CDC 7600      (S.P.)    2  48  7.11E-15  3.13E-294  1.26E+322
!  CRAY-1        (S.P.)    2  48  7.11E-15  4.58E-2467 5.45E+2465
!  IEEE (IBM/XT,
!    SUN, etc.)  (S.P.)    2  24  1.19E-07  1.18E-38   3.40E+38
!  IEEE (IBM/XT,
!    SUN, etc.)  (D.P.)    2  53  1.11D-16  2.23E-308  1.79D+308
!  IBM 3033      (D.P.)   16  14  1.11D-16  5.40D-79   7.23D+75
!  SUN 3/160     (D.P.)    2  53  1.11D-16  2.23D-308  1.79D+308
!  VAX 11/780    (S.P.)    2  24  5.96E-08  2.94E-39   1.70E+38
!                (D.P.)    2  56  1.39D-17  2.94D-39   1.70D+38
!   (G Format)   (D.P.)    2  53  1.11D-16  5.57D-309  8.98D+307

!                         XMIN1      XMAX1     XSMALL    XLARGE

!  CDC 7600      (S.P.)  3.13E-294  1.40E+14  4.64E-08  9.42E+12
!  CRAY-1        (S.P.)  1.84E-2466 1.40E+14  4.64E-08  9.42E+12
!  IEEE (IBM/XT,
!    SUN, etc.)  (S.P.)  1.18E-38   8.38E+06  1.90E-04  1.20E+06
!  IEEE (IBM/XT,
!    SUN, etc.)  (D.P.)  2.23D-308  4.50D+15  5.80D-09  2.71D+14
!  IBM 3033      (D.P.)  1.39D-76   4.50D+15  5.80D-09  2.05D+15
!  SUN 3/160     (D.P.)  2.23D-308  4.50D+15  5.80D-09  2.71D+14
!  VAX 11/780    (S.P.)  5.89E-39   8.38E+06  1.35E-04  1.20E+06
!                (D.P.)  5.89D-39   3.60D+16  2.05D-09  2.05D+15
!   (G Format)   (D.P.)  1.12D-308  4.50D+15  5.80D-09  2.71D+14

!*******************************************************************

! Error Returns

!  The program returns XINF for  X < -XMAX1, for X zero or a negative
!    integer, or when X lies in (-XMIN1, 0), and returns -XINF
!    when X lies in (0, XMIN1).

! Intrinsic functions required are:

!     ABS, AINT, DBLE, INT, LOG, REAL, TAN


!  Author: W. J. Cody
!          Mathematics and Computer Science Division
!          Argonne National Laboratory
!          Argonne, IL 60439

!  Latest modification: March 14, 1992

!----------------------------------------------------------------------

IMPLICIT NONE
INTEGER, PARAMETER  :: dp = SELECTED_REAL_KIND(12, 60)

REAL (dp), INTENT(IN)  :: xx
REAL (dp)              :: fn_val

! Local variables

INTEGER    :: i, n, nq
REAL (dp)  :: aug, den, sgn, upper, w, x, z
!----------------------------------------------------------------------
!  Mathematical constants.  PIOV4 = pi / 4
!----------------------------------------------------------------------
REAL (dp), PARAMETER  :: zero = 0.0_dp, fourth = 0.25_dp, half = 0.5_dp,  &
                         one = 1.0_dp, three = 3.0_dp, four = 4.0_dp,   &
                         piov4 = 7.8539816339744830962D-01
!----------------------------------------------------------------------
!  Machine-dependent constants
!----------------------------------------------------------------------
REAL (dp), PARAMETER  :: XINF = 1.79D+308, XMIN1 = 2.23D-308, XMAX1 = 4.50D+15, &
                         XSMALL = 5.80D-09, XLARGE = 2.71D+14
!----------------------------------------------------------------------
!  Zero of psi(x)
!----------------------------------------------------------------------
REAL (dp), PARAMETER  :: X01 = 187.0_dp, X01D = 128.0_dp,   &
                         X02 = 6.9464496836234126266D-04
!----------------------------------------------------------------------
!  Coefficients for approximation to  psi(x)/(x-x0)  over [0.5, 3.0]
!----------------------------------------------------------------------
REAL (dp), PARAMETER  ::  P1(9) =   &
        (/ 4.5104681245762934160D-03, 5.4932855833000385356D+00,  &
           3.7646693175929276856D+02, 7.9525490849151998065D+03,  &
           7.1451595818951933210D+04, 3.0655976301987365674D+05,  &
           6.3606997788964458797D+05, 5.8041312783537569993D+05,  &
           1.6585695029761022321D+05 /)
REAL (dp), PARAMETER  ::  Q1(8) =   &
        (/ 9.6141654774222358525D+01, 2.6287715790581193330D+03,  &
           2.9862497022250277920D+04, 1.6206566091533671639D+05,  &
           4.3487880712768329037D+05, 5.4256384537269993733D+05,  &
           2.4242185002017985252D+05, 6.4155223783576225996D-08 /)
!----------------------------------------------------------------------
!  Coefficients for approximation to  psi(x) - ln(x) + 1/(2x)
!     for  x > 3.0
!----------------------------------------------------------------------
REAL (dp), PARAMETER  ::  P2(7) =   &
        (/ -2.7103228277757834192D+00, -1.5166271776896121383D+01,  &
           -1.9784554148719218667D+01, -8.8100958828312219821D+00,  &
           -1.4479614616899842986D+00, -7.3689600332394549911D-02,  &
           -6.5135387732718171306D-21 /)
REAL (dp), PARAMETER  ::  Q2(6) =  &
        (/ 4.4992760373789365846D+01, 2.0240955312679931159D+02,  &
           2.4736979003315290057D+02, 1.0742543875702278326D+02,  &
           1.7463965060678569906D+01, 8.8427520398873480342D-01 /)
!----------------------------------------------------------------------

x = xx
w = ABS(x)
aug = zero
!----------------------------------------------------------------------
!  Check for valid arguments, then branch to appropriate algorithm
!----------------------------------------------------------------------
IF (-x >= xmax1 .OR. w < xmin1) THEN
  GO TO 50
ELSE IF (x >= half) THEN
  GO TO 20
!----------------------------------------------------------------------
!  X < 0.5, use reflection formula: psi(1-x) = psi(x) + pi * cot(pi*x)
!     Use 1/X for PI*COTAN(PI*X)  when  XMIN1 < |X| <= XSMALL.
!----------------------------------------------------------------------
ELSE IF (w <= xsmall) THEN
  aug = -one / x
  GO TO 10
END IF
!----------------------------------------------------------------------
!  Argument reduction for cot
!----------------------------------------------------------------------
IF (x < zero) THEN
  sgn = piov4
ELSE
  sgn = -piov4
END IF
w = w - AINT(w)
nq = INT(w*four)
w = four * (w - nq*fourth)
!----------------------------------------------------------------------
!  W is now related to the fractional part of  4.0 * X.
!     Adjust argument to correspond to values in the first
!     quadrant and determine the sign.
!----------------------------------------------------------------------
n = nq / 2
IF ((n+n) /= nq) w = one - w
z = piov4 * w
IF (MOD(n,2) /= 0) sgn = -sgn
!----------------------------------------------------------------------
!  determine the final value for  -pi * cotan(pi*x)
!----------------------------------------------------------------------
n = (nq+1) / 2
IF (MOD(n,2) == 0) THEN
!----------------------------------------------------------------------
!  Check for singularity
!----------------------------------------------------------------------
  IF (z == zero) GO TO 50
  aug = sgn * (four/TAN(z))
ELSE
  aug = sgn * (four*TAN(z))
END IF
10 x = one - x
20 IF (x <= three) THEN
!----------------------------------------------------------------------
!  0.5 <= X <= 3.0
!----------------------------------------------------------------------
  den = x
  upper = p1(1) * x
  DO  i = 1, 7
    den = (den+q1(i)) * x
    upper = (upper+p1(i+1)) * x
  END DO
  den = (upper+p1(9)) / (den+q1(8))
  x = (x-x01/x01d) - x02
  fn_val = den * x + aug
  GO TO 60
END IF
!----------------------------------------------------------------------
!  3.0 < X
!----------------------------------------------------------------------
IF (x < xlarge) THEN
  w = one / (x*x)
  den = w
  upper = p2(1) * w
  DO  i = 1, 5
    den = (den+q2(i)) * w
    upper = (upper+p2(i+1)) * w
  END DO
  aug = (upper+p2(7)) / (den+q2(6)) - half / x + aug
END IF
fn_val = aug + LOG(x)
GO TO 60
!----------------------------------------------------------------------
!  Error return
!----------------------------------------------------------------------
50 fn_val = xinf
IF (x > zero) fn_val = -xinf
60 RETURN
!---------- Last card of PSI ----------
END FUNCTION PSI
