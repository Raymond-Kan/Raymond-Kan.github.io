function y=f21a(v1,v2,z)
%
% This function computes 2F1(v1,v2;(v1+v2+1)/2;(1+z)/2)
% Issue: Does not deal with general v1 and v2
% Comment: The imaginary part of hypergeom of Matlab can
%          be inaccurate.  e.g.,
% f21a(12,120,100) = 1.9229e-24+5.3040e-224i (which is correct) but
% hypergeom([12 120],133/2,101/2) = 1.9229e-24+1.6844e-186i 
%
if rem(v1,1)~=0||rem(v2,1)~=0||v1<0||v2<0
   fprintf(' v1>=0, v2>=0, v1 and v2 need to be integers\n')
   y = NaN(size(z));
   return
end
if v1==0||v2==0
   y = ones(size(z));
   return
end
maxiter = 10000;
tol = 1e-16;
if v1<v2
   c = v1;
   v1 = v2;
   v2 = c;
end
z1 = (1+z)/2; 
d = (v1+v2-1)/2;
if rem(v1-v2,2)==1
   m = (v1-v2-1)/2;
   ind = find(z<=-1);
   if length(ind)>0
      w = z1(ind);
      c = (2./(1-z(ind))).^d;
      y1 = c;
      for k=1:m
          c = (-m+k-1)*(m+k)/k/(d+k)*c.*w;
          y1 = y1+c;
      end
      y(ind) = y1;
   end
   ind = find(z<1&z>-1);
   if length(ind)>0
      w = (z(ind)+1)./(z(ind)-1);
      c = (2./(1-z(ind))).^v2;
      y1 = c;
      for k=1:m
          c = (-m+k-1)*(v2+k-1)/k/(d+k)*c.*w;
          y1 = y1+c;
      end
      y(ind) = y1;
   end
%
%  When z>1, use recursion
%
   ind = find(z>1);
   if length(ind)>0
      w = z1(ind);
      if m==0
         y1 = ones(size(w));
      else
         y0 = ones(size(w));
         y1 = 1-(m+1)/(v2+m+1)*w;
         for k=2:m
             y2 = (((2*k+m+v2-1)-(m+k)*w).*y1+(k-1)*(w-1).*y0)/(v2+m+k);
             y0 = y1;
             y1 = y2;
         end
      end
      y(ind) = y1./(1-w).^(v2+m);
   end
   y(z==1) = Inf;
else
   n = (v1-v2)/2;
   v = v2;
   w0 = exp(psi(1)+psi(2*n+1)-psi(v1)-psi(n+0.5));
   z0 = min(max(3,(2-w0)/w0),20);
%
%  When 0<z<1, use recursive relation
%
   ind = find(z>0&z<1);
   if length(ind)>0
      z2a = (1+z(ind)).*(1-z(ind));
      y0 = (pi/2+asin(z(ind)))./sqrt(z2a);
      for k=1:n
          y0 = (k+0.5)/k*(z(ind)+y0)./z2a;
      end
      y1 = ones(size(y0));
      for k=2:v
          y2 = (2*n+2*k-1)*(2*n+2*k-3)/(2*n+k-1)/(k-1)*(z(ind).*y0+y1)./z2a;
          y1 = y0;
          y0 = y2;
      end
      y(ind) = y0;
   end   
%
%  Direct evaluation for -1<=z<0.
% 
   ind = find(z>=-1&z<0);
   if length(ind)>0
      y(ind) = hyper2f1(v1,v,v+n+0.5,z1(ind));      
   end 
%
%  When -3<=z<-1, transform to 
%  (2/(1-z))^v1*2F1(v1,n+1/2,v+n+1/2,(z+1)/(z-1))
% 
   ind = find(z>-z0&z<-1);
   if length(ind)>0
      w = (z(ind)+1)./(z(ind)-1);
      y(ind) = exp(hyper2f1(v1,n+0.5,v+n+0.5,w,1)+v1*log1p(-w));
   end
%
%  When z<-3, transform to hypergeometric functions that involve
%  w = 2/(1-z).
%
   ind = find(z<=-z0);
   if length(ind)>0
      w = 2./(1-z(ind));
      if n==0
         y1 = zeros(size(w));
      else
         c = exp(gammaln(v+n+0.5)+gammaln(2*n)-gammaln(v1)-gammaln(n+0.5)+v*log(w));
         y1 = c;
         for k=1:2*n-1
             c = (n+0.5-k)*(v+k-1)/k/(2*n-k)*c.*w;
             y1 = y1+c;
         end
      end
      g = -log(w)+psi(1)+psi(2*n+1)-psi(v1)-psi(n+0.5);
      c = (-1)^n/pi*exp(gammaln(v+n+0.5)-gammaln(v)-gammaln(2*n+1)+gammaln(n+0.5)+v1*log(w));
      y1i = c.*g;
      for k=1:maxiter
          g = g+1/k+1/(2*n+k)-1/(v1+k-1)-1/(n+k-0.5);
          c = (v1+k-1)*(n-0.5+k)/k/(k+2*n)*c.*w;
          y2 = c.*g;
          y1i = y1i+y2;
          if all(abs(y2./y1i)<tol)
             break
          end
      end
      y(ind) = y1+y1i;
   end
%
%  When 1<=z<3, transform to hypergeometric functions that involve
%  w = (z-1)/(z+1).
%
   ind = find(z>1&z<z0);
   if length(ind)>0
      w = (z(ind)-1)./(z(ind)+1);
% real part
      y1 = (-1)^v*exp(hyper2f1(v1,n+0.5,v+n+0.5,w,1)+v1*log1p(-w));
% imaginary part
      y2 = (-1)^(n+v)*(1-w).^v1.*w.^(-d)*exp(gammaln(v+n+0.5)+gammaln(v+n-0.5)-gammaln(v1)-gammaln(v));
      y1i = y2;
      for k=1:v-1
          y2 = (-v+k)*(n+k-0.5)/(-v-n+0.5+k)/k*w.*y2;
          y1i = y1i+y2;
      end
      y(ind) = y1+y1i*1i;
   end                
%
%  When z>3, transform to hypergeometric functions that involve
%  w = 2/(1+z).
%
   ind = find(z>=z0);
   if length(ind)>0
      w = 2./(1+z(ind));
      if n==0
         y1 = zeros(size(w));
      else
         c = (-1)^v*exp(gammaln(v+n+0.5)+gammaln(2*n)-gammaln(v1)-gammaln(n+0.5)+v*log(w));
         y1 = c;
         for k=1:2*n-1
             c = (n+0.5-k)*(v+k-1)/k/(2*n-k)*c.*w;
             y1 = y1+c;
         end
      end
      g = -log(w)+psi(1)+psi(2*n+1)-psi(v1)-psi(n+0.5);
      c = (-1)^(v+n)/pi*exp(gammaln(v+n+0.5)-gammaln(v)-gammaln(2*n+1)+gammaln(n+0.5)+v1*log(w));
      y1i = c.*g;
      for k=1:maxiter
          g = g+1/k+1/(2*n+k)-1/(v1+k-1)-1/(n+k-0.5);
          c = (v1+k-1)*(n-0.5+k)/k/(k+2*n)*c.*w;
          y2 = c.*g;
          y1i = y1i+y2;
          if all(abs(y2./y1i)<tol)
             break
          end
      end
% imaginary part
      y2 = (-1)^(n+v)*(1-w).^(-n-0.5).*w.^v1*exp(gammaln(v+n+0.5)+gammaln(n+0.5)-gammaln(2*n+1)-gammaln(v));
      y2i = y2;
      w1 = 2./(1-z(ind));
      for k=1:v-1
          y2 = (-v+k)*(n+k-0.5)/(2*n+k)/k*w1.*y2;
          y2i = y2i+y2;
      end
      y(ind) = y1+y1i+y2i*1i;
   end
   y(z==1) = (-1)^v;
end 
%
%  Special cases
%
y(z==0) = sqrt(pi)*exp(gammaln((v1+v2+1)/2)-gammaln((v1+1)/2)-gammaln((v2+1)/2));
% hypergeom([v1 v2],(v1+v2+1)/2,z1)


   