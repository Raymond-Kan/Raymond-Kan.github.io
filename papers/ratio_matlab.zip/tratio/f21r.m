function r=f21r(v1,v2,z,k)
% This function computes
% (v1+k)(v2+k)/((v1+v2+1)/2+k)F_{k+1}/F_k,
% where F_k=2F1(v1+k,v2+k,(v1+v2+1)/2+k,(1+z)/2)
% It is based on the following differential equation:
% z(1-z)F''+[c-(a+b+1)z]F'-a*b*F=0
% It does not work well with negative z because of
% cancellation error.
%
if z==1
   r = NaN;
   return
end
if v1<v2
   temp = v1;
   v1 = v2;
   v2 = temp;
end
d = v1-v2+1;
r = 2*d/(d+2)*f21a(d+1,2,z)/f21a(d,1,z);
for k1=1:v2+k-1
    r = (2*z*(d+2*k1)+4*(d+k1-1)*k1/r)/(1-z^2);
end
%(v1+k)*(v2+k)/((v1+v2+1)/2+k)*f21a(v1+k+1,v2+k+1,z)/f21a(v1+k,v2+k,z)