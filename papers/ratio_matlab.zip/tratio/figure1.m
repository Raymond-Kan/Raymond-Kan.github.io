%
% figure1.m		Date: 3/5/2015
% This Matlab program plots the SPA approximation of the pdf and cdf
% of a ratio of two Student's t r.v.s, for different values of n.
%
clear
close all
subplot = @(m,n,p) subtightplot (m, n, p, [0.1 0.06], [0.1 0.1], [0.1 0.01]);
set(0,'DefaulttextInterpreter','latex')
npoints = 2000;
order = 1;
m1 = 3;
m2 = 2;
s1 = 1;
pr_y_neg=0.25;
%  n = 1;
%
n = 1;
s2=abs(-m2/tinv(pr_y_neg,n))%

xmin = -5;
xmax = 5;
x = linspace(xmin,xmax,npoints);
[pdf,cdf] = trat(x,n,n,m1,m2,s1,s2);

[spapdf1, spacdf1] = tratspa(x,n,n,m1,m2,s1,s2,order);
subplot(3,2,1)
set(gcf,'color','none','inverthardcopy','off')
hold on
h1=plot(x,pdf);
[h2,h3]=dashline(x,spapdf1,2.5,.5,2.5,.5);
hold off
set(h1,'linewidth',.75)
set(h2,'linewidth',.75)
set(h2,'color','r')
%h = legend('Exact','SPA','Location','NorthWest');
%set(h,'FontSize',7)
xlabel('$r$','FontSize',9)
ylabel('$f_R(r)$','FontSize',9)
title(['$\nu_1=\nu_2=' num2str(n) '$'],'FontSize',9)
axis([xmin xmax 0 0.6])
set(gca,'box','off','TickDir','out','FontSize',8,'XTick',[xmin:xmax],'YTick',[0:0.1:0.6])
set(gca, 'color', 'none');
subplot(3,2,2)
hold on
h1=plot(x,cdf);
[h2,h3]=dashline(x,spacdf1,2.5,.5,2.5,.5);
hold off
set(h1,'linewidth',.75)
set(h2,'linewidth',.75)
set(h2,'color','r')
%h = legend('Exact','SPA','Location','NorthWest');
%set(h,'FontSize',7)
xlabel('$r$','FontSize',9)
ylabel('$F_R(r)$','FontSize',9)
title(['$\nu_1=\nu_2=' num2str(n) '$'],'FontSize',9)
axis([xmin xmax 0 1])
set(gca,'box','off','TickDir','out','FontSize',8,'XTick',[xmin:xmax],'YTick',[0:0.2:1])
set(gca, 'color', 'none');
%
%  n = 3;
%
n = 3;
s2=abs(-m2/tinv(pr_y_neg,n))%
xmina = -5;
xmaxa = 5;
xa = linspace(xmina,xmaxa,npoints);
[pdfa,cdfa]=trat(xa,n,n,m1,m2,s1,s2);
[spapdf1a, spacdf1a] = tratspa(xa,n,n,m1,m2,s1,s2,order);
subplot(3,2,3)
hold on
h1=plot(xa,pdfa);
[h2,h3]=dashline(xa,spapdf1a,2.5,.5,2.5,.5);
hold off
set(h1,'linewidth',.75)
set(h2,'linewidth',.75)
set(h2,'color','r')
%h = legend('Exact','SPA','Location','NorthWest');
%set(h,'FontSize',7)
xlabel('$r$','FontSize',9)
ylabel('$f_R(r)$','FontSize',9)
title(['$\nu_1=\nu_2=' num2str(n) '$'],'FontSize',9)
axis([xmina xmaxa 0 0.6])
set(gca,'box','off','TickDir','out','FontSize',8,'XTick',[xmina:xmaxa],'YTick',[0:0.1:0.6])
set(gca, 'color', 'none');
subplot(3,2,4)
hold on
h1=plot(xa,cdfa);
[h2,h3]=dashline(xa,spacdf1a,2.5,.5,2.5,.5);
hold off
set(h1,'linewidth',.75)
set(h2,'linewidth',.75)
set(h2,'color','r')
%h = legend('Exact','SPA','Location','NorthWest');
%set(h,'FontSize',7)
xlabel('$r$','FontSize',9)
ylabel('$F_R(r)$','FontSize',9)
title(['$\nu_1=\nu_2=' num2str(n) '$'],'FontSize',9)
axis([xmina xmaxa 0 1])
set(gca,'box','off','TickDir','out','FontSize',8,'XTick',[xmina:xmaxa],'YTick',[0:0.2:1])
set(gca, 'color', 'none');
%
%  n = 5;
%
n = 5;
s2=abs(-m2/tinv(pr_y_neg,n))%

xminb = -5;
xmaxb = 5;
xb = linspace(xminb,xmaxb,npoints);
[pdfb,cdfb]=trat(xb,n,n,m1,m2,s1,s2);
[spapdf1b, spacdf1b] = tratspa(xb,n,n,m1,m2,s1,s2,order);
subplot(3,2,5)
hold on
h1=plot(xb,pdfb);
[h2,h3]=dashline(xb,spapdf1b,2.5,.5,2.5,.5);
hold off
set(h1,'linewidth',.75)
set(h2,'linewidth',.75)
set(h2,'color','r')
%h = legend('Exact','SPA','Location','NorthWest');
%set(h,'FontSize',7)
xlabel('$r$','FontSize',9)
ylabel('$f_R(r)$','FontSize',9)
title(['$\nu_1=\nu_2=' num2str(n) '$'],'FontSize',9)
axis([xminb xmaxb 0 0.6])
set(gca,'box','off','TickDir','out','FontSize',8,'XTick',[xminb:xmaxb],'YTick',[0:0.1:0.6])
set(gca, 'color', 'none');
subplot(3,2,6)
hold on
h1=plot(xb,cdfb);
[h2,h3]=dashline(xb,spacdf1b,2.5,.5,2.5,.5);
hold off
set(h1,'linewidth',.75)
set(h2,'linewidth',.75)
set(h2,'color','r')
%h = legend('Exact','SPA 1','Location','NorthWest');
%set(h,'FontSize',7)
xlabel('$r$','FontSize',9)
ylabel('$F_R(r)$','FontSize',9)
title(['$\nu_1=\nu_2=' num2str(n) '$'],'FontSize',9)
axis([xminb xmaxb 0 1])
set(gca,'box','off','TickDir','out','FontSize',8,'XTick',[xminb:xmaxb],'YTick',[0:0.2:1])
set(gca, 'color', 'none');
set(gcf,'PaperUnits','Inches','PaperPosition',[0 0 6.5 5]); 
set(gcf,'color','none','inverthardcopy','off')
print -depsc figure1.eps
!epstopdf figure1.eps

