function y = hyper2f1(a,b,c,w,ln)
%
%  This function computes 2F1(a,b;c;w)  
%  If ln=1, returns log(2F1(a,b;c;w))
%
if nargin<5
   ln = 0;
end
y = zeros(size(w));
maxcount = 50000;
lnsr2pi = 0.9189385332046727417803297364056;  % log(sqrt(2*pi))
tol = 1e-16;
for i=1:numel(w)
    w1 = w(i);
%
%  Find the term kMax that maximizes (v+2n)_k*(v)_k*w^k/(v+n+1/2)_k/k!
%
   if w1>c/(a*b)
      a1 = 1-c+(a+b-2)*w1; 
      d1 = sqrt(a1^2+4*(a-1)*(b-1)*w1*(1-w1));
      kMax = floor((a1+d1)/(2*(1-w1)));
   else
      kMax = 0;
   end
%
%  Set z to be the natural log of (v+2*n)_k(v)_kw^k/(v+n+1/2)_k/k!
%
   if kMax<10&&max([a b c])<10
      z = log(gamma(a+kMax)/gamma(a)*gamma(b+kMax)/gamma(b)*gamma(c)/gamma(c+kMax));
   else
%  This term can probably be improved   
      z = gammaln(a+kMax)-gammaln(a)+gammaln(b+kMax)-gammaln(b)+gammaln(c)-gammaln(c+kMax);
   end
   if kMax>w1*realmin
      z = z-lnsr2pi-0.5*log(kMax)-stirlerr(kMax)-bd0(kMax,w1)+w1;
   end
%
%   First accumlate the terms with k<kMax and
%   then accumlate the terms with k>kMax. 
%
   count1 = 0;
   count2 = 0;
   c1 = 0;
   term = 1;
   k = kMax;
   while k>0&&term>c1*tol&&count1<maxcount 
      count1 = count1+1;
      k = k-1;
      term = term*(k+1)*(k+c)/(k+a)/(k+b)/w1;
      c1 = c1+term;
   end
   term = w1*(kMax+a)*(kMax+b)/(kMax+c)/(kMax+1);
   c2 = term;
   k = kMax+1;
   while term>c2*tol&&count2<maxcount
      count2 = count2+1;
      term = term*w1*(k+a)*(k+b)/(k+c)/(k+1);
      c2 = c2+term;
      k = k+1;
   end
   if ln
      y(i) = z+log1p(c1+c2);
   else
      y(i) = exp(z)*(1+c1+c2);
   end
end

function z = stirlerr(n)
%
%   This function computes the error of 
%   Stirling's approximation of ln(n!)
%   which suggests
%   ln(n!) \approx (n+0.5)*ln(n)-n+ln(sqrt(2*pi))
%
% error for 0, 0.5, 1.0, 1.5, ..., 14.5, 15.0.
sferr_halves =[0.0,... 
	0.1534264097200273452913848,...  % 0.5 %
	0.0810614667953272582196702,...  % 1.0 %
	0.0548141210519176538961390,...  % 1.5 %
	0.0413406959554092940938221,...  % 2.0 %
	0.03316287351993628748511048,... % 2.5 %
	0.02767792568499833914878929,... % 3.0 %
	0.02374616365629749597132920,... % 3.5 %
	0.02079067210376509311152277,... % 4.0 %
	0.01848845053267318523077934,... % 4.5 %
	0.01664469118982119216319487,... % 5.0 %
	0.01513497322191737887351255,... % 5.5 %
	0.01387612882307074799874573,... % 6.0 %
	0.01281046524292022692424986,... % 6.5 %
	0.01189670994589177009505572,... % 7.0 %
	0.01110455975820691732662991,... % 7.5 %
	0.010411265261972096497478567,... % 8.0 %
	0.009799416126158803298389475,... % 8.5 %
	0.009255462182712732917728637,... % 9.0 %
	0.008768700134139385462952823,... % 9.5 %
	0.008330563433362871256469318,... % 10.0 %
	0.007934114564314020547248100,... % 10.5 %
	0.007573675487951840794972024,... % 11.0 %
	0.007244554301320383179543912,... % 11.5 %
	0.006942840107209529865664152,... % 12.0 %
	0.006665247032707682442354394,... % 12.5 %
	0.006408994188004207068439631,... % 13.0 %
	0.006171712263039457647532867,... % 13.5 %
	0.005951370112758847735624416,... % 14.0 %
	0.005746216513010115682023589,... % 14.5 %
	0.005554733551962801371038690]';  % 15.0 %
if n<=15
   nn = n+n;
   if mod(nn,1)==0 
      z = sferr_halves(nn+1); %note: in C, the index of an array starts at 0;
   else
      lnsr2pi = 0.9189385332046727417803297364056;  % log(sqrt(2*pi))
      z = gammaln(n+1)-(n+0.5)*log(n)+n-lnsr2pi;
   end
   return
end
S0 = 0.083333333333333333333;       % 1/12 %
S1 = 0.00277777777777777777778;     % 1/360 %
S2 = 0.00079365079365079365079365;  % 1/1260 %
S3 = 0.000595238095238095238095238; % 1/1680 %
S4 = 0.0008417508417508417508417508;% 1/1188 %
nn = n*n;
if n>500 
   z = ((S0-S1/nn)/n);
   return
end
if n>80 
   z = ((S0-(S1-S2/nn)/nn)/n);
   return
end
if n>35 
   z = ((S0-(S1-(S2-S3/nn)/nn)/nn)/n);
   return
end
% 15 < n <= 35 : %
z = ((S0-(S1-(S2-(S3-S4/nn)/nn)/nn)/nn)/n);

function z = bd0(x,np)
% This function evaluates the "deviance part" 
% bd0(x,np) = x*log(x/np)+np-x for x, np>0
if isinf(x)||isinf(np)||np==0 
   z = NaN;
   return
end 
if abs(x-np)<0.1*(x+np)
   v = (x-np)/(x+np);
   s = (x-np)*v;
   ej = 2*x*v; 
   v = v*v;
   j = 3;
   while j>0
      ej = ej*v;
      z = s+ej/j;           
      if z==s
         return
      end
      s = z;
      j = j+2;
   end
end
z = x*log(x/np)+np-x;
