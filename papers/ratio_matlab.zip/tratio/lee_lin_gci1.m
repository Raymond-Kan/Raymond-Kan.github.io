function lee_lin_gci1()
%Example from Finney (1978, Table 2.3.1)

Ubar = 19.9;
Vbar = 16.8;
sU = sqrt(68.15);
sV = sqrt(75.87);
nU = 7;
nV = 7;
a = Ubar;
b = -sU/sqrt(nU-1);
c = Vbar;
d = -sV/sqrt(nV-1);
alpha= 0.05;

pr_y_neg=tcdf(-c/abs(d),nV-1);
cl = tratquantile(alpha/2,nU-1,nV-1,a,c,b,d)
cu = tratquantile(1-alpha/2,nU-1,nV-1,a,c,b,d)

cl_spa = tratquantile_spa(alpha/2,nU-1,nV-1,a,c,b,d,1)
cu_spa = tratquantile_spa(1-alpha/2,nU-1,nV-1,a,c,b,d,1)

