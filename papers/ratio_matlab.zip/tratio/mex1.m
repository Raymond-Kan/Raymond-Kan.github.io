mex -I. -largeArrayDims -c mexinterface_c.f90
mex -I. -largeArrayDims -c dgamma.f
mex -I. -largeArrayDims -c dlgama.f90
mex -I. -largeArrayDims f21a.f90 mexinterface_c.obj dgamma.obj dlgama.obj
