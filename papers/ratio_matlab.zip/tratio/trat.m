function [f,F]=trat(rvec,n1,n2,m1,m2,s1,s2)
f=zeros(size(rvec));
if nargout>1,
    F=zeros(size(rvec));
end
s1=abs(s1);s2=abs(s2);
for jj=1:numel(rvec)
    r=rvec(jj);
    f(jj)=quadgk(@(y)abs(y).*tpdf((r*y-m1)/s1,n1).*tpdf((y-m2)/s2,n2),-inf,inf)/s1/s2;
    if nargout>1,
        F(jj)=quadgk(@(y)tpdf((y-m2)/s2,n2).*(sign(y).*tcdf((r*y-m1)/s1,n1)+(y<0)),-inf,inf)/s2;
    end
end
% rpisq2=0.101321183642338;
% tol=1e-5;
% myquad = @(fun,a,b,tol,trace,varargin) quadgk(@(x)fun(x,varargin{:}),a,b,'AbsTol',tol);
% f=zeros(size(rvec));
% for jj=1:numel(rvec)
%     r=rvec(jj);
% F(jj)=0.5+rpisq2*dblquad(@(s,t) integd(s,t),0,Inf,0,inf,tol,myquad);
% end;
% 
% 
% function I=integd(s,t)
%     I=real(cf(s,t-r*s)-cf(s,-t-r*s))./(s.*t);
% end
% function phi=cf(s,t)
% M=(gamma(n1/2)*2^(n1/2-1)*gamma(n2/2)*2^(n2/2-1))^(-1);
% phi=M*exp(1i*s*m1).*besselk(n1/2,s1*s*sqrt(n1)).*sqrt(n1*s1^2*s.^2).^(n1/2).*exp(1i*t*m2).*besselk(n2/2,sqrt(n2*s2^2*t.^2)).*sqrt(n2*s2^2*t.^2).^(n2/2);
% 
% end
% function phi=cf2(s,t)
% 
% phi=exp(tratcgf(s,t,n1,n2,m1,m2,s1,s2));
% end
end
