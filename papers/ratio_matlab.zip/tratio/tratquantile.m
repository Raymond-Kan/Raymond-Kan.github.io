function [q] = tratquantile(alpha,n1,n2,m1,m2,s1,s2)
%[q] = tratquantile(alpha,n1,n2,m1,m2,s1,s2)
%
%Computes the 100*alpha percent quantile of
%(m1+s1*T_1)/(m2+s2*T_2), T_i ~ t(n_i) independently.
%
%Reference: Broda, S.A., and Kan, R. (2015), "On Distributions
%of Ratios".
if ~isscalar(alpha), error('alpha must be scalar.');end
options=optimset('disp','none');
if m2==0
    rstart=0;
else
    rstart=norminv(alpha,m1/m2,sqrt((s1^2+(m1*s2/m2)^2)/m2^2));
end
q=fzero(@(r)cdf(r)-alpha,rstart,options);
    function F=cdf(r)
        [~,F]=trat(r,n1,n2,m1,m2,s1,s2);
    end
end