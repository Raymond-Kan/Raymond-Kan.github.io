mex -v rank1up.f ndlaed9.f
