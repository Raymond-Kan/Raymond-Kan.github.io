      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      integer plhs(*), prhs(*)
      integer nlhs, nrhs
      integer mxcreatedoublematrix,mxgetpr 
      integer mxduplicatearray
      integer mxgetm
      integer work
      integer d,z,rho,n,Q,icompq,lwork,n1,lambda
   
      d = mxgetpr(mxduplicatearray(prhs(1)))
      z = mxgetpr(mxduplicatearray(prhs(2)))
      rho = mxgetpr(mxduplicatearray(prhs(3)))
      n = mxgetm(prhs(1))
      lwork = n
      plhs(1) = mxcreatedoublematrix(n-1,1,0)
      work = mxgetpr(mxcreatedoublematrix(lwork,1,0))
      lambda = mxgetpr(plhs(1))    
      call ndlaed9(n,%val(lambda),%val(work),%val(rho),
     *%val(d),%val(z))
      return
      end
