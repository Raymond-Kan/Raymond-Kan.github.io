%
% covrho.m		Date: 1/11/2004
% This Matlab program computes the exact covariance of \hat\rho(k_1) and 
% \hat\rho(k_2) under the null hypothesis assuming normality and constant 
% volatility.
% n: length of time series
% k1/k2: two different lags of autocorrelations
%
function y = covrho(n,ka,kb)
index = n<=ka|n<=kb|ka<0|kb<0;
y1 = max(n-ka-kb,0)-max(ka-kb,0);
ke = ka==kb;
n2 = n.*n;
n2a = n2-1;
y = -2*(n-kb).*(n.*(ka+1)-2*ka)./((n-1).*n2.*n2a) ...
    -2*y1./(n.*n2a)+ke.*(n-ka)./n2a;
y(index) = NaN;
