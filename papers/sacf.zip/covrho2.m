%
% covrho2.m		Date: 5/11/2006
% This Matlab program computes the exact covariance of \hat\rho^2(j) and 
% \hat\rho^2(k) under the null hypothesis assuming normality and constant 
% volatility.
% n: length of time series
% j/k: two different lags of autocorrelations
%
function y = covrho2(n,j,k)
%
%   Note that min(j,k)=j-d, max(j,k)=k+d, where d=(j-k)^+
%
d = max(j-k,0);
j = j-d;
k = k+d;
v1 = max(n-2*j,0);
v2 = max(n-2*k,0);
v3 = max(n-j-k,0);
v4 = max(n+j-2*k,0);
v5 = max(n-j-2*k,0);
v6 = max(n-2*j-k,0);
v7 = max(n-2*j-2*k,0);
v8 = max(2*j,k);
v9 = max(n-v8,0);
v10 = max(n+2*j-2*v8,0);
v11 = j==k;
v12 = 2*j==k;
n2 = n.*n;
n3 = n2.*n;
n4 = n2.*n2;
muj2 = ((n-j).*(n2+n-3*j)-2*n.*v1)./(n4-n2);
muk2 = ((n-k).*(n2+n-3*k)-2*n.*v2)./(n4-n2);
n1 = (n4-n2).*(n+3).*(n+5);
a1 = 105*j.*j.*k-(75*j.*j+60*j.*k).*n+(36*j-3*j.*j+15*k-3*j.*k).*n2+(5*j+3*k-5).*n3+((j-6).*n2-n3).*n2;
a2 = (15*k.*k-24*n.*k+9*n2-n2.*k+n3).*v1+(15*j.*j+9*n2-n2.*j+n3).*v2+(60*j.*k-24*j.*n-4*n3).*v3;
a3 = 6*(n-3*j).*v5+6*(n-3*k).*v6+2*(n-3*j).*v4-12*n.*v7+4*(2*n-3*k).*v9-2*n.*v10-2*n.*(n-k).^2.*v12+ ...
     ((n-k).*(n3+3*n2-k.*n2-8*n.*k+6*k.^2)-2*n.*(n-2*k).*v2).*v11;
mujk2 = -(n-k).*a1./(n2.*n1)-2*a2./(n.*n1)+2*a3./n1;
y = mujk2-muj2.*muk2;
