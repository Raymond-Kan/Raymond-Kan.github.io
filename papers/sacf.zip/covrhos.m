%
% covrhos.m		Date: 1/11/2004
% This Matlab program computes the exact covariance of \hat\rho(k_1) and 
% \hat\rho(k_2) under the null hypothesis assuming normality and constant 
% volatility.
% n: length of time series
% k1/k2: two different lags of autocorrelations
%
function y = covrhos(n,ka,kb)
index = n<=ka|n<=kb|ka<0|kb<0;
y1 = sym(max(n-ka-kb,0)-max(ka-kb,0));
ke = sym(ka==kb);
ns = sym(n);
ns2 = ns.*ns;
ns2a = ns2-1;
y = -2*(ns-kb).*(ns.*(ka+1)-2*ka)./((ns-1).*ns2.*ns2a) ...
    -2*y1./(ns.*ns2a)+ke.*(ns-ka)./ns2a;
y(index) = NaN;
