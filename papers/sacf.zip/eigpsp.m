%
% eigpsp.m		Date: 5/13/2006
% This Matlab program computes the eigenvalues of P'SP, where
% S is an nxn symmetric Toeplitz matrix and P is an nx(n-1) orthonormal 
% matrix that is orthogonal to 1_n.
% Input: 
% a: the vector of the first row of the Toeplitz matrix
%
function y = eigpsp(a)
[m,n] = size(a);
if m>n
   a = a';
   n = m;
end
odd = rem(n,2)==1;
n1 = ceil(n/2);
n2 = n1-odd;
r = [1:n2]'*ones(1,n2);
s = ones(n2,1)*[1:n2];
index1 = abs(r-s)+1;
index2 = (n+2)-(r+s);
B1 = a(index1);
B2 = a(index2);
A1 = B1+B2;
A2 = B1-B2;
if odd,
   P = (eye(n2)-2/(n+sqrt(n)));
   x = (2/sqrt(n))*ones(n2,1)*a(n1:-1:2)*P;
   A1 = P'*A1*P+2*a(1)/n-(x+x');
else
   P = [eye(n1-1)-1/(n1+sqrt(n1)); -(1/sqrt(n1))*ones(1,n1-1)];
   A1 = P'*A1*P;
end
y = sort([eig(0.5*(A1+A1')); eig(A2)],1,'descend');
