%
% eigrange.m		Date: 3/11/2004
% This Matlab program computes the range of the eigenvalues
% of a symmetric Toeplitz matrix P_n'A_kP_n, where A_k = 1/2*[0_k 1 0_{n-k-1}]
% and P_n is an nx(n-1) matrix orthogonal to 1_n.
%	
function [minxi,maxxi] = eigrange(n,k)
m = fix(n/k);
l = rem(n,k);
if (k==1&&rem(n,2)==1)||(k>1&&l==1)
   x2 = [1:m]';
   d2 = cos(x2*pi/(m+1));
   if rem(m,2)==1
      d2((m+1)/2) = 0;
   end
   d2e = d2(1:2:end);
   t2 = x2(1:2:end)*pi./(2*m+2);
   if l==0
      de = d2e;
      qe = 2*sqrt(k/(m+1))*(csc(t2)-sin(t2));
   else
      x1 = [1:m+1]';
      t1 = x1(1:2:end)*pi./(2*m+4);
      d1 = cos(x1*pi/(m+2));
      if rem(m,2)==0
         d1(m/2+1) = 0;
      end
      d1e = d1(1:2:end);
      de = [d1e; d2e];
      qe = [2*sqrt(l)/sqrt(m+2)*(csc(t1)-sin(t1)); 2*sqrt(k-l)/sqrt(m+1)*(csc(t2)-sin(t2))];
      [de,ii] = sort(de,1,'descend');
      qe = qe(ii);
   end
   de1 = rankone(de,qe,-1/n);
end
if k==1
   maxxi = cos(2*pi/(n+1));
   if rem(n,2)==1
      minxi = de1(end);
   else
      minxi = -cos(pi/(n+1));
   end  
elseif l==0
       minxi = -cos(pi/(m+1));
       maxxi = cos(pi/(m+1));
elseif l==1
       maxxi = de1(1);
       if rem(m,2)==1      
          minxi = -cos(pi/(m+2));
       else
          minxi = de1(end);
       end
else
    minxi = -cos(pi/(m+2));
    maxxi = cos(pi/(m+2));
end 
