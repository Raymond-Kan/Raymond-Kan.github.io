%
% eigslow.m		Date: 3/11/2004
% This Matlab program computes the eigenvalues and eigenvectors
% of a symmetric Toeplitz matrix P_n'A_kP_n, where A_k = 1/2*[0_k 1 0_{n-k-1}]
% and P_n is an nx(n-1) symmetric matrix.  It uses a slow algorithm.
%	
function y = eigslow(n,k)
A = toeplitz([zeros(1,k) 1/2 zeros(1,n-k-1)]);
P = null(ones(1,n));
AA = P'*A*P;
y = sort(eig(0.5*(AA+AA')),1,'descend');
