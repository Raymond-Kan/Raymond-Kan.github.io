%
% ilinrhocdf.m		Date: 2/26/2004
% This Matlab program computes the inverse CDF of of a linear combination 
% of \hat\rho(k) under the normality assumption and Sigma = \sigma^2 I_n
% Input
% n: length of time series 
% a: [a_0, a_1, ... a_m] which indicates the random variable is
%    X = a_0+a_1\hat\rho(1)+...+a_m\hat\rho(m)
% prob: quantile of X
% init: initial estimate of the inverse CDF of X
% d: eigenvalues of P'AP, where A = a0*A_0+a1*A_1+...+a_m*A_m.
%
function y = ilinrhocdf(prob,n,a,init,d)
if nargin<5
   a(2:end) = 0.5*a(2:end);
   if length(a)<n
      a(end+1:n) = 0;
   end
   d = eigpsp(a);
end
if nargin<4
   init = zeros(size(prob));
end
y = zeros(size(prob));
for i=1:numel(prob);
    y(i) = fzero(@linchi2a,init(i),[]);
end

function y = linchi2a(c)
   if c>d(1)
      y = 1;
   elseif c<d(end)
      y = -1;
   else
      y = linchi2b(0,d-c,ones(size(d)))-prob(i);
   end
end

end
