%
% irhocdfb.m		Date: 2/26/2004
% This Matlab program computes the inverse CDF of \hat\rho(k)
% the normality assumption and Sigma = \sigma^2 I_n
%
function y = irhocdfb(prob,n,k,init,d0,r0)
if nargin<5
   [d0 r0] = eigpapb(n,k);
end
if nargin<4
   y1 = max(n-2*k,0);
   varrho = (n-k).*(n-2).*(n.^2+n-2*k)./((n-1).^2.*n.^2.*(n+1))-2*y1./(n.*(n.^2-1));
   init = norminv(prob)*sqrt(varrho);
end
y = zeros(size(prob));
for i=1:numel(prob);
    y(i) = fzero(@linchi2a,init(i),[]);
end

function y = linchi2a(c)
   if c>d0(1)
      y = 1;
   elseif c<d0(end)
      y = -1;
   else
      y = linchi2b(0,d0-c,r0)-prob(i);
   end
end

end