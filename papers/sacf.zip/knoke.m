%
% knoke.m        Date: 3/27/2006
% This Matlab program computes the exact mean and variance of Knoke's (1977)
% statistic
% n: length of time series
% mut : E[T]
% vart: Var[T]
%
function [mut,vart] = knoke(n);
h = (psi(n+1)-psi(1))./(n-1);
h1 = psi(1,1)-psi(1,n+1);
mut = 1./(n-1)-h;
n2 = n.*n;
vart = (n+2).*h1./(n2-1)-2*n.*h.*h./(n+1)+ ...
       (3*n2+3*n-2).*h./((n2-1).*n)-2*(3*n-2)./((n-1).*(n2-1));
