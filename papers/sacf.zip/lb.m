%
% lb.m        Date: 3/27/2006
% This Matlab program computes the exact mean and variance of Ljung-Box
% Q-statistic
% n: length of time series
% m: number of lags
% qmu : E[Q_{LB}(m)]
% qvar: Var[Q_{LB}(m)]
%
function [qmu,qvar] = lb(n,m)
h = max(m-fix(n/2),0);
qmu = ((n+2)/(2*n*(n^2-1)))*(m*(2*n*(n-3)-3*(m+1))+4*n*(2*h+n*(psi(n)-psi(n-m+h))));
qvar = n*n*covrho2(n,1,1)*((n+2)/(n-1))^2;
for i=2:m
    a = n*n*covrho2(n,i,[1:i]);
    qvar = qvar+2*((n+2)/(n-i))*(n+2)*sum(a./[n-1:-1:n-i])-a(end)*((n+2)/(n-i))^2;
end
