% 
% lhr.m         Date: 2006/05/01
% This Matlab program calculates the exact mean and variance of the long
% horizon regression test statistic
% mlhr: E[\hat\beta(m)] 
% vlhr: Var[\hat\beta(m)] 
% n: the length of the time series
% m: the length of multiperiods

function [mlhr vlhr] = lhr(n,m)
mlhr = -m.*(n-m)./(n.*(n-1));
f = 2*(m.^2).*(m-n).*(-2*m+n+m.*n)./((n-1).^2.*n.^2.*(n+1));
g = -(m-n).*(2*m.^2+1)/(3.*m.*(n-1).*(n+1));
v1 = (m-1).*(m+1).*(7*m.^2+2)/(15.*m.*(n-1).*n.*(n+1));
ff = -2./(n.*(n.^2-1).*m.^2);
vv = m.^4.*(-2*m+n)+max(4*m-n-2,0).*(4*m-n-1).*(4*m-n).*(4*m-n+1).*(4*m-n+2)/120-...
     max(3*m-n-2,0).*(3*m-n-1).*(3*m-n).*(3*m-n+1).*(3*m-n+2)/30;
vlhr = f+g+v1+ff.*vv;
