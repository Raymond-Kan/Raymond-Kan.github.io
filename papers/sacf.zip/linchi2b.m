%
% linchi2b.m	Date: 2/13/2004
% This Matlab program computes the probability that a linear combination
% of central chi-squared distribution (with r_i d.f.) is less than a constant c.
% d0: distinct weights of the linear combination
% r0: degree of freedom of each chi-squared RV (d.f.)
% e: accuracy (1e-10 by default)
% delta: step size
% U: upper truncation point
%
function y = linchi2b(c,d0,r0,e)
if all(d0>=0)&&c<=0
   y = 0;
   return
end
if all(d0<=0)&&c>=0
   y = 1;
   return
end
if size(d0,1)==1
   d0 = d0';
end
if size(r0,1)==1
   r0 = r0';
end
%
%	Sorting and normalization
%
index = find(d0==0);    % Get rid of zero elements
d0(index) = [];
r0(index) = [];
[d,ii] = sort(d0);
r = r0(ii);
n = length(d);
if n==1     % Using chi-squared distribution
   if d(1)>0
      y = chi2cdf(c/d(1),r(1));
   else
      y = 1-chi2cdf(c/d(1),r(1));
  end
  return
end
if c==0 		% Using F-distribution for this special case
   if n==2
      y = fcdf(-d(1)*r(1)/(d(2)*r(2)),r(2),r(1));
      return
   end
end
if nargin<=3
   e = 1e-10;
end
dmax = max(abs(d));
d = d./dmax;
c = c/dmax;
absd = abs(d);
ei = log(0.1*e);	% log of integration error
et = log(0.9*e);	% log of truncation error
%
%	Choosing delta and K for integration
%
psi1 = 0;
psi2 = 0;
mar = 1e-9;
OPTIONS = optimset('TolFun',log(1.1));
if d(1)<0
   t1 = fzero(@lin1,[1/(2*d(1))+mar -mar],OPTIONS);
   psi1 = sum(r.*d./(1-2*t1*d));
% When c is a very large negative number, no need to worry P[X<c-2*pi/delta]<E_I 
%	but need to worry P[X<c+2*pi/delta]<E_I.
end
if r(end)>0
   t2 = fzero(@lin1,[mar 1/(2*d(end))-mar],OPTIONS);
   psi2 = sum(r.*d./(1-2*t2*d));
end
delta = 2*pi*min(1/max(c-psi1,eps),1/max(psi2-c,eps));
%
%	Imhof truncation bound
%
sd = sum(r.*log(absd));
q = sum(r);
a = exp(-(sd+2*et)/q);	% To avoid overflow problem
U1 = 0.5*a*((2/(q*pi))^(2/q));
%
%	AKS truncation bound
%
OPTIONS1 = optimset('fzero');
d2 = d.*d;
U2 = abs(fzero(@(u) lin2(u,exp(et)),1,OPTIONS1));
%
%	Lu and King truncation bound
%
q1 = q-0.5;
a = exp(-(sd+0.25*log(sum(r./d2))+2*et)/q1);		% To avoid overflow problem
U3 = 0.5*a*((2^(0.75)/(q1*pi))^(2/q1));
[U1 U2 U3];
UU = min([U1 U2 U3]);
K = ceil(UU/delta-0.5);
%
%	Consider further splitting in case of large K
%
if K>5000
   [Umin,ii] = min([U1 U2 U3]);
   V = zeros(1,9);
   alpha = [1:9]/10;
   et2 = log(alpha)+et;
   if ii==1
      a = exp(-(sd+2*et2)/q);	% To avoid overflow problem
      U = 0.5*a*((2/(q*pi))^(2/q));
   end
   if ii==2
      U = zeros(1,9);   
      for i=1:9,
          U(i) = abs(fzero(@(u) lin2(u,exp(et2(i))),1,OPTIONS1));
      end
   end
   if ii==3
      a = exp(-(sd+0.25*log(sum(r./d2))+2*et2)/q1);	% To avoid overflow problem
      U = 0.5*a*((2^(0.75)/(q1*pi))^(2/q1));
   end
   for i=1:9
       V(i) = fzero(@lin3,[1e-12 1-1e-12]*U(i),OPTIONS1);
   end
   UU = min([Umin V]);
   K = ceil(UU/delta-0.5);
end
if K>2000000
   fprintf(' K = %10.0f, should consider reducing the precision.\n',K)
   y = NaN;
else
   index = 0.5:1:K+0.5;
   u = index*delta;
   du = 2*d*u;
   thetak = 0.5*(r'*atan(du))-c*u;
   gk = prod((1+du.*du).^(r*ones(1,size(index,2)))).^(1/4);
   y = 0.5-sum(sin(thetak)./(gk.*index))/pi;
   y = min(max(y,0),1);
end

function y = lin1(t)
   x = 1-2*t*d;
   y = 0.5*sum(r.*log(x))+t*sum(r.*d./x)+ei;
end

function y = lin2(u,P1)
   x = 1+4*u*u*d2;
   y = sum(r.*log(x))-log(1+(2/(pi*P1))^4);
end

function y = lin3(v)
   x = 1+4*v*v*d2;
   y = 0.25*sum(log(x))+log(1-alpha(i))+et-log(log(U(i)/v));
end

end
