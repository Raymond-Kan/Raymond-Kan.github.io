%
% linrhocdf.m		Date: 5/13/2006
% This Matlab program computes the CDF of a linear combination of \hat\rho(k) 
% under the normality assumption.
% Input: 
% n: length of time series 
% a: [a_0, a_1, ... a_m] which indicates the random variable is
%    X = a_0+a_1\hat\rho(1)+...+a_m\hat\rho(m)
% c: P[X<c] 
% d: eigenvalues of P'AP, where A = a0*A_0+a1*A_1+...+a_m*A_m.
%
function y = linrhocdf(c,n,a,d)
if nargin<4
   a(2:end) = 0.5*a(2:end);
   if length(a)<n
      a(end+1:n) = 0;
   end
   d = eigpsp(a);
end
y = zeros(size(c));
for i=1:numel(c)
    if c(i)<=d(end)
       y(i) = 0;
    elseif c(i)>=d(1)
       y(i) = 1;
    else
       y(i) = linchi2b(0,d-c(i),ones(size(d)));
    end
end
