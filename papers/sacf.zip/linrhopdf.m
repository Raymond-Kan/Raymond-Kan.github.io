%
% linrhopdf.m		Date: 5/13/2006
% This Matlab program computes the PDF of a linear combination of \hat\rho(k) 
% under the normality assumption.  It uses the Geary (1944) formula as
% explained in Broda and Paolella (2009).
% Input: 
% n: length of time series 
% a: [a_0, a_1, ... a_m] which indicates the random variable is
%    X = a_0+a_1\hat\rho(1)+...+a_m\hat\rho(m)
% c: f_X(c) 
% d: eigenvalues of P'AP, where A = a0*A_0+a1*A_1+...+a_m*A_m.
%
function y = linrhopdf(c,n,a,d)
if nargin<4
   a(2:end) = 0.5*a(2:end);
   if length(a)<n
      a(end+1:n) = 0;
   end
   d = eigpsp(a);
end
r2pi = 0.15915494309189533577;  % 1/(2*pi)
y = zeros(size(c));
for i=1:numel(c)
    if c(i)<d(end)||c(i)>d(1)
       y(i) = 0;
    else
       wgt = d-c(i);
       y(i) = r2pi*quadgk(@integrand,0,inf,'AbsTol',1e-8);
    end
end

function y1 = integrand(u)
   p = wgt*u;
   d1 = 1./(1+p.*p);
   beta = 0.5*sum(atan(p));
   rho = sum(d1);
   delta = wgt'*d1;
   y1 = (cos(beta).*rho-u.*sin(beta).*delta).*(prod(d1).^0.25);
end

end
