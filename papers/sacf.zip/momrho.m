%
% momrho.m		Date: 1/11/2004
% This Matlab program computes the first s noncentral and central moments of 
% \hat\rho(k) under the null hypothesis that assumes i.i.d. normality 
% Input:
% n: length of time series
% k: lag of autocorrelation
% s: order of moments 
% Output:
% y: first s noncentral moments of \hat\rho(k)
% yc: first s central moments of \hat\rho(k)
%
function [y,yc] = momrho(n,k,s)
[xi r] = eigpapb(n,k);
y = ones(1,s+1);
a = zeros(1,s);
xi1 = 2*xi;
a(1) = r'*xi;
for i=2:s
    xi = xi.*xi1;
    a(i) = r'*xi;
end
c = [1 cumprod([1:s-1])];
for i=1:s
    c1 = round(c(i)./c(1:i));
    y(i+1) = sum(c1.*a(i:-1:1).*y(1:i));
end
y = y(2:end)./cumprod([n-1:2:n-3+2*s]);
%
%  Computation of central moments
%
if nargout>1
   yc = zeros(1,s);
   for i=2:s
       yc(i) = y(i);
       sgn = 1;
       c = 1;
       for j=1:i-1
           sgn = -sgn;
           c = c*(i+1-j)/j;
           yc(i) = yc(i)+sgn*c*y(i-j)*y(1)^j;
       end
       yc(i) = yc(i)-sgn*y(1)^i;
   end
end
