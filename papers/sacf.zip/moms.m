%
% moms.m		Date: 1/11/2004
% This Matlab program computes the first five central and noncentral moment of 
% \hat\rho^2(k) under the null hypothesis assuming normality and constant 
% volatility.  It uses the symbolic toolbox to provide the exact expressions
% of these moments
% n: length of time series
% k: lag of autocorrelation
%
function [y1,y2] = moms(n,k)
v2 = sym(max(n-2*k,0));
v3 = sym(max(n-3*k,0));
v4 = sym(max(n-4*k,0));
v5 = sym(max(n-5*k,0));
n = sym(n);
k = sym(k);
a1 = -(n-k)/n;
a2 = ((n-k)*(n^2-2*k)-2*n*v2)/(2*n^2);
a3 = (-(n-k)*(n^2-2*k*n+4*k^2)-6*k*n*v2-3*n^2*v3)/(4*n^3);
a4 = ((n-k)*(n^4-4*n^2*k+8*n*k^2-8*k^3)+(2*n^4-4*n^3-16*n*k^2)*v2-8*n^2*k*v3-4*n^3*v4)/(8*n^4);
a5 = ((n-k)*(-n^4+4*n^3*k-16*n^2*k^2+24*n*k^3-16*k^4)-10*n*k*(n^2+4*k^2)*v2- ...
      10*n^2*(n^2+n*k+2*k^2)*v3-10*n^3*k*v4-5*n^4*v5)/(16*n^5);
m = n-1;
m1 = a1/m;
m2 = (a1^2+2*a2)/(m*(m+2));
m3 = (a1^3+6*a1*a2+8*a3)/(m*(m+2)*(m+4));
m4 = (a1^4+12*a1^2*a2+12*a2^2+32*a1*a3+48*a4)/(m*(m+2)*(m+4)*(m+6));
m5 = (a1^5+20*a1^3*a2+80*a1^2*a3+240*a1*a4+60*a1*a2^2+160*a2*a3+384*a5)/(m*(m+2)*(m+4)*(m+6)*(m+8));
y1 = [m1 m2 m3 m4 m5]';
mc2 = m2-m1^2;
mc3 = m3-3*m2*m1+2*m1^3;
mc4 = m4-4*m3*m1+6*m2*m1^2-3*m1^4;
mc5 = m5-5*m4*m1+10*m3*m1^2-10*m2*m1^3+4*m1^5;
y2 = [0 mc2 mc3 mc4 mc5]';

