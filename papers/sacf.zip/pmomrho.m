%
% pmomrho.m		Date: 6/11/2006
% This Matlab program computes the cross moment of \hat\rho(k_1)^s_1... \hat\rho(k_p)^s_p,
% where the data is assumed to be i.i.d. normally distributed.
% Usage: pmomrho(n,k,si)
%
function y = pmomrho(n,kk,si)
if nargin==3
   ii = find(si==0);
   si(ii) = [];
   kk(ii) = [];
else   
   si = ones(size(kk));
end
s = sum(si);
if s==0
   y = 1;
   return
end
ls = length(si);
if ls==1
   y = momrho(n,kk,si);
   y = y(end);
   return
end
%
%   Convert moment of product to moments of sum
%
p = 2;
x = zeros(1,ls);
a0 = zeros(1,n);
a0(kk+1) = si./2;
y = 0;
for i=1:fix(prod(si+1)/2)
%
%   This part computes E[(z'Bz)^s]/s!, where 
%   B=(s_1/2-x_1)*B_{k_1}+...(s_r/2-x_r)*B_{k_r}
%
    d = eigpsp(a0);
    y1 = ones(1,s+1);
    a = zeros(1,s);
    d1 = ones(n-1,1);
    for j=1:s
        d1 = d1.*d;
        a(j) = sum(d1);
        y1(j+1) = sum(a(j:-1:1).*y1(1:j))/(2*j);
    end
    y = y+p*y1(end);
    for j=1:ls
        if x(j)<si(j)
           x(j) = x(j)+1;
           a0(kk(j)+1) = a0(kk(j)+1)-1;
           p = -round(p*(si(j)+1-x(j))/x(j));
           break
        end    
        x(j) = 0;
        a0(kk(j)+1) = si(j)/2;
        if rem(si(j),2)==1
           p = -p;
        end
    end
end
y = y/prod([(n-1):2:(n-3)+2*s]);
