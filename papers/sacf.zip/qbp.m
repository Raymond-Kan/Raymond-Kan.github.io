%
% qbp.m        Date: 3/27/2006
% This Matlab program computes the Box-Pierce and adjusted Box-Pierce test
% statistic.
% x: time series data
% m: number of lags
% Qboxp: Box-Pierce test statistic
% Qboxpa: adjusted Box-Pierce test statistic
%
function [Qboxp,Qboxpa] = qbp(x,m)
n = length(x);
%
%   Computation of finite sample mean and variance
%   of Q_{BP}.
%
nodd = rem(n,2)==1;  % n is odd
modd = rem(m,2)==1;  % m is odd
q2 = fix(max(2*m-n+1,0)/2);   % nodd can be written as 2*q2-(2m-n)
q3 = fix(max(3*m-n+1,0)/2);
q4 = fix(max(4*m-n+2,0)/2);
qmu = (m*(2*n.^3-(m+3)*n.^2+(m+1)*(2*m+1))+4*n*q2*(q2-(2*m-n+1)))/(2*n*(n.^2-1));
den = (n*n-1)*(n+3)*(n+5);
g1 = m*(24*n*(-2-2*n-n.^2+3*n.^3-2*n.^4+n.^5)+(35+114*n.^2+60*n.^3-261*n.^4+84*n.^5+12*n.^6)*m ...
         -6*(-35-80*n-70*n.^2-14*n.^3+17*n.^4+2*n.^5)*m.^2+(455+720*n+282*n.^2+24*n.^3+3*n.^4)*m.^3 ...
         -12*(-35-24*n+n.^2)*m.^4+140*m.^5)/(12*n*n*den);
g1a = modd*(4*n*(n-m)*(n-m-1)+6*m-2*n+3)/den;
g2 = -(2*m-n+2)*((24-84*n-150*n.^2+59*n.^3+16*n.^4)-2*(-63-54*n+63*n.^2+10*n.^3)*m ...
                  -6*(-39-18*n+n.^2)*m.^2+156*m.^3)/(6*n*den);
g2a = nodd*(48-27*n-111*n.^2+43*n.^3+16*n.^4-2*(-87-111*n+63*n.^2+10*n.^3)*m- ...
             6*(-47-18*n+n.^2)*m.^2+156*m.^3)/(6*n*den);
g3 = 4*q3*(q3+1)*(2*q3*(q3+1)-(3*m-n+1)*(3*m-n+2)-1)/den;  % This term exists if m>n/3 
g4 = 4*n*q4*(q4+1)*(4*q4-12*m+3*n-4)/den;
qmu2 = g1+g1a+(g2+g2a)*q2+g3+g4;
qvar = qmu2-qmu*qmu;
%
%  Computation of autocorrelation coefficients
%
xbar = x-mean(x);
c0 = xbar'*xbar ;
c1 = zeros(m,1);
for i=1:m
    c1(i) = xbar(1:n-i)'*xbar(i+1:n);
end;
r = c1/c0;
Qboxp = n*sum(r.*r);
Qboxpa = m+sqrt(2*m/qvar)*(Qboxp-qmu);
