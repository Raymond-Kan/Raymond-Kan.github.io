%
%	rankone.m		Date: 10/23/2004
% This Matlab program computes the rank one update of a 
% diagonal matrix, returning the eigenvalues except for
% the largest one when rho is positive and the smallest
% one when rho is negative.
% d: elements of diagonal matrix, must be sorted in ascending order
%    if rho is positive, and descending order if rho is negative
%
function lam = rankone(d,z,rho)
n = length(d);
%
%   Quick return if possible
%
if n==1
   lam = d+rho*z^2;
   return
end
%
%   Scale z such that rho is positive and norm(z)=1
%
maxd = max(abs(d));
normz = norm(z);
z = z./normz;
rho = normz*normz*rho/maxd;
if rho<0
   rho = -rho;
   maxd = -maxd;
end
d = d./maxd;
lam = maxd*rank1up(d,z,rho);
