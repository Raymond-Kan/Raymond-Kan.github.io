%
% rhocdfb.m		Date: 2/26/2004
% This Matlab program computes the CDF of \hat\rho(k) under
% the normality assumption.
%
function y = rhocdfb(c,n,k,d,r)
if nargin<4
   [d r] = eigpapb(n,k);
end
y = zeros(size(c));
for i=1:numel(c)
    if c(i)<=d(end)
       y(i) = 0;
    elseif c(i)>=d(1)
       y(i) = 1;
    else
       y(i) = linchi2b(0,d-c(i),r);
    end
end
