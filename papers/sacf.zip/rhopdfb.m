%
% rhopdfb.m		Date: 2/26/2004
% This Matlab program computes the PDF of \hat\rho(k) under
% the normality assumption.  It uses the Geary (1944) formula as
% explained in Broda and Paolella (2009).
%
function y = rhopdfb(c,n,k,d,r)
if nargin<4
   [d r] = eigpapb(n,k);
end
r2pi = 0.15915494309189533577;  % 1/(2*pi)
y = zeros(size(c));
for i=1:numel(c)
    if c(i)<d(end)||c(i)>d(1)
       y(i) = 0;
    else
       wgt = d-c(i);
       y(i) = r2pi*quadgk(@integrand,0,inf,'AbsTol',1e-8);
    end
end

function y1 = integrand(u)
   p = wgt*u;
   d1 = 1./(1+p.*p);
   beta = 0.5*r'*atan(p);
   rho = r'*d1;
   delta = (wgt.*r)'*d1;
   y1 = (cos(beta).*rho-u.*sin(beta).*delta).*exp(0.25*r'*log(d1));
end

end