%
% vratio.m        Date: 3/27/2006
% This Matlab program computes the exact mean and variance of variance
% ratio statistic
% n: length of time series
% k: length of multiperiod returns
% muvr: E[\hat\theta(k)]
% varvr: Var[\hat\theta(k)]
%
function [muvr,varvr] = vratio(n,m)
muvr = 1-(3*n-m-1).*(m-1)./(3*n.*(n-1));
num = (m-1).*polyval([10*(n-2) 2*(21*n.*n+14*n-10) -(105*n.^3+3*n.*n-8*n-20) ...
                      60*n.^4+15*n.^3-33*n.*n-22*n+20 -6*n.*(n-1).*(5*n.*n-2)],m);
den = 45*m.*(n+1).*n.^2.*(n-1).^2;
num1 = max(2*m-n-2,0).*(2*m-n-1).*(2*m-n).*(2*m-n+1).*(2*m-n+2);
den1 = 15*m.*m.*(n-1).*n.*(n+1);
varvr = num./den-num1./den1;
