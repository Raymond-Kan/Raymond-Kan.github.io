sbw.m       : implements CSR using simple regression betas with known weighting matrix 
sbgls.m     : implements CSR using simple regression betas with estimated GLS weighting matrix 
sbwls.m     : implements CSR using simple regression betas with estimated WLS weighting matrix 

These programs allow us to get the CSR estimates of gamma 
with simple regression betas and the three different t-ratios 
for the gammas:
trat1: correctly specified model without EIV adjustment 
trat2: correctly specified model with EIV adjustment
trat3: misspecification-robust t-ratio

Usage:
(1) For fixed weighting matrix W, we do
[gamma,trat1,trat2,trat3] = sbw(R,F,lag,W);
where R is TxN matrix of returns, F is TxK matrix of factors,
and lag is the number of lags used in computing standard
errors (default is 0), W is an NxN symmetric weighting
matrix (default is identity matrix)

(2) For estimated GLS, we do  
[gamma,trat1,trat2,trat3] = sbgls(R,F,lag);

(3) For estimated WLS, we do  
[gamma,trat1,trat2,trat3] = sbwls(R,F,lag);
