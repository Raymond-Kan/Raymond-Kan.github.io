%
% SBW.M
% This Matlab performs the two-pass CSR with simple betas using a
% fixed weighting matrix W.
%
% Input:
% R: Returns on N test assets (TxN matrix)
% F: K systematic factors (TxK matrix)
% lag: Number of lags of Newey-West adjustment (default is 0)
% W: Weighting matrix (default is identity matrix)
%
% Output:
% gamma: zero-beta rate and risk premia
% trat1: Fama-MacBeth t-ratio
% trat2: EIV t-ratio under general distribution assumptions of JW (1998)
% trat3: misspecification robust t-ratio 
%
function [gamma,trat1,trat2,trat3] = sbw(R,F,lag,W)
[T,K] = size(F);
[T,N] = size(R);
if nargin<3
   lag = 0;
end
if nargin<4
   W = eye(N);
end
Y = [F R];
mu1 = mean(F)';
mu2 = mean(R)';
V = cov(Y,1);
V11 = V(1:K,1:K);
V21 = V(K+1:end,1:K);
V22 = V(K+1:end,K+1:end);
Di = diag(1./diag(V11));
bstar = V21*Di;
Xstar = [ones(N,1) bstar];
Hstar = inv(Xstar'*W*Xstar);
Astar = Hstar*Xstar'*W;
gamma = Astar*mu2;
gamma1 = gamma(2:end);
e = mu2-Xstar*gamma;
Fd = F-ones(T,1)*mu1';     % De-meaned factors
Rd = R-ones(T,1)*mu2';     % De-meaned returns
wt = Fd*Di*gamma1;
yt = 1-wt;                 % SDF
gammat = Rd*Astar';    % This is \hat\gamma_t-\hat\gamma
ut = Rd*W*e;
ztstar = [zeros(T,1) Fd*Di];
D2a = Fd.*Fd.*(ones(T,1)*gamma1'*Di);
ht0 = gammat; % Fama and MacBeth
ht1 = gammat.*(yt*ones(1,K+1))+[zeros(T,1) D2a]; % Without misspecification adjustment
ht2 = gammat.*(yt*ones(1,K+1))+[zeros(T,1) D2a]+(ztstar*Hstar).*(ut*ones(1,K+1)); % With misspecification adjustment
V0 = nw(ht0,lag);
V1 = nw(ht1,lag);
V2 = nw(ht2,lag);
trat1 = gamma./sqrt(diag(V0)./T);
trat2 = gamma./sqrt(diag(V1)./T);
trat3 = gamma./sqrt(diag(V2)./T);
