MATLAB programs for "Uniform saddlepoint expansions for multivariate tail probabilities" by Simon A. Broda and Raymond Kan
(Annals of Statistics).  Free to use and modify with a citation of the paper; contact:
raymond.kan@rotman.utoronto.ca.

See manual.pdf for the description of every program and of how to reproduce the tables.
Requirements: Statistics and Machine Learning Toolbox; Symbolic Math Toolbox for the
variable-precision programs (*_hp.m) and the automatic refinement of spa_mv/spa_tri; Parallel
Computing Toolbox for the grids of Tables S2 and S3 as run (parfor; serial without it).  See the
manual, Section 1, for details.

Quick start:  add this folder to the MATLAB path and run demo_spa (and demo_mv); test_spa runs the
regression tests (test_spa(true) adds the variable-precision tests).

Core programs:  spa_uni.m, spa_ratio_pdf.m, spa_bi.m, spa_orthant2.m, qf_Kmulti.m
Three and more dimensions:  spa_tri.m, spa_mv.m, spa_orthant.m, spa_saddle.m (test model
         mvcc_Kfun.m, mvcc_exact.m)
Variable precision (Symbolic Math Toolbox):  spa_uni_hp.m, spa_bi_hp.m, acf_spa_hp.m
Tables:  tables12/ncx2_table1.m (Table S1), tables12/ncf_table2.m (Table S2; the grids and the
         exact values are in tables12/),
         dncf_run.m + dncf_summary.m (Table S3), bqf_table.m (Table 6), acf_table.m (Table S8),
         lap_table.m (Table 3), wang_table.m (Table 1), kl_table.m (Tables 2, S6 and S7),
         nsweep_table.m (Tables S4 and S5, the Wang and Kolassa-Li examples with n doubling),
         tri_table.m (Table 4), cox/gci_cox.m (Table 5 and the 95% intervals of Section 5.4,
         the ratio of regression coefficients; the folder cox/ also holds the exact distribution
         function and quantiles of the ratio and its saddlepoint quantiles);
         one command per table, each prints the rows of its table.
Approximations of the literature:  kl_bivar.m (Kolassa and Li 2010), wang_bivar.m (Wang 1990;
         wang_check.m compares it with the values printed in Wang's Table 1).
Reference data:  reference/ (raw outputs of the reference computations of Table S8) and
         reference/PROVENANCE.txt (how every reference data set was computed, and the SHA-256
         hashes of the files of this release).

Version of 1 November 2026, matching the paper (Tables 1-6) and its Supplementary Material
(Tables S1-S8).  Julia and Python implementations of the expansions for a user-supplied cumulant
generating function: Pkg.add("SaddlepointExpansions") and pip install saddlepoint-expansions.
