function v = acf_Kfun(nu,s,Mats,c)
%ACF_KFUN Derivatives of K_W(s) for W_j = z'(A_j - c_j A_3)z, j = 1,2 (whitened matrices in
%   Mats = {A1,A2,A3}), nu = [nu1 nu2]; NaN outside the domain.  Memoized: all derivatives
%   with |nu| <= L are computed at the first call with a new (s, c, Mats), with L = 2 when only
%   the derivatives of order at most two are requested (the iterates of the saddlepoint
%   iteration need nothing more) and otherwise L = 24 (enough for orders up to 11), or |nu| if a
%   higher derivative is requested; the cache key includes the matrices, so that models can be
%   alternated without clearing the function.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
persistent lasts lastK lastc lastM lastL
if sum(nu) <= 2, L = 2; else, L = max(24,sum(nu)); end
if isempty(lasts) || ~isequal(s,lasts) || ~isequal(c,lastc) || ~isequal(Mats,lastM) || L > lastL
   B = {Mats{1}-c(1)*Mats{3}, Mats{2}-c(2)*Mats{3}};
   lastK = qf_Kmulti(s,B,L);
   lasts = s; lastc = c; lastM = Mats; lastL = L;
end
if isempty(lastK), v = NaN; return; end
v = lastK(strtrim(sprintf('%d ',nu)));
