function F = acf_exact_cdf(c,Mats,tol)
%ACF_EXACT_CDF P[r1 <= c1, r2 <= c2] for the ratios r_j = z'A_jz/z'A_3z by two-dimensional
%   numerical inversion of P[W <= 0] = (2 pi i)^-2 int exp(K_W(s)) ds1 ds2/(s1 s2) along
%   Re s = -tau, tau > 0 the saddlepoint of the cgf of -W (or Re s = -delta if tau has
%   negative components).
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
if nargin < 3, tol = 1e-12; end
N = size(Mats{1},1);
B1 = Mats{1}-c(1)*Mats{3}; B2 = Mats{2}-c(2)*Mats{3};
KW = @(nu,s) acf_Kfun(nu,s,Mats,c);
KmW = @(nu,t) (-1)^(nu(1)+nu(2))*KW(nu,-t);
[~,~,tau] = spa_bi(KmW,[0 0],1);
s0 = -max(tau,0.02);                              % contour point in the negative orthant
while isnan(KW([0 0],s0)), s0 = s0/2; end           % ... inside the domain of K_W
QR = eye(N)-2*(s0(1)*B1+s0(2)*B2); ldR = sum(log(eig(QR)));
   function v = integrand(y1,y2)
      v = zeros(size(y1));
      for q = 1:numel(y1)
         QI = -2*(y1(q)*B1+y2(q)*B2);
         lam = eig(QI,QR);
         ld = ldR+sum(log(1+1i*lam));
         v(q) = real(exp(-0.5*ld)/((s0(1)+1i*y1(q))*(s0(2)+1i*y2(q))));
      end
   end
H = [KmW([2 0],-s0) KmW([1 1],-s0); KmW([1 1],-s0) KmW([0 2],-s0)];
sc = 1/sqrt(min(eig(H)));
Y = 80*sc;
F = integral2(@integrand,-Y,Y,-Y,Y,'AbsTol',tol*1e-3,'RelTol',tol,'Method','iterated')/(4*pi^2);
end
