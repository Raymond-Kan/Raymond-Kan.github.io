function [f,shat] = acf_exact_pdf(c,Mats,tol)
%ACF_EXACT_PDF Joint density of r_j = z'A_jz/z'A_3z at c by two-dimensional numerical inversion
%   of (45) along the contour through the saddlepoint of K_W:
%   f = (2 pi)^-2 int int Re{ exp(K_W(s)) [K_u(s)^2 + K_uu(s)] } dy, s = shat + i y.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
if nargin < 3, tol = 1e-12; end
N = size(Mats{1},1);
B1 = Mats{1}-c(1)*Mats{3}; B2 = Mats{2}-c(2)*Mats{3}; A3 = Mats{3};
KW = @(nu,s) acf_Kfun(nu,s,Mats,c);
[~,~,shat] = spa_bi(KW,[0 0],1);
QR = eye(N)-2*(shat(1)*B1+shat(2)*B2); ldR = sum(log(eig(QR)));
   function v = integrand(y1,y2)
      v = zeros(size(y1));
      for q = 1:numel(y1)
         QI = -2*(y1(q)*B1+y2(q)*B2);               % Q = QR + i QI, QR positive definite
         lam = eig(QI,QR);                          % det Q = det QR prod(1 + i lam)
         ld = ldR+sum(log(1+1i*lam));               % continuous branch of log det Q
         D = (QR+1i*QI)\A3;                         % Q^{-1} A3
         Ku = trace(D); Kuu = 2*trace(D*D);
         v(q) = real(exp(-0.5*ld)*(Ku^2+Kuu));
      end
   end
% scale of the Gaussian factor: K2 of K_W at shat
H = [KW([2 0],shat) KW([1 1],shat); KW([1 1],shat) KW([0 2],shat)];
sc = 1/sqrt(min(eig(H)));
Y = 60*sc;
f = integral2(@integrand,-Y,Y,-Y,Y,'AbsTol',tol*1e-3,'RelTol',tol,'Method','iterated')/(4*pi^2);
end
