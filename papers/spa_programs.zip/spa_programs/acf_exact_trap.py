"""Exact joint density and distribution function of the sample autocorrelations (r1, r2) for
Table S8, by the trapezoidal rule on the inversion integrals along contours through (or near) the
saddlepoint.  Usage: python acf_exact_trap.py i   (i = 0..23, index into acf_results.mat)
Writes acf_trap_<i>.json.  Raymond Kan, 2026.  Programs accompanying Broda and Kan,
"Uniform saddlepoint expansions for multivariate tail probabilities"; free to use with a citation of the paper."""
import os, sys, json, time
os.environ.setdefault('OMP_NUM_THREADS','1'); os.environ.setdefault('OPENBLAS_NUM_THREADS','1'); os.environ.setdefault('MKL_NUM_THREADS','1')
import numpy as np, scipy.io as sio
def setup(N,rho,c):
    i=np.arange(N); Sig=rho**np.abs(i[:,None]-i[None,:]); w,V=np.linalg.eigh(Sig); S=(V*np.sqrt(w))@V.T
    M=np.eye(N)-np.ones((N,N))/N
    As=[]
    for j in (1,2):
        A=(np.diag(np.ones(N-j),j)+np.diag(np.ones(N-j),-j))/2; As.append(S@M@A@M@S)
    A3=S@M@S; As=[(X+X.T)/2 for X in As]; A3=(A3+A3.T)/2
    return As[0]-c[0]*A3, As[1]-c[1]*A3, A3
def KW(s,B1,B2,d=0):
    Q=np.eye(len(B1))-2*(s[0]*B1+s[1]*B2); 
    if d==0: return -0.5*np.linalg.slogdet(Q)[1]
    Qi=np.linalg.inv(Q); G1=Qi@B1; G2=Qi@B2
    g=np.array([np.trace(G1),np.trace(G2)])
    H=2*np.array([[np.trace(G1@G1),np.trace(G1@G2)],[np.trace(G2@G1),np.trace(G2@G2)]])
    return g,H
def saddle(B1,B2,s=np.zeros(2)):
    for it in range(100):
        g,H=KW(s,B1,B2,1); ds=np.linalg.solve(H,-g)
        t=1.0
        while True:
            sn=s+t*ds; Q=np.eye(len(B1))-2*(sn[0]*B1+sn[1]*B2)
            if np.all(np.linalg.eigvalsh(Q)>0): break
            t/=2
        s=sn
        if np.max(np.abs(ds))<1e-14: break
    return s,H
def grid2(B1,B2,A3,c,h,Y,kind):
    """trapezoid over y1 in [-Y,Y], y2 in [0,Y] (conj symmetry); kind 'cdf' -> J, 'pdf' -> f"""
    N=len(B1); R=np.eye(N)-2*(c[0]*B1+c[1]*B2)
    wR,VR=np.linalg.eigh(R); Rmh=(VR/np.sqrt(wR))@VR.T; ldR=np.sum(np.log(wR))
    y1=np.arange(-int(round(Y/h)),int(round(Y/h))+1)*h; i0=len(y1)//2
    y2s=np.arange(0,int(round(Y/h))+1)*h
    tot=0.0
    for y2 in y2s:
        lam=np.linalg.eigvalsh(Rmh@(-2*y2*B2)@Rmh)
        ldP=ldR+np.sum(np.log(1+1j*lam))
        P=R-2j*y2*B2
        C=np.linalg.solve(P,B1); mu,V=np.linalg.eig(C)
        L=np.log(1-2j*np.outer(y1,mu))          # nodes x N
        ld=ldP+L.sum(1)
        # unwrap imaginary part from y1=0
        im=ld.imag.copy(); 
        im[i0:]=np.unwrap(im[i0:]); im[:i0+1]=np.unwrap(im[:i0+1][::-1])[::-1]
        # anchor: at y1=0 ld = ldP exactly
        ld=ld.real+1j*(im-im[i0]+ldP.imag)
        E=np.exp(-0.5*ld)
        if kind=='cdf':
            v=E/((c[0]+1j*y1)*(c[1]+1j*y2))
        else:
            G=np.linalg.solve(V,np.linalg.solve(P,A3)@V)
            D=1/(1-2j*np.outer(y1,mu))
            Ku=D@np.diag(G); Kuu=2*np.einsum('nk,kl,nl->n',D,G*G.T,D)
            v=E*(Ku**2+Kuu)
        wt=1.0 if y2==0 else 2.0
        tot+=wt*np.sum(v.real)
    return tot*h*h/(4*np.pi**2)
def grid1(B,c,h,Y):
    """J1 = (1/2pi) int Re{exp(K(c+iy))/(c+iy)} dy, K = -1/2 logdet(I-2sB)"""
    w=np.linalg.eigvalsh(B); y=np.arange(0,int(round(Y/h))+1)*h
    ld=np.sum(np.log(1-2*np.outer(c+1j*y,w)),1)  # principal ok: factors 1-2cw-2iyw with real part >0
    v=(np.exp(-0.5*ld)/(c+1j*y)).real; wt=np.ones_like(y)*2; wt[0]=1
    return np.sum(wt*v)*h/(2*np.pi)
def sad1(B,s=0.0):
    w=np.linalg.eigvalsh(B)
    for it in range(200):
        g=np.sum(w/(1-2*s*w)); H=np.sum(2*w*w/(1-2*s*w)**2); ds=-g/H; t=1
        while np.any(1-2*(s+t*ds)*w<=0): t/=2
        s+=t*ds
        if abs(ds)<1e-15: break
    return s,H
def cdf(B1,B2,A3,hf=1/3,Yf=60,delta=1.0):
    s,H=saddle(B1,B2); sc=1/np.sqrt(np.linalg.eigvalsh(H).min())
    c=s.copy()
    for j in range(2):
        if abs(c[j])<delta*sc: c[j]=np.sign(c[j] if c[j]!=0 else -1)*delta*sc
    h=min(hf*sc,min(abs(c))/4)
    J=grid2(B1,B2,A3,c,h,Yf*sc,'cdf')
    eps=np.sign(c); Pb=eps[0]*eps[1]*J        # P(X in H1 x H2)
    marg={}
    def Pm(j):   # P(X_j<=0)
        B=[B1,B2][j]; s1,H1=sad1(B); sc1=1/np.sqrt(H1); c1=s1
        if abs(c1)<delta*sc1: c1=np.sign(c1 if c1!=0 else -1)*delta*sc1
        h1=min(hf*sc1,abs(c1)/4); J1=grid1(B,c1,h1,Yf*sc1*3)
        return -J1 if c1<0 else 1-J1
    if eps[0]<0 and eps[1]<0: F=Pb
    elif eps[0]>0 and eps[1]<0: F=Pm(1)-Pb
    elif eps[0]<0 and eps[1]>0: F=Pm(0)-Pb
    else: F=Pm(0)+Pm(1)-1+Pb
    return F,s,c
def domdist(Bs,c):
    N=len(Bs[0]); R=np.eye(N)-2*sum(cj*Bj for cj,Bj in zip(c,Bs))
    wR,VR=np.linalg.eigh(R); Rmh=(VR/np.sqrt(wR))@VR.T
    d=np.inf
    for B in Bs:
        e=np.linalg.eigvalsh(Rmh@B@Rmh)
        if e.max()>0: d=min(d,1/(2*e.max()))
        if e.min()<0: d=min(d,-1/(2*e.min()))
    return d
def cdf2(B1,B2,A3,k=7,Yf=60,delta=1.0,hscale=1.0):
    s,H=saddle(B1,B2); sc=1/np.sqrt(np.linalg.eigvalsh(H).min())
    c=s.copy()
    for j in range(2):
        if abs(c[j])<delta*sc: c[j]=np.sign(c[j] if c[j]!=0 else -1)*delta*sc
    d=min(min(abs(c)),domdist([B1,B2],c)); h=min(sc/3,d/k)*hscale
    J=grid2(B1,B2,A3,c,h,Yf*sc,'cdf')
    eps=np.sign(c); Pb=eps[0]*eps[1]*J
    def Pm(j):
        B=[B1,B2][j]; s1,H1=sad1(B); sc1=1/np.sqrt(H1); c1=s1
        if abs(c1)<delta*sc1: c1=np.sign(c1 if c1!=0 else -1)*delta*sc1
        d1=min(abs(c1),domdist([B],[c1])); h1=min(sc1/3,d1/k)*hscale
        J1=grid1(B,c1,h1,Yf*sc1*3)
        return -J1 if c1<0 else 1-J1
    if eps[0]<0 and eps[1]<0: F=Pb
    elif eps[0]>0 and eps[1]<0: F=Pm(1)-Pb
    elif eps[0]<0 and eps[1]>0: F=Pm(0)-Pb
    else: F=Pm(0)+Pm(1)-1+Pb
    return F,s,c,h/sc
def pdf2(B1,B2,A3,k=7,Yf=60,hscale=1.0):
    s,H=saddle(B1,B2); sc=1/np.sqrt(np.linalg.eigvalsh(H).min())
    d=domdist([B1,B2],s); h=min(sc/3,d/k)*hscale
    return grid2(B1,B2,A3,s,h,Yf*sc,'pdf'),s,h/sc
def isPD(Bs,c):
    N=len(Bs[0]); R=np.eye(N)-2*sum(cj*Bj for cj,Bj in zip(c,Bs))
    return np.linalg.eigvalsh(R).min()>0
def choose_contour(Bs,s,sc,delta=1.0):
    """contour point: the saddlepoint, with components closer than delta*sc to the pole at 0
    moved (keeping the domain) to maximise the distance to the poles and to the domain boundary"""
    c=np.array(s,float).copy()
    for j in range(len(c)):
        if abs(c[j])>=delta*sc: continue
        best=None
        for t in np.concatenate([-np.geomspace(1e-3,10,121)*sc,np.geomspace(1e-3,10,121)*sc]):
            cc=c.copy(); cc[j]=t
            if not isPD(Bs,cc): continue
            dd=min(min(abs(cc[k]) for k in range(len(c)) if k<=j or abs(cc[k])>=delta*sc),domdist(Bs,cc))
            if best is None or dd>best[0]: best=(dd,t)
        c[j]=best[1]
    return c
def cdf3(B1,B2,A3,k=7,Yf=60,delta=1.0,hscale=1.0):
    s,H=saddle(B1,B2); sc=1/np.sqrt(np.linalg.eigvalsh(H).min())
    c=choose_contour([B1,B2],s,sc,delta)
    d=min(min(abs(c)),domdist([B1,B2],c)); h=min(sc/3,d/k)*hscale
    J=grid2(B1,B2,A3,c,h,Yf*sc,'cdf')
    eps=np.sign(c); Pb=eps[0]*eps[1]*J
    def Pm(j):
        B=[B1,B2][j]; s1,H1=sad1(B); sc1=1/np.sqrt(H1)
        c1=choose_contour([B],[s1],sc1,delta)[0]
        d1=min(abs(c1),domdist([B],[c1])); h1=min(sc1/3,d1/k)*hscale
        J1=grid1(B,c1,h1,Yf*sc1*3)
        return -J1 if c1<0 else 1-J1
    if eps[0]<0 and eps[1]<0: F=Pb
    elif eps[0]>0 and eps[1]<0: F=Pm(1)-Pb
    elif eps[0]<0 and eps[1]>0: F=Pm(0)-Pb
    else: F=Pm(0)+Pm(1)-1+Pb
    return F,s,c,h/sc
if __name__=='__main__':
    i=int(sys.argv[1])
    R=sio.loadmat('acf_results.mat',squeeze_me=True,struct_as_record=False)['R']
    r=R[i]; B1,B2,A3=setup(int(r.N),float(r.rho),np.asarray(r.c,float)); t=time.time()
    F,s,c,hh=cdf3(B1,B2,A3); F2=cdf3(B1,B2,A3,hscale=0.7,Yf=80)[0]
    f,_,hp=pdf2(B1,B2,A3); f2=pdf2(B1,B2,A3,hscale=0.7,Yf=80)[0]
    d=dict(i=i,N=int(r.N),rho=float(r.rho),q=[float(x) for x in r.q],shat=[float(x) for x in s],
           contour_cdf=[float(x) for x in c],F=F,F_check=F2,f=f,f_check=f2,t=time.time()-t)
    json.dump(d,open('acf_trap_%d.json'%i,'w'),indent=1); print(json.dumps(d))
