function G = acf_gam(s,Mats,c,order)
%ACF_GAM Taylor coefficients at s of g_0 = (K_u)^2 and g_1 = K_uu for the pair of ratios
%   r_j = z'A_jz/z'A_3z (Appendix A.1 of the paper): G{1}, G{2} with G{i}(mu1+1,mu2+1) = gamma_mu,
%   |mu| <= 2(order-1), computed directly from the matrices (no binomial chain-rule sums, which
%   lose digits when the matrices are ill conditioned): with
%   D = (I - 2 s_1 B_1 - 2 s_2 B_2)^{-1}, B_j = A_j - c_j A_3, and F_nu the sum of all products of
%   nu_1 copies of D B_1 and nu_2 copies of D B_2 in every order (F_0 = I), the Taylor coefficients
%   at s of K_u = tr(D A_3) and K_uu = 2 tr(D A_3 D A_3) along u = -(c_1 s_1 + c_2 s_2) are
%   T1(nu) = 2^|nu| tr(F_nu D A_3) and T2(nu) = 2^{|nu|+1} sum_{lambda <= nu} tr(F_lambda D A_3
%   F_{nu-lambda} D A_3)  (z ~ N(0,I), so no mean terms).
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
L = 2*(order-1);
n = size(Mats{1},1);
B = {Mats{1}-c(1)*Mats{3}, Mats{2}-c(2)*Mats{3}};
D = inv(eye(n)-2*(s(1)*B{1}+s(2)*B{2}));
DB = {D*B{1}, D*B{2}}; DA = D*Mats{3};
F = cell(L+1,L+1); F{1,1} = eye(n);
for k = 1:L
   for n1 = 0:k
      n2 = k-n1; Fa = zeros(n);
      if n1 > 0, Fa = Fa+DB{1}*F{n1,n2+1}; end
      if n2 > 0, Fa = Fa+DB{2}*F{n1+1,n2}; end
      F{n1+1,n2+1} = Fa;
   end
end
FA = cell(L+1,L+1);                                   % F_nu D A_3
for n1 = 0:L, for n2 = 0:L-n1, FA{n1+1,n2+1} = F{n1+1,n2+1}*DA; end, end
T1 = zeros(L+1); T2 = zeros(L+1);
for n1 = 0:L
   for n2 = 0:L-n1
      T1(n1+1,n2+1) = 2^(n1+n2)*trace(FA{n1+1,n2+1});
      v = 0;
      for l1 = 0:n1
         for l2 = 0:n2
            v = v+sum(sum(FA{l1+1,l2+1}.*FA{n1-l1+1,n2-l2+1}.'));   % tr(X Y)
         end
      end
      T2(n1+1,n2+1) = 2^(n1+n2+1)*v;
   end
end
G0 = conv2(T1,T1); G = {G0(1:L+1,1:L+1), T2};
end
