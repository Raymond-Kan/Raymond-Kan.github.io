function Mats = acf_setup(N,rho,lags)
%ACF_SETUP Whitened matrices for the mean-corrected sample autocorrelations r_j = z'MA_jMz/z'Mz,
%   z ~ N(0,Sigma), Sigma_{ts} = rho^|t-s|: Mats{j} = S M A_j M S (j = 1..numel(lags)) and
%   Mats{end} = S M S, with S = Sigma^{1/2}, so that z'A z = w'(SAS)w with w ~ N(0,I).
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
Sigma = rho.^abs((1:N)'-(1:N));
S = sqrtm(Sigma);
M = eye(N)-ones(N)/N;
Mats = cell(1,numel(lags)+1);
for i = 1:numel(lags)
   j = lags(i);
   A = (diag(ones(N-j,1),j)+diag(ones(N-j,1),-j))/2;
   Mats{i} = S*M*A*M*S;
end
Mats{end} = S*M*S;
for i = 1:numel(Mats), Mats{i} = (Mats{i}+Mats{i}')/2; end
end
