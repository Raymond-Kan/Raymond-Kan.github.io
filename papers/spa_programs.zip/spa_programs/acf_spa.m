function [pdf,cdf,shat,canc,kappa] = acf_spa(c,Mats,order)
%ACF_SPA Saddlepoint approximations of orders 1..order of the joint density and joint distribution
%   function P[r1 <= c1, r2 <= c2] of two ratios of quadratic forms r_j = z'A_jz/z'A_3z with a
%   common positive denominator (Appendix A.1 of the paper), Mats = {A1,A2,A3} whitened, z ~ N(0,I).
%   The expansions are evaluated in whitened coordinates (spa_bi): the derivatives of the
%   transformed cumulant generating function K(T u), the cgf of the quadratic forms with matrices
%   sum_j T_{ji} B_j, and the amplitude coefficients of the ratio density are computed directly
%   from the transformed matrices (acf_Kfun, acf_gam), without the polynomial substitution.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
KW = @(nu,s) acf_Kfun(nu,s,Mats,c);
opts.Kwhite = @(nu,u,T) acf_Kfun(nu,u,tmats(Mats,T),c*T);        % K_W(T u)
opts.gamwhite = @(u,T) acf_gam(u,tmats(Mats,T),c*T,order);
[pdf,~,shat] = spa_bi(KW,[0 0],order,[],@(s) acf_gam(s,Mats,c,order),[],opts);
KmW = @(nu,t) (-1)^(nu(1)+nu(2))*KW(nu,-t);
om.Kwhite = @(nu,u,T) acf_Kfun(nu,u,tmats(Mats,-T),-c*T);         % K_{-W}(T u) = K_W(-T u)
[cdf,~,canc,kappa] = spa_orthant2(KmW,[0 0],order,om);   % canc, kappa: cancellation indicators, see spa_bi
end

function M = tmats(Mats,T)
%  matrices of the quadratic forms s'A -> (T u)'A: Atilde_i = sum_j T(j,i) A_j for the two ratio
%  numerators (the denominator A_3 is unchanged)
M = {T(1,1)*Mats{1}+T(2,1)*Mats{2}, T(1,2)*Mats{1}+T(2,2)*Mats{2}, Mats{3}};
end
