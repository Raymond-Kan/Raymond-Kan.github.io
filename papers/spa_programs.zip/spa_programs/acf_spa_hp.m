function [pdf,cdf,info] = acf_spa_hp(N,rho,q,order,dig)
%ACF_SPA_HP High-precision saddlepoint approximations for the pair of sample autocorrelations
%   (Section S4 of the Supplementary Material): orders 1..order of the joint density and of the joint distribution
%   function P[r1 <= c1, r2 <= c2] of the mean-corrected sample autocorrelations at lags 1 and 2
%   of N observations of a stationary AR(1) with parameter rho, at c_j = rho^j + q_j N^{-1/2}.
%   Same approximations as acf_spa, but every step (matrices, saddlepoints, cumulants, the
%   coefficients a_{r,nu}, the integrals I(nu), the univariate terms of the inclusion-exclusion
%   step) is carried out with dig significant digits (Symbolic Math Toolbox), so that the
%   cancellation among the terms of the orthant-probability expansion, which can exceed the
%   resolution of double precision (output canc of acf_spa), does not limit the accuracy.
%   rho and q are converted to exact rationals (use e.g. 0.5, 1.5).
%   [pdf,cdf,info] = acf_spa_hp(N,rho,q,order,dig)
%   pdf, cdf: vpa column vectors (orders 1..order); info: s, the saddlepoint of K_W (the cgf of
%   (W_1,W_2), the density saddlepoint; that of the distribution function is -s), in double
%   precision, and s_str, the same with dig digits (cell of decimal strings), the cancellation
%   indicator, the computing time and dig.
%   Programs: spa_bi_hp, spa_uni_hp.  Run time: about ten minutes per point for N = 100,
%   order = 5, dig = 50.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
if nargin < 5, dig = 50; end
t0 = tic;
olddig = digits(dig); cleanup = onCleanup(@() digits(olddig));
r = sym(rho,'r'); qq = sym(q,'r'); n = N;
c = [r r^2]+qq/sqrt(sym(n));
%
%  z ~ N(0,Sigma), Sigma_{ts} = rho^|t-s|; W_j = z'B_j z, B_j = M A_j M - c_j M, A_3 = M, so that
%  r_j <= c_j iff W_j <= 0.  K_W(s) = -(1/2){log det Sigma + log det P(s)},
%  P(s) = Sigma^{-1} - 2(s_1 B_1 + s_2 B_2), and K_W^{(alpha)} = 2^{|alpha|-1} alpha! tr F_alpha/|alpha|,
%  F_alpha the sum of all products of the matrices P^{-1}B_i with multiplicities alpha.
%
e = sym(ones(n,1));
Sinv = (diag([1; (1+r^2)*ones(n-2,1); 1])-r*(diag(ones(n-1,1),1)+diag(ones(n-1,1),-1)))/(1-r^2);
M = sym(eye(n))-e*e.'/n;
B = cell(1,3);
for j = 1:2
   A = sym((diag(ones(n-j,1),j)+diag(ones(n-j,1),-j))/2);
   u = A*e;
   MAM = A-(e*u.'+u*e.')/n+(e.'*u)/n^2*(e*e.');
   B{j} = vpa(MAM-c(j)*M);
end
B{3} = vpa(M);
Sinv = vpa(Sinv);
logdetS = (n-1)*log(1-vpa(r)^2);
%
%  saddlepoint of K_W (density) = minus the saddlepoint of K_{-W} (distribution function)
%
s = saddle_hp(Sinv,B(1:2),[0 0]);
P = Sinv-2*(s(1)*B{1}+s(2)*B{2});
Dinv = inv(P);
logdetP = log(det(P));
DA = {Dinv*B{1}, Dinv*B{2}, Dinv*B{3}};
Lc = 2*order+1;                            % cumulants of W needed: |nu| <= p+2 = 2*order+1
Ld = 2*(order-1);                          % amplitude: derivatives of order <= Ld
F = words(DA,ceil(max(Lc,Ld+2)/2));
KW = vpa(zeros(Lc+1,Lc+1));
KW(1,1) = -(logdetS+logdetP)/2;
for m = 1:Lc
   for n1 = 0:m
      al = [n1 m-n1 0];
      KW(n1+1,m-n1+1) = 2^(m-1)*factorial(sym(n1))*factorial(sym(m-n1))*trw(F,al)/m;
   end
end
T1 = vpa(zeros(Ld+1,Ld+1)); T2 = T1;      % Taylor coefficients of K_u and K_uu along u = -c's
for m = 0:Ld
   for n1 = 0:m
      n2 = m-n1; fa = factorial(sym(n1))*factorial(sym(n2));
      T1(n1+1,n2+1) = 2^m*fa*trw(F,[n1 n2 1])/(m+1)/fa;
      T2(n1+1,n2+1) = 2^(m+1)*fa*2*trw(F,[n1 n2 2])/(m+2)/fa;
   end
end
G0 = vpa(zeros(Ld+1,Ld+1));
for m1 = 0:Ld
   for m2 = 0:Ld-m1
      [I1,I2] = ndgrid(0:m1,0:m2);
      G0(m1+1,m2+1) = sum(T1(sub2ind(size(T1),I1(:)+1,I2(:)+1)).*T1(sub2ind(size(T1),m1-I1(:)+1,m2-I2(:)+1)));
   end
end
pdf = spa_bi_hp(KW,s,[0 0],order,{G0,T2});
%
%  distribution function: X = -W, P[X >= 0], saddlepoint tau = -s; inclusion-exclusion (17)
%  over the negative components of tau.  The flipped bivariate terms need the derivatives of
%  K_W at s only: K_f^{(nu)} = prod(g.^nu) K_W^{(nu)}(s), g = -f, at the saddlepoint g.*s.
%
tau = -s;
Nn = find(isAlways(tau < 0));
cdf = vpa(zeros(order,1)); canc = NaN;
for mask = 0:2^numel(Nn)-1
   T = Nn(logical(bitget(mask,1:numel(Nn))));
   sgn = (-1)^numel(T);
   keep = setdiff(1:2,setdiff(Nn,T));
   f = ones(1,2); f(T) = -1; g = -f;
   if numel(keep) == 2
      Kf = KW;
      for n1 = 0:Lc
         for n2 = 0:Lc-n1
            Kf(n1+1,n2+1) = g(1)^n1*g(2)^n2*KW(n1+1,n2+1);
         end
      end
      [~,F2,cc] = spa_bi_hp(Kf(1:Lc+1,1:Lc+1),g.*s,[0 0],order);
      canc = cc(end);
      cdf = cdf+sgn*F2;
   elseif numel(keep) == 1
      j = keep;
      % marginal: Y = f_j X_j = g_j W_j, P[Y >= 0]; K_Y^{(k)}(sig) = g^k K_W^{(k e_j)}(g sig e_j)
      w = saddle_hp(Sinv,B(j),0);                 % K_{W_j}'(w) = 0
      Pj = Sinv-2*w*B{j};
      DB = Pj\B{j};
      Fj = words({DB},ceil(Lc/2));
      Kd = vpa(zeros(Lc+1,1));
      Kd(1) = -(logdetS+log(det(Pj)))/2;
      for k = 1:Lc
         Kd(k+1) = g(j)^k*2^(k-1)*factorial(sym(k-1))*trw(Fj,k);
      end
      [~,cj] = spa_uni_hp(Kd,g(j)*w,0,order);
      cdf = cdf+sgn*(1-cj);
   else
      cdf = cdf+sgn;
   end
end
info = struct('s',double(s),'s_str',{arrayfun(@(v) char(vpa(v,dig)),s(:).','UniformOutput',false)}, ...
   'canc',canc,'time',toc(t0),'digits',dig);
end

function s = saddle_hp(Sinv,B,s0)
%  Newton iteration for grad K_W(s) = 0, first in double precision (damped, staying inside the
%  domain), then in variable precision until the step is below 10^(8-digits)
d = numel(B);
Sd = double(Sinv); Bd = cellfun(@double,B,'UniformOutput',false);
s = s0;
for it = 1:100
   P = Sd; for i = 1:d, P = P-2*s(i)*Bd{i}; end
   DB = cellfun(@(X) P\X,Bd,'UniformOutput',false);
   gr = cellfun(@trace,DB);
   H = zeros(d);
   for i = 1:d, for k = 1:d, H(i,k) = 2*sum(sum(DB{i}.*DB{k}.')); end, end
   step = -(H\gr(:)).';
   if ~all(isfinite(step)), error('acf_spa_hp: the saddlepoint iteration failed (singular Hessian)'); end
   lam = 1;
   while true
      Pn = Sd; for i = 1:d, Pn = Pn-2*(s(i)+lam*step(i))*Bd{i}; end
      [~,flag] = chol(Pn);
      if ~flag, break; end
      lam = lam/2;
      if lam < 1e-14, error('acf_spa_hp: the saddlepoint iteration left the domain'); end
   end
   s = s+lam*step;
   if norm(lam*step) < 1e-14*(1+norm(s)), break; end
end
s = vpa(s);
for it = 1:20
   P = Sinv; for i = 1:d, P = P-2*s(i)*B{i}; end
   Pi = inv(P);
   DB = cellfun(@(X) Pi*X,B,'UniformOutput',false);
   gr = vpa(zeros(1,d)); H = vpa(zeros(d));
   for i = 1:d
      gr(i) = trace(DB{i});
      for k = 1:d, H(i,k) = 2*sum(sum(DB{i}.*DB{k}.')); end
   end
   step = -(H\gr.').';
   s = s+step;
   if double(max(abs(step)))*1e0 < 10^(8-digits)*(1+double(max(abs(s)))), break; end
end
end

function F = words(DA,H)
%  F{key} = F_beta, the sum of all products of the matrices DA{i} with multiplicities beta,
%  |beta| <= H, stored in a containers.Map keyed by sprintf('%d ',beta)
p = numel(DA);
F = containers.Map('KeyType','char','ValueType','any');
for m = 1:H
   B = comps(m,p);
   for b = 1:size(B,1)
      be = B(b,:);
      if p == 3 && be(3) > 2, continue; end
      X = [];
      for i = 1:p
         if be(i) > 0
            bb = be; bb(i) = bb(i)-1;
            if m == 1, Y = DA{i}; else, Y = DA{i}*F(key(bb)); end
            if isempty(X), X = Y; else, X = X+Y; end
         end
      end
      F(key(be)) = X;
   end
end
end

function v = trw(F,al)
%  tr F_alpha, from F_beta with |beta| <= ceil(|alpha|/2): tr F_alpha = sum_beta tr(F_beta F_{alpha-beta})
m = sum(al);
if F.isKey(key(al))
   v = trace(F(key(al)));
   return
end
h = floor(m/2);
B = comps(h,numel(al));
v = vpa(0);
for b = 1:size(B,1)
   be = B(b,:);
   if any(be > al), continue; end
   X = F(key(be)); Y = F(key(al-be));
   v = v+sum(sum(X.*Y.'));
end
end

function k = key(b)
k = sprintf('%d ',b);
end

function C = comps(m,p)
%  all nonnegative integer p-vectors with sum m
if p == 1, C = m; return; end
C = zeros(0,p);
for k = m:-1:0
   R = comps(m-k,p-1);
   C = [C; k*ones(size(R,1),1) R]; %#ok<AGROW>
end
end
