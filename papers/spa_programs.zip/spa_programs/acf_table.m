%ACF_TABLE Prints Table S8 of the Supplementary Material (pairs of sample autocorrelations) from acf_results.mat,
%   produced by acf_table_run.m (exact values by numerical inversion).  The expansions of orders
%   1-5 are computed by acf_spa in double precision, in whitened coordinates (spa_bi), which keeps
%   the cancellation among their terms small also in the blocks with rho = 0.5.  When the files
%   written by acf_table_hp.m (50-digit arithmetic) are present, the double-precision values are
%   compared with them and the largest relative difference is reported at the end.  Relative
%   errors of the distribution function are relative to min(F,1-F), those of the density relative
%   to f.  The comment at the end of each row gives the cancellation indicators canc and C
%   of spa_bi.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
here = fileparts(mfilename('fullpath'));            % data files are read from this folder
S = load(fullfile(here,'acf_results.mat'),'R'); R = S.R;
order = 5; last = []; Mats = {}; ip = 0; dmax = 0; nhp = 0;
for i = 1:numel(R)
   r = R(i);
   if ~isequal([r.N r.rho],last)
      fprintf('\\multicolumn{11}{l}{$N=%d$, $\\rho=%g$}\\\\\n',r.N,r.rho); last = [r.N r.rho];
      Mats = acf_setup(r.N,r.rho,[1 2]); clear acf_Kfun
      ip = 0;
   end
   ip = ip+1;
   [pdf,cdf,shat,canc,C] = acf_spa(r.c,Mats,order);
   hpfile = fullfile(here,sprintf('acf_hp_N%d_rho%g_%d_50.mat',r.N,r.rho,ip));
   if exist(hpfile,'file')
      H = load(hpfile);
      if isequal(H.q,r.q)
         dmax = max([dmax; abs(pdf(:)-H.pdf(:))./abs(H.pdf(:)); abs(cdf(:)-H.cdf(:))./min(H.cdf(:),1-H.cdf(:))]);
         nhp = nhp+1;
      end
   end
   star = ''; if any(-shat < 0), star = '$^*$'; end     % saddlepoint of -W has a negative component
   Fex = r.Fex; if isnan(Fex), Fex = r.Fbqf; end
   ec = (cdf(:)'-Fex)/min(Fex,1-Fex); ep = (pdf(:)'-r.fex)/r.fex;
   fprintf('(%g,%g)%s & %s & %s\\\\   %% canc %.1e, C %.1e\n',r.q,star,e1(ec),e1(ep),canc,C);
end
if nhp > 0
   fprintf('%% largest relative difference between the double-precision and the 50-digit expansions over %d points: %.1e\n',nhp,dmax);
end
function s = e1(x)
   s = '';
   for v = x
      t = sprintf('%.1e',v); u = regexp(t,'e([+-]\d+)','tokens'); ex = str2double(u{1}{1});
      s = [s sprintf('$%s_{%d}$ & ',t(1:strfind(t,'e')-1),ex)]; %#ok<AGROW>
   end
   s = s(1:end-3);
end
