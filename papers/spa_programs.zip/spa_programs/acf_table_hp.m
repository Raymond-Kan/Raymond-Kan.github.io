function acf_table_hp(ip,dig,N,rho,outdir)
%ACF_TABLE_HP High-precision expansions of orders 1-5 of the density and the distribution function
%   for Table S8 of the Supplementary Material: block (N,rho) (default N = 100, rho = 0.5), points ip (indices into
%   the list Q below), dig digits (default 50).  Saves acf_hp_N<N>_rho<rho>_<ip>_<dig>.mat in
%   outdir (default: the folder of this file, where acf_table.m looks for it).  The
%   points are independent and can be run in separate MATLAB sessions; acf_table.m reads the
%   files.  About eight minutes per point for N = 100.  Besides the double-precision values, each
%   file keeps the full-precision results as decimal strings (pdf_str, cdf_str, and tau_str, the
%   saddlepoint s of the cgf of (W_1,W_2) of acf_spa_hp, taken before conversion to double), the
%   working precision, the date, the MATLAB version and the SHA-256 hashes of acf_spa_hp.m,
%   spa_bi_hp.m and spa_uni_hp.m, so that a later run can be checked against them.  (The files
%   supplied with the programs predate these fields and hold the double-precision values.)
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
if nargin < 2 || isempty(dig), dig = 50; end
if nargin < 3 || isempty(N), N = 100; end
if nargin < 4 || isempty(rho), rho = 0.5; end
if nargin < 5 || isempty(outdir), outdir = fileparts(mfilename('fullpath')); end
order = 5;
Q = [-1 -1; 0.5 0.5; 1.5 -0.5; -0.5 1.5; 1 2; 2 2];
for i = ip(:)'
   [pdfv,cdfv,info] = acf_spa_hp(N,rho,Q(i,:),order,dig);
   pdf = double(pdfv); cdf = double(cdfv); q = Q(i,:);  %#ok<NASGU>
   pdf_str = arrayfun(@(v) char(vpa(v,dig)),pdfv(:),'UniformOutput',false);  %#ok<NASGU>
   cdf_str = arrayfun(@(v) char(vpa(v,dig)),cdfv(:),'UniformOutput',false);  %#ok<NASGU>
   tau_str = info.s_str(:);                         % saddlepoint of K_W, full precision %#ok<NASGU>
   prov = struct('date',char(datetime('now','Format','yyyy-MM-dd HH:mm')),'matlab',version, ...
      'digits',dig,'hash',struct('acf_spa_hp',filehash('acf_spa_hp.m'), ...
      'spa_bi_hp',filehash('spa_bi_hp.m'),'spa_uni_hp',filehash('spa_uni_hp.m'))); %#ok<NASGU>
   save(fullfile(outdir,sprintf('acf_hp_N%d_rho%g_%d_%d.mat',N,rho,i,dig)),'N','rho','q','pdf','cdf','info','dig', ...
      'pdf_str','cdf_str','tau_str','prov');
   fprintf('point %d done, %.0f s\n',i,info.time);
end
end

function h = filehash(f)
%  SHA-256 of a file on the MATLAB path (Java), '' if it cannot be read
h = '';
try
   fn = which(f); bytes = fileread(fn);
   md = java.security.MessageDigest.getInstance('SHA-256');
   d = typecast(md.digest(uint8(bytes)),'uint8');
   h = lower(reshape(dec2hex(d)',1,[]));
catch
end
end
