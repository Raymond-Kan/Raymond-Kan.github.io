%ACF_TABLE_RUN Computes the entries of Table S8 of the Supplementary Material (pairs of sample autocorrelations),
%   with exact values by MATLAB's integral2 (acf_exact_pdf, acf_exact_cdf), and saves them in
%   acf_results_integral2.mat; run in the background.  The exact values used for the paper, in
%   acf_results.mat, were computed by the trapezoidal rule (acf_exact_trap.py) and verified in
%   34-digit arithmetic (acf_exact_hp.wls, acf_exact_34.csv); integral2 agrees with them to about
%   1e-13 except for the densities at q = (1.5,-0.5) with rho = 0.5, where its absolute tolerance
%   limits the relative accuracy (errors 1.2e-4 for N = 50, 1.5e-7 for N = 100).  acf_table.m prints
%   the table from acf_results.mat.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
cases = {50,0; 100,0; 50,0.5; 100,0.5};
Q = [-1 -1; 0.5 0.5; 1.5 -0.5; -0.5 1.5; 1 2; 2 2];
order = 4;
R = struct('N',{},'rho',{},'c',{},'q',{},'shat',{},'pdf',{},'cdf',{},'fex',{},'Fex',{},'Fbqf',{},'t',{});
fid = fopen('acf_table_log.txt','w');
for ic = 1:size(cases,1)
   N = cases{ic,1}; rho = cases{ic,2};
   Mats = acf_setup(N,rho,[1 2]);
   m = [rho rho^2];
   for ip = 1:size(Q,1)
      c = m+Q(ip,:)/sqrt(N);
      t0 = tic;
      [pdf,cdf,shat] = acf_spa(c,Mats,order);
      fex = acf_exact_pdf(c,Mats,1e-10);
      Fex = acf_exact_cdf(c,Mats,1e-10);
      Fbqf = NaN;                       % optional independent check (bqfcdf, not distributed)
      if exist('bqfcdf','file')
         Fbqf = bqfcdf(0,0,Mats{1}-c(1)*Mats{3},Mats{2}-c(2)*Mats{3},zeros(N,1),1e-13);
      end
      t = toc(t0);
      R(end+1) = struct('N',N,'rho',rho,'c',c,'q',Q(ip,:),'shat',shat,'pdf',pdf,'cdf',cdf,'fex',fex,'Fex',Fex,'Fbqf',Fbqf,'t',t); %#ok<SAGROW>
      fprintf(fid,'N=%d rho=%g q=(%g,%g) c=(%.4f,%.4f) shat=(%.4f,%.4f) t=%.0fs\n  pdf %.12g err %s\n  cdf %.12g (bqfcdf %.12g) err %s\n', ...
         N,rho,Q(ip,:),c,shat,t,fex,sprintf('%.1e ',(pdf'-fex)/fex),Fex,Fbqf,sprintf('%.1e ',(cdf'-Fex)/min(Fex,1-Fex)));
      save acf_results_integral2.mat R
   end
end
fclose(fid);
