%BQF_TABLE Reproduces Table 6 of the paper: pairs of quadratic forms with a common component,
%   Q1 = X0+X1, Q2 = X0+X2, X_i ~ chi^2_{m_i}(lambda_i), using spa_bi (bivariate expansions of
%   Section 3) and spa_uni (marginals for the inclusion-exclusion step).  Reads bqfcc_exact.csv
%   (m0,m1,m2,lam0,lam1,lam2,c1,c2,x1,x2,Fup,pdf; exact values by one-dimensional integration in
%   30-digit arithmetic, bqfcc_exact.m gives them in double precision) and prints the LaTeX rows:
%   relative errors of the orthant probability and of the density, orders 1..5.
%   The rows are computed in double precision, in whitened coordinates (spa_bi), where the
%   cancellation indicator kappa of order five is at most 4 (it reaches 2e6 in the original
%   coordinates).  With HP = true set before the call, the expansions are also computed in 40-digit
%   arithmetic (spa_bi_hp, spa_uni_hp; about ten seconds per point) and the comment at the end of
%   each row gives the largest difference between the double-precision and the 40-digit relative
%   errors (at most 7e-14 over the table); otherwise the comment gives only the cancellation
%   indicators canc and kappa of spa_bi.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
D = readmatrix(fullfile(fileparts(mfilename('fullpath')),'bqfcc_exact.csv'));   % beside this file
order = 5; last = []; dig = 40;
if ~exist('HP','var'), HP = false; end
for i = 1:size(D,1)
   m = D(i,[2 3 1]); lam = D(i,[5 6 4]);           % programs use [m1 m2 m0], [lam1 lam2 lam0]
   if ~isequal([m lam],last)
      fprintf('\\multicolumn{11}{l}{$(m_0,m_1,m_2)=(%d,%d,%d)$, $(\\lambda_0,\\lambda_1,\\lambda_2)=(%d,%d,%d)$}\\\\\n',D(i,1:3),D(i,4:6));
      last = [m lam];
   end
   Kf = @(nu,t) bqfcc_Kfun(nu,t,m,lam);
   x = D(i,9:10); Fup = D(i,11); pdf = D(i,12);
   [pdfs,Fs,tau,canc,kappa] = spa_bi(Kf,x,order,[],[],400);   % 400 quadrature nodes per coordinate
   star = '';
   if any(tau < 0)
      % inclusion-exclusion (Section 3.3): here tau(1) < 0, tau(2) > 0
      star = '$^*$';
      [Fs,~,canc,kappa] = spa_orthant2(Kf,x,order);
   end
   ec = (Fs'-Fup)/Fup; ep = (pdfs'-pdf)/pdf;
   if HP
      [Fh,ph] = bqf_hp(x,m,lam,order,dig,tau);
      dd = max([abs((Fh'-Fup)/Fup-ec) abs((ph'-pdf)/pdf-ep)]);
      fprintf('(%.1f,%.1f)%s & %s & %s\\\\   %% canc %.1e, kappa %.1e, double vs %d digits %.0e\n', ...
         D(i,7:8),star,e1(ec),e1(ep),canc(end),kappa(end),dig,dd);
   else
      fprintf('(%.1f,%.1f)%s & %s & %s\\\\   %% canc %.1e, kappa %.1e\n',D(i,7:8),star,e1(ec),e1(ep),canc(end),kappa(end));
   end
end

function [Fup,pdf] = bqf_hp(x,m,lam,order,dig,tau0)
%  orthant probability and density of orders 1..order in dig-digit arithmetic (spa_bi_hp), with
%  the inclusion-exclusion step when the first saddlepoint component is negative; returns double
olddig = digits(dig); cleanup = onCleanup(@() digits(olddig));
L = 2*order+1; x = vpa(x);
tau = saddle_hp(@(nu,t) kbq(nu,t,m,lam),x,vpa(tau0));
Kd = kdtab(@(nu,t) kbq(nu,t,m,lam),tau,L);
[pdf,Fup] = spa_bi_hp(Kd,tau,x,order);
if isAlways(tau(1) < 0)
   % P[Q1 >= x1, Q2 >= x2] = P[Q2 >= x2] - P[-Q1 > -x1, Q2 >= x2]
   Kfl = @(nu,t) (-1)^nu(1)*kbq(nu,[-t(1) t(2)],m,lam);
   tf = [-tau(1) tau(2)];
   [~,F2] = spa_bi_hp(kdtab(Kfl,tf,L),tf,[-x(1) x(2)],order);
   K1 = @(k,s) kchi(k,s,m(2),lam(2))+kchi(k,s,m(3),lam(3));   % cgf of Q2 = X2 + X0
   s = vpa(0);
   for it = 1:100
      st = -(K1(1,s)-x(2))/K1(2,s); s = s+st;
      if abs(double(st)) < 10^(5-dig), break, end
   end
   Kd1 = arrayfun(@(k) K1(k,s),0:L).';
   [~,c1] = spa_uni_hp(Kd1,s,x(2),order);
   Fup = (1-c1)-F2;
end
Fup = double(Fup); pdf = double(pdf);
end

function v = kbq(nu,t,m,lam)
%  derivative nu of K(t1,t2) = K1(t1) + K2(t2) + K0(t1+t2) (vpa)
v = kchi(nu(1)+nu(2),t(1)+t(2),m(3),lam(3));
if nu(2) == 0, v = v+kchi(nu(1),t(1),m(1),lam(1)); end
if nu(1) == 0, v = v+kchi(nu(2),t(2),m(2),lam(2)); end
end

function v = kchi(k,u,mm,ll)
%  k-th derivative of the cgf of chi^2_mm(ll) at u (vpa)
if k == 0
   v = -mm/2*log(1-2*u)+ll*u/(1-2*u);
else
   v = 2^(k-1)*factorial(sym(k-1))*mm/(1-2*u)^k+2^(k-1)*factorial(sym(k))*ll/(1-2*u)^(k+1);
end
end

function Kd = kdtab(Kfun,tau,L)
Kd = vpa(zeros(L+1,L+1));
for k = 0:L
   for n1 = 0:k
      Kd(n1+1,k-n1+1) = Kfun([n1 k-n1],tau);
   end
end
end

function tau = saddle_hp(Kfun,x,tau)
%  Newton iteration for K'(tau) = x in variable precision, from a double-precision saddlepoint
for it = 1:100
   g = [Kfun([1 0],tau) Kfun([0 1],tau)]-x;
   H = [Kfun([2 0],tau) Kfun([1 1],tau); Kfun([1 1],tau) Kfun([0 2],tau)];
   st = -(H\g.').';
   tau = tau+st;
   if max(abs(double(st))) < 10^(5-digits), break, end
end
end

function s = e1(x)
   s = '';
   for v = x
      t = sprintf('%.1e',v); u = regexp(t,'e([+-]\d+)','tokens'); ex = str2double(u{1}{1});
      s = [s sprintf('$%s_{%d}$ & ',t(1:strfind(t,'e')-1),ex)]; %#ok<AGROW>
   end
   s = s(1:end-3);
end
