function F = bivtrat_cdfspa(r,n,m1,m2,s1,s2,order)
%F = bivtrat_cdfspa(r,n,m1,m2,s1,s2,order)
%
%  Saddlepoint expansion of order "order" of P(R <= r), R = (m1+s1*T1)/(m2+s2*T2), with
%  T_k = Z_k/sqrt(V), Z1, Z2 independent standard normal and V ~ chi^2_n/n independent of them
%  (the correlation is removed beforehand, see bivtratquantile_spa and gci_cox), from
%     P(R <= r) = P(W < 0) + P(Y < 0) - 2 P(W < 0, Y < 0),  W = X - rY,
%  (Broda and Kan 2016, Lemma 2), X = m1 V + s1 Z1 sqrt(V), Y = m2 V + s2 Z2 sqrt(V)
%  (Section 5.4 of the paper).  The univariate terms are the expansions of Section 4 (spa_uni), and
%  the bivariate term is that of Theorem 1, with the inclusion-exclusion (17) when the saddlepoint
%  of (-W,-Y) has a negative component (spa_orthant2), evaluated in the whitened coordinates of
%  Appendix C with the derivatives of the cumulant generating function in closed form
%  (logquad_kfun).  The Taylor coefficients of the univariate terms come from bivtrat_coef.
%  Needs the folder of the paper's programs (the parent of this folder) on the path; it is added
%  if spa_orthant2 is not found.
if ~exist('spa_orthant2','file'), addpath(fileparts(fileparts(mfilename('fullpath')))); end
N = 2*order+1; S = bivtrat_coef(n,m1,m2,s1,s2,N); W = S.W(r);
fk = factorial(0:N)';
[~,PW] = spa_uni(W.thetaW(1:N+1).*fk,W.s0,0,order);          % P(W <= 0), Section 4 at 0
[~,PY] = spa_uni(S.thetaY(1:N+1).*fk,S.t0,0,order);          % P(Y <= 0)
[Kf,Kw] = logquad_kfun(n,diag([s1^2 s2^2]),[m1;m2],[-1 0; r -1],max(16,N));   % cgf of (-W,-Y)
opts.Kwhite = Kw;
PWY = spa_orthant2(Kf,[0 0],order,opts);                     % P(-W >= 0, -Y >= 0), with (17)
F = PW(order)+PY(order)-2*PWY(order);
end
