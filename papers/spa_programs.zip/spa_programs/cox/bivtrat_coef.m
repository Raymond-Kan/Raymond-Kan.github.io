function S = bivtrat_coef(n,m1,m2,s1,s2,D)
%S = bivtrat_coef(n,m1,m2,s1,s2,D)
%
%  Taylor coefficients, to any order, of the joint cumulant generating function of
%  (X,Y) = (m1*V + s1*Z1*sqrt(V), m2*V + s2*Z2*sqrt(V)), V = U^2 = X/n with X ~ chi^2_n, Z1, Z2
%  independent standard normal, so that X/Y = (m1+s1*T1)/(m2+s2*T2) with T_k = Z_k/U:
%     K(s,t) = -(n/2) log[1 - {s1^2 s^2 + s2^2 t^2 + 2(m1 s + m2 t)}/n].
%  The expansions of Broda and Kan (2016) use the coefficients at the joint saddlepoint
%  st = (-m1/s1^2, -m2/s2^2) (K_1 = K_2 = 0), where K is a function of the squared deviations
%  only: with c = {(m1/s1)^2 + (m2/s2)^2}/n and y = s1^2 sig^2 + s2^2 tau^2,
%     K(st + (sig,tau)) = -(n/2) log(1+c) + (n/2) sum_{j>=1} y^j / {j n^j (1+c)^j},
%  and likewise for the univariate K_Y(t) = K(0,t) at t0 = -m2/s2^2 and, for each r, for
%  K_W(s) = K(s,-r s) at s0 = (m2 r - m1)/c2, c2 = s1^2 + r^2 s2^2, and for the amplitude
%  G(s) = K_2(s,-r s) of the ratio density at s0:
%     G(s0 + sig) = (c1/c2 - r s2^2 sig)/(1+cW) * sum_{j>=0} {c2/(n(1+cW))}^j sig^{2j},
%  c1 = m2 s1^2 + m1 r s2^2, cW = (m2 r - m1) s0/n.  These reproduce the coefficients that were
%  coded by hand up to order 3 in the 2015 programs.
%
%  Output S (all coefficients are of the form K^{(k)}/k!, as the programs expect):
%     S.theta  (D+1)x(D+1), theta(p+1,k+1) = K_{1^{p-k} 2^k}(st)/((p-k)! k!) (row = total order,
%              column = order in t; zero above the diagonal and for odd p-k or k)
%     S.st     the joint saddlepoint [-m1/s1^2 -m2/s2^2]
%     S.thetaY (D+1)x1, K_Y^{(k)}(t0)/k!;  S.t0 = -m2/s2^2
%     S.W(r)   function handle: W = S.W(r) gives W.thetaW ((D+1)x1), W.J ((D+1)x1), W.s0, W.cW
if nargin < 6, D = 12; end
st = [-m1/s1^2 -m2/s2^2];
c = ((m1/s1)^2+(m2/s2)^2)/n;
theta = zeros(D+1);
theta(1,1) = -0.5*n*log1p(c);
for j = 1:floor(D/2)                                 % y^j = sum_i C(j,i) s1^(2i) sig^(2i) s2^(2(j-i)) tau^(2(j-i))
   f = 0.5*n/(j*n^j*(1+c)^j);
   for i = 0:j
      theta(2*j+1,2*(j-i)+1) = f*nchoosek(j,i)*s1^(2*i)*s2^(2*(j-i));
   end
end
t0 = -m2/s2^2; cY = (m2/s2)^2/n;
thetaY = zeros(D+1,1); thetaY(1) = -0.5*n*log1p(cY);
for j = 1:floor(D/2), thetaY(2*j+1) = 0.5*n*s2^(2*j)/(j*n^j*(1+cY)^j); end
S = struct('theta',theta,'st',st,'thetaY',thetaY,'t0',t0,'W',@(r) wcoef(r));
   function W = wcoef(r)
      c1 = m2*s1^2+m1*r*s2^2; c2 = s1^2+(r*s2)^2;
      s0 = (m2*r-m1)/c2; cW = (m2*r-m1)*s0/n;
      thetaW = zeros(D+1,1); thetaW(1) = -0.5*n*log1p(cW);
      for jj = 1:floor(D/2), thetaW(2*jj+1) = 0.5*n*c2^jj/(jj*n^jj*(1+cW)^jj); end
      J = zeros(D+1,1);
      for jj = 0:floor(D/2)
         g = (c2/(n*(1+cW)))^jj/(1+cW);
         J(2*jj+1) = c1/c2*g;
         if 2*jj+2 <= D+1, J(2*jj+2) = -r*s2^2*g; end
      end
      W = struct('thetaW',thetaW,'J',J,'s0',s0,'cW',cW,'c1',c1,'c2',c2);
   end
end
