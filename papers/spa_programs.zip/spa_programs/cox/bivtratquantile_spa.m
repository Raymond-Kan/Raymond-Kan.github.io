function q = bivtratquantile_spa(alpha,n,m1,m2,s1,s2,rho,order)
%q = bivtratquantile_spa(alpha,n,m1,m2,s1,s2,rho,order)
%
%  Saddlepoint approximation of order "order" (default 1) to the 100*alpha percent quantile of
%  (m1+s1*T_1)/(m2+s2*T_2), where (T_1,T_2) is bivariate t with n degrees of freedom and
%  correlation rho: the root of the approximate distribution function of bivtrat_cdfspa, after
%  the correlation is removed by R = Rt + q, q = rho*s1/s2 (Section 5.4 of the paper).
%
%  Reference: Broda, S.A., and Kan, R. (2016), "On Distributions of Ratios", Biometrika.
if ~isscalar(alpha)
   error('alpha must be scalar.');
end
if nargin < 8, order = 1; end
adj = s1*rho/s2;
m1 = m1-adj*m2;
s1 = s1*sqrt(1-rho^2);
ss = min(abs([s1 s2]));                 % a common scale leaves the ratio unchanged
m1 = m1/ss; m2 = m2/ss; s1 = s1/ss; s2 = s2/ss;
options = optimset('disp','none');
if m2==0
   rstart = 0;
else
   rstart = norminv(alpha,m1/m2,sqrt((s1^2+(m1*s2/m2)^2)/m2^2));
end
q = fzero(@(r) bivtrat_cdfspa(r,n,m1,m2,s1,s2,order)-alpha,rstart,options)+adj;
end
