function S = gci_cox(order)
%S = gci_cox(order)
%
%  Section 5.4 and Table 5 of the paper: Cox's (1985) gravel data (Bebu, Seillier-Moiseiwitsch and
%  Mathew 2009, Section 2.3).  The generalized confidence interval for the ratio beta_1/beta_2 of
%  two regression coefficients is given by the quantiles of R = (bhat_1 - s_1 T1)/(bhat_2 - s_2 T2),
%  (T1,T2) bivariate t with nu = n - p degrees of freedom and the estimated correlation rho.  The
%  regression is fitted to the data and the unrounded estimates are used.  Prints
%     - P(Y < 0) and the exact 95% interval (bivtratquantile),
%     - the 95% intervals from the expansions of orders 1..order (bivtratquantile_spa),
%     - Table 5: exact P(Rt <= r) (bivtrat), Rt = R - q, q = rho s_1/s_2 (zero for these data), and
%       the relative errors, normalized by min(F,1-F), of the expansions of orders 1..order
%       (bivtrat_cdfspa) at r = -5, -3, -1, 0, 2, 5, 15.
%  order: highest order (default 5).  Returns S with the inputs, the intervals (exact, and order x 2
%  for the expansions), r, the exact values and the relative errors (order x 7).
%  Run from this folder, or with this folder on the path; the folder of the paper's programs (the
%  parent of this folder) is added to the path if needed.
if nargin < 1, order = 5; end
if ~exist('spa_orthant2','file'), addpath(fileparts(fileparts(mfilename('fullpath')))); end
alpha = 0.05;
% the data (Cox 1985, Table 1): percentage of fine gravel in two kinds of surface soil, 7 samples each
y = [5.9 3.8 6.5 18.3 18.2 16.1 7.6 7.6 0.4 1.1 3.2 6.5 4.1 4.7]';
X = zeros(14,2); X(1:7,1) = 1; X(8:14,2) = 1;
[nobs,p] = size(X);
bhat = X\y; shat = norm(y-X*bhat)/sqrt(nobs-p); V = shat^2*inv(X'*X); %#ok<MINV>
sd = sqrt(diag(V)); rho = V(1,2)/(sd(1)*sd(2));
nu = nobs-p; m1 = bhat(1); m2 = bhat(2); s1 = -sd(1); s2 = -sd(2);
fprintf('bhat = (%.4f, %.4f), s = (%.4f, %.4f), rho = %.4f, nu = %d, P(Y < 0) = %.4f%%\n', ...
   m1, m2, -s1, -s2, rho, nu, 100*tcdf(-m2/abs(s2),nu));
ci = [bivtratquantile(alpha/2,nu,m1,m2,s1,s2,rho) bivtratquantile(1-alpha/2,nu,m1,m2,s1,s2,rho)];
fprintf('exact 95%% interval: (%.4f, %.4f)\n', ci);
cis = zeros(order,2);
for M = 1:order
   cis(M,:) = [bivtratquantile_spa(alpha/2,nu,m1,m2,s1,s2,rho,M) bivtratquantile_spa(1-alpha/2,nu,m1,m2,s1,s2,rho,M)];
   fprintf('order %d:            (%.4f, %.4f)\n', M, cis(M,:));
end
% Table 5: the ratio with the correlation adjustment removed, Rt = R - q
rs = [-5 -3 -1 0 2 5 15];
q = s1*rho/s2;
[~,Fe] = bivtrat(rs+q,nu,m1,m2,s1,s2,rho);
% parameters of Rt = (a + b T1)/(c + d T2) with independent T1, T2, on a common scale
a = m1-q*m2; b = s1*sqrt(1-rho^2); ss = min(abs([b s2]));
a = a/ss; b = b/ss; c = m2/ss; d = s2/ss;
EF = zeros(order,numel(rs));
for M = 1:order
   for k = 1:numel(rs)
      EF(M,k) = (bivtrat_cdfspa(rs(k),nu,a,c,b,d,M)-Fe(k))/min(Fe(k),1-Fe(k));
   end
end
fprintf('Table 5: exact P(Rt <= r) and relative errors normalized by min(F,1-F)\n');
fprintf('   r      exact    '); fprintf('  order %d  ', 1:order); fprintf('\n');
for k = 1:numel(rs), fprintf('  %3d  %.6e %s\n', rs(k), Fe(k), sprintf(' %9.1e', EF(:,k))); end
S = struct('nu',nu,'bhat',bhat','s',sd','rho',rho,'ci_exact',ci,'ci_spa',cis,'r',rs,'F_exact',Fe,'F_err',EF);
end
