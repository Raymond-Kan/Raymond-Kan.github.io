function [Kfun,Kwhite] = logquad_kfun(n,Q,lin,B,L)
%[Kfun,Kwhite] = logquad_kfun(n,Q,lin,B,L)
%
%  Derivative interface (as used by spa_saddle, spa_bi, spa_orthant2 of the paper's programs)
%  for the cumulant generating function
%     K(x) = -(n/2) log{1 - (x'Qx + 2 lin'x)/n},   x = B t,
%  with Q symmetric (diagonal for the bivariate t ratio: Q = diag(s1^2,s2^2), lin = [m1;m2]) and
%  B a 2x2 matrix (the cgf of (-W,-Y) for W = X - rY, Y the second component, is K(Bt) with
%  B = [-1 0; r -1]).  Since the argument of the logarithm is quadratic, the Taylor expansion of
%  K(p + M d) in d, at any point p along any matrix M, is
%     -(n/2) log u0 + (n/2) sum_{j>=1} z(d)^j/j,   z(d) = {g'd + d'A d}/(n u0),
%  u0 = 1 - q(p)/n, g = 2M'(Qp + lin), A = M'QM, computed in closed form by polynomial
%  multiplication (no substitution, so no loss of digits in the whitened coordinates).
%  Kfun(nu,t): derivative of order nu (1x2) of K(Bt) at t (1x2); NaN outside the domain (u0 <= 0).
%  Kwhite(nu,u,T): derivative of order nu at u of K(B T u), T 2x2 or 2x1 (the marginal terms of
%  the inclusion-exclusion).  All derivatives up to total order L (default 16) are computed at the
%  first call with a new (t) or (u,T) and kept.
if nargin < 5, L = 16; end
lastt = []; lastC = []; lastu = []; lastT = []; lastCw = [];
Kfun = @kf; Kwhite = @kw;
   function v = kf(nu,t)
      t = reshape(t,[],1);
      if isempty(lastt) || ~isequal(t,lastt), lastC = coefs(B*t,B,max(L,sum(nu))); lastt = t; end
      v = pick(lastC,nu);
   end
   function v = kw(nu,u,T)
      u = reshape(u,[],1);
      if isempty(lastu) || ~isequal(u,lastu) || ~isequal(T,lastT), lastCw = coefs(B*T*u,B*T,max(L,sum(nu))); lastu = u; lastT = T; end
      v = pick(lastCw,nu);
   end
   function C = coefs(p,M,Lc)
      % Taylor coefficients of K(p + M d) in d (k = size(M,2) variables), as an array of size
      % (Lc+1)^k; [] outside the domain
      k = size(M,2);
      u0 = 1-(p'*Q*p+2*lin'*p)/n;
      if u0 <= 0, C = []; return, end
      g = 2*M'*(Q*p+lin)/(n*u0); A = M'*Q*M/(n*u0);
      if k == 1
         z = zeros(1,Lc+1); z(2) = g(1); if Lc >= 2, z(3) = A(1,1); end
         C = zeros(1,Lc+1); C(1) = -0.5*n*log(u0);
         zj = z;
         for j = 1:Lc
            C = C+0.5*n*zj/j;
            zj = conv(zj,z); zj = zj(1:Lc+1);
         end
      else
         z = zeros(Lc+1); z(2,1) = g(1); z(1,2) = g(2);
         if Lc >= 2, z(3,1) = A(1,1); z(1,3) = A(2,2); z(2,2) = 2*A(1,2); end
         C = zeros(Lc+1); C(1,1) = -0.5*n*log(u0);
         zj = z;
         for j = 1:Lc
            C = C+0.5*n*zj/j;
            zj = conv2(zj,z); zj = zj(1:Lc+1,1:Lc+1);
         end
      end
   end
   function v = pick(C,nu)
      if isempty(C), v = NaN; return, end
      if numel(nu) == 1 || size(C,1) == 1 || isvector(C)
         v = C(nu(1)+1)*factorial(nu(1));
      else
         v = C(nu(1)+1,nu(2)+1)*prod(factorial(nu));
      end
   end
end
