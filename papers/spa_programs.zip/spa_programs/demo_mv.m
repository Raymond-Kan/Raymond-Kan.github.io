%DEMO_MV Examples of the trivariate and general-dimension programs (user manual, Section 4).
%   Q_j = X_0 + X_j, X_i ~ chi^2_{m_i}(lambda_i) independent (mvcc_Kfun), exact values by
%   one-dimensional integration (mvcc_exact).
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
e = @(v) sprintf('%9.1e',v);
%
%  1. Three dimensions (spa_tri): orders 1..4 (in whitened coordinates the cancellation
%     indicator stays small and no variable-precision refinement is triggered)
m3 = [15 20 25 10]; l3 = [5 10 0 8];            % [m1 m2 m3 m0], [lam1 lam2 lam3 lam0]
Kf3 = @(nu,t) mvcc_Kfun(nu,t,m3,l3);
x = [80 95 100];
[Fe,fe] = mvcc_exact(x,m3,l3);
[pdf,Fup,tau,kappa,err,info] = spa_tri(Kf3,x,4);
fprintf('P[Q >= (%g,%g,%g)] = %.10e, saddlepoint (%.4f,%.4f,%.4f)\n',x,Fe,tau);
fprintf('  rel. error of the orthant probability, orders 1..4: %s\n',e((Fup'-Fe)/Fe));
fprintf('  rel. error of the density, orders 1..4:             %s\n',e((pdf'-fe)/fe));
fprintf('      (cancellation indicator %.1e; recomputed in variable precision: %d)\n',kappa(end),info.refined);
%
%  2. A saddlepoint with a negative component: inclusion-exclusion (spa_orthant)
x = [55 70 75];
Fe = mvcc_exact(x,m3,l3);
[F,tau] = spa_orthant(Kf3,x,3);
fprintf('P[Q >= (%g,%g,%g)], saddlepoint (%.4f,%.4f,%.4f), inclusion-exclusion:\n',x,tau);
fprintf('  rel. error, orders 1..3:                            %s\n',e((F'-Fe)/Fe));
%
%  3. Four dimensions (spa_mv): density exact, orthant probability by quasi-Monte Carlo
m4 = [15 20 25 30 10]; l4 = [5 10 0 3 8];
Kf4 = @(nu,t) mvcc_Kfun(nu,t,m4,l4);
x = [70 85 95 105];
[Fe,fe] = mvcc_exact(x,m4,l4);
[pdf,~,tau] = spa_mv(Kf4,x,3);
[F,~,se] = spa_orthant(Kf4,x,3);
fprintf('4-d point (%g,%g,%g,%g): saddlepoint (%.3f,%.3f,%.3f,%.3f)\n',x,tau);
fprintf('  rel. error of the density, orders 1..3:             %s\n',e((pdf'-fe)/fe));
fprintf('  rel. error of the orthant probability, orders 1..3: %s\n',e((F'-Fe)/Fe));
fprintf('      (simulation standard error, relative:           %s)\n',e(se'/Fe));
