%DEMO_SPA Short examples of the programs (see the user manual, Section 4).
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
%
%  1. Noncentral chi-squared: orders 1..6 against MATLAB's ncx2cdf/ncx2pdf
nu = 5; lam = 10; x = 30;
[cdf,pdf] = ncx2_spa(x,nu,lam,6);
F = ncx2cdf(x,nu,lam); f = ncx2pdf(x,nu,lam);
fprintf('chi2_%d(%d) at x = %g: exact cdf %.12f, pdf %.12f\n',nu,lam,x,F,f);
fprintf('  rel. error of 1-F, orders 1..6: %s\n',sprintf('%9.1e',((1-cdf')-(1-F))/(1-F)));
fprintf('  rel. error of f,   orders 1..6: %s\n',sprintf('%9.1e',(pdf'-f)/f));
%
%  2. Singly noncentral F: orders 1..4 against ncfcdf/ncfpdf
m = 4; n = 12; lam = 3; fq = 2.5;
[cdf,pdf] = ncf_spa(fq,m,n,lam,4);
F = ncfcdf(fq,m,n,lam); f = ncfpdf(fq,m,n,lam);
fprintf('F_{%d,%d}(%d) at f = %g: exact cdf %.10f, pdf %.10f\n',m,n,lam,fq,F,f);
fprintf('  rel. error of cdf, orders 1..4: %s\n',sprintf('%9.1e',(cdf'-F)/min(F,1-F)));
fprintf('  rel. error of pdf, orders 1..4: %s\n',sprintf('%9.1e',(pdf'-f)/f));
%
%  3. A general univariate cgf: the gamma distribution with shape 3 (spa_uni directly)
a = 3; x = 6;                                   % K(s) = -a log(1-s), saddlepoint s = 1-a/x
s = 1-a/x; order = 4;
Kd = zeros(2*order+2,1); Kd(1) = -a*log(1-s);
for k = 1:2*order+1, Kd(k+1) = a*factorial(k-1)/(1-s)^k; end
[pdf,cdf] = spa_uni(Kd,s,x,order);
fprintf('Gamma(%d) at x = %g: rel. errors of cdf %s, of pdf %s\n',a,x, ...
   sprintf('%9.1e',(cdf'-gamcdf(x,a))/(1-gamcdf(x,a))),sprintf('%9.1e',(pdf'-gampdf(x,a))/gampdf(x,a)));
%
%  4. Bivariate: Q1 = X0+X1, Q2 = X0+X2 with X_i ~ chi^2_{m_i}(lam_i) (spa_bi, spa_orthant2)
mm = [15 20 10]; ll = [5 10 8];                % [m1 m2 m0], [lam1 lam2 lam0]
Kf = @(nu,t) bqfcc_Kfun(nu,t,mm,ll);
x = [55 70];
[pdfs,Fs,tau,canc] = spa_bi(Kf,x,4);
[Fup,pdfe] = bqfcc_exact(x(1),x(2),mm,ll);
fprintf('P[Q1 >= %g, Q2 >= %g] = %.10f, saddlepoint (%.4f,%.4f)\n',x,Fup,tau);
fprintf('  rel. errors of the orthant probability, orders 1..4: %s (cancellation indicator %.1e)\n', ...
   sprintf('%9.1e',(Fs'-Fup)/Fup),canc(end));
fprintf('  rel. errors of the density, orders 1..4:             %s\n',sprintf('%9.1e',(pdfs'-pdfe)/pdfe));
Fs2 = spa_orthant2(Kf,x,4);                     % same, with inclusion-exclusion when needed
fprintf('  spa_orthant2 agrees: %d\n',max(abs(Fs2-Fs)) < 1e-14);
