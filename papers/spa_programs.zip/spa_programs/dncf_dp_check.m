%DNCF_DP_CHECK compares dncf_exact_dp with the 30-digit Mathematica values and times it.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
D = readmatrix(fullfile(fileparts(mfilename('fullpath')),'dncf_exact_mma.csv'));   % beside this file
E = zeros(size(D,1),3); tic
for i = 1:size(D,1)
   r = D(i,:);
   [c,u,p] = dncf_exact_dp(r(6),r(1),r(2),r(3),r(4));
   E(i,:) = [abs(c-r(7))/r(7), abs(u-r(8))/r(8), abs(p-r(9))/r(9)];
end
t = toc;
fprintf('%d points, %.3f ms per point\n', size(D,1), 1000*t/size(D,1));
pairs = unique(D(:,3:4),'rows','stable');
for ip = 1:size(pairs,1)
   idx = D(:,3)==pairs(ip,1) & D(:,4)==pairs(ip,2);
   fprintf('(%g,%g): max rel err cdf %.1e, upper %.1e, pdf %.1e\n', pairs(ip,:), max(E(idx,:)));
end
