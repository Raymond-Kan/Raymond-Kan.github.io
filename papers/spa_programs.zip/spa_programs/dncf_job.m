function R = dncf_job(m,lam1,lam2,nvec,P,order)
%DNCF_JOB All points of one job: fixed m and (lam1,lam2), all n in nvec and probabilities P.
%   For each point: the quantile f and the exact cdf, upper tail and pdf there
%   (dncf_quantile), and the relative errors of the saddlepoint approximations of orders
%   1..order (dncf_spa), with the cdf error relative to min(F,1-F) (the smaller tail is
%   computed directly), and the cancellation indicator kappa of the cdf sum.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
t0 = tic;
np = numel(nvec)*numel(P);
R.m = m; R.lam = [lam1 lam2]; R.P = P(:);
R.n = zeros(np,1,'uint8'); R.ip = zeros(np,1,'uint8');
R.f = zeros(np,1); R.cdf = R.f; R.upp = R.f; R.pdf = R.f; R.nit = zeros(np,1,'uint8');
R.ec = nan(np,order,'single'); R.ep = R.ec; R.kappa = R.ec;
i = 0;
for n = nvec(:)'
   for ip = 1:numel(P)
      i = i+1;
      [f,c,u,d,nit] = dncf_quantile(P(ip),m,n,lam1,lam2);
      R.n(i) = n; R.ip(i) = ip; R.f(i) = f; R.cdf(i) = c; R.upp(i) = u; R.pdf(i) = d; R.nit(i) = nit;
      try
         [cs,ps,us,ka] = dncf_spa(f,m,n,lam1,lam2,order);
         if c <= u
            R.ec(i,:) = abs(cs'-c)/c;
         else
            R.ec(i,:) = abs(us'-u)/u;
         end
         R.ep(i,:) = abs(ps'-d)/d; R.kappa(i,:) = ka';
      catch
      end
   end
end
R.time = toc(t0);
end
