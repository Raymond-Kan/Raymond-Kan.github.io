function [f,cdf,upp,pdf,nit] = dncf_quantile(p,m,n,lam1,lam2)
%DNCF_QUANTILE Quantile f of probability p of the doubly noncentral F, with the exact cdf,
%   upper tail and pdf at f (dncf_exact_dp). Start: quantile of the first-order saddlepoint
%   approximation; then Newton steps in t = log f on the log of the smaller tail, using the
%   exact cdf and pdf, until the tail matches p to a relative 1e-6. nit = number of exact
%   evaluations (0 if Newton did not converge in 40 steps; the values returned are still the
%   exact ones at the returned f).
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
lo = p < 0.5;
if lo, tgt = log(p); else, tgt = log1p(-p); end
t = log((1+lam1/m)/(1+lam2/n));                     % log of the ratio of the means of Q1/m, Q2/n
try
   t1 = fzero(@(t) spatail(t,m,n,lam1,lam2,lo)-tgt, t, optimset('TolX',1e-4,'Display','off'));
   if isfinite(t1) && isreal(t1), t = t1; end
catch
end
nit = 0;
for it = 1:40
   f = exp(t);
   [cdf,upp,pdf] = dncf_exact_dp(f,m,n,lam1,lam2);
   if lo
      g = log(cdf)-tgt; slope = f*pdf/cdf;
   else
      g = log(upp)-tgt; slope = -f*pdf/upp;
   end
   if abs(g) < 1e-6, nit = it; return, end
   dt = -g/slope;
   if ~isfinite(dt), break, end
   t = t + max(-2,min(2,dt));
end
end

function v = spatail(t,m,n,lam1,lam2,lo)
c = dncf_spa(exp(t),m,n,lam1,lam2,1);
if lo, v = log(c); else, v = log(1-c); end
if ~isreal(v) || ~isfinite(v), v = NaN; end           % fzero then fails and the mean is used as start
end
