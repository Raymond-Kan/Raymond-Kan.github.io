function dncf_run(mode,root)
%DNCF_RUN Grid A for the doubly noncentral F: m,n = 1..100, (lam1,lam2) in {1,10,100,1000}^2,
%   101 quantiles 0.001, 0.01, 0.02, ..., 0.99, 0.999; approximations of orders 1..6.
%   dncf_run          full grid (16 x 100 jobs of 10,100 points each), in parallel
%   dncf_run('test')  small grid (m,n in {1,10,100}, all 16 lambda pairs, 14,544 points) to check
%                     the set-up and estimate the running time of the full grid
%   Each job (one lambda pair and one m) is saved in results_gridA/ (results_test/) as soon as
%   it is finished, and jobs already saved are skipped, so the run can be stopped and restarted.
%   Progress is written to the screen and to dncf_run_<mode>.log.
%   dncf_run(mode,root) keeps the results folder and the log in root (default: the folder of this
%   file), independently of MATLAB's current folder.  Saved jobs are reused without a check of
%   the settings that produced them; delete the results folder after changing the programs.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
if nargin < 1, mode = 'full'; end
if nargin < 2 || isempty(root), root = fileparts(mfilename('fullpath')); end
order = 6;
P = [0.001 0.01:0.01:0.99 0.999];
lam = [1 10 100 1000];
[L1,L2] = ndgrid(lam,lam); pairs = [L1(:) L2(:)];
switch mode
   case 'test'
      mvec = [1 10 100]; nvec = [1 10 100]; outdir = fullfile(root,'results_test');
   otherwise
      mvec = 1:100; nvec = 1:100; outdir = fullfile(root,'results_gridA');
end
if ~exist(outdir,'dir'), mkdir(outdir); end
% jobs, most expensive (largest lambdas) first for load balancing
[I,J] = ndgrid(1:size(pairs,1),1:numel(mvec));
jobs = [I(:) J(:)];
cost = prod(sqrt(pairs(jobs(:,1),:))+3,2);
[~,o] = sort(cost,'descend'); jobs = jobs(o,:);
fname = @(k) fullfile(outdir,sprintf('res_L%02d_m%03d.mat',jobs(k,1),mvec(jobs(k,2))));
todo = find(arrayfun(@(k) ~exist(fname(k),'file'),1:size(jobs,1)));
logf = fopen(fullfile(root,sprintf('dncf_run_%s.log',mode)),'a');
msg(logf,'%s: %d jobs, %d to do, %d points per job',mode,size(jobs,1),numel(todo),numel(nvec)*numel(P));
if isempty(todo), fclose(logf); return, end
if isempty(gcp('nocreate'))
   cl = parcluster('Processes'); nw = feature('numcores');
   if cl.NumWorkers < nw, cl.NumWorkers = nw; end
   parpool(cl,nw);
end
q = parallel.pool.DataQueue; t0 = tic; ndone = 0;
afterEach(q,@progress);
J = jobs(todo,:); names = arrayfun(fname,todo,'UniformOutput',false);
pr = pairs; mv = mvec;
parfor k = 1:numel(todo)
   R = dncf_job(mv(J(k,2)),pr(J(k,1),1),pr(J(k,1),2),nvec,P,order);
   parsave(names{k},R);
   send(q,k);
end
msg(logf,'finished, %.2f hours',toc(t0)/3600);
if strcmp(mode,'test')
   % estimated time of the full grid: CPU time per point for each lambda pair, times 100*100*101
   % points per pair, divided by the number of workers
   cpu = 0;
   for ip = 1:size(pairs,1)
      tt = 0; np = 0;
      for im = 1:numel(mvec)
         S = load(fullfile(outdir,sprintf('res_L%02d_m%03d.mat',ip,mvec(im)))); tt = tt + S.R.time; np = np + numel(S.R.f);
      end
      cpu = cpu + tt/np*100*100*numel(P);
   end
   p = gcp; msg(logf,'estimated time of the full grid on %d workers: %.1f hours',p.NumWorkers,cpu/p.NumWorkers/3600);
end
fclose(logf);
   function progress(~)
      ndone = ndone+1; el = toc(t0);
      msg(logf,'%d/%d jobs done, %.2f h elapsed, about %.2f h to go',ndone,numel(todo),el/3600, ...
          el/ndone*(numel(todo)-ndone)/3600);
   end
end

function parsave(name,R)
save(name,'R');
end

function msg(logf,varargin)
s = sprintf('%s  %s',datestr(now,'yyyy-mm-dd HH:MM:SS'),sprintf(varargin{:}));
fprintf('%s\n',s); fprintf(logf,'%s\n',s);
end
