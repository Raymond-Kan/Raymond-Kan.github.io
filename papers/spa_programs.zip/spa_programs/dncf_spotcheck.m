function dncf_spotcheck(mode,npts,root)
%DNCF_SPOTCHECK Independent check of the exact values of dncf_run: at npts random points
%   (default 400, spread over all lambda pairs) the cdf and pdf saved by dncf_run are compared
%   with one-dimensional numerical integration over Q2 (integral, relative tolerance 1e-13).
%   Prints the maximum relative differences (smaller tail and pdf) for each lambda pair.  root
%   (default: the folder of this file) holds the results folder of dncf_run.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
if nargin < 1, mode = 'full'; end
if nargin < 2, npts = 400; end
if nargin < 3 || isempty(root), root = fileparts(mfilename('fullpath')); end
if strcmp(mode,'test'), outdir = fullfile(root,'results_test'); else, outdir = fullfile(root,'results_gridA'); end
fl = dir(fullfile(outdir,'res_L*_m*.mat'));
rng(1); pick = fl(randperm(numel(fl),min(numel(fl),npts)));
res = zeros(numel(pick),4);
for i = 1:numel(pick)
   S = load(fullfile(outdir,pick(i).name)); R = S.R;
   k = randi(numel(R.f)); m = R.m; n = double(R.n(k)); l1 = R.lam(1); l2 = R.lam(2); f = R.f(k);
   c = m*f/n;
   ci = integral(@(q) ncx2cdf(c*q,m,l1).*ncx2pdf(q,n,l2),0,Inf,'AbsTol',0,'RelTol',1e-13);
   ui = integral(@(q) ncx2cdf(c*q,m,l1,'upper').*ncx2pdf(q,n,l2),0,Inf,'AbsTol',0,'RelTol',1e-13);
   pi_ = m/n*integral(@(q) q.*ncx2pdf(c*q,m,l1).*ncx2pdf(q,n,l2),0,Inf,'AbsTol',0,'RelTol',1e-13);
   if R.cdf(k) <= R.upp(k), et = abs(R.cdf(k)-ci)/ci; else, et = abs(R.upp(k)-ui)/ui; end
   res(i,:) = [l1 l2 et abs(R.pdf(k)-pi_)/pi_];
end
pairs = unique(res(:,1:2),'rows');
for ip = 1:size(pairs,1)
   idx = all(res(:,1:2)==pairs(ip,:),2);
   fprintf('(lam1,lam2) = (%g,%g): %d points, max rel. difference smaller tail %.1e, pdf %.1e\n', ...
      pairs(ip,:),sum(idx),max(res(idx,3)),max(res(idx,4)));
end
fprintf('overall: max %.1e (tail), %.1e (pdf)\n',max(res(:,3)),max(res(:,4)));
end
