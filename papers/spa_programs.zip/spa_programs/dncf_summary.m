function dncf_summary(mode,root)
%DNCF_SUMMARY Table for the doubly noncentral F from the results of dncf_run.
%   For each (lam1,lam2): median, maximum and maximum over min(m,n) >= 10 of the relative
%   errors of the approximations of orders 1..6 of the distribution function (relative to
%   min(F,1-F)) and of the density, as LaTeX rows; also the number of points, of points
%   where Newton did not converge, and of points where an approximation failed (NaN).
%   Output to the screen and to dncf_summary_<mode>.txt.  root (default: the folder of this file)
%   holds the results folder of dncf_run and receives the summary file.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
if nargin < 1, mode = 'full'; end
if nargin < 2 || isempty(root), root = fileparts(mfilename('fullpath')); end
if strcmp(mode,'test'), outdir = fullfile(root,'results_test'); else, outdir = fullfile(root,'results_gridA'); end
fl = dir(fullfile(outdir,'res_L*_m*.mat'));
tok = regexp({fl.name},'res_L(\d+)_m(\d+)','tokens','once');
L = cellfun(@(c) str2double(c{1}),tok);
out = fopen(fullfile(root,sprintf('dncf_summary_%s.txt',mode)),'w');
for l = unique(L)
   ec = []; ep = []; big = []; nit = []; tt = 0; kap = [];
   for k = find(L==l)
      S = load(fullfile(outdir,fl(k).name)); R = S.R;
      ec = [ec; R.ec]; ep = [ep; R.ep]; nit = [nit; R.nit]; tt = tt + R.time; kap = [kap; R.kappa];   %#ok<AGROW>
      big = [big; min(double(R.n),R.m) >= 10];                       %#ok<AGROW>
   end
   big = logical(big);
   pr(out,'(lam1,lam2) = (%g,%g): %d points (%d jobs, %.2f ms per point), Newton not converged %d, cdf NaN %d, pdf NaN %d\n', ...
      R.lam,numel(nit),sum(L==l),1000*tt/numel(nit),sum(nit==0),sum(any(isnan(ec),2)),sum(any(isnan(ep),2)));
   pr(out,'   cancellation indicator kappa of the cdf sum at order 6: median %.1e, max %.1e, points with kappa > 1e8: %d\n', ...
      median(kap(:,end),'omitnan'),max(kap(:,end)),sum(kap(:,end) > 1e8));
   pr(out,'M & cdf: med & max & max(min(m,n)>=10) & pdf: med & max & max(min(m,n)>=10)\\\\\n');
   for M = 1:size(ec,2)
      pr(out,'%d & %s & %s & %s & %s & %s & %s\\\\\n',M,e1(median(ec(:,M),'omitnan')),e1(max(ec(:,M))), ...
         e1(max(ec(big,M))),e1(median(ep(:,M),'omitnan')),e1(max(ep(:,M))),e1(max(ep(big,M))));
   end
end
fclose(out);
end

function pr(out,varargin)
fprintf(varargin{:}); fprintf(out,varargin{:});
end

function s = e1(x)
s = sprintf('%.1e',x);
end
