function S = kl_table(order)
%KL_TABLE Table 2 of the paper and Tables S6 and S7 of the Supplementary Material (Section 5.1): the bivariate example of Kolassa and Li
%   (2010, Table 1).  Y1 = X1+X2, Y2 = X2+X3, X_i independent unit exponentials, (Y1bar,Y2bar)
%   the mean of n pairs; P[Y1bar >= y1, Y2bar >= y2] = int_0^inf g(u) Gbar(y1-u) Gbar(y2-u) du,
%   g and Gbar the density and survival function of the gamma distribution with shape n and scale
%   1/n (relative tolerance 1e-13).
%   Table 2 (n = 5): exact values, the relative errors of the printed approximations of Kolassa
%      and Li (KL) and of Kolassa (2003, K03), the expansions of orders 1..order (default 5,
%      spa_orthant2) and the saddlepoint of the cgf of (Y1bar,Y2bar) (n times the per-observation
%      saddlepoint).  Also the approximation of Kolassa and Li computed by kl_bivar, in both
%      orders of the coordinates, against their printed values.
%   Table S6: at the two points with a negative saddlepoint component, n = 5,...,640: exact
%      values and the relative errors of order one evaluated directly at the negative saddlepoint
%      (spa_bi with opts.direct, Section 3.3) and with the inclusion-exclusion (spa_orthant2);
%      then, for n = 2560, 5120, 10240 at y = (2.5,4.0), log(direct/exact) against -Delta of
%      (22), with the exact value computed on the log scale.
%   Table S7 (n = 5): kl_bivar, evaluated directly in double precision, and our expansion of order
%      2 along y = (2.5+delta, 3.0) and y = (2.5, 2.0+delta) (the lines on which the formula of
%      Kolassa and Li has removable singularities).  The values of kl_bivar near the lines are
%      floating-point artefacts and depend on the details of the arithmetic.
%   S: struct with the rows of the three tables.
%   Requires the Statistics and Machine Learning Toolbox.  About a minute.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
if nargin < 1, order = 5; end
A = [1 0; 1 1; 0 1];
Kn = @(n) @(nu,t) lin_exp_Kfun(nu,t,A,n);
ex = @(y,n) integral(@(u) gampdf(u,n,1/n).*gamcdf(max(y(1)-u,0),n,1/n,'upper').*gamcdf(max(y(2)-u,0),n,1/n,'upper'), ...
   0,Inf,'RelTol',1e-13,'AbsTol',0,'Waypoints',sort(y));
%
%  Table 2.  Printed values of Kolassa and Li (2010, Table 1): KL, K03, exact (three digits)
%
P = [2.5 2.5 9.12e-2 8.98e-2 9.22e-2; 2.5 3.5 1.41e-2 1.41e-2 1.41e-2; 2.5 4.0 3.91e-3 3.99e-3 3.93e-3;
     3.0 3.0 2.20e-2 2.14e-2 2.22e-2; 3.0 3.5 8.97e-3 8.73e-3 8.96e-3; 3.5 3.5 4.40e-3 4.25e-3 4.40e-3;
     3.5 4.0 1.67e-3 1.61e-3 1.66e-3; 4.0 4.0 7.69e-4 7.34e-4 7.58e-4; 2.5 3.0 NaN NaN NaN; 3.0 4.0 NaN NaN NaN];
K5 = Kn(5);
fprintf('Table 2\n');
T8 = [];
for i = 1:size(P,1)
   y = P(i,1:2); e = ex(y,5);
   [F,tau] = spa_orthant2(K5,y,order);
   T8(end+1,:) = [y tau e P(i,3:5) F']; %#ok<AGROW>
   if isnan(P(i,3)), c = ' & --- & ---'; else, c = sprintf(' & %s & %s',fmtE(P(i,3)/e-1),fmtE(P(i,4)/e-1)); end
   tt = round(tau*100)/100; tt(tt == 0) = 0;          % no negative zero
   fprintf('$(%.1f,%.1f)$ & $(%.2f,%.2f)$ & %s%s%s\\\\\n',y,tt,fmtF(e),c,rowE(F'/e-1));
end
fprintf('%% kl_bivar against the printed KL values (relative difference), and its two coordinate orders:\n');
for i = 1:8
   y = P(i,1:2); e = T8(i,5);
   p12 = kl_bivar(K5,y,[1 2]); p21 = kl_bivar(K5,y,[2 1]);
   fprintf('%%   (%.1f,%.1f): printed %.3g, kl_bivar %.6g (%+.4f); order (1,2) error %+.2f%%, (2,1) %+.2f%%\n', ...
      y,P(i,3),p12,p12/P(i,3)-1,100*(p12/e-1),100*(p21/e-1));
end
%
%  Table S6
%
fprintf('Table S6\n');
ns = [5 10 20 40 80 160 320 640];
Y = [2.5 3.5; 2.5 4.0];
T9 = zeros(numel(ns),7);
for j = 1:numel(ns)
   n = ns(j); Kk = Kn(n); T9(j,1) = n;
   for k = 1:2
      y = Y(k,:); e = ex(y,n);
      [~,Fd] = spa_bi(Kk,y,1,[],[],[],struct('direct',true));
      Fr = spa_orthant2(Kk,y,1);
      T9(j,3*k-1:3*k+1) = [e Fd/e-1 Fr/e-1];
   end
   fprintf('%d & %s & %s & %s & %s & %s & %s\\\\\n',n,fmtF4(T9(j,2)),fmtE(T9(j,3)),fmtE(T9(j,4)), ...
      fmtF4(T9(j,5)),fmtE(T9(j,6)),fmtE(T9(j,7)));
end
%  large n on the log scale, y = (2.5,4.0): Delta of (22) from the profile h(s1)
y = [2.5 4.0]; K1 = Kn(1);
s = spa_saddle(K1,y,[0 0]);                          % per-observation saddlepoint, s1 < 0
z = 1-A*s(:); H = zeros(2); for i = 1:3, H = H+A(i,:)'*A(i,:)/z(i)^2; end
t2 = 1-2/y(2);                                       % saddlepoint of the marginal of Y2 (Gamma(2,1))
c3 = (-2*log(1-t2)-t2*y(2))-(-sum(log(z))-s*y(:)+s(1)^2/(2*[1 0]*inv(H)*[1;0]));
T9b = [];
for n = [2560 5120 10240]
   lP = logexact(y,n);
   [~,Fd] = spa_bi(Kn(n),y,1,[],[],[],struct('direct',true,'logscale',lP));
   T9b(end+1,:) = [n log(Fd) -n*c3]; %#ok<AGROW>
   fprintf('%% n = %5d: log(direct/exact) %+.1f, -Delta %+.1f\n',n,log(Fd),-n*c3);
end
%
%  Table S7
%
fprintf('Table S7\n');
ds = [1e-2 1e-3 1e-4 1e-5 1e-6 1e-7 1e-8 0];
T10 = zeros(numel(ds),6);
for j = 1:numel(ds)
   d = ds(j);
   y = [2.5+d 3.0]; e = ex(y,5);
   [F,tau] = spa_orthant2(K5,y,2);
   if abs(tau(1)) < 1e-12, tau(1) = 0; end          % zero up to rounding at delta = 0
   T10(j,1:4) = [d tau(1) kl_bivar(K5,y,[1 2])/e-1 F(2)/e-1];
   y = [2.5 2.0+d]; e = ex(y,5);
   F = spa_orthant2(K5,y,2);
   T10(j,5:6) = [kl_bivar(K5,y,[1 2])/e-1 F(2)/e-1];
   if d == 0, dd = '$0$'; else, dd = sprintf('$10^{%d}$',round(log10(d))); end
   fprintf('%s & %s & %s & %s & %s & %s\\\\\n',dd,fmtE(T10(j,2)),fmtE(T10(j,3)),fmtE(T10(j,4)),fmtE(T10(j,5)),fmtE(T10(j,6)));
end
S = struct('T8',T8,'T9',T9,'T9large',T9b,'T10',T10);
end

function lP = logexact(y,n)
%  log P[Y1bar >= y1, Y2bar >= y2] for y1 < y2 on the log scale (no underflow): trapezoidal rule on
%  a fine grid of the common component, with log gamma tails from the scaled incomplete gamma
lups = @(x,a) log(gammainc(x*a,a,'scaledupper'))-gammaln(a+1)-x*a+a*log(x*a);
lup = @(x,a) (x >= 1).*lups(max(x,1),a)+(x < 1).*log(gammainc(min(x,1)*a,a,'upper'));
u = linspace(0,y(1),200001); u = u(2:end-1);
L = log(n)+(n-1)*log(n*u)-n*u-gammaln(n)+lup(y(1)-u,n)+lup(y(2)-u,n);
u2 = linspace(y(1),y(2),200001); u2 = u2(2:end-1);
L2 = log(n)+(n-1)*log(n*u2)-n*u2-gammaln(n)+lup(y(2)-u2,n);
m = max([L L2]);
lP = m+log(trapz(u,exp(L-m))+trapz(u2,exp(L2-m)));
end

function s = rowE(v)
s = sprintf(' & %s',strjoin(arrayfun(@fmtE,v,'UniformOutput',false),' & '));
end

function s = fmtE(v)
if isnan(v), s = '---'; return; end
if isinf(v), if v > 0, s = '$\infty$'; else, s = '$-\infty$'; end, return; end
if v == 0, s = '$0$'; return; end
e = floor(log10(abs(v))); m = v/10^e;
if abs(round(m*10)/10) >= 10, m = m/10; e = e+1; end
s = sprintf('$%.1f_{%d}$',m,e);
end

function s = fmtF(v)
e = floor(log10(abs(v))); m = v/10^e;
if round(m*1e6)/1e6 >= 10, m = m/10; e = e+1; end
s = sprintf('$%.6f_{%d}$',m,e);
end

function s = fmtF4(v)
e = floor(log10(abs(v))); m = v/10^e;
if round(m*1e4)/1e4 >= 10, m = m/10; e = e+1; end
s = sprintf('$%.4f_{%d}$',m,e);
end
