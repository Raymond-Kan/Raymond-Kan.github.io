function R = lap_table(order)
%LAP_TABLE Table 3 of the paper (Section 5.2): the example in which the approximations of Wang
%   (1990) and Kolassa and Li (2010) are undefined.  X = Z+A, Y = Z+B with Z standard Laplace and
%   A, B standard normal, all independent, and (Xbar,Ybar) the mean of n = 1 and n = 10 pairs;
%   P[Xbar >= x, Ybar >= -x] for x = 0.4, 0.8, ..., 2.0, exact and by the expansions of orders
%   1..order (default 5, spa_orthant2).  The per-observation cgf is
%      K(t,u) = -log(1-(t+u)^2) + (t^2+u^2)/2,  |t+u| < 1,
%   and the approximations of Wang and of Kolassa and Li need K at (tau1,0) and at (0,tau2), which
%   are outside the domain when |tau1| >= 1 or |tau2| >= 1.  The columns W and KL give the
%   relative errors of wang_bivar (in the order of the coordinates that Wang's rule selects, the
%   smaller signed root info.wu0) and of kl_bivar (order (X,Y), as in their paper) where they are
%   defined, --- otherwise.  Wang's term (18) contains phi(vbar0) with
%   vbar0^2 = -2{K(0,tau2) - tau2 y}, which is negative at every point here (info.vbar2);
%   wang_bivar evaluates it through the exponential exp{K(0,tau2) - tau2 y}/sqrt(2 pi) that his
%   (23) produces, and the paper says so.  The comment at the end of each row gives the order
%   selected, wang_bivar in the other order, vbar0^2, and kl_bivar in the reversed order.  Exact
%   values: the mean of the Laplace parts is (G1-G2)/n with G1, G2 independent Gamma(n,1), and
%   given it the probability is a product of normal tails; one-dimensional integration (relative
%   tolerance 1e-12).  Prints the LaTeX rows and returns
%   R = [n x P W KL F(1..order) vbar0^2], W and KL the approximations (not their errors).
%   Same output as Julia/tables/table3_lap.jl.  Requires the Statistics and Machine Learning
%   Toolbox.  A few seconds.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
if nargin < 1, order = 5; end
opts = {'RelTol',1e-12,'AbsTol',0};
onames = {'(X,Y)','(Y,X)'};
R = [];
for n = [1 10]
   Kf = @(nu,s) lapK(nu,s,n);
   Kneg = @(nu,t) (-1)^sum(nu)*Kf(nu,-t);           % cgf of (-Xbar,-Ybar)
   if n == 1
      fS = @(s) 0.5*exp(-abs(s));
   else
      fS = @(s) arrayfun(@(v) integral(@(a) gampdf(a,n,1).*gampdf(a-v,n,1),max(0,v),Inf,opts{:}),s);
   end
   for x = [0.4 0.8 1.2 1.6 2.0]
      y = -x;
      F = spa_orthant2(Kf,[x y],order);
      [W1,~,i1] = wang_bivar(Kneg,[-x -y],[1 2]);
      [W2,~,i2] = wang_bivar(Kneg,[-x -y],[2 1]);
      KL = [kl_bivar(Kf,[x y],[1 2]) kl_bivar(Kf,[x y],[2 1])];
      P = integral(@(s) fS(s).*normcdf(sqrt(n)*(x-s/n),'upper').*normcdf(sqrt(n)*(y-s/n),'upper'),-Inf,Inf,opts{:});
      % Wang's rule: the order with the smaller signed root w_u0; (X,Y) when neither is defined
      Wv = [W1 W2]; info = {i1,i2};
      iw = 1; if isfinite(i1.wu0) && isfinite(i2.wu0) && i2.wu0 < i1.wu0, iw = 2; end
      io = 3-iw;
      R(end+1,:) = [n x P Wv(iw) KL(1) F' info{iw}.vbar2]; %#ok<AGROW>
      fprintf('%d & $(%.1f,%.1f)$ & %s & %s & %s%s\\\\   %% Wang order %s, other order %s, vbar0^2 %.3g; KL (Y,X) %s\n', ...
         n,x,y,fmtF(P),fmtE(Wv(iw)/P-1),fmtE(KL(1)/P-1),rowE(F'/P-1), ...
         onames{iw},fmtE(Wv(io)/P-1),info{iw}.vbar2,fmtE(KL(2)/P-1));
   end
end
end

function v = lapK(nu,s,n)
%  derivatives of K_n(s) = n K(s/n), K(t,u) = h(t+u) + (t^2+u^2)/2, h(v) = -log(1-v^2)
k = sum(nu); w = (s(1)+s(2))/n;
if abs(w) >= 1, v = NaN; return; end
if k == 0
   v = n*(-log(1-w^2))+(s(1)^2+s(2)^2)/(2*n); return
end
hk = factorial(k-1)*((1-w)^(-k)+(-1)^k*(1+w)^(-k));
v = n^(1-k)*hk;
if k == 1, v = v+s(find(nu))/n; end
if k == 2 && any(nu == 2), v = v+1/n; end
end

function s = rowE(v)
s = sprintf(' & %s',strjoin(arrayfun(@fmtE,v,'UniformOutput',false),' & '));
end

function s = fmtE(v)
if ~isfinite(v), s = '---'; return; end
if v == 0, s = '$0$'; return; end
e = floor(log10(abs(v))); m = v/10^e;
if abs(round(m*10)/10) >= 10, m = m/10; e = e+1; end
s = sprintf('$%.1f_{%d}$',m,e);
end

function s = fmtF(v)
e = floor(log10(abs(v))); m = v/10^e;
if round(m*1e6)/1e6 >= 10, m = m/10; e = e+1; end
s = sprintf('$%.6f_{%d}$',m,e);
end
