function S = nsweep_table(order)
%NSWEEP_TABLE Tables S4 and S5 of the Supplementary Material (Section 5.1): sweeps over n for the two bivariate
%   examples (Wang 1990 and Kolassa and Li 2010), with the points fixed and n doubling, so that the
%   per-observation saddlepoint is fixed and the O(n^-M) rates of Theorem 1 can be read off.
%   Wang's example: X = U0+U1-2, Y = U0+U2-2, means of n unit exponentials; F(x,y) =
%      P[Xbar <= x, Ybar <= y] at (x,y) = (-0.5,-0.5) (saddlepoint of (-Xbar,-Ybar) in the open
%      orthant), (0,0) (the mean: both components of the saddlepoint vanish) and (-1.0,2.0) (one
%      negative component, inclusion-exclusion), n = 10, 20, 40, 80, 160: exact (one-dimensional
%      integral), Wang's approximation by wang_bivar in the order of the coordinates his rule
%      selects (--- where it is singular), and the expansions of orders 1..order (default 5,
%      spa_orthant2); errors relative to F, as in Table 1.
%   Kolassa and Li's example: Y1 = X1+X2, Y2 = X2+X3, means of n unit exponentials;
%      P[Y1bar >= y1, Y2bar >= y2] at y = (3.0,3.0), (3.5,4.0) (saddlepoint in the open orthant)
%      and (2.5,3.0) (s-hat_1 = 0), n = 5, 10, 20, 40, 80, 160: exact, kl_bivar in the order of
%      their paper (--- where singular), and the expansions of orders 1..order; errors relative
%      to P.  The comments give kl_bivar with the finite-difference steps hrel = 1e-2 and 1e-4
%      and in the other order of the coordinates.
%   Exact values: int g(u) G(x+2-u) G(y+2-u) du over (0, min(x,y)+2) and
%   int g(u) Gbar(y1-u) Gbar(y2-u) du over (0, Inf), g, G and Gbar the density, distribution and
%   survival functions of the gamma distribution with shape n and scale 1/n (relative tolerance
%   1e-13).  Prints the LaTeX rows of both tables and, as comments, the mean ratio of successive
%   errors of each order (0.5^M expected).  Returns S.wang and S.kl, with rows
%   [x y n exact W-or-KL F(1..order)].  Same output as Julia/tables/tableS4S5_nsweep.jl.
%   Requires the Statistics and Machine Learning Toolbox.  About a minute.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
if nargin < 1, order = 5; end
A = [1 0; 1 1; 0 1];
opts = {'RelTol',1e-13,'AbsTol',0};
S = struct('wang',[],'kl',[]);
onames = {'(X,Y)','(Y,X)'};
fprintf('Wang''s example\n');
for p = {[-0.5 -0.5],[0 0],[-1 2]}
   x = p{1}(1); y = p{1}(2);
   fprintf('\\multicolumn{8}{l}{$(x,y)=(%.1f,%.1f)$}\\\\\n',x,y);
   errs = [];
   for n = [10 20 40 80 160]
      Kw = @(nu,t) lin_exp_Kfun(nu,t,A,n,[-2 -2]);
      Kneg = @(nu,t) (-1)^sum(nu)*Kw(nu,-t);
      g = @(u) gampdf(u,n,1/n); G = @(u) gamcdf(max(u,0),n,1/n);
      ex = integral(@(u) g(u).*G(x+2-u).*G(y+2-u),0,min(x,y)+2,opts{:});
      [F,tau] = spa_orthant2(Kneg,[-x -y],order);
      [W1,~,i1] = wang_bivar(Kw,[x y],[1 2]);       % the lower orthant P[X <= x, Y <= y]
      [W2,~,i2] = wang_bivar(Kw,[x y],[2 1]);
      iw = 1; if isfinite(i1.wu0) && isfinite(i2.wu0) && i2.wu0 < i1.wu0, iw = 2; end
      Wv = [W1 W2]; W = Wv(iw);
      werr = NaN; if isfinite(W) && abs(W/ex-1) < 10, werr = W/ex-1; end
      e = F'/ex-1; errs(end+1,:) = e; %#ok<AGROW>
      S.wang(end+1,:) = [x y n ex W F'];
      fprintf('%d & %s & %s%s\\\\   %% shat = (%.3f,%.3f), W order %s, W raw %.6g\n',n,fmtF(ex),fmtE(werr), ...
         rowE(e),tau(1)+0,tau(2)+0,onames{iw},W);
   end
   fprintf('%% mean ratio of successive errors, orders 1..5: %s\n',rates(errs));
end
fprintf('Kolassa and Li''s example\n');
for p = {[3 3],[3.5 4],[2.5 3]}
   y = p{1};
   fprintf('\\multicolumn{8}{l}{$y=(%.1f,%.1f)$}\\\\\n',y);
   errs = [];
   for n = [5 10 20 40 80 160]
      K = @(nu,t) lin_exp_Kfun(nu,t,A,n);
      g = @(u) gampdf(u,n,1/n); Gb = @(u) gamcdf(max(u,0),n,1/n,'upper');
      e0 = integral(@(u) g(u).*Gb(y(1)-u).*Gb(y(2)-u),0,Inf,opts{:},'Waypoints',sort(y));
      [F,tau] = spa_orthant2(K,y,order);
      kl = kl_bivar(K,y);
      klerr = NaN; if isfinite(kl) && abs(kl/e0-1) < 10, klerr = kl/e0-1; end
      e = F'/e0-1; errs(end+1,:) = e; %#ok<AGROW>
      S.kl(end+1,:) = [y n e0 kl F'];
      kl2 = kl_bivar(K,y,[1 2],1e-2); kl4 = kl_bivar(K,y,[1 2],1e-4); kl21 = kl_bivar(K,y,[2 1]);
      fprintf(['%d & %s & %s%s\\\\   %% shat = (%.3f,%.3f), KL raw %.6g; KL err with hrel 1e-2 %s, ' ...
         '1e-4 %s; order (2,1) %s\n'],n,fmtF(e0),fmtE(klerr),rowE(e),tau(1)+0,tau(2)+0,kl, ...
         fmtE(kl2/e0-1),fmtE(kl4/e0-1),fmtE(kl21/e0-1));
   end
   fprintf('%% mean ratio of successive errors, orders 1..5: %s\n',rates(errs));
end
end

function s = rates(errs)
%  mean over n of the ratio of successive absolute errors, for each order
r = mean(abs(errs(2:end,:))./abs(errs(1:end-1,:)),1);
s = strjoin(arrayfun(@(v) sprintf('%5.2f',v),r,'UniformOutput',false),' ');
end

function s = rowE(v)
s = sprintf(' & %s',strjoin(arrayfun(@fmtE,v,'UniformOutput',false),' & '));
end

function s = fmtE(v)
if isnan(v), s = '---'; return; end
if isinf(v), if v > 0, s = '$\infty$'; else, s = '$-\infty$'; end, return; end
if v == 0, s = '$0$'; return; end
e = floor(log10(abs(v))); m = v/10^e;
if abs(round(m*10)/10) >= 10, m = m/10; e = e+1; end
s = sprintf('$%.1f_{%d}$',m,e);
end

function s = fmtF(v)
e = floor(log10(abs(v))); m = v/10^e;
if round(m*1e6)/1e6 >= 10, m = m/10; e = e+1; end
s = sprintf('$%.6f_{%d}$',m,e);
end
