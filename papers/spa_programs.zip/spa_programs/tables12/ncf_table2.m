%NCF_TABLE2 Reproduces Table S2 of the Supplementary Material (singly noncentral F): relative errors of the
%   approximations of orders 1..6 of the distribution function (relative to min(F,1-F)) and of
%   the density at the 10,100,000 points of the grid m,n = 1..100, lambda in {1,2,5,10,20,50,
%   100,500,1000,5000}, 101 quantiles (ncf_grid.mat: xcutb(lambda,m,n,quantile), the quantiles
%   of ncfinv rounded to four significant digits).  Exact values in ncf_exact_cdf.mat and
%   ncf_exact_pdf.mat (truecdfb, truepdfb), computed in Mathematica in high
%   precision.  Prints, for each lambda, the rows median, maximum, maximum over
%   min(m,n) >= 10; the paper shows lambda = 1, 10, 100, 1000.  Parallel over m (Parallel
%   Computing Toolbox); about half an hour on sixteen cores.  The data files are read from the
%   folder of this file; the error arrays are saved in ncf_table2_errors.mat (large) in
%   the current folder.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
addpath(fullfile(fileparts(mfilename('fullpath')),'..'));
lam = [1 2 5 10 20 50 100 500 1000 5000]; order = 6;
here = fileparts(mfilename('fullpath'));            % data files are read from this folder
G = load(fullfile(here,'ncf_grid.mat')); C = load(fullfile(here,'ncf_exact_cdf.mat'));
D = load(fullfile(here,'ncf_exact_pdf.mat'));
if isempty(gcp('nocreate'))
   cl = parcluster('Processes'); nw = feature('numcores');
   if cl.NumWorkers < nw, cl.NumWorkers = nw; end
   parpool(cl,nw);
end
ec = nan(10,100,100,101,order,'single'); ep = ec;
for il = 1:10
   xl = squeeze(G.xcutb(il,:,:,:)); Fl = squeeze(C.truecdfb(il,:,:,:)); fl = squeeze(D.truepdfb(il,:,:,:));
   lam_l = lam(il); Ec = nan(100,100,101,order,'single'); Ep = Ec;
   parfor m = 1:100
      ec_m = nan(100,101,order,'single'); ep_m = ec_m;
      for n = 1:100
         for ip = 1:101
            x = xl(m,n,ip); F = Fl(m,n,ip); f = fl(m,n,ip);
            [cdf,pdf,upp] = ncf_spa(x,m,n,lam_l,order);
            if F <= 0.5, ec_m(n,ip,:) = abs(cdf-F)/F; else, ec_m(n,ip,:) = abs(upp-(1-F))/(1-F); end
            ep_m(n,ip,:) = abs(pdf-f)/f;
         end
      end
      Ec(m,:,:,:) = ec_m; Ep(m,:,:,:) = ep_m;
   end
   ec(il,:,:,:,:) = Ec; ep(il,:,:,:,:) = Ep;
   fprintf('lambda = %g done\n',lam_l);
end
[mm,nn] = ndgrid(1:100,1:100); big = repmat(min(mm,nn) >= 10,[1 1 101]);
for il = 1:10
   fprintf('lambda = %g: distribution function (med, max, max min(m,n)>=10) and density\n',lam(il));
   for M = 1:order
      a = squeeze(ec(il,:,:,:,M)); b = squeeze(ep(il,:,:,:,M));
      fprintf('%d & %.1e & %.1e & %.1e & %.1e & %.1e & %.1e\\\\\n',M,median(a(:)),max(a(:)),max(a(big)),median(b(:)),max(b(:)),max(b(big)));
   end
end
save('ncf_table2_errors.mat','ec','ep','lam','-v7.3');
