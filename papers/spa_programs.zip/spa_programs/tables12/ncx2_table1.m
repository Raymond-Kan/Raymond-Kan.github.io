%NCX2_TABLE1 Reproduces Table S1 of the Supplementary Material (noncentral chi-squared): relative errors of the
%   approximations of orders 1..6 of the distribution function (relative to min(F,1-F)) and of
%   the density, at the 202,000 points of the grid nu = 1..200, lambda in {1,2,5,10,20,50,100,
%   500,1000,5000}, 101 quantiles (ncx2_grid.mat: xcutb(lambda,nu,quantile), the quantiles of
%   ncx2inv rounded to four significant digits).  Exact values in ncx2_exact_cdf.mat and
%   ncx2_exact_pdf.mat (truecdfb, truepdfb), computed in Mathematica in high
%   precision.  Prints, for each lambda, the rows median, maximum, maximum over nu >= 10;
%   the paper shows lambda = 1, 10, 100, 1000.  About two minutes.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
addpath(fullfile(fileparts(mfilename('fullpath')),'..'));
lam = [1 2 5 10 20 50 100 500 1000 5000]; order = 6;
here = fileparts(mfilename('fullpath'));            % data files are read from this folder
G = load(fullfile(here,'ncx2_grid.mat')); C = load(fullfile(here,'ncx2_exact_cdf.mat'));
D = load(fullfile(here,'ncx2_exact_pdf.mat'));
ec = nan(10,200,101,order); ep = ec;
for il = 1:10
   for nu = 1:200
      for ip = 1:101
         x = G.xcutb(il,nu,ip); F = C.truecdfb(il,nu,ip); f = D.truepdfb(il,nu,ip);
         [cdf,pdf,upp] = ncx2_spa(x,nu,lam(il),order);
         if F <= 0.5, ec(il,nu,ip,:) = abs(cdf-F)/F; else, ec(il,nu,ip,:) = abs(upp-(1-F))/(1-F); end
         ep(il,nu,ip,:) = abs(pdf-f)/f;
      end
   end
end
for il = 1:10
   fprintf('lambda = %g: distribution function (med, max, max nu>=10) and density\n',lam(il));
   for M = 1:order
      a = ec(il,:,:,M); a10 = ec(il,10:end,:,M); b = ep(il,:,:,M); b10 = ep(il,10:end,:,M);
      fprintf('%d & %.1e & %.1e & %.1e & %.1e & %.1e & %.1e\\\\\n',M,median(a(:)),max(a(:)),max(a10(:)),median(b(:)),max(b(:)),max(b10(:)));
   end
end
