function test_spa(full)
%TEST_SPA Regression tests of the general-purpose programs (spa_saddle, spa_bi, spa_orthant2,
%   spa_mv/spa_tri, spa_orthant, acf_spa_hp), with cases whose answers are known exactly:
%   finite density expansions of linear transformations of independent gamma variables, normal
%   orthant probabilities with correlations near +-1, rescaled and extreme-range problems, and
%   the transformation of the Kwhite callback in the inclusion-exclusion.  test_spa runs the
%   quick tests (about a minute); test_spa(true) adds the variable-precision tests (a few more
%   minutes).  Prints one line per test and raises an error if a test fails.
%   Requires the Statistics and Machine Learning Toolbox (and the Symbolic Math Toolbox for the
%   variable-precision tests and the refinement test).
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
if nargin < 1, full = false; end
nfail = 0;
   function check(name,ok)
      if ok, fprintf('  ok    %s\n',name); else, fprintf('  FAIL  %s\n',name); nfail = nfail+1; end
   end
fprintf('test_spa\n');
%  1. Newton's method is invariant under changes of units
for b = [1 1e8 1e12 1e100]
   s = spa_saddle(@(nu,t) gamnorm(nu,t,10,b),[15*b 0]);
   check(sprintf('saddlepoint, scale %g',b),abs(s(1)*b*3-1) < 1e-14 && s(2) == 0);
end
%  2. density prefactor in the log domain
for d = [2 3]
   for v = [1e-160 1e160]
      K = @(nu,t) normk(nu,t,v*eye(d));
      if d == 2, p = spa_bi(K,zeros(1,d),1); else, p = spa_mv(K,zeros(1,d),1,struct('refine',false)); end
      check(sprintf('density, d = %d, variance %g',d,v),abs(p/(2*pi*v)^(-d/2)-1) < 1e-13);
   end
end
%  3. whitened coefficients: X = (U + e V, U - e V), U, V ~ Gamma(10); p3/p1 = 1 - 1/60 + 1/7200
e = 1e-3; A = [1 e; 1 -e]; K = @(nu,t) lgmix(nu,t,A,10);
x = [K([1 0],[0 0]) K([0 1],[0 0])];
[p,~,~,~,~,~,info] = spa_bi(K,x,3);
check('substitution flagged (spa_bi)',contains(info.status,'coefficients inaccurate') && info.coef_err_pdf(3) > 1e-3);
p = spa_bi(K,x,3,[],[],[],struct('Kwhite',@(nu,u,T) lgmix(nu,u,T.'*A,10)));
check('direct whitened coefficients (spa_bi)',abs(p(3)/p(1)-(1-1/60+1/7200)) < 1e-9);
%  4. inclusion-exclusion: Kwhite transformed for the reflected and marginal terms; logscale
K = @(nu,t) lgmix(nu,t,eye(3),10); x = [5 15 15];
F1 = spa_orthant(K,x,2,struct('refine',false));
F2 = spa_orthant(K,x,2,struct('refine',false,'Kwhite',@(nu,u,T) lgmix(nu,u,T.',10)));
check('spa_orthant with Kwhite',all(abs(F2-F1) < 1e-14*abs(F1)));
K = @(nu,t) normk(nu,t,eye(2));
F0 = spa_orthant2(K,[-1 1],1); Fs = spa_orthant2(K,[-1 1],1,struct('logscale',1));
check('spa_orthant2 logscale',abs(Fs/(F0/exp(1))-1) < 1e-14);
%  5. normal orthant probabilities with correlations near +-1 (order 1 is exact)
for rho = [0.999 0.999999 -0.999 -0.999999]
   S = [1 rho; rho 1];
   [~,F] = spa_bi(@(nu,t) normk(nu,t,S),[0 0],1);
   check(sprintf('bivariate normal, rho = %g',rho),abs(F/(1/4+asin(rho)/(2*pi))-1) < 1e-10);
   [~,F,~,~,~,info] = spa_tri(@(nu,t) normk(nu,t,blkdiag(S,1)),[0 0 0],1);
   check(sprintf('trivariate normal, rho = %g',rho),abs(F/((1/4+asin(rho)/(2*pi))/2)-1) < 1e-10 && strcmp(info.status,'ok'));
end
rho = -0.999999; S0 = blkdiag([1 rho; rho 1],1);
for pm = {[1 2 3],[3 1 2],[2 3 1]}
   P = eye(3); P = P(pm{1},:); S = P*S0*P.';
   for xx = {[0.3 -0.4 0.2],[-0.3 -0.2 0.5]}
      x = xx{1}*P.';
      F = spa_orthant(@(nu,t) normk(nu,t,S),x,1);
      ex = mvncdf(-x,[0 0 0],S,statset('TolFun',1e-14));
      check(sprintf('trivariate normal orthant, permutation %s, x = %s',mat2str(pm{1}),mat2str(xx{1})),abs(F/ex-1) < 1e-10);
   end
end
%  6. density in three dimensions: substitution detected and refined in variable precision
if license('test','Symbolic_Toolbox')
   A = blkdiag([1 e; 1 -e],1); K = @(nu,t) lgmix(nu,t,A,10);
   x = [K([1 0 0],[0 0 0]) K([0 1 0],[0 0 0]) K([0 0 1],[0 0 0])];
   [p,~,~,~,~,info] = spa_mv(K,x,3,struct('method','none'));
   check('spa_mv refinement of substituted coefficients',info.refined_pdf && max(abs(p.'/p(1)-[1 0.975 0.9753125])) < 1e-12);
end
if full
   %  7. variable precision: small saddlepoints are not rounded to zero
   old = digits(50); c = onCleanup(@() digits(old));
   [s,info] = spa_saddle(@(nu,t) normk(nu,t,vpa(eye(2))),[vpa('1e-20') vpa(0)]);
   check('variable-precision saddlepoint 1e-20',~info.snapped(1) && abs(double(s(1))/1e-20-1) < 1e-30);
   %  8. variable precision: leading integral outside the double range, base orthant probabilities
   digits(25);
   [~,F,~,~,~,info] = spa_tri(@(nu,t) gamnorm(nu,t,sym(5),sym(2)),vpa([200 0 0]),2, ...
      struct('tau0',[vpa('0.475') vpa(0) vpa(0)],'method','vpa-recursion','refine',false));
   check('variable-precision mixed tail',strcmp(info.status,'ok') && abs(double(F(2))/(ncx2cdf(200,10,0,'upper')/4)-1) < 1e-3);
   digits(20);
   rho = vpa('-0.999999'); S = [vpa(1) rho vpa(0); rho vpa(1) vpa(0); vpa(0) vpa(0) vpa(1)];
   [~,F,~,~,~,info] = spa_tri(@(nu,t) normk(nu,t,S),vpa([0 0 0]),1,struct('method','vpa-recursion','refine',false));
   check('variable-precision normal orthant, rho = -0.999999',strcmp(info.status,'ok') && ...
      abs(double(F/((1/vpa(4)+asin(rho)/(2*vpa(pi)))/2)-1)) < 1e-12);
   %  9. full-precision saddlepoint of the high-precision autocorrelation program
   [~,~,info] = acf_spa_hp(10,0.5,[0.5 0.5],2,30);
   check('acf_spa_hp saddlepoint string',numel(info.s_str) == 2 && all(cellfun(@numel,info.s_str) > 20));
end
if nfail > 0, error('test_spa: %d test(s) failed',nfail); end
fprintf('all tests passed\n');
end

function v = normk(nu,t,S)
%  cgf t'St/2 of N(0,S) and its derivatives
k = sum(nu);
if k == 0, v = t*S*t.'/2;
elseif k == 1, v = (S*t.').'*nu.';
elseif k == 2, ii = find(nu); if numel(ii) == 1, v = S(ii,ii); else, v = S(ii(1),ii(2)); end
else, v = 0*t(1);
end
end

function v = lgmix(nu,t,A,a)
%  cgf -a sum_j log(1 - (t A)_j) of X = A U, U_j independent Gamma(a,1) (t is 1 x k, A is k x m;
%  with t A in place of t'A' this is also the cgf K(M u) of M'X for the callback Kwhite)
z = 1-t*A;
if isa(z,'sym'), bad = any(isAlways(z <= 0)); else, bad = any(z <= 0); end
if bad, v = NaN; return, end
k = sum(nu);
if k == 0, v = -a*sum(log(z)); else, v = a*factorial(k-1)*sum(prod(A.^(nu.'),1)./z.^k); end
end

function v = gamnorm(nu,t,a,b)
%  cgf of (b G, Z_2, ..., Z_d), G ~ Gamma(a,1), Z_j standard normal, all independent
if isa(t,'sym'), bad = isAlways(1-b*t(1) <= 0); else, bad = 1-b*t(1) <= 0; end
if bad, v = NaN; return, end
k = sum(nu); nz = find(nu);
if k == 0, v = -a*log(1-b*t(1))+sum(t(2:end).^2)/2;
elseif numel(nz) > 1, v = 0*t(1);
elseif nz == 1
   if isa(t,'sym'), fk = factorial(sym(k-1)); else, fk = factorial(k-1); end
   v = a*fk*b^k/(1-b*t(1))^k;
elseif k == 1, v = t(nz);
elseif k == 2, v = 1+0*t(1);
else, v = 0*t(1);
end
end
