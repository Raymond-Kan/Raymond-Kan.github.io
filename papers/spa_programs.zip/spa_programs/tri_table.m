function S = tri_table(order,ns)
%TRI_TABLE Table 4 of the paper (Section 5.3): the diagonal Y = (W11,W22,W33) of a Wishart
%   W_3(n,V) matrix with V = 0.75 I + 0.25 11', the unconditional trivariate example of Kolassa and
%   Li (2010, Table 6).  For n = 5 the seven points of their table, and for n = 20 (ns, default
%   [5 20]) the points with the same standardized offsets (y - n)/sqrt(2n): exact orthant
%   probability P[Y >= y] and density, the relative errors of Kolassa and Li's printed
%   approximation (n = 5), and of the expansions of orders 1..order (default 5) of both (spa_tri,
%   whitened coordinates, double precision).  Exact values: writing the columns of the normal
%   matrix as 0.5 f_i 1 + sqrt(0.75) e_i, the Y_j/0.75 are, given F = sum f_i^2 ~ chi2_n,
%   independent noncentral chi-squared with n degrees of freedom and noncentrality F/3; one-
%   dimensional integration over F (relative tolerance 1e-13).  Also prints the ratios of Kolassa
%   and Li's simulation errors to their standard errors (with the two apparent misprints of their
%   table corrected, as inferred from the other entries), and the cancellation indicators.
%   The quadrature nodes are doubled (64 to 128 per coordinate) while the change with half the
%   nodes exceeds 1e-10 relative, which is far below the smallest printed relative errors.
%   S: struct array with the results.  Requires the Statistics and Machine Learning Toolbox.
%   About fifteen minutes.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
if nargin < 1 || isempty(order), order = 5; end
if nargin < 2, ns = [5 20]; end
rho = 0.25; V = (1-rho)*eye(3)+rho*ones(3);
Y5 = [5.5 5.5 5.5; 5.5 5.5 6.5; 5.5 6.5 6.5; 6.5 6.5 6.5; 6.5 6.5 7.5; 6.5 7.5 7.5; 7.5 7.5 7.5];
% Kolassa and Li (2010, Table 6): their approximation, normal approximation, simulation and its
% standard error, as printed (the third standard error, printed 1.10e-4, is 1.10e-3, and in the
% last row the normal approximation and the simulation, printed 1.36e-3 and 1.04e-3, are 1.36e-2
% and 1.04e-2)
kl = [4.93e-2 9.64e-2 5.58e-2 1.42e-3; 3.65e-2 7.17e-2 4.16e-2 1.24e-3; 2.70e-2 5.34e-2 3.26e-2 1.10e-4;
      1.98e-2 3.99e-2 2.45e-2 9.58e-4; 1.45e-2 2.78e-2 1.83e-2 8.31e-4; 1.05e-2 1.94e-2 1.34e-2 7.11e-4;
      0.76e-2 1.36e-3 1.04e-3 1.89e-4];
klc = kl; klc(3,4) = 1.10e-3; klc(7,2) = 1.36e-2; klc(7,3) = 1.04e-2;
S = struct([]);
for n = ns
   Y = n+(Y5-5)/sqrt(10)*sqrt(2*n);
   Kf = @(nu,t) wishdiag_Kfun(nu,t,V,n);
   rowsP = cell(7,1); rowsf = cell(7,1);
   for i = 1:7
      y = Y(i,:);
      [P,f] = wish_exact(y,n,rho);
      [pdf,Fup,tau,C,err,info] = spa_tri(Kf,y,order,struct('qtol',1e-10));   % nodes doubled
      S(end+1).n = n; S(end).y = y; S(end).P = P; S(end).f = f; S(end).Fup = Fup; S(end).pdf = pdf; %#ok<AGROW>
      S(end).tau = tau; S(end).C = C; S(end).err = err; S(end).info = info;
      if n == 5, ystr = sprintf('$(%.1f,%.1f,%.1f)$',y); klstr = fmtE(kl(i,1)/P-1);
      else, ystr = sprintf('$(%g,%g,%g)$',round(y*100)/100); klstr = ''; end
      rowsP{i} = sprintf('%s & %s & %s%s\\\\',ystr,fmtF(P),klstr,rowE(Fup'/P-1));
      rowsf{i} = sprintf('%s & %s & %s\\\\',ystr,fmtF(f),rowE(pdf'/f-1));
   end
   fprintf('\\multicolumn{8}{l}{$n=%d$, orthant probability}\\\\\n',n); fprintf('%s\n',rowsP{:});
   fprintf('\\multicolumn{8}{l}{$n=%d$, density}\\\\\n',n); fprintf('%s\n',rowsf{:});
   k = arrayfun(@(s) s.C(end),S([S.n] == n)); q = arrayfun(@(s) max(s.err./abs(s.Fup)),S([S.n] == n));
   fprintf('%% n = %d: cancellation indicator of order %d at most %.1e; quadrature check at most %.1e relative\n',n,order,max(k),max(q));
   if n == 5
      Pn = [S([S.n] == 5).P]';
      fprintf('%% Kolassa and Li''s simulation minus exact, in standard errors (corrected table): %s\n', ...
         sprintf('%6.2f',(klc(:,3)-Pn)./klc(:,4)));
      fprintf('%% relative errors of their approximation %s, of the normal approximation %s\n', ...
         sprintf('%7.3f',kl(:,1)./Pn-1),sprintf('%7.3f',klc(:,2)./Pn-1));
   end
end
end

function [P,f] = wish_exact(y,n,rho)
%  exact P[Y >= y] and density of the diagonal of W_3(n,(1-rho)I + rho 11')
c = 1-rho; k = rho/c;
opts = {'RelTol',1e-13,'AbsTol',0};
Pint = @(F) chi2pdf(F,n).*ncx2cdf(y(1)/c,n,k*F,'upper').*ncx2cdf(y(2)/c,n,k*F,'upper').*ncx2cdf(y(3)/c,n,k*F,'upper');
fint = @(F) chi2pdf(F,n).*ncx2pdf(y(1)/c,n,k*F).*ncx2pdf(y(2)/c,n,k*F).*ncx2pdf(y(3)/c,n,k*F)/c^3;
P = integral(Pint,0,Inf,opts{:});
f = integral(fint,0,Inf,opts{:});
end

function s = rowE(v)
s = sprintf(' & %s',strjoin(arrayfun(@fmtE,v,'UniformOutput',false),' & '));
end

function s = fmtE(v)
if ~isfinite(v), s = '---'; return; end
if v == 0, s = '$0$'; return; end
e = floor(log10(abs(v))); m = v/10^e;
if abs(round(m*10)/10) >= 10, m = m/10; e = e+1; end
s = sprintf('$%.1f_{%d}$',m,e);
end

function s = fmtF(v)
e = floor(log10(abs(v))); m = v/10^e;
if round(m*1e6)/1e6 >= 10, m = m/10; e = e+1; end
s = sprintf('$%.6f_{%d}$',m,e);
end
