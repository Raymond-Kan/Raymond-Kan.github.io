function [nok,T] = wang_check
%WANG_CHECK Checks wang_bivar against the approximations printed by Wang (1990, Table 1): X = U0+U1-2,
%   Y = U0+U2-2, U0, U1, U2 the means of n = 10 independent unit exponentials, F(x,y) =
%   P[Xbar <= x, Ybar <= y] at the 45 points of his table.  wang_bivar is evaluated in both orders of
%   the coordinates, and the order of Wang's rule (the smaller signed root w_u0) is compared with
%   his printed value, rounded to the number of decimals he prints.  Prints one line per point and
%   returns the number of points that agree and T = [x y printed W(rule) W(1,2) W(2,1) wu0(1,2)
%   wu0(2,1)].  The point (-1.2,-1.2), printed as 0.00000, is compared to five decimals.  At the
%   points where a component of the saddlepoint is zero, (0,0), (1.0,2.0), (0.5,1.0) and
%   (-1.0,-0.5), Wang's formula is a limit and wang_bivar returns NaN.  The values agree with
%   wang_bivar of the Julia programs to 1e-13.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
n = 10;
A = [1 0; 1 1; 0 1];
Kw = @(nu,t) lin_exp_Kfun(nu,t,A,n,[-2 -2]);
xs = [-1.2 -1.0 -0.8 -0.5 0.0 0.5 1.0 1.5 2.0];
ys = [2.0 1.5 1.0 0.5 0.0 -0.5 -0.8 -1.0 -1.2];
wsa  = {{'0.00027' '0.0036' '0.022' '0.129' '0.539' '0.871' '0.979' '0.9976' '0.99955'}, ...
        {'0.00027' '0.0036' '0.022' '0.128' '0.537' '0.869' '0.977' '0.9949'}, ...
        {'0.00026' '0.0036' '0.022' '0.127' '0.532' '0.857' '0.958'}, ...
        {'0.00026' '0.0035' '0.022' '0.124' '0.504' '0.778'}, ...
        {'0.00025' '0.0033' '0.019' '0.104' '0.360'}, ...
        {'0.00017' '0.0020' '0.010' '0.042'}, {'0.00008' '0.0008' '0.0032'}, {'0.00003' '0.0002'}, {'0.00000'}};
T = []; nok = 0; npt = 0; nund = 0;
fprintf('    x     y   printed   W (rule)    order   W(X,Y)      W(Y,X)\n');
for iy = 1:numel(ys)
   for ix = 1:numel(wsa{iy})
      x = xs(ix); y = ys(iy); s = wsa{iy}{ix};
      dec = numel(s)-find(s == '.');                  % decimals printed
      [W1,~,i1] = wang_bivar(Kw,[x y],[1 2]);
      [W2,~,i2] = wang_bivar(Kw,[x y],[2 1]);
      if isfinite(W1) && isfinite(W2), use2 = i2.wu0 < i1.wu0; else, use2 = ~isfinite(W1); end
      if use2, W = W2; o = '(Y,X)'; else, W = W1; o = '(X,Y)'; end
      if ~isfinite(W), o = '  -  '; end
      ok = abs(round(W*10^dec)/10^dec-str2double(s)) < 0.5*10^-dec;
      if ~isfinite(W), nund = nund+1; end
      nok = nok+ok; npt = npt+1;
      T(end+1,:) = [x y str2double(s) W W1 W2 i1.wu0 i2.wu0]; %#ok<AGROW>
      if ~isfinite(W), note = '(a saddlepoint component is zero: undefined)'; elseif ok, note = ''; else, note = sprintf('<-- differs by %.1e', W-str2double(s)); end
      fprintf('%5.1f %5.1f  %-8s  %-10.6g  %s  %-10.6g  %-10.6g %s\n',x,y,s,W,o,W1,W2,note);
   end
end
fprintf(['%d of %d points agree with Wang''s printed values to the digits printed; at %d the formula is ' ...
   'undefined as written (a component of the saddlepoint is zero, where Wang takes limits)\n'],nok,npt,nund);
end

