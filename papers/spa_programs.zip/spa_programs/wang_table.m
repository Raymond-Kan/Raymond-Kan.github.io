function W = wang_table(order,allrows)
%WANG_TABLE Table 1 of the paper (Section 5.1): the example of Wang (1990, Table 1).
%   X = U0+U1-2, Y = U0+U2-2, with U0, U1, U2 the means of n = 10 independent unit exponentials,
%   so that (X,Y) is the mean of n pairs with a common component;
%   F(x,y) = P[Xbar <= x, Ybar <= y] at the 45 points of Wang's table, exact, from Wang's printed
%   simulation (MC, 10^6 samples) and approximation (W), and by the expansions of orders
%   1..order (default 5) of the orthant probability of (-Xbar,-Ybar) (spa_orthant2).  Exact
%   values: F(x,y) = int_0^{min(x,y)+2} g(u) G(x+2-u) G(y+2-u) du, g and G the density and
%   distribution function of the gamma distribution with shape n and scale 1/n (relative
%   tolerance 1e-13).  Prints the LaTeX rows of the table (the selection of the paper; all 45
%   points with wang_table(5,true)), the largest relative errors over the 44 points with a positive
%   printed value and over the 40 at which both printed values have two significant digits, and
%   the rounding share of Wang's printed values.  Relative errors are (F^ - F)/F, relative to F
%   itself, to match Wang's values.  W = [x y exact MC W F(1..order)].
%   Requires the Statistics and Machine Learning Toolbox.  About ten seconds.
%   Raymond Kan (raymond.kan@rotman.utoronto.ca), 2026. Programs accompanying Broda and Kan,
%   "Uniform saddlepoint expansions for multivariate tail probabilities"; free to use and modify with a citation of the paper.
if nargin < 1 || isempty(order), order = 5; end
if nargin < 2, allrows = false; end
n = 10;
A = [1 0; 1 1; 0 1];                                 % rows: U1 -> X, U0 -> X and Y, U2 -> Y
Kw = @(nu,t) lin_exp_Kfun(nu,t,A,n,[-2 -2]);
Kneg = @(nu,t) (-1)^sum(nu)*Kw(nu,-t);               % cgf of (-Xbar,-Ybar)
xs = [-1.2 -1.0 -0.8 -0.5 0.0 0.5 1.0 1.5 2.0];
ys = [2.0 1.5 1.0 0.5 0.0 -0.5 -0.8 -1.0 -1.2];
% Wang (1990), Table 1: simulation and approximation, by rows of y and columns of x, as printed
% (strings, so that the number of printed digits, trailing zeros included, is known)
wsim = {{'0.00026' '0.0035' '0.021' '0.125' '0.530' '0.866' '0.978' '0.9975' '0.99962'}, ...
        {'0.00026' '0.0035' '0.021' '0.125' '0.530' '0.865' '0.976' '0.9955'}, ...
        {'0.00026' '0.0035' '0.021' '0.125' '0.527' '0.857' '0.961'}, ...
        {'0.00026' '0.0035' '0.021' '0.123' '0.503' '0.783'}, ...
        {'0.00025' '0.0033' '0.019' '0.104' '0.364'}, ...
        {'0.00018' '0.0021' '0.010' '0.042'}, {'0.00008' '0.0008' '0.0033'}, {'0.00003' '0.0002'}, {'0.00000'}};
wsa  = {{'0.00027' '0.0036' '0.022' '0.129' '0.539' '0.871' '0.979' '0.9976' '0.99955'}, ...
        {'0.00027' '0.0036' '0.022' '0.128' '0.537' '0.869' '0.977' '0.9949'}, ...
        {'0.00026' '0.0036' '0.022' '0.127' '0.532' '0.857' '0.958'}, ...
        {'0.00026' '0.0035' '0.022' '0.124' '0.504' '0.778'}, ...
        {'0.00025' '0.0033' '0.019' '0.104' '0.360'}, ...
        {'0.00017' '0.0020' '0.010' '0.042'}, {'0.00008' '0.0008' '0.0032'}, {'0.00003' '0.0002'}, {'0.00000'}};
g = @(u) gampdf(u,n,1/n); G = @(u) gamcdf(max(u,0),n,1/n);
opts = {'RelTol',1e-13,'AbsTol',0};
W = []; Ssim = {}; Ssa = {};
for iy = 1:numel(ys)
   y = ys(iy);
   for ix = 1:numel(wsim{iy})
      x = xs(ix);
      ex = integral(@(u) g(u).*G(x+2-u).*G(y+2-u),0,min(x,y)+2,opts{:});
      F = spa_orthant2(Kneg,[-x -y],order);
      W(end+1,:) = [x y ex str2double(wsim{iy}{ix}) str2double(wsa{iy}{ix}) F']; %#ok<AGROW>
      Ssim{end+1} = wsim{iy}{ix}; Ssa{end+1} = wsa{iy}{ix}; %#ok<AGROW>
   end
end
sel = [1 2 4 5 8 9 30 34 35 36 39 42 43 44];          % the rows of Table 1
if allrows, sel = 1:size(W,1); end
for i = sel
   r = W(i,:);
   fprintf('$(%.1f,%.1f)$ & %s & %s & %s%s\\\\\n',r(1),r(2),fmtF(r(3)),fmtE(r(4)/r(3)-1),fmtE(r(5)/r(3)-1),rowE(r(6:end)/r(3)-1));
end
pos = W(:,5) > 0;                                     % Wang prints 0.00000 at the last point
mx = max(abs(W(pos,4:end)./W(pos,3)-1));
two = arrayfun(@(i) sigdig(Ssim{i}) >= 2 && sigdig(Ssa{i}) >= 2,1:size(W,1))' & pos;
mx2 = max(abs(W(two,4:5)./W(two,3)-1));
rnd = zeros(size(W,1),1);                             % rounding share of Wang's approximation
for i = find(pos)'
   str = Ssa{i}; dp = numel(str)-find(str == '.',1);
   rnd(i) = 0.5*10^(-dp)/W(i,3);
end
fprintf('%% %d points with a positive printed value: largest |rel. error| MC %.3f, W %.3f, orders 1..%d %s\n', ...
   sum(pos),mx(1),mx(2),order,sprintf('%9.1e',mx(3:end)));
fprintf('%% %d points with two significant digits in both printed values: MC %.3f, W %.3f (W less rounding %.3f)\n', ...
   sum(two),mx2(1),mx2(2),max(abs(W(two,5)./W(two,3)-1)-rnd(two)));
up = find(W(:,1) == W(:,2) & W(:,1) >= 1);           % upper corner: error relative to 1-F
for i = up'
   fprintf('%% (%.1f,%.1f): 1-F = %.2e, W error relative to 1-F %.3f, orders 1,2: %.1e %.1e\n',W(i,1:2), ...
      1-W(i,3),(W(i,5)-W(i,3))/(1-W(i,3)),(W(i,6)-W(i,3))/(1-W(i,3)),(W(i,7)-W(i,3))/(1-W(i,3)));
end
end

function k = sigdig(str)
%  number of significant digits of a printed value (a string)
str = strrep(str,'.',''); str = regexprep(str,'^0+','');
k = numel(str);
end

function s = rowE(v)
s = sprintf(' & %s',strjoin(arrayfun(@fmtE,v,'UniformOutput',false),' & '));
end

function s = fmtE(v)
if ~isfinite(v), s = '---'; return; end
if v == 0, s = '$0$'; return; end
e = floor(log10(abs(v))); m = v/10^e;
if abs(round(m*10)/10) >= 10, m = m/10; e = e+1; end
s = sprintf('$%.1f_{%d}$',m,e);
end

function s = fmtF(v)
e = floor(log10(abs(v))); m = v/10^e;
if round(m*1e6)/1e6 >= 10, m = m/10; e = e+1; end
s = sprintf('$%.6f_{%d}$',m,e);
end
