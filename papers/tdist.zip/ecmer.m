function [mu,psia,df] = ecmer(r,f,df)
%
%     ECME.M
%     This Matlab function returns the restricted (under the null H0: alpha=0_N) 
%     ML estimate of mu, Psi, and degrees of freedom using data Y_t = (r_t', f_t')', 
%     where Y_t follows a multivariate t-distribution with unknown degrees of freedom.
%     Input:
%     r: a TxN matrix of excess returns
%     f: a TxK matrix of factors
%     df: initial estimate of degrees of freedom (default = 10)
%     Output:
%     mu: ML Estimate of mu
%     psia: ML Estimate of psi
%     df: ML Estimate of degrees of freedom
%
maxiter = 300;
OPTIONS = optimset('Display','off');
[T,N] = size(r);
K = size(f,2);
p = N+K;
Y = [r f];
V = cov(Y,1);
if nargin<3
   df = 10;		% initial estimates
end
%
%  Initial estimate of mu and psi
%
mu2 = mean(f);
psi2 = cov(f,1)*(df-2)/df;
b = inv(V(N+1:end,N+1:p))*V(N+1:p,1:N);
psie = (V(1:N,1:N)-b'*V(N+1:p,N+1:p)*b)*(df-2)/df;
mu = [mu2*b mu2];
psia = [psie+b'*psi2*b b'*psi2; psi2*b psi2];
Y2 = Y-ones(T,1)*mu;
delta = sum(Y2.*(Y2*inv(psia)),2);
for iter=1:maxiter
    Z = (df+p)./(df+delta);	% Conditional expectation of Z
    w = Z/sum(Z);
    if all(abs(w'*f-mu2)<1e-10)
       break
    end
    mu2 = w'*f;
    Y1 = f-ones(T,1)*mu2;
    psi2 = (Y1'*(Z*ones(1,K).*Y1))/T;
    YY = r.*(sqrt(Z)*ones(1,N));
    XX = f.*(sqrt(Z)*ones(1,K));
    b = XX\YY;
    E = YY-XX*b;
    psie = (E'*E)/T;
    psia = [psie+b'*psi2*b b'*psi2; psi2*b psi2];
    mu = [mu2*b mu2];
    Y2 = Y-ones(T,1)*mu;
    delta = sum(Y2.*(Y2*inv(psia)),2);
    df = fzero(@f2,df,OPTIONS);
end
if iter==maxiter
   fprintf(' Warning!  Maximum number of iterations reached.\n')
   fprintf(' Degrees of freedom = %8.1f\n',df)
end

function y = f2(x)
   if x<=0
      y = 10000-x;		% Make sure x will stay away from negative
   else
      Z = (x+p)./(x+delta);
      y = psi(0.5*(x+p))-psi(0.5*x)+log(x/(x+p))+mean(log(Z)-Z)+1;
   end
end

end
