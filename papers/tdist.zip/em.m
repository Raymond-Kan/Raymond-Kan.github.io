function [mu,V] = em(Y,df)
%
%     EM.M
%     This Matlab function returns ML estimate of mu and V using data 
%     Y, where Y_t follows a multivariate t-distribution with known 
%     degrees of freedom.
%     Input:
%     Y: a TxN matrix of data
%     df: degrees of freedom 
%     Output:
%     mu: ML Estimate of mean
%     V: ML Estimate of covariance matrix 
%
[T,p] = size(Y);
maxiter = 300;
mu = mean(Y);
psia = cov(Y,1)*(df-2)/df;
Y1 = Y-ones(T,1)*mu;
for iter=1:maxiter
    delta = sum(Y1.*(Y1*inv(psia)),2);
    Z = (df+p)./(df+delta);	% Conditional expectation of Z
    w = Z/sum(Z);
    if all(abs(w'*Y-mu)<1e-10)
       break
    end
    mu = w'*Y;
    Y1 = Y-ones(T,1)*mu;
    psia = (Y1'*(Z*ones(1,p).*Y1))/T;
end
V = psia*df/(df-2);
if iter==maxiter
   fprintf(' Warning!  Maximum number of iterations reached.\n')
   fprintf(' Degrees of freedom = %8.1f\n',df)
end
