function [mu,psia] = emr(r,f,df)
%
%     EMR.M
%     This Matlab function returns the restricted (under the null H0: alpha=0_N) 
%     ML estimate of mu and Psi using data Y_t = (r_t', f_t')', where Y_t 
%     follows a multivariate t-distribution with known degrees of freedom.
%     Input:
%     Y: a TxN matrix of data
%     df: degrees of freedom 
%     Output:
%     mu: ML Estimate of mean
%     psia: ML Estimate of scale matrix (covariance matrix is df*/(df-2)*psia)
%
maxiter = 300;
[T,N] = size(r);
K = size(f,2);
p = N+K;
Y = [r f];
V = cov(Y,1);
%
%  Initial estimate of mu and psi
%
mu2 = mean(f);
psi2 = cov(f,1)*(df-2)/df;
b = inv(V(N+1:p,N+1:p))*V(N+1:p,1:N);
psie = (V(1:N,1:N)-b'*V(N+1:p,N+1:p)*b)*(df-2)/df;
mu = [mu2*b mu2];
psia = [psie+b'*psi2*b b'*psi2; psi2*b psi2];
for iter=1:maxiter
    Y2 = Y-ones(T,1)*mu;
    delta = sum(Y2.*(Y2*inv(psia)),2);
    Z = (df+p)./(df+delta);	% Conditional expectation of Z
    w = Z/sum(Z);
    if all(abs(w'*f-mu2)<1e-10)
       break
    end
    mu2 = w'*f;
    Y1 = f-ones(T,1)*mu2;
    psi2 = (Y1'*(Z*ones(1,K).*Y1))/T;
    YY = r.*(sqrt(Z)*ones(1,N));
    XX = f.*(sqrt(Z)*ones(1,K));
    b = XX\YY;
    E = YY-XX*b;
    psie = (E'*E)/T;
    psia = [psie+b'*psi2*b b'*psi2; psi2*b psi2];
    mu = [mu2*b mu2];
end
if iter==maxiter
   fprintf(' Warning!  Maximum number of iterations reached.\n')
   fprintf(' Degrees of freedom = %8.1f\n',df)
end
