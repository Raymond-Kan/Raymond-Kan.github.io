%
%   This Matlab function computes the likelihood ratio
%   test of alpha=0_N under multivariate normal or
%   multivariate t-distribution assumptions.
%   Input
%   r: a TxN matrix of excess returns of test assets
%   f: a TxK matrix of excess returns of traded factors
%   nu: degrees of freedom of multivariate t-distribution.
%       For the normality case, set nu=Inf, for the case
%       with unknown degrees of freedom, do not pass this
%       argument
%   Output
%   LRstat: likelihood ratio test statistic
%   pval: p-value of the likelihood ratio test statistic
%
function [LRstat,pval] = lrt(r,f,nu)
[T,N] = size(r);
K = size(f,2);
n = N+K;
y = [r f];
if nargin<3
   nu = 10;
end
if isinf(nu)
   mu = mean(y);
   V = cov(y,1);		% Important to use ML estimate of V here
   V12 = V(1:N,N+1:n);
   V22i = inv(V(N+1:n,N+1:n));
   beta = V12*V22i;
   alpha = mu(1:N)'-beta*mu(N+1:n)';
   mu2 = mu(N+1:n)';
   a = mu2'*V22i*mu2;
   Sigma = V(1:N,1:N)-beta*V12';
   LRstat = (alpha'*inv(Sigma)*alpha)/(1+a);
elseif nargin==3
   [mu,V] = em(y,nu);
   Psi = V*(nu-2)/nu;
   y2 = (y-ones(T,1)*mu)*Psi^(-0.5);
   y2 = 1+sum(y2.*y2,2)/nu;
   Lu = -0.5*log(det(Psi))-0.5*(nu+n)*mean(log(y2));
   [mu,Psi] = emr(r,f,nu);
   y2 = (y-ones(T,1)*mu)*Psi^(-0.5);
   y2 = 1+sum(y2.*y2,2)/nu;
   Lr = -0.5*log(det(Psi))-0.5*(nu+n)*mean(log(y2));
   LRstat = 2*(Lu-Lr)*(T-K-1-0.5*N);
else
   [mu,V,nu] = ecme(y,nu);
   Psi = V*(nu-2)/nu;
   y2 = (y-ones(T,1)*mu)*Psi^(-0.5);
   y2 = 1+sum(y2.*y2,2)/nu;
   Lu = gammaln((nu+n)/2)-gammaln(nu/2)-n/2*log(nu)-0.5*log(det(Psi))-0.5*(nu+n)*mean(log(y2));
   [mu,Psi,nu] = ecmer(r,f,nu);
   y2 = (y-ones(T,1)*mu)*Psi^(-0.5);
   y2 = 1+sum(y2.*y2,2)/nu;
   Lr = gammaln((nu+n)/2)-gammaln(nu/2)-n/2*log(nu)-0.5*log(det(Psi))-0.5*(nu+n)*mean(log(y2));
   LRstat = 2*(Lu-Lr)*(T-K-1-0.5*N);
end
pval = chi2cdf(LRstat,N,'upper');
