These are programs for my China Finance Review International paper 
"Modeling Non-normality Using Multivariate t:Implications for Asset 
Pricing" (with Guofu Zhou).  If you have questions, comments, or bug 
reports, please send them to kan@chass.utoronto.ca

Raymond Kan
Rotman School of Management
University of Toronto

Version 1.0: 10/8/2016, initial release

em.m: Maximum likelihood estimation of mean and variance of multivariate 
      t-distribution with known degrees of freedom.
ecme.m: Maximum likelihood estimation of mean and variance of multivariate 
        t-distribution with unknown degrees of freedom.
emr.m: Maximum likelihood estimation of mean and scale matrix of 
       Y_t = (r_t', f_t')', where Y_t follows a multivariate t-distribution 
       with known degrees of freedom, and the estimate is under the 
       constraint of alpha=0_N for the excess returns r_t.
ecmer.m: Maximum likelihood estimation of mean and scale matrix of 
         Y_t = (r_t', f_t')', where Y_t follows a multivariate t-distribution 
         with unknown degrees of freedom, and the estimate is under the 
         constraint of alpha=0_N for the excess returns r_t.
lrt.m: Likelihood test of alpha=0_N for the case of multivariate
       t-distribution.  It can handle degrees of freedom that are
       known or unknown.
