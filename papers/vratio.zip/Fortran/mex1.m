mex -v mrank1up.f ndlaed9.f
