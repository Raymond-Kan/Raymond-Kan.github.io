#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*), prhs(*)
      integer nlhs, nrhs
      mwpointer mxcreatedoublematrix,mxgetpr,mxduplicatearray
      mwsize mxgetm
      mwpointer work
      mwpointer d,z,rho,n,Q,icompq,lwork,n1,lambda
   
      d = mxgetpr(mxduplicatearray(prhs(1)))
      z = mxgetpr(mxduplicatearray(prhs(2)))
      rho = mxgetpr(mxduplicatearray(prhs(3)))
      n = mxgetm(prhs(1))
      if (nlhs.eq.1) then
         icompq = 0
         lwork = n
         n1 = 1
      else
         icompq = 1
         lwork = n*n
         n1 = n 
      end if
      plhs(1) = mxcreatedoublematrix(n,1,0)
      plhs(2) = mxcreatedoublematrix(n1,n1,0)
      work = mxgetpr(mxcreatedoublematrix(lwork,1,0))
      lambda = mxgetpr(plhs(1))    
      Q = mxgetpr(plhs(2))    
      call ndlaed9(icompq,n,n,%val(lambda),%val(work),n1,%val(rho),
     *%val(d),%val(z),%val(Q),n1)
      return
      end
