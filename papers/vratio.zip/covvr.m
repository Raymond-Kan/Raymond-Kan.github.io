%
% covvr.m		Date: 1/11/2004
% This Matlab program computes the exact covriance of two variance
% ratio test statistics with overlapping returns under the null hypothesis,
% assuming constant volatility.
% T: length of 1-period returns
% ka,kb: length of multi-period returns 
%
function y = covvr(T,ka,kb)
k1 = min(ka,kb);
k2 = max(ka,kb);
n1 = T-k1+1;
n2 = T-k2+1;
r1 = k1.*n1.*(n1-1)./T;
r2 = k2.*n2.*(n2-1)./T;
y1 = (n2.*n2-1).*n2-max(T-ka-kb,0).*(n2-k1).*(n2-k1+1);
y = 2*((T-1)./(T+1)).*(((n2-1)./(n1-1)-T.*(n2+1)./(2*r1)).*(k1./k2)+ ...
    (n2-k1+4*k1.*k2./T).*y1./(6*r1.*r2))-2./(T+1);
y(find(T<=ka|T<=kb|ka<0|kb<0)) = NaN;
