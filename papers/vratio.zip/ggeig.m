%
% ggeig.m		Date: 3/11/2004
% This Matlab program computes the eigenvalues of a symmetric 
% Toeplitz matrix GG'.
% For k=2,3,4, we use an improved algorithm of Handy and Barlow 
% to find out the eigenvalues of a banded Toeplitz matrix and then 
% do a few rank 1 updates of the eigensystem to obtain the 
% eigenvalues of GG'.
%
function y = ggeig(T,k)
if k==1
   y = ones(T-1,1);
   return
end
n = T-k+1;
%
% When T=2k, use an analytical solution
%
if T==2*k
   y = zeros(n,1);
   t1 = [1:2:k-1]'*pi/k;    % odd eigenvalues 
   t2 = [1:2:k]'*pi/n;      % even eigenvalues
   y(k:-2:2) = 1./(1-cos(t1));
   y(n:-2:2) = 1./(1-cos(t2));
   return
end
%
% When T<2k, use an almost analytical solution
%
if T<2*k
   t = [1:2:n-1]'*pi/n;
   d2 = 1./(1-cos(t));      % even eigenvalues
   d1 = d2;                 % odd eigenvalues
   q = csc(t/2);            % sum of even eigenvectors
   if rem(n,2)==1
      d1(end+1,1) = 0.5;
      q(end+1,1) = 1/sqrt(2);
   end
   d1 = mrank(d1,q,((1-k/T)*(2*k-T)-1)/n);
   y = sort([d1; d2]);
   return
end
%
% When k=2, first compute eigenvalues of HH'=GG'+k^2/T (a banded 
% symmetric Toeplitz matrix).  Then do a rank one update to 
% get the eigenvalues of GG'.  Note that we only need to do the 
% rank one update for half of the eigenvalues.
%
if k==2
   index1 = [1:2:n]'*pi/(n+1);
   index2 = [2:2:n]'*pi/(n+1);
   d1 = 2+2*cos(index1);
   d2 = 2+2*cos(index2);
   u = sqrt(2/(n+1))*cot(0.5*index1);
   y = sort([mrank(d1,u,-k*k/T); d2]);
   if rem(T,k)==0
      y(1) = 0;   % Just to take care of numerical error
   end
   return
end   
%
% When k=3, first compute eigenvalues of GG'+k^2/T (a banded 
% symmetric Toeplitz matrix).  Then do two rank one updates 
% to get the eigenvalues of GG'.
%
if k==3
   index1 = [1:2:n]'*pi/(n+1);
   index2 = [2:2:n]'*pi/(n+1);
   d1 = (1+2*cos(index1)).^2;
   d2 = (1+2*cos(index2)).^2;
   u1a = sqrt(2/(n+1))*sin(index1);
   u2a = sqrt(2/(n+1))*sin(index2);
   u = sqrt(2/(n+1))*cot(0.5*index1);
   [d1a,qa] = mrank(d1,u1a,2,u');
   d2a = mrank(d2,u2a,2);
   y = sort([mrank(d1a,qa',-k*k/T); d2a]);
   if rem(T,k)==0
      y(1) = 0;	% Just to take care of numerical error
   end
   return
end   
%
% When k=4, first compute eigenvalues of GG'+k^2/T (a banded 
% symmetric Toeplitz matrix).  Then do three rank one updates 
% to get the eigenvalues of GG'.
%
if k==4&&n>500
   index1 = [1:2:n]'*pi/(n+1);
   index2 = [2:2:n]'*pi/(n+1);
   x1 = cos(index1);
   x2 = cos(index2);
   y1 = sin(index1);
   y2 = sin(index2);
   d1a = 8*(1+x1).*x1.^2;
   d2a = 8*(1+x2).*x2.^2;
   u3a = (1-sqrt(2)+2*x1).*y1;
   u3b = (1+sqrt(2)+2*x1).*y1;
   u4a = (1-sqrt(2)+2*x2).*y2;
   u4b = (1+sqrt(2)+2*x2).*y2;
   u = sqrt(2/(n+1))*cot(0.5*index1);
   a = sqrt(2)/(n+1);
   [d1b,q1b] = mrank(d1a,u3a,-a,[u3b u]');
   [d1c,qa] = mrank(d1b,q1b(1,:)',a,q1b(2,:));
   [d2b,q2b] = mrank(d2a,u4a,-a,u4b');
   d2c = mrank(d2b,q2b',a);
   y = sort([mrank(d1c,qa',-k*k/T); d2c]);
   if rem(T,k)==0
      y(1) = 0;	% Just to take care of numerical error
   end
   return
end
%
% n=k+2
% Add -1 to (1,n) and (n,1) element of GG' to make it full,
% so GG'=S+q_1q_1'-q_2q_2', where q_1 = [1/sqrt(2) 0_{n-2}' 1/sqrt(2)]
% and q_2 = [1/sqrt(2) 0_{n-2}' -1/sqrt(2)]
%
if n==k+2
   t = [1:2:n-1]'*pi/n;
   d2 = 1./(1-cos(t));	 % Even eigenvalues
   d1 = d2;	             % Odd eigenvalues
   q1 = sin(t/2);
   q = 1./q1;            % Sum of even eigenvectors
   if rem(n,2)==1
      d1(end+1,1) = 0.5;
      q(end+1,1) = 1/sqrt(2);
      q1(end+1,1) = 1/sqrt(2);
   end
   [d1,q1] = mrank(d1,q,((1-k/T)*(2*k-T)-1)/n,q1');
   d1 = mrank(d1,q1',4/n);
   d2 = mrank(d2,cos(t/2),-4/n);
   y = sort([d1; d2]);
   return
end
%
% Normal way of doing things.  Split GG' into two smaller 
% matrices, find the eigenvalues of each.
%
r1 = [k:-1:1 zeros(1,n-k)];
r1 = r1(1:n)-k*k/T;
odd = rem(n,2)==1;
n1 = ceil(n/2);
n2 = n1-odd;
r = [1:n2]'*ones(1,n2);
s = ones(n2,1)*[1:n2];
index1 = abs(r-s)+1;
index2 = (n+2)-(r+s); 
B1 = r1(index1);
B2 = r1(index2);
A1 = B1+B2;
if odd
   r1a = sqrt(2)*r1(n1:-1:2);
   A1 = [A1 r1a'; r1a r1(1)];
end
d1 = eig(A1);
A2 = B1-B2;
d2 = eig(A2);
y = sort([d1; d2]);
if rem(T,k)==0
   y(1) = 0;	% Just to take care of numerical error
end
