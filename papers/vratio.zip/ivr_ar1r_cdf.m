%
% iv_ar1r_cdf.m		Date: 2/26/2004
% This Matlab program computes the inverse CDF of sample variance ratio 
% under the assumption that returns follows an AR(1) process
% prob: sample variance ratio
% T: number of 1-period return
% k: length of multi-period return
% phi: AR(1) coefficient
%
function y = ivr_ar1r_cdf(prob,T,k,phi,init)
if nargin<5
   init = max(1e-2,1+norminv(prob)*sqrt(varvr(T,k)));
end
[d,PQD] = pspar(T,phi);
n1 = floor((T-1)/2);
D1 = diag(sparse(d(1:n1)));           % Use sparse matrix to speed up the computation
D2 = diag(sparse(d(n1+1:end)));
n = T-k+1;
c = (T/n)*((T-1)/(n-1))/k;
n2 = ceil(n/2);
HPQD = filter(ones(1,k),1,PQD(1:k+n2-1,:)); 
HPQD = HPQD(k:end,:);
if rem(n,2)==1
   HPQD(end,:) = HPQD(end,:)/sqrt(2);
end
HP1 = HPQD(:,1:n1);
HP2 = HPQD(:,n1+1:end);
x1 = 2*c*(HP1'*HP1);
x2 = 2*c*(HP2'*HP2);
y = zeros(size(prob));
for i=1:numel(prob)
    y(i) = fzero(@linchi2a,init(i));
end

function y1 = linchi2a(c0);
   d0 = eig(x1-c0*D1);
   d1 = eig(x2-c0*D2);
   d = sort([d0; d1]);
   if d(end)<0
      y1 = 1;
   elseif d(1)>0
      y1 = -1;
   else
      y1 = linchi2(0,d)-prob(i);
   end
end

end
