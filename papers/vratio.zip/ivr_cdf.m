%
% ivr_cdf.m		Date: 2/26/2004
% This Matlab program computes the inverse CDF of variance ratio under
% the normality assumption and Sigma = \sigma^2 I_T
%
function y = ivr_cdf(prob,T,k,init,d0)
if nargin<5
   c1 = k*(1-(k-1)/T)*(1-(k-1)/(T-1));
   d0 = [zeros(k-2,1); ggeig(T,k)/c1];
end
if nargin<4
   init = max(1e-2,1+norminv(prob)*sqrt(varvr(T,k)));
end
y = zeros(size(prob));
for i=1:numel(prob)
    y(i) = fzero(@linchi2a,init(i),[]);
end

function y1 = linchi2a(c)
   if c>d0(end)
      y1 = 1;
   elseif c<0
      y1 = -1;
   else
      y1 = linchi2(0,d0-c)-prob(i);
   end
end

end