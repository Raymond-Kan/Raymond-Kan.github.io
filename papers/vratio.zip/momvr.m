%
% momvr.m		Date: 1/11/2004
% This Matlab program computes the first s noncentral and central moments of 
% \hat\theta(k) under the null hypothesis that assumes i.i.d. normality 
% Input:
% T: length of time series
% k: length of long-horizon returns
% s: order of moments 
% Output:
% y: first s noncentral moments of \hat\theta(k)
% yc: first s central moments of \hat\theta(k)
%
function [y,yc] = momvr(T,k,s)
r = T*(T-1)/(k*(T-k+1)*(T-k));
xi = ggeig(T,k)*r;
y = ones(1,s+1);
yc = zeros(1,s);
q0 = zeros(T-k+1,1);
for i=1:s
    q0 = xi.*(y(i)+q0);
    y(i+1) = sum(q0)/(2*i);
end
y = y(2:end).*cumprod([1:s]./[(T-1)/2:(T-3)/2+s]);
y(1) = 1;  % Using the fact that E[\hat\theta(k)] = 1
if nargout>1
   for i=2:s
       yc(i) = y(i);
       sgn = 1;
       c = 1;
       for j=1:i-1
           sgn = -sgn;
           c = c*(i+1-j)/j;
           yc(i) = yc(i)+sgn*c*y(i-j);
       end
       yc(i) = yc(i)-sgn;
    end
end
