%
% mrank.m		Date: 10/23/2004
% This Matlab program computes the rank one update of a 
% diagonal matrix, returning the eigenvalues and optionally 
% the eigenvectors.
% Alternatively, if Qold (a pxn matrix) is passed, then Q 
% will be set equal to Qold*eigenvectors
%
function [lam,Q] = mrank(d,z,rho,Qold)
n = length(d);
%
%   Quick return if possible
%
if n==1
   lam = d+rho*z^2;
   if nargout==2
      if nargin==3
         Q = 1;
      else
         Q = Qold;
      end
   end
   return
end
%
%   Scale z such that rho is positive and norm(z)=1
%
maxd = max(abs(d));
normz = norm(z);
z = z./normz;
rho = normz*normz*rho/maxd;
%
%   If the rank one modifier is small enough, no work
%   needs to be done
%
tol = 4*eps*maxd;
if abs(rho)*max(abs(z))<=tol
   [lam,ii] = sort(d);
   if nargout==2
      if nargin==3
         Q(ii,:) = eye(n);
      else
         Q = Qold(:,ii);
      end
   end
   return
end
%
%		Make sure d is in ascending order
%
if rho<0
   rho = -rho;
   maxd = -maxd;
end
d = d./maxd;
[d,ii] = sort(d);
z = z(ii);
if nargout==2
   if nargin==4
      Q = Qold(:,ii);		% Qold is pxn
   else
      Q = eye(n);
   end
end
%
%   Deflation of the problem
%
index = find(rho*abs(z)>tol);		% elements with nonzero z
k = length(index);
d1 = d(index);
z1 = z(index);
%
%		Collapse the columns with nearly identical d's.
%
for j=k-1:-1:1
    [G,y] = planerot(z1(j:j+1));		% Givens rotation
    if abs((d1(j+1)-d1(j))*prod(G(:,1)))<=tol
       z1(j:j+1) = y;
       d1(j:j+1) = (G.^2)*d1(j:j+1);		% Basically, don't need this if d1(j)-d1(j+1)
       d(index(j+1)) = d1(j+1);
       if nargout==2
          Q(:,index(j:j+1)) = Q(:,index(j:j+1))*G';
       end
    end
end
index1 = find(rho*abs(z1)>tol);		% elements with nonzero z
k1 = length(index1);
d2 = d1(index1);
z2 = z1(index1);
index2 = index(index1);
if nargout==1
   lam = mrank1up(d2,z2,rho);
   if (k1<n)
      d(index2) = lam;
      lam = d;
   end
   lam = sort(lam*maxd);
else      
   [lam,Q1] = mrank1up(d2,z2,rho);
   for i=1:k1
       Q1(:,i) = Q1(:,i)./norm(Q1(:,i));
   end
%   
%  Most commeon case (no deflation), write it
%  separately to improve speed.
%  
   if k1==n
      lam = lam*maxd;
      if nargin==3      
         Q(ii,:) = Q1;
      else
         Q = Q*Q1;
      end
%
%  No need to sort lam as it is already in
%  ascending order.
%      
      if maxd<0    
         lam = flipud(lam);
         Q = fliplr(Q);
      end   
      return
   end
   d(index2) = lam;
   if k1==k&&nargin==3
      Q(index2,index2) = Q1;
   else   
      Q(:,index2) = Q(:,index2)*Q1;
   end
   [lam,jj] = sort(d*maxd);
   if nargin==3
      Q(ii,:) = Q(:,jj);
   else
      Q = Q(:,jj);
   end
end
