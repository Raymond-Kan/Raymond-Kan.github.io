%
% optk_ar1r.m    Date: 2/14/2011
% This matlab program computes the optimal k for a 
% variance ratio test of random walk against an alternative 
% that the return follows an AR(1).  When the AR(1) 
% coefficient is positive (negative), the test is a
% right-tailed (left-tailed) test.  The test is 
% performed using the exact distribution.
% Input
% T: length of time series
% phi: AR(1) parameter
% kinit: initial estimate of optimal k (default = 2)
% p: size of the left-tailed test (default = 0.05)
% cutoff: a vector of the cutoff under the null (optional)
% Output
% k: optimal choice of k
% maxprob: probability of rejection under the optimal choice
%          of k
%
function [k,maxprob] = optk_ar1r(T,phi,kinit,p,cutoff)
kmin = 2;
if nargin<5
   kmax = T-1;
   cutoff = NaN(kmax,1);
   if nargin<4
      p = 0.05;
      if nargin<3
         kinit = kmin;
      end
   end
else
   kmax = length(cutoff);
end
prob = zeros(kmax,1);
kk = [kinit kmin:floor(kmax/4):kmax kmax];
lk = length(kk);
for i=1:lk
    prob(kk(i)) = rejprob(kk(i));
end
[~,ii] = max(prob(kk));
kinit = kk(ii);
%
%  Determine the search direction
%
if kinit==kmin
   direc = 1;
elseif kinit==kmax
   direc = -1;
else
   prob(kinit+1) = rejprob(kinit+1);
   if prob(kinit+1)>prob(kinit)
      direc = 1;
   else
      direc = -1;
   end
end
%
%   Search for optimal k
%
k = kinit;
prob(k+direc) = rejprob(k+direc);
while prob(k)<prob(k+direc)
   k = k+direc;
   if k+direc<kmin||k+direc>kmax
      break
   else
      prob(k+direc) = rejprob(k+direc);
   end
end
maxprob = prob(k);

%
%  Finds out the probability of rejection for a given value of k
%
function z = rejprob(k1)
   if prob(k1)~=0
      z = prob(k1);
      return
   end
   if isnan(cutoff(k1))
      if phi<0
         cutoff(k1) = ivr_cdf(p,T,k1);
      else
         cutoff(k1) = ivr_cdf(1-p,T,k1);
      end
   end
   if phi<0
      z = vr_ar1r_cdf(cutoff(k1),T,k1,phi);
   else
      z = 1-vr_ar1r_cdf(cutoff(k1),T,k1,phi);
   end
end

end
