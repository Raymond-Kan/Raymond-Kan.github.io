%
% pmomvr.m		Date: 1/10/2011
% This Matlab program computes the cross moment of \hat\theta(k_1)^s_1... \hat\theta(k_p)^s_p,
% where the data is assumed to be i.i.d. normally distributed.
% Usage: pmomrho(n,k,si)
%
function y = pmomvr(T,kk,si)
if nargin==3
   ii = find(si==0);
   si(ii) = [];
   kk(ii) = [];
else   
   si = ones(size(kk));
end
s = sum(si);
if s==0
   y = 1;
   return
end
ls = length(si);
if ls==1
   y = momvr(T,kk,si);
   y = y(end);
   return
end
T1 = fix(T/2);
odd = rem(T,2)==1;
if odd
   H1 = zeros(T1,T1,ls);
   H2 = H1;
   B1 = zeros(T1);
   B2 = B1;
   P1 = eye(T1)-2/(T+sqrt(T));
else
   H1 = zeros(T1-1,T1-1,ls);
   H2 = zeros(T1,T1,ls);
   B1 = zeros(T1-1);
   B2 = zeros(T1);
   P1 = [eye(T1-1)-1/(T1+sqrt(T1)); -ones(1,T1-1)./sqrt(T1)];
end
for i=1:ls
    H = toeplitz([1 zeros(1,T-kk(i))],[ones(1,kk(i)) zeros(1,T-kk(i))]);
    Ha = H(:,1:T1);
    Ha1 = Ha'*Ha;
    Ha2 = Ha'*flipud(Ha);
    H1(:,:,i) = 2*P1'*(Ha1+Ha2)*P1;
    H2(:,:,i) = 2*(Ha1-Ha2);
    if odd
       q = 4*min(kk(i),T-kk(i)+1)/T;
       x = P1'*Ha'*H(:,T1+1)*ones(1,T1);
       H1(:,:,i) = H1(:,:,i)+q-4/sqrt(T)*(x+x');
    end
end
%
%   Convert moment of product to moments of sum
%
p = 2;
x = zeros(1,ls);
y = 0;
for i=1:ls
    B1 = B1+0.5*si(i)*H1(:,:,i);
    B2 = B2+0.5*si(i)*H2(:,:,i);
end
for i=1:fix(prod(si+1)/2)
%
%   This part computes E[(z'Bz)^s]/s!, where 
%   B=(s_1/2-x_1)*A_{k_1}+...(s_r/2-x_r)*A_{k_r}
%
    d = [eig(B1); eig(B2)];
    y1 = 1;
    q0 = zeros(T-1,1);
    for j=1:s
        q0 = d.*(y1+q0);
        y1 = sum(q0)/(2*j);
    end 
    y = y+p*y1;
    for j=1:ls
        if x(j)<si(j)
           x(j) = x(j)+1;
           B1 = B1-H1(:,:,j);
           B2 = B2-H2(:,:,j);
           p = -round(p*(si(j)+1-x(j))/x(j));
           break
        end    
        x(j) = 0;
        B1 = B1+si(j)*H1(:,:,j);
        B2 = B2+si(j)*H2(:,:,j);
        if rem(si(j),2)==1
           p = -p;
        end
    end
end
m = kk.*(T-kk+1).*(T-kk)./T;
c = prod(((T-1)./(2*m)).^si);
y = y*c/prod([(T-1)/2:(T-3)/2+s]);
