%
% pnull.m		Date: 1/11/2004
% This Matlab program computes the decomposition of eye(n)-1/n into PP', where
% P is an nx(n-1) matrix with its columns symmetric or skewsymmetric.
%
function Q = pnull(n)
n1 = floor(n/2);
if rem(n,2)==1
   Q1 = [eye(n1)-(2/(sqrt(n)+n)); -(2/sqrt(n))*ones(1,n1)]/sqrt(2);
   Q2 = [eye(n1)/sqrt(2); zeros(1,n1)];
else
   Q1 = [eye(n1-1)-1/(n1+sqrt(n1)); -ones(1,n1-1)/sqrt(n1)]/sqrt(2);
   Q2 = eye(n1)/sqrt(2);
end
Q = [Q1 Q2; Q1(n1:-1:1,:) -Q2(n1:-1:1,:)];
