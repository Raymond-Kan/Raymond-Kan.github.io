%
% pspar.m  Date: 3/6/2004
% This Matlab program finds out the eigenvalue and eigenvectors of
% P'*S*P, where P is orthogonal to 1_n and S is c1*I_n-c2*A, where 
% A is an KMS matrix.  It then outputs the eigenvalues of P'*S*P and 
% P*Q*sqrt(D), where Q*D*Q' is the spectral decomposition of P'*S*P.
% 
function [d2,PQD] = pspar(n,phi,delta)
if nargin==2
   delta = [];
end
odd = rem(n,2)==1;
n1 = ceil(n/2);  % Number of even eigenvalues
n2 = n-n1;       % Number of odd eigenvalues
pi1 = pi/(n+1);
if phi==0
   d2 = ones(n-1,1);
   if nargout==2
      PQD = pnull(n-1);
   end
   return
end
ge = zeros(n1,1);
go = zeros(n2,1);
%
%	Find out all the even eigenvalues
%
for i=1:n1
    if phi>0
       ge(i) = fzero(@kmseven,[(2*i-2)*pi1 (2*i-1)*pi1]);
    else
       ge(i) = fzero(@kmseven,[(2*i-1)*pi1 (2*i)*pi1]);
    end    
end
%
%	Find out all the odd eigenvalues
%
for i=1:n2
    if phi>0
       go(i) = fzero(@kmsodd,[(2*i-1)*pi1 2*i*pi1]);
    else
       go(i) = fzero(@kmsodd,[2*i*pi1 (2*i+1)*pi1]);
    end    
end
de = (1-phi^2)./(1-2*phi*cos(ge)+phi^2);
do = (1-phi^2)./(1-2*phi*cos(go)+phi^2);
if ~isempty(delta)
   c = phi*(2+(1+phi)*delta);
   c1 = (1+phi)*(1+delta*phi)/c;
   c2 = (1-phi)/c;
   de = c1-c2*de;
   do = c1-c2*do;
else
   if phi>0
      do = flipud(do);
      go = flipud(go);
   end
end
%
%	Update de to da
%
x = sqrt(de).*(sin(0.5*n*ge).*csc(0.5*ge))./sqrt(n+sin(n*ge).*csc(ge));
if nargout==1
   da = mrank(de,x,-2/n);
   d2 = [da(2:end); do];
else
   index = 0.5*(n+1)-[1:n1]';
   MQe = cos(index*ge')-ones(n1,1)*(sin(0.5*n*ge').*csc(0.5*ge'))/n;
   sq = sqrt(0.5*(n+sin(n*ge').*csc(ge')));
   MQe = MQe./(ones(n1,1)*sq);
   Qo = sin(index(1:n2)*go');
   sq = sqrt(0.5*(n-sin(n*go').*csc(go')));
   Qo = Qo./(ones(n2,1)*sq);
   [da,Qa] = mrank(de,x,-2/n);
   PQD1 = MQe*diag(sqrt(de))*Qa(:,2:end);
   d2 = [da(2:end); do];      % first even then odd eigenvalues, only sorted within each group
   PQD = [PQD1 [Qo*diag(sqrt(do)); zeros(odd,n2)]];
   PQD = [PQD; PQD(n2:-1:1,1:n1-1) -PQD(n2:-1:1,n1:end)];
end

function y = kmseven(g)
   g1 = 0.5*(n+1)*g;
   y = (1-phi*cos(g)).*cos(g1)-phi*sin(g).*sin(g1);
end

function y = kmsodd(g)
   g1 = 0.5*(n+1)*g;
   y = (1-phi*cos(g)).*sin(g1)+phi*sin(g).*cos(g1);
end

end
