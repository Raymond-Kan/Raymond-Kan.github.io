%
% skewkurts.m		Date: 1/11/2004
% This Matlab program computes the exact skewness and kurtosis of the variance
% ratio test statistic with overlapping returns under the null hypothesis,
% assuming constant volatility.
% T: length of 1-period returns
% k: length of multi-period returns 
% g1: coefficient of skewness
% g2: coefficient of excess kurtosis
% It uses the symbolic math toolbox to avoid numerical problems.
%
%   Original codes:
%   x = [k:-1:1 zeros(1,n-k)];
%   G = ((T-1)/rho)*(toeplitz(x(1:n))-k^2/T);
%   a1 = 1;
%   a2 = trace(G^2)/(T-1);
%   a3 = trace(G^3)/(T-1);
%   a4 = trace(G^4)/(T-1);
%   mu2 = 2*(a2-1)/(T+1);
%   mu3 = 8*(a3-3*a1*a2+2*a1^3)/((T+1)*(T+3));
%   mu4 = 12*((4*a4+T1*a2^2)-2*a1*(8*a3+T1*a1*a2)+a1*a1*(24*a2+T1*a1*a1)-12*a1^4)/((T+1)*(T+3)*(T+5));
%
function [g1,g2] = skewkurts(T,k)
Ts = sym(T);
ks = sym(k);
n = Ts-ks+1;
ks2 = ks.*ks;
ks3 = ks2.*ks;
ks4 = ks2.*ks2;
ks5 = ks3.*ks2;
ks6 = ks3.*ks3;
n2 = n.*n;
n3 = n2.*n;
n4 = n2.*n2;
n5 = n3.*n2;
c = ks.*ks./Ts;
nc = n.*c;
nc2 = nc.*nc;
nc3 = nc2.*nc;
nc4 = nc2.*nc2;
d0 = ks.*(ks2-1);
d1 = sym(max(2*k-T-1,0)).*((ks-n).^2-1);
d2 = sym(max(3*k-T-1,0)).*((2*ks-n).^2-1).*((2*ks-n).^2-4);
d3 = sym(max(4*k-T-1,0)).*((3*ks-n).^2-1).*((3*ks-n).^2-4).*((3*ks-n).^2-9);
tb1 = n.*ks;
tb2 = n.*ks+(4*n-ks).*d0./6+(ks-n).*d1./6;
tb3 = n.*ks+((33*ks2+48).*n-2*ks.*(7*ks2+2)).*d0./60 ...
           +((2*n-15*ks).*n2+(9*ks2-8).*n+2*ks.*(7*ks2+2)).*d1./60;
tb4 = n.*ks+((302*ks4+442*ks2+540).*n-171*ks5-73*ks3-17*ks).*d0./630 ...
           -((149*ks-531*n).*ks4+(200*n2-425).*ks3+(102*n3+201*n).*ks2 ...
           -(55*n4-89*n2-51).*ks+9*n5-19*n3+37*n).*d1./630 ...
           +(2*ks-n).*(5*(2*ks-n).^2-17).*d2./2520;
sb1 = n.*ks2-d0./3+d1./3;
sb2 = n.*ks4-(17*ks2+2).*d0./30+(6+ks2+13*n.*ks-4*n2).*d1./30+d2./60;
sb3 = n.*ks6-(953*ks4+169*ks2+36).*d0./1260 ...
            +((116*n-31*ks).*ks3+(96*n2+55).*ks2-(86*n3-102*n).*ks+15*n4-39*n2+36).*d1./360 ...
            -(2*n2+ks2-15*ks.*n-18).*d2./1260+d3./2520;
c1 = (tb1-nc)./(Ts-1);
den = (Ts-1).*c1.*c1;
a2 = (tb2-2*c.*sb1+nc2)./den;
a3 = (tb3-3*c.*sb2+3*nc.*c.*sb1-nc3)./(den.*c1);
a4 = (tb4-4*c.*sb3+4*nc.*c.*sb2+2*c.*c.*sb1.*sb1-4*nc2.*c.*sb1+nc4)./(den.*c1.*c1);
mu2 = (2*a2-2)./(Ts+1);
mu3 = 8*(a3-3*a2+2)./((Ts+1).*(Ts+3));
mu4 = 12*(4*a4-16*a3+(Ts-1).*a2.^2-(Ts-13).*(2*a2-1))./((Ts+1).*(Ts+3).*(Ts+5));
g1 = double(mu3./sqrt(mu2).^3);
g2 = double(mu4./mu2.^2-3);
index = T<=k;
g1(index) = NaN;
g2(index) = NaN;
