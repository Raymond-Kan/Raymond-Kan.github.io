%
% varvr.m		Date: 1/11/2004
% This Matlab program computes the exact variance of the variance
% ratio test statistic with overlapping returns under the null hypothesis,
% assuming constant volatility.
% T: length of 1-period returns
% k: length of multi-period returns 
%
function y = varvr(T,k)
n = T-k+1;
if n<=1
   y = NaN;
else
   if n>k
      y = (6*k^3*(k-1)^2+4*k^2*(k^2-1)*T-k*(7*k^2-1)*T^2+ ...
          2*(2*k^2+1)*n*T*T)*(T-1)/(3*k*(n-1)^2*n^2*(T+1))-2/(T+1);
   else
      y = (T-1)*((n^2-1)*(n*(T-3*k)+4*k)+k*k*(3*n*n-5*n+4))/(3*(T+1)*n*(n-1)*k*k)-2/(T+1);
   end
end
