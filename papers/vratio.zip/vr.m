%
% vr.m   Date: 1/11/2004
% This Matlab program computes Lo and MacKinlay (1988) variance
% ratio test statistic with overlapping returns.
% Input
% r: matrix of 1-period returns
% k: length of multi-period returns 
% Output
% y: variance ratio of k-period return to 1-period return divided by k
% trat: test statistic of H_0: theta(k)=1 using Lo and MacKinlay (1988)
%       fixed-k asymptotic standard error.
%
function [y,tratio] = vr(r,k)
[T,N] = size(r);
if T<=k
   y = NaN*ones(1,N);
   tratio = y;
else
   vrho = zeros(k-1,N);
   mu = mean(r);
   sa = std(r).^2;
   r = r-ones(T,1)*mu;		% Subtract the mean from the returns
   temp = sum(r.*r).^2;
   for i=1:k-1
       vrho(i,:) = sum((r(1:T-i,:).^2).*(r(i+1:T,:).^2))./temp;
   end
   r1 = filter(ones(1,k),1,r);
   r1 = r1(k:T,:);
   m = k*(T-k+1)*(1-k/T);
   sc = sum(r1.*r1)/m;
   y = sc./sa;
   serr = 2*sqrt(([k-1:-1:1].^2)*vrho)/k; 
   tratio = (y-1)./serr;
end
