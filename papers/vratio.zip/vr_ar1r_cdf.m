%
% vr_ar1r_cdf.m		Date: 2/26/2004
% This Matlab program computes the CDF of variance ratio under
% the assumption that returns follows an AR(1) process
% vr: sample variance ratio
% T: number of 1-period return
% k: length of multi-period return
% phi: AR(1) coefficient
%
function y = vr_ar1r_cdf(vr,T,k,phi)
[d,PQD] = pspar(T,phi);
n1 = floor((T-1)/2);
D1 = diag(sparse(d(1:n1)));           % Use sparse matrix to speed up the computation
D2 = diag(sparse(d(n1+1:end)));
n = T-k+1;
c = (T/n)*((T-1)/(n-1))/k;
n2 = ceil(n/2);
HPQD = filter(ones(1,k),1,PQD(1:k+n2-1,:)); 
HPQD = HPQD(k:end,:);
if rem(n,2)==1
   HPQD(end,:) = HPQD(end,:)/sqrt(2);
end
HP1 = HPQD(:,1:n1);
HP2 = HPQD(:,n1+1:end);
x1 = 2*c*(HP1'*HP1);
x2 = 2*c*(HP2'*HP2);
y = zeros(size(vr));
for i=1:numel(vr)
    if vr(i)<0
       y(i) = 0;
    else
       d0 = eig(x1-vr(i)*D1);
       d1 = eig(x2-vr(i)*D2);
       y(i) = linchi2(0,[d0; d1]);
    end
end
