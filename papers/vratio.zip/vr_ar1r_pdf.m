%
% vr_ar1r_pdf.m		Date: 2/26/2004
% This Matlab program computes the PDF of variance ratio under
% the assumption that returns follows an AR(1) process
% vr: sample variance ratio
% T: number of 1-period return
% k: length of multi-period return
% phi: AR(1) coefficient
%
function y = vr_ar1r_pdf(vr,T,k,phi)
[d,PQD] = pspar(T,phi);
n1 = floor((T-1)/2);
D1 = diag(sparse(d(1:n1)));           % Use sparse matrix to speed up the computation
D2 = diag(sparse(d(n1+1:end)));
n = T-k+1;
c = (T/n)*((T-1)/(n-1))/k;
n2 = ceil(n/2);
HPQD = filter(ones(1,k),1,PQD(1:k+n2-1,:)); 
HPQD = HPQD(k:end,:);
if rem(n,2)==1
   HPQD(end,:) = HPQD(end,:)/sqrt(2);
end
HP1 = HPQD(:,1:n1);
HP2 = HPQD(:,n1+1:end);
x1 = 2*c*(HP1'*HP1);
x2 = 2*c*(HP2'*HP2);
r2pi = 0.15915494309189533577;  % 1/(2*pi)
y = zeros(size(vr));
for i=1:numel(vr)
    if vr(i)<=0
       y(i) = 0;
    else
       [P1,Lam1] = eig(x1-vr(i)*D1);
       [P2,Lam2] = eig(x2-vr(i)*D2);
       wgt = [diag(Lam1); diag(Lam2)];
       h = [diag(P1'*D1*P1); diag(P2'*D2*P2)];
       y(i) = r2pi*quadgk(@integrand,0,inf,'AbsTol',1e-8);
    end
end

function y1=integrand(u)
   p = wgt*u;
   d1 = 1./(1+p.*p);
   beta = 0.5*sum(atan(p));
   rho = h'*d1;
   delta = (h.*wgt)'*d1;
   y1 = (cos(beta).*rho-u.*sin(beta).*delta).*(prod(d1).^0.25);
end

end
