%
% vr_cdf.m		Date: 2/26/2004
% This Matlab program computes the CDF of variance ratio under
% the normality assumption.
%
function y = vr_cdf(vr,T,k,d)
if nargin<4
   d = [zeros(k-2,1); ggeig(T,k)];
end
y = zeros(size(vr));
for i=1:numel(vr)
    c = vr(i)*k*(1-(k-1)/T)*(1-(k-1)/(T-1));
    if c<=0
       y(i) = 0;
    elseif c>=d(end)
       y(i) = 1;
    else
       y(i) = linchi2(0,d-c);
    end
end
