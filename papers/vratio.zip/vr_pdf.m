%
% vr_pdf.m		Date: 2/26/2004
% This Matlab program computes the PDF of variance ratio under
% the normality assumption.
%
function y = vr_pdf(vr,T,k,d)
if nargin<4
   d = [zeros(k-2,1); ggeig(T,k)];
end
adj = k*(1-(k-1)/T)*(1-(k-1)/(T-1));
r2pi = 0.15915494309189533577;  % 1/(2*pi)
y = zeros(size(vr));
for i=1:numel(vr)
    c = vr(i)*adj;
    if c<=0|c>=d(end)
       y(i) = 0;
    else
       wgt = d-c;
       y(i) = r2pi*quadgk(@integrand,0,inf,'AbsTol',1e-8)*adj;
    end
end

function y1=integrand(u)
   p = wgt*u;
   d1 = 1./(1+p.*p);
   beta = 0.5*sum(atan(p));
   rho = sum(d1);
   delta = wgt'*d1;
   y1 = (cos(beta).*rho-u.*sin(beta).*delta).*(prod(d1).^0.25);
end

end