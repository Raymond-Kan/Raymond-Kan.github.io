These are programs for the paper "What Will the Likley Range of My Wealth
Be" (with Guofu Zhou)
If you have questions, comments, or bug reports, please send them to 
kan@chass.utoronto.ca

Raymond Kan
Rotman School of Management
University of Toronto

umvup.m: Unbiased estimation of P[a<W_H<b]
umvuq.m: Unbiased estimation of theta=exp(a*mu+b*sigma).  For
         the problem in the paper, put a=H and b=sqrt(H)*norminv(p).
         The numerical method is explained in the attached note7.pdf,
         and we use Eq.(12) for evaluating the unbiased estimator
         of theta.
hyperg.m: Matlab hypergeometric function replacement.
          Note that Matlab's hypergeom.m has a bug (up to R2008a) 
          that makes it slow and sometimes return incorrect
          answer.  Example: hypergeom([10 30],20,0.5) = 3.5253e15
          whereas the correct answer is 7.4080e04.  
          If you use Matlab R2008b or later, then you can simply 
          replace hyperg with hypergeom.
          hyperg.m requires the symbolic toolbox in Matlab.  However, 
          our program can be easily modified without using this function.
