function p = umvup(a,b,muh,sh,H,T)
%
%     UMVUP
%     This Matlab function returns the UMVU Estimator of P[a<W_H<b] as a function
%     of sample mean (muh) and sample standard deviation (sh), H is the investment
%     horizon and T is the sample size
%
if T>H
   q1 = (log(a)-muh*H)/(sqrt(H)*sh);
   q2 = (log(b)-muh*H)/(sqrt(H)*sh);
   a1 = 0.5*(1+sqrt(T/((T-H)*(T-1)))*q1);
   a2 = 0.5*(1+sqrt(T/((T-H)*(T-1)))*q2);
   a1 = max(min(a1,1),0);
   a2 = max(min(a2,1),0);
   p = betainc(a2,T/2-1,T/2-1)-betainc(a1,T/2-1,T/2-1);
else
   p = NaN;
end
