function w = umvuq(a,b,muh,sh,T)
%
%     UMVUQ
%     This Matlab function returns the UMVU Estimator of exp(a*mu+b*sigma) as a function
%     of sample mean (muh) and sample standard deviation (sh), and T is the sample
%     size.  
%
if b==0
   w = exp(a*muh)*hyperg([],(T-1)/2,-(T-1)*(a*sh)^2/(4*T));
   return
end
c = exp(gammaln((T-1)/2)-gammaln(T/2));
if a==0
   x = sqrt((T-1)/2)*b*sh;
   x2 = (x.*x)./4;
   w = hyperg([],[1/2 (T-1)/2],x2)+c*x.*hyperg([],[3/2 T/2],x2);
   return
end
x = sqrt(T)*b/a;
q = a*sh*sqrt((T-1)/(2*T));
q2 = q*q;
y1 = 1;
z1 = c*q;
M = 10000;
%
%   Compute H_k(x)/k!
%
h1 = 1;
h2 = x;
y = y1+z1*x;
for j=1:M
    y1 = y1*q2/((T-3)/2+j);
    z1 = z1*q2/(T/2+j-1);
    h1 = (x*h2-h1)/(2*j);
    h2 = (x*h1-h2)/(2*j+1);
    e1 = y1*h1;
    e2 = z1*h2;
    y = y+e1+e2;
    if abs(e1)+abs(e2)<eps
       break
    end
end
w = exp(a*muh)*y;
