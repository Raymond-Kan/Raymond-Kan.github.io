%
%  This function computes the coefficients of the denominator 
%  polynomial of \tilde{H}_k^{-1} and \tilde{C}_k^{-1}.  The
%  returned vector are the coefficients of declining power of
%  n1, with the last term being the coefficient of n1. 
%  Note 1: when alpha is not an integer, y is also not an integer
%  vector.  
%  Note 2: When k>11, the elements are not exactly accurate.
%  Note 3: The roots of the full denominator polynomial n1*prod(n1+y1) are
%          n1 = i-1-j*alpha for the cells (i,j+1) of the partitions of k
%          (with multiplicity = the maximum multiplicity over all partitions
%          of k); the largest root is (k-1)*alpha, which is the existence
%          threshold for the inverse moments of degree k.
%
function y = denpoly(k,alpha)
   if k==1
      y = 1;
      return
   end
   if nargin<2
      alpha = 2;
   end
   pp = ip_desc(k);
   dk = size(pp,1);
   y1 = [(-(k-1):0)*alpha 1:k-1]; % This is for \kappa = (k) and (1^k)
   for i=2:dk-1
       pp1 = pp(i,:);
       pp1 = pp1(pp1>0);
       q = []; 
       for j=1:length(pp1)
           q = [q; j-1-alpha*(0:(pp1(j)-1))'];
       end
       a1 = unique(q);
       for j=1:length(a1)
           nn = sum(q==a1(j))-sum(y1==a1(j));
           if nn>0
              y1 = [y1 repelem(a1(j),nn)];
           end
       end
   end
%  The denominator polynomial is prod(n1+y1)   
   y1(k) = [];   % Get rid of the term n1 
   y = zeros(1,length(y1)+1);
   y(1) = 1;
   for i=1:length(y1)
       y(2:i+1) = y(2:i+1)+y1(i)*y(1:i);
   end
 
