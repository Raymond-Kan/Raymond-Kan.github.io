%
%  This function finds the mapping matrix from
%  \tilde{Q}_{k+1} to \tilde{Q}_{k} when W~W_m(n,Sigma).  
%  Note: n1 is n-m+1-alpha. If this input is not provided,
%  a symbolic n1 will be created.  
%  Input 
%  k: order of D_{-k}
%  alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%  n1: n-m+1-alpha
%
function Di = dkimap(k,alpha,n1)
   if nargin<3
      n1 = sym('n1');
      if nargin<2
         alpha = 2;
      end
   end
   if k==1
      Di = inv([n1-alpha+1 -1; -alpha n1]);
      return
   end
%
%  F(i,j) is the number of integer partitions of i with j parts or less,
%  it is also the number of integer partitions of i whose first part
%  is smaller than or equal to j.
%
   F = ones(k);
   for j=2:k
       F(:,j) = F(:,j-1);
       F(j,j) = F(j,j)+1;
       for i=j+1:k
           F(i,j) = F(i,j)+F(i-j,j);
       end
   end
   dd = cumsum([1; diag(F)]);
   lp2 = F(k,k);
   dk1 = dd(k+1);
   dk2 = dd(k);
   D = zeros(dk1,dk1,class(n1));
%  Recursion for E[W^{-(k+1)}]
   D(1,1) = -(alpha-1)*k;
   D(1,dd(1:k)+1) = -1;
%  Recusion for E[W^{-k}*tr(W^{-1})]
   D(2,1) = -alpha;
   D(2,2) = -(alpha-1)*(k-1);
   count = 2;
   for i=2:k 
%      These are terms for W^{-(k+1-i)}
       count = count+1;
       D(count,1) = -alpha*i;
       D(count,count) = -(alpha-1)*(k-i);
       x = [i ones(1,i-1)];
       m = 1;
       h = 1;
       for ii=2:F(i,i)
           if x(h)==2
              m = m+1;
              x(h) = 1;
              h = h-1;
           else
              r = x(h)-1;
              t = m-h+1;
              x(h) = r;
              while t>=r
                 h = h+1;
                 x(h) = r;
                 t = t-r;
              end
              if t==0
                 m = h;
              else
                 m = h+1;
                 if t>1
                    h = h+1;
                    x(h) = t;
                 end
              end
           end
           count = count+1;
           if count<=dk2
              D(count,count) = -(alpha-1)*(k-i);
           end
           pp = x(1:m);
           for j=1:x(1)
               v = find(pp==j);
               lj = length(v);
               if lj>0
                  pp1 = pp;
                  pp1(v(1)) = [];
                  i1 = ind(pp1,k-i+j);
                  D(count,i1) = -alpha*j*lj;
                  D(i1,count) = -1;
               end
           end    
       end
   end
   for i=1:dk1
       D(i,i) = D(i,i)+n1;
   end
   Di = inv(D);
%  If we want to separate the rational polynomials into
%  its numerator and denominator polynomials, we can do
%  dd = det(D);                 % common denominator
%  Dadj = collect(Di*dd,'n1');  % numerator


function ind1 = ind(p,f1)
%
%  This function takes an integer partition p and an integer f1 
%  and returns the location of W^f1*prod_{i=1}^l(p)tr(W^p_i) 
%  within the list of Q_{k-1}, where k-1=f1+|p|.
%
   k1 = sum(p);
   ind1 = F(k1,k1);
   if nargin>1&&f1>0
      ind1 = ind1+dd(k1);
   end
   for i2=1:length(p)
       kk = p(i2);
       if kk>1
          ind1 = ind1-F(k1,kk-1);
          k1 = k1-kk;
       else
          break
       end
   end
end

end
