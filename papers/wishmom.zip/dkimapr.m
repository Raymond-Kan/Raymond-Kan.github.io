%
%  This function finds the mapping matrix \tilde{D}_k, which
%  maps from \tilde{Q}_{k} to \tilde{Q}_{k+1} when W~W_m(n,Sigma).  
%  Input 
%  k: order of 
%  alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%  Output
%  D: coefficient matrices of the numerator of \tilde{D}_k (in declining power of n1,
%     with the last element being the constant term), where n1 = n-m+1-alpha
%  a: coefficients of the denominator of \tilde{D}_k (in declining power of n1, with
%     the last element being the constant term)
%  Method: D_{-k} = n1*I + M with M = -dkmap(k,alpha).  The distinct eigenvalues
%  of -M are y = j*alpha-i for the (zero-based) cells (i,j) that can be added to
%  some partition of k, i.e., {j*alpha-i : (i+1)(j+1) <= k+1} EXCLUDING (i,j)=(0,0)
%  (the empty cell is addable only to the empty diagram); unid.m builds exactly
%  this list.  -M is diagonalizable (dkmap(k,alpha) is reversible for the weights
%  1/(alpha^length(lam)*z_lam), hence similar to a symmetric matrix),
%  so p(x) = prod(x+y) annihilates M and D_{-k}^{-1} = N(n1)/p(n1) with N obtained
%  from the Cayley-Hamilton (Faddeev-LeVerrier) recursion below.  The final
%  result is verified numerically at one value of n1; a warning is issued if
%  the check fails (this would indicate an incomplete root list for the given alpha).
%
function [D,a] = dkimapr(k,alpha)
   if nargin<2
      alpha = 2;
   end
   if k==1
      D = zeros(2,2,2,class(alpha));
      D(:,:,1) = eye(2);
      D(:,:,2) = [0 1; alpha 1-alpha];
      a = [1 1-alpha -alpha];
      return
   end
   Dkn = -dkmap(k,alpha);
   y = [(-k:-1)*alpha 1:k]'; 
   for j=1:floor((k-1)/2)
       maxj = floor((k+1)/(j+1))-1;
       y = [y; j-alpha*(1:maxj)'];
   end
   if isnumeric(alpha)
      y = uniquetol(y,1e-10);
   else
      y = unique(y);
   end
   m1 = length(y);
   a = zeros(1,m1+1,class(alpha));
   a(1) = 1;
   for i=1:m1
       a(2:i+1) = a(2:i+1)+y(i)*a(1:i);
   end
   r = size(Dkn,1);
   D = zeros(r,r,m1,class(alpha));
   D(:,:,1) = eye(r);
   for i=1:m1-1
       D(:,:,i+1) = a(i+1)*eye(r)-Dkn*D(:,:,i);
   end
%  Verification (version 3.0): evaluate at a test point n1 and check that
%  D(n1)/a(n1) is the inverse of D_{-k} = n1*I - dkmap(k,alpha).  A warning is
%  issued if the relative residual exceeds 1e-6.
   if isnumeric(alpha)
      n1 = k*alpha+2;
      dd = a*(n1.^(m1:-1:0).');
      X1 = zeros(r);
      for i=1:m1
          X1 = X1+D(:,:,i)*n1^(m1-i);
      end
      res = norm(X1*(n1*eye(r)+Dkn)/dd-eye(r),1);
      if res>1e-6
         warning('dkimapr:check','dkimapr: consistency check failed at n1=%g (residual %g); the eigenvalue list may be incomplete for this alpha/k.',n1,res);
      end
   end
