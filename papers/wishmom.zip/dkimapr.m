%
%  This function finds the mapping matrix \tilde{D}_k, which
%  maps from \tilde{Q}_{k} to \tilde{Q}_{k+1} when W~W_m(n,Sigma).  
%  Input 
%  k: order of 
%  alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%  Output
%  D: coefficient matrices of the numerator of \tlilde{D}_k (in declining power of n1,
%     with the last element being the constant term), where n1 = n-m+1-alpha
%  a: coefficients of the denominator of \tilde{D}_k (in declining power of n1, with
%     the last element being the constant term)
%
function [D,a] = dkimapr(k,alpha)
   if nargin<2
      alpha = 2;
   end
   if k==1
      D = zeros(2,2,2,class(alpha));
      D(:,:,1) = eye(2);
      D(:,:,2) = [0 1; alpha 1-alpha];
      a = [1 1-alpha -alpha];
      return
   end
   Dkn = -dkmap(k,alpha);
   y = [(-k:-1)*alpha 1:k]'; 
   for j=1:floor((k-1)/2)
       maxj = floor((k+1)/(j+1))-1;
       y = [y; j-alpha*(1:maxj)'];
   end
   if isnumeric(alpha)
      y = uniquetol(y,1e-10);
   else
      y = unique(y);
   end
   m1 = length(y);
   a = zeros(1,m1+1,class(alpha));
   a(1) = 1;
   for i=1:m1
       a(2:i+1) = a(2:i+1)+y(i)*a(1:i);
   end
   r = size(Dkn,1);
   D = zeros(r,r,m1,class(alpha));
   D(:,:,1) = eye(r);
   for i=1:m1-1
       D(:,:,i+1) = a(i+1)*eye(r)-Dkn*D(:,:,i);
   end
