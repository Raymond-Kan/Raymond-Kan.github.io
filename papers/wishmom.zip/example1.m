%
%   This example shows how to compute the D_k matrix 
%   for Q_{k}.
%
delete example1.out
diary example1.out
syms n
alpha = 2;   % alpha = 1 for complex, alpha = 2 for real
for k=1:6
    fprintf('k = %2.0f\n',k)
    D = dkmap(k,alpha);
    pk = size(D,1);
    D = D+eye(pk)*n;
    disp(['D_k = '])
    fprintf('\n')
    disp(D)
    fprintf('\n')
end
fprintf(' CPU time:\n')
maxk = 20;
cput = zeros(maxk,1);
dk = zeros(maxk,1);
for k=1:maxk
    t = cputime;
    Di = dkmap(k,alpha);
    cput(k) = cputime-t;
    dk(k) = size(Di,1);
end
fprintf('  k    d_k   CPU Time (seconds)\n')
for k=1:maxk
    fprintf('%4.0f  %4.0f     %8.2f\n',k,dk(k),cput(k))  
end
diary off

