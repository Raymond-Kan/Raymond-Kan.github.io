%
%   This example shows how to compute the coefficients
%   for q_k.
%
delete example2.out
diary example2.out
syms n
alpha = 2;   % alpha = 1 for complex, alpha = 2 for real
for k=1:6
    fprintf('k = %2.0f\n',k)
    H = wish_ps(k,alpha,n);
    disp(['H_' num2str(k) ' = '])
    disp(H)
    fprintf('\n')
end
fprintf(' CPU time:\n')
maxk = 20;
cput = zeros(maxk,1);
pk = zeros(maxk,1);
for k=1:maxk
    t = cputime;
    H = wish_ps(k,alpha);
    cput(k) = cputime-t;
    pk(k) = size(H,1);
end
fprintf('  k    p_k   CPU Time (seconds)\n')
for k=1:maxk
    fprintf('%4.0f  %4.0f     %8.2f\n',k,pk(k),cput(k))  
end
diary off
