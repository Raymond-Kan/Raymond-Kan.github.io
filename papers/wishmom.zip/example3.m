%
%   This example shows how to compute the coefficients
%   for Q_k.
%
delete example3.out
diary example3.out
syms n
alpha = 2;   % alpha = 1 for complex, alpha = 2 for real
for k=1:6
    fprintf('k = %2.0f\n',k)
    c = qk_coeff(k,alpha,n);
    disp(['C_' num2str(k) ' = '])
    disp(c)
    fprintf('\n')
end
fprintf(' CPU time:\n')
maxk = 20;
cput = zeros(maxk,1);
dk = zeros(maxk,1);
for k=1:maxk
    t = cputime;
    c = qk_coeff(k,alpha);
    cput(k) = cputime-t;
    dk(k) = size(c,1);
end
fprintf('  k    d_k   CPU Time (seconds)\n')
for k=1:maxk
    fprintf('%4.0f  %4.0f     %8.2f\n',k,dk(k),cput(k))  
end
diary off

