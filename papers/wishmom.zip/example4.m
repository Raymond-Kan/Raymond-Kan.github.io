%
%   This example shows how to compute the \tilde{D}_k and \tilde{D}_k^{-1} 
%   matrices for \tilde{Q}_k.
%
delete example4.out
diary example4.out
syms n1
alpha = 2;   % alpha = 1 for complex, alpha = 2 for real
fprintf(' n1 is n-m+1-alpha\n')
for k=1:6
    fprintf('k = %2.0f\n',k)
    [D,den] = dkimapr(k,alpha);
    dd = den*(n1.^[length(den)-1:-1:0].');    
    [r,~,nD] = size(D);
    D1 = zeros(r,r,class(n1));
    nn = n1.^([nD-1:-1:0]');
    for i=1:r
        D1(i,:) = squeeze(D(i,:,:))*nn;
    end
    D = eye(r)*n1-dkmap(k,alpha);
    disp(['D_{-k} ='])
    fprintf('\n')
    disp(D)
    fprintf('\n')
    disp(['Common Denominator of \tilde{D}_k ='])
    disp(dd)
    fprintf('\n')
    disp(['Numerator of \tilde{D}_k ='])
    disp(D1)
    fprintf('\n\n')
end
fprintf(' CPU time:\n')
maxk = 20;
cput = zeros(maxk,1);
dk = zeros(maxk,1);
for k=1:maxk
    t = cputime;
    [D,den] = dkimapr(k,alpha);
    cput(k) = cputime-t;
    dk(k) = size(D,1);
end
fprintf('  k    d_k   CPU Time (seconds)\n')
for k=1:maxk
    fprintf('%4.0f  %4.0f     %8.2f\n',k,dk(k),cput(k))  
end
diary off

