%
%   This example shows how to compute the coefficients
%   for \tilde{q}_{k}.
%
delete example5.out
diary example5.out
syms n1
alpha = 2;   % alpha = 1 for complex, alpha = 2 for real
for k=1:6
    fprintf('k = %2.0f\n',k)
    [H,den] = iwish_psr(k,alpha);
    disp(['\tilde{H}_' num2str(k) ' = '])
    disp('Common Denominator')
    disp(den*(n1.^[length(den):-1:1].'))
    disp('Numerator')
    [r,~,nH] = size(H);
    H1 = zeros(r,r,class(n1));
    nn = n1.^([nH-1:-1:0]');
    for i=1:r
        H1(i,:) = squeeze(H(i,:,:))*nn;
    end
    disp(H1)
    fprintf('\n')
end
fprintf(' CPU time:\n')
maxk = 20;
cput = zeros(maxk,1);
pk = zeros(maxk,1);
for k=1:maxk
    t = cputime;
    Hi = iwish_ps(k);
    cput(k) = cputime-t;
    pk(k) = size(Hi,1);
end
fprintf('  k    p_k   CPU Time (seconds)\n')
for k=1:maxk
    fprintf('%4.0f  %4.0f     %8.2f\n',k,pk(k),cput(k))  
end
diary off
