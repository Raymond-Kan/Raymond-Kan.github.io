%
%   This example shows how to compute the coefficients
%   for \tilde{Q}_k.
%
delete example6.out
diary example6.out
syms n1
alpha = 2;   % alpha = 1 for complex, alpha = 2 for real
for k=1:6
    fprintf('k = %2.0f\n',k)
    [c,den] = qkn_coeffr(k,alpha);
    disp(['\tilde{C}_' num2str(k) ' = '])
    disp('Common Denominator')
    disp(den*(n1.^[length(den):-1:1].'))
    disp('Numerator')
    [r,~,nc] = size(c);
    C1 = zeros(r,r,class(n1));
    nn = n1.^([nc-1:-1:0]');
    for i=1:r
        C1(i,:) = squeeze(c(i,:,:))*nn;
    end
    disp(C1)
    fprintf('\n')
end
fprintf(' CPU time:\n')
maxk = 20;
cput = zeros(maxk,1);
dk = zeros(maxk,1);
for k=1:maxk
    t = cputime;
    c = qkn_coeff(k,alpha);
    cput(k) = cputime-t;
    dk(k) = size(c,1);
end
fprintf('  k    d_k   CPU Time (seconds)\n')
for k=1:maxk
    fprintf('%4.0f  %4.0f     %8.2f\n',k,dk(k),cput(k))  
end
diary off
