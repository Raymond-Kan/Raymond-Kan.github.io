function S = ip_desc(n)
%
%  S = ip_desc(n)
%
%  The integer partitions of n in reverse lexicographic order, one per row,
%  padded with zeros to n columns: (n) first, (1^n) last.  For n = 0 the
%  result is the 1-by-0 matrix, the empty partition being the only one.
%
%  Adapted from "Algorithm ZS1" in ANTOINE ZOGHBI and IVAN STOJMENOVIC
%  (1998), "FAST ALGORITHMS FOR GENERATING INTEGER PARTITIONS",
%  International Journal of Computer Mathematics, Volume 70, Issue 2,
%  pages 319-332, DOI: 10.1080/00207169808804755.  ZS1 produces each
%  partition from the previous one in constant amortized time; the output
%  here is allocated once, from the partition count computed first by the
%  usual dynamic program, instead of being grown one row at a time, which
%  would copy the whole array p(n) times and cost O(p(n)^2).
%
%  Timings (one core): n = 40, 37,338 partitions, 0.022 s; n = 50, 204,226,
%  0.11 s; n = 60, 966,467, 0.54 s; n = 70, 4,087,968, 2.4 s.
%
   if ~isscalar(n) || n < 0 || n ~= fix(n)
      error('ip_desc:badInput','ip_desc: n must be a nonnegative integer');
   end
   if n == 0, S = zeros(1,0); return, end
   P = [1 zeros(1,n)];                        % P(j+1) = number of partitions of j
   for i = 1:n
       for j = i:n
           P(j+1) = P(j+1) + P(j-i+1);
       end
   end
   np = P(n+1);
   S = zeros(np,n);
   x = ones(1,n); x(1) = n; m = 1; h = 1;
   S(1,1) = n;
   for r = 2:np
       if x(h) == 2
          m = m+1; x(h) = 1; h = h-1;
       else
          t = m-h+1; v = x(h)-1; x(h) = v;
          while t >= v
             h = h+1; x(h) = v; t = t-v;
          end
          if t == 0
             m = h;
          else
             m = h+1;
             if t > 1, h = h+1; x(h) = t; end
          end
       end
       S(r,1:m) = x(1:m);
   end
end
