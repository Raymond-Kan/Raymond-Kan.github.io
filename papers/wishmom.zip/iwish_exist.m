function [ok,thr] = iwish_exist(n,m,k,alpha)
%
%  IWISH_EXIST  Existence of inverse beta-Wishart moments of degree k.
%
%  [ok,thr] = iwish_exist(n,m,k,alpha) returns ok = true if the moments
%  E[W^{-r} p_lambda(W^{-1})] with r+|lambda| = k exist for W ~ W_m^beta(n,Sigma),
%  alpha = 2/beta (default 2, real Wishart).  The condition is
%       (n-m+1)/alpha > k,   equivalently   n1 = n-m+1-alpha > (k-1)*alpha,
%  (real: n-m+1 > 2k, complex: n-m+1 > k, quaternion: n-m+1 > k/2).
%  thr is the smallest admissible value of n, i.e. the moment exists iff n > thr,
%  thr = m-1+k*alpha.
%
   if nargin<4 || isempty(alpha)
      alpha = 2;
   end
   thr = m-1+k*alpha;
   ok = n>thr;
