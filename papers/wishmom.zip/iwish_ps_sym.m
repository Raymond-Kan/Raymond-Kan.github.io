%
%   This function computes the inverse of coefficient matrices for E[p_\kappa(W^{-1})], 
%   where W ~ W_m(n,S) and |\kappa|=k.  
%   Input
%   k: |kappa|
%   alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%   n1: n-m+1-alpha (optional)
%   Output
%   h: inverse of transition matrix between E[p^{(k)}(W^{-1})] and p^{(k)}(S^{-1}), arranged 
%      in reverse lexicographical order, where p_\kappa(W^{-1}) is the power-sum 
%      symmetric function.  The output is a matrix of coefficients whose inverse is 
%      multiplied to p^(k)(S^{-1}).  When n1 is not given, h is a 3-dimensional matrix 
%      which stores the coefficients in n1^k to n1 in the last dimension.
%   This program outputs the coefficients in symbolic, so it
%   does not lose precision even for large k, but the program will
%   be slower.
%
function h = iwish_ps_sym(k,alpha,n1)
   if k==1
      if nargin==3
         h = n1;
      else
         h = sym(1);
      end
      return
   end
   if nargin<2
      alpha = 2;
   end   
   c = ones(1,1,1,'sym');     % \tilde{C}_1^{-1} = n1
   h = ones(1,1,1,'sym');     % \tilde{H}_1^{-1} = n1
   D = -dkmap(1,alpha);
   l2 = size(c,1);
   for i=1:k-1
       l1 = size(D,1);
       c1 = c;
       Da = D(:,1:l2);
       Db = D(:,l2+1:end);
       c = zeros(l1,l1,i+1);
       c(1:l2,1:l2,1:i) = c1;
       c(l2+1:end,l2+1:end,1:i) = h;
       for j=1:i
           c(:,:,j+1) = c(:,:,j+1)+[Da*c1(:,:,j) Db*h(:,:,j)];
       end
       l2 = size(c,1);
       D = -dkmap(i+1,alpha);
       D12 = D(1:l2,l2+1:end);
       D21 = D(l2+1:end,1:l2);
       lp = size(D12,2);
       h = zeros(lp,lp,i+1,'sym');
       for j=1:i+1
           h(:,:,j) = D21*c(:,:,j)*D12;
       end          
       h = h/(i+1)/alpha;
   end
   if nargin==3
      h1 = h;
      h = zeros(lp,lp,class(n1));
      nn = n1.^([k:-1:1]');
      for i=1:lp
          h(i,:) = squeeze(h1(i,:,:))*nn;
      end
   end   
