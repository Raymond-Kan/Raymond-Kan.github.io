%
%   This function computes the inverse of the coefficient matrix (i.e., \tilde{H}_k^{-1}) 
%   for E[p_\kappa(W^{-1})], where W ~ W_m(n,S) and |\kappa|=k.  
%   Input
%   k: |kappa|
%   alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%   n1: n-m+1-alpha 
%   Output
%   h: transition matrix between E[p^{(k)}(W^{-1})] and p^{(k)}(S^{-1}), arranged 
%      in reverse lexicographical order, where p_\kappa(W^{-1}) is the power-sum 
%      symmetric function.  The output is a matrix of coefficients with its inverse  
%      multipled to p^(k)(S^{-1}). 
%
function h = iwish_psn(k,alpha,n1)
   h = n1;
   if isempty(alpha)
      alpha = 2;
   end
   if k==1
      return
   end
   c = n1;      % \tilde{C}_1^{-1} = n1
   D = -dkmap(1,alpha);
   dk2 = 1;
   for i=1:k-1
       if isequal(class(n1),'sym')
          D = sym(D);
       end
       for i1=1:size(D,1)
           D(i1,i1) = D(i1,i1)+n1;
       end
       dk2 = size(c,1);
       c = [D(:,1:dk2)*c D(:,dk2+1:end)*h];
       dk2 = size(c,1);          
       D = -dkmap(i+1,alpha);
       D12 = D(1:dk2,dk2+1:end);
       D21 = D(dk2+1:end,1:dk2);
       h = (D21*c*D12)/(i+1)/alpha;
   end
   if isequal(class(n1),'sym')
      h = collect(h,n1);
   end   
