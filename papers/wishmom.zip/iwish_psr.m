%
%   This function computes the coefficient matrices for E[p_\kappa(W^{-1})], 
%   where W ~ W_m(n,S) and |\kappa|=k.  
%   Input
%   k: |kappa|
%   alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%   Output
%   H: coefficient matrices of the numerator of \tlilde{H}_k (in declining power of n1,
%      with the last matrix being the constant term), where n1 = n-m+1-alpha
%   a: coefficients of the denominator of \tilde{H}_k (in declining power of n1, with
%      the last element being the coefficient of n1)
%   Note: This program does not use the symbolic toolbox and it is much faster than
%         taking the inverse of iwish_ps_sym.m
%
function [H,a] = iwish_psr(k,alpha)
   if k==1
      H = ones(1,1,1);
      a = 1;
      return
   end
   if nargin<2
      alpha = 2;
   end   
   Hi = iwish_ps(k,alpha);
   r = size(Hi,1);
   a = denpoly(k,alpha);
   m1 = length(a)-k;
   H = zeros(r,r,m1+1);
   H(:,:,1) = eye(r);
   for i=1:m1
       H(:,:,i+1) = a(i+1)*eye(r);
       for j=1:min(k-1,i)
           H(:,:,i+1) = H(:,:,i+1)-Hi(:,:,j+1)*H(:,:,i-j+1);
       end
   end
