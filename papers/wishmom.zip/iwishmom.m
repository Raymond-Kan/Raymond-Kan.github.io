%
%   This function computes E[\prod_{j=1}^r tr(W^{-j})^{f_j}W^{-iw}],
%   where W~W_m(n,S).  
%   Input:
%   n: degrees of freedom of W
%   S: covariance matrix of W
%   f: a vector of f_j, i=1,...,r.
%   iw: power of W^{-1}
%   alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%   Output:
%   Q: E[\prod_{j=1}^r tr(W^{-j})^{f_j}W^{-iw}] 
%   Example: to obtain E[tr(W^{-1})^2*tr(W^{-3})W^{-2}] for
%   W ~ W_m(n,S), we use
%   iwishmom(n,S,[2 0 1],2,1) for complex Wishart
%   iwishmom(n,S,[2 0 1],2,2) for real Wishart
%
function Q = iwishmom(n,S,f,iw,alpha)
   if nargin<5
      alpha = 2;
      if nargin<4
         iw = 0;
      end
   end
   if isempty(iw)
      iw = 0;
   end
   m = size(S,1);
   n1 = n-m+1-alpha;
   lf = length(f);
   k1 = sum(f.*[1:lf]);
   k = k1+iw;
%
%  Check existence of moments
%
   if n1<=2*k
      if iw==0
         Q = NaN;
      else
         Q = NaN(m);
      end
      return
   end
   Si = inv(S);
%
%  Fast return for k=1
%
   if k==1
      if iw==0
         Q = trace(Si)/n1;
      else
         Q = Si/n1;
      end
      return
   end
   tS = zeros(1,k);
   S1 = Si;
   tS(1) = trace(S1);
   for i=2:k
       S1 = S1*Si;
       tS(i) = trace(S1);
   end
%
%  F(i,j) is the number of integer partitions of i with j parts or less,
%  it is also the number of integer partitions of i whose first part
%  is smaller than or equal to j.
%
   F = ones(k);
   for j=2:k
       F(:,j) = F(:,j-1);
       F(j,j) = F(j,j)+1;
       for i=j+1:k
           F(i,j) = F(i,j)+F(i-j,j);
       end
   end
   dd = cumsum([1; diag(F)]);
   if iw==0  % The output is a scalar for this case
      if k==0
         Q = m;
         return
      end
      c = inv(iwish_psn(k,alpha,n1));
      c = c(ind(f),:);
      pp = ip_desc(k);
      Q = c(1)*tS(k);
      for i=2:size(pp,1);
          pp1 = pp(i,:);
          pp1 = pp1(pp1>0);
          Q = Q+c(i)*prod(tS(pp1));
      end
   else
      c = inv(qkn_coeffn(k,alpha,n1));
      c = fliplr(c(ind(f,iw),:));
      S1 = Si;
      count = 1;
      Q = zeros(m);
      for i=1:k-1
          y = 0;
          pp = ip_desc(k-i);
          for j=size(pp,1):-1:1
              pp1 = pp(j,:);
              pp1 = pp1(pp1>0);
              y = y+c(count)*prod(tS(pp1));
              count = count+1;
          end
          Q = Q+y*S1;
          S1 = S1*Si;
      end
      Q = Q+c(count)*S1;     
   end        

function ind1 = ind(f,f1)
%
%  This function takes an integer partition f (in frequency notation) 
%  and an integer f1 as input, and returns the location of 
%  E[W^f1*prod_{i=1}^k1 tr(W^i)^{f_i}] within the list of Q_{k}.
%
   if k1==0
      ind1 = 1;
      return
   end
   ind1 = F(k1,k1);
   ss = k1;
   for jj=length(f):-1:2
       for kk=1:f(jj)
           ind1 = ind1-F(ss,jj-1);
           ss = ss-jj;
       end
   end
   if nargin>1&&f1>0
      ind1 = ind1+dd(k1);
   end
end

end
