function out = iwishmom_sym(f,iw,alpha)
%
%   IWISHMOM_SYM  Analytical expression of E[\prod_{j} tr(W^{-j})^{f_j} W^{-iw}]
%   for W ~ W_m^beta(n,Sigma), as rational functions of n1 = n-m+1-alpha
%   (no symbolic toolbox needed).
%
%   Input:
%   f:     vector of nonnegative integers f_j, j=1,...,r (f_j = power of tr(W^{-j}))
%   iw:    power of W^{-1} (default 0)
%   alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%   Output: a structure with fields
%   .k       total degree k = sum_j j f_j + iw
%   .var     'n1'   (n1 = n-m+1-alpha, written \tilde{n} in the LaTeX output)
%   .den     coefficients of the common denominator polynomial in descending
%            powers of n1 (the constant term, which is zero, is included)
%   .denpoly string of the denominator
%   When iw = 0:  E[prod_j tr(W^{-j})^{f_j}] = [sum_kappa N_kappa p_kappa(Sigma^{-1})]/den
%   .kappa   cell array of the partitions kappa of k
%   .coef    cell array; coef{i} = coefficients of the numerator N_kappa
%            (descending powers of n1, constant term included)
%   .poly    cell array of strings
%   When iw > 0:  E[prod_j tr(W^{-j})^{f_j} W^{-iw}]
%                 = [sum_i [sum_rho N_{i,rho} p_rho(Sigma^{-1})] Sigma^{-i}]/den
%   .i, .rho, .coef, .poly as in wishmom_sym.m
%   In both cases:
%   .latex   a LaTeX string of the whole expression
%   .text    a plain-text version
%   .exists  string describing the existence condition, n1 > (k-1)*alpha
%
%   The numerator and denominator polynomials are those produced by
%   iwish_psr.m / qkn_coeffr.m and denpoly.m; the denominator is the least
%   common denominator of all entries of \tilde{H}_k (resp. \tilde{C}_k), so an
%   individual coefficient may have a common factor with it.
%
   if nargin<3 || isempty(alpha)
      alpha = 2;
   end
   if nargin<2 || isempty(iw)
      iw = 0;
   end
   [row,k] = wm_index(f,iw);
   out.k = k;
   out.var = 'n1';
   if k==0
      out.den = 1; out.denpoly = '1'; out.kappa = {[]}; out.coef = {1}; out.poly = {'1'};
      out.latex = 'I_m'; out.text = 'I'; out.exists = 'always';
      return
   end
   out.exists = sprintf('n1 > %g  (n1 = n-m+1-alpha, alpha = %g)',(k-1)*alpha,alpha);
   if iw==0
      [h,a] = iwish_psr(k,alpha);        % numerator slices (descending powers), denominator a
      out.den = [a 0]; out.denpoly = wm_polystr([a 0],'n1');
      dl = wm_polystr([a 0],'\tilde{n}');
      pp = ip_desc(k);
      np = size(pp,1);
      out.kappa = cell(np,1); out.coef = cell(np,1); out.poly = cell(np,1);
      lt = ''; tx = '';
      for i=1:np
          kap = pp(i,pp(i,:)>0);
          c = squeeze(h(row,i,:)).';
          out.kappa{i} = kap; out.coef{i} = c;
          ps = wm_polystr(c,'n1'); out.poly{i} = ps;
          if ~strcmp(ps,'0')
             ks = sprintf('%d,',kap); ks = ks(1:end-1);
             lt = [lt sprintf('+(%s)p_{(%s)}(\\Sigma^{-1})',wm_polystr(c,'\tilde{n}'),ks)];
             tx = [tx sprintf('+(%s)p_(%s)(S^-1)',ps,ks)];
          end
      end
      out.latex = sprintf('[%s]/(%s)',lt(2:end),dl);
      out.text = sprintf('[%s]/(%s)',tx(2:end),out.denpoly);
   else
      [c3,a] = qkn_coeffr(k,alpha);
      out.den = [a 0]; out.denpoly = wm_polystr([a 0],'n1');
      dl = wm_polystr([a 0],'\tilde{n}');
      count = 0;
      out.i = []; out.rho = {}; out.coef = {}; out.poly = {};
      lt = ''; tx = '';
      for i=k:-1:1
          if i==k
             pp = zeros(1,0); np = 1;
          else
             pp = ip_desc(k-i); np = size(pp,1);
          end
          blt = ''; btx = ''; nterm = 0;
          for j=1:np
              count = count+1;
              if i==k
                 rho = [];
              else
                 rho = pp(j,pp(j,:)>0);
              end
              c = squeeze(c3(row,count,:)).';
              out.i(end+1,1) = i; out.rho{end+1,1} = rho; out.coef{end+1,1} = c;
              ps = wm_polystr(c,'n1'); out.poly{end+1,1} = ps;
              if ~strcmp(ps,'0')
                 nterm = nterm+1;
                 pl = wm_polystr(c,'\tilde{n}');
                 if isempty(rho)
                    blt = [blt sprintf('+(%s)',pl)];
                    btx = [btx sprintf('+(%s)',ps)];
                 else
                    rs = sprintf('%d,',rho); rs = rs(1:end-1);
                    blt = [blt sprintf('+(%s)p_{(%s)}(\\Sigma^{-1})',pl,rs)];
                    btx = [btx sprintf('+(%s)p_(%s)(S^-1)',ps,rs)];
                 end
              end
          end
          if ~isempty(blt)
             sp = sprintf('\\Sigma^{-%d}',i); st = sprintf('S^-%d',i);
             if nterm>1
                lt = [lt sprintf('+[%s]%s',blt(2:end),sp)];
                tx = [tx sprintf('+[%s]%s',btx(2:end),st)];
             else
                lt = [lt sprintf('+%s%s',blt(2:end),sp)];
                tx = [tx sprintf('+%s%s',btx(2:end),st)];
             end
          end
      end
      out.latex = sprintf('[%s]/(%s)',lt(2:end),dl);
      out.text = sprintf('[%s]/(%s)',tx(2:end),out.denpoly);
   end
