%
%   This function finds the coefficient matrices for
%   Q_k when W~W_m(n,Sigma).  With only k is given as an input
%   argument, it outputs coefficients from n^k to n.
%   When n is provided as a second input (which can be numeric
%   or symbolic), it outputs the polynomials (or value
%   of polynomials) for each coefficient.
%   This program outputs the coefficients in symbolic, so
%   it does not lose precision even for large k
%   Input
%   k: |kappa|
%   alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%   n: degrees of freedom
%   Output
%   c: coefficients of polynomials (from n^k to n) for
%      the C matrix that is multiplied to \mathcal{L}_k(S)
%      to obtain Q_k.
%
function c = qk_coeff_sym(k,alpha,n)
   if k==1
      if nargin==3
         c = n;
      else
         c = sym(1);
      end
      return
   end
   if nargin<2 || isempty(alpha)
      alpha = 2;
   end
   c = ones(1,1,1,'sym');
   h = ones(1,1,1,'sym');
   D = dkmap(1,alpha);
   l2 = size(c,1);
   for i=1:k-1
       l1 = size(D,1);
       c1 = c;
       Da = sym(D(:,1:l2));
       Db = sym(D(:,l2+1:end));
       c = zeros(l1,l1,i+1,'sym');
       c(1:l2,1:l2,1:i) = c1;
       c(l2+1:end,l2+1:end,1:i) = h;
       for j=1:i
           c(:,:,j+1) = c(:,:,j+1)+[Da*c1(:,:,j) Db*h(:,:,j)];
       end
       if i<k-1
          l2 = size(c,1);
          D = dkmap(i+1,alpha);
          D12 = D(1:l2,l2+1:end);
          D21 = D(l2+1:end,1:l2);
          lp = size(D12,2);
          h = zeros(lp,lp,i+1,'sym');
          for j=1:i+1
              h(:,:,j) = D21*c(:,:,j)*D12;
          end          
          h = h/(i+1)/alpha;
       end
   end
   if nargin==3
      c1 = c;
      c = zeros(l1,l1,'sym');
      nn = n.^([k:-1:1]');
      for i=1:l1
          c(i,:) = squeeze(c1(i,:,:))*nn;
      end
   end   
