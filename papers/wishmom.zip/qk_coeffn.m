%
%   This function finds the coefficient matrices for
%   Q_k when W~W_m(n,Sigma).  This version is faster
%   than qk_coeff when n is numeric.
%   Input
%   k: |kappa|
%   alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%   n: degrees of freedom
%   Output
%   c: C matrix that is multiplied to \mathcal{L}_k(S)
%      to obtain Q_k.
%
function c = qk_coeffn(k,alpha,n)
   c = n;
   if isempty(alpha)
      alpha = 2;
   end
   if k==1
      return
   end
   h = n;
   D = dkmap(1,alpha);
   dk2 = 1;
   for i=1:k-1
       if isequal(class(n),'sym')
          D = sym(D);
       end
       for i1=1:size(D,1)
           D(i1,i1) = D(i1,i1)+n;
       end
       c = [D(:,1:dk2)*c D(:,dk2+1:end)*h];
       if i<k-1
          dk2 = size(c,1);          
          D = dkmap(i+1,alpha);
          D12 = D(1:dk2,dk2+1:end);
          D21 = D(dk2+1:end,1:dk2);
          h = (D21*c*D12)/(i+1)/alpha;
       end
   end
   if isequal(class(n),'sym')
      c = collect(c,n);
   end
