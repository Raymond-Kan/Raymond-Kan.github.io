%
%   This function finds the inverse of the coefficient matrices for
%   \tilde{Q}_{k} when W~W_m(n,Sigma).  With only k is given as an input
%   argument, it outputs coefficients from n1^k to n1.
%   When n1 is provided as a second input (which can be numeric
%   or symbolic), it outputs the polynomials (or value
%   of polynomials) for each coefficient.
%   Input
%   k: |kappa|
%   alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%   n1: n-m+1-alpha
%   Output
%   c: coefficients of polynomials (from n1^k to n1) for the inverse 
%      of the \tilde{C}_k matrix that is multiplied to \mathcal{L}_k(S^{-1})
%      to obtain \tilde{Q}_k.
%
function c = qkn_coeff(k,alpha,n1)
   if k==1
      if nargin==3
         c = n1;
      else
         c = 1;
      end
      return
   end
   c = ones(1,1,1);     % C_1^{-1} = n1
   h = ones(1,1,1);     % H_1^{-1} = n1
   D = -dkmap(1,alpha);
   l2 = size(c,1);
   for i=1:k-1
       l1 = size(D,1);
       c1 = c;
       Da = D(:,1:l2);
       Db = D(:,l2+1:end);
       c = zeros(l1,l1,i+1);
       c(1:l2,1:l2,1:i) = c1;
       c(l2+1:end,l2+1:end,1:i) = h;
       for j=1:i
           c(:,:,j+1) = c(:,:,j+1)+[Da*c1(:,:,j) Db*h(:,:,j)];
       end
       if i<k-1
          l2 = size(c,1);
          D = -dkmap(i+1,alpha);
          D12 = D(1:l2,l2+1:end);
          D21 = D(l2+1:end,1:l2);
          h = pagemtimes(D21,c);
          h = pagemtimes(h,D12);
          h = h/(i+1)/alpha;
       end
   end
   if nargin==3
      c1 = c;
      c = zeros(l1,l1,class(n1));
      nn = n1.^([k:-1:1]');
      for i=1:l1
          c(i,:) = squeeze(c1(i,:,:))*nn;
      end
   end   
