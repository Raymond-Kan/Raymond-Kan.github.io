%
%   This function finds the inverse of the coefficient matrices for 
%   \tilde{Q}_{k} when W~W_m(n,Sigma).  This version is faster
%   than qkn_coeff when n1 is numeric.
%   Input
%   k: |kappa|
%   alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%   n1: n-m+1-alpha
%   Output
%   c: the inverse of the \tilde{C}_k matrix that is multiplied to 
%      \mathcal{L}_k(S^{-1}) to obtain \tilde{Q}_k.
%
function c = qkn_coeffn(k,alpha,n1)
   c = n1;       % initial condition for \tilde{C}_1^{-1}
   if k==1
      return
   end
   h = n1;
   D = -dkmap(1,alpha);
   dk2 = 1;
   for i=1:k-1
       if isequal(class(n1),'sym')
          D = sym(D);
       end
       for i1=1:size(D,1)
           D(i1,i1) = D(i1,i1)+n1;
       end
       c = [D(:,1:dk2)*c D(:,dk2+1:end)*h];
       if i<k-1
          dk2 = size(c,1);          
          D = -dkmap(i+1,alpha);
          D12 = D(1:dk2,dk2+1:end);
          D21 = D(dk2+1:end,1:dk2);
          h = (D21*c*D12)/(i+1)/alpha;
       end
   end
   if isequal(class(n1),'sym')
      c = collect(c,n1);
   end
