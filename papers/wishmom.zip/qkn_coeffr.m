%
%   This function finds the the coefficient matrices for
%   \tilde{Q}_{k} when W~W_m(n,Sigma).  
%   Input
%   k: order of \tilde{Q}_k
%   alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%   Output
%   C: coefficient matrices of the numerator of \tilde{C}_k (in declining power of n1,
%      with the last matrix being the constant term), where n1 = n-m+1-alpha
%   a: coefficients of the denominator of \tilde{C}_k (in declining power of n1, with
%      the last element being the coefficient of n1)
%   Note: This program does not use the symbolic toolbox and it is much faster than
%         taking the inverse of qkn_coeff_sym.m
%
function [C,a] = qkn_coeffr(k,alpha)
   if k==1
      C = ones(1,1,1);
      a = 1;
      return
   end
   if nargin<2
      alpha = 2;
   end   
   Ci = qkn_coeff(k,alpha);
   r = size(Ci,1);
   a = denpoly(k,alpha);
   m1 = length(a)-k;
   C = zeros(r,r,m1+1);
   C(:,:,1) = eye(r);
   for i=1:m1
       C(:,:,i+1) = a(i+1)*eye(r);
       for j=1:min(k-1,i)
           C(:,:,i+1) = C(:,:,i+1)-Ci(:,:,j+1)*C(:,:,i-j+1);
       end
   end
%  Verification (version 3.0): evaluate at a test point n1 and check that
%  C(n1)/den(n1) is the inverse of Ci(n1).  A warning is issued if the
%  relative residual exceeds 1e-6 (loss of precision for large k).
   n1 = (k-1)*alpha+2;
   dd = a*(n1.^(length(a):-1:1).');
   X1 = zeros(r); Y1 = zeros(r);
   for i=1:size(C,3)
       X1 = X1+C(:,:,i)*n1^(size(C,3)-i);
   end
   for i=1:k
       Y1 = Y1+Ci(:,:,i)*n1^(k+1-i);
   end
   res = norm(X1*Y1/dd-eye(r),1);
   if res>1e-6
      warning('qkn_coeffr:check','qkn_coeffr: consistency check failed at n1=%g (residual %g); results may be inaccurate for this k.',n1,res);
   end
