%
%   This function finds the the coefficient matrices for
%   \tilde{Q}_{k} when W~W_m(n,Sigma).  
%   Input
%   k: order of \tilde{Q}_k
%   alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%   Output
%   C: coefficient matrices of the numerator of \tlilde{H}_k (in declining power of n1,
%      with the last matrix being the constant term), where n1 = n-m+1-alpha
%   a: coefficients of the denominator of \tilde{C}_k (in declining power of n1, with
%      the last element being the coefficient of n1)
%   Note: This program does not use the symbolic toolbox and it is much faster than
%         taking the inverse of qkn_coeff_sym.m
%
function [C,a] = qkn_coeffr(k,alpha)
   if k==1
      C = ones(1,1,1);
      a = 1;
      return
   end
   if nargin<2
      alpha = 2;
   end   
   Ci = qkn_coeff(k,alpha);
   r = size(Ci,1);
   a = denpoly(k,alpha);
   m1 = length(a)-k;
   C = zeros(r,r,m1+1);
   C(:,:,1) = eye(r);
   for i=1:m1
       C(:,:,i+1) = a(i+1)*eye(r);
       for j=1:min(k-1,i)
           C(:,:,i+1) = C(:,:,i+1)-Ci(:,:,j+1)*C(:,:,i-j+1);
       end
   end
