These are programs for my SJS paper "On the Expectations of Equivariant 
Matrix-valued Functions of Wishart and Inverse Wishart Matrices"
(with Grant Hillier).  If you have questions, comments, or bug reports, 
please send them to Raymond.Kan@rotman.utoronto.ca

Raymond Kan
Rotman School of Management
University of Toronto

Version 1.0: 4/30/2022, initial release.
Version 1.1: 6/30/2024, update iwishmom.m to check non-existence of moments.
Version 1.2: 8/16/2024, introduce denpoly.m to compute the coefficients of
             the denominator polynomial of \tilde{H}_k and \tilde{C}_k.
Version 2.0: 8/18/2024, introduce dkimapr.m, iwish_psr.m, and qkn_coeffr.m.
             These programs allow us to compute the numerator and denominator
             polynomials of \tilde{D}_k, \tilde{H}_k, and \tilde{C}_k without
             using symbolic toolbox. example4.m to example6.m are updated to
             use the new programs.
Version 2.1: 8/28/2024, rewrite dkimapr.m to make use denpoly.m.  The resulting
             expressions for the numerator and denominator polynomials of 
             \tilde{D}_k are shortened as a result.
Version 2.2: 9/13/2023, fixed an error in the algorithm of dkimapr.m
Version 2.3: 9/14/2023, improve the algorithm of dkimapr.m

Moments of Wishart
dkmap.m: creates D_k, but without the n on the diagonal
qk_coeff.m: program to compute coefficients for \mathcal{C}_k.
qk_coeffn.m: program to compute coefficients for \mathcal{C}_k using
             double precision when n is numeric.
qk_coeff_sym.m: program to compute coefficients for \mathcal{C}_k
                symbolically.  
wish_ps.m: program to compute coefficients of \mathcal{H}_k
wish_psn.m: program to compute coefficients of \mathcal{H}_k using
            double precision when n is numeric.
wish_ps_sym.m: program to compute coefficients of \mathcal{H}_k
               symbolically.              
wishmom.m: Computes E[\prod_{j=1}^r tr(W^j)^{f_j}*W^{iw}] using an 
           analytical formula.
wishmom_rec.m: Computes E[\prod_{j=1}^r tr(W^j)^{f_j}*W^{iw}] using a 
               recursive algorithm.  Note that this is for demonstration 
               purpose, and it is very slow when \sum_{j=1}^r j*f_j+iw 
               is large.  Users are advised to use wishmom.m instead.
example1.m: a program that shows how to compute D_k using dkmap.m
example2.m: a program that shows how to compute \mathcal{H}_k using wish_ps.m
example3.m: a program that shows how to compute \mathcal{C}_k using qk_coeff.m

Moments of inverse Wishart
denpoly.m: compute the denominator polynomial for \tilde{H}_k and \tilde{C}_k
dkimap.m: creates \tilde{D}_k
dkimapr.m: creates coefficients of the numerator and denominator polynomials 
           of \tilde{D}_k without using symbolic toolbox
qkn_coeff.m: program to compute coefficients for \tilde{C}_k^{-1}.
qkn_coeffn.m: program to compute coefficients for \tilde{C}_k^{-1} 
              using double precision when n is numeric.
qkn_coeffr.m: program to compute coefficients for the numerator and 
              denominator polynomials of \tilde{C}_k without using
              symbolic toolbox. 
qkn_coeff_sym.m: program to compute coefficients for \tilde{C}_k^{-1}
                 symbolically.  
iwish_ps.m: program to compute coefficients of \tilde{H}_k^{-1}
iwish_psn.m: program to compute coefficients of \tilde{H}_k using
             double precision when n1 is numeric.
iwish_psr.m: program to compute coefficients for the numerator and 
             denominator polynomials of \tilde{H}_k without using
             symbolic toolbox. 
iwish_ps_sym.m: program to compute coefficients of \tilde{H}_k
                symbolically.              
iwishmom.m: Computes E[\prod_{j=1}^r tr(W^{-j})^{f_j}*W^{-iw}] using an
            analytical formula.
example4.m: a program that shows how to compute \tilde{D}_k using dkimapr.m
example5.m: a program that shows how to compute \tilde{H}_k^{-1} using iwish_psr.m
example6.m: a program that shows how to compute \tilde{C}_k^{-1} using qkn_coeffr.m

               
Auxiliary programs:
ip_desc.m: Create integer partitions for an integer k, sorted in reverse 
           lexicographical order

               