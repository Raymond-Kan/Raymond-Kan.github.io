%
%  This Matlab function computes the distinct eigenvalues of D_{-k}.
%  The distinct eigenvalues of D_{-k} are obtained by adding n1 to the
%  output vector.
%
%  The output is y = i-alpha*j over the (zero-based) cells (i,j) that can be
%  added to some partition of k, i.e., over {(i,j): (i+1)*(j+1) <= k+1}
%  EXCLUDING (i,j) = (0,0).  The cell (0,0) is addable only to the empty
%  diagram, so 0 is not an eigenvalue of D_{-k}-n1*I for k >= 1 unless some
%  other addable cell happens to have alpha-content 0 (e.g. (2,1) when
%  alpha = 2 and k >= 5).  Including (0,0) would put a spurious factor of n1
%  in the denominator of \tilde{D}_k.  See HK26, Theorem 5.11.
%
function y = unid(k,a)
   if nargin<2
      syms a
   end
   y = [(-k:-1)*a 1:k].'; % This is for \kappa = (k+1) and (1^{k+1})
   for j=1:floor((k-1)/2)
       maxj = floor((k+1)/(j+1))-1;
       for j1=1:maxj
           a1 = j-a*j1;
           if all(y~=a1)
              y = [y; a1];
           end
       end
   end
   if isnumeric(a)
      y = uniquetol(y,1e-10);
   end

  
