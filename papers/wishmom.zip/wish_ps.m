%
%   This function computes the coefficient matrices for E[p_\kappa(W)], 
%   where W ~ W_m(n,S) and |\kappa|=k.  
%   Input
%   k: |kappa|
%   alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%   n: degrees of freedom (optional)
%   Output
%   h: transition matrix between E[p^{(k)}(W)] and p^{(k)}(S), arranged 
%      in reverse lexicographical order, where p_\kappa(W) is the power-sum 
%      symmetric function.  The output is a matrix of coefficients that is 
%      multiplied to p^(k)(S).  When n is not given, h is a 3-dimensional matrix 
%      which stores the coefficients in n^k to n in the last dimension.
%
function h = wish_ps(k,alpha,n)
   if k==1
      if nargin==3
         h = n;
      else
         h = 1;
      end
      return
   end
   if nargin<2
      alpha = 2;
   end
   c = ones(1,1,1);     % C_1 = n
   h = ones(1,1,1);     % H_1 = n
   D = dkmap(1,alpha);
   l2 = size(c,1);
   for i=1:k-1
       l1 = size(D,1);
       c1 = c;
       Da = D(:,1:l2);
       Db = D(:,l2+1:end);
       c = zeros(l1,l1,i+1);
       c(1:l2,1:l2,1:i) = c1;
       c(l2+1:end,l2+1:end,1:i) = h;
       for j=1:i
           c(:,:,j+1) = c(:,:,j+1)+[Da*c1(:,:,j) Db*h(:,:,j)];
       end
       l2 = size(c,1);
       D = dkmap(i+1,alpha);
       D12 = D(1:l2,l2+1:end);
       D21 = D(l2+1:end,1:l2);
       h = pagemtimes(D21,c);
       h = pagemtimes(h,D12);
       h = h/(i+1)/alpha;
   end
   if nargin==3
      h1 = h;
      lp = size(h1,1);
      h = zeros(lp,lp,class(n));
      nn = n.^([k:-1:1]');
      for i=1:lp
          h(i,:) = squeeze(h1(i,:,:))*nn;
      end
   end   
