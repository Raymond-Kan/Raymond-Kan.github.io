%
%   This function computes the coefficient matrices for E[p_\kappa(W)], 
%   where W ~ W_m(n,S) and |\kappa|=k.  
%   Input
%   k: |kappa|
%   alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%   n: degrees of freedom
%   Output
%   h: transition matrix between E[p^{(k)}(W)] and p^{(k)}(S), arranged 
%      in reverse lexicographical order, where p_\kappa(W) is the power-sum 
%      symmetric function.  
%
function h = wish_psn(k,alpha,n)
   h = n;
   if isempty(alpha)
      alpha = 2;
   end
   if k==1
      return
   end
   c = n;
   D = dkmap(1,alpha);
   dk2 = 1;
   for i=1:k-1
       if isequal(class(n),'sym')
          D = sym(D);
       end
       for i1=1:size(D,1)
           D(i1,i1) = D(i1,i1)+n;
       end
       c = [D(:,1:dk2)*c D(:,dk2+1:end)*h];
       D = dkmap(i+1,alpha);
       dk2 = size(c,1);
       D12 = D(1:dk2,dk2+1:end);
       D21 = D(dk2+1:end,1:dk2);
       h = (D21*c*D12)/(i+1)/alpha;
   end
   if isequal(class(n),'sym')
      h = collect(h,n);
   end   
