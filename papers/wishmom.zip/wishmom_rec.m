%
%   This function computes E[\prod_{j=1}^r tr(W^j)^{f_j}W^{iw}],
%   where W~W_m(n,S).  
%   Input:
%   n: degrees of freedom of W
%   S: covariance matrix of W
%   f: a vector of f_j, i=1,...,r.
%   iw: power of W
%   alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%   Output:
%   Q: E[\prod_{j=1}^r tr(W^j)^{f_j}W^{iw}] 
%   Note: This program uses a recursive algorithm, and it can
%         be quite slow when \sum_{j=1}j*f_j+iw is large.
%         Version 3.0: the recursion now uses the general-alpha
%         coefficient n+(alpha-1)r (earlier versions were only
%         correct for alpha = 1 and 2).
%
function Q = wishmom_rec(n,S,f,iw,alpha)
   if nargin<5
      alpha = 2;
      if nargin<4
         iw = 0;
      end
   end
   if isempty(iw)
      iw = 0;
   end
   a1 = alpha-1;    % coefficient of r in n+(alpha-1)r (real: r, complex: 0, quaternion: -r/2)
   lf = find(f,1,'last');
   f = f(1:lf);
   lf = length(f);
   if lf==0
      if iw==1
         Q = n*S;
      else
         Q = (n+a1*(iw-1))*S*wishmom_rec(n,S,0,iw-1,alpha);
         for j=1:iw-2
             Q = Q+S*wishmom_rec(n,S,[zeros(1,j-1) 1],iw-1-j,alpha);
         end
         Q = Q+wishmom_rec(n,S,[zeros(1,iw-2) 1],0,alpha)*S;
      end
      return
   end
   s = min(find(f>0));
   if iw==0  % The output is a scalar for this case
%     Fast recurrence for the case of E[tr(W)^f]   
      if lf==1
         tS = zeros(f,1);
         for i=1:f
             tS(i) = n*alpha^(i-1)*trace(S^i);
         end
         y = zeros(f,1);
         y(1) = tS(1);
         for i=2:f
             c = factorial(i-1);
             y(i) = tS(i)*c;
             for j=1:i-1
                 c = c/j;
                 y(i) = y(i)+c*tS(i-j)*y(j);
             end
         end
         Q = y(f);
         return
      end
      fa = f;
      fa(s) = fa(s)-1;
      if s==1
         Q = n*trace(S)*wishmom_rec(n,S,fa,0,alpha);
         for r=s:lf
             if fa(r)>0
                f2 = fa;
                f2(r) = f2(r)-1;
                Q = Q+alpha*r*fa(r)*trace(S*wishmom_rec(n,S,f2,r,alpha));
             end
         end
      else
         Q = (n+a1*(s-1))*trace(S*wishmom_rec(n,S,fa,s-1,alpha));
         for r=s:lf
             if fa(r)>0
                f2 = fa;
                f2(r) = f2(r)-1;
                Q = Q+alpha*r*fa(r)*trace(S*wishmom_rec(n,S,f2,s+r-1,alpha));
             end
         end
         for r=1:s-1
             f2 = fa;
             if r>lf
                f2 = [f2 zeros(1,r-1-lf) 1];
             else
                f2(r) = f2(r)+1;
             end
             Q = Q+trace(S*wishmom_rec(n,S,f2,s-1-r,alpha));
         end
      end
   else
      Q = (n+a1*(iw-1))*S*wishmom_rec(n,S,f,iw-1,alpha);
      for r=s:lf
          if f(r)>0
             f2 = f;
             f2(r) = f2(r)-1;
             Q = Q+alpha*r*f(r)*S*wishmom_rec(n,S,f2,iw+r-1,alpha);
          end
      end
      for r=1:iw-1
          f2 = f;
          if r>lf
             f2 = [f2 zeros(1,r-1-lf) 1];
          else
             f2(r) = f2(r)+1;
          end
          Q = Q+S*wishmom_rec(n,S,f2,iw-1-r,alpha);
      end
   end
