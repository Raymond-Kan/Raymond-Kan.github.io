function out = wishmom_sym(f,iw,alpha)
%
%   WISHMOM_SYM  Analytical expression of E[\prod_{j} tr(W^j)^{f_j} W^{iw}]
%   for W ~ W_m^beta(n,Sigma), as polynomials in n (no symbolic toolbox needed).
%
%   Input:
%   f:     vector of nonnegative integers f_j, j=1,...,r (f_j = power of tr(W^j))
%   iw:    power of W (default 0)
%   alpha: 1/2: quaternion Wishart, 1: complex Wishart, 2: real Wishart (default)
%   Output: a structure with fields
%   .k       total degree k = sum_j j f_j + iw
%   .var     'n'
%   When iw = 0:  E[prod_j tr(W^j)^{f_j}] = sum_{kappa |- k} h_kappa p_kappa(Sigma)
%   .kappa   cell array of the partitions kappa of k (reverse lexicographic order)
%   .coef    cell array; coef{i} = coefficients of h_kappa in descending powers of n
%            (from n^k down to the constant term)
%   .poly    cell array of strings, e.g. '32n'
%   When iw > 0:  E[prod_j tr(W^j)^{f_j} W^{iw}]
%                 = sum_{i=1}^k [sum_{rho |- k-i} c_{i,rho} p_rho(Sigma)] Sigma^i
%   .i       vector of the powers i of Sigma for each term
%   .rho     cell array of the partitions rho |- k-i (rho = [] for i = k)
%   .coef    cell array of coefficient vectors of c_{i,rho} (descending powers of n)
%   .poly    cell array of strings
%   In both cases:
%   .latex   a LaTeX string of the whole expression
%   .text    a plain-text version of the same expression
%
%   Example: wishmom_sym([1 1],1) gives E[tr(W)tr(W^2)W] for the real Wishart;
%            writeLines(wishmom_sym(4,0,1).latex) gives E[tr(W)^4] for the complex case.
%   Coefficients are computed in double precision with the recurrence of
%   Hillier and Kan (2024) (qk_coeff.m / wish_ps.m); they are exact integers
%   for moderate k (see readme.txt).
%
   if nargin<3 || isempty(alpha)
      alpha = 2;
   end
   if nargin<2 || isempty(iw)
      iw = 0;
   end
   [row,k] = wm_index(f,iw);
   out.k = k;
   out.var = 'n';
   if k==0
      out.kappa = {[]}; out.coef = {1}; out.poly = {'1'};
      out.latex = 'I_m'; out.text = 'I';
      return
   end
   if iw==0
      h = wish_ps(k,alpha);             % pi(k) x pi(k) x k, powers n^k ... n^1
      pp = ip_desc(k);
      np = size(pp,1);
      out.kappa = cell(np,1); out.coef = cell(np,1); out.poly = cell(np,1);
      lt = ''; tx = '';
      for i=1:np
          kap = pp(i,pp(i,:)>0);
          c = [squeeze(h(row,i,:)).' 0];      % append zero constant term
          out.kappa{i} = kap; out.coef{i} = c;
          ps = wm_polystr(c,'n');
          out.poly{i} = ps;
          if ~strcmp(ps,'0')
             ks = sprintf('%d,',kap); ks = ks(1:end-1);
             lt = [lt sprintf('+(%s)p_{(%s)}(\\Sigma)',ps,ks)];
             tx = [tx sprintf('+(%s)p_(%s)(S)',ps,ks)];
          end
      end
      out.latex = lt(2:end); out.text = tx(2:end);
   else
      c3 = qk_coeff(k,alpha);            % d_k x d_k x k, powers n^k ... n^1
      count = 0;
      out.i = []; out.rho = {}; out.coef = {}; out.poly = {};
      lt = ''; tx = '';
      for i=k:-1:1                      % blocks of L_k(Sigma): Sigma^i, rho |- k-i
          if i==k
             pp = zeros(1,0); np = 1;
          else
             pp = ip_desc(k-i); np = size(pp,1);
          end
          blt = ''; btx = ''; nterm = 0;
          for j=1:np
              count = count+1;
              if i==k
                 rho = [];
              else
                 rho = pp(j,pp(j,:)>0);
              end
              c = [squeeze(c3(row,count,:)).' 0];
              out.i(end+1,1) = i; out.rho{end+1,1} = rho; out.coef{end+1,1} = c;
              ps = wm_polystr(c,'n');
              out.poly{end+1,1} = ps;
              if ~strcmp(ps,'0')
                 nterm = nterm+1;
                 if isempty(rho)
                    blt = [blt sprintf('+(%s)',ps)];
                    btx = [btx sprintf('+(%s)',ps)];
                 else
                    rs = sprintf('%d,',rho); rs = rs(1:end-1);
                    blt = [blt sprintf('+(%s)p_{(%s)}(\\Sigma)',ps,rs)];
                    btx = [btx sprintf('+(%s)p_(%s)(S)',ps,rs)];
                 end
              end
          end
          if ~isempty(blt)
             if i==1
                sp = '\Sigma'; st = 'S';
             else
                sp = sprintf('\\Sigma^{%d}',i); st = sprintf('S^%d',i);
             end
             if nterm>1
                lt = [lt sprintf('+[%s]%s',blt(2:end),sp)];
                tx = [tx sprintf('+[%s]%s',btx(2:end),st)];
             else
                lt = [lt sprintf('+%s%s',blt(2:end),sp)];
                tx = [tx sprintf('+%s%s',btx(2:end),st)];
             end
          end
      end
      out.latex = lt(2:end); out.text = tx(2:end);
   end
