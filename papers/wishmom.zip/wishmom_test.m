%
%   WISHMOM_TEST  Consistency checks for the wishmom programs (version 3.0).
%
%   Run this script from the folder containing the programs.  It performs
%   the following checks and prints the largest relative discrepancy of each:
%    1. wishmom.m (explicit formula) against wishmom_rec.m (recurrence),
%       for alpha = 2, 1, 1/2 and a non-classical alpha;
%    2. the rational-polynomial routines (qkn_coeffr, iwish_psr, dkimapr)
%       against the double-precision routines (qkn_coeffn, iwish_psn, dkimap);
%    3. wishmom_sym / iwishmom_sym against wishmom / iwishmom;
%    4. the commutation D_k*diag(C_k,H_k) = diag(C_k,H_k)*D_k (Corollary 5.3
%       of the companion note), which justifies the update (82) of the paper;
%    5. the reversibility of D_k-n*I for the weights 1/(alpha^l(lam)*z_lam)
%       (Proposition 5.6 of the companion note), the agreement of its spectrum
%       with the root list of unid.m, and the row-sum identities of D_k, C_k,
%       D_{-k}, \tilde{C}_k;
%    6. the unbiased estimators (63)-(64) and (84)-(85) of the paper by
%       Monte Carlo (real Wishart) and a complex Monte Carlo check of
%       E[W^2 tr(W)] and E[W^{-1}tr(W^{-1})];
%    7. the existence test of iwishmom.m.
%   Checks 1-5 should give discrepancies of order 1e-12 or smaller; the
%   Monte Carlo checks 6 use 200,000 draws and should agree to about 1%.
%
fprintf('wishmom version 3.0: consistency checks\n');
fprintf('----------------------------------------\n');
S = [2 .5 .1; .5 1.5 .3; .1 .3 1];
m = size(S,1);
%
%  1. wishmom vs wishmom_rec
%
n = 7.5;
flist = {[2 0 1],[1 1],[0 2],3,[0 0 1],[1 0 0 1]};
for alpha=[2 1 0.5 0.37]
    e = 0;
    for i=1:length(flist)
        for iw=0:2
            q1 = wishmom(n,S,flist{i},iw,alpha);
            q2 = wishmom_rec(n,S,flist{i},iw,alpha);
            e = max(e,max(abs(q1(:)-q2(:)))/max(abs(q1(:))));
        end
    end
    fprintf('1. wishmom vs wishmom_rec, alpha = %-4g: %.1e\n',alpha,e);
end
%
%  2. rational-polynomial routines vs double-precision routines
%
n1 = 17.3;
for alpha=[2 1 0.5]
    e = zeros(1,3);
    for k=2:6
        [Ct,den] = qkn_coeffr(k,alpha);  Ci = qkn_coeffn(k,alpha,n1);
        d = den*(n1.^(length(den):-1:1).');
        r = size(Ci,1); X = zeros(r); nn = n1.^(size(Ct,3)-1:-1:0).';
        for i=1:r, X(i,:) = squeeze(Ct(i,:,:))*nn; end
        e(1) = max(e(1),norm(X/d*Ci-eye(r),1));
        [Ht,den] = iwish_psr(k,alpha);  Hi = iwish_psn(k,alpha,n1);
        d = den*(n1.^(length(den):-1:1).');
        r = size(Hi,1); X = zeros(r); nn = n1.^(size(Ht,3)-1:-1:0).';
        for i=1:r, X(i,:) = squeeze(Ht(i,:,:))*nn; end
        e(2) = max(e(2),norm(X/d*Hi-eye(r),1));
        [Dn,den] = dkimapr(k,alpha);  Dm = n1*eye(size(Dn,1))-dkmap(k,alpha);
        d = den*(n1.^(length(den)-1:-1:0).');
        r = size(Dm,1); X = zeros(r); nn = n1.^(size(Dn,3)-1:-1:0).';
        for i=1:r, X(i,:) = squeeze(Dn(i,:,:))*nn; end
        e(3) = max(e(3),norm(X/d*Dm-eye(r),1));
    end
    fprintf('2. qkn_coeffr/iwish_psr/dkimapr vs qkn_coeffn/iwish_psn/inv(D_{-k}), alpha = %-4g: %.1e %.1e %.1e\n',alpha,e);
end
%
%  3. wishmom_sym / iwishmom_sym vs wishmom / iwishmom
%
n = 20; Si = inv(S);
for alpha=[2 1 0.5]
    n1 = n-m+1-alpha;
    o = wishmom_sym([1 0 1],2,alpha); Q = zeros(m);
    for t=1:numel(o.i)
        pr = 1; for j=o.rho{t}, pr = pr*trace(S^j); end
        Q = Q+polyval(o.coef{t},n)*pr*S^o.i(t);
    end
    Q2 = wishmom(n,S,[1 0 1],2,alpha);
    e1 = max(abs(Q(:)-Q2(:)))/max(abs(Q2(:)));
    o = iwishmom_sym([1 0 1],2,alpha); Q = zeros(m);
    for t=1:numel(o.i)
        pr = 1; for j=o.rho{t}, pr = pr*trace(Si^j); end
        Q = Q+polyval(o.coef{t},n1)/polyval(o.den,n1)*pr*Si^o.i(t);
    end
    Q2 = iwishmom(n,S,[1 0 1],2,alpha);
    e2 = max(abs(Q(:)-Q2(:)))/max(abs(Q2(:)));
    o = wishmom_sym([2 1],0,alpha); v = 0;
    for t=1:numel(o.kappa)
        pr = 1; for j=o.kappa{t}, pr = pr*trace(S^j); end
        v = v+polyval(o.coef{t},n)*pr;
    end
    e3 = abs(v-wishmom(n,S,[2 1],0,alpha))/abs(v);
    o = iwishmom_sym([2 1],0,alpha); v = 0;
    for t=1:numel(o.kappa)
        pr = 1; for j=o.kappa{t}, pr = pr*trace(Si^j); end
        v = v+polyval(o.coef{t},n1)/polyval(o.den,n1)*pr;
    end
    e4 = abs(v-iwishmom(n,S,[2 1],0,alpha))/abs(v);
    fprintf('3. wishmom_sym/iwishmom_sym vs wishmom/iwishmom, alpha = %-4g: %.1e %.1e %.1e %.1e\n',alpha,e1,e2,e3,e4);
end
%
%  4. commutation of D_k with diag(C_k,H_k) and of D_{-k} with diag(Ct_k^{-1},Ht_k^{-1})
%
n = 9.3; n1 = 11.7;
for alpha=[2 1 0.5 0.37]
    e = 0;
    for k=1:6
        D = dkmap(k,alpha)+n*eye(size(dkmap(k,alpha),1));
        B = blkdiag(qk_coeffn(k,alpha,n),wish_psn(k,alpha,n));
        e = max(e,norm(D*B-B*D,1)/norm(D*B,1));
        Dm = n1*eye(size(D,1))-dkmap(k,alpha);
        B = blkdiag(qkn_coeffn(k,alpha,n1),iwish_psn(k,alpha,n1));
        e = max(e,norm(Dm*B-B*Dm,1)/norm(Dm*B,1));
    end
    fprintf('4. commutation D_k diag(C_k,H_k) = diag(C_k,H_k) D_k, alpha = %-4g: %.1e\n',alpha,e);
end
%
%  5. row sums, reversibility, and the eigenvalues of D_k-n*I
%
for alpha=[2 1 0.5 0.37]
    er = 0; ev = 0;
    for k=1:6
        M = dkmap(k,alpha);
        w = wm_weights(k,alpha);            % 1./(alpha^length(lam)*z_lam)
        er = max(er,norm(diag(w)*M-M.'*diag(w),1)/norm(diag(w)*M,1));
        y = sort(unid(k,alpha));            % eigenvalues of D_{-k} minus n1
        d = sort(real(eig(M)));             % eigenvalues of D_k-n*I (real, see above)
        ev = max(ev,max(abs(uniquetol(d,1e-9)-sort(-y))));
    end
    fprintf('5a. reversibility of D_k-n*I and spec vs unid, alpha = %-4g: %.1e %.1e\n',alpha,er,ev);
end
for alpha=[2 1 0.5 0.37]
    e = 0;
    for k=1:6
        D = dkmap(k,alpha)+n*eye(size(dkmap(k,alpha),1));
        e = max(e,max(abs(sum(D,2)-(n+k*alpha)))/(n+k*alpha));
        C = qk_coeffn(k,alpha,n);
        e = max(e,max(abs(sum(C,2)-alpha^k*prod(n/alpha+(0:k-1))))/(alpha^k*prod(n/alpha+(0:k-1))));
        Dm = n1*eye(size(D,1))-dkmap(k,alpha);
        e = max(e,max(abs(sum(Dm,2)-(n1-k*alpha)))/abs(n1-k*alpha));
        Ct = inv(qkn_coeffn(k,alpha,n1));
        e = max(e,max(abs(sum(Ct,2)*prod(n1-alpha*(0:k-1))-1)));
    end
    fprintf('5b. row sums of D_k, C_k, D_{-k}, Ct_k, alpha = %-4g: %.1e\n',alpha,e);
end
%
%  6. Monte Carlo checks
%
rng(1);
N = 200000; n = 12; m = size(S,1);
L = chol(S,'lower');
A2 = zeros(m); A3 = zeros(m); B2 = zeros(m); B3 = zeros(m);
for i=1:N
    X = L*randn(m,n); W = X*X'; Wi = inv(W);
    A2 = A2+W*W; A3 = A3+W*trace(W);
    B2 = B2+Wi*Wi; B3 = B3+Wi*trace(Wi);
end
A2 = A2/N; A3 = A3/N; B2 = B2/N; B3 = B3/N;
n1 = n-m-1;
est1 = (n*A2-A3)/(n*(n^2+n-2));                 % (63): unbiased for S^2
est2 = ((n+1)*A3-2*A2)/(n*(n^2+n-2));           % (64): unbiased for tr(S)S
est3 = n1*(n1-1)*B2-n1*B3;                      % (84): unbiased for S^{-2}
est4 = n1^2*B3-2*n1*B2;                         % (85): unbiased for tr(S^{-1})S^{-1}
fprintf('6. Monte Carlo (real, N=%d): (63) %.3f  (64) %.3f  (84) %.3f  (85) %.3f  (relative errors)\n',N,...
    norm(est1-S^2)/norm(S^2),norm(est2-trace(S)*S)/norm(trace(S)*S),...
    norm(est3-Si^2)/norm(Si^2),norm(est4-trace(Si)*Si)/norm(trace(Si)*Si));
% complex Wishart, E[W^2 tr(W)] and E[W^{-1} tr(W^{-1})]
Sc = [2 .5+.2i .1; .5-.2i 1.5 .3i; .1 -.3i 1];
Lc = chol(Sc,'lower');
A = zeros(m); B = zeros(m);
for i=1:N
    X = Lc*(randn(m,n)+1i*randn(m,n))/sqrt(2); W = X*X'; Wi = inv(W);
    A = A+W*W*trace(W); B = B+Wi*trace(Wi);
end
A = A/N; B = B/N;
fprintf('   Monte Carlo (complex): E[W^2 tr(W)] %.3f   E[W^{-1}tr(W^{-1})] %.3f  (relative errors)\n',...
    norm(A-wishmom(n,Sc,1,2,1))/norm(A), norm(B-iwishmom(n,Sc,1,1,1))/norm(B));
%
%  7. existence test
%
ok = isnan(iwishmom(4,S(1:2,1:2),2)) & ~isnan(iwishmom(4,S(1:2,1:2),1)) ...   % real, m=2: k=2 needs n>5, k=1 needs n>3
   & isnan(iwishmom(3,S(1:2,1:2),1)) & ~isnan(iwishmom(3.5,S(1:2,1:2),[0 1],0,1)) ... % complex: k=2 needs n>3
   & isnan(iwishmom(3,S(1:2,1:2),[0 1],0,1)) & iwish_exist(4,2,1,2) & ~iwish_exist(3,2,1,2);
if ok
    fprintf('7. existence test of iwishmom: OK\n');
else
    fprintf('7. existence test of iwishmom: FAILED\n');
end
