function [ind1,k] = wm_index(f,iw)
%
%  WM_INDEX  Position of a generator inside the stacked vectors of the paper.
%
%  [ind1,k] = wm_index(f,iw) returns the row index of
%     E[W^iw * prod_j tr(W^j)^{f_j}]   within  Q_k = E[L_k(W)]   (if iw > 0), or of
%     E[prod_j tr(W^j)^{f_j}]          within  q_k = E[p^{(k)}(W)] (if iw = 0),
%  where k = sum_j j*f_j + iw, f is the frequency vector of the partition
%  (f_j = multiplicity of the part j), and the blocks of L_k(W) are ordered as
%  in eq. (5) of Hillier and Kan (2024): W^k, then p^{(1)}(W) (x) W^{k-1}, ...,
%  p^{(k-1)}(W) (x) W, with the partitions of each degree in reverse
%  lexicographic order (the order produced by ip_desc.m).  The same index
%  applies to W^{-1} (i.e., to \tilde{Q}_k and \tilde{q}_k).
%
%  Example: wm_index([2 0 1],2) is the position of E[tr(W)^2 tr(W^3) W^2] in Q_7.
%
   if nargin<2 || isempty(iw)
      iw = 0;
   end
   f = f(:).';
   lf = length(f);
   k1 = sum(f.*(1:lf));
   k = k1+iw;
   if k1==0
      ind1 = 1;      % the block W^k (or the empty partition)
      return
   end
%  F(i,j) = number of partitions of i with parts <= j
   F = ones(k1);
   for j=2:k1
       F(:,j) = F(:,j-1);
       F(j,j) = F(j,j)+1;
       for i=j+1:k1
           F(i,j) = F(i,j)+F(i-j,j);
       end
   end
%  position of the partition among the partitions of k1 (reverse lex order)
   ind1 = F(k1,k1);
   ss = k1;
   for jj=lf:-1:2
       for kk=1:f(jj)
           ind1 = ind1-F(ss,jj-1);
           ss = ss-jj;
       end
   end
   if iw>0
%     add the number of blocks of L_k with a higher power of W: sum_{i=0}^{k1-1} pi(i)
      ind1 = ind1+1+sum(diag(F(1:k1-1,1:k1-1)));
   end
