function s = wm_polystr(c,v,tol)
%
%  WM_POLYSTR  String representation of a polynomial.
%
%  s = wm_polystr(c,v) returns a string for the polynomial whose coefficients
%  in descending powers are given by the vector c (c(1) is the coefficient
%  of the highest power, c(end) the constant term), written in the variable
%  v (a string, e.g. 'n' or '\tilde{n}').  Coefficients that are integers
%  (up to a tolerance) are printed as integers; otherwise they are printed
%  with %.10g.  Zero coefficients are omitted.  The zero polynomial is
%  returned as '0'.
%
%  Example: wm_polystr([1 3 0 4],'n') returns 'n^3+3n^2+4n'.
%
   if nargin<2 || isempty(v)
      v = 'n';
   end
   if nargin<3
      tol = 1e-9;
   end
   c = c(:).';
   L = length(c);
   s = '';
   for i=1:L
       p = L-i;             % power of v
       a = c(i);
       if abs(a)<=tol
          continue
       end
       if abs(a-round(a))<=tol*max(1,abs(a))
          a = round(a);
          if p==0
             cs = sprintf('%d',a);
          elseif a==1
             cs = '';
          elseif a==-1
             cs = '-';
          else
             cs = sprintf('%d',a);
          end
       else
          cs = sprintf('%.10g',a);
       end
       if p==0
          term = cs;
       elseif p==1
          term = [cs v];
       else
          term = sprintf('%s%s^%d',cs,v,p);
       end
       if isempty(s)
          s = term;
       elseif a>0
          s = [s '+' term];
       else
          s = [s term];
       end
   end
   if isempty(s)
      s = '0';
   end
