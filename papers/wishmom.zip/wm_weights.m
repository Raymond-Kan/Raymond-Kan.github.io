%
%   WM_WEIGHTS  Reversibility weights for the mapping matrix D_k.
%
%   w = wm_weights(k,alpha) returns the vector w with
%
%       w(r,lambda) = 1/(alpha^length(lambda)*z_lambda),
%       z_lambda    = prod_v v^mu_v(lambda)*mu_v(lambda)!,
%
%   indexed in the same order as the rows of dkmap(k,alpha), i.e. by the
%   degree-k generators W^r*p_lambda(W) with r = k,k-1,...,1 followed by the
%   pure power sums p_lambda(W), |lambda| = k.  With M = dkmap(k,alpha) one
%   has diag(w)*M = M'*diag(w) (detailed balance), so M is similar to a
%   symmetric matrix; see Proposition 5.6 of Hillier and Kan (2026).
%   alpha^length(lambda)*z_lambda is the squared norm of p_lambda in the
%   Jack inner product.
%
function w = wm_weights(k,alpha)
   if nargin<2
      alpha = 2;
   end
   w = 1;                              % r = k, lambda = empty
   for r=k-1:-1:0
       pp = ip_desc(k-r);
       for i=1:size(pp,1)
           lam = pp(i,:); lam = lam(lam>0);
           z = 1;
           v = unique(lam);
           for j=1:length(v)
               mu = sum(lam==v(j));
               z = z*v(j)^mu*factorial(mu);
           end
           w = [w; 1/(alpha^length(lam)*z)];
       end
   end
