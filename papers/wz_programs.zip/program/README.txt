wz: MATLAB programs for the density of the product of a Wishart matrix
and a normal vector
=======================================================================

Raymond Kan, Taras Bodnar, and Stepan Mazur

These programs compute the density function of

    q = L'*W*z,   W ~ W_m(n, Sigma_w),   z ~ N_m(mu, Sigma_z),   W independent of z,

for arbitrary positive definite Sigma_w and Sigma_z, real n > m-1, and an
m x p matrix L of rank p <= m (L = eye(m), or L = [], gives the product W*z).
They implement the representations in

    Bodnar, T., Kan, R., and Mazur, S. (2026). Computation of the exact density
    function of the product of a Wishart matrix and a normal vector.

The user manual, manual.pdf, describes every routine, the automatic choice of
representation, accuracy and computing times.


Requirements
------------
MATLAB with the Statistics and Machine Learning Toolbox (chi2pdf, ncx2pdf,
normpdf, gampdf, randg).  Tested with MATLAB R2025b.


Getting started
---------------
Add this folder to the MATLAB path and call LWZPDF, which chooses the
representation automatically:

    m = 3; n = 8;
    mu = [1; 2; 3]/3;
    Sw = 0.5*eye(m) + 0.5*ones(m);           % Sigma_w
    Sz = 0.2*eye(m) + 0.8*ones(m);           % Sigma_z
    L  = [1 0; 0 1; 0.5 0.5];                % p = 2 linear combinations
    q  = [5 6; 4 7];                         % evaluation points, one per column
    [f, method] = lwzpdf(q, L, mu, Sw, Sz, n)

    f0 = wzpdf([1; 2; 3], mu, Sw, Sz, n)     % density of the full product W*z


Contents
--------
lwzpdf.m          main routine: density of L'*W*z, automatic choice of method
wzpdf.m           density of W*z (Theorem 2.1)
lwzpdf_cf.m       inversion of the characteristic function (Corollary 4.1)
lwzcf.m           characteristic function of L'*W*z (Theorem 4.1)
lwzcf_setup.m     precomputation for lwzcf_eval
lwzcf_eval.m      evaluation of the characteristic function
lwzpdf_bessel.m   Bessel-function representations, p = 1, 2 (Sections 3.1-3.2)
lwzpdf_marg.m     marginalization of Theorem 2.1, m-p = 1, 2 (Remark 4.4)
lwzpdf_ident.m    Sigma_z proportional to inv(Sigma_w) (Section 3.3)
lwzpdf_zero.m     density at the origin for p < m
lwzpdf_mc.m       conditional Monte Carlo estimate, with standard errors
wzrnd.m           random draws of a Wishart matrix with real degrees of freedom
qpdfser.m         density of a quadratic form in normal variables (Ruben series)
qratintnc.m       E[(x'Ax)^p/(x'Bx)^q] for x ~ N(mu, I) (Bao and Kan, 2013)
manual.pdf        user manual

tests\            scripts that reproduce the numerical results of the paper
                  (Tables 1-3, Figures 1-2) and regression checks; see
                  Section "Scripts reproducing the paper" of the manual
tests\results\    saved results behind Tables 1-3 and Figure 2; make_tables
                  rewrites the table bodies and figure2.pdf from them
