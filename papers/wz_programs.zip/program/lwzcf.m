function psi = lwzcf(t,L,mu,Sw,Sz,n,Ku)
%LWZCF  Characteristic function of q = L'*W*z as a single integral.
%
%   psi = lwzcf(t,L,mu,Sw,Sz,n)
%   psi = lwzcf(t,L,mu,Sw,Sz,n,Ku)
%
%   Evaluates psi(t) = E[exp(i t'q)] for q = L'*W*z, where W ~ W_m(n,Sw) and
%   z ~ N_m(mu,Sz) are independent and L is m x p of rank p <= m (any p,
%   including p = m).  By Theorem 4.1 of Bodnar, Kan and Mazur (2026),
%
%      psi(t) = exp(-mu'Sz^{-1}mu/2) * int_0^inf |I_m + u St Ka|^{-1/2}
%               * exp( r_u'(St^{-1} + u Ka)^{-1} r_u / 2 ) f_n(u) du,
%
%   where a = Lt'*t, Ka = (a'a) I_m - a a', r_u = St^{-1} mut + i u a,
%   Lt = Sw^{1/2} L, mut = Sw^{1/2} mu, St = Sw^{1/2} Sz Sw^{1/2}, and f_n is
%   the chi2_n density.  The u-integral is evaluated by Ku-point
%   Gauss-Legendre quadrature over the effective support of f_n, and the
%   m x m determinant and linear solve are reduced to O(m) operations in the
%   eigenbasis of St (Sherman-Morrison).
%
%   Input:
%     t   : p x K array of frequency vectors (one column per point; for
%           p = 1 any vector)
%     L   : m x p matrix of constants
%     mu  : m x 1 mean vector of z
%     Sw  : m x m covariance matrix of the Wishart matrix
%     Sz  : m x m covariance matrix of the normal vector
%     n   : degrees of freedom (real, n > m-1)
%     Ku  : number of quadrature nodes for u (default 128)
%
%   Output:
%     psi : 1 x K vector of complex characteristic function values
%
%   See also LWZPDF_CF, LWZPDF.

if nargin < 7 || isempty(Ku), Ku = 128; end
mu = mu(:); m = length(mu); p = size(L,2);
if p == 1, t = t(:).'; end
S = lwzcf_setup(L,mu,Sw,Sz,n,Ku);
psi = lwzcf_eval(t,S);
end
