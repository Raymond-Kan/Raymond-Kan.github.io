function psi = lwzcf_eval(t,S)
%LWZCF_EVAL  Evaluate the characteristic function of L'*W*z on a grid.
%
%   psi = lwzcf_eval(t,S)
%
%   Internal helper: t is a p x K array of frequency vectors and S is the
%   structure returned by LWZCF_SETUP.  Returns the 1 x K complex vector
%   psi(t).  In the eigenbasis St = V diag(lam) V' of St, with b = V'a,
%   c = a'a = b'b, D = diag(lam./(1+u c lam)) and r = g0 + i u b,
%
%      |I + u St Ka|            = prod_j (1 + u c lam_j) * den,
%      r'(St^{-1} + u Ka)^{-1} r = r'Dr + u (r'Db)^2 / den,
%      den = 1 - u b'Db = (1/c) sum_j b_j^2/(1 + u c lam_j)   (c > 0),
%
%   and den = 1 for c = 0 (Remark 4.2 of the paper).  The positive sum is used
%   for den, which avoids the cancellation in 1 - u b'Db for large u c, and
%   the constant mu'Sz^{-1}mu = sum_j lam_j g0_j^2 is subtracted analytically:
%
%      r'Dr - sum_j lam_j g0_j^2 = sum_j D_j (2 i u g0_j b_j - u^2 b_j^2 - u c lam_j g0_j^2),
%
%   so that no large positive and negative terms cancel in the exponent.
%   Each quadrature node costs O(m K) operations.

Am = S.Lt*t;                                   % m x K   (a = Lt t)
Bm = S.V'*Am;                                  % m x K   (b = V'a)
cc = sum(Bm.^2,1);                             % 1 x K   (c = a'a = b'b)
B2 = Bm.^2;
K  = size(t,2);
psi = zeros(1,K);
pos = cc > 0;
for k = 1:S.Ku
   u   = S.u(k);
   D   = 1./(S.invlam + u*cc);                 % m x K   lam/(1+u c lam)
   den = ones(1,K);
   den(pos) = sum(B2(:,pos)./(1 + u*(S.lam*cc(pos))),1)./cc(pos);
   Db  = D.*Bm;
   rDb = sum((S.g0 + 1i*u*Bm).*Db,1);         % r'Db
   ex  = sum(D.*(2i*u*S.g0.*Bm - u^2*B2 - u*(S.lam.*S.g0.^2)*cc),1) ...
         + u*rDb.^2./den;                      % r'(St^{-1}+u Ka)^{-1}r - mu'Sz^{-1}mu
   ldet = sum(log1p(u*(S.lam*cc)),1) + log(den);
   psi = psi + S.wu(k)*exp(0.5*ex - 0.5*ldet);
end
end
