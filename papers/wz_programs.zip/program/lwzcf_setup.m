function S = lwzcf_setup(L,mu,Sw,Sz,n,Ku)
%LWZCF_SETUP  Precomputations for the characteristic function of L'*W*z.
%
%   S = lwzcf_setup(L,mu,Sw,Sz,n,Ku)
%
%   Internal helper for LWZCF and LWZPDF_CF: transforms to the identity-scale
%   Wishart, diagonalizes St = Sw^{1/2} Sz Sw^{1/2}, and stores Ku-point
%   Gauss-Legendre nodes and weights (times the chi2_n density) for the
%   u-integral.  The returned structure is consumed by LWZCF_EVAL.

mu = mu(:); m = length(mu);
if n <= m-1
   error('lwzcf:n','n must exceed m-1.');
end
Swh = sqrtm(Sw);  Swh = real(0.5*(Swh+Swh'));
S.m   = m;
S.p   = size(L,2);
S.n   = n;
S.Lt  = Swh*L;                                % m x p
mut   = Swh*mu;
St    = Swh*Sz*Swh;  St = 0.5*(St+St');
S.const = mu'*(Sz\mu);                        % = mut' St^{-1} mut
[V,Dl] = eig(St);
lam    = diag(Dl);
S.V    = V;
S.lam  = lam;
S.invlam = 1./lam;
S.g0   = (V'*mut)./lam;                       % V' St^{-1} mut
S.lmin = min(lam);  S.lmax = max(lam);
%  Gauss-Legendre nodes in x = log(u) over the effective support of chi2_n.
%  The log transform removes the integrable singularity u^{n/2-1} of f_n at
%  the origin when n < 2 and resolves the small-u region that dominates the
%  integral for large |t|.
lo = log(2*gaminv_(1e-16,n/2,'lower'));
hi = log(2*gaminv_(1e-16,n/2,'upper'));
[xu,wu] = gauleg_(Ku);
x    = 0.5*(hi-lo)*xu + 0.5*(hi+lo);
S.u  = exp(x);                                % 1 x Ku
S.wu = 0.5*(hi-lo)*wu .* chi2pdf_(S.u,n) .* S.u;   % weights incl. density and Jacobian
S.Ku = Ku;
end

%----------------------------------------------------------------------
function pdf = chi2pdf_(x,nu)
pdf = zeros(size(x)); ii = x > 0;
pdf(ii) = exp((0.5*nu-1).*log(x(ii)) - 0.5*x(ii) - gammaln(0.5*nu) - 0.5*nu*log(2));
end

function [x,w] = gauleg_(N)
%  Gauss-Legendre nodes/weights on (-1,1) by Golub-Welsch
b = (1:N-1)./sqrt(4*(1:N-1).^2-1);
J = diag(b,1)+diag(b,-1);
[Vj,Dj] = eig(J);
[x,idx] = sort(diag(Dj));
x = x'; w = 2*Vj(1,idx).^2;
end

function x = gaminv_(pp,a,tail)
%  Quantile of Gamma(a,1) by bisection on gammainc
if strcmp(tail,'lower'), target = pp; else, target = 1-pp; end
lo = 0; hi = a + 10*sqrt(a) + 20;
while gammainc(hi,a) < target, hi = hi*2; end
for it = 1:200
   mid = 0.5*(lo+hi);
   if gammainc(mid,a) < target, lo = mid; else, hi = mid; end
end
x = 0.5*(lo+hi);
end
