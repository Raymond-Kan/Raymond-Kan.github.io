function [f,method,info] = lwzpdf(q,L,mu,Sw,Sz,n,method)
%LWZPDF  Density of q = L'*W*z for W ~ W_m(n,Sw), z ~ N_m(mu,Sz), independent.
%
%   f = lwzpdf(q,L,mu,Sw,Sz,n)
%   f = lwzpdf(q,L,mu,Sw,Sz,n,method)
%   [f,method,info] = lwzpdf(...)
%
%   Front end that evaluates the density of p linear combinations
%   q = L'*W*z of the product of a Wishart matrix and an independent normal
%   vector, where L is an m x p matrix of rank p <= m, by the fastest of the
%   representations in Bodnar, Kan and Mazur (2026):
%
%     'full'     : p = m, density of the full product W*z (and of any
%                  nonsingular L'*W*z), a two-dimensional integral
%                  (Theorem 2.1)                                       -> WZPDF
%     'cf'       : p < m, inversion of the characteristic function,
%                  a (p+1)-dimensional integral (Corollary 4.1), coded
%                  for p <= 3; when Sz is proportional to inv(Sw)
%                  (e.g. Sw = Sz = I_m), a three-dimensional integral
%                  for every p                                         -> LWZPDF_CF
%     'bessel'   : p in {1,2}, integral with a modified Bessel function
%                  kernel and the Ruben series for the quadratic form
%                  (Sections 3.1-3.2)                                  -> LWZPDF_BESSEL
%     'marginal' : m-p in {1,2}, the density of the full product with
%                  the last m-p coordinates integrated out, an
%                  (m-p+2)-dimensional integral (Remark 4.4)          -> LWZPDF_MARG
%     'proportional' : Sz proportional to inv(Sw), e.g. Sw = Sz = I_m,
%                  p < m (Section 3.3; 'identity' is accepted as an
%                  alias)                                              -> LWZPDF_IDENT
%     'mc'       : conditional Monte Carlo (1e5 draws)                 -> LWZPDF_MC
%
%   With method = 'auto' (default) the routine is chosen as follows
%   (timings from the benchmark in Section 5.3 of the paper and the manual):
%     p = m                                           -> 'full'
%     p = m-1 and n < m+2                             -> 'bessel' (p = 1) or
%                                                        'marginal' (p > 1)
%     p = m-1 >= 3 and Sz not proportional to inv(Sw) -> 'marginal'
%     otherwise, p <= 3 or Sz ~ inv(Sw)               -> 'cf'
%     otherwise                                       -> 'mc' (with a warning)
%   For p = m-1 and n close to m-1 the characteristic function decays slowly
%   and the inversion loses accuracy (see the manual), hence the second rule.
%   The 'proportional' route is slower than 'cf' in every configuration we have
%   tried and is kept for reference and validation.
%   With method = 'auto' and p < m, the density at q = 0_p (exact zero
%   columns of q) is computed from eq. (39) of the paper, the expectation of
%   a ratio of quadratic forms (QRATINTNC), which is faster and more
%   accurate there than any of the routes above.  For p < m this value is
%   always finite; for p = m, f(0_m) = Inf when n <= m+1 (eq. (7)).
%
%   Input:
%     q      : p x N array of evaluation points (for p = 1, any vector)
%     L      : m x p matrix of constants (rank p); use [] or eye(m) for W*z
%     mu     : m x 1 mean vector of z
%     Sw     : m x m covariance matrix of the Wishart matrix
%     Sz     : m x m covariance matrix of the normal vector
%     n      : degrees of freedom (real, n > m-1)
%     method : 'auto' (default) or one of the names above
%
%   Output:
%     f      : 1 x N vector of density values
%     method : the method actually used ('zero' when every column of q
%              is 0_p and eq. (39) was used)
%     info   : structure with diagnostics of the route: for 'mc' the
%              standard errors (field se) and the number of draws (nsim);
%              for 'cf' the diagnostics returned by LWZPDF_CF; empty
%              otherwise
%
%   See also WZPDF, LWZPDF_CF, LWZCF, LWZPDF_BESSEL, LWZPDF_MARG,
%   LWZPDF_IDENT, LWZPDF_MC.

mu = mu(:); m = length(mu);
if isempty(L), L = eye(m); end
p = size(L,2);
info = struct();
if size(L,1) ~= m || ~isequal(size(Sw),[m m]) || ~isequal(size(Sz),[m m])
   error('lwzpdf:dim','L must have m rows and Sw, Sz must be m x m, where m = length(mu).');
end
if rank(L) < p
   error('lwzpdf:L','L must have full column rank.');
end
if ~(isscalar(n) && isreal(n) && isfinite(n) && n > m-1)
   error('lwzpdf:n','n must be a finite real scalar with n > m-1.');
end
[~,pw] = chol(0.5*(Sw+Sw'));  [~,pz] = chol(0.5*(Sz+Sz'));
if pw > 0 || pz > 0 || norm(Sw-Sw','fro') > 1e-12*norm(Sw,'fro') || norm(Sz-Sz','fro') > 1e-12*norm(Sz,'fro')
   error('lwzpdf:cov','Sw and Sz must be symmetric positive definite.');
end
if nargin < 7 || isempty(method), method = 'auto'; end
P = Sw*Sz;  isprop = norm(P - trace(P)/m*eye(m),'fro') <= 1e-10*abs(trace(P));   % Sz ~ inv(Sw)

%  q = 0_p for p < m: eq. (39)
if strcmpi(method,'auto') && p < m
   N = numel(q)/p;  q = reshape(q,p,N);
   iz = all(q == 0,1);
else
   iz = [];
end
if any(iz)
   f = zeros(1,N);
   f(iz) = lwzpdf_zero(L,mu,Sw,Sz,n);
   method = 'zero';
   if any(~iz)
      [f(~iz),method,info] = lwzpdf(q(:,~iz),L,mu,Sw,Sz,n,'auto');
   end
   return
end
if strcmpi(method,'auto')
   method = autoroute(p,m,n,isprop);
end

switch lower(method)
   case 'full'
      if p ~= m, error('lwzpdf:full','Method ''full'' requires p = m (L square).'); end
      if isequal(L,eye(m))
         f = wzpdf(q,mu,Sw,Sz,n);
      else
         %  q = L'Wz = W*z*, W* ~ W_m(n,L'SwL), z* ~ N(L^{-1}mu, L^{-1}Sz L^{-1}')
         Li = L\eye(m);
         f = wzpdf(q, Li*mu, L'*Sw*L, Li*Sz*Li', n);
      end
   case 'cf'
      [f,info] = lwzpdf_cf(q,L,mu,Sw,Sz,n);
   case 'bessel'
      f = lwzpdf_bessel(q,L,mu,Sw,Sz,n);
   case 'marginal'
      f = lwzpdf_marg(q,L,mu,Sw,Sz,n);
   case {'proportional','identity'}
      if ~isprop, error('lwzpdf:proportional','Method ''proportional'' requires Sz to be proportional to inv(Sw).'); end
      if p >= m,  error('lwzpdf:proportional','Method ''proportional'' requires p < m.'); end
      f = lwzpdf_ident(q,L,mu,Sw,Sz,n);
      method = 'proportional';
   case 'mc'
      nsim = 1e5;
      [f,se] = lwzpdf_mc(q,L,mu,Sw,Sz,n,nsim);
      info.se = se;  info.nsim = nsim;
   otherwise
      error('lwzpdf:method',['Unknown method ''%s''; use ''auto'', ''full'', ''cf'', ' ...
            '''bessel'', ''marginal'', ''proportional'' or ''mc''.'],method);
end
end

function method = autoroute(p,m,n,isprop)
%  route chosen by method = 'auto'
if p == m
   method = 'full';
elseif p == m-1 && n < m+2
   %  |psi| decays like |t|^(-(n+m-1)/2) = |t|^(-p-(n-m+1)/2): for p = m-1 and
   %  n close to m-1 the inversion integral converges slowly and the CF route
   %  loses accuracy; the Bessel route (p = 1) and the marginalization are exact
   if p == 1
      method = 'bessel';
   else
      method = 'marginal';
   end
elseif p == m-1 && p >= 3 && ~isprop
   method = 'marginal';           % faster than the CF route for p = 3
elseif p <= 3 || isprop          % (n > 2p-m+1 holds for every p < m)
   method = 'cf';
else
   if m-p == 2
      warning('lwzpdf:mc',['For p = %d, m = %d the deterministic route is the four-dimensional ' ...
         'marginalization (method ''marginal''), which takes minutes per point; using ' ...
         'conditional Monte Carlo (1e5 draws, standard errors in the third output).'],p,m);
   else
      warning('lwzpdf:mc',['For p = %d, m = %d the deterministic routes are integrals of ' ...
         'dimension at least five; using conditional Monte Carlo (1e5 draws, standard ' ...
         'errors in the third output).'],p,m);
   end
   method = 'mc';
end
end
