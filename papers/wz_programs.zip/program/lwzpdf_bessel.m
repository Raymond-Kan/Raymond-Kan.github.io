function f = lwzpdf_bessel(q,L,mu,Sw,Sz,n)
%LWZPDF_BESSEL  Density of q = L'*W*z by the Bessel-function route (p = 1, 2).
%
%   f = lwzpdf_bessel(q,L,mu,Sw,Sz,n)
%
%   Computes the density of q = L'*W*z, W ~ W_m(n,Sw), z ~ N_m(mu,Sz)
%   independent, L an m x p matrix of rank p < m with p = 1 or p = 2, from
%   the representations of Section 3 of Bodnar, Kan and Mazur (2026): the
%   integral over u1 ~ chi2_n is carried out in closed form (modified Bessel
%   function of the second kind), and the remaining integral is over the
%   linear forms z-hat and the quadratic form u-hat, whose conditional
%   density given z-hat is the chi-squared mixture of Ruben (1962) (see
%   Appendix A.2 of the paper).
%
%     p = 1 : two-dimensional integral, eqs. (40) and (47)  (outer: z-hat,
%             inner: u-hat), for arbitrary Sw, Sz.
%     p = 2 : three-dimensional integral, eq. (48) (outer: z-hat_1, z-hat_2,
%             inner: u-hat).
%
%   At q = 0 the density is computed by LWZPDF_ZERO (eq. (39)), as in all the
%   other routes.
%
%   Input:
%     q   : p x N array of evaluation points (for p = 1, any vector)
%     L   : m x p matrix of constants (rank p, p in {1,2}, p < m)
%     mu  : m x 1 mean vector of z
%     Sw  : m x m covariance matrix of the Wishart matrix
%     Sz  : m x m covariance matrix of the normal vector
%     n   : degrees of freedom (real, n > m-1)
%
%   Output:
%     f   : 1 x N vector of density values
%
%   See also LWZPDF_CF, LWZPDF, QPDFSER, QRATINTNC.

mu = mu(:); m = length(mu); p = size(L,2);
if p == 1, q = q(:).'; end
N = size(q,2);
f = zeros(1,N);
if p >= m || p > 2
   error('lwzpdf_bessel:p','lwzpdf_bessel requires p in {1,2} and p < m.');
end

%  ---- common transformations (Section 3 of the paper) ----
S1   = sqrtm(Sw);   S1  = real(0.5*(S1+S1'));
Szh  = sqrtm(Sz);   Szh = real(0.5*(Szh+Szh'));
Szhi = Szh\eye(m);
L1   = S1*L;                                     % L-tilde
LL   = L1'*L1;
LLi  = LL\eye(p);
dL   = sqrt(det(LL));
A    = Szh*S1*(eye(m)-L1*LLi*L1')*S1*Szh;       % Sigma_z^{1/2} Sw^{1/2} (I - P_L) Sw^{1/2} Sigma_z^{1/2}
A    = 0.5*(A+A');
[P,D] = eig(A);
[ev,ix] = sort(diag(D));  P = P(:,ix);           % ascending: the first p eigenvalues are zero
D = diag([zeros(p,1); ev(p+1:m)]);
muy  = P'*(Szhi*mu);                             % mu_y
Bh   = sqrtm(LLi);  Bh = real(0.5*(Bh+Bh'));     % (L~'L~)^{-1/2}
Lh   = P'*Szh*S1*L1*Bh;                          % L-hat, m x p

%  The Ruben series converges slowly for very large noncentralities, which
%  occur only far in the tails of the normal weight of the outer integral,
%  where the integrand is negligible; its convergence warning is suppressed.
wst = warning('off','qpdfser:conv');
cleanupW = onCleanup(@() warning(wst));
if p == 1
   %  ---- p = 1: eqs. (40), (42)-(47) ----
   aa  = LL;                                     % alpha' Sw alpha
   a   = Lh*sqrt(aa);                            % alpha-hat = P' Sz^{1/2} Sw alpha
   Q1  = null(a');
   Q   = [a/sqrt(a'*a) Q1];
   B   = Q'*D*Q;  B = 0.5*(B+B');
   B11 = B(1,1);
   [P1,D1] = eig(B(2:m,2:m));
   d1  = diag(D1);
   b1  = 2*P1'*B(2:m,1);
   mut = P1'*(Q1'*muy);
   am  = a'*muy/sqrt(aa);                        % mean of z-hat
   s   = sqrt((a'*a)/aa);                        % s.d. of z-hat
   lb  = 0;                                      % u-hat >= 0: the Schur complement
                                                 % B11 - b1'D1^{-1}b1/4 vanishes because D
                                                 % has rank m-1
   for i = 1:N
      qi = q(i)/sqrt(aa);                        % q-hat
      if qi == 0
         f(i) = lwzpdf_zero(L,mu,Sw,Sz,n);
      else
         aqi = abs(qi);
         cc  = exp(((n-1)/2)*log(aqi) - ((n-1)/2)*log(2) - gammaln(n/2) - 0.5*log(pi) - 0.5*log(aa));
         f(i) = cc*integral(@(x) kern1(x,qi,aqi).*normpdf(x,am,s), -Inf, Inf, ...
                            'AbsTol',1e-12,'RelTol',1e-9);
      end
   end
else
   %  ---- p = 2: eq. (48) ----
   B1   = sqrtm(Lh'*Lh);  B1 = real(0.5*(B1+B1'));
   Lh1  = Lh/B1;
   Q1   = null(Lh1');
   Q    = [Lh1 Q1];
   C    = Q'*D*Q;  C = 0.5*(C+C');
   C11  = C(1:p,1:p);
   C21  = C(p+1:m,1:p);
   C22  = C(p+1:m,p+1:m);
   [P1,D1] = eig(C22);
   d1   = diag(D1);
   b1   = 2*P1'*C21;
   mux  = Lh1'*muy;
   mut  = P1'*(Q1'*muy);
   cc   = exp(-(n/2)*log(2) - gammaln(n/2) - log(pi) - log(dL));
   for i = 1:N
      qh  = Bh*q(:,i);                           % q-hat
      qqh = qh'*qh;
      if qqh == 0
         f(i) = lwzpdf_zero(L,mu,Sw,Sz,n);
      else
         f(i) = cc*integral2(@(x1,x2) kern2(x1,x2,qh,qqh).*normpdf(x1-mux(1)).*normpdf(x2-mux(2)), ...
                             -Inf,Inf,-Inf,Inf,'AbsTol',1e-12,'RelTol',1e-8);
      end
   end
end

%======================================================================
   function y = kern1(x,qi,aqi)
      %  inner integral over u-hat for p = 1 (scaled Bessel function to avoid
      %  underflow; qpdfser is the Ruben-series density of u-hat given x1)
      y = zeros(size(x));
      for j = 1:numel(x)
         z  = x(j);
         x1 = z/s;
         y(j) = integral(@(u) exp(qi*z./u + log(besselk((n-1)/2,aqi*sqrt(z^2+u)./u,1)) ...
                 - aqi*sqrt(z^2+u)./u - (n-1)/4*log(z^2+u) - 0.5*log(u)) ...
                 .*qpdfser(u,B11*x1^2,x1*b1,d1,mut), lb*x1^2, Inf, 'AbsTol',1e-12,'RelTol',1e-9);
      end
   end

   function y = kern2(x1,x2,qh,qqh)
      x  = [x1(:)'; x2(:)'];
      zh = B1*x;
      v1 = qh'*zh;
      v2 = sum(zh.^2,1);
      a0 = sum((C11*x).*x,1);
      a1 = b1*x;
      y  = zeros(size(x1(:)'));
      for j = 1:numel(y)
         v1j = v1(j);
         y(j) = integral(@(u) exp(log(besselk((n-2)/2,sqrt(qqh*u+v1j^2)./u,1)) + v1j./u ...
                 + (n-2)/4*log(qqh*u+v1j^2) - (n-1)/2*log(v2(j)+u) - 0.5*log(u) ...
                 - sqrt(qqh*u+v1j^2)./u).*qpdfser(u,a0(j),a1(:,j),d1,mut), 0, Inf, ...
                 'AbsTol',1e-12,'RelTol',1e-8);
      end
      y = reshape(real(y),size(x1));
   end
end
