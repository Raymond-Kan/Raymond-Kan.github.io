function [f,info] = lwzpdf_cf(q,L,mu,Sw,Sz,n,opts)
%LWZPDF_CF  Density of q = L'*W*z by characteristic function inversion.
%
%   f = lwzpdf_cf(q,L,mu,Sw,Sz,n)
%   f = lwzpdf_cf(q,L,mu,Sw,Sz,n,opts)
%   [f,info] = lwzpdf_cf(...)
%
%   Computes the density of q = L'*W*z, W ~ W_m(n,Sw), z ~ N_m(mu,Sz)
%   independent, L an m x p matrix of rank p, from the (p+1)-dimensional
%   representation of Corollary 4.1 of Bodnar, Kan and Mazur (2026),
%
%       f(q) = (2 pi)^{-p} int_{R^p} Re[ exp(-i t'q) psi(t) ] dt,
%
%   where psi(t) is the single-integral characteristic function evaluated by
%   LWZCF.  The representation is valid for any p <= m, arbitrary (not
%   necessarily proportional) Sw and Sz, and every q, including q = 0.  It
%   requires n > 2p - m + 1, which guarantees that psi is absolutely
%   integrable (Proposition 4.1 of the paper); for p = m this is the
%   condition n > m+1 under which the density is bounded.
%
%   Numerical method.  psi is evaluated once on a tensor grid of frequencies
%   graded towards the origin (sinh map) whose extent along each axis is set
%   by the decay of |psi|, and the Fourier integral is computed by a Filon
%   rule: exp(-i t'q) is integrated exactly, coordinate by coordinate,
%   against the piecewise-cubic (tensor-product) interpolant of psi on the
%   grid.  The oscillation of exp(-i t'q), which is rapid when |q| is large,
%   is therefore handled analytically and the grid only has to resolve psi
%   itself (the error decreases like Ns^{-4}).  Since psi does not depend on
%   q, a complete density curve costs little more than a single point.
%   Implemented for p = 1, 2 and 3.
%
%   Proportional case.  When Sz is proportional to inv(Sw) (in particular when
%   Sw = Sz = I_m), psi(t) depends on t only through |L~t|^2 and t'L~'mu~, and
%   the p-dimensional inversion reduces to a two-dimensional one: along the
%   direction of eta = (L~'L~)^{-1/2} L~'mu~ (Filon rule as above) and, in the
%   orthogonal complement, a Hankel transform with kernel
%   rho^{p-2} J_{(p-3)/2}(kappa rho)/(kappa rho)^{(p-3)/2} (composite
%   Gauss-Legendre rule with panels shorter than half a period).  The density
%   is then a three-dimensional integral for every p <= m, and this route is
%   used automatically (for any p, not only p <= 3) unless opts.reduce = false.
%
%   Error control (general case).  The number Ku of nodes of the u-integral
%   is doubled, from 128 up to Kumax, until psi changes by less than 1e-12 at
%   probe frequencies.  The box [-T,T]^p is set from the decay of |psi| along
%   the axes and enlarged until |psi| <= 10*tol on its whole boundary.  When
%   the decay of psi is slow, (n+m-1)/2 - p < opts.extrap, the inversion at
%   the points near the origin (max_j |q_j| T_j <= 1) is repeated on a box
%   four times larger and extrapolated in T (Richardson, using the
%   T^{p-(n+m-1)/2} behaviour of the truncation error there).  Negative
%   values are set to zero with a warning.
%
%   Input:
%     q    : p x N array of evaluation points (for p = 1, any vector)
%     L    : m x p matrix of constants (rank p; p <= 3 unless Sz is
%            proportional to inv(Sw))
%     mu   : m x 1 mean vector of z
%     Sw   : m x m covariance matrix of the Wishart matrix
%     Sz   : m x m covariance matrix of the normal vector
%     n    : degrees of freedom (real, n > max(m-1, 2p-m+1))
%     opts : optional structure with fields
%              tol  - truncation level for |psi| (default 1e-10)
%              Ns   - nodes per frequency dimension (made 1 mod 6; default
%                     3001/601/181 for p = 1/2/3)
%              Ku   - initial number of nodes for the u-integral (default 128)
%              Kumax - largest number of u-nodes (default 1024)
%              extrap - extrapolate in T when (n+m-1)/2 - p < extrap
%                     (default 2)
%              reduce - use the reduction of the proportional case when it
%                     applies (default true); in that case Ns (default 700)
%                     is the number of nodes along eta and ppan (default 8) the
%                     Gauss-Legendre nodes per panel in the radial direction
%
%   Output:
%     f    : 1 x N vector of density values
%     info : diagnostics, with fields
%              route       - 'general' or 'proportional'
%              T           - half-widths of the frequency box
%              Ku          - number of u-nodes used
%              Kuchange    - change of psi in the last doubling of Ku
%              tailbound   - rigorous bound on the truncation error, from the
%                            envelope of Proposition 4.1 integrated outside
%                            the largest (whitened) ball in the box; it is
%                            conservative
%              discerr     - 1 x N indicator of the discretization error,
%                            |f - f_c| with f_c computed on every other
%                            node (general case only); when psi decays
%                            slowly it is not smooth at t = 0, and the
%                            error of f can be of the same order as discerr
%              boundarymax - max |psi| on the boundary of the box (general)
%              extrapolated - 1 x N, true where the Richardson step was used
%                            (general case)
%
%   See also LWZCF, LWZPDF, WZPDF, LWZPDF_MC.

mu = mu(:); m = length(mu); p = size(L,2);
if p == 1, q = q(:).'; end
if size(q,1) ~= p
   error('lwzpdf_cf:q','q must be a p x N array of evaluation points.');
end
if n <= 2*p-m+1
   error('lwzpdf_cf:n','Inversion requires n > 2p-m+1 (here n > %g).',2*p-m+1);
end
if nargin < 7, opts = struct; end
alpha = (n+m-1)/2;                       % |psi(t)| = O(|L~t|^{-alpha})
if getopt(opts,'reduce',true) && isprop_(Sw,Sz)
   [f,info] = cf_prop(q,L,mu,Sw,Sz,n,opts);
   info.route = 'proportional';
   f = clipneg(f,info);
   return
end
if p > 3
   error('lwzpdf_cf:dim',['lwzpdf_cf is implemented for p <= 3 (got p = %d) ' ...
         'unless Sz is proportional to inv(Sw).'],p);
end
%  ---- general case ----
[f,info] = cf_general(q,L,mu,Sw,Sz,n,opts,1);
info.route = 'general';
info.extrapolated = false(1,size(q,2));
exc = alpha - p;                          % excess of the decay rate over p
if exc < getopt(opts,'extrap',2)
   %  Slow decay: near q = 0, where exp(-i t'q) does not oscillate over the
   %  tail, the truncation error of the box [-T,T]^p behaves like T^{p-alpha}.
   %  At the points with max_j |q_j| T_j <= 1, repeat on a box four times
   %  larger and extrapolate (Richardson) in T; elsewhere the oscillation
   %  makes the tail contribution smaller and of a different form, and the
   %  value on the first box is kept.
   near = max(abs(q).*info.T(:),[],1) <= 1;
   info.extrapolated = near;
   if any(near)
      [f4,info4] = cf_general(q(:,near),L,mu,Sw,Sz,n,opts,4,info.Ku);
      f(near) = f4 + (f4 - f(near))/(4^exc - 1);
      info.T4 = info4.T;
      info.tailbound4 = info4.tailbound;
      info.discerr(near) = max(info.discerr(near),info4.discerr);
   end
end
f = clipneg(f,info);
end

function f = clipneg(f,info)
%  negative values signal that the numerical approximation failed a basic
%  check; they are set to zero, with a warning
neg = f < 0;
if any(neg)
   warning('lwzpdf_cf:negative',['%d negative density value(s) set to zero (largest %.3g); ' ...
      'see the diagnostics in the second output (tail bound %.3g).'],nnz(neg),max(-f(neg)),info.tailbound);
   f(neg) = 0;
end
end

function [f,info] = cf_general(q,L,mu,Sw,Sz,n,opts,Tfac,Ku0)
%  inversion on a tensor grid over the box [-T,T]^p, T = Tfac * (extent from |psi|)
mu = mu(:); m = length(mu); p = size(L,2);
tol  = getopt(opts,'tol',1e-10);
Ku   = getopt(opts,'Ku',128);
Nsd  = [3001 601 181];
Ns   = getopt(opts,'Ns',Nsd(p));
if nargin >= 9, Ku = Ku0; end

%  ---- number of nodes for the u-integral: double Ku until psi changes by
%       less than 1e-12 at probe frequencies along the axes ----
rk = 2.^((-60:0.5:60)/4);
K  = numel(rk);
Pr = zeros(p,K*p);
for j = 1:p, Pr(j,(j-1)*K+(1:K)) = rk; end
S  = lwzcf_setup(L,mu,Sw,Sz,n,Ku);
P0 = lwzcf_eval(Pr,S);
dK = NaN;
if nargin < 9                             % (the second pass reuses Ku)
   while Ku < getopt(opts,'Kumax',1024)
      S2 = lwzcf_setup(L,mu,Sw,Sz,n,2*Ku);
      P2 = lwzcf_eval(Pr,S2);
      dK = max(abs(P2-P0));
      if dK < 1e-12, break; end
      S = S2;  P0 = P2;  Ku = 2*Ku;
   end
end

%  ---- frequency extent along each coordinate axis ----
%  T(j) is the radius beyond which |psi| < tol along axis j, and Tl(j) the
%  radius beyond which |psi| < 1e-2 (the main lobe).
T = zeros(1,p); Tl = zeros(1,p);
for j = 1:p
   Pk = abs(P0((j-1)*K+(1:K)));
   kT  = find(Pk >= tol, 1, 'last');  if isempty(kT),  kT  = 1; end
   kTl = find(Pk >= 1e-2, 1, 'last'); if isempty(kTl), kTl = 1; end
   T(j)  = rk(min(K,kT+1))*1.15;
   Tl(j) = rk(min(K,kTl+1));
end
T = T*Tfac;

Ng = 6*floor((Ns-1)/6)+1;                 % 1 mod 6: the fine grid and every other node are 1 mod 3
blk = max(1,floor(4e6/(m*Ku)));
for attempt = 1:4
   %  ---- graded grids: t = T sinh(beta x)/sinh(beta), x equally spaced on [-1,1] ----
   tg = cell(1,p);
   for j = 1:p
      beta = max(4, log(4*T(j)/Tl(j)));
      tg{j} = T(j)*sinh(beta*linspace(-1,1,Ng))/sinh(beta);
   end
   %  ---- |psi| on the whole boundary of the box (all directions, not only
   %       the axes) must be below tol; otherwise enlarge the box.  Only the
   %       boundary nodes are evaluated here. ----
   Tb = boxboundary(tg,p);
   bmax = max(abs(evalblocks(Tb,S,blk)));
   if bmax <= 10*tol || Tfac > 1 || attempt == 4, break; end
   T = 1.5*T;
end
%  ---- evaluate psi on the grid (in blocks to limit memory) ----
if p == 1
   Tg = tg{1};
elseif p == 2
   [G1,G2] = ndgrid(tg{1},tg{2}); Tg = [G1(:)'; G2(:)'];
else
   [G1,G2,G3] = ndgrid(tg{1},tg{2},tg{3}); Tg = [G1(:)'; G2(:)'; G3(:)'];
end
PSI = evalblocks(Tg,S,blk);

%  ---- Filon inversion on the grid and on every other node (error estimate) ----
f  = filon_p(tg,PSI,q,p);
tc = cellfun(@(x) x(1:2:end),tg,'UniformOutput',false);
Pc = reshape(PSI,[Ng*ones(1,p) 1]);
if p == 1, Pc = Pc(1:2:end); elseif p == 2, Pc = Pc(1:2:end,1:2:end); else, Pc = Pc(1:2:end,1:2:end,1:2:end); end
fc = filon_p(tc,Pc(:).',q,p);

%  ---- rigorous bound on the truncation error: |psi(t)| <= Phi(|L~t|^2)
%       (Proposition 4.1), integrated over the complement of the largest
%       ball |(L~'L~)^{1/2} t| <= R contained in the box ----
A   = S.Lt'*S.Lt;  A = 0.5*(A+A');
R   = min(T(:)./sqrt(diag(A\eye(p))));
lam = S.lmin;
Phi = @(c) sum(S.wu(:).*(1+lam*S.u(:)*c).^(-(m-1)/2).*exp(-lam*(S.u(:).^2)*c/2),1);
cst = 2*pi^(p/2)/gamma(p/2)/(2*pi)^p/sqrt(det(A));
tb  = cst*integral(@(r) Phi(r.^2).*r.^(p-1),R,Inf,'RelTol',1e-6,'AbsTol',0);

info = struct('T',T,'Tl',Tl,'Ng',Ng,'Ku',Ku,'boundarymax',bmax, ...
              'tailbound',tb,'discerr',abs(f-fc),'Kuchange',dK);
end

function P = evalblocks(Tg,S,blk)
%  psi at the columns of Tg, in blocks to limit memory
G = size(Tg,2);
P = zeros(1,G);
for i0 = 1:blk:G
   i1 = min(G,i0+blk-1);
   P(i0:i1) = lwzcf_eval(Tg(:,i0:i1),S);
end
end

function Tb = boxboundary(tg,p)
%  the nodes of the tensor grid that lie on the boundary of the box
if p == 1
   Tb = tg{1}([1 end]);
elseif p == 2
   a = tg{1}; b = tg{2};
   Tb = [ [a; b(1)*ones(size(a))] [a; b(end)*ones(size(a))] [a(1)*ones(size(b)); b] [a(end)*ones(size(b)); b] ];
else
   Tb = zeros(3,0);
   for j = 1:3
      o = setdiff(1:3,j);
      [X,Y] = ndgrid(tg{o(1)},tg{o(2)});
      for e = [1 numel(tg{j})]
         B = zeros(3,numel(X));
         B(j,:) = tg{j}(e);  B(o(1),:) = X(:)';  B(o(2),:) = Y(:)';
         Tb = [Tb B]; %#ok<AGROW>
      end
   end
end
end

function f = filon_p(tg,PSI,q,p)
%  Filon inversion (cubic interpolant, oscillation integrated exactly)
Ng = numel(tg{1});
N  = size(q,2);
f  = zeros(1,N);
if p == 1
   Wt = filonw(tg{1},q);                                 % N x Ng
   f  = real(Wt*PSI(:))/(2*pi);
elseif p == 2
   P2 = reshape(PSI,Ng,Ng);                              % (t1,t2)
   W1 = filonw(tg{1},q(1,:));
   W2 = filonw(tg{2},q(2,:));
   f  = real(sum((W1*P2).*W2,2)).'/(2*pi)^2;
else
   P3 = reshape(PSI,Ng,Ng*Ng);
   W1 = filonw(tg{1},q(1,:));
   W2 = filonw(tg{2},q(2,:));
   W3 = filonw(tg{3},q(3,:));
   for i = 1:N
      A = reshape(W1(i,:)*P3,Ng,Ng);                     % (t2,t3)
      f(i) = real(W2(i,:)*A*W3(i,:).')/(2*pi)^3;
   end
end
f = reshape(f,1,[]);
end

%======================================================================
function tf = isprop_(Sw,Sz)
%  true if Sw^{1/2} Sz Sw^{1/2} is proportional to the identity, i.e. Sz = s2 inv(Sw)
P = Sw*Sz;  m = size(P,1);  s2 = trace(P)/m;
tf = norm(P - s2*eye(m),'fro') <= 1e-10*abs(s2)*m;
end

function [f,info] = cf_prop(q,L,mu,Sw,Sz,n,opts)
%  Reduced inversion when St = Sw^{1/2} Sz Sw^{1/2} = s2*I_m.  With a = L~t,
%  C = a'a and B = a'mu~, the characteristic function is psi(t) = g(C,B),
%     g(C,B) = int (1+u s2 C)^{-(m-1)/2}
%              exp( u(B^2 - mu~'mu~ C)/(2(1+u s2 C)) + iuB - s2 u^2 C/2 ) f_n(u) du,
%  whose exponent is <= 0 by the Cauchy-Schwarz inequality.  With
%  s = (L~'L~)^{1/2} t, eta = (L~'L~)^{-1/2} L~'mu~, e = eta/|eta|,
%  qh = (L~'L~)^{-1/2} q, q1 = e'qh and kappa = |qh - q1 e|,
%     f(q) = (2pi)^{-(p+1)/2} |L~'L~|^{-1/2}
%            int int Re[ exp(-i s1 q1) g(s1^2+rho^2, |eta| s1) ]
%                    rho^{p-2} Lambda(kappa rho) drho ds1,
%  Lambda(x) = J_{(p-3)/2}(x)/x^{(p-3)/2}; for p = 1 there is no rho integral.
mu = mu(:); m = length(mu); p = size(L,2);
tol  = getopt(opts,'tol',1e-10);
Ku   = getopt(opts,'Ku',128);
Ns   = getopt(opts,'Ns',700);
ppan = getopt(opts,'ppan',8);
Swh = sqrtm(Sw);  Swh = real(0.5*(Swh+Swh'));
Lt  = Swh*L;  mut = Swh*mu;  St = Swh*Sz*Swh;  s2 = trace(St)/m;  mm = mut'*mut;
S   = lwzcf_setup(L,mu,Sw,Sz,n,Ku);          % u-nodes and weights (incl. chi2_n density)
u   = S.u(:)';  wu = S.wu(:)';
A   = Lt'*Lt;  A = 0.5*(A+A');  [V,D] = eig(A);  ev = diag(D);
Ahi = V*diag(ev.^-0.5)*V';
eta = Ahi*(Lt'*mut);  ne = norm(eta);
if ne > 0, e = eta/ne; else, e = [1; zeros(p-1,1)]; end
qh = Ahi*q;  q1 = e'*qh;                      % 1 x N
%  number of u-nodes: double Ku until g changes by less than 1e-12 at probe
%  points along s1 and along rho
r  = 2.^((-60:60)/8);
dK = NaN;
while Ku < getopt(opts,'Kumax',1024)
   g0 = [gfun(r.^2,ne*r) gfun(r.^2,0*r)];
   S2 = lwzcf_setup(L,mu,Sw,Sz,n,2*Ku);
   uo = u;  wo = wu;  u = S2.u(:)';  wu = S2.wu(:)';
   dK = max(abs([gfun(r.^2,ne*r) gfun(r.^2,0*r)] - g0));
   if dK < 1e-12, u = uo; wu = wo; break; end
   Ku = 2*Ku;
end
%  extents of g along s1 (rho = 0) and along rho (s1 = 0); the probe range
%  is extended until |g| < tol at its end
while abs(gfun(r(end)^2,ne*r(end))) >= tol || abs(gfun(r(end)^2,0)) >= tol
   if r(end) > 1e12, break; end
   r = [r r(end)*2.^((1:40)/8)];
end
K  = numel(r);
a1 = abs(gfun(r.^2,ne*r));
k  = find(a1 >= tol,1,'last');  if isempty(k), k = 1; end;  T1 = r(min(K,k+1))*1.15;
k  = find(a1 >= 1e-2,1,'last'); if isempty(k), k = 1; end;  L1 = r(min(K,k+1));
beta = max(4,log(4*T1/L1));
Ng = 3*floor((Ns-1)/3)+1;
s1 = T1*sinh(beta*linspace(-1,1,Ng))/sinh(beta);
W1 = filonw(s1,q1);                            % N x Ng
%  rigorous bound on the truncation error (Proposition 4.1 with
%  lambda_min = s2), over the complement of the ball |s| <= R
Phi = @(c) sum(wu(:).*(1+s2*u(:)*c).^(-(m-1)/2).*exp(-s2*(u(:).^2)*c/2),1);
tbnd = @(R) 2*pi^(p/2)/gamma(p/2)/(2*pi)^p/sqrt(prod(ev)) ...
            *integral(@(r) Phi(r.^2).*r.^(p-1),R,Inf,'RelTol',1e-6,'AbsTol',0);
info = struct('T',T1,'Ku',Ku,'Kuchange',dK,'tailbound',tbnd(T1),'discerr',NaN);
if p == 1
   f = real(W1*gfun(s1.^2,ne*s1).')/(2*pi)/sqrt(prod(ev));
   f = reshape(f,1,[]);
   return
end
kap = sqrt(max(sum((qh - e*q1).^2,1),0));     % 1 x N
ar = abs(gfun(r.^2,0*r));
k  = find(ar >= tol,1,'last');  if isempty(k), k = 1; end;  Tr = r(min(K,k+1))*1.15;
k  = find(ar >= 1e-2,1,'last'); if isempty(k), k = 1; end;  Lr = r(min(K,k+1));
info.T = [T1 Tr];
info.tailbound = tbnd(min(T1,Tr));
betar = max(3,log(4*Tr/Lr));
%  radial panels: graded towards the origin, and shorter than half a period
%  of the Bessel kernel at the largest kappa
np_ = 30;
while true
   b = Tr*sinh(betar*linspace(0,1,np_+1))/sinh(betar);
   if max(diff(b))*max(kap) <= pi || np_ > 4000, break; end
   np_ = ceil(1.3*np_);
end
[xg,wg] = gauleg_(ppan);
hb  = 0.5*diff(b);  cb = 0.5*(b(1:end-1)+b(2:end));
rho = reshape(cb(:)' + hb(:)'.*xg(:),1,[]);     % (ppan x np_) -> 1 x Nr
wr  = reshape(hb(:)'.*wg(:),1,[]);
nu  = (p-3)/2;
X   = kap(:)*rho;                               % N x Nr
Lam = besselj(nu,X)./X.^nu;
Lam(X == 0) = 1/(2^nu*gamma(nu+1));
Kr  = Lam.*(wr.*rho.^(p-2));                    % N x Nr
%  g on the (s1,rho) grid, in blocks of s1 to limit memory
Nr = numel(rho);  G = zeros(Ng,Nr);
blk = max(1,floor(2e6/(Nr*Ku)));
for i0 = 1:blk:Ng
   i1 = min(Ng,i0+blk-1);
   s1b = s1(i0:i1).';
   G(i0:i1,:) = gfun(s1b.^2 + rho.^2, ne*s1b + 0*rho);
end
f = real(sum((W1*G).*Kr,2)).'/((2*pi)^((p+1)/2)*sqrt(prod(ev)));

   function y = gfun(C,B)
      %  g(C,B) for arrays C, B of the same size
      sz = size(C);  C = C(:);  B = B(:);
      d = 1 + C*(s2*u);                          % numel x Ku
      y = (d.^(-(m-1)/2) .* exp((B.^2*u - mm*C*u)./(2*d) + 1i*B*u - (s2/2)*C*(u.^2))) * wu.';
      y = reshape(y,sz);
   end
end

function W = filonw(t,q)
%  Filon weights with cubic interpolation on arbitrary (sorted) nodes:
%     int exp(-i t q_i) g(t) dt  ~  sum_j W(i,j) g(t_j),
%  where g is interpolated by a cubic through each group of four consecutive
%  nodes (t_0,...,t_3), (t_3,...,t_6), ...  (the number of nodes is 1 mod 3).
%  On a group [t_0,t_3] with H = t_3 - t_0 and s = (t-t_0)/H, the Lagrange
%  basis is cubic in s, and the moments M_j(x) = int_0^1 e^{-ixs} s^j ds,
%  j = 0,...,3, x = qH, are available in closed form, so the oscillatory
%  factor is integrated exactly.
q = q(:);                                    % N x 1
G = numel(t);
if mod(G-1,3) ~= 0
   error('lwzpdf_cf:nodes','the number of frequency nodes must be 1 mod 3.');
end
P  = (G-1)/3;
t0 = t(1:3:G-3);  H = t(4:3:G) - t0;         % 1 x P
s1 = (t(2:3:G-2)-t0)./H;  s2 = (t(3:3:G-1)-t0)./H;
x  = q*H;                                    % N x P
[M0,M1,M2,M3] = filonM(x);
ph = exp(-1i*(q*t0)).*H;                     % N x P
W = zeros(numel(q),G);
%  Lagrange basis coefficients C(j,k): l_k(s) = sum_j C(j,k) s^j, from the
%  inverse Vandermonde matrix of the nodes s = (0, s1, s2, 1)
for g = 1:P
   V = [0 0 0 1; s1(g)^3 s1(g)^2 s1(g) 1; s2(g)^3 s2(g)^2 s2(g) 1; 1 1 1 1];  % rows: nodes, cols: s^3..s^0
   C = inv(V);                               % C(j,k): coefficient of s^(4-j) in l_k
   idx = 3*(g-1)+(1:4);
   for k = 1:4
      W(:,idx(k)) = W(:,idx(k)) + ph(:,g).*(C(1,k)*M3(:,g)+C(2,k)*M2(:,g)+C(3,k)*M1(:,g)+C(4,k)*M0(:,g));
   end
end
end

function [M0,M1,M2,M3] = filonM(x)
%  M_j(x) = int_0^1 e^{-ixs} s^j ds, j = 0,...,3
M0 = zeros(size(x)); M1 = M0; M2 = M0; M3 = M0;
big = abs(x) >= 0.3;
xb = x(big);
E  = exp(-1i*xb);
M0(big) = (1 - E)./(1i*xb);
M1(big) = (E.*(1+1i*xb) - 1)./xb.^2;
M2(big) = E.*(1i./xb + 2./xb.^2 - 2i./xb.^3) + 2i./xb.^3;
M3(big) = E.*(1i./xb + 3./xb.^2 - 6i./xb.^3 - 6./xb.^4) + 6./xb.^4;
xs = x(~big);                                % series for small |x|
z  = -1i*xs;                                 % e^{-ixs} = sum z^k s^k/k!
S0 = zeros(size(xs)); S1 = S0; S2 = S0; S3 = S0; zk = ones(size(xs));
for k = 0:16
   if k > 0, zk = zk.*z/k; end
   S0 = S0 + zk/(k+1);  S1 = S1 + zk/(k+2);  S2 = S2 + zk/(k+3);  S3 = S3 + zk/(k+4);
end
M0(~big) = S0; M1(~big) = S1; M2(~big) = S2; M3(~big) = S3;
end

function v = getopt(o,name,default)
if isfield(o,name) && ~isempty(o.(name)), v = o.(name); else, v = default; end
end

function [x,w] = gauleg_(N)
%  Gauss-Legendre nodes/weights on (-1,1) by Golub-Welsch
b = (1:N-1)./sqrt(4*(1:N-1).^2-1);
J = diag(b,1)+diag(b,-1);
[Vj,Dj] = eig(J);
[x,idx] = sort(diag(Dj));
x = x'; w = 2*Vj(1,idx).^2;
end
