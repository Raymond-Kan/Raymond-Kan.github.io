function f = lwzpdf_ident(q,L,mu,Sw,Sz,n)
%LWZPDF_IDENT  Density of q = L'*W*z when Sz is proportional to inv(Sw).
%
%   f = lwzpdf_ident(q,L,mu,Sw,Sz,n)
%   f = lwzpdf_ident(q,L,mu,n)          (Sw = Sz = I_m)
%
%   Computes the density of q = L'*W*z, W ~ W_m(n,Sw), z ~ N_m(mu,Sz)
%   independent, with Sz = sigma^2*inv(Sw) for some sigma > 0 (this includes
%   Sw = Sz = I_m), and L an m x p matrix of rank p < m, from the
%   representations of Section 3.3 of Bodnar, Kan and Mazur (2026), in which
%   all the building blocks are (noncentral) chi-squared and normal variables:
%
%     p = 1 : the two-dimensional integral (59), with a normal kernel;
%     p > 1 : the three-dimensional integral (55)-(56), with a Bessel kernel.
%
%   At q = 0 the density is computed by LWZPDF_ZERO (eq. (39)).
%   The computation uses q = sigma*Lt'*Wt*zeta, with Lt = Sw^(1/2)*L,
%   Wt ~ W_m(n,I_m) and zeta ~ N_m(Sw^(1/2)*mu/sigma, I_m), so that
%   f(q) = sigma^(-p) f0(q/sigma), where f0 is the density in the identity case.
%
%   Input:
%     q   : p x N array of evaluation points (for p = 1, any vector)
%     L   : m x p matrix of constants (rank p < m)
%     mu  : m x 1 mean vector of z
%     Sw  : m x m covariance matrix of the Wishart matrix
%     Sz  : m x m covariance matrix of z, proportional to inv(Sw)
%     n   : degrees of freedom (real, n > m-1)
%
%   Output:
%     f   : 1 x N vector of density values
%
%   See also LWZPDF, LWZPDF_CF, LWZPDF_BESSEL.

mu = mu(:); m = length(mu); p = size(L,2);
if nargin == 4
   n = Sw;  Sw = eye(m);  Sz = eye(m);
end
P  = Sw*Sz;  s2 = trace(P)/m;                      % sigma^2
if norm(P - s2*eye(m),'fro') > 1e-10*abs(s2)*m
   error('lwzpdf_ident:prop','lwzpdf_ident requires Sz to be proportional to inv(Sw).');
end
sig = sqrt(s2);
L0 = L;  mu0 = mu;  Sw0 = Sw;  Sz0 = Sz;             % for q = 0 (LWZPDF_ZERO)
Swh = sqrtm(Sw);  Swh = real(0.5*(Swh+Swh'));
L   = Swh*L;                                         % L-tilde
mu  = Swh*mu/sig;                                    % mean of zeta = Sw^(1/2) z / sigma
if p == 1, q = q(:).'; end
q   = q/sig;
N = size(q,2);
f = zeros(1,N);
if p >= m
   error('lwzpdf_ident:p','lwzpdf_ident requires p < m; use WZPDF for p = m.');
end
LL  = L'*L;
dL  = sqrt(det(LL));
Bh  = sqrtm(LL\eye(p)); Bh = real(0.5*(Bh+Bh'));   % (L'L)^{-1/2}
muh = Bh*(L'*mu);                                   % mu-hat
d0  = mu'*mu - muh'*muh;                            % delta-hat, noncentrality of u-hat ~ chi2_{m-p}
if d0 < -1e-10*max(1,mu'*mu)
   error('lwzpdf_ident:delta','Negative noncentrality %g: inconsistent input.',d0);
end
d0  = max(d0,0);                                    % roundoff

if p == 1
   %  ---- eq. (59) with sigma = 1: q | (u1,r) ~ N(u1 alpha'mu, (alpha'alpha)(u1^2 + u1 r)) ----
   m1 = L'*mu;  s1 = sqrt(LL);
   for i = 1:N
      if q(i) ~= 0
         f(i) = integral2(@(u,u1) normpdf(q(i),m1*u1,s1*sqrt(u1.^2+u.*u1)) ...
                 .*chi2pdf(u1,n).*ncx2pdf(u,m-1,d0), 0,Inf,0,Inf, 'AbsTol',1e-12,'RelTol',1e-9);
      else
         f(i) = lwzpdf_zero(L0,mu0,Sw0,Sz0,n)*sig^p;    % (rescaled below)
      end
   end
else
   %  ---- eqs. (55)-(56) with sigma = 1 ----
   cc = exp(-log(dL) - (p/2)*log(2*pi) - gammaln(n/2) - (n/2-1)*log(2));
   for i = 1:N
      qh  = Bh*q(:,i);
      qq  = qh'*qh;
      if qq == 0
         f(i) = lwzpdf_zero(L0,mu0,Sw0,Sz0,n)*sig^p;    % (rescaled below)
      else
         mu1 = qh'*muh/sqrt(qq);                    % mean of w1
         d1  = max(muh'*muh - mu1^2,0);             % noncentrality of u-hat_1 ~ chi2_{p-1} (roundoff)
         f(i) = cc*integral3(@(u,u1,w1) kern(u,u1,w1,qq).*normpdf(w1-mu1) ...
                 .*ncx2pdf(u,m-p,d0).*ncx2pdf(u1,p-1,d1), 0,Inf,0,Inf,-Inf,Inf, ...
                 'AbsTol',1e-12,'RelTol',1e-8);
      end
   end
end

f = f/sig^p;                                         % back to q = sigma*q0

   function y = kern(u,u1,w1,qq)
      %  eq. (57) with v2 = w1^2 + u-hat_1 (scaled Bessel function)
      u2 = w1.^2 + u;
      zz = u1 + u2;
      a2 = sqrt(qq)*w1./u;
      bb = sqrt(qq)*sqrt(u2)./u;
      y  = exp(a2 + log(besselk((n-p)/2,bb,1)) - bb + (n-p)/4*log(qq*u2) ...
               - 0.5*log(u) - (n-1)/2*log(zz));
   end
end
