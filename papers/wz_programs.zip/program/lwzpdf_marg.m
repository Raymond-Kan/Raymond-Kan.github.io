function f = lwzpdf_marg(q,L,mu,Sw,Sz,n)
%LWZPDF_MARG  Density of q = L'*W*z by marginalizing the full-product density.
%
%   f = lwzpdf_marg(q,L,mu,Sw,Sz,n)
%
%   For an m x p matrix L of rank p with m-p in {1,2}, completes L to a
%   nonsingular H = [L, L0] with L0 orthogonal to L, obtains the density of
%   H'*W*z from Theorem 2.1 (via WZPDF, a two-dimensional integral), and
%   integrates out the last m-p coordinates numerically.  This yields an
%   (m-p+2)-dimensional integral: three-dimensional for p = m-1 and
%   four-dimensional for p = m-2 (Remark 4.4 of Bodnar, Kan and Mazur, 2026).
%
%   Input:
%     q   : p x N array of evaluation points
%     L   : m x p matrix of constants (rank p, m-p in {1,2})
%     mu  : m x 1 mean vector of z
%     Sw  : m x m covariance matrix of the Wishart matrix
%     Sz  : m x m covariance matrix of the normal vector
%     n   : degrees of freedom (real, n > m-1)
%
%   Output:
%     f   : 1 x N vector of density values
%
%   See also WZPDF, LWZPDF.

mu = mu(:); m = length(mu); p = size(L,2);
if p == 1, q = q(:).'; end
N = size(q,2);
k = m-p;
if k < 1 || k > 2
   error('lwzpdf_marg:p','lwzpdf_marg requires m-p in {1,2}.');
end
L0  = null(L');
H   = [L L0];
Hi  = H\eye(m);
%  h = H'*W*z = W*z* with W* ~ W_m(n,H'SwH), z* ~ N(H^{-1}mu, H^{-1}Sz H^{-1}')
mus = Hi*mu;
Sws = H'*Sw*H;   Sws = 0.5*(Sws+Sws');
Szs = Hi*Sz*Hi'; Szs = 0.5*(Szs+Szs');
f = zeros(1,N);
for i = 1:N
   qi = q(:,i);
   if k == 1
      %  purely relative tolerance: the density can be far below any fixed
      %  absolute tolerance in the tails or for large p
      f(i) = integral(@(h2) dens1(h2,qi), -Inf, Inf, 'AbsTol',0,'RelTol',1e-8);
   else
      f(i) = integral2(@(h2,h3) dens2(h2,h3,qi), -Inf,Inf,-Inf,Inf, 'AbsTol',0,'RelTol',1e-7);
   end
end

   function y = dens1(h2,qi)
      hh = [repmat(qi,1,numel(h2)); h2(:)'];
      y  = reshape(wzpdf(hh,mus,Sws,Szs,n),size(h2));
   end
   function y = dens2(h2,h3,qi)
      hh = [repmat(qi,1,numel(h2)); h2(:)'; h3(:)'];
      y  = reshape(wzpdf(hh,mus,Sws,Szs,n),size(h2));
   end
end
