function [f,se] = lwzpdf_mc(q,L,mu,Sw,Sz,n,nobs,seed)
%LWZPDF_MC  Conditional Monte Carlo estimate of the density of q = L'*W*z.
%
%   [f,se] = lwzpdf_mc(q,L,mu,Sw,Sz,n,nobs,seed)
%
%   Unbiased simulation estimate of the density of q = L'*W*z, where
%   W ~ W_m(n,Sw) and z ~ N_m(mu,Sz) are independent and L is m x p of rank
%   p (use L = eye(m) for the full product W*z).  The estimator averages the
%   exact conditional density of q given W,
%
%       f(q) = E_W[ N_p(q; L'*W*mu, L'*W*Sz*W*L) ],
%
%   over nobs Wishart draws, so no kernel smoothing is involved.  W is drawn
%   by the Bartlett decomposition (real n allowed).
%
%   Input:
%     q    : p x N array of evaluation points (for p = 1, any vector)
%     L    : m x p matrix of constants (rank p)
%     mu   : m x 1 mean vector of z
%     Sw   : m x m covariance matrix of the Wishart matrix
%     Sz   : m x m covariance matrix of the normal vector
%     n    : degrees of freedom (real, n > m-1)
%     nobs : number of Wishart draws (default 1e5)
%     seed : seed of a private random stream (default 12345)
%
%   Output:
%     f    : 1 x N vector of estimated density values
%     se   : 1 x N vector of Monte Carlo standard errors
%
%   The standard error is meaningful only when the conditional density has a
%   finite second moment over W.  For example, for the full product at q = 0
%   the conditional density is proportional to 1/|W|, whose mean is finite
%   only for n > m+1 and whose variance is finite only for n > m+3.
%
%   See also WZRND, LWZPDF, WZPDF.

if nargin < 7 || isempty(nobs), nobs = 1e5; end
if nargin < 8 || isempty(seed), seed = 12345; end
mu = mu(:); m = length(mu); p = size(L,2);
if p == 1, q = q(:).'; end
N = size(q,2);
%  use a private stream for reproducibility; restore the caller's stream on exit
rs   = RandStream('mt19937ar','Seed',seed);
prev = RandStream.getGlobalStream;
RandStream.setGlobalStream(rs);
cleanup = onCleanup(@() RandStream.setGlobalStream(prev));
C  = chol(Sw,'lower');
acc  = zeros(1,N);
acc2 = zeros(1,N);
twopi_p = (2*pi)^(p/2);
T = zeros(m,m);
for r = 1:nobs
   for i = 1:m
      T(i,i) = sqrt(2*randg((n-i+1)/2));           % chi_{n-i+1}
      if i > 1
         T(i,1:i-1) = randn(1,i-1);
      end
   end
   A = C*T;
   W = A*A';
   LW  = L'*W;                                   % p x m
   mn  = LW*mu;                                  % p x 1
   cov = LW*Sz*LW';                              % p x p
   R = chol(0.5*(cov+cov'));                     % upper
   d = q - mn;                                   % p x N
   sol = R'\d;
   quad = sum(sol.^2,1);
   val = exp(-0.5*quad)/(twopi_p*prod(diag(R)));
   acc  = acc + val;
   acc2 = acc2 + val.^2;
end
f  = acc/nobs;
se = sqrt(max(acc2/nobs - f.^2,0)/nobs);
end
