function f0 = lwzpdf_zero(L,mu,Sw,Sz,n)
%LWZPDF_ZERO  Density of q = L'*W*z at q = 0_p, for p < m.
%
%   f0 = lwzpdf_zero(L,mu,Sw,Sz,n)
%
%   W ~ W_m(n,Sw), z ~ N_m(mu,Sz) independent, L an m x p matrix of rank
%   p < m.  The value is finite for every n > m-1.  Used by LWZPDF,
%   LWZPDF_BESSEL and LWZPDF_IDENT for the exact zero columns of q.
%
%  Density at q = 0_p for p < m, eq. (39) of the paper:
%    f(0_p) = Gamma((n-p)/2) / (2^p pi^(p/2) Gamma(n/2) |L~'L~|^(1/2))
%             * E[ u^((n-p-1)/2) / (v2+u)^((n-1)/2) ],
%  with u = y'Dy and v2+u = y'(D+Lh*Lh')y, y ~ N(muy,I_m) (Section 3.1 and
%  Appendix A.2).  The expectation is finite for every n > m-1 when p < m:
%  near y = 0 the integrand behaves like |y|^(-p), and the possibly negative
%  power (n-p-1)/2 of u, which has m-p degrees of freedom, is integrable
%  because n > m-1 >= 2p-m+1.
mu = mu(:); m = numel(mu); p = size(L,2);
if p >= m, error('lwzpdf_zero:p','lwzpdf_zero requires p < m.'); end
if ~(isscalar(n) && isreal(n) && n > m-1)
   error('lwzpdf_zero:n','n must be a real scalar with n > m-1.');
end
S1  = sqrtm(Sw);  S1  = real(0.5*(S1+S1'));
Szh = sqrtm(Sz);  Szh = real(0.5*(Szh+Szh'));
L1  = S1*L;  LL = L1'*L1;  LLi = LL\eye(p);
A   = Szh*S1*(eye(m)-L1*LLi*L1')*S1*Szh;  A = 0.5*(A+A');
[P,D] = eig(A);
[ev,ix] = sort(diag(D));  P = P(:,ix);      % ascending: A has rank m-p, so
D = diag([zeros(p,1); ev(p+1:m)]);           % the first p eigenvalues are zero
muy = P'*(Szh\mu(:));
Bh  = sqrtm(LLi);  Bh = real(0.5*(Bh+Bh'));
Lh  = P'*Szh*S1*L1*Bh;
B   = D + Lh*Lh';  B = 0.5*(B+B');
c0  = exp(gammaln((n-p)/2)-gammaln(n/2) - sum(log(diag(chol(LL)))))/(2^p*pi^(p/2));
a   = (n-p-1)/2;  b = (n-1)/2;
if p < m-1
   %  QRATINTNC (Bao and Kan, 2013); a > 0 here because n > m-1 > p+1.
   %  Its default absolute tolerance 1e-10 is too loose when the
   %  expectation is small or a has a small fractional part.
   f0 = c0*qratintnc(D,B,muy,a,b,1e-16);
else
   %  p = m-1: D = diag(0,...,0,d) has rank one and u = d*y_m^2, which gives
   %  a one-dimensional integral that is valid for every a > -1/2, including
   %  a < 0 (m-1 < n < m), which QRATINTNC does not cover.  Writing
   %  (y'By)^(-b) = int_0^Inf t^(b-1) exp(-t y'By) dt/Gamma(b),
   %    E[u^a/(y'By)^b] = d^a/Gamma(b) int_0^Inf t^(b-1) |I+2tB|^(-1/2)
   %        exp(-muy'muy/2 + muy'(I+2tB)^(-1)muy/2) E[|Y_m|^(2a)] dt,
   %  where Y ~ N((I+2tB)^(-1)muy, (I+2tB)^(-1)), and for Y_m ~ N(nu,s2)
   %    E[|Y_m|^(2a)] = (2 s2)^a Gamma(a+1/2)/sqrt(pi) exp(-x) 1F1(a+1/2;1/2;x),
   %  x = nu^2/(2 s2).  On [0,1] the substitution t = s^(1/b) removes the
   %  singularity t^(b-1) at the origin.
   d   = D(m,m);
   [U,Lam] = eig(B);  lam = diag(Lam);
   um  = U(m,:)';  mv = U'*muy;
   I   = integral(@(s) hrank1(s.^(1/b))/b,0,1,'AbsTol',0,'RelTol',1e-11) ...
       + integral(@(t) t.^(b-1).*hrank1(t),1,Inf,'AbsTol',0,'RelTol',1e-11);
   f0  = c0*d^a/gamma(b)*I;
end
   function y = hrank1(t)
      t  = t(:).';
      dd = 1 + 2*lam*t;                                  % m x K
      s2 = sum(um.^2./dd,1);
      nu = sum((um.*mv)./dd,1);
      x  = nu.^2./(2*s2);
      lM = a*log(2*s2) + gammaln(a+0.5) - 0.5*log(pi) + log_kummer(a+0.5,x);
      y  = exp(-0.5*sum(log(dd),1) - 0.5*(muy'*muy) + 0.5*sum(mv.^2./dd,1) + lM);
      y(~isfinite(t)) = 0;
   end
end

function y = log_kummer(c,x)
%  log( exp(-x) 1F1(c;1/2;x) ) for c > 0 and x >= 0 (row vector), by the
%  series of 1F1, whose terms are positive, summed on the log scale
K  = ceil(max(x) + 12*sqrt(max(x)) + 40);
k  = (0:K-1)';
lt = [zeros(1,numel(x)); cumsum(log(c+k) - log(0.5+k) - log(k+1) + log(x),1)];
mx = max(lt,[],1);
y  = mx + log(sum(exp(lt-mx),1)) - x;
end
