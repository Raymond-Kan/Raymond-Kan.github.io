function [y,ok] = qpdfser(q,a0,a1,d,mu,maxit)
%QPDFSER  Density of a quadratic form in normal variables by Ruben's series.
%
%   y = qpdfser(q,a0,a1,d)
%   y = qpdfser(q,a0,a1,d,mu)
%   y = qpdfser(q,a0,a1,d,mu,maxit)
%   [y,ok] = qpdfser(...)
%
%   Computes the density at q of Q = a0 + a1'x + x'diag(d)x, x ~ N(mu,I_m)
%   (mu = 0 if omitted), d_i > 0, by the chi-squared mixture of Ruben (1962)
%   (Appendix A.2 of Bodnar, Kan and Mazur, 2026).  After completing the
%   square, Q = Qt + c0 with Qt = sum_i d_i X_i, X_i ~ chi2_1(delta_i)
%   independent, and
%
%       f_Qt(x) = sum_{i>=0} w_i f_{m+2i}(x/beta)/beta,
%
%   with beta = 0.90625*min(d) <= min(d), so that the weights w_i are
%   nonnegative and sum to one.
%
%   Numerical method.  The weights and the chi-squared densities are carried
%   on the log scale (the weights with a running scale factor), so that
%   neither exp(-sum(delta)/2) nor the chi-squared densities underflow for
%   large noncentralities or large q.  When all d_i are equal, Qt/d is
%   noncentral chi-squared and NCX2PDF is used directly.  The series is
%   summed until the terms decrease below 1e-16 times the partial sum; ok is
%   false for the points where this did not happen within maxit terms
%   (default 1e4; a warning is issued, and the partial sum is returned).  The
%   number of terms needed grows with the noncentrality and with the spread
%   max(d)/min(d) of the coefficients.  Points at which an upper bound on the density, from
%   the generating function of the weights, is below 1e-300 are set to zero
%   without summing the series.
%
%   Input:
%     q   : array of evaluation points
%     a0  : scalar
%     a1  : m x 1 vector
%     d   : m x 1 vector of positive coefficients
%     mu  : m x 1 mean of x (optional, default 0; [] for 0)
%     maxit : largest number of terms of the series (optional, default 1e4)
%
%   Output:
%     y   : density values, same size as q
%     ok  : logical array, true where the series converged
%
%   This is a revised version of the routine of the same name in program\wz:
%   same interface and series, evaluated on the log scale.

d  = d(:);  a1 = a1(:);  m = length(d);
if any(~(d > 0))
   error('qpdfser:d','qpdfser requires d_i > 0 for all i.');
end
if nargin < 6 || isempty(maxit), maxit = 1e4; end
if nargin >= 5 && ~isempty(mu)
   mu  = mu(:);
   mud = mu.*d;
   a0  = a0 + a1'*mu + mu'*mud;                  % convert to the central case
   a1  = a1 + 2*mud;
end
delta = a1.^2./(4*d.^2);
sd    = sum(delta);
x     = q - a0 + sum(delta.*d);                  % Qt = Q - a0 + sum(delta.*d)
y  = zeros(size(q));
ok = true(size(q));

if m == 1 || max(d) - min(d) <= 1e-12*max(d)
   %  equal coefficients: Qt/d ~ chi2_m(sd)
   dd = mean(d);
   ii = x > 0;
   y(ii) = ncx2pdf(x(ii)/dd,m,sd)/dd;
   if m == 2 && sd == 0
      y(x == 0) = 1/(2*dd);
   end
   return
end

beta = 0.90625*min(d);
gam  = beta./d;   gam0 = 1 - gam;                % 0 < gam <= 1, 0 <= gam0 < 1
k    = m/2;
ii   = find(x > 0);
xx   = x(ii);  xx = xx(:).';
z    = xx/(2*beta);
%  points where the density is negligible (< 1e-300) are skipped.  With the
%  generating function G(s) = sum_i w_i s^i, finite for 1 < s < 1/max(gam0),
%  w_i <= G(s) s^{-i} and sum_i y^i/Gamma(k+i) <= y^{1-k} e^y (k >= 1) give
%     2 beta f_Qt(x) <= G(s) s^{k-1} exp(-z(1-1/s)).
if m >= 2
   s   = 2/(1+max(gam0));
   e1  = 1 - 1/s;
   lG  = -k*log(s) - 0.5*sum(log(1-e1./gam)) + sum(delta.*e1./(2*(gam-e1)));
   lbd = lG + (k-1)*log(s) - z*e1 - log(2*beta);
   keep = lbd > -690;
   ii = ii(keep);  xx = xx(keep);  z = z(keep);
end
lz   = log(z);
%  weights: b_i = exp(ls) * bt_i, recursion of Ruben (1962) on the scaled values
ls   = -sd/2 + 0.5*sum(log(gam));               % log of b_0
bt   = 1;
p1   = zeros(m,1);  q1 = zeros(m,1);
delta1 = delta.*gam;
lg   = (k-1)*lz - z - gammaln(k);               % log gamma(k) density at z
lterm = ls + log(bt) + lg;
lmax = lterm;                                    % running log-sum-exp of the terms
ssum = ones(size(z));                            % sum of exp(lterm_i - lmax)
lprev = lterm;
active = true(size(z));
tol = 1e-16;
for i = 1:maxit
   p1 = bt + p1;
   q1 = delta1.*p1 + gam0.*q1;
   p1 = gam0.*p1;
   bt = sum(p1+q1)/(2*i);
   %  rescale to keep the recursion in range
   sc = max(abs([p1; q1; bt]));
   if sc > 1e200 || (sc > 0 && sc < 1e-200)
      p1 = p1/sc;  q1 = q1/sc;  bt = bt/sc;  ls = ls + log(sc);
   end
   if bt <= 0, break; end                        % only when all delta = 0 and all gam0 = 0
   lg = lg + lz - log(k+i-1);                    % log gamma(k+i) density at z
   lterm = ls + log(bt) + lg;
   a = active;
   lnew = max(lmax(a),lterm(a));
   ssum(a) = ssum(a).*exp(lmax(a)-lnew) + exp(lterm(a)-lnew);
   lmax(a) = lnew;
   %  stop when the terms decrease and are negligible
   done = a & (lterm < lprev) & (lterm - lmax - log(ssum) < log(tol));
   active(done) = false;
   lprev = lterm;
   if ~any(active), break; end
end
if any(active)
   ok(ii(active)) = false;
   warning('qpdfser:conv','Ruben series did not converge within %d terms at %d point(s).',maxit,nnz(active));
end
y(ii) = exp(lmax + log(ssum))/(2*beta);
if m == 2
   y(x == 0) = exp(-sd/2 + 0.5*sum(log(gam)))*gampdf(0,k)/(2*beta);
end
end
