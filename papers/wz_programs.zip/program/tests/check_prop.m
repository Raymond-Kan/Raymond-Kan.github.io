function check_prop(logfile)
%CHECK_PROP  Section 3.3 with Sz = sigma^2*inv(Sw): LWZPDF_IDENT against the
%   reduced CF inversion (Remark 4.5), eq. (39) at the origin, and
%   conditional Monte Carlo.
here = fileparts(mfilename('fullpath')); addpath(fileparts(here));
fid = fopen(logfile,'w');
m = 5; n = 10; mu = (1:m)'/m;               % moderate noncentrality (as in the timing table)
rs = RandStream('mt19937ar','Seed',7);
A = randn(rs,m); Sw = A*A'/m + 0.5*eye(m); s2 = 0.7; Sz = s2*inv(Sw); Sz = 0.5*(Sz+Sz');
Ls = {ones(m,1), [eye(2); ones(m-2,2)/2], [eye(3); ones(m-3,3)/3], [eye(4); ones(1,4)/4]};
for p = 1:4
   L = Ls{p};
   q = n*L'*Sw*mu + 0.5*sqrt(n*(n+1)*diag(L'*Sw*Sz*Sw*L) + n*(L'*Sw*mu).^2).*((-1).^(1:p))';
   tic; fi = lwzpdf_ident(q,L,mu,Sw,Sz,n); ti = toc;
   tic; fc = lwzpdf_cf(q,L,mu,Sw,Sz,n); tc = toc;
   [fm,se] = lwzpdf_mc(q,L,mu,Sw,Sz,n,1e6);
   fprintf(fid,'p=%d  Sec 3.3: %.8g (%.1fs)  CF: %.8g (%.2fs)  rel.diff %.1e   MC: %.6g (%.1f s.e.)\n', ...
      p,fi,ti,fc,tc,fi/fc-1,fm,(fm-fi)/se);
end
%  origin, p = 2: Section 3.3 (QRATINTNC in the identity form) against eq. (39) in LWZPDF
L = Ls{2};
f1 = lwzpdf_ident([0;0],L,mu,Sw,Sz,n); f2 = lwzpdf([0;0],L,mu,Sw,Sz,n);
fprintf(fid,'q=0, p=2: Sec 3.3 %.10g   eq.(39) %.10g   rel.diff %.1e\n',f1,f2,f1/f2-1);
%  identity covariances: the rows of Table 2, recomputed with the new code
V = load(fullfile(here,'results','exp_validation.mat'));
Lv = {ones(m,1), [1 0;0 1;1 1;0 1;1 0]};
for i = 1:size(V.rows,1)
   if strncmp(V.rows{i,1},'Identity',8)
      q = V.rows{i,9}(:);
      f = lwzpdf(q,Lv{numel(q)},(1:m)',eye(m),eye(m),n,'proportional');
      fprintf(fid,'Table 2 "%s" (%s): stored %.10g  now %.10g  rel.diff %.1e\n',V.rows{i,1},V.rows{i,2},V.rows{i,3},f,f/V.rows{i,3}-1);
   end
end
fprintf(fid,'PROP-DONE\n'); fclose(fid);
end
