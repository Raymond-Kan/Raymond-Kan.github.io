function check_regression(logfile)
%CHECK_REGRESSION  Regression tests: hard inputs, exact values, identities.
%
%   check_regression(logfile)
%
%   1. quadratic-form series with a large noncentrality (QPDFSER)
%   2. full-product density with a large mean (WZPDF)
%   3. density at the origin by every deterministic route, against the closed
%      form for the centered proportional case
%   4. characteristic function at very high frequency, psi(0) = 1,
%      psi(-t) = conj(psi(t)), |psi| <= 1
%   5. first two moments of q, from the density
%   6. invariance f_{B'q}(x) = f_q(inv(B')x)/|det B| and symmetry for mu = 0
%   7. non-commuting covariance matrices: routes against each other and MC
%   8. CF inversion near the origin for slow decay of psi
here = fileparts(mfilename('fullpath')); addpath(fileparts(here));
fid = fopen(logfile,'w'); pr = @(varargin) fprintf(fid,varargin{:});
warning('off','MATLAB:integral:MaxIntervalCountReached');

%  ---- 1. QPDFSER ----
pr('1. qpdfser\n');
pr('   chi2_2(1600) at 1602: %.15g   ncx2pdf %.15g\n', ...
   qpdfser(1602,0,[0;0],[1;1],[40;0]), ncx2pdf(1602,2,1600));
d = [2;0.7];
for mu = {[1;-0.5],[30;-12]}
   mm = mu{1}; delta = mm.^2;                       % Q = sum d_i (y_i)^2, y ~ N(mu,I)
   EQ = sum(d.*(1+delta));  SQ = sqrt(sum(2*d.^2.*(1+2*delta)));
   x  = EQ + SQ*linspace(-3,5,9);  x = x(x > 0);
   y  = qpdfser(x,0,[0;0],d,mm);
   yr = arrayfun(@(xx) convq(xx,d,delta), x);
   pr('   d = %s, noncentralities %s: max rel diff to direct convolution %.2e\n', ...
      mat2str(d'),mat2str(delta',4),max(abs(y-yr)./yr));
end
%  ---- 2. WZPDF with a large mean ----
pr('2. wzpdf, large mean\n');
f  = wzpdf([160;0],[40;0],eye(2),eye(2),4);
[fm,se] = lwzpdf_mc([160;0],eye(2),[40;0],eye(2),eye(2),4,2e5,4831);
pr('   f = %.15g   MC %.6g (s.e. %.2g, z = %.2f)\n',f,fm,se,(f-fm)/se);
B = load(fullfile(here,'results','exp_bivariate.mat'));
f1 = wzpdf(B.qt,B.mu,B.Sw,B.Sz,B.n);
pr('   Table 1 points: max rel diff to stored values %.2e\n',max(abs(f1-B.f_thm)./B.f_thm));
[X1,X2] = meshgrid(B.x1,B.x2);
F = reshape(wzpdf([X1(:)';X2(:)'],B.mu,B.Sw,B.Sz,B.n),size(X1));
pr('   Figure 2 grid: max abs diff / max %.2e\n',max(abs(F-B.F),[],'all')/max(B.F(:)));

%  ---- 3. origin, every route ----
pr('3. density at the origin (centered, Sz = s2 inv(Sw))\n');
rs = RandStream('mt19937ar','Seed',11);
for c = {{2,1,1.2},{2,1,1.8},{2,1,4},{3,1,2.3},{3,2,2.3},{4,2,3.5},{5,3,4.2},{5,4,6}}
   [m,p,n] = c{1}{:};
   A = randn(rs,m); Sw = A*A'/m + 0.5*eye(m); s2 = 0.6; Sz = s2*inv(Sw); Sz = 0.5*(Sz+Sz');
   L = randn(rs,m,p); mu = zeros(m,1);
   fx = origin_exact(L,Sw,s2,n);
   fa = lwzpdf(zeros(p,1),L,mu,Sw,Sz,n);
   fi = lwzpdf_ident(zeros(p,1),L,mu,Sw,Sz,n);
   s = sprintf('m=%d p=%d n=%.1f: exact %.12g  auto %.1e  proportional %.1e',m,p,n,fx,fa/fx-1,fi/fx-1);
   if p <= 2, s = [s sprintf('  bessel %.1e',lwzpdf_bessel(zeros(p,1),L,mu,Sw,Sz,n)/fx-1)]; end
   pr('   %s\n',s);
end
L = [1;0]; mu = zeros(2,1);
for n = [1.2 1.8 2 4]
   pr('   m=2, L=[1;0], mu=0, Sw=Sz=I, n=%.1f: auto %.15g  bessel %.15g  proportional %.15g\n',n, ...
      lwzpdf(0,L,mu,eye(2),eye(2),n),lwzpdf_bessel(0,L,mu,eye(2),eye(2),n),lwzpdf_ident(0,L,mu,eye(2),eye(2),n));
end

%  ---- 4. characteristic function ----
pr('4. characteristic function\n');
t = [0 1 10 1e3 1e6 1e8 -1e8];
psi = lwzcf(t,[1;0],[0;0],eye(2),eye(2),4);
pr('   m=2,n=4: psi(%s) = %s\n',mat2str(t),mat2str(psi,4));
m = 3; A = randn(rs,m); Sw = A*A'/m+0.3*eye(m); A = randn(rs,m); Sz = A*A'/m+0.3*eye(m); mu = [3;-2;1]*5;
L = randn(rs,m,2); T = [0 0; 0.3 -0.7; -0.3 0.7; 50 20; 1e5 -3e4; 1e9 1e9]';
psi = lwzcf(T,L,mu,Sw,Sz,3.5);
pr('   general m=3: psi(0) = %s, |psi(t)+... conj| = %.1e, max|psi| = %.6f, finite: %d\n', ...
   num2str(psi(1)), abs(psi(2)-conj(psi(3))), max(abs(psi)), all(isfinite(psi)));

%  ---- 5. moments ----
pr('5. first two moments (p = 1, from the density on a grid)\n');
m = 3; n = 8; mu = [1;-0.5;2]; A = randn(rs,m); Sw = A*A'/m+0.5*eye(m); A = randn(rs,m); Sz = A*A'/m+0.5*eye(m);
L = [1;0.5;-1];
Eq = n*L'*Sw*mu;
Vq = n*(n+1)*L'*Sw*Sz*Sw*L + n*(L'*Sw*mu)^2 + n*(trace(Sw*Sz)+mu'*Sw*mu)*(L'*Sw*L);
x  = Eq + sqrt(Vq)*linspace(-12,25,8001);
f  = lwzpdf_cf(x,L,mu,Sw,Sz,n);
m0 = trapz(x,f); m1 = trapz(x,x.*f)/m0; v1 = trapz(x,(x-m1).^2.*f)/m0;
pr('   mass %.8f   mean %.8g (exact %.8g)   variance %.8g (exact %.8g)\n',m0,m1,Eq,v1,Vq);

%  ---- 6. invariance and symmetry ----
pr('6. invariance and symmetry\n');
m = 4; n = 7; mu = [1;2;-1;0.5]; A = randn(rs,m); Sw = A*A'/m+0.5*eye(m); A = randn(rs,m); Sz = A*A'/m+0.5*eye(m);
L = randn(rs,m,2); Bm = [1 0.5; -0.3 2]; x = [3;-4];
fa = lwzpdf_cf(x,L*Bm,mu,Sw,Sz,n);
fb = lwzpdf_cf(Bm'\x,L,mu,Sw,Sz,n)/abs(det(Bm));
pr('   f_{B''q}(x) %.12g   f_q(inv(B'')x)/|B| %.12g   rel.diff %.1e\n',fa,fb,fa/fb-1);
f1 = lwzpdf_cf([2 -2],L(:,1),zeros(m,1),Sw,Sz,n);
pr('   mu = 0, p = 1: f(2) %.12g  f(-2) %.12g  rel.diff %.1e\n',f1(1),f1(2),f1(1)/f1(2)-1);
f2 = wzpdf([1 -1;2 -2;-1 1;0.5 -0.5],zeros(m,1),Sw,Sz,n);
pr('   mu = 0, p = m: f(q) %.12g  f(-q) %.12g  rel.diff %.1e\n',f2(1),f2(2),f2(1)/f2(2)-1);

%  ---- 7. non-commuting covariance matrices ----
pr('7. non-commuting covariance matrices (m = 3)\n');
m = 3; n = 6; mu = [1;-1;2]; A = randn(rs,m); Sw = A*A'/m+0.4*eye(m); A = randn(rs,m); Sz = A*A'/m+0.4*eye(m);
pr('   |Sw*Sz - Sz*Sw| = %.2f\n',norm(Sw*Sz-Sz*Sw));
L1 = [1;2;-1]; L2 = [1 0;0 1;1 -1];
q1 = n*L1'*Sw*mu + 2; q2 = n*L2'*Sw*mu + [1;-2];
[fc,info] = lwzpdf_cf(q1,L1,mu,Sw,Sz,n);
fb = lwzpdf_bessel(q1,L1,mu,Sw,Sz,n);
[fm,se] = lwzpdf_mc(q1,L1,mu,Sw,Sz,n,4e5);
pr('   p=1: cf %.10g  bessel %.10g (rel %.1e)  MC %.6g (z = %.2f)  [Ku %d, tail bound %.1e, disc. %.1e]\n', ...
   fc,fb,fc/fb-1,fm,(fc-fm)/se,info.Ku,info.tailbound,info.discerr);
fc = lwzpdf_cf(q2,L2,mu,Sw,Sz,n);
fg = lwzpdf_marg(q2,L2,mu,Sw,Sz,n);
[fm,se] = lwzpdf_mc(q2,L2,mu,Sw,Sz,n,4e5);
pr('   p=2: cf %.10g  marginal %.10g (rel %.1e)  MC %.6g (z = %.2f)\n',fc,fg,fc/fg-1,fm,(fc-fm)/se);
q3 = n*Sw*mu + [1;-2;1];
ff = wzpdf(q3,mu,Sw,Sz,n); fc = lwzpdf_cf(q3,eye(m),mu,Sw,Sz,n);
[fm,se] = lwzpdf_mc(q3,eye(m),mu,Sw,Sz,n,4e5);
pr('   p=3=m: Thm 2.1 %.10g  cf %.10g (rel %.1e)  MC %.6g (z = %.2f)\n',ff,fc,fc/ff-1,fm,(ff-fm)/se);

%  ---- 8. CF near the origin, slow decay ----
pr('8. CF inversion near the origin (slow decay of psi)\n');
m = 4; L = [eye(2);1 1;0 1]; mu = (1:m)'/2; Sw = 0.5*eye(m)+0.5; Sz = 0.2*eye(m)+0.8; n = 3.1;
f0 = lwzpdf([0;0],L,mu,Sw,Sz,n);
[fc,info] = lwzpdf_cf([0 1e-5; 0 1e-5],L,mu,Sw,Sz,n);
pr('   m=4,p=2,n=3.1: eq.(39) at 0: %.10g   cf at 0: %.10g (rel %.1e)   cf at 1e-5: %.10g\n', ...
   f0,fc(1),fc(1)/f0-1,fc(2));
pr('      [Ku %d, extrapolated %s, tail bound %.1e, disc. %s]\n',info.Ku,mat2str(info.extrapolated),info.tailbound,mat2str(info.discerr,2));
m = 2; L = [1;2]; mu = [0.5;1]; Sw = 0.5*eye(2)+0.5; Sz = 0.2*eye(2)+0.8;
for n = [1.2 2 3]
   qq = [0.2 1 3];
   fc = lwzpdf_cf(qq,L,mu,Sw,Sz,n); fb = lwzpdf_bessel(qq,L,mu,Sw,Sz,n);
   pr('   m=2,p=1,n=%.1f: cf/bessel - 1 = %s\n',n,mat2str(fc./fb-1,3));
end
pr('REG-DONE\n'); fclose(fid);
end

function f = origin_exact(L,Sw,s2,n)
%  closed form for mu = 0 and Sz = s2*inv(Sw), p < m
m = size(L,1); p = size(L,2); A = L'*Sw*L;
f = exp(gammaln((n-p)/2) + gammaln((n+m-2*p-1)/2) - gammaln(n/2) - gammaln((n+m-p-1)/2)) ...
    /(2^(3*p/2)*pi^(p/2)*s2^(p/2)*sqrt(det(A)));
end

function f = convq(x,d,delta)
%  density of d1*chi2_1(delta1) + d2*chi2_1(delta2) at x by direct convolution
g1 = @(u) ncx2pdf(u/d(1),1,delta(1))/d(1);
g2 = @(u) ncx2pdf(u/d(2),1,delta(2))/d(2);
%  split at the midpoint so that each endpoint singularity u^(-1/2) is at an end
f = integral(@(u) g1(u).*g2(x-u),0,x/2,'RelTol',1e-12,'AbsTol',0) ...
  + integral(@(u) g1(u).*g2(x-u),x/2,x,'RelTol',1e-12,'AbsTol',0);
end
