function check_smalln(logfile)
%CHECK_SMALLN  p = m-1 and n close to m-1: accuracy of the CF inversion,
%   against the marginal route (and, for p = 1, the Bessel route).
here = fileparts(mfilename('fullpath')); addpath(fileparts(here));
fid = fopen(logfile,'w');
%  m = 2, p = 1
m = 2; L = [1;2]; mu = (1:m)'/2; Sw = 0.5*eye(m)+0.5; Sz = 0.2*eye(m)+0.8;
for n = [1.2 1.5 2 2.5 3 4 6]
   q = [0.2 1 3];
   tic; fc = lwzpdf_cf(q,L,mu,Sw,Sz,n); tc = toc;
   tic; fb = lwzpdf_bessel(q,L,mu,Sw,Sz,n); tb = toc;
   tic; fm = lwzpdf_marg(q(2),L,mu,Sw,Sz,n); tm = toc;
   fprintf(fid,'m=2 p=1 n=%.1f  q=%s: cf/bessel-1 = %s (cf %.2fs, bessel %.1fs); marg/bessel-1 at q=1: %.1e (%.1fs)\n', ...
      n,mat2str(q),sprintf('%9.1e ',fc./fb-1),tc,tb,fm/fb(2)-1,tm);
   f0 = lwzpdf_zero(L,mu,Sw,Sz,n);  [fc0,info] = lwzpdf_cf(0,L,mu,Sw,Sz,n);
   fprintf(fid,'      at q=0: cf %.6g, eq. (39) %.6g (cf/exact-1 = %.1e, extrapolated %d)\n',fc0,f0,fc0/f0-1,info.extrapolated);
end
%  m = 3, p = 2
m = 3; L = [1 0;0 1;1 1]; mu = (1:m)'/2; Sw = 0.5*eye(m)+0.5; Sz = 0.2*eye(m)+0.8;
Q = [1 1; 3 -1]';
for n = [2.2 2.5 3 3.5 4 5]
   tic; fc = lwzpdf_cf(Q,L,mu,Sw,Sz,n); tc = toc;
   tic; fm = lwzpdf_marg(Q,L,mu,Sw,Sz,n); tm = toc;
   fprintf(fid,'m=3 p=2 n=%.1f  cf/marg-1 = %s (cf %.1fs, marg %.1fs for 2 points)\n',n,sprintf('%9.1e ',fc./fm-1),tc,tm);
end
%  m = 4, p = 3
m = 4; L = [eye(3);1 1 0]; mu = (1:m)'/2; Sw = 0.5*eye(m)+0.5; Sz = 0.2*eye(m)+0.8;
q = [1;1;1];
for n = [3.2 3.5 4 5]
   tic; fc = lwzpdf_cf(q,L,mu,Sw,Sz,n); tc = toc;
   tic; fm = lwzpdf_marg(q,L,mu,Sw,Sz,n); tm = toc;
   fprintf(fid,'m=4 p=3 n=%.1f  cf/marg-1 = %9.1e (cf %.1fs, marg %.1fs)\n',n,fc/fm-1,tc,tm);
end
fprintf(fid,'SMALLN-DONE\n'); fclose(fid);
end
