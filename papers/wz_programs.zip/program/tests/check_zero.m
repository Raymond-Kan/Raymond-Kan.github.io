function check_zero(logfile)
%CHECK_ZERO  Development check of the density at q = 0 (LWZPDF with method 'auto'):
%   eq. (39) against the CF route, the marginal route and Monte Carlo, the cases
%   f(0_m) = Inf, and the rescaled WZPDF far in the tails.
here = fileparts(mfilename('fullpath')); addpath(fileparts(here));
fid = fopen(logfile,'w'); pr = @(varargin) fprintf(fid,varargin{:});
%  (a) eq. (39) vs the CF route, including n close to m-1 (negative power of u)
cases = {5,[eye(3);1 1 0;0 1 1],10; 5,[eye(4);1 1 1 1],9.5;  % (the m=5, p=4 case was NaN before)
         3,[1 0;0 1;1 1],2.2; ...
         3,[1;1;1],2.05; 2,[1;2],1.2; 4,[eye(2);1 1;0 1],3.1};
for k = 1:size(cases,1)
   [m,L,n] = cases{k,:}; p = size(L,2); mu = (1:m)'/2;
   Sw = 0.5*eye(m)+0.5; Sz = 0.2*eye(m)+0.8;
   tic; [f0,meth] = lwzpdf(zeros(p,1),L,mu,Sw,Sz,n); t0 = toc;
   if p <= 3
      tic; fc = lwzpdf_cf(zeros(p,1),L,mu,Sw,Sz,n); tc = toc; lab = 'cf';
   else
      tic; fc = lwzpdf_marg(zeros(p,1),L,mu,Sw,Sz,n); tc = toc; lab = 'marg';
   end
   pr('m=%d p=%d n=%5.2f  %s: %.8g (%.3f s)   %s: %.8g (%.2f s)   rel.diff %.1e\n', ...
      m,p,n,meth,f0,t0,lab,fc,tc,(f0-fc)/fc);
end
%  (a2) continuity across (n-p-1)/2 = 0, where the code switches from the
%  double integral for a negative power of u to QRATINTNC
for c = {{2,[1;2],[1.99 2 2.01]}, {3,[1 0;0 1;1 1],[2.99 3 3.01]}}
   [m,L,ns] = c{1}{:}; p = size(L,2); mu = (1:m)'/2; Sw = 0.5*eye(m)+0.5; Sz = 0.2*eye(m)+0.8;
   v = zeros(size(ns)); for j = 1:numel(ns), v(j) = lwzpdf(zeros(p,1),L,mu,Sw,Sz,ns(j)); end
   pr('continuity m=%d p=%d: n = %s -> %s\n',m,p,mat2str(ns),sprintf('%.8g ',v));
end
%  (b) p = m-1 against values computed independently (polar coordinates and
%  the rank-one formula in Python): E[u^a/(y'By)^b] times the constant
ref = {2,[1;2],1.2,5.335378746807; 2,[1;2],2.01,0.205097244021; 3,[1 0;0 1;1 1],2.2,2.152605484703; ...
       5,[eye(4);1 1 1 1],9.5,2.268499697432e-06};
for k = 1:size(ref,1)
   [m,L,n,fr] = ref{k,:}; p = size(L,2); mu = (1:m)'/2; Sw = 0.5*eye(m)+0.5; Sz = 0.2*eye(m)+0.8;
   f0 = lwzpdf(zeros(p,1),L,mu,Sw,Sz,n);
   pr('reference m=%d p=%d n=%.2f: %.12g  ref %.12g  rel.diff %.1e\n',m,p,n,f0,fr,(f0-fr)/fr);
end
%  (c) p = m: f(0_m) = Inf iff n <= m+1, also with a nonsingular L ~= I
for m = [1 2 3 5]
   mu = (1:m)'/2; Sw = 0.5*eye(m)+0.5; Sz = 0.2*eye(m)+0.8; L = eye(m) + triu(ones(m),1);
   for n = [m-0.5 m m+1 m+1.01 m+2]
      if n <= m-1, continue; end
      f1 = lwzpdf(zeros(m,1),[],mu,Sw,Sz,n); f2 = lwzpdf(zeros(m,1),L,mu,Sw,Sz,n);
      pr('p=m=%d n=%5.2f  f(0)=%.6g  (L~=I: %.6g)\n',m,n,f1,f2);
   end
end
%  (d) WZPDF far in the tail (was NaN) and the old example values
m=5; mu=(1:m)'; Sw=0.5*eye(m)+0.5; Sz=0.2*eye(m)+0.8; L=[eye(4);1 1 1 1]; n=9.5;
L0=null(L'); H=[L L0]; Hi=H\eye(m); mus=Hi*mu; Sws=H'*Sw*H; Sws=.5*(Sws+Sws'); Szs=Hi*Sz*Hi'; Szs=.5*(Szs+Szs');
h2 = [-785.72671648360279 -100 -1 0.5 10 100 1000];
pr('wzpdf tail: %s\n',sprintf('%.6g ',wzpdf([zeros(4,numel(h2)); h2],mus,Sws,Szs,n)));
%  (e) the rescaled WZPDF reproduces Table 1 and the coarse grid of Figure 2
B = load(fullfile(here,'results','exp_bivariate.mat'));
f1 = wzpdf(B.qt,B.mu,B.Sw,B.Sz,B.n);
pr('Table 1 points: max rel diff %.2e\n',max(abs(f1-B.f_thm)./B.f_thm));
[X1,X2] = meshgrid(B.x1,B.x2); F = reshape(wzpdf([X1(:)';X2(:)'],B.mu,B.Sw,B.Sz,B.n),size(X1));
pr('Figure 2 coarse grid: max abs diff / max %.2e\n',max(abs(F-B.F),[],'all')/max(B.F(:)));
pr('CHK-DONE\n'); fclose(fid);
end
