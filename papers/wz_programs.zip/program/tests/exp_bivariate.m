function exp_bivariate(outfile)
%EXP_BIVARIATE  Numerical check of Theorem 2.1 for m = 2 (Section 5.1 of the paper).
%   Exact density on a 61 x 61 grid (Theorem 2.1), bivariate kernel density estimate
%   from simulated draws, and a table at selected points comparing Theorem 2.1,
%   the characteristic function inversion, and conditional Monte Carlo.  The
%   inner contours of Figure 2 use a finer grid near the peak (EXP_BIVARIATE_FINE).
m  = 2;
Sw = [2 0.5; 0.5 1.3];
Sz = [1.4 -0.3; -0.3 0.9];
mu = [0.7; -0.4];
n  = 6;
R = struct('m',m,'Sw',Sw,'Sz',Sz,'mu',mu,'n',n);

%  ---- simulated draws ----
nsim = 1e6;
W = wzrnd(n,Sw,nsim,2024);
rs = RandStream('mt19937ar','Seed',2025);
Z = mu + chol(Sz,'lower')*randn(rs,m,nsim);
Qs = zeros(m,nsim);
for r = 1:nsim
   Qs(:,r) = W(:,:,r)*Z(:,r);
end
mq = mean(Qs,2); sq = std(Qs,0,2);
R.Qs_mean = mq; R.Qs_cov = cov(Qs');

%  ---- exact density on a grid (Theorem 2.1) ----
ng = 61;
x1 = linspace(mq(1)-3*sq(1), mq(1)+3*sq(1), ng);
x2 = linspace(mq(2)-3*sq(2), mq(2)+3*sq(2), ng);
[X1,X2] = meshgrid(x1,x2);
Q = [X1(:)'; X2(:)'];
tic; F = wzpdf(Q,mu,Sw,Sz,n); R.t_grid = toc;
R.x1 = x1; R.x2 = x2; R.F = reshape(F,size(X1));

%  ---- binned kernel density estimate (Gaussian kernel, Silverman bandwidth) ----
h = 1.06*sq*nsim^(-1/6);
R.h = h;
nb = 800;
e1 = linspace(mq(1)-8*sq(1), mq(1)+8*sq(1), nb+1);
e2 = linspace(mq(2)-8*sq(2), mq(2)+8*sq(2), nb+1);
C  = histcounts2(Qs(1,:),Qs(2,:),e1,e2);                   % nb x nb, x1 along rows
c1 = 0.5*(e1(1:end-1)+e1(2:end)); c2 = 0.5*(e2(1:end-1)+e2(2:end));
K1 = exp(-0.5*((x1(:)-c1)/h(1)).^2)/(sqrt(2*pi)*h(1));     % ng x nb
K2 = exp(-0.5*((x2(:)-c2)/h(2)).^2)/(sqrt(2*pi)*h(2));     % ng x nb
R.Fkde = (K1*C*K2')'/nsim;                                 % rows x2, cols x1 (meshgrid layout)
R.frac_in_box = mean(Qs(1,:)>e1(1) & Qs(1,:)<e1(end) & Qs(2,:)>e2(1) & Qs(2,:)<e2(end));

%  ---- table at selected points: mode region, shoulders, tail, origin ----
qt = [mq(1) mq(1)-sq(1) mq(1)+sq(1) mq(1)+2*sq(1) mq(1)-1.5*sq(1) 0;
      mq(2) mq(2)+sq(2) mq(2)-sq(2) mq(2)+2*sq(2) mq(2)-1.5*sq(2) 0];
tic; R.f_thm = wzpdf(qt,mu,Sw,Sz,n); R.t_thm = toc;
tic; R.f_cf  = lwzpdf_cf(qt,eye(2),mu,Sw,Sz,n); R.t_cf = toc;
tic; [R.f_mc,R.se_mc] = lwzpdf_mc(qt,eye(2),mu,Sw,Sz,n,1e6); R.t_mc = toc;
R.qt = qt;
Kq1 = exp(-0.5*((qt(1,:)'-c1)/h(1)).^2)/(sqrt(2*pi)*h(1));
Kq2 = exp(-0.5*((qt(2,:)'-c2)/h(2)).^2)/(sqrt(2*pi)*h(2));
R.f_kde = diag(Kq1*C*Kq2')'/nsim;
save(outfile,'-struct','R');

%  ---- fine grid near the peak, for the inner contours of Figure 2 ----
exp_bivariate_fine(outfile);
end
