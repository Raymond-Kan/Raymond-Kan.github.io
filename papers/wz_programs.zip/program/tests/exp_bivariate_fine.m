function exp_bivariate_fine(matfile)
%EXP_BIVARIATE_FINE  Fine grid near the peak for Figure 2 (Section 5.1 of the paper).
%
%   exp_bivariate_fine(matfile)
%
%   The density of q = W*z in the bivariate example has a sharp peak next to the
%   origin, which the 61 x 61 grid of EXP_BIVARIATE (spacing about 1.7 x 1.0) does
%   not resolve: the innermost contours would be drawn through a handful of grid
%   points.  This function evaluates Theorem 2.1 (WZPDF) and the kernel density
%   estimate on a grid with spacing 0.1 over [-8,12] x [-7,6] and adds the fields
%   x1f, x2f, Ff (exact) and Fkdef (kernel estimate) to matfile, which must hold the
%   results of EXP_BIVARIATE.  The simulated draws are regenerated from the same
%   seeds, and the kernel estimate is checked against the one stored on the coarse
%   grid.  WZPDF is run in parallel when the Parallel Computing Toolbox is available.
%
%   See also EXP_BIVARIATE, MAKE_TABLES.

R  = load(matfile);
m  = R.m; Sw = R.Sw; Sz = R.Sz; mu = R.mu; n = R.n;

%  ---- the simulated draws of EXP_BIVARIATE (same seeds) ----
nsim = 1e6;
W = wzrnd(n,Sw,nsim,2024);
rs = RandStream('mt19937ar','Seed',2025);
Z = mu + chol(Sz,'lower')*randn(rs,m,nsim);
Qs = zeros(m,nsim);
for r = 1:nsim
   Qs(:,r) = W(:,:,r)*Z(:,r);
end
clear W Z
mq = mean(Qs,2); sq = std(Qs,0,2);
h  = 1.06*sq*nsim^(-1/6);
nb = 800;
e1 = linspace(mq(1)-8*sq(1), mq(1)+8*sq(1), nb+1);
e2 = linspace(mq(2)-8*sq(2), mq(2)+8*sq(2), nb+1);
C  = histcounts2(Qs(1,:),Qs(2,:),e1,e2);
c1 = 0.5*(e1(1:end-1)+e1(2:end)); c2 = 0.5*(e2(1:end-1)+e2(2:end));
kde = @(x1,x2) ((exp(-0.5*((x1(:)-c1)/h(1)).^2)/(sqrt(2*pi)*h(1))) * C * ...
               (exp(-0.5*((x2(:)-c2)/h(2)).^2)/(sqrt(2*pi)*h(2)))')'/nsim;
chk = max(abs(kde(R.x1,R.x2) - R.Fkde),[],'all')/max(R.Fkde(:));
if chk > 1e-10
   error('exp_bivariate_fine:draws','Regenerated draws differ from EXP_BIVARIATE (rel. diff %g).',chk);
end

%  ---- fine grid ----
x1f = -8:0.1:12;
x2f = -7:0.1:6;
[X1,X2] = meshgrid(x1f,x2f);
Q = [X1(:)'; X2(:)'];
N = size(Q,2);
nchunk = 400;
idx = round(linspace(0,N,nchunk+1));
Fc = cell(1,nchunk);
v = ver;
if any(strcmp({v.Name},'Parallel Computing Toolbox')) && isempty(gcp('nocreate'))
   parpool('Processes');
end
tic;
parfor k = 1:nchunk
   Fc{k} = wzpdf(Q(:,idx(k)+1:idx(k+1)),mu,Sw,Sz,n);
end
R.t_fine = toc;
R.x1f = x1f;  R.x2f = x2f;
R.Ff  = reshape([Fc{:}],size(X1));
R.Fkdef = kde(x1f,x2f);
save(matfile,'-struct','R');
end
