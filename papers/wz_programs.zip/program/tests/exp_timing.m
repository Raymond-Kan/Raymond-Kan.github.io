function exp_timing(outfile,skip,only)
%EXP_TIMING  Computing time of the alternative representations (Table in Section 5.3).
%   For each configuration (m, p, covariance setting) the density is computed
%   at one point and, for the characteristic function route and Theorem 2.1,
%   also on a 101-point grid.  Routes: 'cf' (Corollary 4.1), 'bessel'
%   (Sections 3.1-3.2), 'marginal' (Remark 4.4, marginalization of Theorem
%   2.1), 'proportional' (Section 3.3), 'full' (Theorem 2.1).
%
%   Parameters: n = m+5, mu = (1,...,m)'/m, L = [I_p; 1_(m-p) 1_p'/p] (L = I_m
%   for p = m); general setting Sw = 0.5 I + 0.5 11', Sz = 0.2 I + 0.8 11';
%   identity setting Sw = Sz = I.  The evaluation point is E[q] + 0.5 sd, with
%   sd the exact standard deviations of q (from the exact covariance matrix),
%   and the grid is E[q] + 0.5 sd t (p >= 2) or E[q] + sd t (p = 1), with 101
%   equally spaced values of t in [-3,3].
%
%   Timing: every route is first run once on a small problem (warm-up, not
%   timed, so that first-call overheads are excluded), then each entry is
%   timed NREP = 3 times and the median is reported.  A route whose
%   first timed run takes more than TLONG = 60 s is timed only once.
%
%   skip (optional): cell array of {m, p, method} triples to leave out.
%   only (optional): 'general' or 'identity', to run only those rows.
if nargin < 2, skip = {}; end
if nargin < 3, only = ''; end
rows = {}; k = 0;
NREP = 3; TLONG = 60;
rng(7);
cfgs = {
%   m   p   setting
    2   1   'general'
    3   1   'general'
    5   1   'general'
   10   1   'general'
    3   2   'general'
    4   2   'general'
    5   2   'general'
    4   3   'general'
    5   3   'general'
    5   4   'general'
    3   1   'identity'
    5   1   'identity'
    5   2   'identity'
    5   3   'identity'
    5   4   'identity'
   10   2   'identity'
   10   5   'identity'
   10   9   'identity'
    5   5   'general'
   10  10   'general'
};
warmup();
for c = 1:size(cfgs,1)
   m = cfgs{c,1}; p = cfgs{c,2}; setting = cfgs{c,3};
   if ~isempty(only) && ~strcmp(setting,only), continue; end
   n = m+5;
   mu = (1:m)'/m;
   if strcmp(setting,'identity')
      Sw = eye(m); Sz = eye(m);
   else
      Sw = 0.5*eye(m)+0.5*ones(m); Sz = 0.2*eye(m)+0.8*ones(m);
   end
   if p == m
      L = eye(m);
   else
      L = [eye(p); ones(m-p,1)*ones(1,p)/p];
   end
   q0 = n*L'*Sw*mu;                                % the mean of q
   a  = L'*Sw*mu;                                  % exact covariance matrix of q
   V  = n*(n+1)*(L'*Sw*Sz*Sw*L) + n*(a*a') + n*(trace(Sw*Sz)+mu'*Sw*mu)*(L'*Sw*L);
   sd = sqrt(diag(V));
   q  = q0 + 0.5*sd;
   if p == 1
      qgrid = linspace(q0-3*sd, q0+3*sd, 101);
   else
      qgrid = q0 + 0.5*sd.*ones(p,101).*linspace(-3,3,101);
   end
   meths = {};
   if p == m, meths{end+1} = 'full'; end
   if p < m && n > 2*p-m+1 && (p <= 3 || strcmp(setting,'identity')), meths{end+1} = 'cf'; end
   if p < m && p <= 2 && m <= 5, meths{end+1} = 'bessel'; end
   if p < m && m-p == 1, meths{end+1} = 'marginal'; end
   if p < m && strcmp(setting,'identity'), meths{end+1} = 'proportional'; end
   for j = 1:numel(meths)
      meth = meths{j};
      if any(cellfun(@(c) isequal(c,{m,p,meth}), skip)), continue; end
      warning('off','all');
      [f1,t1,nr1] = timeit_med(@() lwzpdf(q,L,mu,Sw,Sz,n,meth),NREP,TLONG);
      tg = NaN; nrg = 0;
      if strcmp(meth,'cf') || strcmp(meth,'full')
         [~,tg,nrg] = timeit_med(@() lwzpdf(qgrid,L,mu,Sw,Sz,n,meth),NREP,TLONG);
      end
      warning('on','all');
      k = k+1;
      rows(k,:) = {m, p, setting, meth, f1, t1, tg, nr1, nrg};
      msg = sprintf('m=%d p=%d %s %s: f=%.6g  t1=%.3f s (%d runs)  tgrid=%.3f s (%d runs)',m,p,setting,meth,f1,t1,nr1,tg,nrg);
      disp(msg);
      logf = fullfile(fileparts(outfile),'run_all.log');            % progress, and partial results
      fid = fopen(logf,'a'); if fid > 0, fprintf(fid,'   %s\n',msg); fclose(fid); end
      R.rows = rows; R.header = {'m','p','setting','method','f','t_point','t_grid101','nrep_point','nrep_grid'};
      save(outfile,'-struct','R');
   end
end
R.rows = rows;
R.header = {'m','p','setting','method','f','t_point','t_grid101','nrep_point','nrep_grid'};
save(outfile,'-struct','R');
end

function [f,t,nr] = timeit_med(fun,nrep,tlong)
%  median time of up to nrep runs; a single run if the first one exceeds tlong
tt = zeros(nrep,1);
tic; f = fun(); tt(1) = toc; nr = 1;
if tt(1) <= tlong
   for r = 2:nrep
      tic; fun(); tt(r) = toc;
   end
   nr = nrep;
end
t = median(tt(1:nr));
end

function warmup
%  run every route once on a small problem, untimed
warning('off','all');
m = 3; n = 8; mu = (1:m)'/m;
SwG = 0.5*eye(m)+0.5*ones(m); SzG = 0.2*eye(m)+0.8*ones(m);
L1 = [1;0.5;0.5]; L2 = [eye(2); 0.5 0.5];
q1 = n*L1'*SwG*mu; q2 = n*L2'*SwG*mu;
lwzpdf(q1,L1,mu,SwG,SzG,n,'cf');
lwzpdf(q1,L1,mu,SwG,SzG,n,'bessel');
lwzpdf(q2,L2,mu,SwG,SzG,n,'marginal');
lwzpdf(n*SwG*mu,eye(m),mu,SwG,SzG,n,'full');
lwzpdf(n*L1'*mu,L1,mu,eye(m),eye(m),n,'proportional');
lwzpdf(n*L2'*mu,L2,mu,eye(m),eye(m),n,'cf');
warning('on','all');
end
