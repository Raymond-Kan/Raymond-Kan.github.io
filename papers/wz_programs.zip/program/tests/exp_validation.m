function exp_validation(outfile)
%EXP_VALIDATION  Analytic density vs conditional Monte Carlo (Table in Section 5.2).
m  = 5;
mu = (1:5)';
SwG = 0.5*eye(m)+0.5*ones(m);  SzG = 0.2*eye(m)+0.8*ones(m);   % general setting
n  = 10;
nmc = 1e6;
rows = {};
k = 0;
L1 = ones(m,1);
L2 = [1 0;0 1;1 1;0 1;1 0];
L3 = [eye(3); 1 1 0; 0 1 1];
L4 = [eye(4); 1 1 1 1];
addcase('General, $p=1$',           L1, SwG, SzG, mu, n, 'cf',     5);
addcase('General, $p=1$ (Bessel)',  L1, SwG, SzG, mu, n, 'bessel', 5);
addcase('General, $p=2$',           L2, SwG, SzG, mu, n, 'cf',     [3;-4]);
addcase('General, $p=3$',           L3, SwG, SzG, mu, n, 'cf',     [3;-4;2]);
addcase('General, $p=m-1=4$',       L4, SwG, SzG, mu, n, 'marginal', [3;-4;2;1]);
addcase('General, $p=m=5$',         eye(m), SwG, SzG, mu, n, 'full',  [3;-4;2;1;-2]);
addcase('General, $p=1$, $n=m-0.5$',L1, SwG, SzG, mu, m-0.5, 'cf', 2);
addcase('General, $p=1$, $\mu=0$',  L1, SwG, SzG, zeros(m,1), n, 'cf', 5);
addcase('Identity, $p=1$',          L1, eye(m), eye(m), mu, n, 'proportional', 2);
addcase('Identity, $p=2$',          L2, eye(m), eye(m), mu, n, 'proportional', [1;-1]);
addcase('Identity, $p=2$ (CF)',     L2, eye(m), eye(m), mu, n, 'cf',    [1;-1]);
addcase('General, $p=1$, $q=0$',    L1, SwG, SzG, mu, n, 'cf',     -n*L1'*SwG*mu);
R.rows = rows;
R.header = {'Setting','Method','Analytic','MonteCarlo','s.e.','|diff|/s.e.','t_analytic','t_mc','q'};
save(outfile,'-struct','R');

   function addcase(name,L,Sw,Sz,mu0,nn,meth,shift)
      %  evaluation point near the mean E[q] = nn L'Sw mu0, shifted by 'shift'
      q = nn*L'*Sw*mu0 + shift;
      tic; fa = lwzpdf(q,L,mu0,Sw,Sz,nn,meth); ta = toc;
      tic; [fm,se] = lwzpdf_mc(q,L,mu0,Sw,Sz,nn,nmc); tm = toc;
      k = k+1;
      rows(k,:) = {name, meth, fa, fm, se, abs(fa-fm)/se, ta, tm, q(:)'};
   end
end
