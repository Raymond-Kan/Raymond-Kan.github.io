%FIG_P1  Figure 1 of the paper: density of alpha'*W*z for m = 5, n = 9 and 10,
%   computed by the characteristic function route (Corollary 4.1), written to
%   figure1.pdf in tests\results.  The Bessel route of Section 3.1 gives the
%   same curves to within 1e-8.
here   = fileparts(mfilename('fullpath'));
texdir = fullfile(here,'results');
addpath(fileparts(here));
m = 5;
Sw = 0.5*eye(m)+0.5;
Sz = 0.2*eye(m)+0.8;
mu = [1 2 3 4 5]';
alpha = [1 1 1 1 1]';
q = -200:1:1600;
tic; f  = lwzpdf(q,alpha,mu,Sw,Sz,9);  t9 = toc;
tic; f1 = lwzpdf(q,alpha,mu,Sw,Sz,10); t10 = toc;
fprintf('1801-point curves: n=9 %.2f s, n=10 %.2f s; masses %.6f %.6f\n',t9,t10,trapz(q,f),trapz(q,f1));
set(groot,'DefaultTextInterpreter','latex')
set(groot,'DefaultAxesTickLabelInterpreter','latex');
set(groot,'DefaultLegendInterpreter','latex')
fig = figure('Visible','off');                       % same page size and fonts as Figure 2
c1 = [0 0.447 0.741];  c2 = [0.850 0.325 0.098];      % blue (n = 9), orange (n = 10), as in Figure 2
plot(q,f,'-','Color',c1,'LineWidth',1); hold on
plot(q,f1,'--','Color',c2,'LineWidth',1)
xlabel('$q$','FontSize',12)
ylabel('Density','FontSize',12)
legend('$n=9$','$n=10$','Location','NorthEast','Box','off','FontSize',11)
set(gca,'box','off','TickDir','out','FontSize',11)
set(gcf,'PaperUnits','inches','PaperPosition',[0 0 5.5 4.4],'PaperSize',[5.5 4.4]);
print(fig,'-dpdf',fullfile(texdir,'figure1.pdf'));
close(fig);
