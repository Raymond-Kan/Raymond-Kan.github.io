function finalize(outfile)
%FINALIZE  Collect the final results and write the LaTeX tables and Figure 2
%   (into the folder of outfile).
%   outfile is <outdir>\finalize.mat; exp_bivariate.mat and the other results
%   are read from the same folder (tests\results for the paper).
outdir = fileparts(outfile);
here   = fileparts(mfilename('fullpath'));
if ~exist(fullfile(outdir,'exp_bivariate.mat'),'file')
   error('finalize:missing','Run exp_bivariate first: %s not found.',fullfile(outdir,'exp_bivariate.mat'));
end
%  recompute the CF column of Table 1 with the shipped inversion code
B = load(fullfile(outdir,'exp_bivariate.mat'));
tic; B.f_cf = lwzpdf_cf(B.qt,eye(2),B.mu,B.Sw,B.Sz,B.n,struct('Ns',1501)); B.t_cf = toc;
%  behaviour of the density near the origin (Theorem 2.1), along two rays
B.ray_s = [0 0.05 0.1 0.2 0.5 1 2 4];
e1 = [1;0]; e2 = [1;1]/sqrt(2);
B.ray_f1 = wzpdf(e1*B.ray_s,B.mu,B.Sw,B.Sz,B.n);
B.ray_f2 = wzpdf(e2*B.ray_s,B.mu,B.Sw,B.Sz,B.n);
save(fullfile(outdir,'exp_bivariate.mat'),'-struct','B');
make_tables(outdir,outdir);
R.done = datestr(now);
save(outfile,'-struct','R');
end
