function make_figures
%MAKE_FIGURES  Write figure1.pdf (FIG_P1) and figure2.pdf (MAKE_TABLES, figure
%   only, from tests\results) into tests\results.
here = fileparts(mfilename('fullpath'));
fig_p1;
make_tables(fullfile(here,'results'), fullfile(here,'results'), 'figure');
end
