function make_tables(resdir,texdir,what)
%MAKE_TABLES  Write the LaTeX table bodies and Figure 2 from the saved results.
%
%   make_tables(resdir,texdir)
%   make_tables(resdir,texdir,'figure')   % write figure2.pdf only
%
%   resdir : folder with exp_bivariate.mat, exp_validation.mat, exp_timing_all.mat
%            (default: tests\results)
%   texdir : output folder for tab_biv.tex, tab_val.tex, tab_time.tex (LaTeX
%            table bodies) and figure2.pdf (default: resdir)
if nargin < 1 || isempty(resdir), resdir = fullfile(fileparts(mfilename('fullpath')),'results'); end
if nargin < 2 || isempty(texdir), texdir = resdir; end
if nargin < 3, what = 'all'; end
figonly = strcmpi(what,'figure');

%  ---------------- Table 1 and Figure 2: bivariate example ----------------
if exist(fullfile(resdir,'exp_bivariate.mat'),'file')
B = load(fullfile(resdir,'exp_bivariate.mat'));
if ~figonly
fid = fopen(fullfile(texdir,'tab_biv.tex'),'w');
for i = 1:size(B.qt,2)
   fprintf(fid,'%s & %s & %s & %s & %s & %s (%s) \\\\\n', fmtq(B.qt(1,i)), fmtq(B.qt(2,i)), ...
      fmt6(B.f_thm(i)), fmt6(B.f_cf(i)), fmt6(B.f_kde(i)), fmt6(B.f_mc(i)), fmt6(B.se_mc(i)));
end
fprintf(fid,'\\hline\n'); fclose(fid);
end
%  contour figure
fig = figure('Visible','off');
set(groot,'DefaultTextInterpreter','latex');
set(groot,'DefaultAxesTickLabelInterpreter','latex');
set(groot,'DefaultLegendInterpreter','latex');
lw = 1;                                                % line width
c1 = [0 0.447 0.741];  c2 = [0.850 0.325 0.098];      % blue (exact), orange (kernel estimate)
fine = isfield(B,'Ff');
fmax = max(B.F(:));    kmax = max(B.Fkde(:));
if fine, fmax = max(fmax,max(B.Ff(:)));  kmax = max(kmax,max(B.Fkdef(:))); end
lev = fmax*[0.02 0.05 0.1 0.2 0.35 0.5 0.7 0.9];
lev = lev(lev < min(fmax,kmax));      % only levels reached by both, so the two sets of contours match
%  each level is drawn from the fine grid near the peak when its contour lies
%  entirely inside that grid, and from the coarse grid otherwise
for k = 1:numel(lev)
   for s = 1:2
      if s == 1, G = B.F;  Gf = []; col = c1; ls = '-';  if fine, Gf = B.Ff;    end
      else,      G = B.Fkde; Gf = []; col = c2; ls = '--'; if fine, Gf = B.Fkdef; end
      end
      if ~isempty(Gf) && max([Gf(1,:) Gf(end,:) Gf(:,1)' Gf(:,end)']) < lev(k)
         contour(B.x1f,B.x2f,Gf,[lev(k) lev(k)],'LineStyle',ls,'LineColor',col,'LineWidth',lw);
      else
         contour(B.x1,B.x2,G,[lev(k) lev(k)],'LineStyle',ls,'LineColor',col,'LineWidth',lw);
      end
      hold on
   end
end
h1 = plot(NaN,NaN,'-','Color',c1,'LineWidth',lw);      % legend samples
h2 = plot(NaN,NaN,'--','Color',c2,'LineWidth',lw);
xlabel('$q_1$','FontSize',12); ylabel('$q_2$','FontSize',12);
legend([h1 h2],{'Theorem 2.1','Kernel density estimate'},'Location','NorthWest','Box','off','FontSize',11);
set(gca,'box','off','TickDir','out','FontSize',11);
set(gcf,'PaperUnits','inches','PaperPosition',[0 0 5.5 4.4],'PaperSize',[5.5 4.4]);
print(fig,'-dpdf',fullfile(texdir,'figure2.pdf'));
close(fig);
end

%  ---------------- Table 2: validation ----------------
if ~figonly && exist(fullfile(resdir,'exp_validation.mat'),'file')
V = load(fullfile(resdir,'exp_validation.mat'));
fid = fopen(fullfile(texdir,'tab_val.tex'),'w');
for i = 1:size(V.rows,1)
   r = V.rows(i,:);  r{2} = newname(r{2});
   name = strrep(strrep(r{1},' (Bessel)',''),' (CF)','');
   fprintf(fid,'%s & %s & %s & %s (%s) & %.2f \\\\\n', name, methname(r{2}), fmt6(r{3}), fmt6(r{4}), fmt6(r{5}), r{6});
end
fprintf(fid,'\\hline\n'); fclose(fid);
end

%  ---------------- Table 3: timing ----------------
rows = {};
if exist(fullfile(resdir,'exp_timing_all.mat'),'file')
   tfiles = {'exp_timing_all.mat'};                  % a single run of all rows (RUN_TIMING_ALL)
else
   tfiles = {'exp_timing_wzpdf.mat','exp_timing_ident.mat','exp_timing_full.mat','exp_timing.mat','exp_timing_rest.mat'};
end
for fn = tfiles                                      % merge, first file wins
   if ~exist(fullfile(resdir,fn{1}),'file'), continue; end
   Tm = load(fullfile(resdir,fn{1}));
   for i = 1:size(Tm.rows,1)
      r = Tm.rows(i,1:7);  r{4} = newname(r{4});
      if isempty(rows) || ~any(cell2mat(rows(:,1))==r{1} & cell2mat(rows(:,2))==r{2} & strcmp(rows(:,3),r{3}) & strcmp(rows(:,4),r{4}))
         rows(end+1,:) = r;
      end
   end
end
if ~figonly && ~isempty(rows)
cfgall = [2 1; 3 1; 5 1; 10 1; 3 2; 4 2; 5 2; 4 3; 5 3; 5 4; 5 5; 10 10; 10 2; 10 5; 10 9];
cfg = unique(cfgall,'rows','stable');
fid = fopen(fullfile(texdir,'tab_time.tex'),'w');
meths = {'full','cf','bessel','marginal','proportional'};
for setting = {'general','identity'}
   for c = 1:size(cfg,1)
      m = cfg(c,1); p = cfg(c,2);
      sel = cell2mat(rows(:,1))==m & cell2mat(rows(:,2))==p & strcmp(rows(:,3),setting{1});
      if ~any(sel), continue; end
      cells = cell(1,numel(meths));
      for j = 1:numel(meths)
         k = find(sel & strcmp(rows(:,4),meths{j}), 1);
         if isempty(k)
            cells{j} = '--';
         else
            t1 = rows{k,6}; tg = rows{k,7};
            if isnan(tg), cells{j} = sprintf('%s', fmtt(t1));
            else, cells{j} = sprintf('%s / %s', fmtt(t1), fmtt(tg)); end
         end
      end
      fprintf(fid,'%d & %d & %s & %s \\\\\n', m, p, cap(setting{1}), strjoin(cells,' & '));
   end
end
fprintf(fid,'\\hline\n'); fclose(fid);
end
end

%======================================================================
function s = fmt6(x)
if isinf(x), s = '$\infty$'; return; end
if x == 0, s = '0'; return; end
e = floor(log10(abs(x)));
if e >= -3 && e <= 3
   s = sprintf('%.*f', max(0,5-e), x);
else
   s = sprintf('$%.4f \\times 10^{%d}$', x/10^e, e);
end
end

function s = fmtq(x)
if abs(x-round(x)) < 1e-9, s = sprintf('%d',round(x)); else, s = sprintf('%.3f',x); end
end

function s = fmtt(t)
if t < 0.095, s = sprintf('%.2f',t);
elseif t < 9.95, s = sprintf('%.1f',t);
else, s = sprintf('%.0f',t); end
end

function s = methname(m)
switch m
   case 'full',     s = 'Thm 2.1';
   case 'cf',     s = 'CF';
   case 'bessel', s = 'Bessel';
   case 'marginal', s = 'Marg.';
   case 'proportional', s = 'Prop.';
   otherwise,     s = m;
end
end

function s = newname(s)
%  method names used in results saved before the routes were renamed
switch s
   case 'thm21', s = 'full';
   case 'marg',  s = 'marginal';
   case {'ident','identity'}, s = 'proportional';
end
end

function s = cap(x)
s = [upper(x(1)) x(2:end)];
end
