function run_all(which,outdir)
%RUN_ALL  Driver for the numerical experiments (run detached: matlab -batch).
%   which  : cell array of experiment names (default: all)
%   outdir : folder for the .mat results and the log (default: tests\results)
here = fileparts(mfilename('fullpath'));
if nargin < 2 || isempty(outdir), outdir = fullfile(here,'results'); end
if ~exist(outdir,'dir'), mkdir(outdir); end
addpath(fileparts(here)); addpath(here);
if nargin < 1, which = {'exp_bivariate','exp_validation','exp_timing'}; end
logf = fullfile(outdir,'run_all.log');
fid = fopen(logf,'a'); fprintf(fid,'%s  start %s\n',datestr(now),strjoin(which,',')); fclose(fid);
for k = 1:numel(which)
   name = which{k};
   t0 = tic;
   try
      feval(name, fullfile(outdir,[name '.mat']));
      msg = sprintf('%s  %s done in %.1f s',datestr(now),name,toc(t0));
   catch ME
      msg = sprintf('%s  %s FAILED: %s',datestr(now),name,getReport(ME,'extended','hyperlinks','off'));
   end
   fid = fopen(logf,'a'); fprintf(fid,'%s\n',msg); fclose(fid);
end
end
