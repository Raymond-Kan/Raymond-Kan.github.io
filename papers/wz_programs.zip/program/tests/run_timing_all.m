function run_timing_all
%RUN_TIMING_ALL  Re-time every row of Table 3 in a single MATLAB session.
%
%   run_timing_all
%
%   Runs EXP_TIMING for all configurations and saves the results in
%   tests\results\exp_timing_all.mat, together with the processor and MATLAB
%   version.  When that file exists, MAKE_TABLES builds Table 3 from it alone
%   (the partial re-runs exp_timing_*.mat are then ignored).
%
%   Each entry is the median of three timed runs, after an untimed warm-up
%   (a single run for entries that take more than 60 s; see EXP_TIMING).
%   The run takes about twenty minutes (Intel Core Ultra 9 185H).
%   For reproducible timings, run it on an otherwise idle computer, on mains
%   power, with the power mode set to best performance.  Progress is written
%   to tests\results\run_all.log.

here   = fileparts(mfilename('fullpath'));
addpath(fileparts(here));                          % the program folder
resdir = fullfile(here,'results');
if ~exist(resdir,'dir'), mkdir(resdir); end
outfile = fullfile(resdir,'exp_timing_all.mat');

logf = fullfile(resdir,'run_all.log');
fid = fopen(logf,'a'); fprintf(fid,'%s  start run_timing_all\n',datestr(now)); fclose(fid);
t0 = tic;
exp_timing(outfile);
ttot = toc(t0);

R = load(outfile);
R.matlab  = version;
R.cpu     = cpu_name();
R.date    = datestr(now);
R.t_total = ttot;
save(outfile,'-struct','R');
fid = fopen(logf,'a');
fprintf(fid,'%s  run_timing_all done in %.0f s on %s, MATLAB %s\n',datestr(now),ttot,R.cpu,R.matlab);
fclose(fid);
fprintf('Done in %.1f minutes.  Results: %s\n',ttot/60,outfile);
end

function s = cpu_name
s = 'unknown';
try
   if ispc
      [st,o] = system('powershell -NoProfile -Command "(Get-CimInstance Win32_Processor).Name"');
   elseif ismac
      [st,o] = system('sysctl -n machdep.cpu.brand_string');
   else
      [st,o] = system('grep -m1 "model name" /proc/cpuinfo | cut -d: -f2');
   end
   if st == 0, s = strtrim(o); end
catch
end
end
