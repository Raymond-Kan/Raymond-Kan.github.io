function f = wzpdf(q,mu,Sw,Sz,n)
%WZPDF  Density of q = W*z for W ~ W_m(n,Sw), z ~ N_m(mu,Sz), independent.
%
%   f = wzpdf(q,mu,Sw,Sz,n)
%
%   Implements Theorem 2.1 of Bodnar, Kan and Mazur (2026), "Computation of
%   the exact density function of the product of a Wishart matrix and a
%   normal vector": the density is a two-dimensional integral over
%   (v1,v2) ~ chi2_{n-m+1} x chi2_{n-m+2}, irrespective of m.  For m = 1 the
%   density is the single integral in eq. (1) of the paper, and at q = 0 the
%   closed form
%
%       f(0) = exp(-mu'Sz^{-1}mu/2) / ((2 pi)^{m/2}|Sw||Sz|^{1/2})
%              * Gamma(n-m-1)/Gamma(n-1),      n > m+1,
%
%   is used (f(0) = Inf when n <= m+1).
%
%   Input:
%     q   : m x N array of evaluation points (one column per point)
%     mu  : m x 1 mean vector of z
%     Sw  : m x m covariance (scale) matrix of the Wishart matrix
%     Sz  : m x m covariance matrix of the normal vector
%     n   : degrees of freedom, real, n > m-1
%
%   Output:
%     f   : 1 x N vector of density values
%
%   The double integral (6) of the paper is evaluated with the normal density
%   written as in Remark 2.2, in which every term of the exponent is
%   nonpositive and all constants are kept on the log scale, so that large
%   means and points far in the tails do not overflow or underflow; each
%   evaluation of the integrand costs O(m) operations.
%   Requires the Statistics and Machine Learning Toolbox (chi2inv).
%
%   See also LWZPDF, LWZCF, LWZPDF_MC, WZRND.

mu = mu(:);
m  = length(mu);
if size(q,1) ~= m
   if isvector(q) && m == 1
      q = q(:).';
   else
      error('wzpdf:q','q must be an m x N array of evaluation points.');
   end
end
N = size(q,2);
f = zeros(1,N);
if n <= m-1
   error('wzpdf:n','n must exceed m-1.');
end

%  ---- m = 1: single integral, eq. (1) ----
if m == 1
   sw2 = Sw; sz = sqrt(Sz);
   for i = 1:N
      qi = q(i);
      if qi == 0
         if n > 2
            f(i) = exp(-mu^2/(2*Sz))/sqrt(2*pi*Sz)/sw2/(n-2);
         else
            f(i) = Inf;
         end
      else
         f(i) = integral(@(v) exp(-(qi-sw2*v*mu).^2./(2*Sz*sw2^2*v.^2)) ...
                ./(sqrt(2*pi)*sz*sw2*v).*chi2pdf(v,n), 0, Inf, ...
                'RelTol',1e-12,'AbsTol',1e-14);
      end
   end
   return
end

%  ---- m >= 2 ----
%  Theorem 2.1 of the paper, eq. (6), with the normal density evaluated in
%  the coordinates of Remark 2.2:
%
%    f(q) = Gamma(n-m+1)/(|Sw|^{1/2} Gamma(n-1))
%           E[ phi_m((r/v1) e; eta, S + r^2/(v1^2 v2) (I - ee')) / (v1 v2) ],
%
%  with S = Sw^{1/2} Sz Sw^{1/2}, eta = Sw^{1/2} mu, q-hat = Sw^{-1/2} q,
%  r = |q-hat|, e = q-hat/r, v1 ~ chi2_{n-m+1} and v2 ~ chi2_{n-m+2}
%  independent.  In the basis [e, Q1], with Q'SQ = [s c'; c S22],
%  V = S22 - cc'/s = U diag(d) U' and h = Q'eta, the normal density is
%
%    exp(-(x-h1)^2/(2s) - sum_j hj(x)^2/(2(dj+a))) / ((2 pi)^{m/2} s^{1/2} prod_j (dj+a)^{1/2}),
%
%  x = r/v1, a = x^2/v2, hj(x) = [U'(h2 + (c/s)(x-h1))]_j: every term of the
%  exponent is nonpositive, so no cancellation occurs, and each evaluation
%  costs O(m) operations.  All constants are kept on the log scale.
Swh  = sqrtm(Sw);   Swh  = real(0.5*(Swh+Swh'));
S    = Swh*Sz*Swh;  S    = 0.5*(S+S');
eta  = Swh*mu;
[Rw,pw] = chol(Sw);
if pw > 0, error('wzpdf:Sw','Sw must be positive definite.'); end
[~,pz] = chol(Sz);
if pz > 0, error('wzpdf:Sz','Sz must be positive definite.'); end
ldSw = 2*sum(log(diag(Rw)));                          % log|Sw|
lc0  = gammaln(n-m+1) - gammaln(n-1) - 0.5*ldSw - 0.5*m*log(2*pi);
k1   = n-m+1;  k2 = n-m+2;                            % chi-square degrees of freedom
lc1  = -k1/2*log(2) - gammaln(k1/2);
lc2  = -k2/2*log(2) - gammaln(k2/2);
%  probe grid for the scale of the integrand: chi-square quantiles plus a wide
%  logarithmic grid (far in the tails of q the peak of the integrand lies far
%  in the tails of v1 and v2)
pp   = [0.001 0.01 0.05 0.1:0.1:0.9 0.95 0.99 0.999];
vg   = logspace(-8,4,61);
[V1g,V2g] = ndgrid([chi2inv(pp,k1) vg],[chi2inv(pp,k2) vg]);
X1g = log(V1g);  X2g = log(V2g);

for i = 1:N
   qi = q(:,i);
   if all(qi == 0)
      %  closed form at the origin, eq. (7)
      if n > m+1
         lf0 = -0.5*(mu'*(Sz\mu)) - 0.5*m*log(2*pi) - ldSw - sum(log(diag(chol(Sz)))) ...
               + gammaln(n-m-1) - gammaln(n-1);
         f(i) = exp(lf0);
      else
         f(i) = Inf;
      end
      continue
   end
   qh = Swh\qi;  r = norm(qh);  e = qh/r;
   Q  = [e null(e')];
   C  = Q'*S*Q;  C = 0.5*(C+C');
   h  = Q'*eta;
   s  = C(1,1);  c = C(2:end,1);
   V  = C(2:end,2:end) - c*c'/s;  V = 0.5*(V+V');
   [U,Dv] = eig(V);  d = max(diag(Dv),0);
   h2 = U'*h(2:end);  cs = U'*c/s;
   lcs = lc0 - 0.5*log(s);
   %  locate the peak of the integrand: best probe point, refined by a
   %  local search (for large means and points far out the peak can be much
   %  narrower than the probe spacing; x = r/v1 is then close to h1)
   LG = lkern(X1g,X2g);
   [lM,kk] = max(LG(:));
   if ~(lM > -Inf)
      f(i) = 0;
      continue
   end
   starts = [X1g(kk) X2g(kk)];
   if h(1) > 0
      x1s = log(r/h(1));
      [~,kk] = max(lkern(x1s+0*X2g(1,:),X2g(1,:)));
      starts = [starts; x1s X2g(1,kk)];
   end
   xo = starts(1,:);
   for kk = 1:size(starts,1)
      xs = fminsearch(@(z) -lkern(z(1),z(2)),starts(kk,:),optimset('TolX',1e-10,'TolFun',1e-12,'Display','off'));
      if lkern(xs(1),xs(2)) > lkern(xo(1),xo(2)), xo = xs; end
   end
   lM = max(lM,lkern(xo(1),xo(2)));
   %  widths of the peak from the curvature of the log integrand
   hh = 1e-4;  w = zeros(1,2);
   for j = 1:2
      ej = [0 0];  ej(j) = hh;
      c2 = (lkern(xo(1)+ej(1),xo(2)+ej(2)) - 2*lkern(xo(1),xo(2)) + lkern(xo(1)-ej(1),xo(2)-ej(2)))/hh^2;
      w(j) = 1/sqrt(max(-c2,1e-12));
   end
   %  integrate in x = log(v1), y = log(v2): the chi-square densities with
   %  fewer than two degrees of freedom are unbounded at the origin, which the
   %  substitution removes.  A narrow peak is integrated separately on a box of
   %  +-10 widths, and the rest of the plane in the eight surrounding pieces.
   if min(w) >= 0.5
      I = integral2(@(x,y) kern(x,y,lM), -Inf, Inf, -Inf, Inf, ...
                    'RelTol',1e-10,'AbsTol',1e-13);
   else
      e1 = [-Inf xo(1)-10*w(1) xo(1)+10*w(1) Inf];
      e2 = [-Inf xo(2)-10*w(2) xo(2)+10*w(2) Inf];
      I = 0;
      for j1 = 1:3
         for j2 = 1:3
            I = I + integral2(@(x,y) kern(x,y,lM), e1(j1), e1(j1+1), e2(j2), e2(j2+1), ...
                              'RelTol',1e-10,'AbsTol',1e-14);
         end
      end
   end
   f(i) = exp(log(I)+lM);
end

   function y = lkern(x1,x2)
      %  log of the integrand in (log v1, log v2), including all constants
      sz1 = size(x1);
      x1 = x1(:).';  x2 = x2(:).';
      v1 = exp(x1);  v2 = exp(x2);
      xx = r./v1;                                      % x = r/v1
      a  = xx.^2./v2;                                  % a = x^2/v2
      den = d + a;                                     % (m-1) x K
      res = h2 + cs*(xx - h(1));                       % (m-1) x K
      y = lcs - 0.5*(xx - h(1)).^2/s - 0.5*sum(log(den) + res.^2./den,1) ...
          + lc1 + (k1/2-1)*x1 - v1/2 ...               % chi2_{n-m+1} density
          + lc2 + (k2/2-1)*x2 - v2/2;                  % chi2_{n-m+2} density
      %  (the factor 1/(v1 v2) cancels the Jacobian v1 v2 of the log substitution)
      y = reshape(y,sz1);
   end
   function y = kern(x1,x2,lM)
      y = exp(lkern(x1,x2) - lM);
      y(~isfinite(y)) = 0;                             % v1 or v2 under/overflow at the ends
   end
end
