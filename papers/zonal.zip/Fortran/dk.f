#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*),prhs(*)
      integer nlhs,nrhs,m2
      mwpointer mxcreatedoublematrix,mxgetpr
      mwsize mxgetm,s
      mwpointer m,a,n,y
      real*8 m1

      m = mxgetpr(prhs(1))
      a = mxgetpr(prhs(2))
      n = mxgetpr(prhs(3))
      s = mxgetm(prhs(2))
      call mxcopyptrtoreal8(m,m1,1)
      m2 = nint(m1)
      plhs(1) = mxcreatedoublematrix(m2+1,1,0)
      y = mxgetpr(plhs(1))
      call dk(%val(y),m2,%val(a),%val(n),s)
      return
      end

      SUBROUTINE DK(YD,M,A,N,S)
C
C     This program computes the normalized top order
C     zonal polynomial.  It uses quadruple precision
C     for all intermediate calculations but output
C     the results in double precision.
C     YD is a vector of the output with dimension (M+1)x1,
C     A and N are input, which are the eigenvalues and
C     multiplicities, and they are Sx1 vectors
C
      INTEGER M,S,L,N1
      REAL*8 YD(M+1),A(S),N(S)
      REAL*16 Y(:),T(:),AQ(:),NQ(:),C(:),P(:)
      ALLOCATABLE :: Y,T,AQ,NQ,C,P

      ALLOCATE(Y(M+1))
      ALLOCATE(AQ(S))
      ALLOCATE(NQ(S))
      L = MIN(M,S)
      ALLOCATE(P(L))
      AQ = A
      NQ = N
      P = 0q0
      Y(1) = 1q0
C
C     Compute coefficients for the recursion
C
      DO 100 I=1,S
      J = MAX(1,L-I+1)
      P(J:L-1) = P(J:L-1)-AQ(I)*P(J+1:L)
  100 P(L) = P(L)-AQ(I)
C
C     Deal with the case that n's are equal separately
C
      IF (MINVAL(N).EQ.MAXVAL(N)) THEN
         N1 = NINT(N(1))
         IF (N1.EQ.2) THEN
            DO 130 I=1,L
  130       Y(I+1) = -DOT_PRODUCT(P(L-I+1:L),Y(1:I))
            DO 131 I=L+1,M
  131       Y(I+1) = -DOT_PRODUCT(P(1:S),Y(I-S+1:I))
         ELSE
            DO 132 I=1,L
  132       Y(I+1) = -DOT_PRODUCT(P(L-I+1:S)*Y(1:I), 
     *               (/(J,J=N1*I,N1+2*I-2,2-N1)/)/QFLOAT(2*I))
            DO 133 I=L+1,M
  133       Y(I+1) = -DOT_PRODUCT(P*Y(I-S+1:I), 
     *               (/(J,J=2*I-(2-N1)*S,N1+2*I-2,2-N1)/)/QFLOAT(2*I))
         END IF
      ELSE
         ALLOCATE(T(S))
         T = 0q0
C
C     Start the recursion
C
         IF (S.NE.L) THEN
            DO 103 I=1,M
            NQ = NQ*AQ
            T(I) = SUM(NQ)
            DO 103 J=1,I
  103       Y(I+1) = DOT_PRODUCT(Y(1:I),T(I:1:-1))/QFLOAT(2*I)
         ELSE
            ALLOCATE(C(S))
            DO 106 I=1,S
            NQ = NQ*AQ
            T(I) = SUM(NQ)
            C(S+1-I) = QFLOAT(I)*P(S+1-I)+0.5q0*(T(I)+
     *                 DOT_PRODUCT(P(S+2-I:S),T(1:I-1)))
  106       Y(I+1) = DOT_PRODUCT(Y(1:I),T(I:1:-1))/QFLOAT(2*I)
            DO 110 I=S+1,M
  110       Y(I+1) = DOT_PRODUCT(C/QFLOAT(I)-P,Y(I-S+1:I))   
         END IF
      END IF
C
C     Output the results in double precision
C
      YD = Y
      RETURN
      END
