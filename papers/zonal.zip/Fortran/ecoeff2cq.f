#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*),prhs(*)
      integer nlhs,nrhs,pa
      mwpointer mxcreatedoublematrix,mxgetpr
      mwsize mxgetm,n
      mwpointer a,b,c,d
      real*8 rpa

      a = mxgetpr(prhs(1))
      b = mxgetpr(prhs(2))
      c = mxgetpr(prhs(3))
      n = mxgetm(prhs(1))
      call mxcopyptrtoreal8(c,rpa,1)
      pa = nint(rpa)
      pa = min(pa,n)
      plhs(1) = mxcreatedoublematrix(pa+1,n+1,0)
      d = mxgetpr(plhs(1))
      call ecoeff(%val(d),%val(a),%val(b),n,pa)
      return
      end

      SUBROUTINE ECOEFF(C,AD,BD,N,PA)
      INTEGER I,J,K,N,PA
      REAL*8 AD(N,N),BD(N),C(PA+1,N+1)
      REAL*16 X(:,:),P(:,:),E(:,:),A(:,:),B(:),B1(:)
      ALLOCATABLE :: X,P,E,A,B,B1
      ALLOCATE(A(N,N))
      ALLOCATE(B(N))
      ALLOCATE(X(N,PA+1))
      ALLOCATE(P(PA+1,N+1))
      ALLOCATE(E(PA+1,N+1))
      A = AD
      B = BD
      P = 0q0
      IF (PA.EQ.0) THEN
         ALLOCATE(B1(N))
         B1 = B
         DO 105 I=2,N+1
         P(1,I) = SUM(B1)
 105     B1 = B1*B                 
      ELSE
C
C     Compute p_{i,j}'s
C
         DO 100 I=1,N
         P(2,1) = P(2,1)+A(I,I)
  100    P(1,2) = P(1,2)+B(I)
         DO 101 I=1,N
         X(:,1) = A(:,I)
         X(:,2) = 0q0
         X(I,2) = B(I)
         DO 102 J=2,PA
         X(:,J+1) = B*X(:,J)
         DO 103 K=J,2,-1
  103    X(:,K) = MATMUL(A,X(:,K))+B*X(:,K-1)
         X(:,1) = MATMUL(A,X(:,1))
         DO 102 K=0,J
  102    P(J-K+1,K+1) = P(J-K+1,K+1)+X(I,K+1)   
         DO 107 J=1,N-PA
         DO 108 K=1,PA
  108    X(:,K) = MATMUL(A,X(:,K+1))+B*X(:,K)
         X(:,PA+1) = B*X(:,PA+1)
         DO 107 K=0,PA
  107    P(PA-K+1,J+K+1) = P(PA-K+1,J+K+1)+X(I,K+1)   
  101    CONTINUE
      END IF
C
C     Use multivariate Newton-Girard formula to
C     compute e_{i,j} from p_{i,j} 
C
      E = 0q0
      E(1,1) = 1q0
      DO 104 I=1,PA+1
      K = 1
      If (I.EQ.1) K = 2
      DO 104 J=K,N+2-I
  104 E(I,J) = -SUM(E(1:I,1:J)*P(I:1:-1,J:1:-1))/QFLOAT(I+J-2)
C
C     Output the results in double precision
C
      C = E
      RETURN
      END
