#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*),prhs(*)
      integer nlhs,nrhs
      mwpointer mxcreatedoublematrix,mxgetpr
      mwsize mxgetm,n
      mwpointer a,b,c

      a = mxgetpr(prhs(1))
      b = mxgetpr(prhs(2))
      n = mxgetm(prhs(1))
      plhs(1) = mxcreatedoublematrix(n+1,n+1,0)
      c = mxgetpr(plhs(1))
      call ecoeff(%val(c),%val(a),%val(b),n)
      return
      end

      SUBROUTINE ECOEFF(C,AD,BD,N)
      INTEGER I,J,K,N
      REAL*8 AD(N,N),BD(N,N),C(N+1,N+1)
      REAL*16 X(:,:),P(:,:),E(:,:),A(:,:),B(:,:)
      ALLOCATABLE :: X,P,E,A,B

      ALLOCATE(A(N,N))
      ALLOCATE(B(N,N))
      ALLOCATE(X(N,N))
      ALLOCATE(P(N+1,N+1))
      ALLOCATE(E(N+1,N+1))
      A = AD
      B = BD
C
C     Compute p_{i,j}'s
C
      P = 0q0
      DO 100 I=1,N
      P(2,1) = P(2,1)+A(I,I)
  100 P(1,2) = P(1,2)+B(I,I)
      DO 101 I=1,N
      X(:,1) = A(:,I)
      X(:,2) = B(:,I)
      DO 102 J=2,N-1
      X(:,J+1) = MATMUL(B,X(:,J))
      DO 103 K=J,2,-1
  103 X(:,K) = MATMUL(A,X(:,K))+MATMUL(B,X(:,K-1))
      X(:,1) = MATMUL(A,X(:,1))
      DO 102 K=0,J
  102 P(J-K+1,K+1) = P(J-K+1,K+1)+X(I,K+1)   
      P(N+1,1) = P(N+1,1)+DOT_PRODUCT(A(I,:),X(:,1))
      P(1,N+1) = P(1,N+1)+DOT_PRODUCT(B(I,:),X(:,N))
      DO 101 J=1,N-1
  101 P(N-J+1,J+1) = P(N-J+1,J+1)+DOT_PRODUCT(A(I,:),X(:,J+1))
     *              +DOT_PRODUCT(B(I,:),X(:,J))
C
C     Use multivariate Newton-Girard formula to
C     compute e_{i,j} from p_{i,j} 
C
      E = 0q0
      E(1,1) = 1q0
      DO 104 I=1,N+1
      K = 1
      If (I.EQ.1) K = 2
      DO 104 J=K,N+2-I
  104 E(I,J) = -SUM(E(1:I,1:J)*P(I:1:-1,J:1:-1))/QFLOAT(I+J-2)
C
C     Output the results in double precision
C
      C = E
      RETURN
      END
