#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*),prhs(*)
      integer nlhs,nrhs
      mwpointer mxgetpr,mxcreatedoublescalar
      mwsize mxgetnumberofdimensions,mxgetdimensions,m
      mwpointer x1,x2,y
      mwsize dims(3)

      x1 = mxgetpr(prhs(1))
      x2 = mxgetpr(prhs(2))
C
C     dims(1) is n, dims(3) is p
C
      m = mxgetnumberofdimensions(prhs(1))
      call mxCopyPtrToInteger8(mxGetDimensions(prhs(1)),dims,m)
      if (m.eq.2) dims(3) = 1 
      plhs(1) = mxcreatedoublescalar(0)
      y = mxgetpr(plhs(1))
      call qmom(%val(y),%val(x1),%val(x2),dims(1),dims(3))
      return
      end


      SUBROUTINE QMOM(YD,A,SIR,N,P)
      MWSIGNEDINDEX N
      INTEGER M,P
      INTEGER SI(:),X(:),SII(2)
      INTEGER*8 P1,PX
      REAL*8 YD,A(N,N,P),SIR(P),B(:,:)
      ALLOCATABLE :: B,SI,X
      REAL*16 Y,Y1
      ALLOCATE(B(N,N))
      ALLOCATE(SI(P))
C
C     Setting up variables
C
      SI = NINT(SIR)
      SII = NINT(SIR)
      M = SUM(SI)
C
C     Quick return if m=0 or p=1
C
      IF (M.EQ.0) THEN
         YD = 1d0
         RETURN
      END IF
      Y = 0q0
      IF (P.EQ.1) THEN
         IF (M.EQ.1) THEN
            DO 134 I=1,N
  134       Y = Y+A(I,I,1)
            Y = 0.5q0*Y
         ELSE
            CALL TRS(Y,M,A(:,:,1),N)
         END IF
         YD = Y      
         RETURN
      END IF
      ALLOCATE(X(P))
      X = 0
      PX = PRODUCT(SI+1)/2
      P1 = 2
C
C     Create initial B
C
      B = 0.5d0*SI(1)*A(:,:,1)
      DO 152 K=2,P
  152 B = B+0.5d0*SI(K)*A(:,:,K)
      DO 153 I=1,PX
      CALL TRS(Y1,M,B,N)
      Y = Y+QFLOAT(P1)*Y1
         DO 154 J=1,P
         IF (X(J).LT.SI(J)) THEN
            X(J) = X(J)+1
            P1 = -P1*(SI(J)+1-X(J))/X(J)
C
C     Update B
C
            B = B-A(:,:,J)
            GOTO 153
         END IF
         X(J) = 0
         IF (MOD(SI(J),2).EQ.1) P1 = -P1
  154    B = B+SI(J)*A(:,:,J)
  153 CONTINUE
      DO 155 I=1,P
      DO 155 J=2,SI(I)
  155 Y = Y/QFLOAT(J)
      YD = Y
      RETURN 
      END


      SUBROUTINE TRS(YQ,M,AA,N)
      MWSIGNEDINDEX N,LWORK,INFO
      INTEGER M,L
      REAL*8 AA(N,N),A(:),WORK(:),B(:,:)
      REAL*16 YQ,Y(:),P(:)
      ALLOCATABLE :: A,WORK,B,P,Y

      LWORK = 3*N
      ALLOCATE(A(N))
      ALLOCATE(WORK(LWORK))
      ALLOCATE(B(N,N))
      ALLOCATE(P(N))
      ALLOCATE(Y(N+1))
      B = AA
C
C     Call LAPACK dsyev to produce the eigenvalues
C
      CALL DSYEV('N','U',N,B,N,A,WORK,LWORK,INFO)
      L = MIN(M,N)
      P = 0q0
      Y(1) = 1q0
C
C     Compute coefficients for the recursion
C
      DO 100 I=1,N
      J = MAX(1,L-I+1)
      P(J:L-1) = P(J:L-1)-A(I)*P(J+1:L)
  100 P(L) = P(L)-A(I)
C
C     Start the recursion
C
      DO 132 I=1,L
  132 Y(I+1) = -DOT_PRODUCT(P(L-I+1:L)*Y(1:I),
     *          (/(J,J=I,2*I-1)/))/QFLOAT(2*I)
      DO 133 I=L+1,M
      Y = EOSHIFT(Y,1)       ! Y(1:N) = Y(2:N+1)
  133 Y(N+1) = -DOT_PRODUCT(P*Y(1:N),
     *          (/(J,J=2*I-N,2*I-1)/))/QFLOAT(2*I)
      YQ = Y(L+1)
      RETURN
      END
