#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*),prhs(*)
      integer nlhs,nrhs
      mwpointer mxcreatedoublematrix,mxgetpr
      mwsize mxgetm,n
      mwpointer a,b,c,k1,k2
      real*8 rk1,rk2

      a = mxgetpr(prhs(1))
      b = mxgetpr(prhs(2))
      k1 = mxgetpr(prhs(3))
      k2 = mxgetpr(prhs(4))
      n = mxgetm(prhs(1))
      call mxcopyptrtoreal8(k1,rk1,1)
      call mxcopyptrtoreal8(k2,rk2,1)
      k1 = nint(rk1)
      k2 = nint(rk2)
      plhs(1) = mxcreatedoublematrix(k1+1,k2+1,0)
      c = mxgetpr(plhs(1))
      call mdkl(%val(c),%val(a),%val(b),n,k1,k2)
      return
      end

      SUBROUTINE MDKL(C,AD,BD,N,K1,K2)
      INTEGER I,I1,J,J1,K,N,K1,K2
      REAL*8 AD(N,N),BD(N),C(K1+1,K2+1)
      REAL*16 A(:,:),B(:),X(:,:),P(:,:),D(:,:),SIJ
      ALLOCATABLE :: X,P,D,A,B

      ALLOCATE(A(N,N))
      ALLOCATE(B(N))
      ALLOCATE(X(N,K2+1))
      ALLOCATE(P(K1+1,K2+1))
      ALLOCATE(D(K1+1,K2+1))
      A = AD
      B = BD
C
C     Compute p_{i,j}'s
C
      P = 0q0
      DO 100 I=1,N
      P(1,2) = P(1,2)+B(I)
  100 P(2,1) = P(2,1)+A(I,I)
      DO 101 I=1,N
      X(:,1) = A(:,I)
      X(:,2) = 0q0
      X(I,2) = B(I)
      DO 102 J=2,K1+K2-1
      IF (J.LE.K2) X(:,J+1) = B*X(:,J)
      DO 103 K=MIN(J,K2+1),MAX(2,J-K1+1),-1
  103 X(:,K) = MATMUL(A,X(:,K))+B*X(:,K-1)
      IF (J.LE.K1) X(:,1) = MATMUL(A,X(:,1))
      DO 102 K=MAX(0,J-K1),MIN(J,K2)
  102 P(J-K+1,K+1) = P(J-K+1,K+1)+X(I,K+1)   
      P(K1+1,K2+1) = P(K1+1,K2+1)+DOT_PRODUCT(A(I,:),X(:,K2+1))
     *              +B(I)*X(I,K2)
  101 CONTINUE
C
C     Start the recursion of d_{i,j}
C
      D = 0q0
      D(1,1) = 1q0
      DO 107 I=1,K1+1
      K = 1
      IF (I.EQ.1) K = 2
      DO 107 J=K,K2+1
  107 D(I,J) = SUM(D(1:I,1:J)*P(I:1:-1,J:1:-1))/QFLOAT(2*(I+J-2))
C
C     Output the results in double precision
C
      C = D
      RETURN
      END
