#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*),prhs(*)
      integer nlhs,nrhs
      mwpointer mxgetpr,mxcreatedoublematrix
      mwsize mxgetdimensions
      mwpointer x1,x2,y
      integer dims(3),k(:),nind
      real*8 m1(:)
      allocatable :: m1,k

      x1 = mxgetpr(prhs(1))   ! x1 is A
      x2 = mxgetpr(prhs(2))   ! x2 is k_i
C
C     dims(1) is n, dims(3) is r
C
      call mxCopyPtrToInteger4(mxGetDimensions(prhs(1)),dims,3)
      allocate(m1(dims(3)))
      call mxcopyptrtoreal8(x2,m1,dims(3))
      allocate(k(dims(3)))
      k = nint(m1)
      nind = product(k+1)
      plhs(1) = mxcreatedoublematrix(nind,1,0)
      y = mxgetpr(plhs(1))
      call mdkl(%val(y),%val(x1),k,dims(1),dims(3),nind)
      return
      end

      SUBROUTINE MDKL(Y,AD,K,N,R,NIND)
      INTEGER L,N,M,R,NIND,K(R),SK(:),MAXK,L0,IND,SX
      INTEGER X(:),F(:,:),INDEX(:,:),S(:),LK0(:),PIND(:),CS(:)
      INTEGER*8 FAC(:)
      REAL*8 AD(N,N,R),Y(NIND)
      REAL*16 A(:,:,:),D(:),P(:),X0(:,:),X1(:,:),Y1
      ALLOCATABLE :: A,D,X,FAC,SK,F,INDEX,S,X0,X1,LK0,P,PIND,CS
 
      ALLOCATE(A(N,N,R))
      ALLOCATE(D(NIND))
      ALLOCATE(X(R))
      A = AD
      IF (N.EQ.1) THEN
         SX = SUM(K)
         ALLOCATE(P(SX))
         MAXK = MAXVAL(K)
         ALLOCATE(FAC(MAXK))
         P(1) = 0.5q0
         DO 102 I=2,SX
  102    P(I) = P(I-1)*(QFLOAT(I)-0.5q0)
         FAC(1) = 1
         DO 103 I=2,MAXK
  103    FAC(I) = FAC(I-1)*I
         X = 0
         SX = 0
         Y1 = 1q0
         D(1) = 1q0
         DO 100 I=2,NIND
         DO 101 J=1,R
         IF (X(J).EQ.K(J)) THEN
            X(J) = 0
            SX = SX-K(J)
            Y1 = Y1*QFLOAT(FAC(K(J)))/A(1,1,J)**K(J)
         ELSE
            X(J) = X(J)+1
            SX = SX+1
            Y1 = Y1*A(1,1,J)/QFLOAT(X(J))
            GOTO 100
         END IF
  101    CONTINUE
  100    D(I) = P(SX)*Y1
         Y = D
         RETURN
      END IF
      ALLOCATE(SK(R))
      SK(1) = K(1)
      DO 111 I=2,R
  111 SK(I) = SK(I-1)+K(I)
      M = SK(R)
      ALLOCATE(F(M,R))
      F = 0
      F(1,:) = 1
      DO 112 I=2,K(1)
  112 F(I,1) = I
      F(K(1)+1:M,1) = K(1)+1
      DO 113 J=2,R
      DO 114 I=1,K(J)
  114 F(I+1,J) = F(I+1,J-1)+F(I,J)                
      DO 115 I=K(J)+1,M-1
  115 F(I+1,J) = F(I+1,J-1)+F(I,J)-F(I-K(J),J-1)
  113 CONTINUE
C
C   Compute the index for the updating from one block to the
C   next block. 
C
      ALLOCATE(CS(R))
      ALLOCATE(S(R))
      ALLOCATE(PIND(NIND))
      ALLOCATE(INDEX(F(M,R),R))
      CS(1) = 1
      DO 126 I=2,R
  126 CS(I) = CS(I-1)*(1+K(I-1))
      PIND(1) = 1
      PIND(2) = CS(R)+1
      INDEX = 0
      DO 120 I=1,R
  120 INDEX(1,I) = R+1-I
      S = 0
      S(R) = 1
      DO 121 I=2,F(M,R)
      IND = I-F(S(R),R)
      DO 122 J=R-1,1,-1
      B = S(J+1)-K(J+1)
      IF (B.GT.0) THEN
         IND = IND+F(B,J)-F(B+1,J)
      ELSE IF (B.EQ.0) THEN
         IND = IND-1
      END IF
      IF (B.LT.S(J)) INDEX(I,J+1) = IND
      IND = IND+F(S(J)+1,J)
      IF (S(J).GT.0) IND = IND-F(S(J),J)
  122 CONTINUE
      IF (S(1).LT.K(1)) INDEX(I,1) = IND
      DO 123 J=1,R-1
      IF (S(J).LT.S(J+1).AND.S(J).NE.SK(J)) GOTO 124
  123 CONTINUE
      J = R
  124 S(J) = S(J)+1
      DO 125 I1=J,2,-1
  125 S(I1-1) = MAX(0,S(I1)-K(I1))
  121 PIND(I+1) = S(1)+SUM((S(2:R)-S(1:R-1))*CS(2:R))+1
C
C     Create the p coefficients
C
      ALLOCATE(P(NIND))
      P = 0q0
      DO 131 I=2,R+1
      DO 131 J=1,N
  131 P(I) = P(I)+A(J,J,R-I+2)
      ALLOCATE(LK0(M-1))    
      LK0 = F(2:M,R)-F(1:M-1,R)
      L0 = MAXVAL(LK0)
      ALLOCATE(X0(N,L0))
      ALLOCATE(X1(N,L0))
      X1 = 0q0
      DO 132 I=1,N
      X0 = 0q0
      X0(:,1:R) = A(:,I,R:1:-1)
      DO 133 I1=2,M-1
      X1(:,1:LK0(I1-1)) = X0(:,1:LK0(I1-1))
      X0 = 0q0
      DO 134 J=1,R
      DO 134 J1=1,F(I1,R)-F(I1-1,R)
      IND = INDEX(F(I1-1,R)+J1,J)
      IF (IND.GT.0) X0(:,IND) = X0(:,IND)+MATMUL(A(:,:,J),X1(:,J1))
  134 CONTINUE
  133 P(F(I1,R)+1:F(I1+1,R)) = P(F(I1,R)+1:F(I1+1,R))+X0(I,1:LK0(I1))
      DO 132 J=1,R
  132 P(NIND) = P(NIND)+DOT_PRODUCT(X0(:,J),A(:,I,J)) 
C
C   Compute d's using the long recursive relation
C
      P(PIND) = P
      D = P
      D(1) = 1q0
      X = 0
      SX = 0
      DO 163 I=2,NIND
      DO 161 II=1,R
      IF (X(II).LT.K(II)) THEN
         X(II) = X(II)+1
         SX = SX+1
         GOTO 162
      END IF
      X(II) = 0;
  161 SX = SX-K(II)
  162 S = 0
      J = 1
      DO 165 I1=1,PRODUCT(X+1)-2
      DO 164 J1=II,R
      IF (S(J1).LT.X(J1)) THEN
         S(J1) = S(J1)+1
         J = J+CS(J1)
         D(I) = D(I)+D(J)*P(I-J+1)
         GOTO 165 
      END IF
      S(J1) = 0
  164 J = J-X(J1)*CS(J1)
  165 CONTINUE
  163 D(I) = D(I)/QFLOAT(2*SX)
      Y = D
      RETURN
      END
