#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*),prhs(*)
      integer nlhs,nrhs
      mwpointer mxgetpr,mxcreatedoublematrix
      mwsize mxgetdimensions
      mwpointer x1,x2,y
      integer dims(3),k(:),nind
      real*8 m1(:)
      allocatable :: m1,k

      x1 = mxgetpr(prhs(1))   ! x1 is A
      x2 = mxgetpr(prhs(2))   ! x2 is k_i
C
C     dims(1) is n, dims(3) is r
C
      call mxCopyPtrToInteger4(mxGetDimensions(prhs(1)),dims,3)
      allocate(m1(dims(3)))
      call mxcopyptrtoreal8(x2,m1,dims(3))
      allocate(k(dims(3)))
      k = nint(m1)
      nind = product(k+1)
      plhs(1) = mxcreatedoublematrix(nind,1,0)
      y = mxgetpr(plhs(1))
      call mdks(%val(y),%val(x1),k,dims(1),dims(3),nind)
      return
      end

      SUBROUTINE MDKS(Y,AD,K,N,R,NIND)
      INTEGER L,N,M,R,NIND,K(R),SK(:),MAXK,L0,IND,SX0
      INTEGER KAPPA(:),X(:),F(:,:),INDEX(:,:),S(:),LK0(:)
      INTEGER SX(:),PIND(:),CS(:),CX(:)
      INTEGER*8 FAC(:)
      REAL*8 AD(N,N,R),Y(NIND)
      REAL*16 A(:,:,:),D(:),H(:),P(:),P1(:),E(:),X0(:,:),X1(:,:),Y1
      ALLOCATABLE :: A,D,KAPPA,X,H,FAC,SK,F,INDEX,S,X0,X1,LK0,P,E
      ALLOCATABLE :: P1,SX,PIND,CS,CX
 
      ALLOCATE(A(N,N,R))
      ALLOCATE(D(NIND))
      ALLOCATE(X(R))
      A = AD
      D = 0q0
      D(1) = 1q0
      IF (N.EQ.1) THEN
         SX0 = SUM(K)
         ALLOCATE(H(SX0))
         MAXK = MAXVAL(K)
         ALLOCATE(FAC(MAXK))
         H(1) = 0.5q0
         DO 102 I=2,SX0
  102    H(I) = H(I-1)*(QFLOAT(I)-0.5q0)
         FAC(1) = 1
         DO 103 I=2,MAXK
  103    FAC(I) = FAC(I-1)*I
         X = 0
         SX0 = 0
         Y1 = 1q0
         DO 100 I=2,NIND
         DO 101 J=1,R
         IF (X(J).EQ.K(J)) THEN
            X(J) = 0
            SX0 = SX0-K(J)
            Y1 = Y1*QFLOAT(FAC(K(J)))/A(1,1,J)**K(J)
         ELSE
            X(J) = X(J)+1
            SX0 = SX0+1
            Y1 = Y1*A(1,1,J)/QFLOAT(X(J))
            GOTO 100
         END IF
  101    CONTINUE
  100    D(I) = H(SX0)*Y1
         Y = D
         RETURN
      END IF
      ALLOCATE(KAPPA(R))
      ALLOCATE(SK(R))
      DO 110 I=1,R
  110 KAPPA(I) = MIN(N,K(I))
      SK(1) = KAPPA(1)
      DO 111 I=2,R
  111 SK(I) = SK(I-1)+KAPPA(I)
      M = MIN(N,SK(R))
      ALLOCATE(F(M+1,R))
      F = 0
      F(1,:) = 1
      DO 112 I=2,KAPPA(1)
  112 F(I,1) = I
      F(KAPPA(1)+1:M+1,1) = KAPPA(1)+1
      DO 113 J=2,R
      DO 114 I=1,KAPPA(J)
  114 F(I+1,J) = F(I+1,J-1)+F(I,J)                
      DO 115 I=KAPPA(J)+1,M
  115 F(I+1,J) = F(I+1,J-1)+F(I,J)-F(I-KAPPA(J),J-1)
  113 CONTINUE
C
C   Compute the index for the updating from one block to the
C   next block. 
C
      L = F(M+1,R)
      ALLOCATE(INDEX(L,R))
      ALLOCATE(CS(R))
      ALLOCATE(S(R))
      ALLOCATE(PIND(L))
      ALLOCATE(E(NIND))
      ALLOCATE(P1(NIND))
      ALLOCATE(SX(NIND))
      CS(1) = 1
      DO 116 I=2,R
  116 CS(I) = CS(I-1)*(1+K(I-1))
      PIND(1) = 1
      PIND(2) = CS(R)+1
      INDEX = 0
      DO 120 I=1,R
  120 INDEX(1,I) = R+1-I
      S = 0
      S(R) = 1
      SX(1) = 0
      SX(CS(R)+1) = 1
      DO 121 I=2,F(M,R)
      IND = I-F(S(R),R)
      DO 122 J=R-1,1,-1
      B = S(J+1)-KAPPA(J+1)
      IF (B.GT.0) THEN
         IND = IND+F(B,J)-F(B+1,J)
      ELSE IF (B.EQ.0) THEN
         IND = IND-1
      END IF
      IF (B.LT.S(J)) INDEX(I,J+1) = IND
      IND = IND+F(S(J)+1,J)
      IF (S(J).GT.0) IND = IND-F(S(J),J)
  122 CONTINUE
      IF (S(1).LT.KAPPA(1)) INDEX(I,1) = IND
      DO 123 J=1,R-1
      IF (S(J).LT.S(J+1).AND.S(J).NE.SK(J)) GOTO 124
  123 CONTINUE
      J = R
  124 S(J) = S(J)+1
      DO 125 I1=J,2,-1
  125 S(I1-1) = MAX(0,S(I1)-KAPPA(I1))
      PIND(I+1) = S(1)+SUM((S(2:R)-S(1:R-1))*CS(2:R))+1
  121 SX(PIND(I+1)) = S(R)
      DO 126 I=F(M,R)+1,F(M+1,R)-1
      DO 127 J=1,R-1
      IF (S(J).LT.S(J+1).AND.S(J).NE.SK(J)) GOTO 128
  127 CONTINUE
      J = R
  128 S(J) = S(J)+1
      DO 129 I1=J,2,-1
  129 S(I1-1) = MAX(0,S(I1)-KAPPA(I1))
      PIND(I+1) = S(1)+SUM((S(2:R)-S(1:R-1))*CS(2:R))+1
  126 SX(PIND(I+1)) = S(R)
C
C     Create the p coefficients
C
      ALLOCATE(P(L))
      P = 0q0
      DO 131 I=2,R+1
      DO 131 J=1,N
  131 P(I) = P(I)+A(J,J,R-I+2)
      ALLOCATE(LK0(M))    
      LK0 = F(2:M+1,R)-F(1:M,R)
      L0 = MAXVAL(LK0)
      ALLOCATE(X0(N,L0))
      ALLOCATE(X1(N,L0))
      X1 = 0q0
      DO 132 I=1,N
      X0 = 0q0
      X0(:,1:R) = A(:,I,R:1:-1)
      DO 133 I1=2,M-1
      X1(:,1:LK0(I1-1)) = X0(:,1:LK0(I1-1))
      X0 = 0q0
      DO 134 J=1,R
      DO 134 J1=1,F(I1,R)-F(I1-1,R)
      IND = INDEX(F(I1-1,R)+J1,J)
      IF (IND.GT.0) X0(:,IND) = X0(:,IND)+MATMUL(A(:,:,J),X1(:,J1))
  134 CONTINUE
  133 P(F(I1,R)+1:F(I1+1,R)) = P(F(I1,R)+1:F(I1+1,R))
     *                        +X0(I,1:LK0(I1))
      DO 135 J=1,R
      DO 135 J1=1,F(M,R)-F(M-1,R)
      IND = INDEX(F(M-1,R)+J1,J)
      IF (IND.GT.0) P(F(M,R)+IND) = P(F(M,R)+IND)
     *                              +DOT_PRODUCT(X0(:,J1),A(:,I,J)) 
  135 CONTINUE
  132 CONTINUE
C
C   Use multivariate Newton-Girard formula to obtain the
C   e coefficients.
C
      ALLOCATE(CX(R))
      P1(PIND) = P
      E = 0q0
      E(1) = 1q0
      X = 0
      SX0 = 0
      DO 140 I=2,NIND
      DO 141 II=1,R
      IF (X(II).LT.K(II)) THEN
         X(II) = X(II)+1
         SX0 = SX0+1
         GOTO 142
      END IF
      X(II) = 0
  141 SX0 = SX0-K(II)
  142 SK = 0
      J = 1
      DO 143 I1=II,R
  143 S(I1) = MIN(X(I1),N)
      CX(II) = S(II)+1
      DO 151 I1=II+1,R
  151 CX(I1) = CX(I1-1)*(S(I1)+1)
      IND = CX(R)-1
      IF (SX0.LE.N) THEN
         DO 144 I1=2,IND
         DO 145 I2=II,R
         IF (SK(I2).LT.S(I2)) THEN
            SK(I2) = SK(I2)+1
            J = J+CS(I2)
            E(I) = E(I)-P1(I-J+1)*E(J)
            D(I) = D(I)+P1(I-J+1)*D(J)
            GOTO 144
         END IF
         J = J-SK(I2)*CS(I2)
  145    SK(I2) = 0
  144    CONTINUE
         E(I) = (E(I)-P1(I))/QFLOAT(SX0)
         D(I) = (D(I)+P1(I))/QFLOAT(2*SX0)
      ELSE
         IF (ALL(X.GE.KAPPA)) THEN
            DO 146 I1=2,L
            J = PIND(I1)
  146       D(I) = D(I)+D(I-J+1)*E(J)*(QFLOAT(SX(J))/QFLOAT(2*SX0)-1q0)
         ELSE
            I1 = 0
            DO 148 WHILE (I1.LT.IND)
               DO 147 I2=II,R
               IF (SK(I2).LT.S(I2)) THEN
                  J = J+CS(I2)
                  SK(I2) = SK(I2)+1
                  IF (SX(J).NE.0) THEN
                     D(I) = D(I)+
     *               D(I-J+1)*E(J)*(QFLOAT(SX(J))/QFLOAT(2*SX0)-1q0)
                     I1 = I1+1
                     GOTO 148
                  END IF
                  IF (I2.EQ.II) THEN
                     I1 = I1+S(II)-SK(II)+1
                  ELSE
                     I1 = I1+CX(I2)-CX(I2-1)*SK(I2)
                  END IF
                  IF (I1.EQ.IND) GOTO 140
               END IF
               J = J-SK(I2)*CS(I2)
  147          SK(I2) = 0
  148       END DO 
         END IF
      END IF
  140 CONTINUE
      Y = D
      RETURN
      END
