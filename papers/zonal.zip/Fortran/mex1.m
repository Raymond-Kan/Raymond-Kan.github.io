arch = computer('arch');
lapacklib = fullfile(matlabroot,'extern','lib',arch,'microsoft','libmwlapack.lib');
blaslib = fullfile(matlabroot,'extern','lib',arch,'microsoft','libmwblas.lib');
mex -v dk.f
mex -v ecoeff2cq.f
mex -v ecoeff2q.f
mex -v mdkl2quad.f
mex -v mdklquad.f
mex -v mdks2quad.f
mex -v mdksquad.f
mex -v tau2quad.f
if strcmp(arch,'win32') 
   mex('-v','invpqf.f',lapacklib,blaslib)
   mex('-v','qmomlf.f',lapacklib,blaslib)
   mex('-v','qmomsf.f',lapacklib,blaslib)
end
if strcmp(arch,'win64') 
   mex('-v','-largeArrayDims','invpqf.f',lapacklib,blaslib)
   mex('-v','-largeArrayDims','qmomlf.f',lapacklib,blaslib)
   mex('-v','-largeArrayDims','qmomsf.f',lapacklib,blaslib)
end
