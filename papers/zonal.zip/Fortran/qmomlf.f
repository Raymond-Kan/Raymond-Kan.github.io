#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*),prhs(*)
      integer nlhs,nrhs,p,q,M
      mwpointer mxgetpr,mxcreatedoublescalar
      mwsize mxgetm,n
      mwpointer r1,r2,r3,r4,r5,r6,l1,l2,l3
      real*8 temp,E

      r1 = mxgetpr(prhs(1))
      r2 = mxgetpr(prhs(2))
      r3 = mxgetpr(prhs(3))
      r4 = mxgetpr(prhs(4))
      r5 = mxgetpr(prhs(5))
      r6 = mxgetpr(prhs(6))
      plhs(1) = mxcreatedoublescalar(0)
      plhs(2) = mxcreatedoublescalar(0)
      plhs(3) = mxcreatedoublescalar(0)
      l1 = mxgetpr(plhs(1))
      l2 = mxgetpr(plhs(2))
      l3 = mxgetpr(plhs(3))
      n = mxgetm(prhs(1))
      call mxcopyptrtoreal8(r3,temp,1)
      p = nint(temp)
      call mxcopyptrtoreal8(r4,temp,1)
      q = nint(temp)
      call mxcopyptrtoreal8(r5,E,1)
      call mxcopyptrtoreal8(r6,temp,1)
      M = nint(temp)
      call mratio(%val(l1),%val(l2),%val(l3),%val(r1),%val(r2),
     *            p,q,E,M,n)
      return
      end

      SUBROUTINE MRATIO(MOMD,ERRD,M0,A,B,P,Q,ED,M,N)
      MWSIGNEDINDEX N,LWORK,INFO
      INTEGER P,Q,M,CR,PEND,K1,P1
      REAL*8 M0,MOMD,ERRD,A(N,N),B(N),ED,X0(:,:),WORK(:),EAD(:)
      REAL*16 MOM,ERR,MAXEA,MAXEB,E0,SX,N2P,E,CONST
      REAL*16 EA(:),EB(:),X(:,:,:),X1(:,:,:),AT(:,:)
      REAL*16 EE(:),TC(:),NC(:),AD(:,:),DD(:,:)
      REAL*16 PCOEFF(:,:),PCOEFF1(:,:),D(:,:),D1(:,:)
      
      ALLOCATABLE :: PCOEFF,PCOEFF1,D,D1,WORK,X,X1,X0,EA,EB,AT,EAD
      ALLOCATABLE :: EE,TC,NC,AD,DD
      E = ED
      N2P = QFLOAT(N)/2q0+QFLOAT(P)
      PEND = P+1
      ALLOCATE(AD(N,N))
      ALLOCATE(DD(N,N))
      ALLOCATE(PCOEFF(PEND,PEND+M))
      ALLOCATE(X(N,N,PEND))
      ALLOCATE(D(PEND,M+1))
      ALLOCATE(X0(N,N))
      ALLOCATE(EAD(N))
      ALLOCATE(EA(N))
      ALLOCATE(EB(N))
      ALLOCATE(EE(PEND))
      LWORK = 3*N
      ALLOCATE(WORK(LWORK))
C
C     Call LAPACK dsyev to produce the eigenvalues of A
C
      X0 = A
      CALL DSYEV('N','U',N,X0,N,EAD,WORK,LWORK,INFO)
      CR = 1
      MAXEA = MAXVAL(ABS(EAD))
      AD = A/MAXEA
      IF (ALL(EAD.LE.0d0)) THEN
         CR = 2
         AD = -AD
      ELSEIF ((MOD(P,2).EQ.1).AND.(MAXVAL(EAD)*MINVAL(EAD).LT.0d0)) THEN
         CR = 3
         ALLOCATE(AT(N,N))
         ALLOCATE(PCOEFF1(PEND,PEND+M))
         ALLOCATE(X1(N,N,PEND))
         ALLOCATE(D1(PEND,M+1))
      END IF
      MAXEB = MAXVAL(B)
      EB = B/MAXEB
      EE(1) = 1q0
      IF (P.GT.0) THEN
         IF (CR.LT.3) THEN
            DO 120 I=1,N
            DO 120 J=1,N
  120       X0(I,J) = AD(I,J)/SQRT(EB(I)*EB(J))
         ELSE
            X0 = AD
            CALL DSYEV('V','U',N,X0,N,EAD,WORK,LWORK,INFO)
            EA = EAD
            DO 104 I=1,N
  104       AT(:,I) = ABS(EA(I))*X0(:,I)
            AT = MATMUL(AT,TRANSPOSE(X0))
            DO 121 I=1,N
            DO 121 J=1,N
  121       X0(I,J) = AT(I,J)/SQRT(EB(I)*EB(J))
         END IF
         CALL DSYEV('N','U',N,X0,N,EAD,WORK,LWORK,INFO)
C
C     Generate d_p(\tilde{A}*inv(B)) for error bound
C
         ALLOCATE(TC(P))
         ALLOCATE(NC(N))
         EA = EAD
         NC = 1q0
         DO 109 I=1,P
         NC = NC*EA
         TC(I) = SUM(NC)
  109    EE(I+1) = DOT_PRODUCT(TC(I:1:-1),EE(1:I))/QFLOAT(2*I)
      END IF
      E0 = EE(PEND)/SQRT(PRODUCT(EB))
      EB = 1q0-EB
C
C     Generate p_{i,j} for recursive algorithm
C
      PCOEFF = 0q0
      X = 0q0
      DD = 0q0
      DO 100 I=1,N
      DD(I,:) = EB(I)
      IF (P.GT.0) X(I,I,2) = 1q0
  100 X(I,I,1) = 1q0
      IF (CR.EQ.3) X1 = X
      DO 101 J=1,P
      X(:,:,J+1) = DD*X(:,:,J)
      DO 102 K=J,2,-1
  102 X(:,:,K) = MATMUL(AD,X(:,:,K))+DD*X(:,:,K-1)
      X(:,:,1) = MATMUL(AD,X(:,:,1))
      DO 103 K=1,J+1
      DO 103 I=1,N
  103 PCOEFF(J+2-K,K) = PCOEFF(J+2-K,K)+X(I,I,K)
  101 CONTINUE
      IF (CR.EQ.3) THEN
         PCOEFF1 = 0q0
         DO 106 J=1,P
         X1(:,:,J+1) = DD*X1(:,:,J)
         DO 107 K=J,2,-1
  107    X1(:,:,K) = MATMUL(AT,X1(:,:,K))+DD*X1(:,:,K-1)
         X1(:,:,1) = MATMUL(AT,X1(:,:,1))
         DO 108 K=1,J+1
         DO 108 I=1,N
  108    PCOEFF1(J+2-K,K) = PCOEFF1(J+2-K,K)+X1(I,I,K)
  106    CONTINUE
      END IF
C
C     Generate d's and m's
C
      D = 0q0
      D(1,1) = 1q0
      IF (CR.EQ.3) D1 = D
C
C     k=0
C
      CONST = 1q0
      DO 110 I=1,P
      D(I+1,1) = SUM(D(1:I+1,1)*PCOEFF(I+1:1:-1,1))/QFLOAT(2*I)
      IF (CR.EQ.3)
     *   D1(I+1,1) = SUM(D1(1:I+1,1)*PCOEFF1(I+1:1:-1,1))/QFLOAT(2*I)
  110 CONST = QFLOAT(2*I)*MAXEA*CONST
      DO 111 I=1,Q
  111 CONST = CONST/(QFLOAT(N+2*(P-I))*MAXEB)
      MOM = CONST*D(PEND,1)
      CONST = CONST*QFLOAT(Q)/N2P
      IF (CR.EQ.3) THEN
         E0 = E0-D1(PEND,1)
      ELSE
         E0 = E0-D(PEND,1)
      END IF
      ERR = E0*CONST
C
C     k>0
C
      K1 = 2
      DO 114 WHILE (ERR.GT.E.AND.K1.LE.M+1)
      DO 131 K=1,P
  131 X(:,:,K) = MATMUL(AD,X(:,:,K+1))+DD*X(:,:,K)
      X(:,:,PEND) = DD*X(:,:,PEND)
      DO 132 K=1,PEND
      DO 132 I=1,N
  132 PCOEFF(PEND+1-K,K1+K-1) = PCOEFF(PEND+1-K,K1+K-1)+X(I,I,K)
      IF (CR.EQ.3) THEN
         DO 133 K=1,P
  133    X1(:,:,K) = MATMUL(AT,X1(:,:,K+1))+DD*X1(:,:,K)
         X1(:,:,PEND) = DD*X1(:,:,PEND)
         DO 134 K=1,PEND
         DO 134 I=1,N
  134    PCOEFF1(PEND+1-K,K1+K-1) = PCOEFF1(PEND+1-K,K1+K-1)+X1(I,I,K)
      END IF
      DO 113 P1=1,PEND
      SX = QFLOAT(2*(P1+K1-2))
      D(P1,K1) = SUM(D(1:P1,1:K1)*PCOEFF(P1:1:-1,K1:1:-1))/SX
      IF (CR.EQ.3) D1(P1,K1) = 
     *             SUM(D1(1:P1,1:K1)*PCOEFF1(P1:1:-1,K1:1:-1))/SX
  113 CONTINUE
      MOM = MOM+CONST*D(PEND,K1)
      CONST = CONST*QFLOAT(Q+K1-1)/(N2P+QFLOAT(K1-1))
      IF (CR.EQ.3) THEN
         E0 = E0-D1(PEND,K1)
      ELSE
         E0 = E0-D(PEND,K1)
      END IF
      ERR = E0*CONST
      K1 = K1+1
  114 END DO
      M0 = QFLOAT(K1-2)
      ERRD = ERR
      MOMD = MOM
      IF (CR.EQ.2) MOMD = -MOMD
      RETURN
      END
