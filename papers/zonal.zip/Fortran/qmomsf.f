#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*),prhs(*)
      integer nlhs,nrhs,p,q,M
      mwpointer mxgetpr,mxcreatedoublescalar
      mwsize mxgetm,n
      mwpointer r1,r2,r3,r4,r5,r6,l1,l2,l3
      real*8 temp,E

      r1 = mxgetpr(prhs(1))
      r2 = mxgetpr(prhs(2))
      r3 = mxgetpr(prhs(3))
      r4 = mxgetpr(prhs(4))
      r5 = mxgetpr(prhs(5))
      r6 = mxgetpr(prhs(6))
      plhs(1) = mxcreatedoublescalar(0)
      plhs(2) = mxcreatedoublescalar(0)
      plhs(3) = mxcreatedoublescalar(0)
      l1 = mxgetpr(plhs(1))
      l2 = mxgetpr(plhs(2))
      l3 = mxgetpr(plhs(3))
      n = mxgetm(prhs(1))
      call mxcopyptrtoreal8(r3,temp,1)
      p = nint(temp)
      call mxcopyptrtoreal8(r4,temp,1)
      q = nint(temp)
      call mxcopyptrtoreal8(r5,E,1)
      call mxcopyptrtoreal8(r6,temp,1)
      M = nint(temp)
      call mratio(%val(l1),%val(l2),%val(l3),%val(r1),%val(r2),
     *            p,q,E,M,n)
      return
      end

      SUBROUTINE MRATIO(MOMD,ERRD,M0,A,B,P,Q,ED,M,N)
      MWSIGNEDINDEX N,LWORK,INFO
      INTEGER P,Q,M,CR,PEND,K1,P1
      REAL*8 M0,MOMD,ERRD,A(N,N),B(N),ED,X0(:,:),WORK(:),EAD(:)
      REAL*16 MOM,ERR,MAXEA,MAXEB,E0,SX,N2P,E,CONST
      REAL*16 EA(:),EB(:),AT(:,:)
      REAL*16 EE(:),TC(:),NC(:),AD(:,:)
      REAL*16 ECOEFF(:,:),ECOEFF1(:,:),D(:,:),D1(:,:)
      
      ALLOCATABLE :: D,D1,WORK,X0,EA,EB,AT,EAD
      ALLOCATABLE :: ECOEFF,ECOEFF1,EE,TC,NC,AD
      E = ED
      N2P = QFLOAT(N)/2q0+QFLOAT(P)
      PEND = P+1
      P1 = MIN(P,N)
      ALLOCATE(AD(N,N))
      ALLOCATE(ECOEFF(P1+1,N+1))
      ALLOCATE(D(PEND,N+1))
      ALLOCATE(X0(N,N))
      ALLOCATE(EAD(N))
      ALLOCATE(EA(N))
      ALLOCATE(EB(N))
      ALLOCATE(EE(PEND))
      LWORK = 3*N
      ALLOCATE(WORK(LWORK))
C
C     Call LAPACK dsyev to produce the eigenvalues of A
C
      X0 = A
      CALL DSYEV('N','U',N,X0,N,EAD,WORK,LWORK,INFO)
      CR = 1
      MAXEA = MAXVAL(ABS(EAD))
      AD = A/MAXEA
      IF (ALL(EAD.LE.0d0)) THEN
         CR = 2
         AD = -AD
      ELSEIF ((MOD(P,2).EQ.1).AND.(MAXVAL(EAD)*MINVAL(EAD).LT.0d0)) THEN
         CR = 3
         ALLOCATE(AT(N,N))
         ALLOCATE(ECOEFF1(P1+1,N+1))
         ALLOCATE(D1(PEND,N+1))
      END IF
      MAXEB = MAXVAL(B)
      EB = B/MAXEB
      EE(1) = 1q0
      IF (P.GT.0) THEN
         IF (CR.LT.3) THEN
            DO 120 I=1,N
            DO 120 J=1,N
  120       X0(I,J) = AD(I,J)/SQRT(EB(I)*EB(J))
         ELSE
            X0 = AD
            CALL DSYEV('V','U',N,X0,N,EAD,WORK,LWORK,INFO)
            EA = EAD
            DO 104 I=1,N
  104       AT(:,I) = ABS(EA(I))*X0(:,I)
            AT = MATMUL(AT,TRANSPOSE(X0))
            DO 121 I=1,N
            DO 121 J=1,N
  121       X0(I,J) = AT(I,J)/SQRT(EB(I)*EB(J))
         END IF
         CALL DSYEV('N','U',N,X0,N,EAD,WORK,LWORK,INFO)
C
C     Generate d_p(\tilde{A}*inv(B)) for error bound
C
         ALLOCATE(TC(P))
         ALLOCATE(NC(N))
         EA = EAD
         NC = 1q0
         DO 109 I=1,P
         NC = NC*EA
         TC(I) = SUM(NC)
  109    EE(I+1) = DOT_PRODUCT(TC(I:1:-1),EE(1:I))/QFLOAT(2*I)
      END IF
      E0 = EE(PEND)/SQRT(PRODUCT(EB))
      EB = 1q0-EB
      CALL ECOEFFC(ECOEFF,AD,EB,N,P1)
      IF (CR.EQ.3) THEN
         CALL ECOEFFC(ECOEFF1,AT,EB,N,P1)
      END IF
C
C     Generate d's and m's
C
      D = 0q0
      D(1,1) = 1q0
      IF (CR.EQ.3) D1 = D
C
C     k=0
C
      CONST = 1q0
      DO 110 I=1,P
      N1 = MIN(N,I)
      D(I+1,1) = SUM((/(J,J=1-2*I,N1-2*I)/)*
     *           D(I:I+1-N1:-1,1)*ECOEFF(2:N1+1,1))/QFLOAT(2*I)
      IF (CR.EQ.3) D1(I+1,1) = SUM((/(J,J=1-2*I,N1-2*I)/)*
     *             D1(I:I+1-N1:-1,1)*ECOEFF1(2:N1+1,1))/QFLOAT(2*I)
  110 CONST = QFLOAT(2*I)*MAXEA*CONST
      DO 111 I=1,Q
  111 CONST = CONST/(QFLOAT(N+2*(P-I))*MAXEB)
      MOM = CONST*D(PEND,1)
      CONST = CONST*QFLOAT(Q)/N2P
      IF (CR.EQ.3) THEN
         E0 = E0-D1(PEND,1)
      ELSE
         E0 = E0-D(PEND,1)
      END IF
      ERR = E0*CONST
C
C     k>0
C
      K = 1
      DO 116 WHILE (ERR.GT.E.AND.K.LE.M)
      IF (K.GT.N) THEN
         K1 = N+1
         D(:,1:N) = D(:,2:N+1)
         D(:,N+1) = 0q0
         IF (CR.EQ.3) THEN
            D1(:,1:N) = D1(:,2:N+1)
            D1(:,N+1) = 0q0
         END IF
      ELSE
         K1 = K+1
      END IF
      DO 113 P1=1,PEND
      SX = QFLOAT(2*(P1+K-1))
      DO 114 J=0,MIN(N-1,K)
      DO 114 I=MAX(0,1-J),MIN(P1-1,N-J)
  114 D(P1,K1) = D(P1,K1)+(QFLOAT(I+J)/SX-1q0)*ECOEFF(I+1,J+1)*
     *           D(P1-I,K1-J)
      IF (CR.EQ.3) THEN
         DO 115 J=0,MIN(N-1,K)
         DO 115 I=MAX(0,1-J),MIN(P1-1,N-J)
  115    D1(P1,K1) = D1(P1,K1)+(QFLOAT(I+J)/SX-1q0)*ECOEFF1(I+1,J+1)*
     *               D1(P1-I,K1-J)
      END IF
  113 CONTINUE
      MOM = MOM+CONST*D(PEND,K1)
      CONST = CONST*QFLOAT(Q+K)/(N2P+QFLOAT(K))
      IF (CR.EQ.3) THEN
         E0 = E0-D1(PEND,K1)
      ELSE
         E0 = E0-D(PEND,K1)
      END IF
      ERR = E0*CONST
      K = K+1
  116 END DO
      M0 = DFLOAT(K-1)
      ERRD = ERR
      MOMD = MOM
      IF (CR.EQ.2) MOMD = -MOMD
      RETURN
      END

      SUBROUTINE ECOEFFC(E,A,B,N,PA)
      INTEGER I,J,K,N,PA
      REAL*16 A(N,N),B(N),E(PA+1,N+1),X(:,:),P(:,:),B1(:)
      ALLOCATABLE :: X,P,B1
      ALLOCATE(X(N,PA+1))
      ALLOCATE(P(PA+1,N+1))
      P = 0q0
      IF (PA.EQ.0) THEN
         ALLOCATE(B1(N))
         B1 = 1q0
         DO 105 I=2,N+1
         B1 = B1*B                 
  105    P(1,I) = SUM(B1)
      ELSE
C
C     Compute p_{i,j}'s
C
         DO 100 I=1,N
         P(2,1) = P(2,1)+A(I,I)
  100    P(1,2) = P(1,2)+B(I)
         DO 101 I=1,N
         X(:,1) = A(:,I)
         X(:,2) = 0q0
         X(I,2) = B(I)
         DO 102 J=2,PA
         X(:,J+1) = B*X(:,J)
         DO 103 K=J,2,-1
  103    X(:,K) = MATMUL(A,X(:,K))+B*X(:,K-1)
         X(:,1) = MATMUL(A,X(:,1))
         DO 102 K=0,J
  102    P(J-K+1,K+1) = P(J-K+1,K+1)+X(I,K+1)   
         DO 107 J=1,N-PA
         DO 108 K=1,PA
  108    X(:,K) = MATMUL(A,X(:,K+1))+B*X(:,K)
         X(:,PA+1) = B*X(:,PA+1)
         DO 107 K=0,PA
  107    P(PA-K+1,J+K+1) = P(PA-K+1,J+K+1)+X(I,K+1)   
  101    CONTINUE
      END IF
C
C     Use multivariate Newton-Girard formula to
C     compute e_{i,j} from p_{i,j} 
C
      E = 0q0
      E(1,1) = 1q0
      DO 104 I=1,PA+1
      DO 104 J=MAX(1,3-I),N+2-I
  104 E(I,J) = -SUM(E(1:I,1:J)*P(I:1:-1,J:1:-1))/QFLOAT(I+J-2)
      RETURN
      END
