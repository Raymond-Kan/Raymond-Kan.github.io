#include "fintrf.h"
      subroutine mexFunction(nlhs, plhs, nrhs, prhs)
      mwpointer plhs(*),prhs(*)
      integer nlhs,nrhs
      mwpointer mxcreatedoublematrix,mxgetpr
      mwsize mxgetm,n
      mwpointer a,b,c

      a = mxgetpr(prhs(1))
      b = mxgetpr(prhs(2))
      n = mxgetm(prhs(1))
      plhs(1) = mxcreatedoublematrix(n+1,n+1,0)
      c = mxgetpr(plhs(1))
      call tau2(%val(c),%val(a),%val(b),n)
      return
      end

      SUBROUTINE TAU2(C,AD,BD,N)
      INTEGER I,J,K,N
      REAL*8 AD(N,N),BD(N),C(N+1,N+1)
      REAL*16 X(:,:),H(:,:),A(:,:),B(:)
      ALLOCATABLE :: X,H,A,B

      ALLOCATE(A(N,N))
      ALLOCATE(B(N))
      ALLOCATE(X(N,N))
      ALLOCATE(H(N+1,N+1))
      A = AD
      B = BD
      H = 0q0
      DO 100 I=1,N
      H(2,1) = H(2,1)+A(I,I)
  100 H(1,2) = H(1,2)+B(I)
      DO 101 I=1,N
      X(:,1) = A(:,I)
      X(:,2) = 0q0
      X(I,2) = B(I)
      DO 102 J=2,N-1
      X(:,J+1) = B*X(:,J)
      DO 103 K=J,2,-1
  103 X(:,K) = MATMUL(A,X(:,K))+B*X(:,K-1)
      X(:,1) = MATMUL(A,X(:,1))
      DO 102 K=0,J
  102 H(J-K+1,K+1) = H(J-K+1,K+1)+X(I,K+1)   
      H(N+1,1) = H(N+1,1)+DOT_PRODUCT(A(I,:),X(:,1))
      H(1,N+1) = H(1,N+1)+B(I)*X(I,N)
      DO 101 J=1,N-1
  101 H(N-J+1,J+1) = H(N-J+1,J+1)+DOT_PRODUCT(A(I,:),X(:,J+1))
     *              +B(I)*X(I,J)
C
C     Output the results in double precision
C
      C = H
      RETURN
      END
