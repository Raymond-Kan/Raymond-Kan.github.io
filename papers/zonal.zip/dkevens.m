%
%   This Matlab function computes d_k(A) for k=0,...,M
%   when the eigenvalues of A have even multiplicities
%   using Symbolic Math Toolbox
%   a: eigenvalues of A
%   n: multiplicities of a 
%
function y = dkevens(M,a,n)
if M==0
   y = sym(1);
   return
end
m = n./2;
y = sym(zeros(M+1,1));
if length(a)==1
   y(1) = 1;
   for i=1:M
       y(i+1) = a*y(i)*sym((m+i-1)/i);
   end
   return
end
for i=1:length(a)
    b = sym(zeros(m(i),1));
    a1 = a;
    a1(i) = [];
    m1 = m;
    m1(i) = [];
    b0 = dkrecurs(m(i)-1,a1./(a1-a(i)),2*m1)./prod((1-a1./a(i)).^m1);
    b(end) = b0(end);
    if m(i)>1
       c = sym(1);
       for j=1:m(i)-1
           c = [c(1)/j; c(2:end)./j+c(1:end-1); c(end)];
           b(end-j:end) = b(end-j:end)+c*b0(m(i)-j);
       end           
    end
    y = y+polyvals(b,[0:M]').*(a(i).^[0:M]');
end


