%
%   This Matlab function computes d_k(A) for k=0,...,M
%   a: eigenvalues of A
%   n: multiplicities of a (default is a vector of ones)
%
function y = dkr(M,a,n)
if M==0
   y = 1;
   return
end
if nargin<3
   n = ones(size(a));
end
if size(a,1)==1
   a = a';
   n = n';
end
y = dk(M,a,n);
