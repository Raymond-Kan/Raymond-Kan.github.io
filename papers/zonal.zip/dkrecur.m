%
%   This Matlab function computes d_k(A) for k=0,...,M
%   a: eigenvalues of A
%   n: multiplicities of a (default is a vector of ones)
%
function y = dkrecur(M,a,n)
y = ones(M+1,1);
s = length(a);
L = min(M,s);
p = poly(a);  
%
%   We flip p for programming convenience
%
p = fliplr(p(2:L+1));
if nargin<3
   n = ones(size(a));
end
if min(n)==max(n)
   m = n(1);  
   if m==2
      for i=1:L
          y(i+1) = -p(L-i+1:end)*y(1:i);
      end
      for i=L+1:M
          y(i+1) = -p*y(i-s+1:i);
      end
   else
      for i=1:L
          y(i+1) = (-([m*i:(2-m):m+2*i-2]./(2*i)).*p(L-i+1:end))*y(1:i);
      end
      for i=L+1:M
          y(i+1) = (-([2*i-(2-m)*s:(2-m):m+2*i-2]./(2*i)).*p)*y(i-s+1:i);
      end
   end
   return
end
t = zeros(L,1);
na = n;
if M<=s
   for i=1:M
       na = na.*a;
       t(i) = sum(na);
       y(i+1) = (y(i:-1:1)'*t(1:i))/(2*i);
   end
   return
end
c = zeros(1,L);
for i=1:L
    na = na.*a;
    t(i) = sum(na);
    c(L+1-i) = i*p(L+1-i)+(t(i)+p(L+2-i:end)*t(1:i-1))/2;
%
%   For the first L elements of dk, can use either Ruben's
%   recursive relation or ours.
%   Ruben: y(i+1) = (y(i:-1:1)'*t(1:i))/(2*i);
%   Ours:  y(i+1) = (c(L-i+1:end)./i-p(L-i+1:end))*y(1:i);
%
    y(i+1) = (y(i:-1:1)'*t(1:i))/(2*i);
end
for i=L+1:M
    y(i+1) = (c./i-p)*y(i-s+1:i);
end
