%
%  This program generates the coefficient e's for |I-t_1A_1-...-t_rA_r|
% 
function e = ecoeff(A)
n = size(A,1);
r = size(A,3);
%
%  Quick return for r=1 or n=1
%
if r==1
   e = poly(eig(A));
   return
end
if n==1
   e = zeros(r+1,1);
   e(1) = 1;
   e(r+1:-1:2) = -squeeze(A);
   return
end
F = zeros(n+1,r);
F(1,:) = 1;
F(2:end,1) = 2:n+1;
for j=2:r
    for i=2:n+1
        F(i,j) = F(i,j-1)+F(i-1,j);
    end
end
lx0 = F(n,r-1);   % max length of x0, when |v|=n-1, there are (n+r-2,r-1) different coefficients
%
%   Create a matrix index which allows us to update the x0 matrix 
%   from block k to block k+1.
%
if r==2
   index = [2:n+1]';
else
   index = zeros(lx0,r-1);
   index(1,:) = 1;
   for k=1:n-1      
       lk = F(k+1,r-1);
       lk0 = F(k,r-1);
       index(lk0+1:lk,r-1) = F(k+1,r-2);
       for i=r-2:-1:2
           d = F(k,i);
           index(lk0+1:lk0+d,2:i) = index(lk0-d+1:lk0,2:i);
           lk0 = lk0+d;
           index(lk0+1:lk,i) = F(k+1,i-1);
       end
   end
   index(:,1) = 1;
   index(:,r-1) = index(:,r-1)+[1:lx0]';
   for i=r-2:-1:1
       index(:,i) = index(:,i)+index(:,i+1);
   end
end
%
% When k=1, p(2:r+1) are trace of A_r to trace of A_1
%
l = F(end);
p = zeros(l,1);
for i=1:r
    p(i+1) = trace(A(:,:,r-i+1));
end
lx = F(n-1,r-1);
x = zeros(n,lx);
for i=1:n         % trace of a matrix is equal to the sum of the diagonal elements
    x0 = zeros(n,lx0);
    x0(:,1:r) = A(:,i,r:-1:1);
    lk0 = F(2,r-1);
    for k=2:n-1          % |nu|=k
        x(:,1:lk0) = x0(:,1:lk0);           % copy the old x0 to x
        x0(:,1:lk0) = A(:,:,r)*x(:,1:lk0);  % updates of A_r from x to x0
        for j=1:r-1
            x0(:,index(1:lk0,j)) = x0(:,index(1:lk0,j))+A(:,:,j)*x(:,1:lk0);
        end
        sp = F(k,r);
        lk0 = F(k+1,r-1);       
        p(sp+1:sp+lk0) = p(sp+1:sp+lk0)+x0(i,1:lk0)';
    end
%
% Separately for k=n as there is no need to update x0 anymore
%
    sp = F(n,r);
    p(sp+1:sp+lx0) = p(sp+1:sp+lx0)+x0'*A(i,:,r)';
    for j=1:r-1
        p(sp+index(:,j)) = p(sp+index(:,j))+x0'*A(i,:,j)';
    end
end
%
%   Use multivariate Newton-Girard formula to obtain the
%   e coefficients.
%
e = zeros(l,1);
e(1) = 1;
e(2:r+1) = -p(2:r+1);   % for k=1
for k=2:n
    S = [zeros(1,r-1) k];
    S(r) = k;
    i = F(k,r)+1;
    ind1 = F(1:k-1,r)+1;
    e(i) = (-p(i)-p(ind1)'*e(flipud(ind1)))/k;
    j = r; 
    for i=F(k,r)+2:F(k+1,r)
%
%       Update S
%
        if j>1
           j = j-1;
           S(j) = S(j)+1;
        else
           while S(j)==S(j+1)
              j = j+1;
           end
           S(j) = S(j)+1;
           S(1:j-1) = 0;
        end
        ka = [S(1) diff(S)];
        e(i) = -p(i);
        x = zeros(1,r);
        hh = find(ka>0);
        for ii=1:prod(ka+1)-2
            for jj=hh
                if x(jj)<ka(jj)
                   x(jj) = x(jj)+1;
                   break
                else
                   x(jj) = 0;
                end
            end
            S1 = cumsum(x);
            ind1 = F(S1(r),r)+1;
            jj = r-1;
            while jj>0&&S1(jj)>0
               ind1 = ind1+F(S1(jj),jj);
               jj = jj-1;
            end
            S1 = S-S1;
            ind2 = F(S1(r),r)+1;
            jj = r-1;
            while jj>0&&S1(jj)>0
                ind2 = ind2+F(S1(jj),jj);
                jj = jj-1;
            end
            e(i) = e(i)-p(ind1)*e(ind2);
        end
        e(i) = e(i)/k;
    end
end 

