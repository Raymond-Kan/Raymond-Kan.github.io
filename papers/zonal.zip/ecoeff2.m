function e = ecoeff2(A,B)
%
%     This program computes the coefficients of 
%     |I_n-x*A-y*B|.  The output is an (n+1)x(n+1) 
%     matrix with elements e_{i-1,j-1}.
%
n = size(A,1);
e = zeros(n+1);
p = tau2(A,B);
e(1,1) = 1;
%
%   Compute e's from p's using multivariate
%   Newton-Girard formula.
%
for i=1:n+1
    for j=1+(i==1):n+2-i
        e(i,j) = -sum(sum(e(1:i,1:j).*p(i:-1:1,j:-1:1)))/(i+j-2);
    end
end
