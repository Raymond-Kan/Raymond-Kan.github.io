%
%     This program computes the coefficients of 
%     |I_n-x*A-y*diag(B)|.  The output is an (pa+1)x(n+1) 
%     matrix with elements e_{i-1,j-1}.
%
%     It calls ecoeff2cq.mex32 that uses quadruple
%     precision.
%     Usage: ecoeff2cq(A,b,pa)
%