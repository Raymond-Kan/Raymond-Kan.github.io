%
%     This program computes the coefficients of 
%     |I_n-x*A-y*B|.  The output is an (n+1)x(n+1) 
%     matrix with elements e_{i-1,j-1}.
%
%     It calls ecoeff2q.mex32 that uses quadruple
%     precision.
%     Usage: ecoeff2q(A,B)
%