%
%  This Matlab function generates the coefficients of t_1^it_2^j in
%  the expansion of |I_n-t_1A-t_2B|
% 
function q = ecoeff2s(A,B)
syms x y positive
n = size(A,1);
q = zeros(n+1);
[P,D] = eig(B);
c = det(eye(n)-x*A-y*B);
maple('with(PolynomialTools):');
c1 = sym(maple('CoefficientList',c,y));
for i=1:size(c1,2)
    c2 = sym(maple('CoefficientList',c1(i),x));
    q(1:length(c2),i) = double(c2)';
end
