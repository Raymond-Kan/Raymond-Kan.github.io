%
%  This program generates the coefficient e's for |I-t_1A_1-...-t_rA_r|
%  but with the constraint nu<=kappa
% 
function e = ecoeffc(A,kappa)
index = find(kappa>0);
kappa = kappa(index);
A = A(:,:,index);
n = size(A,1);
r = size(A,3);
%
%  Quick return for r=1 or n=1
%
if r==1
   e = poly(eig(A));
   return
end
if n==1
   e = zeros(r+1,1);
   e(1) = 1;
   e(r+1:-1:2) = -squeeze(A);
   return
end
kappa = min(kappa,n);
sk = cumsum(kappa);
M = min(n,sk(r));
F = zeros(M+1,r);
F(1,:) = 1;
F(2:M+1,1) = min([2:M+1]',kappa(1)+1);
for j=2:r
    if kappa(j)==0
       F(:,j) = F(:,j-1);
    else
       for i=1:kappa(j)
           F(i+1,j) = F(i+1,j-1)+F(i,j);
       end
       for i=kappa(j)+1:M
           F(i+1,j) = F(i+1,j-1)+F(i,j)-F(i-kappa(j),j-1);
       end
    end
end
%
%   Compute the index for the updating from one block to the
%   next block. 
%
index = zeros(F(M,r),r);
index(1,:) = r:-1:1;
S = [zeros(1,r-1) 1];  % Can set first S to this because kappa_r>0
% Loop through all possible nu's with |nu|<=n and nu<=kappa
for i=2:F(M,r)         
    df = i-F(S(r),r);  % Position of S in its own block
    for ss=r-1:-1:1    % Going backward by setting index(i,r) first
        b = S(ss+1)-kappa(ss+1);
        if b>0
           df = df+F(b,ss)-F(b+1,ss);
        elseif b==0
           df = df-1;
        end
        if b<S(ss)   % Check constraint for the 2nd to last element
           index(i,ss+1) = df;
        end
        df = df+F(S(ss)+1,ss);
        if S(ss)>0
           df = df-F(S(ss),ss);
        end
    end               
    if S(1)<kappa(1)  % Check constraint for the first element
       index(i,1) = df;
    end
% Create next S
    j = 1;
    while j<r&&(S(j)==S(j+1)||S(j)==sk(j))
       j = j+1;
    end  
    S(j) = S(j)+1;
    for ss=j:-1:2
        S(ss-1) = max(0,S(ss)-kappa(ss));
    end
end
%
% When k=1, p(2:r+1) are trace of A_r to trace of A_1
%
l = F(end);
p = zeros(l,1);
for i=1:r
    p(i+1) = trace(A(:,:,r-i+1));
end
lx0 = max(diff(F(:,r)));
x = zeros(n,lx0);
for i=1:n         % trace of a matrix is equal to the sum of the diagonal elements
    x0 = zeros(n,lx0);
    x0(:,1:r) = A(:,i,r:-1:1);
    lk0 = F(2,r)-F(1,r);
    for k=2:M-1          % |nu|=k
        x(:,1:lk0) = x0(:,1:lk0);           % copy the old x0 to x
        x0(:) = 0;
        for j=1:r
            h = index(F(k-1,r)+1:F(k-1,r)+lk0,j);
            lh = find(h>0);
            lh0 = h(lh);
            x0(:,lh0) = x0(:,lh0)+A(:,:,j)*x(:,lh);
        end
        sp = F(k,r);
        lk0 = F(k+1,r)-F(k,r);
        p(sp+1:sp+lk0) = p(sp+1:sp+lk0)+x0(i,1:lk0)';
    end
    %
    % Separately for k=M as there is no need to update x0 anymore
    %
    sp = F(M,r);
    for j=1:r
        h = index(F(M-1,r)+1:F(M-1,r)+lk0,j);
        lh = find(h>0);
        lh0 = h(lh);
        p(sp+lh0) = p(sp+lh0)+x0(:,lh)'*A(i,:,j)';
    end
end
%
%   Use multivariate Newton-Girard formula to obtain the
%   e coefficients.
%
e = zeros(l,1);
e(1) = 1;
e(2:r+1) = -p(2:r+1);   % for k=1
S = ones(1,r);
for i=r+2:l
    j = 1;
    while j<r&&(S(j)==S(j+1)||S(j)==sk(j))
       j = j+1;
    end  
    S(j) = S(j)+1;
    for ss=j:-1:2
        S(ss-1) = max(0,S(ss)-kappa(ss));
    end
    ka = [S(1) diff(S)];
    e(i) = -p(i);
    x = zeros(1,r);
    hh = find(ka>0);
    for ii=1:prod(ka+1)-2
        for jj=hh
            if x(jj)<ka(jj)
               x(jj) = x(jj)+1;
               break
            else
               x(jj) = 0;
            end
        end
        S1 = cumsum(x);
        ind1 = F(S1(r),r)+1;
        for jj=r-1:-1:1
            if S1(jj)==0
               break
            end
            ind1 = ind1+F(S1(jj),jj);
            b = S1(jj+1)-kappa(jj+1);
            if b>0
               ind1 = ind1-F(b,jj);
            end
        end
        S1 = S-S1;
        ind2 = F(S1(r),r)+1;
        for jj=r-1:-1:1
            if S1(jj)==0
               break
            end
            ind2 = ind2+F(S1(jj),jj);
            b = S1(jj+1)-kappa(jj+1);
            if b>0
               ind2 = ind2-F(b,jj);
            end
        end
        e(i) = e(i)-p(ind1)*e(ind2);
    end
    e(i) = e(i)/S(r);
end 
