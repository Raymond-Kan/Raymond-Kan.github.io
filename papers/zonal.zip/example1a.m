n = 20;
p = 10;
q = 10;
A = zeros(n);
for i=1:n
    for j=1:n
        A(i,j) = (-1+abs(i-j))/n^2;
    end
end
B = diag([1:n]./n^2);
t = cputime;
m = zeros(p+1,q+1);
err = zeros(p+1,q+1);
M0 = zeros(p+1,q+1);
for p1=0:p
    for q1=0:q
        [m1,err1,M1] = qmoms(A,B,p1,q1,1e-5);
        m(p1+1,q1+1) = m1;
        err(p1+1,q1+1) = err1;
        M0(p1+1,q1+1) = M1;
    end
end
t = cputime-t;
delete example1a.out
diary example1a.out
fprintf('\n\nShort Recursions:\n')
fprintf('Quadruple Precision\n')
fprintf('CPU Time = %10.3fs\n',t)
fprintf('Moments:\n')
for i=0:p
    for j=0:q
        fprintf('%17.5f',m(i+1,j+1))
    end
    fprintf('\n')
end
fprintf('\nError Bounds:\n')
for i=0:p
    for j=0:q
        fprintf('%17.6e',err(i+1,j+1))
    end
    fprintf('\n')
end
fprintf('\nNumber of Terms:\n')
for i=0:p
    for j=0:q
        fprintf('%6.0f',M0(i+1,j+1))
    end
    fprintf('\n')
end
%
%   Long recursion
%
t = cputime;
m = zeros(p+1,q+1);
err = zeros(p+1,q+1);
M0 = zeros(p+1,q+1);
for p1=0:p
    for q1=0:q
        [m1,err1,M1] = qmoml(A,B,p1,q1,1e-5);
        m(p1+1,q1+1) = m1;
        err(p1+1,q1+1) = err1;
        M0(p1+1,q1+1) = M1;
    end
end
t = cputime-t;
fprintf('\n\nLong Recursions:\n')
fprintf('Quadruple Precision\n')
fprintf('CPU Time = %10.3fs\n',t)
fprintf('Moments:\n')
for i=0:p
    for j=0:q
        fprintf('%17.5f',m(i+1,j+1))
    end
    fprintf('\n')
end
fprintf('\nError Bounds:\n')
for i=0:p
    for j=0:q
        fprintf('%17.6e',err(i+1,j+1))
    end
    fprintf('\n')
end
fprintf('\nNumber of Terms:\n')
for i=0:p
    for j=0:q
        fprintf('%6.0f',M0(i+1,j+1))
    end
    fprintf('\n')
end
diary off
