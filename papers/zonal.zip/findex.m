function [F,index]=findex(kappa,n)
%
% This function constructs the F matrix F(i,j) 
% for i=0,...,n and j=1,...,r, where F(i,j)
% stands for the number of elements of nu such 
% that 0<=|nu|<=i and nu<=kappa(1:j).  In 
% addition, it also constructs an index matrix 
% index(i,j) for i=1,...,F(n,r) and j=1,...,r. 
% index(i,j) tells us the corresponding index when we update 
% \nu_j to \nu_j+1. When we cannot perform the update, we
% set index(i,j) equal to 0.
% Note: Zero elements of kappa are first taken away
%
kappa = kappa(find(kappa>0));
kappa = min(kappa,n);
sk = cumsum(kappa);
r = length(kappa);   % Number of nonzero elements of kappa.
n = min(n,sk(r));
if n==0
   index = [];
   F = onses(1,r);
   return
end
if r==1
   index = ones(n,1);
   F = ones(n+1,1);
   return
end
%
%   Compute the matrix of F(i,j) for i=0,...,n
%   and j=1,...,r.
%
F = zeros(n+1,r);
F(1,:) = 1;
F(2:kappa(1),1) = 2:kappa(1);
F(kappa(1)+1:n+1,1) = kappa(1)+1;
for j=2:r
    for i=1:kappa(j)
        F(i+1,j) = F(i+1,j-1)+F(i,j);
    end
    for i=kappa(j)+1:n
        F(i+1,j) = F(i+1,j-1)+F(i,j)-F(i-kappa(j),j-1);
    end
end
%
%   Compute the index for the updating from one block to the
%   next block. 
%
index = zeros(F(n,r),r);
index(1,:) = r:-1:1;
S = [zeros(1,r-1) 1];  % Can set first S to this because kappa_r>0
% Loop through all possible nu's with |nu|<=n and nu<=kappa
for i=2:F(n,r)         
    df = i-F(S(r),r);  % Position of S in its own block
    for ss=r-1:-1:1    % Going backward by setting index(i,r) first
        b = S(ss+1)-kappa(ss+1);
        if b>0
           df = df+F(b,ss)-F(b+1,ss);
        elseif b==0
           df = df-1;
        end
        if b<S(ss)   % Check constraint for the 2nd to last element
           index(i,ss+1) = df;
        end
        df = df+F(S(ss)+1,ss);
        if S(ss)>0
           df = df-F(S(ss),ss);
        end
    end               
    if S(1)<kappa(1)  % Check constraint for the first element
       index(i,1) = df;
    end
% Create next S
    j = 1;
    while j<r&&(S(j)==S(j+1)||S(j)==sk(j))
       j = j+1;
    end  
    S(j) = S(j)+1;
    for ss=j:-1:2
        S(ss-1) = max(0,S(ss)-kappa(ss));
    end
end
