%
% invpoly_new.m     Date: 2006/12/29
% This function computes the top order invariant polynomials up to order k
% using the new identity
% A: list of matrices input 
% k: order of each matrix
%
function d = invpoly_new(A,si)
s = sum(si);
if s==0
   d = 1;
   return
end
ind = find(si==0);
if ind
   A(:,:,ind) = [];
   si(ind) = [];
end
nd = prod(si+1);
d = zeros(nd,1);
d(1) = 1;
p = 2*ones(nd,1);
ls = length(si);
s0 = [1; cumprod(si(1:ls-1)+1)'];
n = size(A,1);
%
% Obtain E[(z'Bz)^i]/i! for i=0,...,s, and update relavant d's
%
count = 0;
for i=ls:-1:1     
    si1 = [si(1:i-1)*2 si(i)-1];    % track the updates of B
    si2 = [si(1:i) zeros(1,ls-i)];  % B = si2/2*A; the first B given i
    B = zeros(n);
    for j=1:i
        B = B+0.5*si2(j)*A(:,:,j);
    end
    trb = dkr(s,eig(B));
    id = 1+si2*s0;
    p(id) = p(id)/prod(gamma(si2+1));    % d = E[\mu_{k_1,...,k_r}]/(k_1!...k_r!)
    d(id) = d(id)+p(id)*trb(sum(si2)+1); % first term for d(id)
    ss = si2;
    nd = prod(fix(si(i+1:end)./2)+1)-1;  % number of d's to be updated    
    % 
    % The update is only for d's with k_{i+1}, k_{end} all even; \nu_{in} =
    % k_{in}/2, when k_{in} is the first non-zero k's after k_i.
    %
    for k=1:nd
        for j=i+1:ls
            if ss(j)+2<=si(j)
               ss(j) = ss(j)+2;
               id = 1+ss*s0;
               in = find(ss(i+1:end)>0); 
               in = i+in(1);
               p(id) = p(id)*(-1)^(sum(ss(1:in-1))+1)*(ss(in)+2)/ss(in);     
               d(id) = d(id)+p(id)*trb(sum(ss)+1);
               break
            else
               ss(j) = si2(j);
            end
        end
    end    
    ss = si2;
    nt = prod(si1+1);   % number of different B will be dealt given i
    ssi1 = si1;
    for j=1:nt-1
        for jj=1:i
            if ssi1(jj)>0
               ssi1(jj) = ssi1(jj)-1;
               ss(jj) = ss(jj)-1;
               B = B-0.5*A(:,:,jj);
               trb = dkr(s,eig(B));   % E[B^i]/i! for i = 0,...,s
               abss = abs(ss); % d>=abss need updated
               %
               % first deal with d = abss
               %
               if all(ss>=0)   % The first term of a new d
                  id = 1+ss*s0;
                  p(id) = p(id)/prod(gamma(ss+1));
                  d(id) = d(id)+p(id)*trb(sum(ss)+1);
               else            % \nu_{in} updates to k_{in}
                  id = 1+abss*s0;
                  in = find(ss<abss);
                  in = in(1);
                  ch = (-1)^(sum(abss(1:in-1))+1);
                  p(id) = p(id)*ch/abss(in);                     
                  d(id) = d(id)+p(id)*trb(sum(abss)+1);
               end
               nd = prod(fix((si-abss)./2)+1)-1;  % number of d's to be updated given B, d>abss
               bbss = abss;
               for k=1:nd
                   for kk=1:ls
                       if bbss(kk)+2<=si(kk)
                          bbss(kk) = bbss(kk)+2;
                          id = 1+bbss*s0;
                          if all(bbss(1:i)==ss(1:i))  % update d's with k_{i+1:end} all even
                             in = find(bbss(i+1:end)>0);
                             in = i+in(1);
                             p(id) = p(id)*(-1)^(sum(ss(1:in-1))+1)*...
                                     (bbss(in)+2)/bbss(in);
                          else
                             in = find(ss<bbss);      
                             in = in(1);              % place for update
                             if all(bbss(1:in-1)==0)
                                x = 0.5*(bbss(in)-ss(in));
                                p(id) = -p(id)*(bbss(in)-x+1)/x;
                             else
                                ch = (-1)^(sum(bbss(1:in-1))+1);
                                x = (bbss(in)-ss(in))/2;
                                p(id) = p(id)*ch*(bbss(in)-x+1)/x;
                             end
                          end              
                          d(id) = d(id)+p(id)*trb(sum(bbss)+1);
                          break
                       else
                          bbss(kk) = abss(kk);
                       end
                   end
               end
               break
            else
               B = B+0.5*si1(jj)*A(:,:,jj);
               ssi1(jj) = si1(jj);
               ss(jj) = si2(jj);
            end
        end
    end
end

