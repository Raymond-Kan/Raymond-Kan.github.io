%
% invpq.m		Date: 7/1/2007
% This Matlab program computes the top order invariant polynomial
% d_\kappa(A_1,...,A_r).  It calls an external Fortran
% program which makes use of quadruple precision for intermediate
% computations.
% Usage: invpq(A,s)
%
function y = invpq(A,si);
if nargin==1
   p = size(A,3);
   si = ones(1,p);
end
% Sorting of si is to reduce the number of updates,
% it is not really necessary to do it.
[si inu] = sort(si,2,'descend');  
A = A(:,:,inu);
y = invpqf(A,si);
