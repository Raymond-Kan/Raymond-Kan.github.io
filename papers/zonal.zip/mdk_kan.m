%
% mdk_kan.m		Date: 1/11/2004
% This Matlab program computes 
% \tilde{d}_{k1,k2,...,kr}(A_1,A_2,...,A_r) using the Kan (2008) algorithm.
% Usage: mdk_kan(A,k)
%
function y = mdk_kan(A,si);
p = size(A,3);
if nargin==1
   si = ones(1,p);
end
s = sum(si);
if s==0
   y = 1;
   return
end
n = size(A,2);
if p==1
   if s==1
      y = 0.5*trace(A);
   else
      y = trs(A);
   end
   return
end
%
%   Convert moment of product to moments of sum
%
% Sorting of si is to reduce the number of updates,
% it is really not necessary.
%
[si inu] = sort(si,2,'descend');  
ls = length(si);
x = zeros(1,ls);
B = 0.5*si(1)*A(:,:,inu(1));
for i=2:ls
    B = B+0.5*si(i)*A(:,:,inu(i));
end
p = 2/prod(gamma(si+1));
y = 0;
for i=1:fix(prod(si+1)/2)
    y = y+p*trs(B);
    for j=1:ls
        if x(j)<si(j)
           x(j) = x(j)+1;
           p = -p*(si(j)+1-x(j))/x(j);
           B = B-A(:,:,inu(j));
           break
        end    
        x(j) = 0;
        if rem(si(j),2)==1
           p = -p;
        end
        B = B+si(j)*A(:,:,inu(j));
    end
end
%
%   This function computes E[(z'Bz)^s]/(2^s*s!), where B=x_1*A_1+...x_p*A_p
%   where z ~ N(0_n,I_n).  
%
function h = trs(B)
   y1 = ones(1,s+1);
   d = eig(B);
   a = zeros(1,s);
   d1 = ones(n,1);
   for i=1:s
       d1 = d1.*d;
       a(i) = sum(d1);
       y1(i+1) = sum(a(i:-1:1).*y1(1:i))/(2*i);
   end
   h = y1(end);
end

end
