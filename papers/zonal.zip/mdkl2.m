%
% This program computes d_{i,j}(A,B) for 0<=i<=k1 and
% 0<=j<=k2 using the long recursive algorithm.
%
function d = mdkl2(A,B,k1,k2)
n = size(A,1);
%
%   Quick return for n=1, k1=0 or k2=0
%   For n=1, d_{i,j}=(1/2)_{i+j}(a^i/i!)(b^j/j!).
%
if n==1
   d = zeros(k1+1,k2+1);
   d(1,1) = 1;
   for i=1:k2
       d(1,i+1) = B*d(1,i)*(i-0.5)/i;
   end
   for i=2:k1+1
       d(i,:) = (A/(i-1))*(d(i-1,:).*(i+[0:k2]-1.5));
   end
   return
end
if k2==0
   d = dkr(k1,eig(0.5*(A+A')));
   return
end
if k1==0
   d = dkr(k2,eig(0.5*(B+B')))';
   return
end
%
%   Cases when n>1, k1>0, and k2>0
%
[P,D] = eig(0.5*(B+B'));
b = diag(D);
p = zeros(k1+1,k2+1);
p(2,1) = trace(A);
p(1,2) = sum(b);
A = P'*A*P;
%
%   Compute p_{ij}
%
x = zeros(n,k2+1);
for i=1:n
    x(:,1:2) = [A(:,i) zeros(n,1)];
    x(i,2) = b(i);
    for j=2:k1+k2-1
        if j<=k2
           x(:,j+1) = b.*x(:,j);
        end
        for k=min(j,k2+1):-1:max(2,j-k1+1)
            x(:,k) = A*x(:,k)+b.*x(:,k-1);
        end
        if j<=k1
           x(:,1) = A*x(:,1);
        end
        for k=max(0,j-k1):min(j,k2)
            p(j-k+1,k+1) = p(j-k+1,k+1)+x(i,k+1);
        end 
    end
%
%   Treat the last one differently as there is no need to carry
%   the matrix x any further.
%
    p(k1+1,k2+1) = p(k1+1,k2+1)+A(i,:)*x(:,k2+1)+b(i)*x(i,k2);
end
%
%   Start the recursion of d's
%
d = zeros(k1+1,k2+1);
d(1,1) = 1;
for i=1:k1+1
    for j=1+(i==1):k2+1;
        d(i,j) = sum(sum(d(1:i,1:j).*p(i:-1:1,j:-1:1)))/(2*(i+j-2));
    end    
end
