%
% This program computes d_{k} using the long recursive algorithm
% by calling an external Fortran program to perform the
% intermediate operations in quadruple precision.
%
function d = mdklq(A,k)
index = find(k>0);
A = A(:,:,index);
k = k(index);
r = length(k);
if r==0
   d = 1;
   return
end
if r==1
   d = dkr(k,eig(A));
   return
end
d = mdklquad(A,k);
