%
% This program computes d_{i,j}(A,B) for 0<=i<=k1 and
% 0<=j<=k2 using the short recursive algorithm.
%
function d = mdks2(A,B,k1,k2)
n = size(A,1);
%
%  When n is larger than k1+k2, it is faster to use
%  the long recursion.
%
%if n>=k1+k2
%   d = mdkl2(A,B,k1,k2);
%   return
%end
%
%   Quick return for n=1, k1=0 or k2=0
%   For n=1, d_{i,j}=(1/2)_{i+j}(a^i/i!)(b^j/j!).
%
if n==1
   d = zeros(k1+1,k2+1);
   d(1,1) = 1;
   for i=1:k2
       d(1,i+1) = B*d(1,i)*(i-0.5)/i;
   end
   for i=2:k1+1
       d(i,:) = (A/(i-1))*(d(i-1,:).*(i+[0:k2]-1.5));
   end
   return
end
if k2==0
   d = dkr(k1,eig(0.5*(A+A')));
   return
end
if k1==0
   d = dkr(k2,eig(0.5*(B+B')))';
   return
end
%
%   Cases when n>1, k1>0, and k2>0
%
[P,D] = eig(0.5*(B+B'));
b = diag(D);
i1 = min(n,k1)+1;
j1 = min(n,k2)+1;
k3 = min(n,k1+k2);
k4 = min(n,k2+1);
p = zeros(i1,j1);
p(2,1) = trace(A);
p(1,2) = sum(b);
A = P'*A*P;
%
%   Compute p_{ij}
%
x = zeros(n,k4);
for i=1:n
    x(:,1:2) = [A(:,i) zeros(n,1)];
    x(i,2) = b(i);
    for j=2:k3-1
        if j<=k2
           x(:,j+1) = b.*x(:,j);
        end
        for k=min(j,k4):-1:max(2,j-i1+2)
            x(:,k) = A*x(:,k)+b.*x(:,k-1);
        end
        if j<i1
           x(:,1) = A*x(:,1);
        end
        for k=max(0,j+1-i1):min(j,k2)
            p(j-k+1,k+1) = p(j-k+1,k+1)+x(i,k+1);
        end 
    end
%
%   Treat the last one differently as there is no need to carry
%   the matrix x any further.
%
    if k1>=n
       p(n+1,1) = p(n+1,1)+A(i,:)*x(:,1);
    end
    if k2>=n 
       p(1,n+1) = p(1,n+1)+b(i)*x(i,n);
    end
    for j=max(1,k3-k1):k4-1
        p(k3-j+1,j+1) = p(k3-j+1,j+1)+A(i,:)*x(:,j+1)+b(i)*x(i,j);
    end
end
%
%     Use multivariate Newton-Girard formula to
%     compute e_{i,j} from p_{i,j} 
%
e = zeros(i1,j1);
e(1,1) = 1;
for i=1:i1
    for j=1+(i==1):min(j1,n+2-i)
        e(i,j) = -sum(sum(e(1:i,1:j).*p(i:-1:1,j:-1:1)))/(i+j-2);
    end
end
%
%   Start the recursion of d's
%
d = zeros(k1+1,k2+1);
d(1,1) = 1;
for i=1:k1+1
    i1 = min(i,n+1);
    for j=1+(i==1):k2+1
        sij = 1/(2*(i+j-2));
        j1 = min(j,n+1);
        for i2=1:i1
            for j2=1:min(j1,n+2-i2)
                d(i,j) = d(i,j)+(sij*(i2+j2-2)-1)*e(i2,j2) ...
                         *d(i-i2+1,j-j2+1);
            end
        end
    end    
end
