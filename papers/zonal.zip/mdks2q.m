%
% This program computes d_{k_1,k_2}(A,B) using the short 
% recursive algorithm.  The output d_{i,j} is stored in a
% (k_1+1)x(k_2+1) array.  It calls an external mdks2quad.f
% Fortran program to do most of the work in quadruple
% precision.
%
function d = mdks2q(A,B,k1,k2)
n = size(A,1);
%
%   Quick return for n=1, k1=0 or k2=0
%   For n=1, d_{i,j}=(1/2)_{i+j}(a^i/i!)(b^j/j!).
%
if n==1
   d = zeros(k1+1,k2+1);
   d(1,1) = 1;
   for i=1:k2
       d(1,i+1) = B*d(1,i)*(i-0.5)/i;
   end
   for i=2:k1+1
       d(i,:) = (A/(i-1))*(d(i-1,:).*(i+[0:k2]-1.5));
   end
   return
end
if k2==0
   d = dkr(k1,eig(0.5*(A+A')));
   return
end
if k1==0
   d = dkr(k2,eig(0.5*(B+B')))';
   return
end
%
%  For k1>0, k2>0 and n>1, call an external
%  Fortran program to do the computation in
%  quadruple precision.
%
[P,D] = eig(0.5*(B+B'));
d = mdks2quad(P'*A*P,diag(D),k1,k2);
