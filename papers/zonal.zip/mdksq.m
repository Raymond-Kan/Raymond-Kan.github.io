%
% This program computes d_{k} using the short recursive algorithm
% by calling an external Fortran program to perform the
% intermediate operations in quadruple precision.
%
function d = mdksq(A,k)
index = find(k>0);
A = A(:,:,index);
k = k(index);
r = length(k);
if r==0
   d = 1;
   return
end
if r==1
   d = dkr(A,k);
   return
end
d = mdksquad(A,k);
