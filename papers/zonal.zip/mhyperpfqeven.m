%
%    This Matlab function computes {}_pF_q(1/2,alpha;beta;A),
%    where the eigenvalues of A have even multiplicites.
%
function y = mhyperpfqeven(alpha,beta,a,n)
s = length(a);
if nargin==3
   m = ones(size(a));
else
   m = n./2;
end
if s==1
   y = hypergeom([m alpha],beta,a);
   return
end
y = 0;
for i=1:length(a)
    a1 = a;
    a1(i) = [];
    m1 = m;
    m1(i) = [];
    b0 = dkr(m(i)-1,a1./(a1-a(i)),2*m1)./prod((1-a1./a(i)).^m1);
    for j=1:m(i)
        y = y+b0(m(i)+1-j)*hypergeom([j alpha],beta,a(i));
    end
end

