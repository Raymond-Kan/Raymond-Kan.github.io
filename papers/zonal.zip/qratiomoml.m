%
% qratiomoml.m   Date: 2007/01/15
% This program computes E[(z'A'z)^p/(z'Bz)^q] when z ~ N(0,I), following
% Smith (1993)'s identity.
% B is assumed to be positive definite.
% This program uses the long recursive algorithm and generates the entire
% table.
% Input: 
% A, B: matrix of the quadratic forms in the numerator and the denominator
% p, q: power of the quadratic forms in the numerator and the denominator
% E: precision, default is 1e-10
% M: maximum number of terms, default is 1000
% Output:
% m: E[(z'Az)^i/(z'Bz)^j] for i=0,...,p and j=0,...,q
% err: upper bound of the approximation errors in m
% M0: number of terms to reach the desired level of precision
%
function [m,err,M0] = qratiomoml(A,B,p,q,E,M)
pend = p+1;
M0 = zeros(pend,q+1);
err = M0;
if q==0
   m = cumprod([1 2:2:2*p]').*dkr(p,eig(A));
   return
end
n = size(A,1);
m = NaN(pend,q+1); 
m(1,1) = 1;
%
%   Normalization of A and B such that
%   their largest eigenvalue is 1.
%
[P,B] = eig(B);
b = diag(B);
if any(b<=0)
   fprintf('B matrix must be positive definite!\n')
   return
end
A = P'*A*P;
ea = eig(A);
maxea = max(abs(ea));
A = A./maxea;
ch = 1;
if all(ea<=0)    % when A is negative semi-definite
   ch = 2;
   A = -A;
elseif max(ea)*min(ea)<0&&p>0
   ch = 3;
   pt = pend-rem(pend,2);
end
maxeb = max(b);
b = b./maxeb;
eb = 1-b;   % nonzero eigenvalues of I_n-B
%
% Set max times of iteration and tolerance level
%
if nargin<5
   E = 1e-10;
end
if nargin<6
   M = 1000;
end
%
% generate p_{i,j} for recursive algorithm
%
n2 = n/2;
e = ones(pend,1);
pcoeff = zeros(pend,pend+M);
x = zeros(n,n,pend);
x(:,:,1) = eye(n);
if pend>0
   x(:,:,2) = eye(n);
end
if ch==3
   x1 = x(:,:,1:pt);
end
D = eb*ones(1,n);
for j=1:pend-1
    x(:,:,j+1) = D.*x(:,:,j);
    for k=j:-1:2
        x(:,:,k) = A*x(:,:,k)+D.*x(:,:,k-1);
    end
    x(:,:,1) = A*x(:,:,1);
    for k=1:j+1
        pcoeff(j+2-k,k) = trace(x(:,:,k));
    end
end
pbeg = 1;
if ch==3
   [P,D1] = eig(A);
   At = P*abs(D1)*P';
   pcoeff1 = zeros(pt,pt+M);
   for j=1:pt-1
       x1(:,:,j+1) = D.*x1(:,:,j);
       for k=j:-1:2
           x1(:,:,k) = At*x1(:,:,k)+D.*x1(:,:,k-1);
       end
       x1(:,:,1) = At*x1(:,:,1);
       for k=1:j+1
           pcoeff1(j+2-k,k) = trace(x1(:,:,k));
       end
   end
   pbeg1 = 1;
   pend1 = pt-1;
end
%
% generate d_p(tilde{A}*B) for error bound 
%
c = eig(A./sqrt(b*b'));
tc = zeros(p,1);
nc = ones(n,1);
for i=1:p
    nc = nc.*c;
    tc(i) = sum(nc);
    e(i+1) = tc(i:-1:1)'*e(1:i)/(2*i);
end
if ch==3
   c = eig(At./sqrt(b*b'));
   e2 = ones(pt,1);
   nc = ones(n,1);
   for i=1:pt-1
       nc = nc.*c;
       tc(i) = sum(nc);
       e2(i+1) = tc(i:-1:1)'*e2(1:i)/(2*i);
       if rem(i,2)==1;
          e(i+1) = e2(i+1);   % when p odd, the bound is different
       end
   end
end
e = e./sqrt(prod(b));
%
% generate d's and m's
%
d = zeros(pend,M+1);
d(1,1) = 1;
if ch==3
   d1 = zeros(pt,M+1);
   d1(1,1) = 1;
end
%
% when k==0
%
const = ones(pend,q);
xx = 1;
e(1) = e(1)-1;
for i=1:min(q,fix(n2-1/2))     % for p=0
    xx = xx/((n-2*i)*maxeb);
    const(1,i) = xx*i/n2;
    err(1,i+1) = e(1)*const(1,i);
    m(1,i+1) = xx;
end
x0 = 1;
for i=1:p             % for p>0
    d(i+1,1) = (d(1:i+1,1)'*pcoeff(i+1:-1:1,1))/(2*i);
    if ch==3&&i<pt
       d1(i+1,1) = (d1(1:i+1,1)'*pcoeff1(i+1:-1:1,1))/(2*i);
    end
    x0 = 2*maxea*x0*i;
    xx = x0;
    m(i+1,1) = xx*d(i+1,1);
    if ch==3&&rem(i,2)==1
       e(i+1) = e(i+1)-d1(i+1,1);
    else
       e(i+1) = e(i+1)-d(i+1,1);
    end     
    for j=1:min(q,fix(n2+i-1/2))
        xx = xx/((n+2*(i-j))*maxeb);
        const(i+1,j) = xx*j/(n2+i);
        m(i+1,j+1) = xx*d(i+1,1);
        err(i+1,j+1) = e(i+1)*const(i+1,j);
    end
end
k1 = 2;
while any(any(err>E))&&k1<=M+1
   for k=pbeg:p
       x(:,:,k) = A*x(:,:,k+1)+D.*x(:,:,k);
       pcoeff(p+2-k,k1+k-1) = trace(x(:,:,k));
   end
   x(:,:,end) = D.*x(:,:,end);
   pcoeff(1,k1+p) = trace(x(:,:,end));
   if ch==3
      for k=pbeg1:pend1
          x1(:,:,k) = At*x1(:,:,k+1)+D.*x1(:,:,k);
          pcoeff1(pend1+2-k,k1+k-1) = trace(x1(:,:,k));
      end
      x1(:,:,end) = D.*x1(:,:,end);
      pcoeff1(1,pend1+k1) = trace(x1(:,:,end));
   end
   for p1=1:pend
       sx = 2*(p1+k1-2);
       d(p1,k1) = sum(sum(d(1:p1,1:k1).*pcoeff(p1:-1:1,k1:-1:1)))/sx;
       if ch==3&&p1<=pt
          d1(p1,k1) = sum(sum(d1(1:p1,1:k1).*pcoeff1(p1:-1:1,k1:-1:1)))/sx;
       end
       if ch==3&&rem(p1,2)==0
          e(p1) = e(p1)-d1(p1,k1);
       else
          e(p1) = e(p1)-d(p1,k1);
       end
       for q1=2:min(q+1,fix(n2+p1-1/2))
           if err(p1,q1)>E
              m(p1,q1) = m(p1,q1)+const(p1,q1-1)*d(p1,k1);
              const(p1,q1-1) = const(p1,q1-1)*(q1+k1-2)/(n2+p1+k1-2);
              M0(p1,q1) = M0(p1,q1)+1;
              err(p1,q1) = e(p1)*const(p1,q1-1);
           end
       end
   end
   if all(err(pend,:)<E)
      if ch==3&&pend==pt
         pbeg1 = pbeg1+2;
         pt = pt-2;
      end
      pbeg = pbeg+1;
      pend = pend-1;
   end   
   k1 = k1+1;
end
if ch==2
   m(2:2:end,:) = -m(2:2:end,:); 
end
