%
% qratiomoms.m   Date: 2007/01/15
% This program computes E[(z'A'z)^p/(z'Bz)^q] when z ~ N(0,I), following
% Smith (1993)'s identity.
% B is assumed to be positive definite.
% This program uses the short recursive algorithm and generates the entire
% table.
% Input: 
% A, B: matrix of the quadratic forms in the numerator and the denominator
% p, q: power of the quadratic forms in the numerator and the denominator
% E: precision, default is 1e-10
% M: maximum number of terms, default is 1000
% Output:
% m: E[(z'Az)^i/(z'Bz)^j] for i=0,...,p and j=0,...,q
% err: upper bound of the approximation errors in m
% M0: number of terms to reach the desired level of precision
%
function [m,err,M0] = qratiomoms(A,B,p,q,E,M)
pend = p+1;
M0 = zeros(pend,q+1);
err = M0;
if q==0
   m = cumprod([1 2:2:2*p]').*dkr(p,eig(A));
   return
end
n = size(A,1);
m = NaN(pend,q+1); 
m(1,1) = 1;
%
%   Normalization of A and B such that
%   their largest eigenvalue is 1.
%
[P,B] = eig(B);
b = diag(B);
if any(b<=0)
   fprintf('B matrix must be positive definite!\n')
   return
end
A = P'*A*P;
ea = eig(A);
maxea = max(abs(ea));
A = A./maxea;
ch = 1;
if all(ea<=0)    % when A is negative semi-definite
   ch = 2;
   A = -A;
elseif max(ea)*min(ea)<0
   ch = 3;
   pt = pend-rem(pend,2);  % if p is even pt=p
end
maxeb = max(b);
b = b./maxeb;
%
%   Generate p's for computing the d's
%   With our normalization of B, the last column of 
%   pp is zero as one of the eigenvalues of I_n-B is zero.
%
pp = ecoeff2cq(A,1-b,p);
if ch==3&&p>0
   [P,D] = eig(A);
   At = P*abs(D)*P';
   pp1 = ecoeff2cq(At,1-b,pt-1);
end
%
% Set maximum times of iteration and tolerance level
%
if nargin<5
   E = 1e-10; 
end
if nargin<6
   M = 1000;
end
%
% generate the bound for different p
%
e = ones(pend,1);
c = eig(A./sqrt(b*b'));
tc = zeros(p,1);
nc = ones(n,1);
n2 = n/2;
for i=1:p
    nc = nc.*c;
    tc(i) = sum(nc);
    e(i+1) = tc(i:-1:1)'*e(1:i)/(2*i);
end
if ch==3&&p>0
   e2 = ones(pend,1);
   c = eig(At./sqrt(b*b'));
   nc = ones(n,1);
   for i=1:p-(rem(p,2)==0)
       nc = nc.*c;
       tc(i) = sum(nc);
       e2(i+1) = tc(i:-1:1)'*e2(1:i)/(2*i);
       if rem(i,2)==1;
          e(i+1) = e2(i+1);   % when p odd, the bound is different
       end
   end
end
e = e./sqrt(prod(b));
%
% generate d's and m's
%
d = zeros(pend,n+1);
d(1,1) = 1;
if ch==3
   d1 = zeros(pt,n+1);
   d1(1,1) = 1;
end
%
% when k==0
%
const = ones(pend,q);
x = 1;
e(1) = e(1)-1;
for i=1:min(fix(n2-1/2),q)     % for p=0
    x = x/((n-2*i)*maxeb);
    const(1,i) = x*i/n2;
    err(1,i+1) = e(1)*const(1,i);
    m(1,i+1) = x;
end
x0 = 1;
for i=1:p             % for p>0
    index = [1:min(n,i)]';
    d(i+1,1) = sum((index-2*i).*pp(index+1,1).*d(i+1-index,1))/(2*i);
    if ch==3&&i<pt
       d1(i+1,1) = sum((index-2*i).*pp1(index+1,1).*d1(i+1-index,1))/(2*i);
    end
    x0 = 2*maxea*x0*i;
    x = x0;
    m(i+1,1) = x*d(i+1,1);
    if ch==3&&rem(i,2)==1
       e(i+1) = e(i+1)-d1(i+1,1);
    else
       e(i+1) = e(i+1)-d(i+1,1);
    end     
    for j=1:min(q,fix(n2+i-1/2))
        x = x/((n+2*(i-j))*maxeb);
        const(i+1,j) = x*j/(n2+i);
        m(i+1,j+1) = x*d(i+1,1);
        err(i+1,j+1) = e(i+1)*const(i+1,j);
    end
end
k = 1;
while any(any(err>E))&&k<=M
   if k>n
      k1 = n+1;
      d = [d(:,2:end) zeros(pend,1)];
      if ch==3
         d1 = [d1(:,2:end) zeros(pt,1)];
      end
   else
      k1 = k+1;
   end 
   for p1=1:pend
       sx = 2*(p1+k-1);
       for v2=0:min(n-1,k)   % Normally, it should be min(n,k) but pp has zero elements in its last column
           for v1=1-sign(v2):min(p1-1,n-v2)
               d(p1,k1) = d(p1,k1)+((v1+v2)/sx-1)*pp(v1+1,v2+1)*d(p1-v1,k1-v2);
           end
       end
       if ch==3&&p1<=pt
          for v2=0:min(n-1,k)   % Normally, it should be min(n,k) but pp1 has zero elements in its last column
              for v1=1-sign(v2):min(p1-1,n-v2)
                  d1(p1,k1) = d1(p1,k1)+((v1+v2)/sx-1)*pp1(v1+1,v2+1)*d1(p1-v1,k1-v2);
              end
          end
       end
       if ch==3&&rem(p1,2)==0
          e(p1) = e(p1)-d1(p1,k1);
       else
          e(p1) = e(p1)-d(p1,k1);
       end
       for q1=2:min(q+1,fix(n2+p1-1/2))
           if err(p1,q1)>E
              m(p1,q1) = m(p1,q1)+const(p1,q1-1)*d(p1,k1);
              const(p1,q1-1) = const(p1,q1-1)*(q1+k-1)/(n2+p1+k-1);
              M0(p1,q1) = M0(p1,q1)+1;
              err(p1,q1) = e(p1)*const(p1,q1-1);
           end
       end
   end
   if all(err(pend,:)<E)
      if ch==3&&pend==pt
         pt = pt-2;
         d1(pt+1:pt+2,:) = [];
      end
      pend = pend-1;
      d(end,:) = [];
   end   
   k = k+1;
end
if ch==2
   m(2:2:end,:) = -m(2:2:end,:); 
end
