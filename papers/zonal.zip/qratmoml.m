%
% qratmoml.m   Date: 2007/01/15
% This program computes E[(z'A'z)^p/(z'Bz)^q] when z ~ N(0,I), following
% Smith (1993)'s identity.
% B is assumed to be positive definite.
% This program uses the long recursive algorithm.
% Input: 
% A, B: matrix of the quadratic forms in the numerator and the denominator
% p, q: power of the quadratic forms in the numerator and the denominator
% E: precision, default is 1e-10
% M: maximum number of terms, default is 1000
% Output:
% m: E[(z'Az)^p/(z'Bz)^q] 
% err: upper bound of the approximation errors in m
% M0: number of terms to reach the desired level of precision
%
function [m,err,M0] = qratmoml(A,B,p,q,E,M)
pend = p+1;
n = size(A,1);
M0 = 0;
err = 0;
n2p = n/2+p;
if n2p<=q
   m = NaN;
   return
end
if q==0
   d = dkr(p,eig(A));
   m = prod([2:2:2*p])*d(end);
   return
end
%
%   Normalization of A and B such that
%   their largest eigenvalue is 1.
%
[P,B] = eig(B);
b = diag(B);
if any(b<=0)
   m = NaN;
   fprintf('B matrix must be positive definite!\n')
   return
end
A = P'*A*P;
ea = eig(A);
maxea = max(abs(ea));
A = A./maxea;
ch = 1;
if all(ea<=0)    % when A is negative semi-definite
   ch = 2;
   A = -A;
elseif rem(p,2)==1&&max(ea)*min(ea)<0
   ch = 3;
end
maxeb = max(b);
b = b./maxeb;
eb = 1-b;   % nonzero eigenvalues of I_n-B
%
% Set max times of iteration and tolerance level
%
if nargin<5
   E = 1e-10; 
end
if nargin<6
   M = 1000;
end
%
% generate p_{i,j} for recursive algorithm
%
pcoeff = zeros(pend,pend+M);
x = zeros(n,n,pend);
x(:,:,1) = eye(n);
if p>0
   x(:,:,2) = eye(n);
end
if ch==3
   x1 = x;
end
D = eb*ones(1,n);
for j=1:p
    x(:,:,j+1) = D.*x(:,:,j);
    for k=j:-1:2
        x(:,:,k) = A*x(:,:,k)+D.*x(:,:,k-1);
    end
    x(:,:,1) = A*x(:,:,1);
    for k=1:j+1
        pcoeff(j+2-k,k) = trace(x(:,:,k));
    end
end
if ch==3
   [P,D1] = eig(A);
   At = P*abs(D1)*P';
   pcoeff1 = zeros(pend,pend+M);
   for j=1:p
       x1(:,:,j+1) = D.*x1(:,:,j);
       for k=j:-1:2
           x1(:,:,k) = At*x1(:,:,k)+D.*x1(:,:,k-1);
       end
       x1(:,:,1) = At*x1(:,:,1);
       for k=1:j+1
           pcoeff1(j+2-k,k) = trace(x1(:,:,k));
       end
   end
end
%
% generate d_p(tilde{A}*B) for error bound 
%
e = ones(pend,1);
if p>0
   if ch==3
      c = eig(At./sqrt(b*b'));
   else
      c = eig(A./sqrt(b*b'));
   end
   tc = zeros(p,1);
   nc = ones(n,1);
   for i=1:p
       nc = nc.*c;
       tc(i) = sum(nc);
       e(i+1) = tc(i:-1:1)'*e(1:i)/(2*i);
   end
end
e = e(end)./sqrt(prod(b));
%
% generate d's and m's
%
d = zeros(pend,M+1);
d(1,1) = 1;
if ch==3
   d1 = d;
end
%
% when k==0
%
const = 1;
for i=1:p            
    d(i+1,1) = (d(1:i+1,1)'*pcoeff(i+1:-1:1,1))/(2*i);
    if ch==3
       d1(i+1,1) = (d1(1:i+1,1)'*pcoeff1(i+1:-1:1,1))/(2*i);
    end
    const = 2*maxea*const*i;
end
if rem(q,1)==0  % q is an integer
   for j=1:q
       const = const/((n+2*(p-j))*maxeb);
   end
else
   const = const*exp(gammaln(n2p-q)-gammaln(n2p))/((2*maxeb)^q);
end 
m = const*d(pend,1);     
const = const*q/n2p;
if ch==3
   e = e-d1(pend,1);
else
   e = e-d(pend,1);
end
err = e*const;
%
%   k>0
%
k1 = 2;
while err>E&&k1<=M+1
   for k=1:p
       x(:,:,k) = A*x(:,:,k+1)+D.*x(:,:,k);
       pcoeff(pend+1-k,k1+k-1) = trace(x(:,:,k));
   end
   x(:,:,pend) = D.*x(:,:,pend);
   pcoeff(1,p+k1) = trace(x(:,:,pend));
   if ch==3
      for k=1:p
          x1(:,:,k) = At*x1(:,:,k+1)+D.*x1(:,:,k);
          pcoeff1(pend+1-k,k1+k-1) = trace(x1(:,:,k));
      end
      x1(:,:,pend) = D.*x1(:,:,pend);
      pcoeff1(1,p+k1) = trace(x1(:,:,pend));
   end
   for p1=1:pend
       sx = 2*(p1+k1-2);
       d(p1,k1) = sum(sum(d(1:p1,1:k1).*pcoeff(p1:-1:1,k1:-1:1)))/sx;
       if ch==3
          d1(p1,k1) = sum(sum(d1(1:p1,1:k1).*pcoeff1(p1:-1:1,k1:-1:1)))/sx;
       end
   end
   m = m+const*d(pend,k1);
   const = const*(q+k1-1)/(n2p+k1-1);
   if ch==3
      e = e-d1(pend,k1);
   else
      e = e-d(pend,k1);
   end
   err = e*const;
   k1 = k1+1;
end
M0 = k1-2;
if ch==2
   m = -m; 
end
