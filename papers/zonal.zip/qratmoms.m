%
% qratmoms.m   Date: 2007/01/15
% This program computes E[(z'A'z)^p/(z'Bz)^q] when z ~ N(0,I), following
% Smith (1993)'s identity.
% B is assumed to be positive definite.
% This program uses the short recursive algorithm.
% Input: 
% A, B: matrix of the quadratic forms in the numerator and the denominator
% p, q: power of the quadratic forms in the numerator and the denominator
% E: precision, default is 1e-10
% M: maximum number of terms, default is 1000
% Output:
% m: E[(z'Az)^p/(z'Bz)^q] 
% err: upper bound of the approximation errors in m
% M0: number of terms to reach the desired level of precision
%
function [m,err,M0] = qratmoms(A,B,p,q,E,M)
pend = p+1;
n = size(A,1);
M0 = 0;
err = 0;
n2p = n/2+p;
if n2p<=q
   m = NaN;
   return
end
if q==0
   d = dkr(p,eig(A));
   m = prod([2:2:2*p])*d(end);
   return
end
%
%   Normalization of A and B such that
%   their largest eigenvalue is 1.
%
[P,B] = eig(B);
b = diag(B);
if any(b<=0)
   m = NaN;
   fprintf('B matrix must be positive definite!\n')
   return
end
A = P'*A*P;
ea = eig(A);
maxea = max(abs(ea));
A = A./maxea;
ch = 1;
if all(ea<=0)    % when A is negative semi-definite
   ch = 2;
   A = -A;
elseif rem(p,2)==1&&max(ea)*min(ea)<0
   ch = 3;
end
maxeb = max(b);
b = b./maxeb;
%
%   Generate p's for computing the d's
%   With our normalization of B, the last column of 
%   pp is zero as one of the eigenvalues of I_n-B is zero.
%
e = ones(pend,1);
pp = ecoeff2cq(A,1-b,p);
if p>0
   if ch==3
      [P,D] = eig(A);
      At = P*abs(D)*P';
      pp1 = ecoeff2cq(At,1-b,p);
      c = eig(At./sqrt(b*b'));
   else
      c = eig(A./sqrt(b*b'));
   end
%
% generate d_p(tilde{A}*B) for error bound 
%
   tc = zeros(p,1);
   nc = ones(n,1);
   for i=1:p
       nc = nc.*c;
       tc(i) = sum(nc);
       e(i+1) = tc(i:-1:1)'*e(1:i)/(2*i);
   end
end
e = e(end)./sqrt(prod(b));
%
% Set maximum times of iteration and tolerance level
%
if nargin<5
   E = 1e-10; 
end
if nargin<6
   M = 1000;
end
%
% generate d's and m's
%
d = zeros(pend,n+1);
d(1,1) = 1;
if ch==3
   d1 = d;
end
%
% when k==0
%
const = 1;
for i=1:p            
    index = [1:min(n,i)]';
    d(i+1,1) = sum((index-2*i).*pp(index+1,1).*d(i+1-index,1))/(2*i);
    if ch==3
       d1(i+1,1) = sum((index-2*i).*pp1(index+1,1).*d1(i+1-index,1))/(2*i);
    end
    const = 2*maxea*const*i;
end
if rem(q,1)==0  % q is an integer
   for j=1:q
       const = const/((n+2*(p-j))*maxeb);
   end
else
   const = const*exp(gammaln(n2p-q)-gammaln(n2p))/((2*maxeb)^q);
end      
m = const*d(pend,1);     
const = const*q/n2p;
if ch==3
   e = e-d1(pend,1);
else
   e = e-d(pend,1);
end
err = e*const;
%
%   k>0
%
k = 1;
while err>E&&k<=M
   if k>n
      k1 = n+1;
      d = [d(:,2:end) zeros(pend,1)];
      if ch==3
         d1 = [d1(:,2:end) zeros(pend,1)];
      end
   else
      k1 = k+1;
   end 
   for p1=1:pend
       sx = 2*(p1+k-1);
       for v2=0:min(n-1,k)   % Normally, it should be min(n,k) but pp has zero elements in its last column
           for v1=1-sign(v2):min(p1-1,n-v2)
               d(p1,k1) = d(p1,k1)+((v1+v2)/sx-1)*pp(v1+1,v2+1)*d(p1-v1,k1-v2);
           end
       end
       if ch==3
          for v2=0:min(n-1,k)   % Normally, it should be min(n,k) but pp1 has zero elements in its last column
              for v1=1-sign(v2):min(p1-1,n-v2)
                  d1(p1,k1) = d1(p1,k1)+((v1+v2)/sx-1)*pp1(v1+1,v2+1)*d1(p1-v1,k1-v2);
              end
          end
       end
   end
   m = m+const*d(pend,k1);
   const = const*(q+k)/(n2p+k);
   if ch==3
      e = e-d1(pend,k1);
   else
      e = e-d(pend,k1);
   end   
   err = e*const;
   k = k+1;
end
M0 = k-1;
if ch==2
   m = -m; 
end
