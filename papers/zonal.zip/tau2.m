function h = tau2(A,B)
%
%     This program computes the sum of the trace of different
%     premutations of 2 different matrices.  The output is
%     an (n+1)x(n+1) matrix with elements tau_{i-1,j-1}.
%     Algorithm: It is computed based on the fact that 
%     tr((x*A+y*B)^k) = \sum_{i=1}^n e_i'(x*A+y*B)^k e_i,
%     where e_i is the ith column of eye(n). 
%
n = size(A,1);
h = zeros(n+1);
h(2,1) = trace(A);
h(1,2) = trace(B);
x = zeros(n);    % A matrix to store the coefficients.
for i=1:n
    x(:,1:2) = [A(:,i) B(:,i)];
    for k1=2:n-1
        x(:,1:k1+1) = [A*x(:,1) A*x(:,2:k1)+B*x(:,1:k1-1) B*x(:,k1)];
        for j=0:k1
            h(k1-j+1,j+1) = h(k1-j+1,j+1)+x(i,j+1);
        end 
    end
%
%   Treat the last one differently as there is no need to carry
%   the matrix x any further.
%
    h(n+1,1) = h(n+1,1)+A(i,:)*x(:,1);
    h(1,n+1) = h(1,n+1)+B(i,:)*x(:,n);
    for j=1:n-1
        h(n-j+1,j+1) = h(n-j+1,j+1)+A(i,:)*x(:,j+1)+B(i,:)*x(:,j);
    end
end
