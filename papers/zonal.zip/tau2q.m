%     
%     This program computes p_{i,j}(A,B) using a fast
%     algorithm.  The output is an (n+1)x(n+1) matrix 
%     with elements p_{i-1,j-1}.
%
%     It calls tau2quad.mex32 that uses quadruple precision,
%     which is quite time consuming.
%     Usage: tau2q(A,b), where b is the column vector
%     of the diagonal elements of B.
%
function y = tau2q(A,B)
[P,D] = eig(B);
y = tau2quad(P'*A*P,diag(D));
