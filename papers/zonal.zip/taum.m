function p=taum(A,M)
%
%     This program computes the coefficients of t's in tr(t_1A_1+
%     t_2A_2+...+t_rA_r)^k, where k=0,1,...,M.
%     The output is a vector of length (M+r) choose r. The ordering is
%     based on \sum_{i=1}^m \nu_i, m = r, r-1,...,1.
%     Algorithm: It is computed based on the fact that
%     tr(A(t)^k) = \sum_{i=1}^n e_i'A(t)^k e_i,
%     where e_i is the ith column of eye(n).
%
n = size(A,1);
r = size(A,3);
if nargin==1
   M = n;
end
%
%   Quick return if M=1 or r=1
%
if M==1
   p = zeros(r+1,1);
   for i=1:r
       p(i+1) = trace(A(:,:,r-i+1));
   end
   return
end
if r==1
   d = eig(A);
   d0 = ones(n,1);
   p = zeros(M+1,1);
   for i=1:M
       d0 = d0.*d;
       p(i+1) = sum(d0);
   end
   return
end
%
%   F(i,j) is a matrix of nchoosek(i+j,j) for i=0,...M
%   and j=1,...,r.  F is created using a recursive
%   relation and the boundary conditions of:
%   F(0,j) = 1 and F(j,1) = j+1.
%
F = zeros(M+1,r);
F(1,:) = 1;
F(2:end,1) = 2:M+1;
for j=2:r
    for i=2:M+1
        F(i,j) = F(i,j-1)+F(i-1,j);
    end
end
lx0 = F(M,r-1);   % max length of x0, when |v|=M-1, there are (M+r-2,r-1) different coefficients
%
%   Create a matrix index which allows us to update the x0 matrix 
%   from block k to block k+1.
%
if r==2
   index = [2:M+1]';
else
   index = zeros(lx0,r-1);
   index(1,:) = 1;
   for k=1:M-1      
       lk = F(k+1,r-1);
       lk0 = F(k,r-1);
       index(lk0+1:lk,r-1) = F(k+1,r-2);
       for i=r-2:-1:2
           d = F(k,i);
           index(lk0+1:lk0+d,2:i) = index(lk0-d+1:lk0,2:i);
           lk0 = lk0+d;
           index(lk0+1:lk,i) = F(k+1,i-1);
       end
   end
   index(:,1) = 1;
   index(:,r-1) = index(:,r-1)+[1:lx0]';
   for i=r-2:-1:1
       index(:,i) = index(:,i)+index(:,i+1);
   end
end
%
% When k=1, p(2:r+1) are trace of A_r to trace of A_1
%
l = F(end);
p = zeros(l,1);
for i=1:r
    p(i+1) = trace(A(:,:,r-i+1));
end
lx = F(M-1,r-1);
x = zeros(n,lx);
for i=1:n         % trace of a matrix is equal to the sum of the diagonal elements
    x0 = zeros(n,lx0);
    x0(:,1:r) = A(:,i,r:-1:1);
    lk0 = F(2,r-1);
    for k=2:M-1          % |nu|=k
        x(:,1:lk0) = x0(:,1:lk0);           % copy the old x0 to x
        x0(:,1:lk0) = A(:,:,r)*x(:,1:lk0);  % updates of A_r from x to x0
        for j=1:r-1
            x0(:,index(1:lk0,j)) = x0(:,index(1:lk0,j))+A(:,:,j)*x(:,1:lk0);
        end
        sp = F(k,r);
        lk0 = F(k+1,r-1);       
        p(sp+1:sp+lk0) = p(sp+1:sp+lk0)+x0(i,1:lk0)';
    end
%
% Separately for k=M as there is no need to update x0 anymore
%
    sp = F(M,r);
    p(sp+1:sp+lx0) = p(sp+1:sp+lx0)+x0'*A(i,:,r)';
    for j=1:r-1
        p(sp+index(:,j)) = p(sp+index(:,j))+x0'*A(i,:,j)';
    end
end
