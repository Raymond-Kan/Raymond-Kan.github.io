function p=taumc(A,kappa,M)
%
%     This program computes the coefficients of t's in tr(t_1A_1+
%     t_2A_2+...+t_rA_r)^k, where k=0,1,...,min[M,|kappa|], with 
%     the constraint that the power of t_i smaller than or equal 
%     to kappa_i. The ordering is based on \sum_{j=1}^i \nu_j, 
%     i = r, r-1,...,1.
%     Algorithm: It is computed based on the fact that
%     tr(A(t)^k) = \sum_{i=1}^n e_i'A(t)^k e_i,
%     where e_i is the ith column of eye(n).
%
n = size(A,1);
if nargin==1
   kappa = n*ones(r,1);
end
if nargin<=2
   M = n;
end
h = find(kappa>0);
r = length(h);
kappa = kappa(h);
A = A(:,:,h);
kappa = min(kappa,M);
M = min(sum(kappa),M);
%
%   Quick return if M=1 or r=1
%
if M==1
   p(1) = 0;
   k=2;
   for i=1:r
       p(k) = trace(A(:,:,r-i+1));
       k=k+1;
   end
   return
end
if r==1
   d = eig(A);
   d0 = ones(n,1);
   p = zeros(M+1,1);
   for i=1:M
       d0 = d0.*d;
       p(i+1) = sum(d0);
   end
   return
end
%
%   F(i,j) is a matrix of number of partitions such that \nu_1+...+\nu_j=i
%   for i=0,...,M and j=1,...,r.  
%
[F,index] = findex(kappa,M);
lx0 = max(diff(F(:,r)));
%
% When k=1, p(2:r+1) are trace of A_r to trace of A_1
%
l = F(end);
p = zeros(l,1);
for i=1:r
    p(i+1) = trace(A(:,:,r-i+1));
end
x = zeros(n,lx0);
for i=1:n         % trace of a matrix is equal to the sum of the diagonal elements
    x0 = zeros(n,lx0);
    x0(:,1:r) = A(:,i,r:-1:1);
    lk0 = F(2,r)-F(1,r);
    for k=2:M-1          % |nu|=k
        x(:,1:lk0) = x0(:,1:lk0);           % copy the old x0 to x
        x0(:) = 0;
        for j=1:r
            h = index(F(k-1,r)+1:F(k-1,r)+lk0,j);
            lh = find(h>0);
            lh0 = h(lh);
            x0(:,lh0) = x0(:,lh0)+A(:,:,j)*x(:,lh);
        end
        sp = F(k,r);
        lk0 = F(k+1,r)-F(k,r);
        p(sp+1:sp+lk0) = p(sp+1:sp+lk0)+x0(i,1:lk0)';
    end
    %
    % Separately for k=M as there is no need to update x0 anymore
    %
    sp = F(M,r);
    for j=1:r
        h = index(F(M-1,r)+1:F(M-1,r)+lk0,j);
        lh = find(h>0);
        lh0 = h(lh);
        p(sp+lh0) = p(sp+lh0)+x0(:,lh)'*A(i,:,j)';
    end
end
