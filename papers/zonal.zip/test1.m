n = [2 4 6 8];
a = [1/2 1/3 1/4 1/5];
as = [sym('1/2') sym('1/3') sym('1/4') sym('1/5')];
alpha = 4;
beta = 6;
delete test1.out
diary test1.out
format long
fprintf(' Alpha = 4, a = [1/2 1/3 1/4 1/5]:\n')
y1 = mhyperpfqeven([],alpha,a,n)
y2 = mhyperpfqevens([],sym(alpha),as,n)
fprintf(' Alpha = 4, Beta = 6, a = [1/2 1/3 1/4 1/5]:\n')
y1 = mhyperpfqeven(alpha,beta,a,n)
y2 = mhyperpfqevens(sym(alpha),sym(beta),as,n)
alpha = [4 5];
beta = [6 7 8];
fprintf(' Alpha = [4 5], Beta = [6 7 8], a = [1/2 1/3 1/4 1/5]:\n')
y = mhyperpfqeven(alpha,beta,a,n)
y1 = mhyperpfqevens(sym(alpha),sym(beta),as,n)
diary off