n = 60;
x = randn(200,n);
A = (x'*x)./200;
x = randn(200,n);
B = (x'*x)./200;
C = cat(3,A,B);
k = [8 100];
delete test2.out
diary test2.out
tic, a = mdks2(A,B,k(1),k(2)); toc
tic, b = mdks2q(A,B,k(1),k(2)); toc
tic, c = mdks(C,k); toc
tic, d = mdksq(C,k); toc
tic, e = mdkl2(A,B,k(1),k(2)); toc
tic, f = mdkl2q(A,B,k(1),k(2)); toc
tic, g = mdkl(C,k); toc
tic, h = mdklq(C,k); toc
c = reshape(c,k+1);
d = reshape(d,k+1);
g = reshape(g,k+1);
h = reshape(h,k+1);
format long
a(end) 
b(end) 
c(end) 
d(end)
e(end) 
f(end) 
g(end) 
h(end)
diary off
