n = 20;
k = [4 6 8 3];
r = length(k);
A = zeros(n,n,r);
for i=1:r,
    x = randn(200,n);
    A(:,:,i) = (x'*x)./200;
end
delete test3.out
diary test3.out
tic, a = mdks(A,k); toc
tic, b = mdksq(A,k); toc
tic, c = mdkl(A,k); toc
tic, d = mdklq(A,k); toc
tic, e = invpoly_new(A,k); toc
a = reshape(a,k+1);
b = reshape(b,k+1);
c = reshape(c,k+1);
d = reshape(d,k+1);
e = reshape(e,k+1);
format long
[a(end) b(end) c(end) d(end) e(end)]
diary off
